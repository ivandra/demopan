<?php
require_once 'config.php'; // Подключаем файл с конфигурацией

// Устанавливаем заголовок для XML-файла
header("Content-Type: application/xml; charset=utf-8");

// Текущая дата в формате YYYY-MM-DD
$currentDate = date('Y-m-d');

// Формируем содержимое sitemap.xml
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
echo '    <url>' . "\n";
echo '        <loc>' . $domain . '/</loc>' . "\n";
echo '        <lastmod>' . $currentDate . '</lastmod>' . "\n";
echo '        <changefreq>monthly</changefreq>' . "\n";
echo '        <priority>1.0</priority>' . "\n";
echo '    </url>' . "\n";
echo '</urlset>';
?>