<?php
require_once __DIR__ . '/config.php';

header('Content-Type: text/plain; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

function sameHost($a, $b) {
    $hostA = parse_url(rtrim($a, '/'), PHP_URL_HOST);
    $hostB = parse_url(rtrim($b, '/'), PHP_URL_HOST);
    return mb_strtolower($hostA ?? '') === mb_strtolower($hostB ?? '');
}

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$currentBase = $scheme . '://' . $_SERVER['HTTP_HOST'];

// Если домен запроса не равен $domain из config — закрываем (старый домен)
if (!sameHost($currentBase, $domain)) {
    echo "User-agent: *\n";
    echo "Disallow: /\n";
    exit;
}

// Иначе — открыт (для актуального домена). /reg закрываем от поисковиков
// (страница регистрации редиректит на партнёрку, не должна индексироваться).
echo "User-agent: *\n";
echo "Allow: /\n";
echo "Disallow: /reg\n";
echo "Host: " . rtrim($domain, '/') . "/\n";
echo "Sitemap: " . rtrim($domain, '/') . "/sitemap.xml\n";