<?php
$domain = 'https://stake204.casino';
$yandex_verification = "727c0c1135400267";
$yandex_metrika = "";
$promolink = "/play";
?>