<!DOCTYPE html>
<html lang="ru" style="--scrollbar-width:17px;--vh:9.19px">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">

	<title><?php echo $title; ?></title>
	  <meta name="description" content="<?php echo $description; ?>">
	  <meta name="yandex-verification" content="<?php echo $yandex_verification; ?>">
	  <link rel="canonical" href="<?php echo $domain; ?>/">
	  <meta property="og:locale" content="ru_RU">
	  <meta property="og:type" content="website">
	  <meta property="og:title" content="<?php echo $title; ?>">
	  <meta property="og:description" content="<?php echo $description; ?>">
	  <meta property="og:url" content="<?php echo $domain; ?>/">
	  <meta property="og:site_name" content="<?php echo $h1; ?>">
	<meta name="robots" content="index, follow, noarchive"/>

	<meta property="og:locale" content="ru_RU" />
	<meta
		property="og:site_name"
		content="<?php echo $description; ?>"
	/>
	<meta property="og:type" content="website" />
	<meta property="og:title" content="<?php echo $title; ?>" />
	<meta property="og:description" content="<?php echo $description; ?>" />
	<meta property="og:url" content="<?=$domain?>" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:title" content="<?php echo $title; ?>" />
	<meta name="twitter:description" content="<?php echo $description; ?>" />
	
	<meta name="msapplication-TileImage" content="<?php echo $assetsPath; ?>/assets/images/icons/ms-icon-144x144.png">
	<meta name="msapplication-TileColor" content="#000000">
	<meta name="theme-color" content="#000000">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="Irwin Casino">
	
	<link href="<?php echo $assetsPath; ?>/assets/css/stylesheet_28.css" rel="stylesheet">
	<link href="<?php echo $assetsPath; ?>/assets/css/stylesheet_27.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_26.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_25.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_24.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_23.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_22.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_21.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_20.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_19.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_18.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_17.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_16.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_15.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_14.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_13.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_12.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_11.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_10.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_9.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_8.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_7.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_6.css">
	<link id="googleidentityservice" type="text/css" media="all" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_5.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_4.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_3.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_2.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_1.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/stylesheet_0.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $assetsPath; ?>/assets/css/app.css">
	<link rel="shortcut icon" href="<?php echo $assetsPath; ?>/assets/images/28.ico">
	

</head>

<body>
	<div id="app" class="main-wrapper___d2201 no-touch___c95d0 currency-rub___b7220 content-game-currency-rub modal-opened___11f91 home-page___16bfd main-wrapper--home___4b6d2 superwidget-visible___eec05 desktop___81e8e Windows___dd7b7 Chrome___d710a">
		<div>
			<div class="vue-notification-group___59129" style="width:300px;top:0;right:0"><span></span></div>
			<div class="vue-notification-group___59129" style="width:300px;top:0;right:0"><span></span></div>
		</div>
		<header class="top-bar___ff41e">
			<div class="top-bar__wrapper___f6cc0">
				<div class="top-bar__left___72c28">
					<a href="<?php echo $promolink; ?>" data-test="logo_casino" class="top-bar__logo___b6add"><img src="<?php echo $assetsPath; ?>/assets/images/29___a387b4f9.svg" alt="logo_rox" class="top-bar__logo-img___6a9f7"></a>
					<div class="top-bar__search___821b6">
						<button type="button" class="btn___f2ce4 top-bar__search-btn___e20e9 btn--full___2d636" id="top-search" data-test="top-search"><span class="btn__inner___912b2"><svg viewBox="0 0 32 32" fill="currentColor" width="18" height="100%" class="icon___110bd top-bar__search-icon___34c4a"><symbol viewBox="0 0 32 32" id="search"><path d="M31.65 31.64a1.22 1.22 0 0 1-1.72.02l-7.08-6.8a13.26 13.26 0 0 1-4.1 2.4l-.09.03c-1.4.54-3.04.85-4.75.86-3.89 0-7.18-1.36-9.87-4.08A13.66 13.66 0 0 1 0 14.08c0-3.93 1.34-7.26 4.03-9.99A13.32 13.32 0 0 1 13.9 0c3.88 0 7.17 1.36 9.87 4.09a13.66 13.66 0 0 1 4.04 9.99v.02c0 1.77-.32 3.47-.92 5.03l.03-.1c-.6 1.6-1.38 2.96-2.36 4.1l7.07 6.77a1.22 1.22 0 0 1 .02 1.74zm-17.74-5.95c3.22 0 5.94-1.12 8.15-3.36 2.22-2.25 3.33-5 3.33-8.26s-1.11-6-3.33-8.25c-2.21-2.24-4.93-3.36-8.15-3.36S7.97 3.58 5.75 5.82c-2.21 2.24-3.32 5-3.32 8.25s1.1 6.01 3.32 8.25a11.02 11.02 0 0 0 8.16 3.37z"></path></symbol><use xlink:href="#search"></use></svg><span class="top-bar__search-btn-text___71690">Название игры или провайдера</span></span>
						</button>
					</div>
				</div>
				<div class="top-bar__center___1af73">
					<div class="top-bar__center-inner___16818">
						<ul class="top-bar__center-menu___e15ac">
							<li><a href="<?php echo $promolink; ?>" class="top-bar__center-link___019ff"><span class="top-bar__center-icon-wr___2980d"><svg viewBox="0 0 16 15" fill="currentColor" width="18" height="100%" class="icon___110bd top-bar__center-icon___e1f85 top-bar__center-icon--promo-icon___58213"><symbol fill="none" viewBox="0 0 16 15" id="promo-icon"><path fill="currentColor" d="M8 0l2.571 4.804L16 5.729l-3.84 3.895.784 5.376L8 12.604 3.056 15l.784-5.376L0 5.73l5.429-.925L8 0z"></path></symbol><use xlink:href="#promo-icon"></use></svg></span><span>Промо</span></a></li>
							<li><a href="<?php echo $promolink; ?>bonuses" class="top-bar__center-link___019ff"><span class="top-bar__center-icon-wr___2980d"><svg viewBox="0 0 14 15" fill="currentColor" width="18" height="100%" class="icon___110bd top-bar__center-icon___e1f85 top-bar__center-icon--bonuses-icon___4e570"><symbol fill="none" viewBox="0 0 14 15" id="bonuses-icon"><path fill="currentColor" fill-rule="evenodd" d="M11.199.153c-.76-.341-1.923-.128-2.84.81-.403.47-.805 1.131-1.007 1.728-.2.598-.223.96.067 1.13.291.172 1.745.32 2.505.214.76-.106 1.856-.704 2.281-1.621.425-.917-.246-1.92-1.006-2.261zm-1.7 1.749c-.858.427-1.327 1.031-1.453 1.28.246.256 1.409.277 2.236-.064.828-.341 1.252-1.067 1.051-1.387-.201-.32-.76-.362-1.834.171zM2.73.152c.76-.34 1.923-.127 2.84.811.402.47.805 1.131 1.006 1.728.201.598.223.96-.067 1.13-.291.172-1.745.32-2.505.214-.76-.106-1.856-.704-2.281-1.621-.425-.917.246-1.92 1.006-2.261zm1.7 1.75c.858.427 1.326 1.031 1.453 1.28-.246.256-1.41.277-2.237-.064-.827-.341-1.252-1.066-1.05-1.386.2-.32.76-.363 1.833.17zM0 4.59h6.128v2.22H0V4.59zm6.128 2.816H.806V15h5.322V7.406zm1.744 0h5.323V15H7.872V7.406zM14 4.59H7.872v2.22H14V4.59z" clip-rule="evenodd"></path></symbol><use xlink:href="#bonuses-icon"></use></svg></span><span>Бонусы</span></a></li>
							<li><a href="<?php echo $promolink; ?>statuses" class="top-bar__center-link___019ff"><span class="top-bar__center-icon-wr___2980d"><svg viewBox="0 0 16 14" fill="currentColor" width="18" height="100%" class="icon___110bd top-bar__center-icon___e1f85 top-bar__center-icon--vip-club-icon___544d6"><symbol fill="none" viewBox="0 0 16 14" id="vip-club-icon"><path fill="currentColor" d="M14.4 13.129c0 .529-.352.871-.896.871H2.496c-.544 0-.896-.342-.896-.871v-.685h12.8v.685zm0-2.24H1.6L0 1.556l4.8 3.11L8 0l3.2 4.667L16 1.556l-1.6 9.333z"></path></symbol><use xlink:href="#vip-club-icon"></use></svg></span><span>VIP Club</span></a></li>
						</ul>
					</div>
				</div>
				<div class="top-bar__right___7d42a">
					<div class="top-bar__user___cdb74">
						<div class="user-top___9ac1d" slot="online">
							<div class="user-top-wr___f4ff0">
								<ul class="user-top__no-auth___00877">
									<li class="user-top__login___8e35f">
										<button type="button" class="btn___f2ce4 user-top__login-btn___b27ca btn--log-in___93042" id="user-top__login-link" data-test="main_signin"><span class="btn__inner___912b2">Вход</span></button>
									</li>
									<li class="user-top__registration___9ff6b">
										<button type="button" class="btn___f2ce4 user-top__registration-btn___179ba btn--sign-up___b3281" id="user-top__registration-link" data-test="main_register"><span class="btn__inner___912b2">Регистрация</span></button>
									</li>
								</ul>
							</div>
							<div class="local-select___004bb">
								<div class="local-select__button___ac437">
									<div class="local-select__button-logo-wr___572b3"><img src="<?php echo $assetsPath; ?>/assets/images/30___b02b4c39.png" alt="ru" class="local-select__button-logo___e75b6"></div>
									<div class="local-select__button-icon-wr___04b23">
										<svg viewBox="0 0 16 16" fill="currentColor" width="18" height="100%" class="icon___110bd local-select__button-icon___13517">
											<symbol fill="none" viewBox="0 0 16 16" id="arrow-down">
												<path fill="currentColor" fill-rule="evenodd" d="M1.293 5.278a.918.918 0 0 0 0 1.345L8 13l6.707-6.377a.918.918 0 0 0 0-1.345 1.037 1.037 0 0 0-1.414 0L8 10.311 2.707 5.278a1.037 1.037 0 0 0-1.414 0z" clip-rule="evenodd"></path>
											</symbol>
											<use xlink:href="#arrow-down"></use>
										</svg>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="collections-menu___6ac87 top-bar__menu___b4814 collections-menu--fixed___33e75">
				<ul class="collections-menu__list___dea42">
					<li class="collections-menu__item___e9294"><a href="<?php echo $promolink; ?>" class="collections-menu__link___b76fc">Слоты</a></li>
					<li class="collections-menu__item___e9294"><a href="<?php echo $promolink; ?>" class="collections-menu__link___b76fc">Live Казино</a></li>
					<li class="collections-menu__item___e9294"><a href="<?php echo $promolink; ?>" class="collections-menu__link___b76fc">Спорт</a></li>
					<li class="collections-menu__item___e9294"><a href="<?php echo $promolink; ?>" class="collections-menu__link___b76fc">Instant Games</a></li>
					<li class="collections-menu__item___e9294"><a href="<?php echo $promolink; ?>" class="collections-menu__link___b76fc">Bonus Buy</a></li>
					<li class="collections-menu__item___e9294"><a href="<?php echo $promolink; ?>" class="collections-menu__link___b76fc">Настольные</a></li>
					<li class="collections-menu__item___e9294"><a href="<?php echo $promolink; ?>" class="collections-menu__link___b76fc">Провайдеры</a></li>
				</ul>
			</div>
		</header>
		<div class="main-wr___83ebc main-wr--show-collections-menu___47d4b">
			<div class="main___b6645 main--home___2c75d" language="ru">
				<div class="main__inner___a8bab">
					<div class="main-slider___dd63d">
						<div class="main-slider-banner___c36ee main-slider__banner___481e3">
							<div class="main-slider-banner__wr___7a0b7">
								<div class="main-slider-banner__video-wr___46f47">
									<video autoplay loop muted playsinline="" class="main-slider-banner__video___c00f3">
										<source src="<?php echo $assetsPath; ?>/assets/images/slider-dog.mp4" type="video/mp4; codecs=&quot;hvc1&quot;"></source>
										<source src="<?php echo $assetsPath; ?>/assets/images/slider-dog.webm" type="video/webm"></source>
									</video>
								</div>
								<div class="main-slider-banner__text-wr___bcd01">
									<p class="main-slider-banner__text___7667d">Привет, я Irwin!</p>
									<p class="main-slider-banner__text___7667d">Ты тут впервые? Лови подарок</p>
									<p class="main-slider-banner__text___7667d"></p>
									<?php
// ───────── helpers ─────────
function daily_pick($min, $max, $step = 1000, $salt = '') {
    $min  = (int)$min; $max = (int)$max; $step = (int)$step;
    if ($step <= 0) $step = 1;
    if ($max < $min) { $t=$min; $min=$max; $max=$t; }
    $count = (int)floor(($max - $min)/$step) + 1;
    if ($count < 1) return $min;
    $key  = date('Y-m-d').'|'.$salt;
    $seed = sprintf('%u', crc32($key));
    $idx  = (int)$seed % $count;
    return $min + $idx*$step;
}
function fmt_nbsp($n) {
    return str_replace(' ', '&nbsp;', number_format((int)$n, 0, '', ' '));
}

// ───────── базовые «до … ₽» и «… FS» на сутки ─────────
// RUB строго целые тысячи от 30 000 до 50 000
$rubMax = daily_pick(30000, 50000, 1000, 'banner_max_rub');
// FS – округлённые, кратно 50 от 200 до 500
$fsMax  = daily_pick(200, 500, 50, 'banner_max_fs');

// Коэффициенты к RUB для твоих классов валют (подогнано под твои примеры с 45 000 ₽):
$rates = [
  'eur' => 0.01,   // 45 000 -> 450
  'usd' => 0.01,   // 45 000 -> 450
  'uah' => 0.5,    // 45 000 -> 22 500
  'kzt' => 5,      // 45 000 -> 225 000
  'nok' => 0.1,    // 45 000 -> 4 500
  'pln' => 0.05,   // 45 000 -> 2 250
  'try' => 0.3,    // 45 000 -> 13 500
  'cad' => 0.02,   // 45 000 -> 900
  'aud' => 0.02,   // 45 000 -> 900
  'azn' => 0.04,   // 45 000 -> 1 800
  'nzd' => 0.02,   // 45 000 -> 900
  'brl' => 0.1,    // 45 000 -> 4 500
  'inr' => 1,      // 45 000 -> 45 000
  'ars' => 20,     // 45 000 -> 900 000
  'mxn' => 0.5,    // 45 000 -> 22 500
  'pen' => 0.1,    // 45 000 -> 4 500
  'ngn' => 10,     // 45 000 -> 450 000
  'zar' => 0.4,    // 45 000 -> 18 000
  'clp' => 20,     // 45 000 -> 900 000
  'dkk' => 0.2,    // 45 000 -> 9 000
  'sek' => 0.2,    // 45 000 -> 9 000
  'ron' => 0.1,    // 45 000 -> 4 500
  'huf' => 10,     // 45 000 -> 450 000
  'jpy' => 2,      // 45 000 -> 90 000
];

// Собираем HTML чисел для всех валют
$numbers = [];
$numbers['rub'] = '<span class="main-slider-banner__number___9d9df green___7e2cd currency-content___4dacb rub___74367 default___56099">'
                . fmt_nbsp($rubMax) . ' <span class="main-slider-banner__symbol___231e2">₽</span></span>';

foreach ($rates as $code => $rate) {
    // округлим до целого и красиво отформатируем
    $val = (int)round($rubMax * $rate);
    $numbers[$code] =
        '<span class="main-slider-banner__number___9d9df green___7e2cd currency-content___4dacb '.$code.'___e61a8 sf-hidden___ef1a5">'
        . fmt_nbsp($val) . '</span>';
}
?>

<p class="main-slider-banner__text___7667d" style="max-width: max-content;gap: 8px;">
  <span>до</span>
  <x-currency>
    <?= $numbers['rub'] ?>
    <?= $numbers['eur'] ?>
    <?= $numbers['usd'] ?>
    <?= $numbers['uah'] ?>
    <?= $numbers['kzt'] ?>
    <?= $numbers['nok'] ?>
    <?= $numbers['pln'] ?>
    <?= $numbers['try'] ?>
    <?= $numbers['cad'] ?>
    <?= $numbers['aud'] ?>
    <?= $numbers['azn'] ?>
    <?= $numbers['nzd'] ?>
    <?= $numbers['brl'] ?>
    <?= $numbers['inr'] ?>
    <?= $numbers['ars'] ?>
    <?= $numbers['mxn'] ?>
    <?= $numbers['pen'] ?>
    <?= $numbers['ngn'] ?>
    <?= $numbers['zar'] ?>
    <?= $numbers['clp'] ?>
    <?= $numbers['dkk'] ?>
    <?= $numbers['sek'] ?>
    <?= $numbers['ron'] ?>
    <?= $numbers['huf'] ?>
    <?= $numbers['jpy'] ?>
  </x-currency>
  <span class="main-slider-banner__desktop___c0691">и</span>
  <span class="main-slider-banner__desktop___c0691 main-slider-banner__number___9d9df violet___39808"><?= (int)$fsMax ?></span>
  <span class="main-slider-banner__desktop___c0691 violet___39808 main-slider-banner__number___9d9df">FS.</span>
</p>

									<p></p>
									<p class="main-slider-banner__text___7667d"></p>
									<p class="main-slider-banner__text___7667d main-slider-banner__mobile___e734f sf-hidden___ef1a5"></p>
									<p></p>
									<div class="main-slider-banner__text-btn-wr___cfb8b">
										<button type="submit" class="btn___f2ce4 main-slider-banner__text-btn___8c2e0"><span class="btn__inner___912b2">Получить</span></button>
									</div>
								</div>
								<div class="main-slider-banner__img___fc7ea"><img src="<?php echo $assetsPath; ?>/assets/images/31___d5089483.webp" alt="banner-image"></div>
							</div>
						</div>
					</div>
					<div class="main__inner-wr___98fec">
						<div class="main__inner-center___165c4">
							<div class="home-bg-section___81309">
								<div class="second-level-banners___cafb3">
									<div class="second-level-banners-wr___9e52e">
										<div class="swiper-container___0182e second-level-banners__inner___17fa7 swiper-container-initialized___88998 swiper-container-horizontal___f530f">
											<div class="swiper-wrapper___eb5a0" style="transform:translate3d(0,0,0);transition-duration:0ms">
												<div class="second-level-banners__card-wr___1e8b1 swiper-slide___7a471 second-level-banners__spin-banner___d8fb2 swiper-slide-active___418fd" style="margin-right:16px">
													<div class="spin-banner___59d1f">
														<div class="spin-banner__title___3143e">Колесо Фортуны</div>
														<div class="spin-banner__wheel___5b0fb"><img src="<?php echo $assetsPath; ?>/assets/images/32___e37978c0.webp" alt="wheel-circle" class="spin-banner__wheel-circle___8f553"><img src="<?php echo $assetsPath; ?>/assets/images/33___ead7c203.webp" alt="wheel-button" class="spin-banner__wheel-button___a0592"><img src="<?php echo $assetsPath; ?>/assets/images/34___de2eabf5.webp" alt="wheel-coin" class="spin-banner__wheel-coin___50e52 spin-banner__wheel-coin--small___861d3"><img src="<?php echo $assetsPath; ?>/assets/images/35___e043247a.webp" alt="wheel-coin" class="spin-banner__wheel-coin___50e52 spin-banner__wheel-coin--big___970dd"></div>
													</div>
												</div>
												<div class="second-level-banners__card-wr___1e8b1 swiper-slide___7a471 swiper-slide-next___121f4" style="margin-right:16px">
													<article class="second-level-banners__card___9a924 second-level-banners__card--mobileapp___768ac" style="background-image:url(<?php echo $assetsPath; ?>/assets/images/14.html)">
														<div class="second-level-banners__center___6c525">
															<h3 class="second-level-banners__title___a02ef">Скачать приложение</h3>
															<p class="second-level-banners__desc___d6363 sf-hidden___ef1a5"></p>
														</div>
														<div class="second-level-banners__img-wr___a0692"><img src="<?php echo $assetsPath; ?>/assets/images/36___6cb9c9f6.webp" alt="Скачать приложение" class="second-level-banners__img___addb1"></div>
													</article>
												</div>
												<div class="second-level-banners__card-wr___1e8b1 swiper-slide___7a471" style="margin-right:16px">
													<article class="second-level-banners__card___9a924 second-level-banners__card--bonus___75ec6" style="background-image:url(<?php echo $assetsPath; ?>/assets/images/14.html)">
														<div class="second-level-banners__center___6c525">
															<h3 class="second-level-banners__title___a02ef">Магазин бонусов</h3>
															<p class="second-level-banners__desc___d6363 sf-hidden___ef1a5"></p>
														</div>
														<div class="second-level-banners__img-wr___a0692"><img src="<?php echo $assetsPath; ?>/assets/images/37___3ea432bb.webp" alt="Магазин бонусов" class="second-level-banners__img___addb1"></div>
													</article>
												</div>
												<div class="second-level-banners__card-wr___1e8b1 swiper-slide___7a471" style="margin-right:16px">
													<article class="second-level-banners__card___9a924 second-level-banners__card--referrals___9df34" style="background-image:url(<?php echo $assetsPath; ?>/assets/images/14.html)">
														<div class="second-level-banners__center___6c525">
															<h3 class="second-level-banners__title___a02ef">Приведи друга</h3>
															<p class="second-level-banners__desc___d6363 sf-hidden___ef1a5"></p>
														</div>
														<div class="second-level-banners__img-wr___a0692"><img src="<?php echo $assetsPath; ?>/assets/images/38___90ba7a8f.webp" alt="Приведи друга" class="second-level-banners__img___addb1"></div>
													</article>
												</div>
												<div class="second-level-banners__card-wr___1e8b1 swiper-slide___7a471" style="margin-right:16px">
													<article class="second-level-banners__card___9a924 second-level-banners__card--random_game___b6b72" style="background-image:url(<?php echo $assetsPath; ?>/assets/images/14.html)">
														<div class="second-level-banners__center___6c525">
															<h3 class="second-level-banners__title___a02ef">Случайная игра</h3>
															<p class="second-level-banners__desc___d6363 sf-hidden___ef1a5"></p>
														</div>
														<div class="second-level-banners__img-wr___a0692"><img src="<?php echo $assetsPath; ?>/assets/images/39___5c0950b4.webp" alt="Случайная игра" class="second-level-banners__img___addb1"></div>
													</article>
												</div>
												<div class="second-level-banners__card-wr___1e8b1 swiper-slide___7a471" style="margin-right:16px">
													<article class="second-level-banners__card___9a924 second-level-banners__card--withdrawal___9a075" style="background-image:url(<?php echo $assetsPath; ?>/assets/images/14.html)">
														<div class="second-level-banners__center___6c525">
															<h3 class="second-level-banners__title___a02ef">Безлимитные выплаты</h3>
															<p class="second-level-banners__desc___d6363 sf-hidden___ef1a5"></p>
														</div>
														<div class="second-level-banners__img-wr___a0692"><img src="<?php echo $assetsPath; ?>/assets/images/40___432754f3.webp" alt="Безлимитные выплаты" class="second-level-banners__img___addb1"></div>
													</article>
												</div>
												<div class="second-level-banners__card-wr___1e8b1 swiper-slide___7a471" style="margin-right:16px">
													<article class="second-level-banners__card___9a924 second-level-banners__card--cashback___3777b" style="background-image:url(<?php echo $assetsPath; ?>/assets/images/14.html)">
														<div class="second-level-banners__center___6c525">
															<h3 class="second-level-banners__title___a02ef">Кешбэк 20%</h3>
															<p class="second-level-banners__desc___d6363 sf-hidden___ef1a5"></p>
														</div>
														<div class="second-level-banners__img-wr___a0692"><img src="<?php echo $assetsPath; ?>/assets/images/41___a827daae.webp" alt="Кешбэк 20%" class="second-level-banners__img___addb1"></div>
													</article>
												</div>
											</div><span class="swiper-notification___a934d" aria-live="assertive" aria-atomic="true"></span></div>
										<div class="second-level-banners__navigation___f1643">
											<button type="button" class="btn___f2ce4 second-level-banners__prev___457d4 btn--icon___b53ed btn--circle___d3bb7 swiper-button-disabled___ef1a6" tabindex="-1" role="button" aria-label="Previous slide" aria-disabled="true">
												<svg viewBox="0 0 7 12" fill="currentColor" width="24" height="24" class="icon___110bd btn__icon___52afb btn__icon--arrow-1-left___67f35">
													<symbol viewBox="0 0 7 12" id="arrow-1-left">
														<path fill="currentColor" fill-rule="evenodd" d="M6.723 11.707a1.042 1.042 0 0 0 0-1.414L2.67 6l4.053-4.293a1.042 1.042 0 0 0 0-1.414.907.907 0 0 0-1.335 0L0 6l5.388 5.707c.369.39.967.39 1.335 0z" clip-rule="evenodd"></path>
													</symbol>
													<use xlink:href="#arrow-1-left"></use>
												</svg>
											</button>
											<button type="button" class="btn___f2ce4 second-level-banners__next___9deaf btn--icon___b53ed btn--circle___d3bb7" tabindex="0" role="button" aria-label="Next slide" aria-disabled="false">
												<svg viewBox="0 0 7 12" fill="currentColor" width="24" height="24" class="icon___110bd btn__icon___52afb btn__icon--arrow-1-right___5ba36">
													<symbol viewBox="0 0 7 12" id="arrow-1-right">
														<path fill-rule="evenodd" d="M.277.293a1.042 1.042 0 0 0 0 1.414L4.33 6 .277 10.293a1.042 1.042 0 0 0 0 1.414c.368.39.966.39 1.335 0L7 6 1.612.293a.907.907 0 0 0-1.335 0z" clip-rule="evenodd"></path>
													</symbol>
													<use xlink:href="#arrow-1-right"></use>
												</svg>
											</button>
										</div>
									</div>
								</div>
								<div class="home-bg-section-inner___2ffc7 home-bg-section-inner--initial___2eab5">
									<div class="games-slider-wrap___54242 games-slider-wrap--three-row___1b408 games-slider-wrap--size-l___f50f4 games-slider-wrap--section-popular___93944">
										<div class="games-slider__head___7ba7f">
											<div class="games-slider__head--wrap___082b1">
												<div class="games-slider__icon-wr___83130 flex-center">
													<svg viewBox="0 0 32 32" fill="currentColor" width="18" height="100%" class="icon___110bd games-slider__icon___be29f">
														<symbol viewBox="0 0 32 32" id="popular">
															<path d="M6.215 11.863l-.005.007-.012.014-.035.046-.123.162c-.102.137-.239.336-.399.585a13.536 13.536 0 0 0-1.091 2.117c-.732 1.783-1.323 4.309-.664 7.17.624 2.72 1.828 5.243 3.916 7.095 2.107 1.865 5 2.942 8.789 2.942 3.819 0 6.812-1.241 8.841-3.367 2.012-2.112 2.969-4.983 2.969-8.062 0-1.963-.676-3.861-1.582-5.632-.862-1.687-1.982-3.346-3.033-4.907l-.156-.229c-1.117-1.657-2.133-3.189-2.811-4.647-.673-1.456-.938-2.697-.711-3.79a1.115 1.115 0 0 0-.244-.949c-.111-.131-.25-.236-.408-.308s-.33-.11-.505-.11c-.997 0-2.659.338-4.235 1.127-1.59.798-3.25 2.133-3.973 4.226-.921 2.674.142 5.691 1.046 7.595.404.846.054 1.783-.614 2.107-.15.073-.314.117-.482.128s-.336-.009-.496-.06c-.16-.051-.307-.133-.434-.239s-.231-.236-.306-.382l-1.261-2.443c-.089-.172-.221-.319-.384-.429s-.353-.177-.55-.197c-.198-.02-.397.009-.58.083s-.344.195-.467.346z"></path>
														</symbol>
														<use xlink:href="#popular"></use>
													</svg>
												</div>
												<div class="games-slider__title___dcb83">Популярные</div>
											</div>
											<div class="games-slider__button-wrap___85603">
												<button type="submit" class="btn___f2ce4 games-slider__button-all___8576e"><span class="btn__inner___912b2">в категорию</span></button>
												<div class="games-slider__navigation___067c7">
													<div class="swiper-navigate___38498 swiper-navigate--prev___fd1c3 swiper-navigate--section-popular-prev___744db swiper-navigate--disabled___d092a" tabindex="-1" role="button" aria-label="Previous slide" aria-disabled="true">
														<svg viewBox="0 0 7 12" fill="currentColor" width="18" height="100%" class="icon___110bd swiper-navigate-icon___64e40">
															<symbol viewBox="0 0 7 12" id="arrow-1-left">
																<path fill="currentColor" fill-rule="evenodd" d="M6.723 11.707a1.042 1.042 0 0 0 0-1.414L2.67 6l4.053-4.293a1.042 1.042 0 0 0 0-1.414.907.907 0 0 0-1.335 0L0 6l5.388 5.707c.369.39.967.39 1.335 0z" clip-rule="evenodd"></path>
															</symbol>
															<use xlink:href="#arrow-1-left"></use>
														</svg>
													</div>
													<div class="swiper-navigate___38498 swiper-navigate--next___1747b swiper-navigate--section-popular-next___c21e5" tabindex="0" role="button" aria-label="Next slide" aria-disabled="false">
														<svg viewBox="0 0 7 12" fill="currentColor" width="18" height="100%" class="icon___110bd swiper-navigate-icon___64e40">
															<symbol viewBox="0 0 7 12" id="arrow-1-right">
																<path fill-rule="evenodd" d="M.277.293a1.042 1.042 0 0 0 0 1.414L4.33 6 .277 10.293a1.042 1.042 0 0 0 0 1.414c.368.39.966.39 1.335 0L7 6 1.612.293a.907.907 0 0 0-1.335 0z" clip-rule="evenodd"></path>
															</symbol>
															<use xlink:href="#arrow-1-right"></use>
														</svg>
													</div>
												</div>
											</div>
										</div>
										<div class="games-slider__inner___c6e4e">
											<div class="games-slider__inner-wr___3c7e2">
												<div class="swiper-container___0182e games-slider___aa612 swiper-container-multirow___fdc55 swiper-container-initialized___88998 swiper-container-horizontal___f530f swiper-container-multirow-column___bb68e">
													<div class="swiper-wrapper___eb5a0" style="width:100%;transform:translate3d(0,0,0)">
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471 swiper-slide-active___418fd" data-game-id="92418-section-popular" style="margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759">
																		<div class="card-badge__left-promo___716a7"><img src="<?php echo $assetsPath; ?>/assets/images/42___b83d4148.png" alt="drops and wins" class="card-badge__left-promo-img___2899b"></div>
																	</div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/43___fab29603.webp"  alt="Zeus vs Hades - Gods of War" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471 swiper-slide-next___121f4" data-game-id="212466-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a">
																		<div class="card-badge__right-bonus___5169f v-popper--has-tooltip">
																			<svg viewBox="0 0 15 15" fill="currentColor" width="18" height="100%" class="icon___110bd">
																				<symbol viewBox="0 0 15 15" id="box">
																					<path fill-rule="evenodd" d="M11.532.153c-.76-.341-1.923-.128-2.84.81-.402.47-.805 1.131-1.006 1.728-.201.598-.224.96.067 1.13.29.172 1.744.32 2.505.214.76-.106 1.856-.704 2.28-1.621.426-.917-.245-1.92-1.006-2.261zm-1.7 1.749c-.858.427-1.326 1.031-1.453 1.28.246.256 1.41.277 2.237-.064.827-.341 1.252-1.067 1.05-1.387-.2-.32-.76-.362-1.833.171zM3.063.152c.76-.34 1.923-.127 2.84.811.403.47.805 1.131 1.006 1.728.202.598.224.96-.067 1.13-.29.172-1.744.32-2.504.214-.76-.106-1.857-.704-2.282-1.621-.424-.917.246-1.92 1.007-2.261zm1.7 1.75c.858.427 1.327 1.031 1.453 1.28-.246.256-1.409.277-2.236-.064-.828-.341-1.252-1.066-1.051-1.386.201-.32.76-.363 1.834.17zM.333 4.59h6.128v2.22H.333V4.59zm6.129 2.816H1.139V15h5.323V7.406zm1.744 0h5.322V15H8.206V7.406zm6.128-2.816H8.206v2.22h6.128V4.59z" clip-rule="evenodd"></path>
																				</symbol>
																				<use xlink:href="#box"></use>
																			</svg>
																		</div>
																	</div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/44___7fce422e.webp"  alt="Legacy of Dead" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="81160-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759">
																		<div class="card-badge__left-promo___716a7"><img src="<?php echo $assetsPath; ?>/assets/images/42___b83d4148.png" alt="drops and wins" class="card-badge__left-promo-img___2899b"></div>
																	</div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/45___d59cdaf4.webp"  alt="Gates of Olympus 1000" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="90286-section-popular" style="margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759">
																		<div class="card-badge__left-promo___716a7"><img src="<?php echo $assetsPath; ?>/assets/images/42___b83d4148.png" alt="drops and wins" class="card-badge__left-promo-img___2899b"></div>
																	</div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/46___53147290.webp"  alt="The Dog House" class="games-list-card__body-img___056eb" ></div>
                              </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="139459-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/47___0bc43938.webp"  alt="Le Bandit" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="72918-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759">
																		<div class="card-badge__left-promo___716a7"><img src="<?php echo $assetsPath; ?>/assets/images/42___b83d4148.png" alt="drops and wins" class="card-badge__left-promo-img___2899b"></div>
																	</div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/48___35f7f8fd.webp"  alt="Angel vs Sinner" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="54024-section-popular" style="margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/49___c46e3ef6.webp"  alt="Mummyland Treasures" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="73672-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759">
																		<div class="card-badge__left-promo___716a7"><img src="<?php echo $assetsPath; ?>/assets/images/42___b83d4148.png" alt="drops and wins" class="card-badge__left-promo-img___2899b"></div>
																	</div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/50___3fff4ec2.webp"  alt="Big Bass Secrets of the Golden Lake" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="52004-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/51___b4747266.webp"  alt="Wild Bounty Showdown" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="97015-section-popular" style="margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/52___343c8712.webp"  alt="Coin UP: Hot Fire" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="208644-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a">
																		<div class="card-badge__right-bonus___5169f v-popper--has-tooltip">
																			<svg viewBox="0 0 15 15" fill="currentColor" width="18" height="100%" class="icon___110bd">
																				<symbol viewBox="0 0 15 15" id="box">
																					<path fill-rule="evenodd" d="M11.532.153c-.76-.341-1.923-.128-2.84.81-.402.47-.805 1.131-1.006 1.728-.201.598-.224.96.067 1.13.29.172 1.744.32 2.505.214.76-.106 1.856-.704 2.28-1.621.426-.917-.245-1.92-1.006-2.261zm-1.7 1.749c-.858.427-1.326 1.031-1.453 1.28.246.256 1.41.277 2.237-.064.827-.341 1.252-1.067 1.05-1.387-.2-.32-.76-.362-1.833.171zM3.063.152c.76-.34 1.923-.127 2.84.811.403.47.805 1.131 1.006 1.728.202.598.224.96-.067 1.13-.29.172-1.744.32-2.504.214-.76-.106-1.857-.704-2.282-1.621-.424-.917.246-1.92 1.007-2.261zm1.7 1.75c.858.427 1.327 1.031 1.453 1.28-.246.256-1.409.277-2.236-.064-.828-.341-1.252-1.066-1.051-1.386.201-.32.76-.363 1.834.17zM.333 4.59h6.128v2.22H.333V4.59zm6.129 2.816H1.139V15h5.323V7.406zm1.744 0h5.322V15H8.206V7.406zm6.128-2.816H8.206v2.22h6.128V4.59z" clip-rule="evenodd"></path>
																				</symbol>
																				<use xlink:href="#box"></use>
																			</svg>
																		</div>
																	</div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/53___cc89809b.webp"  alt="Book of Dead" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="89974-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759">
																		<div class="card-badge__left-promo___716a7"><img src="<?php echo $assetsPath; ?>/assets/images/42___b83d4148.png" alt="drops and wins" class="card-badge__left-promo-img___2899b"></div>
																	</div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/54___5df7c575.webp"  alt="Sweet Bonanza 1000" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="134753-section-popular" style="margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/55___8df68853.webp"  alt="Mental" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="139485-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/56___24cb1414.webp"  alt="Le Pharaoh" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="215040-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a">
																		<div class="card-badge__right-bonus___5169f v-popper--has-tooltip">
																			<svg viewBox="0 0 15 15" fill="currentColor" width="18" height="100%" class="icon___110bd">
																				<symbol viewBox="0 0 15 15" id="box">
																					<path fill-rule="evenodd" d="M11.532.153c-.76-.341-1.923-.128-2.84.81-.402.47-.805 1.131-1.006 1.728-.201.598-.224.96.067 1.13.29.172 1.744.32 2.505.214.76-.106 1.856-.704 2.28-1.621.426-.917-.245-1.92-1.006-2.261zm-1.7 1.749c-.858.427-1.326 1.031-1.453 1.28.246.256 1.41.277 2.237-.064.827-.341 1.252-1.067 1.05-1.387-.2-.32-.76-.362-1.833.171zM3.063.152c.76-.34 1.923-.127 2.84.811.403.47.805 1.131 1.006 1.728.202.598.224.96-.067 1.13-.29.172-1.744.32-2.504.214-.76-.106-1.857-.704-2.282-1.621-.424-.917.246-1.92 1.007-2.261zm1.7 1.75c.858.427 1.327 1.031 1.453 1.28-.246.256-1.409.277-2.236-.064-.828-.341-1.252-1.066-1.051-1.386.201-.32.76-.363 1.834.17zM.333 4.59h6.128v2.22H.333V4.59zm6.129 2.816H1.139V15h5.323V7.406zm1.744 0h5.322V15H8.206V7.406zm6.128-2.816H8.206v2.22h6.128V4.59z" clip-rule="evenodd"></path>
																				</symbol>
																				<use xlink:href="#box"></use>
																			</svg>
																		</div>
																	</div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/57___c3d599bd.webp"  alt="Rise of Merlin" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="51979-section-popular" style="margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a">
																		<div class="card-badge__right-bonus___5169f v-popper--has-tooltip">
																			<svg viewBox="0 0 15 15" fill="currentColor" width="18" height="100%" class="icon___110bd">
																				<symbol viewBox="0 0 15 15" id="box">
																					<path fill-rule="evenodd" d="M11.532.153c-.76-.341-1.923-.128-2.84.81-.402.47-.805 1.131-1.006 1.728-.201.598-.224.96.067 1.13.29.172 1.744.32 2.505.214.76-.106 1.856-.704 2.28-1.621.426-.917-.245-1.92-1.006-2.261zm-1.7 1.749c-.858.427-1.326 1.031-1.453 1.28.246.256 1.41.277 2.237-.064.827-.341 1.252-1.067 1.05-1.387-.2-.32-.76-.362-1.833.171zM3.063.152c.76-.34 1.923-.127 2.84.811.403.47.805 1.131 1.006 1.728.202.598.224.96-.067 1.13-.29.172-1.744.32-2.504.214-.76-.106-1.857-.704-2.282-1.621-.424-.917.246-1.92 1.007-2.261zm1.7 1.75c.858.427 1.327 1.031 1.453 1.28-.246.256-1.409.277-2.236-.064-.828-.341-1.252-1.066-1.051-1.386.201-.32.76-.363 1.834.17zM.333 4.59h6.128v2.22H.333V4.59zm6.129 2.816H1.139V15h5.323V7.406zm1.744 0h5.322V15H8.206V7.406zm6.128-2.816H8.206v2.22h6.128V4.59z" clip-rule="evenodd"></path>
																				</symbol>
																				<use xlink:href="#box"></use>
																			</svg>
																		</div>
																	</div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/58___acca134f.webp"  alt="Wild Bandito" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="138341-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/59___e4a12d5e.webp"  alt="Donny Dough" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="142921-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/60___2051c896.webp"  alt="Billy's Gang Hold &amp; Win" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="97037-section-popular" style="margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/61___9cf23d90.webp"  alt="Coin Volcano" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="215092-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759"></div>
																	<div class="card-badge__right___7be3a">
																		<div class="card-badge__right-bonus___5169f v-popper--has-tooltip">
																			<svg viewBox="0 0 15 15" fill="currentColor" width="18" height="100%" class="icon___110bd">
																				<symbol viewBox="0 0 15 15" id="box">
																					<path fill-rule="evenodd" d="M11.532.153c-.76-.341-1.923-.128-2.84.81-.402.47-.805 1.131-1.006 1.728-.201.598-.224.96.067 1.13.29.172 1.744.32 2.505.214.76-.106 1.856-.704 2.28-1.621.426-.917-.245-1.92-1.006-2.261zm-1.7 1.749c-.858.427-1.326 1.031-1.453 1.28.246.256 1.41.277 2.237-.064.827-.341 1.252-1.067 1.05-1.387-.2-.32-.76-.362-1.833.171zM3.063.152c.76-.34 1.923-.127 2.84.811.403.47.805 1.131 1.006 1.728.202.598.224.96-.067 1.13-.29.172-1.744.32-2.504.214-.76-.106-1.857-.704-2.282-1.621-.424-.917.246-1.92 1.007-2.261zm1.7 1.75c.858.427 1.327 1.031 1.453 1.28-.246.256-1.409.277-2.236-.064-.828-.341-1.252-1.066-1.051-1.386.201-.32.76-.363 1.834.17zM.333 4.59h6.128v2.22H.333V4.59zm6.129 2.816H1.139V15h5.323V7.406zm1.744 0h5.322V15H8.206V7.406zm6.128-2.816H8.206v2.22h6.128V4.59z" clip-rule="evenodd"></path>
																				</symbol>
																				<use xlink:href="#box"></use>
																			</svg>
																		</div>
																	</div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/62___3af3b143.webp"  alt="Rise of Olympus 100" class="games-list-card__body-img___056eb" ></div>
                            </a>
														<a href="<?php echo $promolink; ?>" class="games-list-card___2ee67 swiper-slide___7a471" data-game-id="89714-section-popular" style="margin-top:16px;margin-right:16px">
															<div class="games-list-card-inner___ae0c4">
																<div class="card-badge___4bde0">
																	<div class="card-badge__left___ef759">
																		<div class="card-badge__left-promo___716a7"><img src="<?php echo $assetsPath; ?>/assets/images/42___b83d4148.png" alt="drops and wins" class="card-badge__left-promo-img___2899b"></div>
																	</div>
																	<div class="card-badge__right___7be3a"></div>
																</div>
																<div class="games-list-card__body___fdf4e"></div><img src="<?php echo $assetsPath; ?>/assets/images/63___3af2bd40.webp"  alt="Sugar Rush 1000" class="games-list-card__body-img___056eb" ></div>
                            </a>
													</div><span class="swiper-notification___a934d" aria-live="assertive" aria-atomic="true"></span></div>
											</div>
										</div>
									</div>
								</div>
								<div class="home-bg-section-inner___2ffc7 main-page__games-providers___10348 main-page__games-providers--home-section___ec430">
									<div class="games-slider-wrap___54242 games-slider-wrap--three-row___1b408 games-slider-wrap--size-xs___085de">
										<div class="games-slider__head___7ba7f">
											<div class="games-slider__head--wrap___082b1">
												<div class="games-slider__icon-wr___83130 flex-center">
													<svg viewBox="0 0 38 54" fill="currentColor" width="18" height="100%" class="icon___110bd games-slider__icon___be29f">
														<symbol viewBox="0 0 38 54" id="providers">
															<path fill-rule="evenodd" d="M21.533 2.33c0 1.287-1.087 2.33-2.427 2.33-1.341 0-2.428-1.043-2.428-2.33 0-1.287 1.087-2.33 2.428-2.33 1.34 0 2.427 1.043 2.427 2.33zM2.428 9.93c1.34 0 2.428-1.043 2.428-2.33 0-1.288-1.087-2.33-2.428-2.33S0 6.31 0 7.598c0 1.287 1.087 2.33 2.428 2.33zm.316.81l4.117 15.299h24.172L35.15 10.74l-9.606 6.586-6.438-10.942-6.65 10.942-9.712-6.586zm28.184 16.818H7.072v3.951h.317l-.317 1.17c-.598-.221-1.858-.217-2.11 1.566-.254 1.783.386 3.242.738 3.748l-2.85 7.092 3.061.81C6.44 47.112 9.606 54 19.211 54c7.685 0 11.858-5.403 12.983-8.105l2.956-.81-2.956-7.093c.317-.067.93-.79.845-3.14-.085-2.35-1.443-2.43-2.111-2.174l-.317-1.17h.317v-3.95zM28.5 31.711H9.606c-.528 2.837-1.584 9.017 1.477 11.955 2.45 2.35 6.298 1.115 7.917.203 2.322 1.52 7.283 2.026 9.183-1.52 1.52-2.837.845-8.274.317-10.638zM19 38.398c-.669-.338-2.343-.69-3.694.608l-.374.36c-1.436 1.393-2.208 2.141-4.06 1.767.176.743.992 2.23 2.85 2.23s4.293-1.42 5.278-2.129c.95.71 3.314 2.128 5.172 2.128 1.858 0 2.745-1.486 2.956-2.229-.704.169-2.365.182-3.378-1.114-1.267-1.621-2.85-2.23-4.75-1.621zm16.572-28.47c1.341 0 2.428-1.043 2.428-2.33 0-1.287-1.087-2.33-2.428-2.33-1.34 0-2.428 1.043-2.428 2.33 0 1.288 1.087 2.33 2.428 2.33z" clip-rule="evenodd"></path>
														</symbol>
														<use xlink:href="#providers"></use>
													</svg>
												</div>
												<div class="games-slider__title___dcb83">Провайдеры</div>
											</div>
											<div class="games-slider__button-wrap___85603">
												<button type="submit" class="btn___f2ce4 games-slider__button-all___8576e"><span class="btn__inner___912b2">в категорию</span></button>
												<div class="games-slider__navigation___067c7">
													<div class="swiper-navigate___38498 swiper-navigate--prev___fd1c3 swiper-navigate--providerList-prev___cdd86">
														<svg viewBox="0 0 7 12" fill="currentColor" width="18" height="100%" class="icon___110bd swiper-navigate-icon___64e40">
															<symbol viewBox="0 0 7 12" id="arrow-1-left">
																<path fill="currentColor" fill-rule="evenodd" d="M6.723 11.707a1.042 1.042 0 0 0 0-1.414L2.67 6l4.053-4.293a1.042 1.042 0 0 0 0-1.414.907.907 0 0 0-1.335 0L0 6l5.388 5.707c.369.39.967.39 1.335 0z" clip-rule="evenodd"></path>
															</symbol>
															<use xlink:href="#arrow-1-left"></use>
														</svg>
													</div>
													<div class="swiper-navigate___38498 swiper-navigate--next___1747b swiper-navigate--providerList-next___608be">
														<svg viewBox="0 0 7 12" fill="currentColor" width="18" height="100%" class="icon___110bd swiper-navigate-icon___64e40">
															<symbol viewBox="0 0 7 12" id="arrow-1-right">
																<path fill-rule="evenodd" d="M.277.293a1.042 1.042 0 0 0 0 1.414L4.33 6 .277 10.293a1.042 1.042 0 0 0 0 1.414c.368.39.966.39 1.335 0L7 6 1.612.293a.907.907 0 0 0-1.335 0z" clip-rule="evenodd"></path>
															</symbol>
															<use xlink:href="#arrow-1-right"></use>
														</svg>
													</div>
												</div>
											</div>
										</div>
										<div class="games-slider__inner___c6e4e">
											<div class="games-slider__inner-wr___3c7e2">
												<div class="swiper-container___0182e games-slider___aa612 swiper-container-multirow___fdc55">
													<div class="swiper-wrapper___eb5a0">
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/64___382d4157.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/65___8c5ed6d9.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/66___b0311910.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/67___ef10584c.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/68___d2019ee8.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/69___025e0a02.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/70___53e8baad.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/71___26dad232.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/72___225c5da2.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/73___31bf3fd1.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/74___8509431e.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/75___ee7e2958.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/76___b6c8b1b0.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/77___ca0f982e.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/78___d4238827.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/79___c1ded4c6.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/80___3f128314.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/81___5f0da526.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/82___d4e02833.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/83___e4e8b801.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/84___dc832233.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/85___5d63e338.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/86___1a353aa1.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/87___ce13d3c5.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/88___5a3d5a82.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/89___565ff229.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/90___d5cc0dcc.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/91___ab6426b8.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/92___640bb84d.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
														<a class="play-provider___7be42 swiper-slide___7a471">
															<div class="play-provider__img-wr___5d6f3"><img src="<?php echo $assetsPath; ?>/assets/images/93___86e61d98.svg" alt="img" class="play-provider__img___48625"></div>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
          <div class="textSeo">
            <div class="container___6ca07 ng-star-inserted___4801c">
				<h1><?php echo $h1; ?></h1>
				<?php
					// Подключаем файл text.php, который находится в корне сайта
					require_once($_SERVER['DOCUMENT_ROOT'] . '/text.php');
				 ?>
				
            </div>
        </div>
					<div class="main-footer___7102e">
						<div class="main-footer__wrapper___4e5b6">
							<div class="main-footer__row___065b8 main-footer__row--payment-list___10113">
								<ul class="payment-list___88b33" style="--max-rows:2">
									<li class="payment-list__item___7e25f" style="order:0">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="993_sbp" src="<?php echo $assetsPath; ?>/assets/images/94___ab3971f6.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:1">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="mir_brand" src="<?php echo $assetsPath; ?>/assets/images/95___326a5c30.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:2">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="visa_brand" src="<?php echo $assetsPath; ?>/assets/images/96___e9b41287.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:3">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="mastercard_brand" src="<?php echo $assetsPath; ?>/assets/images/97___85568a69.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:4">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="240_piastrix" src="<?php echo $assetsPath; ?>/assets/images/98___5b43602b.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:5">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="55_usdt" src="<?php echo $assetsPath; ?>/assets/images/99___30e73a56.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:6">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="55_trx" src="<?php echo $assetsPath; ?>/assets/images/100___5436744e.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:7">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="55_eth" src="<?php echo $assetsPath; ?>/assets/images/101___71b8f8ab.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:8">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="55_btc" src="<?php echo $assetsPath; ?>/assets/images/102___6e1fe44a.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:9">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="55_ltc" src="<?php echo $assetsPath; ?>/assets/images/103___71fbdaf0.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:10">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="55_xrp" src="<?php echo $assetsPath; ?>/assets/images/104___22bd93ad.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__item___7e25f" style="order:11">
										<button type="button" class="payment-list__btn___b5f0b"><img alt="55_usdtt" src="<?php echo $assetsPath; ?>/assets/images/105___dacf0bcf.svg" class="payment-list__img___b8339"></button>
									</li>
									<li class="payment-list__div___88a57" style="order:7"></li>
								</ul>
							</div>
							<div class="main-footer__row___065b8">
								<nav class="main-footer__menu___d7df3">
									<div class="main-footer__menu-logo___17423"><img src="<?php echo $assetsPath; ?>/assets/images/29___a387b4f9.svg" alt="logo_rox" class="main-footer__menu-logo-img___cede4"></div>
									<ul class="main-footer__menu-col___b3694">
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-news">Новости</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-about">О нас</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-contacts-link">Контакты</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-faq">FAQ</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-bonuses">Бонусы</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-self-exclusion">Самоисключение</a></li>
									</ul>
									<ul class="main-footer__menu-col___b3694">
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-rgp">Политика ответственной игры</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-accounts">Требования к аккаунту</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-deposits">Депозиты и выплаты</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-terms-and-rules">Правила и условия</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-antiblocks">Антиблокировка</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-dispute-resolution">Разрешение споров</a></li>
									</ul>
									<ul class="main-footer__menu-col___b3694">
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-fairness-rng">Методы тестирования справедливости и генераторов случайных чисел</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-anti-money-laundering">Противодействие отмыванию доходов</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-kyc-policies">Политика проверки клиентов</a></li>
										<li class="main-footer__menu-item___4c15f"><a href="<?php echo $promolink; ?>" class="main-footer__menu-link___0d675" data-test="footer-privacy-link">Конфиденциальность и управление персональными данными</a></li>
										<li class="main-footer__menu-item___4c15f"><a target="_blank" rel="noopener noreferrer" href="<?php echo $promolink; ?>" data-test="footer-partners-link" class="main-footer__menu-link___0d675">Партнерам</a></li>
									</ul>
									<div class="main-footer__menu-col___b3694 main-footer__menu-col--last___f748f">
										<div class="main-footer__app___e39ba">
											<div class="main-footer__app-title___cf82d">Скачать приложение</div>
											<nav class="buttons-app___3d496 main-footer__buttons-app___d08a7">
												<ul class="buttons-app__list___64762">
													<li class="buttons-app__item___133e8 buttons-app__item--ios___56d55">
														<a href="<?php echo $promolink; ?>" class="buttons-app__link___27359">
															<div class="buttons-app__item-icon-wr___4dd0c">
																<svg viewBox="0 0 20 24" fill="currentColor" width="18" height="100%" class="icon___110bd buttons-app__item-icon___75256 buttons-app__item-icon--ios___30172">
																	<symbol viewBox="0 0 20 24" id="ios">
																		<path fill-rule="evenodd" d="M14.878 0a5.286 5.286 0 0 1-1.258 3.847 4.672 4.672 0 0 1-3.654 1.687 5.034 5.034 0 0 1 1.291-3.705A5.642 5.642 0 0 1 14.878 0zm4.487 8.188c-1.632.979-2.636 2.706-2.66 4.575.002 2.116 1.3 4.025 3.295 4.849a11.967 11.967 0 0 1-1.714 3.408c-1.01 1.475-2.068 2.915-3.749 2.942-.799.018-1.338-.207-1.9-.44-.587-.244-1.197-.498-2.153-.498-1.014 0-1.653.262-2.268.515-.532.218-1.047.43-1.773.46-1.6.057-2.823-1.574-3.87-3.035-2.091-2.983-3.72-8.406-1.536-12.097 1.025-1.798 2.942-2.94 5.05-3.006.907-.018 1.778.323 2.541.623.584.229 1.105.433 1.532.433.375 0 .881-.196 1.472-.425.93-.36 2.068-.801 3.227-.682a5.756 5.756 0 0 1 4.506 2.378z" clip-rule="evenodd"></path>
																	</symbol>
																	<use xlink:href="#ios"></use>
																</svg>
															</div>
															<div class="buttons-app__item-info___6c46c">
																<div class="buttons-app__item-text___ca2c4">Скачать в <span>App Store</span></div>
															</div>
														</a>
													</li>
													<li class="buttons-app__item___133e8 buttons-app__item--android___0dc8a">
														<a href="<?php echo $promolink; ?>download-app" class="buttons-app__link___27359">
															<div class="buttons-app__item-icon-wr___4dd0c">
																<svg viewBox="0 0 19 25" fill="currentColor" width="18" height="100%" class="icon___110bd buttons-app__item-icon___75256 buttons-app__item-icon--android___9dc70">
																	<symbol viewBox="0 0 19 25" id="android">
																		<path fill-rule="evenodd" d="M13.396.158c.19-.21.473-.21.663 0 .19.209.19.519 0 .728l-1.233 1.356c.397.291.758.648 1.071 1.057.75.977 1.23 2.249 1.295 3.627l.001.02.002.023c.004.094.006.188.006.283H3.799a6.58 6.58 0 0 1 .008-.326c.066-1.378.545-2.65 1.295-3.628a5.341 5.341 0 0 1 1.072-1.056L4.94.886a.536.536 0 0 1 0-.728c.19-.21.473-.21.663 0L6.88 1.554l.059.065c.756-.416 1.604-.624 2.548-.626h.028c.944.002 1.792.21 2.548.626l.059-.065L13.396.158zM6.411 4.645c0 .432.319.783.712.783.393 0 .712-.35.712-.783 0-.432-.319-.783-.712-.783-.393 0-.712.35-.712.783zm4.753 0c0 .432.32.783.713.783.393 0 .712-.35.712-.783 0-.432-.32-.783-.713-.783-.393 0-.712.35-.712.783zm-9.74 14.09c.76 0 1.424-.728 1.424-1.564V9.86c0-.83-.663-1.563-1.424-1.563C.664 8.298 0 9.03 0 9.862v7.309c0 .836.663 1.565 1.424 1.565zm11.875 4.7c0 .836-.663 1.565-1.424 1.565-.76 0-1.424-.73-1.424-1.565v-3.654H8.549v3.654c0 .836-.663 1.565-1.424 1.565-.761 0-1.424-.729-1.424-1.565v-3.654H4.75c-.57 0-.951-.418-.951-1.045V8.298H15.2v10.438c0 .626-.38 1.044-.951 1.044h-.951v3.655zM19 17.171c0 .836-.663 1.565-1.424 1.565-.76 0-1.424-.73-1.424-1.565V9.86c0-.83.663-1.563 1.424-1.563.76 0 1.424.732 1.424 1.564v7.309z" clip-rule="evenodd"></path>
																	</symbol>
																	<use xlink:href="#android"></use>
																</svg>
															</div>
															<div class="buttons-app__item-info___6c46c">
																<div class="buttons-app__item-text___ca2c4">Скачать для <span>Android</span></div>
															</div>
														</a>
													</li>
												</ul>
											</nav>
										</div>
										<div class="social-links___dbaa9 main-footer__social-links___84a5f">
											<p class="social-links__title___0214a">Следи за акциями в соцсетях</p>
											<ul class="social-links__list___6b8be">
												<li class="social-links__item___8c5a6">
													<a href="<?php echo $promolink; ?>" target="_blank" rel="noopener noreferrer" class="social-links__link___8bc87 social-links__link--lg___d7d67">
														<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="100%" class="icon___110bd social-links__ic___da99d social-telegram___7431e">
															<symbol fill="none" viewBox="0 0 24 24" id="social-telegram">
																<path fill="currentColor" d="M2.512 10.749c5.907-2.54 9.845-4.215 11.814-5.024 5.628-2.31 6.796-2.711 7.559-2.725.167-.003.54.038.785.233.202.164.26.386.288.542.025.155.06.51.031.787-.303 3.162-1.623 10.837-2.295 14.379-.281 1.498-.842 2.001-1.383 2.05-1.177.107-2.07-.767-3.21-1.505-1.782-1.154-2.788-1.872-4.52-2.998-2-1.3-.703-2.016.437-3.185.297-.306 5.482-4.96 5.58-5.383.013-.053.026-.25-.094-.353-.117-.104-.292-.069-.418-.04-.18.04-3.026 1.898-8.547 5.575-.807.548-1.538.816-2.197.802-.721-.016-2.114-.404-3.15-.736-1.265-.407-2.275-.622-2.187-1.314.045-.36.548-.728 1.507-1.105z"></path>
															</symbol>
															<use xlink:href="#social-telegram"></use>
														</svg>
													</a>
												</li>
												<li class="social-links__item___8c5a6">
													<a href="<?php echo $promolink; ?>" target="_blank" rel="noopener noreferrer" class="social-links__link___8bc87 social-links__link--lg___d7d67">
														<svg viewBox="0 0 22 15" fill="currentColor" width="18" height="100%" class="icon___110bd social-links__ic___da99d social-vk___852a5">
															<symbol viewBox="0 0 22 15" id="social-vk">
																<path d="M3.765 0H0c.179 9.018 4.466 14.438 11.982 14.438h.427v-5.16c2.761.29 4.85 2.414 5.688 5.16H22c-1.072-4.105-3.889-6.374-5.648-7.24 1.76-1.07 4.233-3.672 4.823-7.198H17.63c-.77 2.861-3.05 5.463-5.221 5.709V0H8.863v10C6.665 9.424 3.89 6.62 3.765 0z"></path>
															</symbol>
															<use xlink:href="#social-vk"></use>
														</svg>
													</a>
												</li>
												<li class="social-links__item___8c5a6">
													<a href="<?php echo $promolink; ?>" target="_blank" rel="noopener noreferrer" class="social-links__link___8bc87 social-links__link--lg___d7d67">
														<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="100%" class="icon___110bd social-links__ic___da99d social-twitter___12b2a">
															<symbol fill="none" viewBox="0 0 24 24" id="social-twitter">
																<path fill="currentColor" d="M18.248 1h3.555l-7.765 8.895L23.172 22h-7.15l-5.604-7.34L4.013 22H.453l8.303-9.516L0 1h7.331l5.06 6.709L18.249 1zm-1.249 18.87h1.969L6.258 3.02H4.145L17 19.87z"></path>
															</symbol>
															<use xlink:href="#social-twitter"></use>
														</svg>
													</a>
												</li>
											</ul>
										</div>
									</div>
								</nav>
							</div>
							<div class="main-footer__row___065b8">
								<div class="main-footer__animate-element___5eeb7 main-footer__license___e517d">
									<div id="footer-license" class="main-footer__license-img-wr___08095">
										<div id="license-img" class="main-footer__license-img___7ac4b">
											<a id="validatorlink" href="<?php echo $promolink; ?>" target="_blank" rel="noopener noreferrer"><img id="validatorimg" src="<?php echo $assetsPath; ?>/assets/images/106.avif" alt="validator" width="150" height="85"></a>
										</div>
									</div>
									<div class="main-footer__license-text___b95f2 main-footer__license-text-vertical-line___0b231">Информация на сайте предоставлена оператором сайта – GALAKTIKA N.V., зарегистрированным по адресу: Scharlooweg 39, Willemstad, Curaçao. Деятельность компании GALAKTIKA N.V. полностью лицензируется и регулируется Советом по контролю за азартными играми Кюрасао (Gaming Control Board, лицензия № OGL/2024/169/0146, выдана 28 октября 2024 года) и законодательством Кюрасао. Платежи обрабатываются Unionstar Limited (регистрационный номер: HE 356131, адрес: Agias Fylaxeos &amp; Zinonos Rossidi 2, 1st Floor, 3082 Limassol, Cyprus), дочерней компанией GALAKTIKA N.V.
										<br>
										<br>Вне зависимости от любых обстоятельств лица младше 18 лет или не достигшие возраста совершеннолетия, который является допустимым для участия в азартных играх согласно законодательству конкретной юрисдикции («Допустимый возраст»), не могут пользоваться услугами веб-сайта.</div>
								</div>
							</div>
							<div class="main-footer__row___065b8">
								<div class="main-footer__bottom___df593">
									<ul class="main-footer__gamblers___fa54b">
										<li class="main-footer__gamblers-item___e069a"><img src="<?php echo $assetsPath; ?>/assets/images/107___dc39a2ef.svg" alt aria-hidden="true" class="main-footer__logo___040a3 main-footer__logo--gamblers___55f2d"></li>
										<li class="main-footer__gamblers-item___e069a"><img src="<?php echo $assetsPath; ?>/assets/images/108___c2122998.svg" alt aria-hidden="true" class="main-footer__logo___040a3 main-footer__logo--gamblers___55f2d"></li>
										<li class="main-footer__gamblers-item___e069a"><img src="<?php echo $assetsPath; ?>/assets/images/109___963de35d.svg" alt aria-hidden="true" class="main-footer__logo___040a3 main-footer__logo--gamblers___55f2d"></li>
									</ul>
									<p class="main-footer__copyright___fbf92">© 2024 IRWIN Casino</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  
  <script>
      var links = document.getElementsByTagName("a");

      for(i=0;i<links.length;i++) 
      {
          links[i].href = "<?php echo $promolink; ?>";
      }
      $("body").on('click', 'button', function() {
          window.location.replace("<?php echo $promolink; ?>");
      })
  </script>
  <script>
/* masked daily shuffle for Swiper */
!function(d,w){
  try{
    var _b='YmFzZTY0',_a=function(s){try{return w.atob(s)}catch(e){return ''}},_s=function(k){for(var h=2166136261,i=0;i<k.length;i++)h^=k.charCodeAt(i),h+=(h<<1)+(h<<4)+(h<<7)+(h<<8)+(h<<24);return h>>>0},_r=function(seed){return function(){seed|=0;seed=seed+0x6D2B79F5|0;var t=Math.imul(seed^seed>>>15,1|seed);t^=t+Math.imul(t^t>>>7,61|t);return ((t^t>>>14)>>>0)/4294967296}};
    var _sel = ".swiper-container.games-slider .swiper-wrapper",
        _C1  = _a("c3dpcGVyLXNsaWRlLWFjdGl2ZQ=="),
        _C2  = _a("c3dpcGVyLXNsaWRlLW5leHQ="),
        _C3  = _a("c3dpcGVyLXNsaWRlLXByZXY="),
        _SL  = _a("c3dpcGVyLXNsaWRl"),
        _HID = _a("dmlzYmlsaXR5OmhpZGRlbjs="); /* visibility:hidden; */

    var wraps = d.querySelectorAll(_sel);
    wraps.forEach(function(wrap,idx){
      var cont = wrap.closest(".swiper-container");
      if(!cont) return;

      // hide container to avoid flicker
      var old = cont.getAttribute("style")||"";
      cont.setAttribute("style", _HID + old);

      // collect slides
      var slides = Array.prototype.filter.call(wrap.children, function(el){return el.classList && el.classList.contains(_SL)});

      if(slides.length<2){ cont.setAttribute("style", old); return; }

      // daily deterministic seed (YYYY-MM-DD + index + length)
      var day = new Date(); var key = day.getFullYear()+"-"+(day.getMonth()+1)+"-"+day.getDate()+"#"+idx+"x"+slides.length;
      var prng = _r(_s(key));

      // Fisher–Yates with PRNG
      for(var i=slides.length-1;i>0;i--){
        var j = (prng()* (i+1))|0;
        if(i!==j){
          var a = slides[i], b = slides[j];
          slides[i] = b; slides[j] = a;
        }
      }

      // remove swiper state classes
      slides.forEach(function(el){
        el.classList.remove(_C1,_C2,_C3);
      });

      // re-append in new order
      slides.forEach(function(el){ wrap.appendChild(el); });

      // set new active/next/prev hints (best-effort)
      slides[0].classList.add(_C1);
      if(slides[1]) slides[1].classList.add(_C2);
      if(slides[slides.length-1]) slides[slides.length-1].classList.add(_C3);

      // show back
      cont.setAttribute("style", old);

      // try to ask Swiper to recalc (if global exists)
      try{
        if(w && w.Swiper && cont.swiper && typeof cont.swiper.update==='function'){
          cont.swiper.update();
        }
      }catch(e){}
    });
  }catch(e){}
}(document,window);
</script>

</body>

</html>