<h1>Ирвин казино официальный сайт</h1>
        
      <!-- Главное меню навигации -->
      <nav class="main-nav">
        <ul>
          <li>
            <a href="/" class="active">
              Главная
            </a>
          </li>
          <li>
            <a href="/slots/" >
              Игровые автоматы
            </a>
          </li>
          <li>
            <a href="/game-slots/" >
              Слоты
            </a>
          </li>
          <li>
            <a href="/bonuses/" >
              Бонусы
            </a>
          </li>
          <li>
            <a href="/mirror/" >
              Зеркало
            </a>
          </li>
          <li>
            <a href="/reviews/" >
              Отзывы
            </a>
          </li>
          <li>
            <a href="/mobile/" >
              Мобильная версия
            </a>
          </li>
        </ul>
      </nav>
      <!-- Хлебные крошки -->
      <div class="breadcrumbs">
        <ul itemscope itemtype="https://schema.org/BreadcrumbList">
          <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
            <a itemprop="item" href="/">
              <span itemprop="name">
                Главная
              </span>
            </a>
            <meta itemprop="position" content="1" />
          </li>
        </ul>
      </div>
      <!-- Баннеры -->
      <div class="banner-container">
        <div class="banner">
          <div class="banner-image">
            Бонус за регистрацию
          </div>
          <div class="banner-content">
            <h3 class="banner-title">
              Получите 150% бонус на первый депозит до 30,000 рублей
            </h3>
            <p class="banner-description">
              Начните играть с тройным балансом! Просто зарегистрируйтесь и сделайте свой первый депозит.
            </p>
            <a href="/bonuses/" class="banner-button">
              Получить бонус
            </a>
          </div>
        </div>
        <div class="banner">
          <div class="banner-image">
            Турнир недели
          </div>
          <div class="banner-content">
            <h3 class="banner-title">
              Турнир недели
            </h3>
            <p class="banner-description">
              Призовой фонд 1,000,000 рублей. Играйте в избранные слоты и поднимайтесь в турнирной таблице!
            </p>
            <a href="#" class="banner-button">
              Участвовать
            </a>
          </div>
        </div>
      </div>
      <!-- Популярные слоты -->
      <h3 class="section-title">
        Популярные слоты
      </h3>
      <!-- Блок фильтров по провайдеру -->
      <div class="filters-container">
        <div class="filters-title">
          Фильтровать по провайдеру:
        </div>
        <div class="filters-options">
          <div class="filter-option active" data-provider="all">
            Все
          </div>
          <div class="filter-option" data-provider="Igrosoft">
            Igrosoft                
          </div>
          <div class="filter-option" data-provider="NetEnt">
            NetEnt                
          </div>
          <div class="filter-option" data-provider="Novomatic">
            Novomatic                
          </div>
          <div class="filter-option" data-provider="Playson">
            Playson                
          </div>
          <div class="filter-option" data-provider="Push Gaming">
            Push Gaming                
          </div>
        </div>
      </div>
      <!-- Блок фильтров по рейтингу -->
      <div class="filters-container">
        <div class="filters-title">
          Фильтровать по рейтингу:
        </div>
        <div class="filters-options rating-filters">
          <div class="filter-option rating-option active" data-rating="all">
            Все
          </div>
          <div class="filter-option rating-option" data-rating="5">
            5.0 ★
          </div>
          <div class="filter-option rating-option" data-rating="4">
            4.0+ ★
          </div>
          <div class="filter-option rating-option" data-rating="3">
            3.0+ ★
          </div>
        </div>
      </div>
      <!-- Счетчик результатов -->
      <div class="results-count">
        Показано: 
        <span id="visible-count">
          1374
        </span>
        из 1374 слотов
      </div>
      <div class="slots-grid">
        <div class="slot-card" data-provider="Playson" data-rating="4.2">
          <div class="slot-image">
            Book of Ra                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Book of Ra
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/book-of-ra-1" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.6">
          <div class="slot-image">
            Fruit Cocktail                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Fruit Cocktail
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/fruit-cocktail-2" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.2">
          <div class="slot-image">
            Crazy Monkey                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Crazy Monkey
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/crazy-monkey-3" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.4">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Lucky Lady&#039;s Charm                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Lucky Lady&#039;s Charm
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/lucky-ladys-charm-4" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.8">
          <div class="slot-image">
            Resident                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Resident
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/resident-5" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.4">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Always Hot                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Always Hot
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/always-hot-6" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.5">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Happy Fishing                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Happy Fishing
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.5                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/happy-fishing-7" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.3">
          <div class="slot-image">
            Eye of Horus                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Eye of Horus
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/eye-of-horus-8" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.2">
          <div class="slot-image">
            Sizzling Hot                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Sizzling Hot
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/sizzling-hot-9" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.3">
          <div class="slot-image">
            Dolphin&#039;s Pearl                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Dolphin&#039;s Pearl
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/dolphins-pearl-10" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.8">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Book of Ra Magic                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Book of Ra Magic
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/book-of-ra-magic-11" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.6">
          <div class="slot-image">
            Bananas go Bahamas                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Bananas go Bahamas
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/bananas-go-bahamas-12" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.8">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Pharaoh&#039;s Tomb                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Pharaoh&#039;s Tomb
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/pharaohs-tomb-13" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.8">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Book of Ra Deluxe                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Book of Ra Deluxe
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/book-of-ra-deluxe-14" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.9">
          <div class="slot-image">
            Sharky                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Sharky
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.9                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/sharky-15" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.6">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            The Money Game                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              The Money Game
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/the-money-game-16" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.4">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Island 2                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Island 2
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/island-2-17" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.3">
          <div class="slot-image">
            Keks                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Keks
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/keks-18" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.4">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Ultra Hot                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Ultra Hot
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/ultra-hot-19" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.4">
          <div class="slot-image">
            Rock Climber                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Rock Climber
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/rock-climber-20" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.8">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Lucky Haunter                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Lucky Haunter
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/lucky-haunter-21" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.3">
          <div class="slot-image">
            Legacy of Dead                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Legacy of Dead
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/legacy-of-dead-22" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.4">
          <div class="slot-image">
            Lucky Lady&#039;s Charm Deluxe                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Lucky Lady&#039;s Charm Deluxe
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/lucky-ladys-charm-deluxe-23" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.8">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Tidal Riches                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Tidal Riches
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/tidal-riches-24" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.9">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            27 Wins                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              27 Wins
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.9                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/27-wins-25" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.2">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Book of Ra Deluxe 6                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Book of Ra Deluxe 6
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/book-of-ra-deluxe-6-26" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.7">
          <div class="slot-image">
            Garage                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Garage
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.7                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/garage-27" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.7">
          <div class="slot-image">
            Diamond Trio                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Diamond Trio
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.7                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/diamond-trio-28" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.5">
          <div class="slot-image">
            Just Jewels Deluxe                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Just Jewels Deluxe
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.5                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/just-jewels-deluxe-29" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.2">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Shining Crown                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Shining Crown
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/shining-crown-30" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.6">
          <div class="slot-image">
            Reel Catch                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Reel Catch
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/reel-catch-31" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.5">
          <div class="slot-image">
            Stein Haus                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Stein Haus
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.5                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/stein-haus-32" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.7">
          <div class="slot-image">
            Gnome                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Gnome
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.7                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/gnome-33" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.8">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Irish Coins                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Irish Coins
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/irish-coins-34" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.7">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Book of Ra HD                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Book of Ra HD
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.7                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/book-of-ra-hd-35" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.3">
          <div class="slot-image">
            Lucky Joker 10 Extra Gifts                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Lucky Joker 10 Extra Gifts
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/lucky-joker-10-extra-gifts-36" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.6">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Sizzling Hot 6 Extra Gold                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Sizzling Hot 6 Extra Gold
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/sizzling-hot-6-extra-gold-37" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.3">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Mega Joker                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Mega Joker
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/mega-joker-38" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.6">
          <div class="slot-image">
            Columbus                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Columbus
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/columbus-39" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.9">
          <div class="slot-image">
            Lucky Lady&#039;s Charm Deluxe 10                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Lucky Lady&#039;s Charm Deluxe 10
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.9                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/lucky-ladys-charm-deluxe-10-40" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.4">
          <div class="slot-image">
            Sweet Life 2                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Sweet Life 2
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/sweet-life-2-41" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.9">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Book of Fate                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Book of Fate
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.9                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/book-of-fate-42" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.6">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Retro Love                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Retro Love
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/retro-love-43" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.6">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Ghost of Dead                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Ghost of Dead
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/ghost-of-dead-44" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.5">
          <div class="slot-image">
            Book of Dead                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Book of Dead
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.5                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/book-of-dead-45" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.2">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Secret Forest                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Secret Forest
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/secret-forest-46" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.2">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Ultra Hot Deluxe                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Ultra Hot Deluxe
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/ultra-hot-deluxe-47" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.8">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            River Queen                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              River Queen
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/river-queen-48" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.2">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Triple Lucky 8&#039;s                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Triple Lucky 8&#039;s
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/triple-lucky-8s-49" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.6">
          <div class="slot-image">
            Fruit Cocktail 2                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Fruit Cocktail 2
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/fruit-cocktail-2-50" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.3">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            First Class Traveller                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              First Class Traveller
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/first-class-traveller-51" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.6">
          <div class="slot-image">
            Dolphin&#039;s Pearl Deluxe                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Dolphin&#039;s Pearl Deluxe
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/dolphins-pearl-deluxe-52" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.4">
          <div class="slot-image">
            Columbus Deluxe                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Columbus Deluxe
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/columbus-deluxe-53" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.6">
          <div class="slot-image">
            Oliver&#039;s Bar                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Oliver&#039;s Bar
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/olivers-bar-54" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.5">
          <div class="slot-image">
            Banana Splash                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Banana Splash
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.5                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/banana-splash-55" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.6">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Pumpkin Fairy                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Pumpkin Fairy
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/pumpkin-fairy-56" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.7">
          <div class="slot-image">
            Book of Mega Moolah                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Book of Mega Moolah
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.7                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/book-of-mega-moolah-57" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Playson" data-rating="4.2">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Marco Polo                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Marco Polo
            </div>
            <div class="slot-rating">
              ★★★★ 4.2                    
            </div>
            <div class="slot-provider">
              Playson
            </div>
            <a href="/game/marco-polo-58" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.4">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            9 Masks of Fire                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              9 Masks of Fire
            </div>
            <div class="slot-rating">
              ★★★★ 4.4                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/9-masks-of-fire-59" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.6">
          <div class="slot-image">
            Jaguar Moon                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Jaguar Moon
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.6                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/jaguar-moon-60" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Push Gaming" data-rating="4.3">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Burning Hot                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Burning Hot
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              Push Gaming
            </div>
            <a href="/game/burning-hot-61" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="NetEnt" data-rating="4.7">
          <div class="slot-image">
            Gorilla                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Gorilla
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.7                    
            </div>
            <div class="slot-provider">
              NetEnt
            </div>
            <a href="/game/gorilla-62" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Novomatic" data-rating="4.8">
          <div class="slot-image">
            Sizzling Hot Deluxe                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Sizzling Hot Deluxe
            </div>
            <div class="slot-rating">
              ★★★★☆ 4.8                    
            </div>
            <div class="slot-provider">
              Novomatic
            </div>
            <a href="/game/sizzling-hot-deluxe-63" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
        <div class="slot-card" data-provider="Igrosoft" data-rating="4.3">
          <div class="new-badge">
            NEW
          </div>
          <div class="slot-image">
            Coils of Cash                
          </div>
          <div class="slot-info">
            <div class="slot-name">
              Coils of Cash
            </div>
            <div class="slot-rating">
              ★★★★ 4.3                    
            </div>
            <div class="slot-provider">
              Igrosoft
            </div>
            <a href="/game/coils-of-cash-64" class="slot-link">
              Подробнее
            </a>
          </div>
        </div>
<?php
require_once("footer.php");
?>