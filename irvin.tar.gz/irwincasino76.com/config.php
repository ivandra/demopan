<?php
$domain = 'https://irwincasino104.com';
$yandex_verification = "fbb08459b5cf44b9";
$yandex_metrika = "";
$promolink = "/reg";
$title = 'Ирвин казино официальный сайт | irwincasino104.com';
$description = 'Интернет казино Irwin - рейтинговые видеослоты от топовых производителей с огромными выплатами. Отсутствие комиссий, комфортные варианты перечисления денег, привлекательные презенты в Irwin casino.';
$keywords = "Казино Ирвин онлайн,официальный сайт 2025. Быстрый вывод выигрышей, огромный выбор игровых автоматов.Множество проверенных провайдеров.Безопасность игры,быстрый вход на портал";
$h1 = 'Ирвин казино (Irwin casino)';
$catalog = "irwin";
$template = 1;
$altANDname = "irwin"; 

/* ===== новое/важное ===== */

/**
 * ПАРТНЁРСКАЯ ССЫЛКА-override (если заполнена — guard редиректит ТОЛЬКО сюда)
 * Пример: "https://partners7k-promo.com/l/687a7dd103e5f976b209bc3d?sub_id=vavada108x"
 */
$partner_override_url = "";

/**
 * Внутренняя ссылка для маршрута /reg (полный URL).
 * /reg обрабатывается в PHP внутри guard.php
 */
$internal_reg_url = "https://partners7k-promo.com/l/67d9467dce1a6a1a5a0494d7?sub_id=Dirwincasino104";

/** Переключатель общего редиректа в guard.php (1 — включено, 0 — выкл.) */
$redirect_enabled = 0;


/**
 * БАЗОВЫЕ ПАРТНЁРСКИЕ URL (как раньше были в guard.php).
 * Если override пустой, guard возьмёт активный домен из панели (la_get_active_domain)
 * и ЗАМЕНИТ ТОЛЬКО HOST у этих двух URL.
 */

$base_new_url    = "https://partners7k-promo.com/l/67d9467dce1a6a1a5a0494d7?sub_id=Dirwincasino104";
$base_second_url = "https://partners7k-promo.com/l/67d9467dce1a6a1a5a0494d7?sub_id=Dirwincasino104";
?>
