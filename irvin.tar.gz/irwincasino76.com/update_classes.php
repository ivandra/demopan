<?php
// Совместимо с PHP 5.6+ (нет strict_types, тип-хинтов и str_starts_with)

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

/**
 * Обновляет классы, переименовывает изображения с хешем и безопасно заменяет
 * в HTML/PHP/CSS без «двойных хешей».
 *
 * Структура:
 *   /templates/irwin/1/
 *     ├── source/                (исходники *.txt)
 *     ├── assets/
 *     │   ├── images/            (webp/png/jpg/svg)
 *     │   └── css/
 *     └── ... (сюда выкладываем header.php и прочее)
 */

// ===================== НАСТРОЙКИ =====================
$ENABLE_IMAGE_REPLACEMENT = true;

$basePath      = __DIR__ . '/templates/irwin/1';
$sourcePath    = $basePath . '/source';
$assetsPath    = $basePath . '/assets';
$assetsPathIMG = $assetsPath . '/images';
$assetsPathCSS = $assetsPath . '/css';

$mappingFile  = $sourcePath . '/class_name_mapping.txt';
$imageMapFile = $sourcePath . '/image_mapping.txt';

$phpSourceFiles = array(
    'header-php.txt' => 'header.php',
);

$cssSourceFiles = array(
    'app-css.txt'           => 'app.css',
    'stylesheet_0-css.txt'  => 'stylesheet_0.css',
    'stylesheet_1-css.txt'  => 'stylesheet_1.css',
    'stylesheet_2-css.txt'  => 'stylesheet_2.css',
    'stylesheet_3-css.txt'  => 'stylesheet_3.css',
    'stylesheet_4-css.txt'  => 'stylesheet_4.css',
    'stylesheet_5-css.txt'  => 'stylesheet_5.css',
    'stylesheet_6-css.txt'  => 'stylesheet_6.css',
    'stylesheet_7-css.txt'  => 'stylesheet_7.css',
    'stylesheet_8-css.txt'  => 'stylesheet_8.css',
    'stylesheet_9-css.txt'  => 'stylesheet_9.css',
    'stylesheet_10-css.txt' => 'stylesheet_10.css',
    'stylesheet_11-css.txt' => 'stylesheet_11.css',
    'stylesheet_12-css.txt' => 'stylesheet_12.css',
    'stylesheet_13-css.txt' => 'stylesheet_13.css',
    'stylesheet_14-css.txt' => 'stylesheet_14.css',
    'stylesheet_15-css.txt' => 'stylesheet_15.css',
    'stylesheet_16-css.txt' => 'stylesheet_16.css',
    'stylesheet_17-css.txt' => 'stylesheet_17.css',
    'stylesheet_18-css.txt' => 'stylesheet_18.css',
    // фикс опечатки .cWss -> .css
    'stylesheet_19-css.txt' => 'stylesheet_19.css',
    'stylesheet_20-css.txt' => 'stylesheet_20.css',
    'stylesheet_21-css.txt' => 'stylesheet_21.css',
    'stylesheet_22-css.txt' => 'stylesheet_22.css',
    'stylesheet_23-css.txt' => 'stylesheet_23.css',
    'stylesheet_24-css.txt' => 'stylesheet_24.css',
    'stylesheet_25-css.txt' => 'stylesheet_25.css',
    'stylesheet_26-css.txt' => 'stylesheet_26.css',
    'stylesheet_27-css.txt' => 'stylesheet_27.css',
    'stylesheet_28-css.txt' => 'stylesheet_28.css',
);

// ===================== УТИЛИТЫ =====================
function generateNewClassName($oldName) {
    return $oldName . '___' . substr(md5(uniqid($oldName, true)), 0, 5);
}
function generateImageSuffix() {
    return substr(md5(uniqid(mt_rand(), true)), 0, 8);
}
function ensureDir($dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
}

// ===================== 1) КАРТА КЛАССОВ =====================
function updateClassNameMapping($filePath) {
    if (!file_exists($filePath)) {
        echo "⚠️ class_name_mapping.txt не найден — создаю пустой.\n";
        file_put_contents($filePath, '');
        return array();
    }
    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) $lines = array();

    $newMappingLines = array();
    $assoc = array();

    foreach ($lines as $line) {
        $parts = explode(':', $line, 2);
        $original = isset($parts[0]) ? $parts[0] : null;
        if ($original === null || $original === '') continue;
        $new = generateNewClassName($original);
        $newMappingLines[] = $original . ':' . $new;
        $assoc[$original]  = $new;
    }
    file_put_contents($filePath, implode("\n", $newMappingLines));
    return $assoc;
}

function replaceClassesInHtml($content, $mapping) {
    if (empty($mapping)) return $content;
    return preg_replace_callback('/class="([^"]+)"/u', function($m) use ($mapping) {
        $classes = preg_split('/\s+/', trim($m[1]));
        $out = array();
        foreach ($classes as $c) {
            $out[] = isset($mapping[$c]) ? $mapping[$c] : $c;
        }
        return 'class="' . implode(' ', $out) . '"';
    }, $content);
}

function replaceClassesInCss($content, $mapping) {
    if (empty($mapping)) return $content;
    return preg_replace_callback('/\.([a-zA-Z0-9_-]+)/u', function($m) use ($mapping) {
        $name = $m[1];
        return '.' . (isset($mapping[$name]) ? $mapping[$name] : $name);
    }, $content);
}

// ===================== 2) ПЕРЕИМЕНОВАНИЕ ИЗОБРАЖЕНИЙ =====================
/**
 * Возвращает mapping, где КАЖДЫЙ файл дает два ключа:
 *   "как_лежал_(с_хешем_или_без).ext" => "base___newhash.ext"
 *   "base.ext"                         => "base___newhash.ext"
 * Пишет image_mapping.txt (ключи отсортированы по длине desc).
 */
function renameImagesAlways($assetsPath, $mapFile) {
    ensureDir($assetsPath);
    if (!is_writable($assetsPath)) {
        echo "❌ Папка недоступна для записи: $assetsPath\n";
        return array();
    }

    $files = scandir($assetsPath);
    if ($files === false) $files = array();

    $mapping = array();
    $log = array();

    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($ext, array('jpg','jpeg','png','webp','svg'), true)) continue;

        $rawName  = pathinfo($file, PATHINFO_FILENAME);                // 49___36748895
        $baseName = preg_replace('/___[a-f0-9]{8}$/', '', $rawName);   // 49
        $originalPath = $assetsPath . '/' . $file;

        // Генерируем новое имя ОТ baseName
        $newName = $baseName . '___' . generateImageSuffix() . '.' . $ext;
        $newPath = $assetsPath . '/' . $newName;

        $attempt = 0;
        while (file_exists($newPath) && $attempt++ < 5) {
            $newName = $baseName . '___' . generateImageSuffix() . '.' . $ext;
            $newPath = $assetsPath . '/' . $newName;
        }

        if (@copy($originalPath, $newPath)) {
            // два ключа
            $mapping[$file] = $newName;                   // как лежал (с хешем или без)
            $mapping[$baseName . '.' . $ext] = $newName;  // «голый» base
            $log[] = "🖼 $file → $newName";
            if ($newName !== $file) {
                @unlink($originalPath);
            }
        } else {
            $log[] = "❌ Не удалось переименовать $file";
        }
    }

    if (!empty($mapping)) {
        // длинные ключи первыми
        uksort($mapping, function($a, $b){
            $la = strlen($a); $lb = strlen($b);
            if ($la == $lb) return 0;
            return ($lb < $la) ? -1 : 1;
        });
        $lines = array();
        foreach ($mapping as $k => $v) {
            $lines[] = $k . ':' . $v;
        }
        file_put_contents($mapFile, implode("\n", $lines));
    }

    file_put_contents($assetsPath . '/rename_log.txt', implode("\n", $log));
    return $mapping;
}

// ===================== 3) БЕЗОПАСНЫЕ ЗАМЕНЫ КАРТИНОК =====================
/**
 * Делает замену имен файлов картинок.
 * 1) str_replace("/old","/new") — накрывает относительные пути с тем же префиксом.
 * 2) Регулярка по «голому имени» с границами: (?<=/)old(?=[^A-Za-z0-9_])
 *    — накрывает случаи с другими префиксами каталогов.
 */
function replaceImageNamesInText($content, $imageMap) {
    if (empty($imageMap)) return $content;

    // сначала длинные ключи
    uksort($imageMap, function($a, $b){
        $la = strlen($a); $lb = strlen($b);
        if ($la == $lb) return 0;
        return ($lb < $la) ? -1 : 1;
    });

    foreach ($imageMap as $old => $new) {
        // 1) простая замена, если путь уже содержит '/'+имя
        $content = str_replace('/' . $old, '/' . $new, $content);

        // 2) надежная подмена голого имени (внутри любых путей)
        $pattern = '~(?<=/)' . preg_quote($old, '~') . '(?=[^A-Za-z0-9_])~u';
        $content = preg_replace($pattern, $new, $content);
    }
    return $content;
}

/** HTML/PHP: подменяем src, data-src, srcset, style и сырые вхождения */
function replaceImagesInPhpHtml($content, $imageMap) {
    if (empty($imageMap)) return $content;

    // src/srcset/data-*
    $content = replaceImageNamesInText($content, $imageMap);

    // дополнительно аккуратно пройтись по srcset (там через запятую)
    $content = preg_replace_callback('/\bsrcset\s*=\s*"([^"]*)"/u', function($m) use ($imageMap) {
        $val = $m[1];
        $val = replaceImageNamesInText($val, $imageMap);
        return 'srcset="' . $val . '"';
    }, $content);

    // и по style="background-image:url(...)"
    $content = preg_replace_callback('/url\(([^)]+)\)/u', function($m) use ($imageMap) {
        $inside  = $m[1];
        $trimmed = trim($inside, '\'" ');
        $new     = replaceImageNamesInText($trimmed, $imageMap);

        // вместо str_starts_with — проверяем первый символ
        $firstChar = substr($inside, 0, 1);
        if ($firstChar === '"' || $firstChar === "'") {
            return 'url(' . $firstChar . $new . $firstChar . ')';
        }
        return 'url(' . $new . ')';
    }, $content);

    return $content;
}

/** CSS: заменяем внутри url(...) и подстраховываем «голые» вхождения */
function replaceImagesInCss($content, $imageMap) {
    if (empty($imageMap)) return $content;

    // url(...)
    $content = preg_replace_callback('/url\(([^)]+)\)/u', function($m) use ($imageMap) {
        $inside  = $m[1];
        $trimmed = trim($inside, '\'" ');
        $new     = replaceImageNamesInText($trimmed, $imageMap);

        $firstChar = substr($inside, 0, 1);
        if ($firstChar === '"' || $firstChar === "'") {
            return 'url(' . $firstChar . $new . $firstChar . ')';
        }
        return 'url(' . $new . ')';
    }, $content);

    // подстраховка: «голые» вхождения
    $content = replaceImageNamesInText($content, $imageMap);
    return $content;
}

// ===================== 4) ОБРАБОТКА ФАЙЛОВ =====================
function processPhpFiles($sourcePath, $targetPath, $files, $classMap, $imageMap) {
    ensureDir($targetPath);
    foreach ($files as $src => $target) {
        $srcFile = $sourcePath . '/' . $src;
        $dstFile = $targetPath . '/' . $target;

        if (!file_exists($srcFile)) {
            echo "⚠️ Пропущен (нет файла): $srcFile\n";
            continue;
        }
        $content = file_get_contents($srcFile);
        if ($content === false) {
            echo "⚠️ Не удалось прочитать: $srcFile\n";
            continue;
        }

        // классы
        $content = replaceClassesInHtml($content, $classMap);
        // картинки
        $content = replaceImagesInPhpHtml($content, $imageMap);

        file_put_contents($dstFile, $content);
        echo "✅ Обновлен: $dstFile\n";
    }
}

function processCssFiles($sourcePath, $targetPath, $files, $classMap, $imageMap) {
    ensureDir($targetPath);
    foreach ($files as $src => $target) {
        $srcFile = $sourcePath . '/' . $src;
        $dstFile = $targetPath . '/' . $target;

        if (!file_exists($srcFile)) {
            echo "⚠️ Пропущен (нет файла): $srcFile\n";
            continue;
        }
        $content = file_get_contents($srcFile);
        if ($content === false) {
            echo "⚠️ Не удалось прочитать: $srcFile\n";
            continue;
        }

        // классы в CSS
        $content = replaceClassesInCss($content, $classMap);
        // картинки в CSS
        $content = replaceImagesInCss($content, $imageMap);

        file_put_contents($dstFile, $content);
        echo "✅ Обновлен: $dstFile\n";
    }
}

// ===================== ЗАПУСК =====================
echo "🚀 Старт...\n";

if (!is_dir($basePath) || !is_dir($sourcePath)) {
    echo "❌ Ошибка: нет нужных директорий.\n";
    exit(1);
}

$classMapping = updateClassNameMapping($mappingFile);
$imageMapping = $ENABLE_IMAGE_REPLACEMENT ? renameImagesAlways($assetsPathIMG, $imageMapFile) : array();

processPhpFiles($sourcePath, $basePath, $phpSourceFiles, $classMapping, $imageMapping);
processCssFiles($sourcePath, $assetsPathCSS, $cssSourceFiles, $classMapping, $imageMapping);

echo "✅ Готово.\n";
