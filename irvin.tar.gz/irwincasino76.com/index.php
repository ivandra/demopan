<?php
// Подключаем конфигурационный файл
require_once("config.php");
require_once __DIR__.'/guard.php';

// Проверяем, существует ли указанный шаблон и загружаем соответствующие файлы
$templatePath = "templates/{$catalog}/{$template}";
$assetsPath = "/templates/{$catalog}/{$template}"; // Динамический путь к папке ассетов


// Проверяем, существует ли папка с шаблоном
if (is_dir($templatePath)) {
    // Подключаем header, content и footer из папки выбранного шаблона
    require_once("{$templatePath}/header.php");
} else {
    // Если указанной папки нет, можно загрузить шаблон по умолчанию или выдать ошибку
    echo "Ошибка: Шаблон не найден.";
}
?>
<div class="container">
    <?php
    // Подключаем основной контент
    if (file_exists("{$templatePath}/content.php")) {
        require_once("{$templatePath}/content.php");
    } else {
        echo "Ошибка: Файл content.php не найден.";
    }
    ?>
</div>
<?php
// Подключаем footer
if (file_exists("{$templatePath}/footer.php")) {
    require_once("{$templatePath}/footer.php");
} else {
    echo "Ошибка: Файл footer.php не найден.";
}
?>
