<?php
require_once __DIR__ . '/config.php'; // Подключаем файл с конфигурацией

//мониторинг ботов
require_once __DIR__ . '/tracker.php';


// Устанавливаем заголовок для текстового файла
// Запрещаем кэширование на всех уровнях (браузер, прокси, CDN)
header('Content-Type: text/plain; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false); // совместимость со старыми прокси
header('Pragma: no-cache');
header('Expires: 0'); // либо прошедшая дата

/**
 * Нормализация хоста:
 * - приводит к нижнему регистру
 * - убирает порт
 * - убирает www.
 */
function normalizeHost(string $host): string {
    $host = trim(strtolower($host));
    // убрать порт, если есть (example.com:443)
    $host = preg_replace('~:\d+$~', '', $host);
    // убрать www.
    $host = preg_replace('~^www\.~', '', $host);
    return $host;
}

/**
 * Извлекаем хост из домена в конфиге (может быть https://example.com)
 */
function getHostFromConfigDomain(string $cfgDomain): string {
    $cfgDomain = trim($cfgDomain);
    if ($cfgDomain === '') return '';

    $p = parse_url($cfgDomain);
    // если в $domain вдруг передали просто "example.com" без схемы
    if (!$p || empty($p['host'])) {
        return normalizeHost($cfgDomain);
    }
    return normalizeHost((string)$p['host']);
}

$cfgDomain = (string)($domain ?? '');
$cfgHost   = getHostFromConfigDomain($cfgDomain);

$currentHostRaw = (string)($_SERVER['HTTP_HOST'] ?? '');
$currentHost    = normalizeHost($currentHostRaw);

// Если не смогли определить основной хост из конфига — на всякий случай закрываем все
if ($cfgHost === '' || $currentHost === '') {
    echo "User-agent: *\n";
    echo "Disallow: /\n";
    exit;
}

// Сравниваем текущий домен с доменом из config.php
$isMainDomain = ($currentHost === $cfgHost);

if (!$isMainDomain) {
    // Закрываем весь сайт на "чужом" домене/поддомене
    echo "User-agent: *\n";
    echo "Disallow: /\n";
    exit;
}

// ====== ОСНОВНОЙ ДОМЕН: открытый robots (как у тебя было) ======
$cfgDomain = rtrim($cfgDomain, '/');

echo "User-agent: *\n";
echo "Allow: /\n";
echo "Disallow: /reg\n";

// Host по стандарту чаще указывают без схемы (особенно для Яндекса)
echo "Host: {$cfgHost}\n";

// Sitemap лучше отдавать абсолютным URL
if ($cfgDomain !== '') {
    echo "Sitemap: {$cfgDomain}/sitemap.xml\n";
}
