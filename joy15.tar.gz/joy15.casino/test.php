<?php
/**
 * guard.php — единая точка:
 *  - маршруты /reg и /reg/* → редирект на $internal_reg_url (из config.php)
 *  - глобальные партнёрские редиректы (override ИЛИ подмена только домена по панели)
 *  - защита от двойного подключения
 */

if (defined('PROMO_GUARD_LOADED')) return;
define('PROMO_GUARD_LOADED', true);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/link_agent.php'; // la_get_active_domain(), la_replace_domain()

  $activeDomain = la_get_active_domain(); // напр. partners7k-promo.com
  echo  $activeDomain;
 

  $baseNew    = $base_new_url    ?? '';
  $baseSecond = $base_second_url ?? '';
  if ($baseNew && $baseSecond) {
    $configRed = [
      'new_domain'    => la_replace_domain($baseNew,    $activeDomain),
      'second_domain' => la_replace_domain($baseSecond, $activeDomain),
    ];
  }

  var_export($configRed);