<?php
/**
 * Yandex Bot Tracker v1.0
 * Отслеживание визитов быстробота Яндекса + Telegram-уведомления
 *
 * Режимы:
 *   Middleware:  require_once 'tracker.php'; в начале index.php
 *   Дашборд:    tracker.php?key=SECRET_KEY
 *   CLI парсинг: php tracker.php parse /path/to/access.log example.ru
 *
 * @channel @seo_drift
 */

// ===================== КОНФИГ =====================
define('TG_TOKEN',   'YOUR_BOT_TOKEN');      // Токен Telegram-бота (@BotFather). Можно оставить пустым если алерты идут из центра.
define('TG_CHAT_ID', 'YOUR_CHAT_ID');        // ID чата для уведомлений
define('SECRET_KEY', 'changeme123');          // Ключ доступа к локальному дашборду tracker.php?key=...
define('DATA_DIR',   __DIR__ . '/data');      // Папка для локального буфера
define('MAX_VISITS', 500);                   // Макс. визитов на сайт в локальной истории

// --- Централизованный мониторинг (botmanager.seotop-one.ru) ---
define('CENTRAL_URL',    'https://botmanager.seotop-one.ru/ingest.php'); // endpoint приёма. Пусто '' = слать только локально
define('INGEST_KEY',     'c720ea9d88bebf0d1aabe0c07b4b23b9');             // общий ключ агентов (= ingest_key в конфиге центра)
define('INGEST_SECRET',  '37f7ab190d1fca21ec583eecfe56f7ba4d7c9db9cb3311a1'); // секрет HMAC (= ingest_secret в центре)
define('CENTRAL_TIMEOUT', 2);                // таймаут отправки в центр, сек (короткий чтобы не тормозить отдачу)
// ==================================================

define('DATA_FILE', DATA_DIR . '/visits.json');

// Этапы "флеш-рояля"
define('STAGES', [
    'webmaster' => [
        'num'   => 1,
        'label' => 'Webmaster — доступность',
        'ua'    => 'YandexWebmaster',
        'url'   => null, // любой URL
    ],
    'robots' => [
        'num'   => 2,
        'label' => 'Robots.txt — разрешения',
        'ua'    => 'YandexBot',
        'url'   => '/robots.txt',
    ],
    'content' => [
        'num'   => 3,
        'label' => 'HTML — контент',
        'ua'    => 'YandexBot',
        'url'   => '__html__', // специальный маркер: HTML-страницы
    ],
    'sitemap' => [
        'num'   => 4,
        'label' => 'Sitemap — карта сайта',
        'ua'    => 'YandexBot',
        'url'   => '/sitemap',
    ],
    'favicon' => [
        'num'   => 5,
        'label' => 'Favicon — индексация!',
        'ua'    => 'YandexFavicons',
        'url'   => '/favicon.ico',
    ],
]);

// ===================== РОУТИНГ =====================

// CLI-режим
if (php_sapi_name() === 'cli') {
    handleCli($argv);
    exit;
}

// Веб-режимы с ключом доступа
if (isset($_GET['key']) && $_GET['key'] === SECRET_KEY) {
    // JSON API для авто-обновления дашборда
    if (isset($_GET['api']) && $_GET['api'] === 'data') {
        jsonApi();
        exit;
    }
    // Обработка действий (тест TG, сброс сайта)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        handleAction($_POST['action']);
        exit;
    }
    // Дашборд
    renderDashboard();
    exit;
}

// Middleware-режим (по умолчанию)
handleMiddleware();
return; // return, не exit — чтобы index.php продолжил работу

// ===================== CORE ФУНКЦИИ =====================

/**
 * Определить этап по User-Agent и URL
 */
function classifyVisit($ua, $url) {
    // Favicon — проверяем первым (у него свой UA)
    if (stripos($ua, 'YandexFavicons') !== false && stripos($url, 'favicon') !== false) {
        return 'favicon';
    }
    // Webmaster
    if (stripos($ua, 'YandexWebmaster') !== false) {
        return 'webmaster';
    }
    // Дальше только YandexBot
    if (stripos($ua, 'YandexBot') === false) {
        return null; // не бот Яндекса
    }
    // Robots.txt
    if (stripos($url, 'robots.txt') !== false) {
        return 'robots';
    }
    // Sitemap
    if (preg_match('/sitemap.*\.xml/i', $url)) {
        return 'sitemap';
    }
    // Проверяем что это не статика (CSS, JS, картинки и т.д.)
    $assetExts = ['css','js','png','jpg','jpeg','gif','svg','webp','woff','woff2','ttf','eot','ico','xml','txt','json','map'];
    $pathInfo = parse_url($url, PHP_URL_PATH);
    if ($pathInfo) {
        $ext = strtolower(pathinfo($pathInfo, PATHINFO_EXTENSION));
        if (in_array($ext, $assetExts)) {
            return null; // статика — не считаем
        }
    }
    // HTML-контент
    return 'content';
}

/**
 * Извлечь тип бота из User-Agent
 */
function extractBotType($ua) {
    if (preg_match('/Yandex(\w+)\//i', $ua, $m)) {
        return 'Yandex' . $m[1];
    }
    return 'YandexBot';
}

/**
 * Загрузить данные из JSON
 */
function loadData() {
    if (!is_dir(DATA_DIR)) {
        @mkdir(DATA_DIR, 0755, true);
    }
    if (!file_exists(DATA_FILE)) {
        return ['sites' => []];
    }
    $raw = @file_get_contents(DATA_FILE);
    if ($raw === false) {
        return ['sites' => []];
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : ['sites' => []];
}

/**
 * Сохранить данные в JSON (атомарная запись)
 */
function saveData($data) {
    if (!is_dir(DATA_DIR)) {
        @mkdir(DATA_DIR, 0755, true);
    }
    $tmp = DATA_FILE . '.tmp.' . getmypid();
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    file_put_contents($tmp, $json, LOCK_EX);
    rename($tmp, DATA_FILE);
}

/**
 * Инициализировать сайт в данных если его нет
 */
function ensureSite(&$data, $domain) {
    if (!isset($data['sites'][$domain])) {
        $emptyStages = [];
        foreach (STAGES as $key => $def) {
            $emptyStages[$key] = [
                'hit'     => false,
                'count'   => 0,
                'lastIp'  => null,
                'lastUrl' => null,
                'at'      => null,
            ];
        }
        $data['sites'][$domain] = [
            'firstSeen'      => null,
            'lastSeen'       => null,
            'flushRoyale'    => false,
            'flushRoyaleAt'  => null,
            'stages'         => $emptyStages,
            'visits'         => [],
        ];
    }
}

/**
 * Добавить визит и обновить этапы
 */
function addVisit(&$data, $domain, $visit) {
    ensureSite($data, $domain);
    $site = &$data['sites'][$domain];
    $now = $visit['ts'];

    // Обновить временные метки сайта
    if ($site['firstSeen'] === null) {
        $site['firstSeen'] = $now;
    }
    $site['lastSeen'] = $now;

    // Добавить визит
    $site['visits'][] = $visit;

    // Обрезать до MAX_VISITS
    if (count($site['visits']) > MAX_VISITS) {
        $site['visits'] = array_slice($site['visits'], -MAX_VISITS);
    }

    // Обновить этап
    $stage = $visit['stage'];
    if (isset($site['stages'][$stage])) {
        $s = &$site['stages'][$stage];
        $s['hit'] = true;
        $s['count']++;
        $s['lastIp'] = $visit['ip'];
        $s['lastUrl'] = $visit['url'];
        $s['at'] = $now;
        unset($s); // Обязательно! Иначе foreach ниже сломает данные через ссылку
    }

    // Проверить флеш-рояль
    $allHit = true;
    foreach ($site['stages'] as $stg) {
        if (!$stg['hit']) {
            $allHit = false;
            break;
        }
    }
    $wasComplete = $site['flushRoyale'];
    if ($allHit && !$wasComplete) {
        $site['flushRoyale'] = true;
        $site['flushRoyaleAt'] = $now;
    }

    return !$wasComplete && $allHit; // true = только что завершился флеш-рояль
}

/**
 * Подсчитать прогресс этапов
 */
function stageProgress($stages) {
    $done = 0;
    foreach ($stages as $s) {
        if ($s['hit']) $done++;
    }
    return $done;
}

/**
 * Визуальный прогресс-бар
 */
function progressEmojis($stages) {
    $out = '';
    foreach (STAGES as $key => $def) {
        $out .= $stages[$key]['hit'] ? "\xE2\x9C\x85" : "\xE2\xAC\x9C"; // ✅ или ⬜
    }
    return $out;
}

// ===================== MIDDLEWARE =====================

function handleMiddleware() {
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
    $ip = getClientIp();

    // Быстрая проверка — содержит ли UA "Yandex"
    if (stripos($ua, 'Yandex') === false) {
        return; // не бот Яндекса — выходим мгновенно
    }

    $stage = classifyVisit($ua, $url);
    if ($stage === null) {
        return; // не интересный запрос
    }

    // Определить домен
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'unknown';
    $domain = strtolower(preg_replace('/^www\./i', '', $host));

    // Убрать порт если есть
    $domain = preg_replace('/:\d+$/', '', $domain);

    $now = date('c'); // ISO 8601

    $visit = [
        'ts'    => $now,
        'ip'    => $ip,
        'ua'    => $ua,
        'bot'   => extractBotType($ua),
        'url'   => $url,
        'stage' => $stage,
        'src'   => 'middleware',
    ];

    $data = loadData();
    $justCompleted = addVisit($data, $domain, $visit);
    saveData($data);

    // v1.1: Отправка визита в центральную панель (fire-and-forget, после отдачи страницы)
    sendToCentral($domain, $visit);

    // Отправить уведомление в Telegram
    $stageNum = STAGES[$stage]['num'];
    $stageLabel = STAGES[$stage]['label'];
    $progress = stageProgress($data['sites'][$domain]['stages']);
    $emojis = progressEmojis($data['sites'][$domain]['stages']);

    $text = "\xF0\x9F\xA4\x96 *Яндекс бот на* `{$domain}`\n\n";
    $text .= "\xF0\x9F\x93\x8D `{$url}`\n";
    $text .= "\xF0\x9F\x94\x8D `{$visit['bot']}`\n";
    $text .= "\xF0\x9F\x8C\x90 `{$ip}`\n";
    $text .= "\xF0\x9F\x95\x90 `" . date('H:i:s') . "`\n\n";
    $text .= "\xF0\x9F\x93\x8A Этап {$stageNum}/5: {$stageLabel}\n";
    $text .= $emojis;

    if ($justCompleted) {
        $text .= "\n\n\xF0\x9F\x8E\x89 *FLUSH ROYALE!*\nВсе 5 этапов пройдены!\nСайт должен появиться в выдаче!";
    }

    sendTelegram($text);
}

/**
 * Получить IP клиента
 */
function getClientIp() {
    $headers = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    foreach ($headers as $h) {
        if (!empty($_SERVER[$h])) {
            $ip = trim(explode(',', $_SERVER[$h])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return '0.0.0.0';
}

// ===================== CLI ПАРСИНГ ЛОГОВ =====================

function handleCli($argv) {
    $command = isset($argv[1]) ? $argv[1] : 'help';

    if ($command === 'parse') {
        $logFile = isset($argv[2]) ? $argv[2] : null;
        $domain  = isset($argv[3]) ? $argv[3] : null;

        if (!$logFile || !$domain) {
            echo "Использование: php tracker.php parse /path/to/access.log example.ru\n";
            exit(1);
        }

        if (!file_exists($logFile)) {
            echo "Ошибка: файл не найден: {$logFile}\n";
            exit(1);
        }

        parseLogFile($logFile, $domain);
        return;
    }

    if ($command === 'stats') {
        printStats();
        return;
    }

    if ($command === 'resend') {
        // Дослать все локальные визиты в центр (если центр был недоступен)
        if (!defined('CENTRAL_URL') || CENTRAL_URL === '') {
            echo "CENTRAL_URL не задан — слать некуда.\n";
            return;
        }
        $data = loadData();
        $sent = 0;
        foreach ($data['sites'] as $domain => $site) {
            foreach ($site['visits'] as $visit) {
                sendToCentral($domain, $visit);
                $sent++;
            }
        }
        echo "Отправлено визитов в центр: {$sent}\n";
        echo "(дубли центр отсеет автоматически по visit_hash)\n";
        return;
    }

    echo "Yandex Bot Tracker CLI\n";
    echo "Команды:\n";
    echo "  php tracker.php parse <файл_лога> <домен>  — парсинг access.log\n";
    echo "  php tracker.php stats                      — показать статистику\n";
    echo "  php tracker.php resend                     — дослать локальные визиты в центр\n";
}

function parseLogFile($logFile, $domain) {
    $handle = fopen($logFile, 'r');
    if (!$handle) {
        echo "Ошибка: не удалось открыть файл\n";
        exit(1);
    }

    $data = loadData();
    $totalLines = 0;
    $foundVisits = 0;

    echo "Парсинг: {$logFile} -> {$domain}\n";
    echo str_repeat('-', 60) . "\n";

    while (($line = fgets($handle)) !== false) {
        $totalLines++;
        $parsed = parseLogLine($line);
        if (!$parsed) continue;

        $stage = classifyVisit($parsed['ua'], $parsed['url']);
        if ($stage === null) continue;

        $foundVisits++;

        $visit = [
            'ts'    => $parsed['ts'],
            'ip'    => $parsed['ip'],
            'ua'    => $parsed['ua'],
            'bot'   => extractBotType($parsed['ua']),
            'url'   => $parsed['url'],
            'stage' => $stage,
            'src'   => 'logparse',
        ];

        addVisit($data, $domain, $visit);

        $stageLabel = STAGES[$stage]['label'];
        echo "[{$foundVisits}] {$parsed['ts']} | {$stage} | {$parsed['url']} | {$stageLabel}\n";
    }

    fclose($handle);
    saveData($data);

    echo str_repeat('-', 60) . "\n";
    echo "Обработано строк: {$totalLines}\n";
    echo "Найдено визитов Яндекс-ботов: {$foundVisits}\n";

    if ($foundVisits > 0) {
        $site = $data['sites'][$domain];
        $progress = stageProgress($site['stages']);
        echo "Прогресс флеш-рояля: {$progress}/5\n";
        if ($site['flushRoyale']) {
            echo "*** FLUSH ROYALE ЗАВЕРШЁН! ***\n";
        }
    }
}

/**
 * Парсинг строки access.log (combined формат)
 */
function parseLogLine($line) {
    // Combined формат: IP - - [datetime] "METHOD URL PROTO" STATUS SIZE "REF" "UA"
    $pattern = '/^(\S+) \S+ \S+ \[([^\]]+)\] "(\S+) (\S+)[^"]*" (\d+) \S+ "[^"]*" "([^"]*)"/';
    if (!preg_match($pattern, $line, $m)) {
        return null;
    }

    // Конвертировать дату: 21/Feb/2026:10:23:00 +0300 -> ISO 8601
    $dt = DateTime::createFromFormat('d/M/Y:H:i:s O', $m[2]);
    $ts = $dt ? $dt->format('c') : date('c');

    return [
        'ip'     => $m[1],
        'ts'     => $ts,
        'method' => $m[3],
        'url'    => $m[4],
        'status' => (int)$m[5],
        'ua'     => $m[6],
    ];
}

function printStats() {
    $data = loadData();
    if (empty($data['sites'])) {
        echo "Нет данных. Запустите парсинг или middleware.\n";
        return;
    }

    echo "Yandex Bot Tracker — Статистика\n";
    echo str_repeat('=', 50) . "\n\n";

    foreach ($data['sites'] as $domain => $site) {
        $progress = stageProgress($site['stages']);
        $visitCount = count($site['visits']);
        $status = $site['flushRoyale'] ? 'FLUSH ROYALE!' : "{$progress}/5";

        echo "{$domain} [{$status}] — {$visitCount} визитов\n";
        foreach (STAGES as $key => $def) {
            $s = $site['stages'][$key];
            $icon = $s['hit'] ? '+' : '-';
            $info = $s['hit'] ? "x{$s['count']}, {$s['at']}" : 'ожидание';
            echo "  [{$icon}] {$def['num']}. {$def['label']} — {$info}\n";
        }
        echo "\n";
    }
}

// ===================== TELEGRAM =====================

function sendTelegram($text) {
    if (TG_TOKEN === 'YOUR_BOT_TOKEN' || TG_CHAT_ID === 'YOUR_CHAT_ID') {
        return; // не настроено
    }

    $url = 'https://api.telegram.org/bot' . TG_TOKEN . '/sendMessage';
    $payload = json_encode([
        'chat_id'    => TG_CHAT_ID,
        'text'       => $text,
        'parse_mode' => 'Markdown',
    ]);

    // Метод 1: cURL
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 3,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        curl_exec($ch);
        curl_close($ch);
        return;
    }

    // Метод 2: file_get_contents
    if (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $payload,
                'timeout' => 3,
            ],
            'ssl' => [
                'verify_peer' => true,
            ],
        ]);
        @file_get_contents($url, false, $ctx);
        return;
    }

    // Метод 3: fsockopen
    $fp = @fsockopen('ssl://api.telegram.org', 443, $errno, $errstr, 3);
    if ($fp) {
        $request  = "POST /bot" . TG_TOKEN . "/sendMessage HTTP/1.1\r\n";
        $request .= "Host: api.telegram.org\r\n";
        $request .= "Content-Type: application/json\r\n";
        $request .= "Content-Length: " . strlen($payload) . "\r\n";
        $request .= "Connection: close\r\n\r\n";
        $request .= $payload;
        fwrite($fp, $request);
        fclose($fp);
    }
}

/**
 * v1.1: Отправка визита в центральную панель мониторинга.
 * Fire-and-forget: короткий таймаут, ошибки не мешают работе сайта.
 * Тело подписывается HMAC-SHA256 секретом — центр проверяет подпись.
 *
 * Если центр недоступен — визит остаётся в локальном data/visits.json (буфер),
 * откуда его можно до-слать через CLI: php tracker.php resend
 */
function sendToCentral($domain, $visit) {
    if (!defined('CENTRAL_URL') || CENTRAL_URL === '') return;

    $payload = json_encode([
        'domain' => $domain,
        'visits' => [$visit],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $sig = hash_hmac('sha256', $payload, INGEST_SECRET);
    $timeout = defined('CENTRAL_TIMEOUT') ? CENTRAL_TIMEOUT : 2;

    if (function_exists('curl_init')) {
        $ch = curl_init(CENTRAL_URL);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'X-Ingest-Key: ' . INGEST_KEY,
                'X-Signature: ' . $sig,
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        curl_exec($ch);
        curl_close($ch);
        return;
    }

    if (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n"
                           . "X-Ingest-Key: " . INGEST_KEY . "\r\n"
                           . "X-Signature: " . $sig . "\r\n",
                'content' => $payload,
                'timeout' => $timeout,
            ],
            'ssl' => ['verify_peer' => true],
        ]);
        @file_get_contents(CENTRAL_URL, false, $ctx);
    }
}

// ===================== ВЕБ-ДЕЙСТВИЯ =====================

function handleAction($action) {
    header('Content-Type: application/json; charset=utf-8');

    if ($action === 'test_tg') {
        $text = "\xF0\x9F\x94\x94 *Тестовое уведомление*\n\nYandex Bot Tracker работает!\n\xE2\x9C\x85\xE2\x9C\x85\xE2\x9C\x85\xE2\x9C\x85\xE2\x9C\x85";
        sendTelegram($text);
        echo json_encode(['ok' => true, 'msg' => 'Тестовое уведомление отправлено']);
        return;
    }

    if ($action === 'reset' && isset($_POST['site'])) {
        $domain = $_POST['site'];
        $data = loadData();
        if (isset($data['sites'][$domain])) {
            foreach ($data['sites'][$domain]['stages'] as &$s) {
                $s['hit'] = false;
                $s['count'] = 0;
                $s['lastIp'] = null;
                $s['lastUrl'] = null;
                $s['at'] = null;
            }
            unset($s);
            $data['sites'][$domain]['flushRoyale'] = false;
            $data['sites'][$domain]['flushRoyaleAt'] = null;
            saveData($data);
        }
        echo json_encode(['ok' => true, 'msg' => "Этапы {$domain} сброшены"]);
        return;
    }

    if ($action === 'delete' && isset($_POST['site'])) {
        $domain = $_POST['site'];
        $data = loadData();
        if (isset($data['sites'][$domain])) {
            unset($data['sites'][$domain]);
            saveData($data);
        }
        echo json_encode(['ok' => true, 'msg' => "{$domain} удалён"]);
        return;
    }

    echo json_encode(['ok' => false, 'msg' => 'Неизвестное действие']);
}

function jsonApi() {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-cache');
    $data = loadData();
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

// ===================== ДАШБОРД =====================

function renderDashboard() {
    $data = loadData();
    $jsonData = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $secretKey = SECRET_KEY;
    $stagesJson = json_encode(STAGES, JSON_UNESCAPED_UNICODE);

    header('Content-Type: text/html; charset=utf-8');

    echo <<<HTML
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Yandex Bot Tracker</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
    --bg:#0d1117;--card:#161b22;--card-hover:#1c2129;--border:#30363d;
    --text:#e6edf3;--muted:#8b949e;--accent:#58a6ff;
    --success:#3fb950;--warning:#d29922;--danger:#f85149;
    --radius:10px;--shadow:0 2px 8px rgba(0,0,0,.3);
}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding:0}
a{color:var(--accent);text-decoration:none}

/* Шапка */
.header{background:var(--card);border-bottom:1px solid var(--border);padding:16px 24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;position:sticky;top:0;z-index:100}
.header h1{font-size:20px;font-weight:600;display:flex;align-items:center;gap:8px}
.header-actions{display:flex;gap:8px;flex-wrap:wrap}

/* Кнопки */
.btn{padding:8px 16px;border:1px solid var(--border);border-radius:6px;background:var(--card);color:var(--text);cursor:pointer;font-size:13px;transition:all .15s;display:inline-flex;align-items:center;gap:6px}
.btn:hover{background:var(--card-hover);border-color:var(--muted)}
.btn-accent{background:rgba(88,166,255,.15);border-color:var(--accent);color:var(--accent)}
.btn-accent:hover{background:rgba(88,166,255,.25)}
.btn-danger{color:var(--danger);border-color:transparent}
.btn-danger:hover{background:rgba(248,81,73,.1);border-color:var(--danger)}
.btn-sm{padding:4px 10px;font-size:12px}

/* Контейнер */
.container{max-width:1200px;margin:0 auto;padding:20px 24px}

/* Пустое состояние */
.empty-state{text-align:center;padding:60px 20px;color:var(--muted)}
.empty-state .icon{font-size:48px;margin-bottom:16px}
.empty-state h2{font-size:18px;color:var(--text);margin-bottom:8px}
.empty-state p{font-size:14px;max-width:500px;margin:0 auto;line-height:1.6}

/* Карточки сайтов */
.sites-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px;margin-bottom:24px}
.site-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:20px;transition:border-color .2s}
.site-card:hover{border-color:var(--muted)}
.site-card.complete{border-color:var(--success);box-shadow:0 0 12px rgba(63,185,80,.15)}
.site-card-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px}
.site-domain{font-size:16px;font-weight:600;word-break:break-all}
.site-badge{font-size:11px;padding:3px 8px;border-radius:12px;font-weight:600;white-space:nowrap}
.badge-complete{background:rgba(63,185,80,.15);color:var(--success)}
.badge-progress{background:rgba(210,153,34,.15);color:var(--warning)}
.site-meta{font-size:12px;color:var(--muted);margin-bottom:16px;display:flex;gap:16px;flex-wrap:wrap}

/* Прогресс-бар этапов */
.stages{display:flex;align-items:center;gap:0;margin-bottom:16px}
.stage-dot{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600;border:2px solid var(--border);background:var(--bg);color:var(--muted);flex-shrink:0;position:relative}
.stage-dot.hit{border-color:var(--success);background:rgba(63,185,80,.15);color:var(--success)}
.stage-connector{flex:1;height:2px;background:var(--border);min-width:8px}
.stage-connector.hit{background:var(--success)}
.stage-labels{display:flex;justify-content:space-between;font-size:10px;color:var(--muted);padding:0 2px}
.stage-labels span{text-align:center;width:36px;flex-shrink:0}

.site-card-footer{display:flex;justify-content:flex-end;gap:6px;margin-top:12px;padding-top:12px;border-top:1px solid var(--border)}

/* Секция */
.section{margin-bottom:24px}
.section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:8px}
.section-title{font-size:16px;font-weight:600}

/* Фильтры */
.filters{display:flex;gap:8px;flex-wrap:wrap}
.filter-select{padding:6px 10px;border:1px solid var(--border);border-radius:6px;background:var(--card);color:var(--text);font-size:13px;cursor:pointer}
.filter-select:focus{outline:none;border-color:var(--accent)}

/* Таблица */
.table-wrap{overflow-x:auto;border:1px solid var(--border);border-radius:var(--radius);background:var(--card)}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;padding:10px 14px;background:rgba(0,0,0,.2);color:var(--muted);font-weight:500;font-size:12px;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border);white-space:nowrap}
td{padding:10px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.stage-tag{display:inline-block;padding:2px 8px;border-radius:4px;font-size:12px;font-weight:500}
.stage-tag-1{background:rgba(88,166,255,.15);color:var(--accent)}
.stage-tag-2{background:rgba(210,153,34,.15);color:var(--warning)}
.stage-tag-3{background:rgba(63,185,80,.15);color:var(--success)}
.stage-tag-4{background:rgba(188,143,243,.15);color:#bc8ff3}
.stage-tag-5{background:rgba(248,81,73,.15);color:var(--danger)}
.src-tag{font-size:11px;color:var(--muted);background:rgba(255,255,255,.05);padding:2px 6px;border-radius:3px}
.mono{font-family:'SF Mono',Monaco,Consolas,monospace;font-size:12px}

/* Тост */
.toast{position:fixed;bottom:20px;right:20px;padding:12px 20px;border-radius:8px;font-size:14px;z-index:1000;transform:translateY(100px);opacity:0;transition:all .3s}
.toast.show{transform:translateY(0);opacity:1}
.toast-success{background:var(--success);color:#fff}
.toast-error{background:var(--danger);color:#fff}

/* Статус-бар */
.status-bar{text-align:center;padding:8px;font-size:12px;color:var(--muted)}

@media(max-width:600px){
    .header{padding:12px 16px}
    .header h1{font-size:16px}
    .container{padding:12px 16px}
    .sites-grid{grid-template-columns:1fr}
    .site-meta{flex-direction:column;gap:4px}
    th,td{padding:8px 10px}
}
</style>
</head>
<body>

<div class="header">
    <h1>🤖 Yandex Bot Tracker</h1>
    <div class="header-actions">
        <button class="btn btn-accent" onclick="testTelegram()">📨 Тест TG</button>
        <button class="btn" onclick="refreshData()">🔄 Обновить</button>
    </div>
</div>

<div class="container">
    <div id="content"></div>
    <div class="status-bar" id="statusBar">Загрузка...</div>
</div>

<div class="toast" id="toast"></div>

<script>
const SECRET_KEY = '{$secretKey}';
const STAGES_DEF = {$stagesJson};
const STAGE_KEYS = Object.keys(STAGES_DEF);
const STAGE_SHORT = {webmaster:'WM', robots:'RBT', content:'HTML', sitemap:'SMP', favicon:'FAV'};
let DATA = {$jsonData};
let filterDomain = '';
let filterBot = '';
let autoRefreshTimer = null;

function renderAll() {
    const el = document.getElementById('content');
    const sites = DATA.sites || {};
    const domains = Object.keys(sites);

    if (domains.length === 0) {
        el.innerHTML = '<div class="empty-state">' +
            '<div class="icon">🔍</div>' +
            '<h2>Нет данных</h2>' +
            '<p>Добавьте <code>require_once "tracker.php";</code> в начало index.php вашего сайта, или запустите парсинг логов через CLI.</p>' +
            '</div>';
        updateStatus('Ожидание данных');
        return;
    }

    let html = '';

    // Карточки сайтов
    html += '<div class="sites-grid">';
    domains.forEach(function(domain) {
        const site = sites[domain];
        const progress = countHits(site.stages);
        const isComplete = site.flushRoyale;
        const cardClass = isComplete ? 'site-card complete' : 'site-card';

        html += '<div class="' + cardClass + '">';
        html += '<div class="site-card-header">';
        html += '<div class="site-domain">' + escHtml(domain) + '</div>';
        if (isComplete) {
            html += '<span class="site-badge badge-complete">FLUSH ROYALE 🎉</span>';
        } else {
            html += '<span class="site-badge badge-progress">' + progress + '/5</span>';
        }
        html += '</div>';

        // Мета
        html += '<div class="site-meta">';
        html += '<span>Визитов: ' + site.visits.length + '</span>';
        if (site.lastSeen) {
            html += '<span>Последний: ' + formatTime(site.lastSeen) + '</span>';
        }
        if (site.flushRoyaleAt) {
            html += '<span>FR: ' + formatTime(site.flushRoyaleAt) + '</span>';
        }
        html += '</div>';

        // Прогресс-бар
        html += '<div class="stages">';
        STAGE_KEYS.forEach(function(key, i) {
            const hit = site.stages[key] && site.stages[key].hit;
            html += '<div class="stage-dot' + (hit ? ' hit' : '') + '" title="' + STAGES_DEF[key].label + '">' + STAGES_DEF[key].num + '</div>';
            if (i < STAGE_KEYS.length - 1) {
                html += '<div class="stage-connector' + (hit ? ' hit' : '') + '"></div>';
            }
        });
        html += '</div>';
        html += '<div class="stage-labels">';
        STAGE_KEYS.forEach(function(key, i) {
            html += '<span>' + STAGE_SHORT[key] + '</span>';
            if (i < STAGE_KEYS.length - 1) html += '<span></span>';
        });
        html += '</div>';

        // Футер
        html += '<div class="site-card-footer">';
        html += '<button class="btn btn-sm" onclick="resetSite(\'' + escHtml(domain) + '\')">Сброс</button>';
        html += '<button class="btn btn-sm btn-danger" onclick="deleteSite(\'' + escHtml(domain) + '\')">Удалить</button>';
        html += '</div>';

        html += '</div>';
    });
    html += '</div>';

    // Таблица визитов
    html += '<div class="section">';
    html += '<div class="section-header">';
    html += '<div class="section-title">Визиты ботов</div>';
    html += '<div class="filters">';

    // Фильтр по домену
    html += '<select class="filter-select" id="filterDomain" onchange="filterDomain=this.value;renderAll()">';
    html += '<option value="">Все сайты</option>';
    domains.forEach(function(d) {
        html += '<option value="' + escHtml(d) + '"' + (filterDomain===d?' selected':'') + '>' + escHtml(d) + '</option>';
    });
    html += '</select>';

    // Фильтр по боту
    var botTypes = {};
    domains.forEach(function(d) {
        sites[d].visits.forEach(function(v) { botTypes[v.bot] = true; });
    });
    html += '<select class="filter-select" id="filterBot" onchange="filterBot=this.value;renderAll()">';
    html += '<option value="">Все боты</option>';
    Object.keys(botTypes).forEach(function(b) {
        html += '<option value="' + escHtml(b) + '"' + (filterBot===b?' selected':'') + '>' + escHtml(b) + '</option>';
    });
    html += '</select>';
    html += '</div></div>';

    // Собрать все визиты
    var allVisits = [];
    domains.forEach(function(d) {
        sites[d].visits.forEach(function(v) {
            allVisits.push({domain: d, visit: v});
        });
    });

    // Фильтрация
    if (filterDomain) {
        allVisits = allVisits.filter(function(x) { return x.domain === filterDomain; });
    }
    if (filterBot) {
        allVisits = allVisits.filter(function(x) { return x.visit.bot === filterBot; });
    }

    // Сортировка по времени (новые сверху)
    allVisits.sort(function(a, b) {
        return new Date(b.visit.ts) - new Date(a.visit.ts);
    });

    // Ограничить 200 записями
    var shown = allVisits.slice(0, 200);

    html += '<div class="table-wrap"><table>';
    html += '<tr><th>Время</th><th>Домен</th><th>Бот</th><th>URL</th><th>Этап</th><th>Источник</th></tr>';

    if (shown.length === 0) {
        html += '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:20px">Нет визитов</td></tr>';
    } else {
        shown.forEach(function(item) {
            var v = item.visit;
            var stageNum = STAGES_DEF[v.stage] ? STAGES_DEF[v.stage].num : '?';
            html += '<tr>';
            html += '<td class="mono">' + formatTime(v.ts) + '</td>';
            html += '<td>' + escHtml(item.domain) + '</td>';
            html += '<td>' + escHtml(v.bot) + '</td>';
            html += '<td class="mono" title="' + escHtml(v.url) + '">' + escHtml(truncate(v.url, 40)) + '</td>';
            html += '<td><span class="stage-tag stage-tag-' + stageNum + '">' + stageNum + '/5 ' + escHtml(v.stage) + '</span></td>';
            html += '<td><span class="src-tag">' + escHtml(v.src) + '</span></td>';
            html += '</tr>';
        });
    }

    html += '</table></div>';
    if (allVisits.length > 200) {
        html += '<div style="text-align:center;padding:8px;font-size:12px;color:var(--muted)">Показано 200 из ' + allVisits.length + '</div>';
    }
    html += '</div>';

    el.innerHTML = html;
    updateStatus('Обновлено: ' + new Date().toLocaleTimeString());
}

function countHits(stages) {
    var n = 0;
    STAGE_KEYS.forEach(function(k) { if (stages[k] && stages[k].hit) n++; });
    return n;
}

function formatTime(ts) {
    if (!ts) return '—';
    var d = new Date(ts);
    var pad = function(n) { return n < 10 ? '0' + n : n; };
    return pad(d.getDate()) + '.' + pad(d.getMonth()+1) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function truncate(s, n) {
    return s.length > n ? s.substring(0, n) + '...' : s;
}

function escHtml(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showToast(msg, type) {
    var t = document.getElementById('toast');
    t.textContent = msg;
    t.className = 'toast toast-' + (type || 'success') + ' show';
    setTimeout(function() { t.className = 'toast'; }, 3000);
}

function updateStatus(msg) {
    document.getElementById('statusBar').textContent = msg;
}

function apiCall(action, params) {
    var form = new FormData();
    form.append('action', action);
    if (params) {
        Object.keys(params).forEach(function(k) { form.append(k, params[k]); });
    }
    return fetch('?key=' + SECRET_KEY, {
        method: 'POST',
        body: form,
    }).then(function(r) { return r.json(); });
}

function testTelegram() {
    apiCall('test_tg').then(function(r) {
        showToast(r.ok ? 'Уведомление отправлено!' : 'Ошибка: ' + r.msg, r.ok ? 'success' : 'error');
    }).catch(function() {
        showToast('Ошибка сети', 'error');
    });
}

function resetSite(domain) {
    if (!confirm('Сбросить этапы для ' + domain + '?')) return;
    apiCall('reset', {site: domain}).then(function(r) {
        showToast(r.msg);
        refreshData();
    });
}

function deleteSite(domain) {
    if (!confirm('Удалить все данные для ' + domain + '?')) return;
    apiCall('delete', {site: domain}).then(function(r) {
        showToast(r.msg);
        refreshData();
    });
}

function refreshData() {
    updateStatus('Обновление...');
    fetch('?key=' + SECRET_KEY + '&api=data')
        .then(function(r) { return r.json(); })
        .then(function(d) {
            DATA = d;
            renderAll();
        })
        .catch(function() {
            updateStatus('Ошибка загрузки данных');
        });
}

// Первый рендер
renderAll();

// Авто-обновление каждые 15 сек
autoRefreshTimer = setInterval(refreshData, 15000);
</script>

</body>
</html>
HTML;
}