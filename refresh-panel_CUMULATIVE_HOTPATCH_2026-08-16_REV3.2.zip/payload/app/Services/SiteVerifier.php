<?php

/**
 * Верификатор сайта после замены.
 *
 * Используется на стадии 'verify_replacement' оркестратора.
 *
 * Проверки:
 *   1. GET https://{new_domain}/  → 200/3xx (не 5xx, не connect error)
 *   2. GET https://{new_domain}/robots.txt → должен содержать "Allow:"
 *      и НЕ должен содержать только "Disallow: /" для * user-agent
 *   3. GET https://{old_domain}/robots.txt → ДОЛЖЕН содержать "Disallow: /"
 *      (т.е. старый домен закрыт от поисковиков)
 *   4. GET https://{old_domain}/  → 200/3xx (не 5xx) — сайт живой, просто закрыт от роботов
 *
 * v18-fix: добавлен `$resolveIp` — если задан, при провале обычного curl
 * (DNS resolve fail или подозрительный контент) делает повторный запрос
 * через `--resolve domain:443:IP`. Это обходит DNS пропагацию — идём прямо
 * на наш сервер, но с правильным Host header. Yandex/юзер используют DNS,
 * мы — IP. В случае успеха через resolve — пишем warning что DNS ещё
 * пропагируется, но физически на сервере всё ок.
 *
 * Используем cURL с ignore_ssl=true (для self-signed sertificate новых доменов
 * пока не выпущен LE wildcard в v14b).
 */
class SiteVerifier
{
    private int $timeout;

    /** v18-fix: IP VPS-сервера для --resolve fallback. Null = только DNS. */
    private ?string $resolveIp = null;

    /** v18.1.20: новый домен — используется при проверках старого (валидируем 301 → new). */
    private string $newDomain = '';

    /** v18.1.26: кеш конфига для VPS-side и temp-disable. */
    private ?array $verifierConfigCache = null;

    public function __construct(int $timeout = 15)
    {
        $this->timeout = $timeout;
    }

    /**
     * v18-fix: задать IP сервера для --resolve fallback.
     * Если задан — при провале curl через DNS будем пробовать через
     * прямое подключение к этому IP с правильным Host header.
     */
    public function setResolveIp(?string $ip): void
    {
        $this->resolveIp = $ip !== null && $ip !== '' ? $ip : null;
    }

    /**
     * Проверить старый и новый домены.
     *
     * @return array {
     *   overall_ok: bool,
     *   requires_user_action: bool,
     *   checks: array<string, array{ok: bool, ...}>,
     *   failed_checks: string[],
     *   warnings: string[],
     * }
     */
    /**
     * v18.1.26: расширена сигнатура — добавлен опциональный $context для multi-method robots check.
     */
    public function verifyAfterReplacement(string $oldDomain, string $newDomain, JobEventLogger $log, array $context = []): array
    {
        $checks = [];

        $oldDom = $this->stripScheme($oldDomain);
        $newDom = $this->stripScheme($newDomain);

        // v18.1.20: запомним newDomain для checkRobots/checkHttpRoot чтобы
        // проверять 301 со старого → новый как валидное закрытие.
        $this->newDomain = $newDom;

        // 1) Новый домен отвечает (role=new — мягко к 5xx, антибот защита часто отдаёт 500)
        $log->info('verify_replacement', "→ Проверяю https://{$newDom}/");
        $checks['new_http'] = $this->checkHttpRoot($newDom, 'new');

        // 2) robots.txt нового домена — Allow (главная проверка здоровья нового домена)
        $log->info('verify_replacement', "→ Проверяю https://{$newDom}/robots.txt");
        $checks['new_robots'] = $this->checkRobots($newDom, 'allow', $log, $context);

        // 3) robots.txt старого домена — Disallow (либо DNS-fail = тоже OK, домен мёртв)
        $log->info('verify_replacement', "→ Проверяю https://{$oldDom}/robots.txt");
        $checks['old_robots'] = $this->checkRobots($oldDom, 'disallow', $log, $context);

        // 4) Старый домен отвечает (role=old — DNS-fail трактуем как OK)
        $log->info('verify_replacement', "→ Проверяю https://{$oldDom}/");
        $checks['old_http'] = $this->checkHttpRoot($oldDom, 'old');

        // Анализируем
        $failed = [];
        $warnings = [];
        $dnsPendingChecks = [];
        foreach ($checks as $name => $result) {
            if (empty($result['ok'])) {
                $failed[] = $name;
            }
            if (!empty($result['warning'])) {
                $warnings[] = "{$name}: {$result['warning']}";
            }
            if (!empty($result['dns_pending'])) {
                $dnsPendingChecks[] = $name;
            }
        }

        // v18-fix: warning если использовали --resolve (DNS пропагируется)
        if (!empty($dnsPendingChecks)) {
            $warnings[] = 'DNS ещё пропагируется для: ' . implode(', ', $dnsPendingChecks)
                . ' (использовали --resolve, проверки прошли через прямой IP)';
            $log->warn('verify_replacement',
                "DNS пропагация ещё идёт. Проверки {$this->joinList($dnsPendingChecks)} " .
                "выполнены через прямое подключение к IP сервера ($this->resolveIp). " .
                "Через 5-30 мин DNS обновится у всех resolver'ов.");
        }

        $overallOk = empty($failed);
        $requiresUser = !$overallOk;

        // Лог для пользователя
        if ($overallOk) {
            $log->ok('verify_replacement', '✓ Все 4 проверки прошли успешно');
        } else {
            $log->error('verify_replacement',
                'Провалены проверки: ' . implode(', ', $failed));
            foreach ($failed as $name) {
                $msg = $checks[$name]['message'] ?? '';
                if ($msg !== '') {
                    $log->warn('verify_replacement', "  • {$name}: {$msg}");
                }
            }
        }

        return [
            'overall_ok' => $overallOk,
            'requires_user_action' => $requiresUser,
            'checks' => $checks,
            'failed_checks' => $failed,
            'warnings' => $warnings,
        ];
    }

    /**
     * Проверка корня домена.
     *
     * @param string $domain  — домен для проверки
     * @param string $role    — 'new' или 'old' (логика трактовки результата разная)
     */
    private function checkHttpRoot(string $domain, string $role = 'new'): array
    {
        $url = "https://{$domain}/";
        // v18.1.1: --resolve fallback только для нового домена (там DNS пропагируется).
        // Для старого — только DNS: если не резолвится, значит домен мёртв (что OK для old).
        // v18.1.20: для старого домена не следуем редиректу — 301 на новый домен это OK.
        $allowResolve = ($role === 'new');
        $followRedirects = ($role === 'new');
        $resp = $this->httpGetWithResolveFallback($url, $allowResolve, $followRedirects);

        // DNS / connect error
        if ($resp['error'] !== null) {
            $isDnsError = stripos($resp['error'], 'could not resolve') !== false ||
                          stripos($resp['error'], 'name or service not known') !== false ||
                          stripos($resp['error'], 'name resolution') !== false;

            // Для СТАРОГО домена DNS-fail — это OK (домен мёртв, поисковики выкинут)
            if ($role === 'old' && $isDnsError) {
                return [
                    'ok' => true,
                    'url' => $url,
                    'http_code' => 0,
                    'error' => $resp['error'],
                    'message' => "DNS не резолвится — домен мёртв (OK для старого домена)",
                ];
            }

            return [
                'ok' => false,
                'url' => $url,
                'http_code' => 0,
                'error' => $resp['error'],
                'message' => "Не удалось подключиться: {$resp['error']}",
            ];
        }

        $code = (int)$resp['http_code'];

        // v18-fix: пометка что использовали resolve fallback (DNS ещё не пропагирован)
        $resolveNote = !empty($resp['used_resolve'])
            ? ' (через --resolve, DNS ещё пропагируется)' : '';

        if ($role === 'new') {
            // Для НОВОГО домена 5xx — это warning, не failure.
            if ($code >= 200 && $code < 500) {
                return [
                    'ok' => true,
                    'url' => $url,
                    'http_code' => $code,
                    'message' => "HTTP {$code}{$resolveNote}",
                    'used_resolve' => !empty($resp['used_resolve']),
                    'dns_pending'  => !empty($resp['dns_pending']),
                ];
            }
            return [
                'ok' => true,  // ← смягчили
                'url' => $url,
                'http_code' => $code,
                'warning' => 'HTTP 5xx — возможно антибот-защита',
                'message' => "HTTP {$code} (возможно антибот-защита, не блокирующая ошибка)",
            ];
        }

        // role === 'old'.
        // v18.1.20: для move-режима 301 на новый домен — это PERFECT result
        if ($code >= 300 && $code < 400) {
            $location = (string)($resp['location'] ?? '');
            $redirectHost = $location !== '' ? parse_url($location, PHP_URL_HOST) : '';
            $isToNewDomain = ($this->newDomain !== '' && $redirectHost === $this->newDomain);
            return [
                'ok' => true,
                'url' => $url,
                'http_code' => $code,
                'location' => $location,
                'message' => $isToNewDomain
                    ? "HTTP {$code} → {$redirectHost} (правильный 301 на новый домен)"
                    : "HTTP {$code} → {$redirectHost} (редирект работает)",
            ];
        }

        // Любой другой HTTP-ответ — OK (даже 5xx означает что домен живой).
        return [
            'ok' => true,
            'url' => $url,
            'http_code' => $code,
            'message' => "HTTP {$code}",
        ];
    }

    /**
     * Проверка robots.txt.
     *
     * @param string $expect 'allow' (новый домен — должен быть открыт) или
     *                       'disallow' (старый — должен быть закрыт от поисковиков)
     *
     * v18.1.20: для $expect = 'disallow' (старый домен в move-режиме) НЕ следуем
     * редиректу — иначе попадаем на новый домен через 301 (move_htaccess_redirect)
     * и видим новый robots с Allow: /, что выдаёт ложный fail.
     * Если получили 301 на новый домен — считаем валидным closure (поисковики
     * пойдут на новый, старый исчезнет из индекса).
     */
    /**
     * v18.1.26: Проверка robots.txt с многоэтапным fallback.
     *
     * @param string $expect 'allow' (новый домен — должен быть открыт) или
     *                       'disallow' (старый — должен быть закрыт от поисковиков)
     * @param JobEventLogger|null $log Логгер для info-сообщений о методах
     * @param array $context Контекст джобы: ['job_id' => int, 'site_id' => int, 'job' => array]
     *                       Нужен для VPS-side fallback и temp-disable.
     *
     * АРХИТЕКТУРНОЕ: проблема была что robots.php у olymp/7k шаблонов подключает
     * guard.php, который при `$redirect_enabled = 1` редиректит на партнёрку
     * (если IP не Yandex по reverse-DNS). С сервера панели мы получаем HTML
     * с meta refresh / Location header, а не robots-контент.
     *
     * Цепочка методов (по приоритету):
     *   1. Method 1 — Curl с YandexBot UA напрямую.
     *      Работает если guard.php whitelist'ит /robots.txt в .htaccess
     *      (RewriteRule ^robots\.txt$ robots.php [L]) ИЛИ если IP в Yandex AS.
     *      На некоторых сайтах работает, на olymp/7k — нет (guard перехватывает).
     *
     *   2. Method 2 — VPS-side через FTP-uploaded probe script.
     *      Заливаем __verify_robots_<token>.php в корень сайта который делает
     *      curl http://127.0.0.1/robots.txt с Host: <domain>. Локальный
     *      запрос обходит REMOTE_ADDR проверку (всё равно 127.0.0.1).
     *      Если guard опирается на UA — это всё равно не сработает,
     *      но даёт второй независимый source.
     *
     *   3. Method 3 — Temp-disable trick.
     *      Временно ставим $redirect_enabled = 0 через RedirectToggler::disable(),
     *      делаем curl /robots.txt (теперь guard не редиректит), возвращаем
     *      $redirect_enabled = 1 через RedirectToggler::enable().
     *      Самый дорогой метод но самый надёжный.
     *
     * Возвращает result первого метода который дал ВАЛИДНЫЙ robots-контент.
     * Если все три провалились — возвращает fail из последнего с details.
     */
    private function checkRobots(string $domain, string $expect, ?JobEventLogger $log = null, array $context = []): array
    {
        // Method 1 — простой curl с YandexBot UA (старая логика).
        if ($log !== null) {
            $log->info('verify_replacement', "robots.txt method 1/3: curl с YandexBot UA");
        }
        $r1 = $this->checkRobotsViaCurl($domain, $expect);
        $r1['method'] = 'curl_yandexbot';

        // Если результат однозначно валидный (получили robots-контент или DNS-fail для disallow) — возвращаем.
        if ($r1['ok'] || $this->isRobotsResultDefinitive($r1)) {
            $r1['methods_tried'] = ['curl_yandexbot'];
            return $r1;
        }

        // Method 1 fail — но valid robots-контент мы НЕ получили (guard перехватил, или 4xx/5xx).
        // Сохраняем для итогового сообщения.
        $allResults = [$r1];

        // Method 2 — VPS-side FTP probe (если разрешено и есть site_id).
        $siteId = (int)($context['site_id'] ?? 0);
        $job = $context['job'] ?? null;
        if ($siteId > 0 && $job !== null && $this->isVpsSideRobotsCheckAllowed()) {
            if ($log !== null) {
                $log->info('verify_replacement', "robots.txt method 2/3: VPS-side через FTP probe");
            }
            $r2 = $this->checkRobotsViaVpsSide($domain, $expect, $siteId, $job, $log);
            $r2['method'] = 'vps_side_ftp';
            if ($r2['ok'] || $this->isRobotsResultDefinitive($r2)) {
                $r2['methods_tried'] = ['curl_yandexbot', 'vps_side_ftp'];
                return $r2;
            }
            $allResults[] = $r2;
        }

        // Method 3 — pipeline-aware temp-disable (если разрешено).
        $jobId = (int)($context['job_id'] ?? 0);
        if ($siteId > 0 && $jobId > 0 && $this->isTempDisableTrickAllowed()) {
            if ($log !== null) {
                $log->info('verify_replacement',
                    "robots.txt method 3/3: pipeline-aware временное отключение редиректа");
            }
            $r3 = $this->checkRobotsViaTempDisable($domain, $expect, $siteId, $jobId, $log, $context);
            $r3['method'] = 'temp_disable_trick';
            if ($r3['ok'] || $this->isRobotsResultDefinitive($r3)) {
                $r3['methods_tried'] = ['curl_yandexbot', 'vps_side_ftp', 'temp_disable_trick'];
                return $r3;
            }
            $allResults[] = $r3;
        }

        // Все методы провалились — возвращаем последний с merge'ом details.
        $last = end($allResults);
        $last['methods_tried'] = array_map(fn($r) => $r['method'] ?? '?', $allResults);
        $last['all_methods_failed'] = true;
        return $last;
    }

    /**
     * v18.1.26: проверка ДЕЙСТВИТЕЛЬНО ли это финальный результат (success или
     * definitive fail), или это "guard перехватил, попробуем другие методы".
     *
     * Definitive = есть смысл прекратить chain:
     *   - ok=true (явно прошло)
     *   - DNS-error для disallow (домен мёртв, не нужно дальше пробовать)
     *   - HTTP 4xx (сервер реально отвечает 4xx, не guard)
     *
     * Indeterminate (нужно пробовать дальше):
     *   - ok=false с HTTP 200 но body не похож на robots — скорее всего guard
     *     перехватил и отдал HTML с meta refresh
     *   - ok=false с HTTP 30x на партнёрский домен — guard отдал Location
     */
    private function isRobotsResultDefinitive(array $result): bool
    {
        if (!empty($result['ok'])) return true;
        // v18.1.26: guard_hijacked = indeterminate (явно пробуем дальше)
        if (!empty($result['guard_hijacked'])) return false;
        $code = (int)($result['http_code'] ?? 0);
        // DNS error для старого — definitive success (domain dead = closed)
        if ($code === 0 && stripos((string)($result['message'] ?? ''), 'не резолвится') !== false) {
            return true;
        }
        // HTTP 4xx/5xx — сервер реально отвечает ошибкой (не guard)
        if ($code >= 400) return true;
        // HTTP 200 но не валидный robots → возможно guard перехватил без HTML
        // (если body просто пустой / странный) — попробуем ещё методы
        // HTTP 30x → guard может редиректить на партнёрку, нужно пробовать дальше
        return false;
    }

    /**
     * v18.1.26: разрешён ли VPS-side robots check? Зависит от настроек.
     */
    private function isVpsSideRobotsCheckAllowed(): bool
    {
        $cfg = $this->loadVerifierConfig();
        return !empty($cfg['allow_vps_side_robots_check']);
    }

    /**
     * v18.1.26: разрешён ли temp-disable trick? Зависит от настроек.
     * По умолчанию ВКЛЮЧЕН, так как это самый надёжный способ.
     */
    private function isTempDisableTrickAllowed(): bool
    {
        $cfg = $this->loadVerifierConfig();
        // Default = true (включено если явно не выключено)
        return !isset($cfg['allow_temp_disable_robots_check'])
            || !empty($cfg['allow_temp_disable_robots_check']);
    }

    /**
     * v18.1.26: загружает конфиг verifier'а (с кешированием).
     */
    private function loadVerifierConfig(): array
    {
        if ($this->verifierConfigCache !== null) return $this->verifierConfigCache;
        $path = Paths::appRoot() . '/config/verifier.php';
        $cfg = [];
        if (is_file($path)) {
            try { $cfg = (require $path) ?: []; } catch (\Throwable $e) { $cfg = []; }
        }
        $this->verifierConfigCache = is_array($cfg) ? $cfg : [];
        return $this->verifierConfigCache;
    }

    /**
     * v18.1.26: Method 1 — старая логика checkRobots переименована.
     * Простой curl с YandexBot UA через httpGetWithResolveFallback.
     */
    private function checkRobotsViaCurl(string $domain, string $expect): array
    {
        $url = "https://{$domain}/robots.txt";
        // v18.1.1: $expect='allow' — это новый домен; $expect='disallow' — старый.
        // --resolve fallback нужен только для нового (DNS пропагируется).
        // Для старого — только DNS: если домен мёртв в DNS, это эквивалент Disallow.
        $allowResolve = ($expect === 'allow');
        // v18.1.20: для СТАРОГО домена НЕ следуем редиректу — в move-режиме на старом
        // домене стоит 301 на новый (через move_htaccess_redirect), и FOLLOWLOCATION
        // привёл бы нас на НОВЫЙ домен → ложный pass/fail на основе нового robots.
        // Для НОВОГО домена follow=true как раньше (может быть www→non-www редирект и т.п.)
        $followRedirects = ($expect === 'allow');
        $resp = $this->httpGetWithResolveFallback($url, $allowResolve, $followRedirects);

        if ($resp['error'] !== null) {
            $isDnsError = stripos($resp['error'], 'could not resolve') !== false ||
                          stripos($resp['error'], 'name or service not known') !== false ||
                          stripos($resp['error'], 'name resolution') !== false;

            // Для СТАРОГО домена DNS-fail значит "домен мёртв" — поисковики его выкинут.
            // Это эквивалентно Disallow: / (даже надёжнее).
            if ($expect === 'disallow' && $isDnsError) {
                return [
                    'ok' => true,
                    'url' => $url,
                    'http_code' => 0,
                    'error' => $resp['error'],
                    'message' => "DNS не резолвится — домен мёртв (≡ закрыт от поисковиков)",
                ];
            }

            return [
                'ok' => false,
                'url' => $url,
                'http_code' => 0,
                'error' => $resp['error'],
                'message' => "Не удалось скачать robots.txt: {$resp['error']}",
            ];
        }

        $code = (int)$resp['http_code'];
        $body = (string)($resp['body'] ?? '');

        // v18-fix: пометка про --resolve fallback
        $usedResolve = !empty($resp['used_resolve']);
        $dnsPending  = !empty($resp['dns_pending']);
        $resolveNote = $usedResolve ? ' (через --resolve, DNS ещё пропагируется)' : '';

        // v18.1.20: для СТАРОГО домена в move-режиме часто стоит 301 → новый домен.
        // Это валидное "закрытие" — поисковики переиндексируют как переезд.
        // Проверяем что Location ведёт именно на newDomain (не куда попало).
        if ($expect === 'disallow' && $code >= 300 && $code < 400) {
            $location = (string)($resp['location'] ?? '');
            $redirectHost = $location !== '' ? parse_url($location, PHP_URL_HOST) : '';
            $isToNewDomain = ($this->newDomain !== '' && $redirectHost === $this->newDomain);
            if ($isToNewDomain) {
                return [
                    'ok' => true,
                    'url' => $url,
                    'http_code' => $code,
                    'location' => $location,
                    'message' => "Старый домен отдаёт {$code} → новый домен ({$redirectHost}) — переезд (≡ закрытию для поисковиков)",
                ];
            }
            // 30x но не на новый домен — подозрительно, но не критично:
            // редирект на куда-то ещё = старый всё равно "недоступен напрямую"
            return [
                'ok' => true,
                'url' => $url,
                'http_code' => $code,
                'location' => $location,
                'message' => "HTTP {$code} → {$redirectHost} (не наш newDomain, но контента нет — ≡ закрытию)",
            ];
        }

        // Для СТАРОГО домена 4xx/5xx тоже нормально — сайт не отвечает корректно,
        // значит поисковики переиндексируют как мёртвый.
        if ($expect === 'disallow' && $code >= 400) {
            return [
                'ok' => true,
                'url' => $url,
                'http_code' => $code,
                'body_excerpt' => $this->excerpt($body),
                'used_resolve' => $usedResolve,
                'dns_pending'  => $dnsPending,
                'message' => "HTTP {$code} — старый домен не отдаёт robots, что эквивалентно закрытию",
            ];
        }

        if ($code !== 200) {
            return [
                'ok' => false,
                'url' => $url,
                'http_code' => $code,
                'body_excerpt' => $this->excerpt($body),
                'used_resolve' => $usedResolve,
                'dns_pending'  => $dnsPending,
                'message' => "robots.txt вернул HTTP {$code}{$resolveNote}",
            ];
        }

        // v18.1.26: ДЕТЕКТ guard-hijacked body. Если HTTP 200 пришёл, но body — это HTML
        // с meta refresh / JS redirect / Location header вместо robots-контента, значит
        // guard.php перехватил запрос (не whitelistнул /robots.txt). Возвращаем
        // indeterminate result чтобы chain попробовал другие методы.
        if ($code === 200 && $this->isRobotsBodyGuardHijacked($body)) {
            return [
                'ok' => false,
                'url' => $url,
                'http_code' => $code,
                'body_excerpt' => $this->excerpt($body),
                'used_resolve' => $usedResolve,
                'dns_pending'  => $dnsPending,
                'guard_hijacked' => true,
                'message' => "guard.php перехватил /robots.txt — отдал HTML с редиректом вместо текста robots. " .
                             "Попробую другие методы проверки.",
            ];
        }

        // Парсим robots
        $hasDisallowAll = $this->robotsHasDisallowAll($body);
        $hasAllow = $this->robotsHasAllow($body);

        if ($expect === 'disallow') {
            // Старый домен — должен быть закрыт
            $ok = $hasDisallowAll && !$hasAllow;
            // v18.1.1: подсказка про возможные причины фейла
            $hint = '';
            if (!$ok) {
                $hint = ". Возможные причины: (1) старый домен на ДРУГОМ FastPanel-сайте " .
                        "(не алиас текущего); (2) кеш CDN/Cloudflare ещё хранит старый robots — " .
                        "сбрось через CDN-панель";
            }
            return [
                'ok' => $ok,
                'url' => $url,
                'http_code' => $code,
                'has_disallow_all' => $hasDisallowAll,
                'has_allow' => $hasAllow,
                'body_excerpt' => $this->excerpt($body),
                'used_resolve' => $usedResolve,
                'dns_pending'  => $dnsPending,
                'message' => $ok
                    ? "Старый домен закрыт (Disallow: /){$resolveNote}"
                    : "Старый домен НЕ закрыт от поисковиков (нет Disallow: / или есть Allow:){$resolveNote}{$hint}",
            ];
        }

        // Новый домен — должен быть открыт
        $ok = $hasAllow && !$this->robotsIsOnlyDisallowAll($body);
        // REV3.2 robots-diag: валидный HTTP 200 robots, ЯВНО закрывающий новый домен
        // (Disallow: / без Allow:) — не транзиент кеша, а осознанно закрытый robots.
        $robotsClosed = !$ok && $hasDisallowAll && !$hasAllow;
        return [
            'ok' => $ok,
            'url' => $url,
            'http_code' => $code,
            'has_disallow_all' => $hasDisallowAll,
            'has_allow' => $hasAllow,
            'robots_closed' => $robotsClosed,
            'body_excerpt' => $this->excerpt($body),
            'used_resolve' => $usedResolve,
            'dns_pending'  => $dnsPending,
            'message' => $ok
                ? "Новый домен открыт для поисковиков{$resolveNote}"
                : ($robotsClosed
                    ? "Новый домен отдаёт `Disallow: /` без `Allow:` — robots закрыт для поисковиков{$resolveNote}"
                    : "Новый домен закрыт или robots не настроен правильно{$resolveNote}"),
        ];
    }

    /**
     * В robots есть строка `Disallow: /` для * user-agent?
     */
    private function robotsHasDisallowAll(string $body): bool
    {
        // Ищем "Disallow: /" в любом месте, в начале строки, после User-agent: *
        // Простая эвристика: если есть строка точно "Disallow: /" — возвращаем true
        $lines = preg_split('/\R/', $body);
        if ($lines === false) return false;
        foreach ($lines as $line) {
            $trimmed = trim($line);
            // Disallow: /  (без чего-то после)
            if (preg_match('~^Disallow:\s*/\s*$~i', $trimmed)) {
                return true;
            }
        }
        return false;
    }

    /**
     * В robots есть строка `Allow: ...`?
     */
    private function robotsHasAllow(string $body): bool
    {
        $lines = preg_split('/\R/', $body);
        if ($lines === false) return false;
        foreach ($lines as $line) {
            $trimmed = trim($line);
            if (preg_match('~^Allow:\s*\S+~i', $trimmed)) {
                return true;
            }
        }
        return false;
    }

    /**
     * robots содержит ТОЛЬКО Disallow: / (без Allow: и других полезных строк).
     * Используется для проверки нового домена — он не должен быть закрыт.
     */
    private function robotsIsOnlyDisallowAll(string $body): bool
    {
        $hasDisallow = $this->robotsHasDisallowAll($body);
        $hasAllow = $this->robotsHasAllow($body);
        return $hasDisallow && !$hasAllow;
    }

    /**
     * cURL GET с обходом self-signed SSL и таймаутом.
     */
    /**
     * v18-fix: HTTP GET с прозрачным fallback'ом на --resolve если первый
     * запрос фейлит из-за DNS. Возвращает один результат + флаг used_resolve.
     *
     * Логика:
     *   1. Делаем обычный GET через DNS
     *   2. Если упал с "Could not resolve host" / "name resolution" — это DNS race
     *      → пробуем через --resolve $domain:443:$resolveIp
     *      → если получилось — отмечаем used_resolve=true, dns_pending=true
     *   3. В остальных случаях возвращаем результат как есть.
     *
     * Если $resolveIp не задан — работает как обычный httpGet.
     */
    /**
     * v18.1.1: добавлен $allowResolve. Если false (default для old_* проверок) —
     * используется только обычный DNS, никогда не fallback'имся через --resolve.
     *
     * Зачем: --resolve fallback идёт на наш IP. Для НОВОГО домена это правильно
     * (DNS ещё пропагируется, но физически файл уже на нашем сервере). Для
     * СТАРОГО домена это вредно: старый алиас может быть удалён с FP, и
     * --resolve попадёт на дефолтный сайт сервера (или на тот же сайт но без
     * правильного Host-роутинга — robots.php увидит HTTP_HOST = oldDomain
     * но config показывает newDomain → отдаст Disallow: /, что мы хотим. Но
     * это случайно работает, не системно.) Поэтому для old_* — только DNS.
     */
    private function httpGetWithResolveFallback(string $url, bool $allowResolve = true, bool $followRedirects = true): array
    {
        // Извлекаем домен из URL для resolve
        $parsed = parse_url($url);
        $domain = $parsed['host'] ?? '';
        $port = $parsed['port'] ?? (($parsed['scheme'] ?? 'https') === 'https' ? 443 : 80);

        // Первая попытка — обычная через DNS
        $r1 = $this->httpGet($url, null, $followRedirects);
        $r1['used_resolve'] = false;
        $r1['dns_pending']  = false;

        // Если успешно (2xx-3xx или контент есть) — возвращаем
        if ($r1['error'] === null && $r1['http_code'] > 0) {
            return $r1;
        }

        // resolve_ip не задан — fallback невозможен
        if ($this->resolveIp === null || $domain === '') {
            return $r1;
        }

        // v18.1.1: если caller запретил resolve — не делаем fallback
        if (!$allowResolve) {
            return $r1;
        }

        // Проверяем что ошибка — DNS-related
        $err = (string)($r1['error'] ?? '');
        $isDnsErr = (
            stripos($err, 'resolve host') !== false
            || stripos($err, "couldn't resolve") !== false
            || stripos($err, 'name resolution') !== false
            || stripos($err, 'name or service not known') !== false
        );

        if (!$isDnsErr) {
            // Не DNS-ошибка — fallback не поможет
            return $r1;
        }

        // Делаем повторный запрос через --resolve. Передаём followRedirects.
        $r2 = $this->httpGet($url, "{$domain}:{$port}:{$this->resolveIp}", $followRedirects);
        $r2['used_resolve'] = true;
        $r2['dns_pending']  = true;
        $r2['original_error'] = $err;

        return $r2;
    }

    /**
     * v18-fix: расширен с опциональным $resolveOverride — строка вида
     * "domain:port:ip" для CURLOPT_RESOLVE. Если задан, curl идёт прямо
     * на указанный IP с правильным Host header.
     *
     * v18.1.20: добавлен $followRedirects. Если false — НЕ следуем 3xx, чтобы
     * увидеть первый Location header (нужно для old-проверок в move-режиме).
     * Возвращает 'location' в ответе если был 3xx-ответ.
     */
    private function httpGet(string $url, ?string $resolveOverride = null, bool $followRedirects = true): array
    {
        $ch = curl_init($url);
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => $followRedirects,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => $this->timeout,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) refresh-panel-verifier',
            // v18.1.20: всегда забираем заголовки чтобы вытащить Location при 3xx
            CURLOPT_HEADER => true,
        ];
        if ($resolveOverride !== null) {
            $opts[CURLOPT_RESOLVE] = [$resolveOverride];
        }
        curl_setopt_array($ch, $opts);

        $rawResponse = curl_exec($ch);
        $errNo = curl_errno($ch);
        $err = $errNo !== 0 ? curl_error($ch) : null;
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);

        if ($rawResponse === false) $rawResponse = '';

        // Разделим headers и body
        $rawHeaders = substr((string)$rawResponse, 0, $headerSize);
        $body = substr((string)$rawResponse, $headerSize);

        // Вытащим Location из первого блока заголовков (если был 3xx без follow)
        $location = '';
        if (preg_match('~^Location:\s*(.+?)\r?$~mi', $rawHeaders, $m)) {
            $location = trim($m[1]);
        }

        return [
            'http_code' => $code,
            'body' => $body,
            'location' => $location,
            'error' => $err,
        ];
    }

    private function excerpt(string $body, int $maxLen = 200): string
    {
        $body = trim($body);
        if (mb_strlen($body) <= $maxLen) return $body;
        return mb_substr($body, 0, $maxLen) . '...';
    }

    private function joinList(array $items): string
    {
        if (empty($items)) return '';
        return implode(', ', $items);
    }

    private function stripScheme(string $url): string
    {
        $u = trim($url);
        $u = preg_replace('~^https?://~i', '', $u);
        $u = preg_replace('~/.*$~', '', $u);
        return strtolower(trim($u));
    }

    // ============================================================
    // v18.1.26: helpers для robots multi-method chain
    // ============================================================

    /**
     * Детектор: body — это HTML с meta refresh / JS redirect (guard перехватил),
     * вместо реального robots.txt текста.
     *
     * Признаки:
     *   - содержит "<html" или "<!doctype"
     *   - содержит meta http-equiv="refresh"
     *   - содержит location.href= / document.location=
     *   - НЕ содержит ни одной строки начинающейся с User-agent:/Allow:/Disallow:/Host:/Sitemap:
     *
     * Реальный robots.txt — это plain-text без HTML тегов, обычно <200 байт.
     */
    private function isRobotsBodyGuardHijacked(string $body): bool
    {
        $body = trim($body);
        if ($body === '') return false; // пусто — не считаем hijacked, пусть выше парсится

        // Признак реального robots — есть хотя бы одна строка с robots-директивой
        $hasRobotsDirective = preg_match(
            '~^\s*(?:User-agent:|Allow:|Disallow:|Host:|Sitemap:|Crawl-delay:|Clean-param:)~mi',
            $body
        ) === 1;
        if ($hasRobotsDirective) return false;

        // Признаки HTML / редирект-страницы
        $hasHtml = stripos($body, '<html') !== false || stripos($body, '<!doctype') !== false;
        $hasMetaRefresh = (bool)preg_match('~<meta[^>]+http-equiv=["\']?refresh~i', $body);
        $hasJsRedirect = preg_match(
            '~(?:window\.location|document\.location|location\.href)\s*=~i',
            $body
        ) === 1;

        return $hasHtml || $hasMetaRefresh || $hasJsRedirect;
    }

    /**
     * v18.1.26: Method 2 — VPS-side robots probe.
     *
     * Заливаем через FTP скрипт __verify_robots_<token>.php в корень сайта,
     * который делает `curl http://127.0.0.1/robots.txt` с правильным Host header
     * и возвращает body. Запускаем через https://<domain>/__verify_robots_<token>.php
     * (probe-скрипт — это PHP, отвечает раньше чем guard.php который только
     * для /reg /play /robots.txt — для нашего uri он НЕ запускается).
     *
     * После use — удаляем probe-скрипт через FTP.
     *
     * Note: probe-скрипт сам по себе не подключает guard.php, поэтому он не
     * редиректит. Он использует loopback curl чтобы получить честный ответ
     * сайта от Apache как если бы запрос был с самого сервера.
     */
    private function checkRobotsViaVpsSide(
        string $domain,
        string $expect,
        int $siteId,
        array $job,
        ?JobEventLogger $log = null
    ): array {
        $url = "https://{$domain}/robots.txt";

        try {
            // Получаем FTP credentials из sites_managed/ftp_credentials.
            $ftpInfo = $this->resolveSiteFtp($siteId);
            if (empty($ftpInfo)) {
                return [
                    'ok' => false,
                    'url' => $url,
                    'http_code' => 0,
                    'message' => 'VPS-side: не найдены FTP credentials для сайта',
                ];
            }

            $token = bin2hex(random_bytes(8));
            $probeFile = "__verify_robots_{$token}.php";
            $probeBody = "<?php\n" .
                "// v18.1.26 robots probe — авто-удаляется\n" .
                "header('Content-Type: application/json');\n" .
                "\$host = " . var_export($domain, true) . ";\n" .
                "\$ch = curl_init('http://127.0.0.1/robots.txt');\n" .
                "curl_setopt_array(\$ch, [\n" .
                "    CURLOPT_RETURNTRANSFER => true,\n" .
                "    CURLOPT_HTTPHEADER => ['Host: ' . \$host],\n" .
                "    CURLOPT_FOLLOWLOCATION => false,\n" .
                "    CURLOPT_TIMEOUT => 10,\n" .
                "    CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; YandexBot/3.0)',\n" .
                "]);\n" .
                "\$body = curl_exec(\$ch);\n" .
                "\$code = curl_getinfo(\$ch, CURLINFO_HTTP_CODE);\n" .
                "\$err = curl_error(\$ch);\n" .
                "curl_close(\$ch);\n" .
                "echo json_encode([\n" .
                "    'http_code' => \$code,\n" .
                "    'body' => \$body !== false ? base64_encode(\$body) : null,\n" .
                "    'error' => \$err ?: null,\n" .
                "], JSON_UNESCAPED_UNICODE);\n";

            $ftp = new FtpService(
                $ftpInfo['host'],
                $ftpInfo['user'],
                $ftpInfo['pass'],
                ['port' => (int)($ftpInfo['port'] ?? 21)]
            );

            $remotePath = ($ftpInfo['base_path'] ?? '') !== ''
                ? rtrim($ftpInfo['base_path'], '/') . '/' . $probeFile
                : $probeFile;
            // backupExt=null — probe-файл не нужен backup
            try {
                $ftp->putContent($remotePath, $probeBody, null);
                $uploadOk = true;
            } catch (\Throwable $e) {
                $uploadOk = false;
                if ($log !== null) {
                    $log->warn('verify_replacement', 'VPS-side: FTP upload failed: ' . $e->getMessage());
                }
            }
            if (!$uploadOk) {
                return [
                    'ok' => false,
                    'url' => $url,
                    'http_code' => 0,
                    'message' => 'VPS-side: не удалось загрузить probe-script через FTP',
                ];
            }

            // Дёргаем probe.
            $probeUrl = "https://{$domain}/{$probeFile}";
            $resp = $this->httpGetWithResolveFallback($probeUrl, true, false);

            // Удаляем probe сразу (даже если ответ плохой).
            try { $ftp->deleteFile($remotePath); } catch (\Throwable $e) {}

            if ($resp['error'] !== null || (int)$resp['http_code'] !== 200) {
                return [
                    'ok' => false,
                    'url' => $url,
                    'http_code' => (int)$resp['http_code'],
                    'probe_url' => $probeUrl,
                    'message' => "VPS-side: probe ответил HTTP " . (int)$resp['http_code'] .
                                 ($resp['error'] ? " (err: {$resp['error']})" : ''),
                ];
            }

            $probeData = json_decode((string)$resp['body'], true);
            if (!is_array($probeData) || !isset($probeData['body'])) {
                return [
                    'ok' => false,
                    'url' => $url,
                    'http_code' => 0,
                    'message' => 'VPS-side: probe вернул не-JSON ответ',
                ];
            }

            $realBody = base64_decode((string)$probeData['body']) ?: '';
            $realCode = (int)($probeData['http_code'] ?? 0);

            // Парсим как обычный robots
            return $this->parseRobotsBody($realBody, $realCode, $url, $expect, 'vps_side');
        } catch (\Throwable $e) {
            if ($log !== null) {
                $log->warn('verify_replacement', 'VPS-side robots check exception: ' . $e->getMessage());
            }
            return [
                'ok' => false,
                'url' => $url,
                'http_code' => 0,
                'message' => 'VPS-side: exception — ' . $e->getMessage(),
            ];
        }
    }

    /**
     * v18.1.26: Method 3 — temp-disable trick.
     *
     * 1. Снимаем $redirect_enabled=0 через RedirectToggler::disable() — guard не редиректит.
     * 2. Делаем curl /robots.txt — guard НЕ перехватит, отдаст реальный robots.
     * 3. Возвращаем $redirect_enabled=1 через RedirectToggler::enable().
     *
     * ВАЖНО: между шагами 1 и 3 сайт ВРЕМЕННО не редиректит на партнёрку — может
     * быть период до нескольких секунд когда живой трафик упадёт. Это допустимая
     * цена за корректную верификацию.
     *
     * Возвращает result проверки. Гарантирует что redirect будет включён обратно
     * (даже при exception'е в middle).
     */
    /**
     * v18.1.28: Method 3 — pipeline-aware redirect handling для robots check.
     *
     * НЕ нарушает pipeline state. Поведение зависит от текущей стадии job'а:
     *
     * ━━━ A) До `redirect_enable` (стадия verify_replacement, etc):
     *     Pipeline-invariant: редирект ДОЛЖЕН быть отключён (стадия redirect_disable
     *     уже отработала). Если мы видим guard-hijacked ответ — это значит редирект
     *     "вдруг включён" = косяк скрипта (тихий fail redirect_disable стадии).
     *     Действие: отключить редирект ЗАНОВО (восстановить инвариант), проверить
     *     robots, и ОСТАВИТЬ редирект отключённым (его включит redirect_enable стадия).
     *
     * ━━━ B) После `redirect_enable` (стадии index_watching, wm_*, etc):
     *     Pipeline-invariant: редирект ДОЛЖЕН быть включён.
     *     Действие: temp-disable trick — отключить → проверить → ВКЛЮЧИТЬ обратно.
     *
     * Это решает проблему v18.1.26 где Method 3 безусловно делал disable+enable,
     * нарушая pipeline state на verify_replacement (там pipeline хочет редирект
     * отключённым, а Method 3 включал обратно — конфликт state).
     */
    private function checkRobotsViaTempDisable(
        string $domain,
        string $expect,
        int $siteId,
        int $jobId,
        ?JobEventLogger $log = null,
        array $context = []
    ): array {
        $url = "https://{$domain}/robots.txt";
        $logger = $log ?? new JobEventLogger($jobId);

        // Определяем pipeline-стадию из context job'а
        $currentStage = (string)(($context['job']['stage'] ?? '') ?: '');
        $shouldRedirectBeDisabledNow = $this->isStageBeforeRedirectEnable($currentStage);

        $modeLabel = $shouldRedirectBeDisabledNow
            ? 'restore-disabled-state'   // pipeline хочет disabled, восстанавливаем
            : 'temp-disable-roundtrip';  // pipeline хочет enabled, делаем temp roundtrip

        $disabled = false;
        $disableResult = null;

        try {
            $toggler = new RedirectToggler();
            $logger->info('verify_replacement',
                "robots check ({$modeLabel}): отключаю редирект для {$domain}");
            $disableResult = $toggler->disable($siteId, $jobId, $logger);
            if (empty($disableResult['ok'])) {
                return [
                    'ok' => false,
                    'url' => $url,
                    'http_code' => 0,
                    'method_mode' => $modeLabel,
                    'message' => "temp-disable ({$modeLabel}): не удалось снять редирект — " .
                                 ($disableResult['message'] ?? '?'),
                ];
            }
            $disabled = true;

            // Небольшая пауза — apache/opcache мог закешировать config.php.
            sleep(2);

            // Проверяем (без HTML hijack — guard сейчас не редиректит).
            $resp = $this->httpGetWithResolveFallback($url, true, ($expect === 'allow'));

            $code = (int)($resp['http_code'] ?? 0);
            $body = (string)($resp['body'] ?? '');

            // === Pipeline-aware решение что делать с редиректом дальше ===
            if ($shouldRedirectBeDisabledNow) {
                // Mode A: pipeline хочет disabled — ОСТАВЛЯЕМ отключённым.
                // Это и есть восстановление pipeline state (был косяк — пофиксили).
                $logger->warn('verify_replacement',
                    "robots check: редирект ОСТАВЛЕН отключённым (pipeline-стадия '{$currentStage}' " .
                    "ожидает отключённый редирект; включат на стадии redirect_enable). " .
                    "Если редирект был включён до этого — это косяк, который мы исправили.");
                // Mark $disabled=true чтобы catch-блок НЕ пытался включить обратно
                $disabled = false; // блок выхода уже не нужен
            } else {
                // Mode B: pipeline хочет enabled — ВКЛЮЧАЕМ обратно (temp roundtrip).
                $logger->info('verify_replacement',
                    "robots check: включаю редирект обратно (pipeline-стадия '{$currentStage}' " .
                    "ожидает включённый редирект)");
                $stateFromDisable = $disableResult ?? [];
                $toggler->enable($siteId, $jobId, $stateFromDisable, $logger);
                $disabled = false;
            }

            // Парсим body
            $result = $this->parseRobotsBody($body, $code, $url, $expect, 'temp_disable');
            $result['method_mode'] = $modeLabel;
            $result['pipeline_stage_at_check'] = $currentStage;
            return $result;
        } catch (\Throwable $e) {
            $logger->warn('verify_replacement', 'temp-disable exception: ' . $e->getMessage());
            // Решение catch-блока ЗАВИСИТ от mode:
            // Mode A (pipeline хочет disabled) — НЕ включаем (это правильный state)
            // Mode B (pipeline хочет enabled) — пытаемся включить обратно
            if ($disabled && !$shouldRedirectBeDisabledNow) {
                try {
                    $toggler = new RedirectToggler();
                    $stateFromDisable = $disableResult ?? [];
                    $toggler->enable($siteId, $jobId, $stateFromDisable, $logger);
                    $logger->warn('verify_replacement',
                        "temp-disable: включил редирект обратно после exception'а " .
                        "(pipeline-стадия '{$currentStage}' требует включённый)");
                } catch (\Throwable $e2) {
                    $logger->error('verify_replacement',
                        "ВНИМАНИЕ: temp-disable не смог включить редирект обратно: " . $e2->getMessage() .
                        ". Проверь сайт {$domain} вручную!");
                }
            }
            return [
                'ok' => false,
                'url' => $url,
                'http_code' => 0,
                'method_mode' => $modeLabel,
                'message' => 'temp-disable: exception — ' . $e->getMessage(),
            ];
        }
    }

    /**
     * v18.1.28: проверка — текущая pipeline-стадия ДО стадии `redirect_enable`?
     * Если да — редирект сейчас должен быть отключён (pipeline-инвариант).
     * Если нет — редирект должен быть включён.
     *
     * Стадии в порядке pipeline'а (см. RefreshOrchestrator::STAGES_ORDER):
     *   queued, domain_purchasing, aliases_added, ssl_self_signed_first,
     *   redirect_disable, analyze_site, config_replaced, verify_replacement,
     *   ssl_le_polling, update_classes_call,
     *   ───── redirect_enable ───── (граница)
     *   move_htaccess_redirect, wm_*, index_watching, ...
     */
    private function isStageBeforeRedirectEnable(string $stage): bool
    {
        $beforeEnable = [
            'queued', 'domain_purchasing', 'aliases_added', 'ssl_self_signed_first',
            'redirect_disable', 'analyze_site', 'config_replaced', 'verify_replacement',
            'ssl_le_polling', 'update_classes_call',
        ];
        return in_array($stage, $beforeEnable, true);
    }

    /**
     * v18.1.26: общий парсер robots body. Используется и method 2 и method 3.
     */
    private function parseRobotsBody(
        string $body,
        int $code,
        string $url,
        string $expect,
        string $methodLabel
    ): array {
        // Если HTTP не 200 — handle как fail (если allow) или success (если disallow + 4xx)
        if ($code !== 200) {
            if ($expect === 'disallow' && $code >= 300) {
                return [
                    'ok' => true,
                    'url' => $url,
                    'http_code' => $code,
                    'message' => "[{$methodLabel}] HTTP {$code} — старый домен не отдаёт robots (≡ закрытию)",
                ];
            }
            return [
                'ok' => false,
                'url' => $url,
                'http_code' => $code,
                'message' => "[{$methodLabel}] HTTP {$code}",
            ];
        }

        // HTTP 200 — проверяем hijack
        if ($this->isRobotsBodyGuardHijacked($body)) {
            return [
                'ok' => false,
                'url' => $url,
                'http_code' => 200,
                'guard_hijacked' => true,
                'body_excerpt' => $this->excerpt($body),
                'message' => "[{$methodLabel}] body — HTML с редиректом, не robots-контент",
            ];
        }

        $hasDisallowAll = $this->robotsHasDisallowAll($body);
        $hasAllow = $this->robotsHasAllow($body);

        if ($expect === 'disallow') {
            $ok = $hasDisallowAll && !$hasAllow;
            return [
                'ok' => $ok,
                'url' => $url,
                'http_code' => $code,
                'has_disallow_all' => $hasDisallowAll,
                'has_allow' => $hasAllow,
                'body_excerpt' => $this->excerpt($body),
                'message' => $ok
                    ? "[{$methodLabel}] Старый домен закрыт (Disallow: /)"
                    : "[{$methodLabel}] Старый домен НЕ закрыт от поисковиков",
            ];
        }

        // Новый домен — должен быть открыт
        $ok = $hasAllow && !$this->robotsIsOnlyDisallowAll($body);
        $robotsClosed = !$ok && $hasDisallowAll && !$hasAllow;  // REV3.2 robots-diag
        return [
            'ok' => $ok,
            'url' => $url,
            'http_code' => $code,
            'has_disallow_all' => $hasDisallowAll,
            'has_allow' => $hasAllow,
            'robots_closed' => $robotsClosed,
            'body_excerpt' => $this->excerpt($body),
            'message' => $ok
                ? "[{$methodLabel}] Новый домен открыт для поисковиков"
                : ($robotsClosed
                    ? "[{$methodLabel}] Новый домен отдаёт `Disallow: /` без `Allow:` — robots закрыт для поисковиков"
                    : "[{$methodLabel}] Новый домен закрыт или robots не настроен правильно"),
        ];
    }

    /**
     * v18.1.26: получить FTP credentials для сайта из БД.
     */
    private function resolveSiteFtp(int $siteId): ?array
    {
        try {
            $st = DB::pdo()->prepare(
                "SELECT ftp_host, ftp_user, ftp_pass, ftp_port, ftp_base_path
                 FROM sites_managed WHERE id = ?"
            );
            $st->execute([$siteId]);
            $row = $st->fetch();
            if (!$row) return null;
            return [
                'host' => (string)($row['ftp_host'] ?? ''),
                'user' => (string)($row['ftp_user'] ?? ''),
                'pass' => (string)($row['ftp_pass'] ?? ''),
                'port' => (int)($row['ftp_port'] ?? 21),
                'base_path' => (string)($row['ftp_base_path'] ?? ''),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }
}
