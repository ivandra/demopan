<?php

/**
 * Сервис для отключения/включения редиректов на сайтах во время перевыставления.
 *
 * Используется двумя стадиями оркестратора:
 *   - redirect_disable — перед analyze_site, чтобы пользователи не уходили
 *     на партнёрку пока сайт в неполноценном состоянии
 *   - redirect_enable — после verify_replacement, чтобы вернуть редирект
 *     обратно
 *
 * Правила хранятся в config/redirect_rules.php — каждое правило это пара
 * regex (detect / disable / enable). Для каждого подходящего файла применяются
 * ВСЕ подходящие правила. State (что было применено) сохраняется в artifacts
 * чтобы enable знал какие правила обращать.
 *
 * Использует тот же FtpService и multi-path probing что и SiteFileScanner —
 * чтобы работать на чрутнутых FTP.
 */
class RedirectToggler
{
    /** @var array кэш правил из конфига */
    private array $rules;

    private string $snapshotsBaseDir;

    public function __construct()
    {
        $this->rules = $this->loadRules();
        $this->snapshotsBaseDir = dirname(__DIR__, 2) . '/storage/snapshots';
        if (!is_dir($this->snapshotsBaseDir)) {
            @mkdir($this->snapshotsBaseDir, 0775, true);
        }
    }

    /**
     * Отключить редиректы на сайте.
     *
     * Алгоритм:
     *   1. Подключиться к FTP, найти рабочий base_path
     *   2. Для каждого правила:
     *      - скачать соответствующий файл
     *      - применить detect — сработало?
     *      - если да: применить disable_find/replace, сохранить snapshot, залить
     *   3. Вернуть state — какие правила сработали и для каких файлов сделаны
     *      snapshots. enable() будет использовать этот state.
     *
     * @return array {
     *   ok: bool,
     *   applied_rules: array — список применённых rule_id с деталями
     *   snapshots: array     — file => snapshot_filename
     *   base_path: string    — для последующего enable
     *   errors: array
     * }
     */
    public function disable(int $siteId, int $jobId, $log): array
    {
        $this->markerDiag = [];
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'errors' => ["Site #{$siteId} not found"], 'applied_rules' => [], 'snapshots' => []];
        }

        $siteRoot = $this->resolveSiteRoot($site);
        if ($siteRoot === '') {
            return ['ok' => false, 'errors' => ['Cannot resolve site root'], 'applied_rules' => [], 'snapshots' => []];
        }

        $log->info('redirect_disable', "Файлы кандидатов на редактирование: " .
            implode(', ', array_unique(array_column($this->rules, 'file'))));

        // FTP
        try {
            $ftp = $this->makeFtp($site);
            $ftp->connect();
        } catch (\Throwable $e) {
            return [
                'ok' => false,
                'errors' => ['FTP connect failed: ' . $e->getMessage()],
                'applied_rules' => [], 'snapshots' => []
            ];
        }

        // Multi-path probing — переиспользуем логику из SiteFileScanner.
        // Берём первый файл из правил (обычно .htaccess или config.php) как маяк.
        $basePath = $this->findWorkingBasePath($ftp, $siteRoot, $site, $log);
        if ($basePath === null) {
            $ftp->disconnect();
            return [
                'ok' => false,
                'errors' => ['Не удалось найти рабочий base_path. FTP-доступ корректен? Файлы есть?'],
                'applied_rules' => [], 'snapshots' => []
            ];
        }
        $log->info('redirect_disable', "Рабочий base_path: '" . ($basePath === '' ? '(пустой = от FTP-корня)' : $basePath) . "'");

        // Группируем правила по файлам — чтобы не качать один файл много раз
        $byFile = [];
        foreach ($this->rules as $rule) {
            $byFile[$rule['file']][] = $rule;
        }

        $appliedRules = [];
        $snapshots = [];
        $errors = [];
        $detectedMechanisms = [];   // REV3.2 §5
        $readback = [];             // REV3.2 §3.2: file => bool (exact FTP read-back verified)
        $originalSha = [];          // REV3.2 §3.2: file => sha256 исходного содержимого

        $snapshotDir = $this->snapshotsBaseDir . '/job_' . $jobId;
        if (!is_dir($snapshotDir)) {
            @mkdir($snapshotDir, 0775, true);
        }

        foreach ($byFile as $fileName => $fileRules) {
            $remotePath = $basePath === '' ? $fileName : (rtrim($basePath, '/') . '/' . $fileName);

            // Скачиваем файл
            try {
                $content = $ftp->getContent($remotePath);
            } catch (\Throwable $e) {
                $log->info('redirect_disable',
                    "файл {$fileName} не найден или недоступен — пропускаю (не критично)");
                continue;
            }

            $modified = $content;
            $appliedToFile = [];

            foreach ($fileRules as $rule) {
                // ТЗ044 §9: idempotent канонизация для php_redirect_enabled_var (без дублей маркеров).
                if (($rule['id'] ?? '') === 'php_redirect_enabled_var') {
                    $canon = $this->canonicalizeRedirectVar($modified, 0);
                    if (!empty($canon['found'])) {
                        $this->markerDiag[$fileName] = $canon['diag'];
                        if (!empty($canon['changed'])) {
                            $modified = $canon['content'];
                            $appliedToFile[] = ['rule_id' => $rule['id'], 'description' => $rule['description'], 'count' => 1];
                            $log->info('redirect_disable',
                                "✓ {$rule['id']} в {$fileName}: канонизирован redirect_enabled=0 "
                                . "(маркеров до={$canon['markers_before']}, после=1, снято дублей={$canon['normalized_duplicates']})");
                        } else {
                            $log->info('redirect_disable',
                                "= {$rule['id']} в {$fileName}: уже disabled — идемпотентно, маркеров={$canon['markers_after']}");
                        }
                        continue; // generic regex не применяем
                    }
                }

                // Detect
                if (!@preg_match($rule['detect'], $modified)) {
                    continue; // правило не подходит к этому контенту
                }

                // Disable
                $newContent = @preg_replace($rule['disable_find'], $rule['disable_replace'], $modified, -1, $count);
                if ($newContent === null) {
                    $errors[] = "{$rule['id']}: regex error in disable_find";
                    continue;
                }
                if ($count === 0 || $newContent === $modified) {
                    // detect сработал, но disable_find не нашёл подходящих строк — странно, лог предупреждение
                    $log->warn('redirect_disable',
                        "правило {$rule['id']}: detect совпал, но disable_find не нашёл строк (regex несогласован?)");
                    continue;
                }

                $modified = $newContent;
                $appliedToFile[] = [
                    'rule_id' => $rule['id'],
                    'description' => $rule['description'],
                    'count' => $count,
                ];
                $log->info('redirect_disable',
                    "✓ {$rule['id']} в {$fileName}: применено {$count} замен");
            }

            // Если хоть одно правило применилось — сохраняем snapshot и заливаем
            if (!empty($appliedToFile) && $modified !== $content) {
                $snapshotName = $this->safeSnapshotName($fileName) . '.before-disable.txt';
                $snapshotPath = $snapshotDir . '/' . $snapshotName;
                if (@file_put_contents($snapshotPath, $content) === false) {
                    $errors[] = "{$fileName}: не удалось сохранить snapshot";
                    continue;
                }

                try {
                    $ftp->putContent($remotePath, $modified, null);
                    $snapshots[$fileName] = $snapshotName;
                    $originalSha[$fileName] = hash('sha256', $content);
                    // REV3.2 §3.2: exact read-back — remote_sha256 должен совпасть с залитым.
                    $rb = $this->readBackVerify($ftp, $remotePath, $modified);
                    $readback[$fileName] = $rb;
                    if (!$rb) {
                        $errors[] = "{$fileName}: read-back mismatch (залитое содержимое не подтверждено чтением)";
                        $log->error('redirect_disable', "✗ {$fileName}: read-back mismatch — отключение НЕ подтверждено");
                    }
                    foreach ($appliedToFile as $a) {
                        $a['file'] = $fileName;
                        $appliedRules[] = $a;
                    }
                } catch (\Throwable $e) {
                    $errors[] = "{$fileName}: upload failed - " . $e->getMessage();
                    $log->error('redirect_disable', "✗ {$fileName}: " . $e->getMessage());
                }
            }
        }

        // ── REV3.2: отдельный проход для legacy index.php redirector (Mellstroy-тип) ──
        // Regex-правила выше покрывают .htaccess/config.php. Партнёрский редирект,
        // зашитый вызовом handleRequest($configRed) в index.php, ими не отключается.
        $idxFile = 'index.php';
        $idxRemote = $basePath === '' ? $idxFile : (rtrim($basePath, '/') . '/' . $idxFile);
        try {
            $idxContent = $ftp->getContent($idxRemote);
        } catch (\Throwable $e) {
            $idxContent = null; // index.php нет — не критично
        }
        if ($idxContent !== null) {
            $det = self::detectLegacyIndexHandleRequest($idxContent);
            if ($det['present']) { $detectedMechanisms[] = 'legacy_index_handle_request'; }
            if ($det['present'] && $det['already_disabled'] && $det['active_calls'] === 0) {
                $log->info('redirect_disable', 'index.php: legacy-редирект уже отключён (маркер присутствует) — идемпотентно.');
                $readback[$idxFile] = true;
            } elseif ($det['supported'] && $det['active_calls'] === 1) {
                $dis = self::disableLegacyIndexHandleRequest($idxContent);
                if (!empty($dis['ok']) && $dis['content'] !== $idxContent) {
                    $snapName = $this->safeSnapshotName($idxFile) . '.before-disable.txt';
                    $snapPath = $snapshotDir . '/' . $snapName;
                    if (@file_put_contents($snapPath, $idxContent) === false) {
                        $errors[] = "{$idxFile}: не удалось сохранить snapshot";
                    } else {
                        try {
                            $ftp->putContent($idxRemote, $dis['content'], null);
                            $snapshots[$idxFile] = $snapName;
                            $originalSha[$idxFile] = hash('sha256', $idxContent);
                            $rb = $this->readBackVerify($ftp, $idxRemote, $dis['content']);
                            $readback[$idxFile] = $rb;
                            if (!$rb) {
                                $errors[] = "{$idxFile}: read-back mismatch (legacy index disable не подтверждён)";
                                $log->error('redirect_disable', "✗ index.php: read-back mismatch — legacy disable НЕ подтверждён");
                            } else {
                                $log->ok('redirect_disable', 'index.php: legacy handleRequest($configRed) отключён и подтверждён read-back.');
                            }
                            $appliedRules[] = ['rule_id' => 'legacy_index_handle_request', 'mechanism' => 'legacy_index_handle_request',
                                               'description' => 'Нейтрализован вызов handleRequest($configRed) в index.php', 'count' => 1, 'file' => $idxFile];
                        } catch (\Throwable $e) {
                            $errors[] = "{$idxFile}: upload failed - " . $e->getMessage();
                        }
                    }
                }
            } elseif ($det['present'] && !$det['supported']) {
                // 0 или >1 совпадений / несовпадение сигнатуры — НЕ угадываем.
                $errors[] = "{$idxFile}: legacy redirector не поддержан для авто-отключения ({$det['reason']})";
                $log->warn('redirect_disable', "index.php: механизм редиректа не распознан однозначно ({$det['reason']}) — файл не изменялся.");
            }
        }

        $ftp->disconnect();

        if (empty($appliedRules)) {
            $log->info('redirect_disable',
                'Ни одно правило не подошло к файлам сайта. Возможно у этого шаблона редиректы устроены иначе. ' .
                'Это не блокирует pipeline.');
        } else {
            $log->ok('redirect_disable',
                'Редиректы отключены: ' . count($appliedRules) . ' правил, файлов изменено: ' . count($snapshots));
        }

        return [
            // ВНИМАНИЕ: 'ok' здесь = отсутствие ошибок применения/read-back. Финальный
            // postcondition (в т.ч. live-probe) вычисляет стадия redirect_disable (§4).
            'ok' => empty($errors),
            'applied_rules' => $appliedRules,
            'detected_mechanisms' => array_values(array_unique($detectedMechanisms)),
            'snapshots' => $snapshots,
            'readback' => $readback,
            'original_sha256' => $originalSha,
            'base_path' => $basePath,
            'errors' => $errors,
        ];
    }

    /** REV3.2 §6: exact FTP read-back — скачать remotePath и сверить sha256 с ожидаемым. */
    private function readBackVerify($ftp, string $remotePath, string $expectedContent): bool
    {
        try {
            $back = $ftp->getContent($remotePath);
        } catch (\Throwable $e) {
            return false;
        }
        return is_string($back) && hash('sha256', $back) === hash('sha256', $expectedContent);
    }

    /**
     * Включить редиректы обратно используя state из disable().
     *
     * @param array $stateFromArtifacts — то что disable() вернул и сохранил в artifacts.redirect_disabled_stage
     */
    public function enable(int $siteId, int $jobId, array $stateFromArtifacts, $log): array
    {
        $this->markerDiag = [];
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'errors' => ["Site #{$siteId} not found"], 'restored_rules' => []];
        }

        $appliedBefore = $stateFromArtifacts['applied_rules'] ?? [];
        if (empty($appliedBefore)) {
            // v18.1.8: defense-in-depth — даже если в state нет applied_rules,
            // всё равно сканируем файлы на наличие REFRESH-DISABLED маркеров.
            // Это защита от ситуации когда:
            //   - джоба прошла redirect_disable, потом был rollback,
            //   - rollback очистил redirect_disabled_stage из artifacts,
            //   - pipeline снова прошёл redirect_disable, но preg_replace не нашёл маркеры
            //     (они уже закомментированы в файлах) → applied_rules = []
            //   - redirect_enable увидел пустой list → молча ok → файл с префиксом → денег нет
            //
            // Поэтому если applied_rules пусто — пытаемся прогнать ВСЕ известные правила
            // и снять любые REFRESH-DISABLED маркеры которые найдём.
            $log->warn('redirect_enable',
                'В state нет applied_rules из disable. Прогоняю все известные правила blindly ' .
                'чтобы снять любые REFRESH-DISABLED маркеры (defense-in-depth).');
            $appliedBefore = [];
            foreach ($this->rules as $r) {
                $appliedBefore[] = [
                    'rule_id' => $r['id'],
                    'file' => $r['file'],
                    'description' => $r['description'] ?? '',
                ];
            }
        }

        $basePath = $stateFromArtifacts['base_path'] ?? null;
        if ($basePath === null) {
            // fallback на siteRoot
            $basePath = $this->resolveSiteRoot($site);
        }

        // FTP
        try {
            $ftp = $this->makeFtp($site);
            $ftp->connect();
        } catch (\Throwable $e) {
            return [
                'ok' => false,
                'errors' => ['FTP connect failed: ' . $e->getMessage()],
                'restored_rules' => [],
            ];
        }

        // Группируем по файлам
        $rulesByFile = [];
        foreach ($appliedBefore as $applied) {
            $ruleId = $applied['rule_id'] ?? '';
            $file = $applied['file'] ?? '';
            if ($ruleId === '' || $file === '') continue;

            // Находим правило в текущем конфиге
            $rule = $this->findRuleById($ruleId);
            if ($rule === null) {
                $log->warn('redirect_enable',
                    "правило {$ruleId} не найдено в конфиге (видимо удалено) — пропускаю");
                continue;
            }
            $rulesByFile[$file][] = $rule;
        }

        $restored = [];
        $errors = [];

        foreach ($rulesByFile as $fileName => $fileRules) {
            $remotePath = $basePath === '' ? $fileName : (rtrim($basePath, '/') . '/' . $fileName);

            try {
                $content = $ftp->getContent($remotePath);
            } catch (\Throwable $e) {
                $errors[] = "{$fileName}: не удалось скачать для enable - " . $e->getMessage();
                continue;
            }

            $modified = $content;
            $appliedToFile = [];

            foreach ($fileRules as $rule) {
                // ТЗ044 §9: enable канонизирует redirect_enabled=1 и снимает ВСЕ REFRESH-DISABLED.
                if (($rule['id'] ?? '') === 'php_redirect_enabled_var') {
                    $canon = $this->canonicalizeRedirectVar($modified, 1);
                    if (!empty($canon['found'])) {
                        $this->markerDiag[$fileName] = $canon['diag'];
                        if (!empty($canon['changed'])) {
                            $modified = $canon['content'];
                            $appliedToFile[] = ['rule_id' => $rule['id'], 'description' => $rule['description'], 'count' => 1];
                            $log->info('redirect_enable',
                                "✓ {$rule['id']} в {$fileName}: redirect_enabled=1, снято маркеров={$canon['markers_before']}");
                        } else {
                            $log->info('redirect_enable',
                                "= {$rule['id']} в {$fileName}: уже enabled (idempotent), маркеров={$canon['markers_after']}");
                        }
                        continue;
                    }
                }

                $newContent = @preg_replace($rule['enable_find'], $rule['enable_replace'], $modified, -1, $count);
                if ($newContent === null) {
                    $errors[] = "{$rule['id']}: regex error in enable_find";
                    continue;
                }
                if ($count === 0 || $newContent === $modified) {
                    // v18.1.14: основной regex не сматчил. ДО того как сдаться —
                    // пробуем fallback паттерны.
                    $fallbackResult = $this->tryFallbackEnableRegex($rule, $modified, $log);
                    if ($fallbackResult !== null) {
                        $newContent = $fallbackResult['content'];
                        $count = $fallbackResult['count'];
                        $log->info('redirect_enable',
                            "✓ {$rule['id']} в {$fileName}: основной regex не сработал, " .
                            "fallback восстановил {$count} строк (паттерн: {$fallbackResult['pattern']})");
                    } else {
                        // v18.1.15: ни основной regex, ни fallback не сработали.
                        // Включаем diagnostic dump — что на самом деле в файле?
                        // Это критично потому что без видимости реального содержимого
                        // мы не можем починить корневую причину.
                        $diagSnippet = $this->diagnosticFileSnippet($rule, $modified);
                        $log->warn('redirect_enable',
                            "правило {$rule['id']} в {$fileName}: enable_find НЕ нашёл маркеров " .
                            "(основной + fallback). DIAGNOSTIC: " . $diagSnippet);
                        continue;
                    }
                }

                $modified = $newContent;
                $appliedToFile[] = [
                    'rule_id' => $rule['id'],
                    'description' => $rule['description'],
                    'count' => $count,
                ];
                $log->info('redirect_enable',
                    "✓ {$rule['id']} в {$fileName}: восстановлено {$count} строк");
            }

            if (!empty($appliedToFile) && $modified !== $content) {
                try {
                    $ftp->putContent($remotePath, $modified, null);
                    foreach ($appliedToFile as $a) {
                        $a['file'] = $fileName;
                        $restored[] = $a;
                    }
                } catch (\Throwable $e) {
                    $errors[] = "{$fileName}: upload failed - " . $e->getMessage();
                    $log->error('redirect_enable', "✗ {$fileName}: " . $e->getMessage());
                }
            }
        }

        $ftp->disconnect();

        if (!empty($restored)) {
            $log->ok('redirect_enable',
                'Редиректы включены: ' . count($restored) . ' правил восстановлено');
        }

        return [
            'ok' => empty($errors),
            'restored_rules' => $restored,
            'errors' => $errors,
        ];
    }

    // ===================== HELPERS =====================

    private function loadRules(): array
    {
        $rulesFile = dirname(__DIR__, 2) . '/config/redirect_rules.php';
        if (!is_file($rulesFile)) {
            return [];
        }
        $rules = require $rulesFile;
        if (!is_array($rules)) return [];
        return $rules;
    }

    /** @var array ТЗ044 §9: диагностика нормализации маркеров по файлам. */
    public array $markerDiag = [];

    /**
     * ТЗ044 §9 — идемпотентная канонизация строки `$redirect_enabled = <d>;` с маркерами.
     *  target=0 (disable): ровно `$redirect_enabled = 0; // REFRESH-DISABLED` (дубли/stale сняты);
     *  target=1 (enable):  ровно `$redirect_enabled = 1;` (все REFRESH-DISABLED сняты).
     * Идемпотентно: повторный вызов не добавляет второй маркер и ничего не меняет.
     * @return array ['found'=>bool,'content'=>string,'changed'=>bool,'semantic_before'=>?int,
     *                'semantic_after'=>int,'markers_before'=>int,'markers_after'=>int,
     *                'normalized_duplicates'=>int,'diag'=>array]
     */
    public function canonicalizeRedirectVar(string $content, int $target): array
    {
        // Захватываем присваивание + весь «хвост» строки (комментарии/маркеры) до конца строки.
        $re = '~(\$redirect_enabled\s*=\s*)(\d+)(\s*;)([^\r\n]*)~';
        if (!preg_match($re, $content, $m, PREG_OFFSET_CAPTURE)) {
            return ['found' => false, 'content' => $content, 'changed' => false];
        }
        $before = (int)$m[2][0];
        $tail = (string)$m[4][0];
        $markersBefore = (int)preg_match_all('~REFRESH-DISABLED~', $tail);

        $target = $target === 0 ? 0 : 1;
        $canonTail = ($target === 0) ? ' // REFRESH-DISABLED' : '';
        $markersAfter = ($target === 0) ? 1 : 0;

        $newContent = preg_replace_callback($re, function ($mm) use ($target, $canonTail) {
            return $mm[1] . $target . $mm[3] . $canonTail;
        }, $content, 1);

        $diag = [
            'semantic_before' => $before, 'semantic_after' => $target,
            'markers_before' => $markersBefore, 'markers_after' => $markersAfter,
            'normalized_duplicates' => max(0, $markersBefore - $markersAfter),
        ];
        return [
            'found' => true, 'content' => $newContent, 'changed' => $newContent !== $content,
            'semantic_before' => $before, 'semantic_after' => $target,
            'markers_before' => $markersBefore, 'markers_after' => $markersAfter,
            'normalized_duplicates' => max(0, $markersBefore - $markersAfter), 'diag' => $diag,
        ];
    }

    /** Прочитать семантическое состояние redirect_enabled для read-back. @return array [?int value, int markerCount] */
    public function redirectVarState(string $content): array
    {
        if (!preg_match('~\$redirect_enabled\s*=\s*(\d+)\s*;([^\r\n]*)~', $content, $m)) return [null, 0];
        return [(int)$m[1], (int)preg_match_all('~REFRESH-DISABLED~', $m[2])];
    }

    /**
     * ТЗ044 §9 (BLOCKER 3) — реальный semantic read-back config.php после enable по FTP.
     * @return array ['ok'=>bool,'reason'=>?,'found'=>bool,'value'=>?int,'marker_count'=>?int]
     * ok=false — read-back недоступен (fail-closed на стороне вызывающего).
     */
    public function readBackConfigState(int $siteId, int $jobId, $log): array
    {
        $site = $this->loadSite($siteId);
        if ($site === null) return ['ok' => false, 'reason' => 'site_not_found'];
        try { $ftp = $this->makeFtp($site); $ftp->connect(); }
        catch (\Throwable $e) { return ['ok' => false, 'reason' => 'ftp_connect_failed: ' . $e->getMessage()]; }
        $basePath = $this->findWorkingBasePath($ftp, $this->resolveSiteRoot($site), $site, $log);
        if ($basePath === null) { $ftp->disconnect(); return ['ok' => false, 'reason' => 'base_path_not_found']; }
        $remote = $basePath === '' ? 'config.php' : (rtrim($basePath, '/') . '/config.php');
        try { $content = $ftp->getContent($remote); }
        catch (\Throwable $e) { $ftp->disconnect(); return ['ok' => false, 'reason' => 'config_read_failed: ' . $e->getMessage()]; }
        $ftp->disconnect();
        [$val, $mk] = $this->redirectVarState((string)$content);
        return ['ok' => true, 'found' => $val !== null, 'value' => $val, 'marker_count' => $mk];
    }

    private function findRuleById(string $id): ?array
    {
        foreach ($this->rules as $rule) {
            if (($rule['id'] ?? '') === $id) return $rule;
        }
        return null;
    }

    private function safeSnapshotName(string $fileName): string
    {
        $safe = ltrim($fileName, '/');
        $safe = str_replace(['.', '/', '\\'], '_', $safe);
        return $safe;
    }

    private function loadSite(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    private function resolveSiteRoot(array $site): string
    {
        $idx = trim((string)($site['fp_index_dir'] ?? ''));
        if ($idx !== '') return $idx;
        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        $dom = trim((string)($site['current_domain'] ?? ''));
        if ($owner !== '' && $dom !== '') {
            return "/var/www/{$owner}/data/www/{$dom}";
        }
        return '';
    }

    private function makeFtp(array $site): FtpService
    {
        $host = trim((string)($site['ftp_host'] ?? ''));
        $user = trim((string)($site['ftp_user'] ?? ''));
        $pass = '';
        if (!empty($site['ftp_pass_enc'])) {
            try {
                $pass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            } catch (\Throwable $e) {}
        }

        if ($host === '') {
            $serverId = (int)($site['fastpanel_server_id'] ?? 0);
            if ($serverId > 0) {
                $st = DB::pdo()->prepare("SELECT host FROM fastpanel_servers WHERE id=?");
                $st->execute([$serverId]);
                $rawHost = (string)$st->fetchColumn();
                $rawHost = preg_replace('~^https?://~i', '', $rawHost);
                $rawHost = preg_replace('~:\d+$~', '', $rawHost);
                $rawHost = preg_replace('~/.*$~', '', $rawHost);
                $host = trim($rawHost);
            }
        }

        if ($host === '' || $user === '' || $pass === '') {
            throw new \RuntimeException('FTP credentials missing for site #' . ($site['id'] ?? '?'));
        }

        return new FtpService($host, $user, $pass, ['passive' => true, 'timeout' => 30]);
    }

    /**
     * Multi-path probing — копия логики из SiteFileScanner.
     * Используем config.php как маяк для определения рабочего base_path.
     */
    private function findWorkingBasePath(
        FtpService $ftp,
        string $siteRoot,
        array $site,
        $log
    ): ?string {
        $candidates = $this->buildBasePathCandidates($siteRoot, $site);

        foreach ($candidates as $base) {
            $probe = $base === '' ? 'config.php' : (rtrim($base, '/') . '/config.php');
            try {
                $content = $ftp->getContent($probe);
                if ($content !== '' && stripos($content, '<?php') !== false) {
                    return $base;
                }
            } catch (\Throwable $e) {
                // try next
            }
        }

        return null;
    }

    private function buildBasePathCandidates(string $siteRoot, array $site): array
    {
        $out = [];

        if ($siteRoot !== '') $out[] = $siteRoot;
        $out[] = '';

        if (preg_match('~^/var/www/[^/]+(/.*)$~', $siteRoot, $m)) {
            $out[] = $m[1];
            $out[] = ltrim($m[1], '/');
        }

        if (preg_match('~/www/([^/]+/?)$~', $siteRoot, $m)) {
            $out[] = '/' . $m[1];
            $out[] = $m[1];
            $out[] = 'www/' . $m[1];
        }

        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        if ($owner !== '') {
            $out[] = "/home/{$owner}/data/www/" . trim((string)($site['current_domain'] ?? ''), '/');
        }

        $seen = [];
        $clean = [];
        foreach ($out as $p) {
            $p = trim($p);
            $key = ($p === '') ? '__empty__' : $p;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $clean[] = $p;
        }

        return $clean;
    }

    /**
     * v18.1.15: dump первых ~200 символов вокруг места где должен быть маркер,
     * чтобы оператор мог увидеть в логе ЧТО реально в файле.
     *
     * Возвращает hex+ascii dump в одну строку, готовый для лога.
     */
    private function diagnosticFileSnippet(array $rule, string $content): string
    {
        $ruleId = $rule['id'] ?? '';

        // По rule_id определяем anchor — паттерн который ловит общий "контур"
        // строки без требования наличия маркера (нам нужно показать что в файле,
        // даже если маркер отсутствует или искажён).
        $anchors = [
            'php_redirect_enabled_var'        => '~\$redirect_enabled\s*=\s*\d~',
            'htaccess_redirect_play'          => '~Redirect\s+30[12]\s+/\S+~mi',
            'php_index_handle_request'        => '~handleRequest\s*\(\s*\$\w+\s*\)~mi',
            'php_site_redirect_array_enabled' => "~'redirect'\s*=>\s*\[~",
        ];

        $anchor = $anchors[$ruleId] ?? null;
        if ($anchor === null) {
            return 'no anchor for rule_id=' . $ruleId;
        }

        if (!preg_match($anchor, $content, $m, PREG_OFFSET_CAPTURE)) {
            return "anchor '{$ruleId}' NOT FOUND in file — строки с целевой переменной нет вообще";
        }

        $offset = (int)$m[0][1];
        $start = max(0, $offset - 40);
        $len = 200;
        $snippet = substr($content, $start, $len);

        // Hex dump
        $hex = bin2hex($snippet);
        // Группируем по 32 char (16 bytes) для читаемости
        $hexGroups = str_split($hex, 32);

        // ASCII representation (printable only)
        $ascii = '';
        for ($i = 0; $i < strlen($snippet); $i++) {
            $c = $snippet[$i];
            $o = ord($c);
            if ($o >= 32 && $o < 127) {
                $ascii .= $c;
            } elseif ($o === 0x0D) {
                $ascii .= '\\r';
            } elseif ($o === 0x0A) {
                $ascii .= '\\n';
            } elseif ($o === 0x09) {
                $ascii .= '\\t';
            } else {
                $ascii .= '?';
            }
        }

        return sprintf(
            "offset=%d, ascii='%s', hex=%s",
            $offset,
            $ascii,
            implode(' ', $hexGroups)
        );
    }

    /**
     * v18.1.14: fallback enable regex'ы для случаев когда основной
     * enable_find из конфига не сматчил маркер.
     *
     * Симптом который ловим: после disable файл содержит маркер
     * REFRESH-DISABLED, но между disable и enable что-то изменило
     * формат строки (пробелы, line endings, кодировка, двойной маркер),
     * и основной regex не сматчивается.
     *
     * Стратегия: для каждого известного rule_id — пробуем максимально
     * гибкие regex'ы. Возвращаем первый сматчивший вариант.
     *
     * Возвращает: ['content' => string, 'count' => int, 'pattern' => string]
     *           или null если ни один fallback не сработал.
     */
    private function tryFallbackEnableRegex(array $rule, string $content, JobEventLogger $log): ?array
    {
        $ruleId = $rule['id'] ?? '';

        // Набор fallback'ов по rule_id
        $fallbacks = [];

        if ($ruleId === 'php_redirect_enabled_var') {
            // Целевая строка вида: $redirect_enabled = 0; // REFRESH-DISABLED
            // Варианты которые ловим: разные пробелы, табы, типы комментариев (// или /* */),
            // двойной маркер, маркер в любом месте после ;.
            $fallbacks = [
                // Максимально гибкий — \h это горизонтальный whitespace (пробелы+табы)
                // .* до конца строки чтобы поймать всё после ; включая двойные маркеры
                ['~(\$redirect_enabled\s*=\s*)0(\s*;)[^\r\n]*REFRESH-DISABLED[^\r\n]*~',
                 '${1}1${2}', 'flexible_eol'],
                // Маркер /* REFRESH-DISABLED */ (block comment)
                ['~(\$redirect_enabled\s*=\s*)0(\s*;)\s*/\*\s*REFRESH-DISABLED\s*\*/~',
                 '${1}1${2}', 'block_comment'],
                // Самый широкий — игнорирует ВСЕ символы между 0; и REFRESH-DISABLED, в пределах строки
                ['~(\$redirect_enabled\s*=\s*)0(\s*;)[^\n]{0,80}REFRESH-DISABLED~',
                 '${1}1${2}', 'wide_match'],
            ];
        } elseif ($ruleId === 'htaccess_redirect_play') {
            $fallbacks = [
                // \h гибкий пробел, маркер в любой форме
                ['~^([\t ]*)#\s*REFRESH-DISABLED[^\r\n]*?(Redirect\s+30[12]\s+/\S+\s+\S+)[\t ]*$~mi',
                 '${1}${2}', 'flexible_marker'],
            ];
        } elseif ($ruleId === 'php_index_handle_request') {
            $fallbacks = [
                ['~^([\t ]*)//\s*REFRESH-DISABLED[^\r\n]*?(handleRequest\s*\(\s*\$\w+\s*\)\s*;)[\t ]*$~mi',
                 '${1}${2}', 'flexible_marker'],
            ];
        } elseif ($ruleId === 'php_site_redirect_array_enabled') {
            $fallbacks = [
                // Маркер /* REFRESH-DISABLED */ — основной regex уже это ловит, но более гибко
                ["~('redirect'\s*=>\s*\[[^\]]*?'enabled'\s*=>\s*)0(\s*,)[^\r\n]*REFRESH-DISABLED[^\r\n]*~s",
                 '${1}1${2}', 'flexible_eol'],
            ];
        }

        if (empty($fallbacks)) {
            return null;
        }

        foreach ($fallbacks as [$pattern, $replacement, $patternName]) {
            $newContent = @preg_replace($pattern, $replacement, $content, -1, $count);
            if ($newContent === null) continue; // regex error — пропускаем
            if ($count > 0 && $newContent !== $content) {
                return [
                    'content' => $newContent,
                    'count' => $count,
                    'pattern' => $patternName,
                ];
            }
        }

        return null;
    }

    // ==================================================================
    // REV3.2: поддержка legacy index.php redirector (Mellstroy-тип) +
    // классификация host редиректа. Чистые статические методы — тестируемы
    // без FTP/HTTP. Логика редиректов остаётся в этом сервисе (не в оркестраторе).
    // ==================================================================

    /** Маркер отключённого legacy-вызова (для идемпотентности и enable-детекта). */
    public const LEGACY_INDEX_MARKER = 'REFRESH_DISABLED_HANDLEREQUEST';

    /**
     * Детект legacy index.php redirector вида:
     *   $configRed["new_domain"]=...; $configRed["second_domain"]=...; ... handleRequest($configRed);
     * Возвращает: present, active_calls, already_disabled, supported, reason.
     * supported=true ТОЛЬКО когда механизм есть и активных вызовов ровно 1.
     */
    public static function detectLegacyIndexHandleRequest(string $content): array
    {
        $hasConfigRed = (bool)preg_match('/\$configRed\s*\[\s*[\'"]new_domain[\'"]\s*\]/', $content);
        $alreadyDisabled = strpos($content, self::LEGACY_INDEX_MARKER) !== false;
        // активные (не закомментированные нашим маркером) вызовы handleRequest($configRed);
        $activeCalls = preg_match_all('/handleRequest\s*\(\s*\$configRed\s*\)\s*;/', $content, $m);
        // если наш маркер присутствует — соответствующий вызов уже внутри блок-комментария,
        // но preg_match_all всё равно найдёт текст внутри комментария. Скорректируем:
        if ($alreadyDisabled) {
            $disabledCalls = preg_match_all('/' . self::LEGACY_INDEX_MARKER . '\s+handleRequest\s*\(\s*\$configRed\s*\)\s*;/', $content, $mm);
            $activeCalls = max(0, $activeCalls - $disabledCalls);
        }

        if (!$hasConfigRed && $activeCalls === 0) {
            return ['present' => false, 'active_calls' => 0, 'already_disabled' => $alreadyDisabled,
                    'supported' => false, 'reason' => 'legacy_index_mechanism_absent'];
        }
        if ($alreadyDisabled && $activeCalls === 0) {
            return ['present' => true, 'active_calls' => 0, 'already_disabled' => true,
                    'supported' => true, 'reason' => 'already_disabled'];
        }
        if ($activeCalls === 1 && $hasConfigRed) {
            return ['present' => true, 'active_calls' => 1, 'already_disabled' => $alreadyDisabled,
                    'supported' => true, 'reason' => 'legacy_index_handle_request'];
        }
        if ($activeCalls > 1) {
            return ['present' => true, 'active_calls' => $activeCalls, 'already_disabled' => $alreadyDisabled,
                    'supported' => false, 'reason' => 'unsupported_multiple_handle_request'];
        }
        // handleRequest без $configRed-сигнатуры — не угадываем
        return ['present' => (bool)$activeCalls, 'active_calls' => $activeCalls, 'already_disabled' => $alreadyDisabled,
                'supported' => false, 'reason' => 'unsupported_signature_mismatch'];
    }

    /**
     * Отключить legacy index redirector: нейтрализовать ЕДИНСТВЕННЫЙ вызов
     * handleRequest($configRed); обернув его в блок-комментарий с маркером.
     * Не трогает функцию handleRequest, $configRed и остальной index.php.
     * Возвращает ['ok'=>bool,'content'=>string,'reason'=>string].
     */
    public static function disableLegacyIndexHandleRequest(string $content): array
    {
        $det = self::detectLegacyIndexHandleRequest($content);
        if ($det['already_disabled'] && $det['active_calls'] === 0) {
            return ['ok' => true, 'content' => $content, 'reason' => 'already_disabled'];
        }
        if (!$det['supported']) {
            return ['ok' => false, 'content' => $content, 'reason' => $det['reason']];
        }
        $count = 0;
        $new = preg_replace_callback(
            '/handleRequest\s*\(\s*\$configRed\s*\)\s*;/',
            function ($mm) { return '/*' . self::LEGACY_INDEX_MARKER . ' ' . $mm[0] . '*/'; },
            $content, 1, $count
        );
        if ($new === null || $count !== 1) {
            return ['ok' => false, 'content' => $content, 'reason' => 'disable_replace_failed'];
        }
        return ['ok' => true, 'content' => $new, 'reason' => 'legacy_index_handle_request'];
    }

    /**
     * Нормализация hostname: lowercase, без завершающей точки, без www., без порта.
     */
    public static function normalizeHost(string $value): string
    {
        $value = trim($value);
        if ($value === '') return '';
        if (strpos($value, '://') !== false) {
            $h = parse_url($value, PHP_URL_HOST);
        } else {
            $h = parse_url('http://' . $value, PHP_URL_HOST);
        }
        $h = is_string($h) ? $h : '';
        $h = strtolower(rtrim($h, '.'));
        if (strpos($h, 'www.') === 0) $h = substr($h, 4);
        return $h;
    }

    /**
     * Извлечь host назначения редиректа из ответа (Location-заголовок, meta refresh,
     * немедленный JS-редирект). Возвращает нормализованный host или '' если редиректа нет.
     * Разбор ТОЛЬКО через parse_url (не strpos по подстроке).
     */
    public static function extractRedirectTargetHost(string $html, ?string $locationHeader = null): string
    {
        // 1) HTTP Location
        if ($locationHeader !== null && trim($locationHeader) !== '') {
            $h = self::normalizeHost(trim($locationHeader));
            if ($h !== '') return $h;
        }
        // 2) meta refresh: <meta http-equiv="refresh" content="0;url=https://...">
        if (preg_match('/<meta[^>]+http-equiv\s*=\s*["\']?refresh["\']?[^>]*content\s*=\s*["\']([^"\']+)["\']/i', $html, $m)) {
            if (preg_match('/url\s*=\s*(\S+)/i', $m[1], $u)) {
                $h = self::normalizeHost(trim($u[1], '\'"'));
                if ($h !== '') return $h;
            }
        }
        // 3) немедленный JS редирект: location.href=... / window.location=...
        if (preg_match('/(?:window\.)?location(?:\.href)?\s*=\s*["\']([^"\']+)["\']/i', $html, $j)) {
            $h = self::normalizeHost($j[1]);
            if ($h !== '') return $h;
        }
        return '';
    }

    /**
     * Host входит в allowlist собственных редиректоров? Точное сравнение
     * нормализованных host (host или суффикс .host), без strpos по всей строке.
     * $ownDomains — из wm.own_redirect_domains (второй hardcoded-список НЕ заводим).
     */
    public static function hostInOwnRedirectAllowlist(string $host, array $ownDomains): bool
    {
        $host = self::normalizeHost($host);
        if ($host === '') return false;
        foreach ($ownDomains as $d) {
            $d = self::normalizeHost((string)$d);
            if ($d === '') continue;
            if ($host === $d || substr($host, -(strlen($d) + 1)) === '.' . $d) return true;
        }
        return false;
    }

    /**
     * REV3.2 §6: СИММЕТРИЧНОЕ восстановление редиректа — заливаем сохранённый на disable()
     * snapshot БАЙТ-В-БАЙТ (не регенерируем PHP regex'ом) и подтверждаем read-back'ом:
     * sha256(remote) == sha256(snapshot) == original_sha256. Иначе файл не считается восстановленным.
     *
     * @param array $state  redirect_disabled_stage: snapshots[file=>snapfile], original_sha256[file=>sha], base_path
     * @return array ['ok'=>bool,'restored'=>[file=>true],'errors'=>[],'verified'=>[file=>sha]]
     */
    public function restoreSnapshotsExact(int $siteId, int $jobId, array $state, $log): array
    {
        $snapshots = (array)($state['snapshots'] ?? []);
        $originalSha = (array)($state['original_sha256'] ?? []);
        $basePath = $state['base_path'] ?? null;
        if (empty($snapshots)) {
            return ['ok' => true, 'restored' => [], 'errors' => [], 'verified' => [], 'reason' => 'no_snapshots'];
        }
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'restored' => [], 'errors' => ["Site #{$siteId} not found"], 'verified' => []];
        }
        if ($basePath === null) { $basePath = $this->resolveSiteRoot($site); }

        try { $ftp = $this->makeFtp($site); $ftp->connect(); }
        catch (\Throwable $e) { return ['ok' => false, 'restored' => [], 'errors' => ['FTP connect failed: ' . $e->getMessage()], 'verified' => []]; }

        $snapshotDir = $this->snapshotsBaseDir . '/job_' . $jobId;
        $restored = []; $errors = []; $verified = [];

        foreach ($snapshots as $fileName => $snapName) {
            $snapPath = $snapshotDir . '/' . $snapName;
            $orig = @file_get_contents($snapPath);
            if ($orig === false) {
                $errors[] = "{$fileName}: snapshot '{$snapName}' недоступен для восстановления";
                continue;
            }
            // Если знаем original_sha256 — снапшот обязан ему соответствовать.
            if (isset($originalSha[$fileName]) && hash('sha256', $orig) !== $originalSha[$fileName]) {
                $errors[] = "{$fileName}: snapshot sha256 не совпадает с сохранённым original_sha256";
                continue;
            }
            $remotePath = ($basePath === '' || $basePath === null) ? $fileName : (rtrim((string)$basePath, '/') . '/' . $fileName);
            try {
                $ftp->putContent($remotePath, $orig, null);
            } catch (\Throwable $e) {
                $errors[] = "{$fileName}: upload restore failed - " . $e->getMessage();
                continue;
            }
            if (!$this->readBackVerify($ftp, $remotePath, $orig)) {
                $errors[] = "{$fileName}: read-back после восстановления не совпал (byte-for-byte не подтверждён)";
                continue;
            }
            $restored[$fileName] = true;
            $verified[$fileName] = hash('sha256', $orig);
            if ($log) { $log->ok('redirect_enable', "✓ {$fileName}: восстановлен из snapshot byte-for-byte (read-back подтверждён)."); }
        }
        $ftp->disconnect();

        return [
            'ok' => empty($errors) && count($restored) === count($snapshots),
            'restored' => $restored,
            'verified' => $verified,
            'errors' => $errors,
            'reason' => empty($errors) ? 'restored_exact' : 'restore_incomplete',
        ];
    }
}
