# REPORT — refresh-panel CUMULATIVE HOTPATCH REV3.2 (2026-08-16)

Кумулятивный production-патч поверх установленного **REV3.1**. Закрывает вторую волну боевых дефектов
(диагностика закрытого robots, ложный успех redirect_disable, бесконечный preflight update_classes / job #227)
строго по ТЗ REV3.2, объём **1+4**. Архитектура пайплайна не переписывалась; изменены только нарушенные
инварианты. Миграций/таблиц нет — новое состояние хранится в существующих job artifacts.

## Изменённые файлы (baseline REV3.1 → REV3.2)

| Файл | REV3.1 baseline SHA256 | REV3.2 SHA256 | diff |
|---|---|---|---|
| app/Services/RefreshOrchestrator.php | 4409b16a… | d81e9fcccbb85ef3e653501b6f7ec33b3d2cac09e00b86a131d81ec620d5f772 | +543 −38 |
| app/Services/RedirectToggler.php | 1cb4d214… | 066931e6b0575d3c95730b776326acb2796fef0ed01af22580ebecaae1dedef0 | +281 −0 |
| app/Services/SiteVerifier.php | 1ef18e2c… | 403346bcde3c900a4742efe78ca61f21a6f99462b1b04405af5d1d84643865fb | +12 −2 |
| app/Services/DiagnosticCatalog.php | 096b1082… | 0d33c0a0fe702fc7ea5ab55993aec086b343468322ba03661afedd93bf763bc9 | +78 −0 |
| bin/repair_stuck_job.php (новый) | — | 0019c08f3a8039cb64673e03792158743c38d2e269825e856bacbc36d46b504d | new |

## Что сделано (по разделам ТЗ)

- **§2/§4/§5 redirect_disable — реальный postcondition.** `applied_rules=[]` больше не считается ни ошибкой,
  ни доказательством отключения: правду даёт live-probe (FOLLOWLOCATION=false, обычный UA, host через
  `parse_url`). `applied_rules=[]` + живой редирект на own-redirector ⇒ `ok=false`. Артефакт §5:
  `detected_mechanisms/applied_rules/readback_verified/live_verified/external_redirect_after`.
- **§3 legacy index.php redirector.** Распознаётся тип `legacy_index_handle_request`; безопасно
  нейтрализуется РОВНО один вызов `handleRequest($configRed);` блок-комментарием с маркером
  (функция/$configRed/шаблон сохранены). 0/>1 совпадений или иная сигнатура → `unsupported` (не угадываем).
  §3.2 snapshot + exact FTP read-back (`sha256`).
- **§6 redirect_enable — симметрия.** Восстановление из snapshot байт-в-байт (не регенерация PHP),
  `sha256(restored)==original_sha256`; иначе `awaiting_user` (редирект остаётся выключен, не продолжаем).
- **§7–§9 preflight update_classes — structured result.** `checkSiteResponsiveToNewDomain` заменён на
  `preflightUpdateClasses`+`classifyPreflightResult` (ok/reason_code/http_code/location/external_host/
  is_own_redirect/retryable/details). literal newDomain — ОДИН из сигналов (плюс alias/FTP evidence),
  «HTTP 200 без строки домена» больше НЕ равно default_vhost.
- **§8/§10/§11/§12 матрица + бюджет + recovery.** own-redirect → `own_redirect_active` (детерминированно,
  НЕ default_vhost, НЕ бесконечный polling) → ОДИН controlled `redirect_disable` + live-verify
  (`uc_redirect_repair_attempted`) → retry; повтор неэффективен → `awaiting_user`/`redirect_disable_ineffective`.
  transient (dns/tls/conn/502-4) → retry с бюджетом `uc_preflight_attempts` ≤10 / 15 мин → затем awaiting.
- **§13/§14/§15.** `uc_execution_attempts++` только атомарным CAS-резервированием прямо перед реальным
  mutating-вызовом; at-most-once (повторный tick при state=started → 0 строк). «дёргаю» больше не пишется
  до preflight — только событие `uc.detected_update_classes`; реальный вызов → `uc.execution_started`.
- **§16/§17 robots + коды.** Закрытый robots нового домена → `new_domain_robots_closed` (source=site,
  human_action=required), не `unknown_stage_error`; не-ретраибелен. Новые коды: `own_redirect_active_during_refresh`,
  `redirect_disable_ineffective`, `update_classes_preflight_exhausted`, `update_classes_external_redirect`.
- **§18.** Легаси-verifier `update_classes` НЕ тронут — 4 метода (`hasUpdateClassesCompletionMarker`,
  `reserveUpdateClassesExecution`, `callUpdateClassesUrl`, `doUpdateClassesCurl`) байт-идентичны baseline.
- **§21.** `bin/repair_stuck_job.php --job=227 --reason=…`: только застрявшая `update_classes_call` с
  `uc_execution_attempts=0`, трогает лишь одну job, сбрасывает preflight-бюджет, requeue + audit-событие; без raw SQL.

## §27 DoD — сценарии (все PASS)

| Сценарий | Результат |
|---|---|
| REV3.1 .htaccess redirect | PASS без изменения поведения |
| REV3.1 config.php redirect | PASS |
| Сайт без redirect | PASS (no_active_redirect) |
| Mellstroy legacy index.php redirect | PASS (detect/disable/read-back) |
| Disable exact read-back | PASS |
| Disable live verification | PASS (external own-redirect ⇒ ok=false) |
| Enable exact restoration (sha==original) | PASS |
| own redirect в preflight | own_redirect_active (не default_vhost, не цикл) |
| unknown external redirect | awaiting_user / update_classes_external_redirect |
| DNS/TLS/conn/5xx transient | bounded retry ≤10/15мин → awaiting exhausted |
| robots normal | PASS |
| robots closed | new_domain_robots_closed (source=site) |
| legacy update_classes | verifier не тронут (§18, byte-identical) |
| repeated worker ticks | нет повторной mutation (at-most-once) |
| existing job #227 recovery | PASS (own_redirect→recover→proceed; ineffective→awaiting) |

## Тесты

`tests/run_all.sh`: **TOTAL PASS=102, FAIL=0** — 28 legacy-index + 16 redirect-disable eval +
19 preflight classify + 12 preflight budget + 5 restore round-trip + 8 diagnostic codes + 14 DB
(#227 recovery / at-most-once / repair CLI). PHP lint всех изменённых файлов — OK. Миграции — нет.
