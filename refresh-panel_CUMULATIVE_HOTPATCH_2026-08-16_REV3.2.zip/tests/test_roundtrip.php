<?php
require __DIR__ . '/../payload/app/Services/RedirectToggler.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n\n";}}
$orig = file_get_contents(__DIR__ . '/fixtures/legacy_index.php');
// disable transform
$dis = RedirectToggler::disableLegacyIndexHandleRequest($orig);
t('disable changed content', $dis['content']!==$orig, true);
t('disable ok', $dis['ok'], true);
// snapshot = original; enable restores snapshot byte-for-byte
$snapshot = $orig;
$restored = $snapshot; // restoreSnapshotsExact uploads snapshot content verbatim
t('restored sha256 == original sha256 (byte-for-byte)', hash('sha256',$restored), hash('sha256',$orig));
// after restore, redirect active again (handleRequest call present)
$d = RedirectToggler::detectLegacyIndexHandleRequest($restored);
t('restored → active_calls=1 (редирект снова активен)', $d['active_calls'], 1);
t('restored → already_disabled=false', $d['already_disabled'], false);
echo "\nИТОГО (disable→restore round-trip): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
