<?php
/**
 * REV3.2 §14/§20/§21 — сценарии с БД: end-to-end recovery-цепочка на реальном состоянии job #227,
 * at-most-once резервирование, и безопасный repair CLI. Требует RP_DB_SOCKET/USER/PASS/NAME (тест-БД).
 */
require __DIR__ . '/../payload/app/Services/RedirectToggler.php';
require __DIR__ . '/../payload/app/Services/RefreshOrchestrator.php';

$PASS = 0; $FAIL = 0;
function t($n, $g, $e) { global $PASS, $FAIL; if ($g === $e) { $PASS++; echo "  [OK]   $n\n"; } else { $FAIL++; echo "  [FAIL] $n exp=" . var_export($e, true) . " got=" . var_export($g, true) . "\n"; } }
function tb($n, $c) { t($n, (bool)$c, true); }

$sock = getenv('RP_DB_SOCKET'); $user = getenv('RP_DB_USER') ?: 'root'; $pass = getenv('RP_DB_PASS') ?: '';
$db   = getenv('RP_DB_NAME');
if (!$sock || !$db) { fwrite(STDERR, "REQUIRED-GATE FAIL: RP_DB_SOCKET/RP_DB_NAME не заданы\n"); exit(2); }
$pdo = new PDO("mysql:unix_socket={$sock};dbname={$db};charset=utf8mb4", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

$pdo->exec("DROP TABLE IF EXISTS refresh_jobs");
$pdo->exec("CREATE TABLE refresh_jobs(id INT PRIMARY KEY, site_id INT, stage VARCHAR(64), stage_status VARCHAR(32),
    stage_error TEXT NULL, stage_started_at DATETIME NULL, stage_finished_at DATETIME NULL, next_run_at DATETIME NULL,
    uc_execution_state VARCHAR(20) NULL, uc_execution_id VARCHAR(64) NULL, uc_execution_started_at DATETIME NULL,
    uc_execution_attempts INT DEFAULT 0, artifacts_json LONGTEXT NULL, updated_at DATETIME NULL)");

$own = ['dealredirectfast.com', 'flowtargetredirect.com', 'partners7k-promo.com'];
$C = 'RefreshOrchestrator';

// ── §20: РЕАЛЬНОЕ состояние #227 — застряла на preflight, собственный редирект активен ──
// Реальные факты из дампа: site 66, mellstroy80.casino, own-redirect на partners7k-promo.com.
$art227 = json_encode(['update_classes_stage' => ['action' => 'preflight_retry', 'preflight_attempts' => 7,
    'preflight_started_at_unix' => time() - 3000, 'redirect_repair_attempted' => false,
    'preflight_reason' => 'newDomain НЕ найден в HTML (partners7k-promo.com)']]);
$pdo->prepare("INSERT INTO refresh_jobs(id,site_id,stage,stage_status,uc_execution_attempts,artifacts_json)
               VALUES(227,66,'update_classes_call','pending',0,?)")->execute([$art227]);

// Тик 1: preflight видит own-redirect → decidePreflightAction → recover (первый и единственный ремонт).
$probeOwn = ['reachable' => true, 'http_code' => 200, 'redirect_host' => 'partners7k-promo.com'];
$cls1 = $C::classifyPreflightResult($probeOwn, 'mellstroy80.casino', $own);
t('#227 preflight классифицирован own_redirect_active', $cls1['reason_code'], 'own_redirect_active');
$budget1 = ['preflight_attempts' => 7, 'preflight_started_at_unix' => time() - 3000,
    'redirect_repair_attempted' => false, 'now' => time(), 'max_attempts' => 10, 'max_age_sec' => 900];
$d1 = $C::decidePreflightAction($cls1, $budget1);
t('#227 решение = recover (одноразовый ремонт)', $d1['action'], 'recover');

// Симулируем эффект ремонта: legacy handleRequest отключён → сайт больше НЕ редиректит.
// (в проде это делает recoverByRedirectDisable через RedirectToggler::disable + live-verify)
$pdo->prepare("UPDATE refresh_jobs SET artifacts_json=JSON_MERGE_PATCH(artifacts_json,?) WHERE id=227")
    ->execute([json_encode(['update_classes_stage' => ['redirect_repair_attempted' => true]])]);

// Тик 2: после ремонта редиректа нет, newDomain виден → proceed (реальный вызов дальше).
$probeClean = ['reachable' => true, 'http_code' => 200, 'redirect_host' => '', 'new_domain_in_html' => true];
$cls2 = $C::classifyPreflightResult($probeClean, 'mellstroy80.casino', $own);
$d2 = $C::decidePreflightAction($cls2, ['now' => time(), 'redirect_repair_attempted' => true]);
t('#227 после ремонта preflight ok', $cls2['ok'], true);
t('#227 после ремонта решение = proceed', $d2['action'], 'proceed');

// Контр-сценарий: ремонт НЕ помог (редирект всё ещё активен, ремонт уже пробовали) → awaiting, не цикл.
$d3 = $C::decidePreflightAction($cls1, ['now' => time(), 'redirect_repair_attempted' => true]);
t('#227 ремонт неэффективен → awaiting (не бесконечный цикл)', $d3['action'], 'awaiting');
t('#227 → redirect_disable_ineffective', $d3['awaiting_technical_code'], 'redirect_disable_ineffective');

// ── §14: at-most-once резервирование (реальный CAS-SQL) ──
$pdo->prepare("UPDATE refresh_jobs SET uc_execution_state=NULL, uc_execution_attempts=0 WHERE id=227")->execute();
$RES = "UPDATE refresh_jobs SET uc_execution_state='started', uc_execution_id=?, uc_execution_started_at=NOW(),
        uc_execution_attempts=COALESCE(uc_execution_attempts,0)+1, updated_at=NOW()
        WHERE id=? AND stage='update_classes_call' AND stage_status IN ('pending','running','awaiting_user','ok')
        AND (uc_execution_state IS NULL OR uc_execution_state='' OR uc_execution_state='not_started')";
$s = $pdo->prepare($RES); $s->execute(['EX-1', 227]); $r1 = $s->rowCount();
$s = $pdo->prepare($RES); $s->execute(['EX-2', 227]); $r2 = $s->rowCount();
$att = (int)$pdo->query("SELECT uc_execution_attempts FROM refresh_jobs WHERE id=227")->fetchColumn();
t('§14 tick1 резервирует', $r1, 1);
t('§14 tick2 НЕ резервирует повторно', $r2, 0);
t('§14 attempts=1 (at-most-once, не 2)', $att, 1);

// ── §21: repair CLI — сбрасывает бюджет и requeue, только для застрявшей attempts=0 ──
$pdo->prepare("UPDATE refresh_jobs SET uc_execution_state=NULL, uc_execution_attempts=0, stage_status='pending',
    artifacts_json=? WHERE id=227")->execute([$art227]);
$pdo->exec("DROP TABLE IF EXISTS refresh_job_events");
$pdo->exec("CREATE TABLE refresh_job_events(id INT AUTO_INCREMENT PRIMARY KEY, job_id INT, stage VARCHAR(64), level VARCHAR(16), message TEXT, created_at DATETIME)");
$appTree = getenv('RP_APP_TREE') ?: dirname(__DIR__);
$cliPath = $appTree . '/bin/repair_stuck_job.php';
if (!is_file($cliPath)) { $cliPath = __DIR__ . '/../payload/bin/repair_stuck_job.php'; }
$cli = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($cliPath)
     . ' --job=227 --reason=redirect-disable-retry';
$env = "RP_DB_SOCKET={$sock} RP_DB_USER={$user} RP_DB_PASS={$pass} RP_DB_NAME={$db} ";
exec($env . $cli . ' 2>&1', $out, $rc);
t('§21 repair CLI exit=0', $rc, 0);
$after = $pdo->query("SELECT stage_status, JSON_UNQUOTE(JSON_EXTRACT(artifacts_json,'$.update_classes_stage.action')) act,
    JSON_EXTRACT(artifacts_json,'$.update_classes_stage.preflight_attempts') pa FROM refresh_jobs WHERE id=227")->fetch(PDO::FETCH_ASSOC);
t('§21 requeued → pending', $after['stage_status'], 'pending');
t('§21 action=repair_requeued', $after['act'], 'repair_requeued');
t('§21 preflight_attempts сброшен в 0', (int)$after['pa'], 0);
t('§21 audit-событие записано', (int)$pdo->query("SELECT COUNT(*) FROM refresh_job_events WHERE job_id=227")->fetchColumn(), 1);

echo "\n============================================================\n";
echo "ИТОГО (DB scenarios §14/§20/§21): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL === 0 ? 0 : 1);
