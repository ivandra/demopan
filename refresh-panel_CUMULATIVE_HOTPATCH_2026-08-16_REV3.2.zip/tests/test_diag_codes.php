<?php
require __DIR__ . '/../payload/app/Services/DiagnosticCatalog.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$C='DiagnosticCatalog';
// robots-closed
$d=$C::classify('verify_replacement','error','verify_replacement: new_robots — Новый домен отдаёт `Disallow: /` без `Allow:` — robots закрыт');
t('robots-closed → code', $d['technical_code'],'new_domain_robots_closed');
t('robots-closed source=site', $d['source'],'site');
// own_redirect_active
$d=$C::classify('update_classes_call','warning','update_classes_call: own_redirect_active (redirect→partners7k-promo.com)');
t('own_redirect → code', $d['technical_code'],'own_redirect_active_during_refresh');
// redirect_disable_ineffective
$d=$C::classify('update_classes_call','error','redirect_disable_ineffective после ремонта');
t('ineffective → code', $d['technical_code'],'redirect_disable_ineffective');
t('ineffective human_action=required', $d['human_action'],'required');
// preflight exhausted
$d=$C::classify('update_classes_call','error','update_classes_preflight_exhausted (dns_not_resolving)');
t('exhausted → code', $d['technical_code'],'update_classes_preflight_exhausted');
// external redirect
$d=$C::classify('update_classes_call','error','update_classes_external_redirect → evil.example.com');
t('external → code', $d['technical_code'],'update_classes_external_redirect');
// none of them → NOT these codes (regression: DNS still classified as dns_not_resolving)
$d=$C::classify('ssl_le_polling','info','getaddrinfo failed name or service not known');
t('DNS regression → dns_not_resolving', $d['technical_code'],'dns_not_resolving');
echo "\nИТОГО (diagnostic codes §17): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
