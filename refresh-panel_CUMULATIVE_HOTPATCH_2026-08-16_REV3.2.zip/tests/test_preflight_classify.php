<?php
require __DIR__ . '/../payload/app/Services/RedirectToggler.php';
require __DIR__ . '/../payload/app/Services/RefreshOrchestrator.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$own=['dealredirectfast.com','flowtargetredirect.com','partners7k-promo.com'];
$C='RefreshOrchestrator';$nd='mellstroy80.casino';

// #227: own redirect active → deterministic, own_redirect_active (НЕ default_vhost, НЕ retryable)
$r=$C::classifyPreflightResult(['reachable'=>true,'http_code'=>200,'redirect_host'=>'partners7k-promo.com'],$nd,$own);
t('own-redirect → reason_code', $r['reason_code'],'own_redirect_active');
t('own-redirect → retryable=false (не бесконечно)', $r['retryable'],false);
t('own-redirect → is_own_redirect', $r['is_own_redirect'],true);
t('own-redirect → external_host', $r['external_host'],'partners7k-promo.com');
t('own-redirect → ok=false', $r['ok'],false);

// unknown external redirect → deterministic
$r=$C::classifyPreflightResult(['reachable'=>true,'http_code'=>302,'redirect_host'=>'evil.example.com'],$nd,$own);
t('unknown external → reason', $r['reason_code'],'external_redirect_unknown');
t('unknown external → retryable=false', $r['retryable'],false);
t('unknown external → is_own=false', $r['is_own_redirect'],false);

// DNS not resolving → transient retryable
$r=$C::classifyPreflightResult(['reachable'=>false,'http_code'=>0,'curl_error'=>'Could not resolve host: mellstroy80.casino'],$nd,$own);
t('dns → reason', $r['reason_code'],'dns_not_resolving');
t('dns → retryable=true', $r['retryable'],true);

// TLS transient
$r=$C::classifyPreflightResult(['reachable'=>false,'http_code'=>0,'curl_error'=>'SSL certificate problem'],$nd,$own);
t('tls → reason', $r['reason_code'],'temporary_tls_failure');
t('tls → retryable', $r['retryable'],true);

// 503 transient
$r=$C::classifyPreflightResult(['reachable'=>true,'http_code'=>503,'redirect_host'=>''],$nd,$own);
t('503 → reason', $r['reason_code'],'http_502_503_504');
t('503 → retryable', $r['retryable'],true);

// site responsive (marker present) → ok
$r=$C::classifyPreflightResult(['reachable'=>true,'http_code'=>200,'redirect_host'=>'','new_domain_in_html'=>true],$nd,$own);
t('marker present → ok=true', $r['ok'],true);
t('marker present → reason', $r['reason_code'],'site_responsive');

// §9: HTTP 200 без маркера, но с trusted evidence → ok
$r=$C::classifyPreflightResult(['reachable'=>true,'http_code'=>200,'redirect_host'=>'','trusted_site_evidence'=>true],$nd,$own);
t('trusted evidence (без literal) → ok=true', $r['ok'],true);

// §9: HTTP 200 без маркера и без доказательств → НЕ default_vhost автоматически, deterministic unsupported
$r=$C::classifyPreflightResult(['reachable'=>true,'http_code'=>200,'redirect_host'=>''],$nd,$own);
t('200 без маркера/доказательств → unsupported (не default_vhost)', $r['reason_code'],'unsupported_site_response');
t('200 без маркера → retryable=false', $r['retryable'],false);

echo "\n============================================================\n";
echo "ИТОГО (classifyPreflightResult): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
