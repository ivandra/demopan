#!/usr/bin/env bash
# REV3.2 unified runner: pure-logic suites + DB scenarios (#227 recovery, at-most-once, repair CLI).
# RP_DB_SOCKET=... RP_DB_USER=... RP_DB_PASS=... RP_DB_NAME=<test_db> RP_APP_TREE=<panel+payload> bash tests/run_all.sh
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
RC=0; TOTAL=0; PARTS=""
run(){ local name="$1" file="$2"; echo ""; echo "==== $name [$file] ===="
  local out rc; out=$(php "$HERE/$file" 2>&1); rc=$?
  echo "$out" | grep -viE "cannot write|Telegram|Deprec"
  local p f; p=$(echo "$out"|grep -oE "PASS=[0-9]+"|tail -1|grep -oE "[0-9]+"); f=$(echo "$out"|grep -oE "FAIL=[0-9]+"|tail -1|grep -oE "[0-9]+")
  [ -n "${p:-}" ] && TOTAL=$((TOTAL+p)) && PARTS="${PARTS}${PARTS:+ + }${p}(${file%.*})"
  { [ "$rc" != 0 ] || [ "${f:-0}" != 0 ]; } && RC=1; echo "---- exit=$rc ----"
}
echo "###### REV3.2 RUN_ALL ######  PHP $(php -r 'echo PHP_VERSION;')"
run "legacy index + host + redirect-target" test_legacy_index.php
run "redirect_disable postcondition"        test_eval_disable.php
run "preflight classify (own_redirect≠vhost)" test_preflight_classify.php
run "preflight budget/recovery"             test_preflight_decide.php
run "redirect_enable exact restore"         test_roundtrip.php
run "diagnostic codes §17"                  test_diag_codes.php
run "DB: #227 recovery + at-most-once + repair" test_db_scenarios.php
echo ""; echo "======================================================"
echo "PASS breakdown: ${PARTS}"
echo "TOTAL PASS=${TOTAL}"
echo "###### RESULT: $([ $RC = 0 ] && echo 'ALL GREEN (FAIL=0)' || echo 'FAILURES') ######"
exit $RC
