<?php
require __DIR__ . '/../payload/app/Services/RedirectToggler.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

$idx = file_get_contents(__DIR__ . '/fixtures/legacy_index.php');

// detect on real fixture
$d = RedirectToggler::detectLegacyIndexHandleRequest($idx);
t('detect present', $d['present'], true);
t('detect active_calls=1', $d['active_calls'], 1);
t('detect supported', $d['supported'], true);
t('detect reason', $d['reason'], 'legacy_index_handle_request');

// disable
$dis = RedirectToggler::disableLegacyIndexHandleRequest($idx);
t('disable ok', $dis['ok'], true);
tb('disabled content содержит маркер', strpos($dis['content'], RedirectToggler::LEGACY_INDEX_MARKER)!==false);
tb('функция handleRequest сохранена', strpos($dis['content'],'function handleRequest')!==false);
tb('$configRed сохранён', strpos($dis['content'],'$configRed["new_domain"]')!==false);
tb('шаблонный код сохранён (footer.php)', strpos($dis['content'],'footer.php')!==false);
// активный вызов больше не активен
$d2 = RedirectToggler::detectLegacyIndexHandleRequest($dis['content']);
t('после disable active_calls=0', $d2['active_calls'], 0);
t('после disable already_disabled', $d2['already_disabled'], true);
// идемпотентность: повторный disable — no-op
$dis2 = RedirectToggler::disableLegacyIndexHandleRequest($dis['content']);
t('повторный disable идемпотентен ok', $dis2['ok'], true);
t('повторный disable reason=already_disabled', $dis2['reason'], 'already_disabled');
t('повторный disable не меняет контент', $dis2['content'], $dis['content']);

// enable = byte-for-byte restore из snapshot (симулируем): restored == original
$restored = $idx; // enable восстанавливает исходный snapshot
t('restore byte-identical (sha)', hash('sha256',$restored), hash('sha256',$idx));

// >1 call → unsupported
$twoCalls = $idx . "\nhandleRequest(\$configRed);\n";
$d3 = RedirectToggler::detectLegacyIndexHandleRequest($twoCalls);
t('>1 call → not supported', $d3['supported'], false);
t('>1 call → reason', $d3['reason'], 'unsupported_multiple_handle_request');

// site without legacy redirect
$plain = "<?php echo 'hi'; ?>";
$d4 = RedirectToggler::detectLegacyIndexHandleRequest($plain);
t('no mechanism → present=false', $d4['present'], false);
t('no mechanism → supported=false', $d4['supported'], false);

// host classification (own allowlist)
$own = ['dealredirectfast.com','flowtargetredirect.com','partners7k-promo.com'];
tb('partners7k in allowlist', RedirectToggler::hostInOwnRedirectAllowlist('partners7k-promo.com',$own));
tb('www.partners7k in allowlist', RedirectToggler::hostInOwnRedirectAllowlist('www.partners7k-promo.com',$own));
tb('sub.partners7k in allowlist (suffix)', RedirectToggler::hostInOwnRedirectAllowlist('l.partners7k-promo.com',$own));
tb('evil-partners7k-promo.com.attacker NOT in allowlist', !RedirectToggler::hostInOwnRedirectAllowlist('partners7k-promo.com.attacker.com',$own));
tb('foreign NOT in allowlist', !RedirectToggler::hostInOwnRedirectAllowlist('example.com',$own));

// redirect target extraction (real meta-refresh from the log)
$metaHtml = '<!DOCTYPE html><meta http-equiv="refresh" content="0;url=https://partners7k-promo.com/l/67d9?sub_id=X">';
t('extract meta-refresh host', RedirectToggler::extractRedirectTargetHost($metaHtml), 'partners7k-promo.com');
t('extract Location header host', RedirectToggler::extractRedirectTargetHost('', 'https://partners7k-promo.com/l/1'), 'partners7k-promo.com');
t('extract JS redirect host', RedirectToggler::extractRedirectTargetHost('<script>window.location.href="https://partners7k-promo.com/x"</script>'), 'partners7k-promo.com');
t('no redirect → empty', RedirectToggler::extractRedirectTargetHost('<html>real content mellstroy80.casino</html>'), '');

echo "\n============================================================\n";
echo "ИТОГО (legacy-index + host classification): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
