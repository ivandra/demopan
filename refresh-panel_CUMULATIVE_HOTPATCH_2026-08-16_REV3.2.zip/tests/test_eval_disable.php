<?php
require __DIR__ . '/../payload/app/Services/RedirectToggler.php';
require __DIR__ . '/../payload/app/Services/RefreshOrchestrator.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$own=['dealredirectfast.com','flowtargetredirect.com','partners7k-promo.com'];
$E='RefreshOrchestrator';

// (1) БАГ #227: applied_rules=[] + live external redirect → partner → ok=FALSE (не ложный успех)
$r=$E::evaluateRedirectDisableResult(
  ['applied_rules'=>[],'errors'=>[],'readback'=>[],'detected_mechanisms'=>['legacy_index_handle_request']],
  ['reachable'=>true,'redirect_host'=>'partners7k-promo.com'], 'mellstroy80.casino', $own);
t('1a applied=[] + own-redirect live → ok=false', $r['ok'], false);
t('1b external_redirect_after', $r['external_redirect_after'], 'partners7k-promo.com');
t('1c is_own_redirect', $r['is_own_redirect'], true);
t('1d live_verified=false', $r['live_verified'], false);
t('1e reason', $r['reason'], 'external_redirect_own_after_disable');

// (2) applied + read-back ok + live чисто → ok=true
$r=$E::evaluateRedirectDisableResult(
  ['applied_rules'=>[['file'=>'index.php','rule_id'=>'legacy_index_handle_request']],'errors'=>[],'readback'=>['index.php'=>true],'detected_mechanisms'=>['legacy_index_handle_request']],
  ['reachable'=>true,'redirect_host'=>''], 'mellstroy80.casino', $own);
t('2a applied+readback+чисто → ok=true', $r['ok'], true);
t('2b live_verified=true', $r['live_verified'], true);
t('2c reason=disabled_and_verified', $r['reason'], 'disabled_and_verified');

// (3) applied но read-back mismatch → ok=false
$r=$E::evaluateRedirectDisableResult(
  ['applied_rules'=>[['file'=>'index.php']],'errors'=>[],'readback'=>['index.php'=>false],'detected_mechanisms'=>[]],
  ['reachable'=>true,'redirect_host'=>''], 'mellstroy80.casino', $own);
t('3 read-back mismatch → ok=false', $r['ok'], false);
t('3b readback_verified=false', $r['readback_verified'], false);

// (4) нет активного редиректа, ничего не применялось, live чисто → ok=true, no_active_redirect
$r=$E::evaluateRedirectDisableResult(
  ['applied_rules'=>[],'errors'=>[],'readback'=>[],'detected_mechanisms'=>[]],
  ['reachable'=>true,'redirect_host'=>''], 'somesite.casino', $own);
t('4a нет редиректа → ok=true', $r['ok'], true);
t('4b reason=no_active_redirect', $r['reason'], 'no_active_redirect');

// (5) внешний редирект на НЕизвестный (не own) домен → ok=false, is_own=false
$r=$E::evaluateRedirectDisableResult(
  ['applied_rules'=>[],'errors'=>[],'readback'=>[],'detected_mechanisms'=>[]],
  ['reachable'=>true,'redirect_host'=>'evil.example.com'], 'mellstroy80.casino', $own);
t('5a unknown external → ok=false', $r['ok'], false);
t('5b is_own=false', $r['is_own_redirect'], false);
t('5c reason=external_redirect_unknown', $r['reason'], 'external_redirect_unknown_after_disable');

// (6) внутренний редирект на тот же host (www→non-www уже нормализован) → не external → ok
$r=$E::evaluateRedirectDisableResult(
  ['applied_rules'=>[['file'=>'index.php']],'errors'=>[],'readback'=>['index.php'=>true],'detected_mechanisms'=>[]],
  ['reachable'=>true,'redirect_host'=>'mellstroy80.casino'], 'www.mellstroy80.casino', $own);
t('6 внутренний same-host редирект → ok=true', $r['ok'], true);

echo "\n============================================================\n";
echo "ИТОГО (evaluateRedirectDisableResult): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
