<?php
require __DIR__ . '/../payload/app/Services/RedirectToggler.php';
require __DIR__ . '/../payload/app/Services/RefreshOrchestrator.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$C='RefreshOrchestrator';
$now=1000000;

// ok → proceed
$d=$C::decidePreflightAction(['ok'=>true,'reason_code'=>'site_responsive'],['now'=>$now]);
t('ok → proceed', $d['action'],'proceed');

// own_redirect_active, ремонт не пробовали → recover (один раз)
$d=$C::decidePreflightAction(['ok'=>false,'reason_code'=>'own_redirect_active','retryable'=>false],
  ['now'=>$now,'redirect_repair_attempted'=>false]);
t('own-redirect, 1й раз → recover', $d['action'],'recover');

// own_redirect_active, ремонт уже был → awaiting redirect_disable_ineffective
$d=$C::decidePreflightAction(['ok'=>false,'reason_code'=>'own_redirect_active','retryable'=>false],
  ['now'=>$now,'redirect_repair_attempted'=>true]);
t('own-redirect, ремонт был → awaiting', $d['action'],'awaiting');
t('  → technical_code=redirect_disable_ineffective', $d['awaiting_technical_code'],'redirect_disable_ineffective');

// external unknown → awaiting сразу (не polling)
$d=$C::decidePreflightAction(['ok'=>false,'reason_code'=>'external_redirect_unknown','retryable'=>false],['now'=>$now]);
t('external unknown → awaiting', $d['action'],'awaiting');
t('  → technical_code=update_classes_external_redirect', $d['awaiting_technical_code'],'update_classes_external_redirect');

// transient в пределах бюджета → retry
$d=$C::decidePreflightAction(['ok'=>false,'reason_code'=>'dns_not_resolving','retryable'=>true],
  ['now'=>$now,'preflight_attempts'=>2,'preflight_started_at_unix'=>$now-120,'max_attempts'=>10,'max_age_sec'=>900]);
t('transient в бюджете → retry', $d['action'],'retry');
t('  delay_sec есть', isset($d['delay_sec']), true);

// transient, attempts исчерпаны → awaiting exhausted
$d=$C::decidePreflightAction(['ok'=>false,'reason_code'=>'dns_not_resolving','retryable'=>true],
  ['now'=>$now,'preflight_attempts'=>9,'preflight_started_at_unix'=>$now-60,'max_attempts'=>10]);
t('transient attempts исчерпаны → awaiting', $d['action'],'awaiting');
t('  → technical_code=update_classes_preflight_exhausted', $d['awaiting_technical_code'],'update_classes_preflight_exhausted');

// transient, время исчерпано (>15мин) → awaiting exhausted
$d=$C::decidePreflightAction(['ok'=>false,'reason_code'=>'connection_failed','retryable'=>true],
  ['now'=>$now,'preflight_attempts'=>1,'preflight_started_at_unix'=>$now-1000,'max_age_sec'=>900]);
t('transient время исчерпано → awaiting', $d['action'],'awaiting');

// unsupported_site_response (deterministic) → awaiting, не polling
$d=$C::decidePreflightAction(['ok'=>false,'reason_code'=>'unsupported_site_response','retryable'=>false],['now'=>$now]);
t('unsupported → awaiting (не polling)', $d['action'],'awaiting');

echo "\n============================================================\n";
echo "ИТОГО (decidePreflightAction): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
