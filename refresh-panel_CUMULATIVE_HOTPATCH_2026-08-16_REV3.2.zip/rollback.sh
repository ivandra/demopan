#!/usr/bin/env bash
# REV3.2 rollback: восстановить 4 файла из rollback/ (REV3.1 baseline, byte-for-byte) и удалить bin/repair_stuck_job.php.
# §26: если какая-либо job между redirect_disable и redirect_enable — сперва вернуть редирект из snapshot
#       (redirect_enabled_stage/snapshots в артефактах), иначе сайт останется с выключенным редиректом.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="${1:-}"
[ -z "$TARGET" ] && { echo "usage: rollback.sh /path/to/panel-root"; exit 2; }
FILES="app/Services/RefreshOrchestrator.php app/Services/RedirectToggler.php app/Services/SiteVerifier.php app/Services/DiagnosticCatalog.php"
echo "== восстанавливаю REV3.1 baseline (byte-for-byte) из rollback/ =="
for f in $FILES; do
  cp "$HERE/rollback/$f" "$TARGET/$f"
  php -l "$TARGET/$f" >/dev/null 2>&1 || { echo "php -l FAIL после restore: $f"; exit 4; }
  echo "  restored: $f"
done
rm -f "$TARGET/bin/repair_stuck_job.php" && echo "  removed: bin/repair_stuck_job.php"
echo ""
echo "ROLLBACK_OK — файлы возвращены к REV3.1. Сбросьте OPcache (reload php-fpm / opcache_reset)."
echo "§26: проверьте джобы между redirect_disable и redirect_enable — при необходимости верните редирект из snapshot вручную,"
echo "     чтобы сайт не остался с выключенным партнёрским редиректом."
