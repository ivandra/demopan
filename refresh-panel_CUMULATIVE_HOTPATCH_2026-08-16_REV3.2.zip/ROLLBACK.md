# ROLLBACK — REV3.2

`bash rollback.sh /path/to/panel-root` — восстанавливает 4 файла из `rollback/` (REV3.1 baseline,
byte-for-byte) и удаляет `bin/repair_stuck_job.php`. После — сбросить OPcache.

§26: перед откатом проверить, нет ли job между `redirect_disable` и `redirect_enable`. Если есть —
сперва вернуть редирект из сохранённого snapshot (redirect_disabled_stage.snapshots), иначе сайт
останется с выключенным редиректом.
