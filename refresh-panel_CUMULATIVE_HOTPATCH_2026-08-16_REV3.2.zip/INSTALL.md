# INSTALL — REV3.2 (кумулятивно поверх REV3.1)

1. Снять SHA256 изменяемых файлов и сделать backup; сделать дамп БД.
2. Проверить baseline: `sha256sum -c` неявно — установщик сам сверяет BASE_SHA256.txt с целевым деревом;
   при несовпадении установка ОСТАНАВЛИВАЕТСЯ (§24), дерево не трогается.
3. Установка: `bash install.sh /path/to/panel-root`
   - опц. прогон полного набора: `RP_DB_SOCKET=… RP_TEST_DB_NAME=<db>_hotpatch_test bash install.sh /path/to/panel-root`
4. Сбросить OPcache (reload php-fpm / opcache_reset) — иначе останется старый байткод.
5. Вернуть зависшую #227: `php /path/to/panel-root/bin/repair_stuck_job.php --job=227 --reason=redirect-disable-retry`
6. Наблюдать #227 до выхода из update_classes_call (evidence-цепочка §25).

Миграций/таблиц нет. Новое состояние — в job artifacts.
