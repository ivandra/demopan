<?php

/**
 * Сервис для отключения/включения редиректов на сайтах во время перевыставления.
 *
 * Используется двумя стадиями оркестратора:
 *   - redirect_disable — перед analyze_site, чтобы пользователи не уходили
 *     на партнёрку пока сайт в неполноценном состоянии
 *   - redirect_enable — после verify_replacement, чтобы вернуть редирект
 *     обратно
 *
 * Правила хранятся в config/redirect_rules.php — каждое правило это пара
 * regex (detect / disable / enable). Для каждого подходящего файла применяются
 * ВСЕ подходящие правила. State (что было применено) сохраняется в artifacts
 * чтобы enable знал какие правила обращать.
 *
 * Использует тот же FtpService и multi-path probing что и SiteFileScanner —
 * чтобы работать на чрутнутых FTP.
 */
class RedirectToggler
{
    /** @var array кэш правил из конфига */
    private array $rules;

    private string $snapshotsBaseDir;

    public function __construct()
    {
        $this->rules = $this->loadRules();
        $this->snapshotsBaseDir = dirname(__DIR__, 2) . '/storage/snapshots';
        if (!is_dir($this->snapshotsBaseDir)) {
            @mkdir($this->snapshotsBaseDir, 0775, true);
        }
    }

    /**
     * Отключить редиректы на сайте.
     *
     * Алгоритм:
     *   1. Подключиться к FTP, найти рабочий base_path
     *   2. Для каждого правила:
     *      - скачать соответствующий файл
     *      - применить detect — сработало?
     *      - если да: применить disable_find/replace, сохранить snapshot, залить
     *   3. Вернуть state — какие правила сработали и для каких файлов сделаны
     *      snapshots. enable() будет использовать этот state.
     *
     * @return array {
     *   ok: bool,
     *   applied_rules: array — список применённых rule_id с деталями
     *   snapshots: array     — file => snapshot_filename
     *   base_path: string    — для последующего enable
     *   errors: array
     * }
     */
    public function disable(int $siteId, int $jobId, $log): array
    {
        $this->markerDiag = [];
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'errors' => ["Site #{$siteId} not found"], 'applied_rules' => [], 'snapshots' => []];
        }

        $siteRoot = $this->resolveSiteRoot($site);
        if ($siteRoot === '') {
            return ['ok' => false, 'errors' => ['Cannot resolve site root'], 'applied_rules' => [], 'snapshots' => []];
        }

        $log->info('redirect_disable', "Файлы кандидатов на редактирование: " .
            implode(', ', array_unique(array_column($this->rules, 'file'))));

        // FTP
        try {
            $ftp = $this->makeFtp($site);
            $ftp->connect();
        } catch (\Throwable $e) {
            return [
                'ok' => false,
                'errors' => ['FTP connect failed: ' . $e->getMessage()],
                'applied_rules' => [], 'snapshots' => []
            ];
        }

        // Multi-path probing — переиспользуем логику из SiteFileScanner.
        // Берём первый файл из правил (обычно .htaccess или config.php) как маяк.
        $basePath = $this->findWorkingBasePath($ftp, $siteRoot, $site, $log);
        if ($basePath === null) {
            $ftp->disconnect();
            return [
                'ok' => false,
                'errors' => ['Не удалось найти рабочий base_path. FTP-доступ корректен? Файлы есть?'],
                'applied_rules' => [], 'snapshots' => []
            ];
        }
        $log->info('redirect_disable', "Рабочий base_path: '" . ($basePath === '' ? '(пустой = от FTP-корня)' : $basePath) . "'");

        // Группируем правила по файлам — чтобы не качать один файл много раз
        $byFile = [];
        foreach ($this->rules as $rule) {
            $byFile[$rule['file']][] = $rule;
        }

        $appliedRules = [];
        $snapshots = [];
        $errors = [];

        $snapshotDir = $this->snapshotsBaseDir . '/job_' . $jobId;
        if (!is_dir($snapshotDir)) {
            @mkdir($snapshotDir, 0775, true);
        }

        foreach ($byFile as $fileName => $fileRules) {
            $remotePath = $basePath === '' ? $fileName : (rtrim($basePath, '/') . '/' . $fileName);

            // Скачиваем файл
            try {
                $content = $ftp->getContent($remotePath);
            } catch (\Throwable $e) {
                $log->info('redirect_disable',
                    "файл {$fileName} не найден или недоступен — пропускаю (не критично)");
                continue;
            }

            $modified = $content;
            $appliedToFile = [];

            foreach ($fileRules as $rule) {
                // ТЗ044 §9: idempotent канонизация для php_redirect_enabled_var (без дублей маркеров).
                if (($rule['id'] ?? '') === 'php_redirect_enabled_var') {
                    $canon = $this->canonicalizeRedirectVar($modified, 0);
                    if (!empty($canon['found'])) {
                        $this->markerDiag[$fileName] = $canon['diag'];
                        if (!empty($canon['changed'])) {
                            $modified = $canon['content'];
                            $appliedToFile[] = ['rule_id' => $rule['id'], 'description' => $rule['description'], 'count' => 1];
                            $log->info('redirect_disable',
                                "✓ {$rule['id']} в {$fileName}: канонизирован redirect_enabled=0 "
                                . "(маркеров до={$canon['markers_before']}, после=1, снято дублей={$canon['normalized_duplicates']})");
                        } else {
                            $log->info('redirect_disable',
                                "= {$rule['id']} в {$fileName}: уже disabled — идемпотентно, маркеров={$canon['markers_after']}");
                        }
                        continue; // generic regex не применяем
                    }
                }

                // Detect
                if (!@preg_match($rule['detect'], $modified)) {
                    continue; // правило не подходит к этому контенту
                }

                // Disable
                $newContent = @preg_replace($rule['disable_find'], $rule['disable_replace'], $modified, -1, $count);
                if ($newContent === null) {
                    $errors[] = "{$rule['id']}: regex error in disable_find";
                    continue;
                }
                if ($count === 0 || $newContent === $modified) {
                    // detect сработал, но disable_find не нашёл подходящих строк — странно, лог предупреждение
                    $log->warn('redirect_disable',
                        "правило {$rule['id']}: detect совпал, но disable_find не нашёл строк (regex несогласован?)");
                    continue;
                }

                $modified = $newContent;
                $appliedToFile[] = [
                    'rule_id' => $rule['id'],
                    'description' => $rule['description'],
                    'count' => $count,
                ];
                $log->info('redirect_disable',
                    "✓ {$rule['id']} в {$fileName}: применено {$count} замен");
            }

            // Если хоть одно правило применилось — сохраняем snapshot и заливаем
            if (!empty($appliedToFile) && $modified !== $content) {
                $snapshotName = $this->safeSnapshotName($fileName) . '.before-disable.txt';
                $snapshotPath = $snapshotDir . '/' . $snapshotName;
                if (@file_put_contents($snapshotPath, $content) === false) {
                    $errors[] = "{$fileName}: не удалось сохранить snapshot";
                    continue;
                }

                try {
                    $ftp->putContent($remotePath, $modified, null);
                    $snapshots[$fileName] = $snapshotName;
                    foreach ($appliedToFile as $a) {
                        $a['file'] = $fileName;
                        $appliedRules[] = $a;
                    }
                } catch (\Throwable $e) {
                    $errors[] = "{$fileName}: upload failed - " . $e->getMessage();
                    $log->error('redirect_disable', "✗ {$fileName}: " . $e->getMessage());
                }
            }
        }

        $ftp->disconnect();

        if (empty($appliedRules)) {
            $log->info('redirect_disable',
                'Ни одно правило не подошло к файлам сайта. Возможно у этого шаблона редиректы устроены иначе. ' .
                'Это не блокирует pipeline.');
        } else {
            $log->ok('redirect_disable',
                'Редиректы отключены: ' . count($appliedRules) . ' правил, файлов изменено: ' . count($snapshots));
        }

        return [
            'ok' => empty($errors),
            'applied_rules' => $appliedRules,
            'snapshots' => $snapshots,
            'base_path' => $basePath,
            'errors' => $errors,
        ];
    }

    /**
     * Включить редиректы обратно используя state из disable().
     *
     * @param array $stateFromArtifacts — то что disable() вернул и сохранил в artifacts.redirect_disabled_stage
     */
    public function enable(int $siteId, int $jobId, array $stateFromArtifacts, $log): array
    {
        $this->markerDiag = [];
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'errors' => ["Site #{$siteId} not found"], 'restored_rules' => []];
        }

        $appliedBefore = $stateFromArtifacts['applied_rules'] ?? [];
        if (empty($appliedBefore)) {
            // v18.1.8: defense-in-depth — даже если в state нет applied_rules,
            // всё равно сканируем файлы на наличие REFRESH-DISABLED маркеров.
            // Это защита от ситуации когда:
            //   - джоба прошла redirect_disable, потом был rollback,
            //   - rollback очистил redirect_disabled_stage из artifacts,
            //   - pipeline снова прошёл redirect_disable, но preg_replace не нашёл маркеры
            //     (они уже закомментированы в файлах) → applied_rules = []
            //   - redirect_enable увидел пустой list → молча ok → файл с префиксом → денег нет
            //
            // Поэтому если applied_rules пусто — пытаемся прогнать ВСЕ известные правила
            // и снять любые REFRESH-DISABLED маркеры которые найдём.
            $log->warn('redirect_enable',
                'В state нет applied_rules из disable. Прогоняю все известные правила blindly ' .
                'чтобы снять любые REFRESH-DISABLED маркеры (defense-in-depth).');
            $appliedBefore = [];
            foreach ($this->rules as $r) {
                $appliedBefore[] = [
                    'rule_id' => $r['id'],
                    'file' => $r['file'],
                    'description' => $r['description'] ?? '',
                ];
            }
        }

        $basePath = $stateFromArtifacts['base_path'] ?? null;
        if ($basePath === null) {
            // fallback на siteRoot
            $basePath = $this->resolveSiteRoot($site);
        }

        // FTP
        try {
            $ftp = $this->makeFtp($site);
            $ftp->connect();
        } catch (\Throwable $e) {
            return [
                'ok' => false,
                'errors' => ['FTP connect failed: ' . $e->getMessage()],
                'restored_rules' => [],
            ];
        }

        // Группируем по файлам
        $rulesByFile = [];
        foreach ($appliedBefore as $applied) {
            $ruleId = $applied['rule_id'] ?? '';
            $file = $applied['file'] ?? '';
            if ($ruleId === '' || $file === '') continue;

            // Находим правило в текущем конфиге
            $rule = $this->findRuleById($ruleId);
            if ($rule === null) {
                $log->warn('redirect_enable',
                    "правило {$ruleId} не найдено в конфиге (видимо удалено) — пропускаю");
                continue;
            }
            $rulesByFile[$file][] = $rule;
        }

        $restored = [];
        $errors = [];

        foreach ($rulesByFile as $fileName => $fileRules) {
            $remotePath = $basePath === '' ? $fileName : (rtrim($basePath, '/') . '/' . $fileName);

            try {
                $content = $ftp->getContent($remotePath);
            } catch (\Throwable $e) {
                $errors[] = "{$fileName}: не удалось скачать для enable - " . $e->getMessage();
                continue;
            }

            $modified = $content;
            $appliedToFile = [];

            foreach ($fileRules as $rule) {
                // ТЗ044 §9: enable канонизирует redirect_enabled=1 и снимает ВСЕ REFRESH-DISABLED.
                if (($rule['id'] ?? '') === 'php_redirect_enabled_var') {
                    $canon = $this->canonicalizeRedirectVar($modified, 1);
                    if (!empty($canon['found'])) {
                        $this->markerDiag[$fileName] = $canon['diag'];
                        if (!empty($canon['changed'])) {
                            $modified = $canon['content'];
                            $appliedToFile[] = ['rule_id' => $rule['id'], 'description' => $rule['description'], 'count' => 1];
                            $log->info('redirect_enable',
                                "✓ {$rule['id']} в {$fileName}: redirect_enabled=1, снято маркеров={$canon['markers_before']}");
                        } else {
                            $log->info('redirect_enable',
                                "= {$rule['id']} в {$fileName}: уже enabled (idempotent), маркеров={$canon['markers_after']}");
                        }
                        continue;
                    }
                }

                $newContent = @preg_replace($rule['enable_find'], $rule['enable_replace'], $modified, -1, $count);
                if ($newContent === null) {
                    $errors[] = "{$rule['id']}: regex error in enable_find";
                    continue;
                }
                if ($count === 0 || $newContent === $modified) {
                    // v18.1.14: основной regex не сматчил. ДО того как сдаться —
                    // пробуем fallback паттерны.
                    $fallbackResult = $this->tryFallbackEnableRegex($rule, $modified, $log);
                    if ($fallbackResult !== null) {
                        $newContent = $fallbackResult['content'];
                        $count = $fallbackResult['count'];
                        $log->info('redirect_enable',
                            "✓ {$rule['id']} в {$fileName}: основной regex не сработал, " .
                            "fallback восстановил {$count} строк (паттерн: {$fallbackResult['pattern']})");
                    } else {
                        // v18.1.15: ни основной regex, ни fallback не сработали.
                        // Включаем diagnostic dump — что на самом деле в файле?
                        // Это критично потому что без видимости реального содержимого
                        // мы не можем починить корневую причину.
                        $diagSnippet = $this->diagnosticFileSnippet($rule, $modified);
                        $log->warn('redirect_enable',
                            "правило {$rule['id']} в {$fileName}: enable_find НЕ нашёл маркеров " .
                            "(основной + fallback). DIAGNOSTIC: " . $diagSnippet);
                        continue;
                    }
                }

                $modified = $newContent;
                $appliedToFile[] = [
                    'rule_id' => $rule['id'],
                    'description' => $rule['description'],
                    'count' => $count,
                ];
                $log->info('redirect_enable',
                    "✓ {$rule['id']} в {$fileName}: восстановлено {$count} строк");
            }

            if (!empty($appliedToFile) && $modified !== $content) {
                try {
                    $ftp->putContent($remotePath, $modified, null);
                    foreach ($appliedToFile as $a) {
                        $a['file'] = $fileName;
                        $restored[] = $a;
                    }
                } catch (\Throwable $e) {
                    $errors[] = "{$fileName}: upload failed - " . $e->getMessage();
                    $log->error('redirect_enable', "✗ {$fileName}: " . $e->getMessage());
                }
            }
        }

        $ftp->disconnect();

        if (!empty($restored)) {
            $log->ok('redirect_enable',
                'Редиректы включены: ' . count($restored) . ' правил восстановлено');
        }

        return [
            'ok' => empty($errors),
            'restored_rules' => $restored,
            'errors' => $errors,
        ];
    }

    // ===================== HELPERS =====================

    private function loadRules(): array
    {
        $rulesFile = dirname(__DIR__, 2) . '/config/redirect_rules.php';
        if (!is_file($rulesFile)) {
            return [];
        }
        $rules = require $rulesFile;
        if (!is_array($rules)) return [];
        return $rules;
    }

    /** @var array ТЗ044 §9: диагностика нормализации маркеров по файлам. */
    public array $markerDiag = [];

    /**
     * ТЗ044 §9 — идемпотентная канонизация строки `$redirect_enabled = <d>;` с маркерами.
     *  target=0 (disable): ровно `$redirect_enabled = 0; // REFRESH-DISABLED` (дубли/stale сняты);
     *  target=1 (enable):  ровно `$redirect_enabled = 1;` (все REFRESH-DISABLED сняты).
     * Идемпотентно: повторный вызов не добавляет второй маркер и ничего не меняет.
     * @return array ['found'=>bool,'content'=>string,'changed'=>bool,'semantic_before'=>?int,
     *                'semantic_after'=>int,'markers_before'=>int,'markers_after'=>int,
     *                'normalized_duplicates'=>int,'diag'=>array]
     */
    public function canonicalizeRedirectVar(string $content, int $target): array
    {
        // Захватываем присваивание + весь «хвост» строки (комментарии/маркеры) до конца строки.
        $re = '~(\$redirect_enabled\s*=\s*)(\d+)(\s*;)([^\r\n]*)~';
        if (!preg_match($re, $content, $m, PREG_OFFSET_CAPTURE)) {
            return ['found' => false, 'content' => $content, 'changed' => false];
        }
        $before = (int)$m[2][0];
        $tail = (string)$m[4][0];
        $markersBefore = (int)preg_match_all('~REFRESH-DISABLED~', $tail);

        $target = $target === 0 ? 0 : 1;
        $canonTail = ($target === 0) ? ' // REFRESH-DISABLED' : '';
        $markersAfter = ($target === 0) ? 1 : 0;

        $newContent = preg_replace_callback($re, function ($mm) use ($target, $canonTail) {
            return $mm[1] . $target . $mm[3] . $canonTail;
        }, $content, 1);

        $diag = [
            'semantic_before' => $before, 'semantic_after' => $target,
            'markers_before' => $markersBefore, 'markers_after' => $markersAfter,
            'normalized_duplicates' => max(0, $markersBefore - $markersAfter),
        ];
        return [
            'found' => true, 'content' => $newContent, 'changed' => $newContent !== $content,
            'semantic_before' => $before, 'semantic_after' => $target,
            'markers_before' => $markersBefore, 'markers_after' => $markersAfter,
            'normalized_duplicates' => max(0, $markersBefore - $markersAfter), 'diag' => $diag,
        ];
    }

    /** Прочитать семантическое состояние redirect_enabled для read-back. @return array [?int value, int markerCount] */
    public function redirectVarState(string $content): array
    {
        if (!preg_match('~\$redirect_enabled\s*=\s*(\d+)\s*;([^\r\n]*)~', $content, $m)) return [null, 0];
        return [(int)$m[1], (int)preg_match_all('~REFRESH-DISABLED~', $m[2])];
    }

    /**
     * ТЗ044 §9 (BLOCKER 3) — реальный semantic read-back config.php после enable по FTP.
     * @return array ['ok'=>bool,'reason'=>?,'found'=>bool,'value'=>?int,'marker_count'=>?int]
     * ok=false — read-back недоступен (fail-closed на стороне вызывающего).
     */
    public function readBackConfigState(int $siteId, int $jobId, $log): array
    {
        $site = $this->loadSite($siteId);
        if ($site === null) return ['ok' => false, 'reason' => 'site_not_found'];
        try { $ftp = $this->makeFtp($site); $ftp->connect(); }
        catch (\Throwable $e) { return ['ok' => false, 'reason' => 'ftp_connect_failed: ' . $e->getMessage()]; }
        $basePath = $this->findWorkingBasePath($ftp, $this->resolveSiteRoot($site), $site, $log);
        if ($basePath === null) { $ftp->disconnect(); return ['ok' => false, 'reason' => 'base_path_not_found']; }
        $remote = $basePath === '' ? 'config.php' : (rtrim($basePath, '/') . '/config.php');
        try { $content = $ftp->getContent($remote); }
        catch (\Throwable $e) { $ftp->disconnect(); return ['ok' => false, 'reason' => 'config_read_failed: ' . $e->getMessage()]; }
        $ftp->disconnect();
        [$val, $mk] = $this->redirectVarState((string)$content);
        return ['ok' => true, 'found' => $val !== null, 'value' => $val, 'marker_count' => $mk];
    }

    private function findRuleById(string $id): ?array
    {
        foreach ($this->rules as $rule) {
            if (($rule['id'] ?? '') === $id) return $rule;
        }
        return null;
    }

    private function safeSnapshotName(string $fileName): string
    {
        $safe = ltrim($fileName, '/');
        $safe = str_replace(['.', '/', '\\'], '_', $safe);
        return $safe;
    }

    private function loadSite(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    private function resolveSiteRoot(array $site): string
    {
        $idx = trim((string)($site['fp_index_dir'] ?? ''));
        if ($idx !== '') return $idx;
        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        $dom = trim((string)($site['current_domain'] ?? ''));
        if ($owner !== '' && $dom !== '') {
            return "/var/www/{$owner}/data/www/{$dom}";
        }
        return '';
    }

    private function makeFtp(array $site): FtpService
    {
        $host = trim((string)($site['ftp_host'] ?? ''));
        $user = trim((string)($site['ftp_user'] ?? ''));
        $pass = '';
        if (!empty($site['ftp_pass_enc'])) {
            try {
                $pass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            } catch (\Throwable $e) {}
        }

        if ($host === '') {
            $serverId = (int)($site['fastpanel_server_id'] ?? 0);
            if ($serverId > 0) {
                $st = DB::pdo()->prepare("SELECT host FROM fastpanel_servers WHERE id=?");
                $st->execute([$serverId]);
                $rawHost = (string)$st->fetchColumn();
                $rawHost = preg_replace('~^https?://~i', '', $rawHost);
                $rawHost = preg_replace('~:\d+$~', '', $rawHost);
                $rawHost = preg_replace('~/.*$~', '', $rawHost);
                $host = trim($rawHost);
            }
        }

        if ($host === '' || $user === '' || $pass === '') {
            throw new \RuntimeException('FTP credentials missing for site #' . ($site['id'] ?? '?'));
        }

        return new FtpService($host, $user, $pass, ['passive' => true, 'timeout' => 30]);
    }

    /**
     * Multi-path probing — копия логики из SiteFileScanner.
     * Используем config.php как маяк для определения рабочего base_path.
     */
    private function findWorkingBasePath(
        FtpService $ftp,
        string $siteRoot,
        array $site,
        $log
    ): ?string {
        $candidates = $this->buildBasePathCandidates($siteRoot, $site);

        foreach ($candidates as $base) {
            $probe = $base === '' ? 'config.php' : (rtrim($base, '/') . '/config.php');
            try {
                $content = $ftp->getContent($probe);
                if ($content !== '' && stripos($content, '<?php') !== false) {
                    return $base;
                }
            } catch (\Throwable $e) {
                // try next
            }
        }

        return null;
    }

    private function buildBasePathCandidates(string $siteRoot, array $site): array
    {
        $out = [];

        if ($siteRoot !== '') $out[] = $siteRoot;
        $out[] = '';

        if (preg_match('~^/var/www/[^/]+(/.*)$~', $siteRoot, $m)) {
            $out[] = $m[1];
            $out[] = ltrim($m[1], '/');
        }

        if (preg_match('~/www/([^/]+/?)$~', $siteRoot, $m)) {
            $out[] = '/' . $m[1];
            $out[] = $m[1];
            $out[] = 'www/' . $m[1];
        }

        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        if ($owner !== '') {
            $out[] = "/home/{$owner}/data/www/" . trim((string)($site['current_domain'] ?? ''), '/');
        }

        $seen = [];
        $clean = [];
        foreach ($out as $p) {
            $p = trim($p);
            $key = ($p === '') ? '__empty__' : $p;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $clean[] = $p;
        }

        return $clean;
    }

    /**
     * v18.1.15: dump первых ~200 символов вокруг места где должен быть маркер,
     * чтобы оператор мог увидеть в логе ЧТО реально в файле.
     *
     * Возвращает hex+ascii dump в одну строку, готовый для лога.
     */
    private function diagnosticFileSnippet(array $rule, string $content): string
    {
        $ruleId = $rule['id'] ?? '';

        // По rule_id определяем anchor — паттерн который ловит общий "контур"
        // строки без требования наличия маркера (нам нужно показать что в файле,
        // даже если маркер отсутствует или искажён).
        $anchors = [
            'php_redirect_enabled_var'        => '~\$redirect_enabled\s*=\s*\d~',
            'htaccess_redirect_play'          => '~Redirect\s+30[12]\s+/\S+~mi',
            'php_index_handle_request'        => '~handleRequest\s*\(\s*\$\w+\s*\)~mi',
            'php_site_redirect_array_enabled' => "~'redirect'\s*=>\s*\[~",
        ];

        $anchor = $anchors[$ruleId] ?? null;
        if ($anchor === null) {
            return 'no anchor for rule_id=' . $ruleId;
        }

        if (!preg_match($anchor, $content, $m, PREG_OFFSET_CAPTURE)) {
            return "anchor '{$ruleId}' NOT FOUND in file — строки с целевой переменной нет вообще";
        }

        $offset = (int)$m[0][1];
        $start = max(0, $offset - 40);
        $len = 200;
        $snippet = substr($content, $start, $len);

        // Hex dump
        $hex = bin2hex($snippet);
        // Группируем по 32 char (16 bytes) для читаемости
        $hexGroups = str_split($hex, 32);

        // ASCII representation (printable only)
        $ascii = '';
        for ($i = 0; $i < strlen($snippet); $i++) {
            $c = $snippet[$i];
            $o = ord($c);
            if ($o >= 32 && $o < 127) {
                $ascii .= $c;
            } elseif ($o === 0x0D) {
                $ascii .= '\\r';
            } elseif ($o === 0x0A) {
                $ascii .= '\\n';
            } elseif ($o === 0x09) {
                $ascii .= '\\t';
            } else {
                $ascii .= '?';
            }
        }

        return sprintf(
            "offset=%d, ascii='%s', hex=%s",
            $offset,
            $ascii,
            implode(' ', $hexGroups)
        );
    }

    /**
     * v18.1.14: fallback enable regex'ы для случаев когда основной
     * enable_find из конфига не сматчил маркер.
     *
     * Симптом который ловим: после disable файл содержит маркер
     * REFRESH-DISABLED, но между disable и enable что-то изменило
     * формат строки (пробелы, line endings, кодировка, двойной маркер),
     * и основной regex не сматчивается.
     *
     * Стратегия: для каждого известного rule_id — пробуем максимально
     * гибкие regex'ы. Возвращаем первый сматчивший вариант.
     *
     * Возвращает: ['content' => string, 'count' => int, 'pattern' => string]
     *           или null если ни один fallback не сработал.
     */
    private function tryFallbackEnableRegex(array $rule, string $content, JobEventLogger $log): ?array
    {
        $ruleId = $rule['id'] ?? '';

        // Набор fallback'ов по rule_id
        $fallbacks = [];

        if ($ruleId === 'php_redirect_enabled_var') {
            // Целевая строка вида: $redirect_enabled = 0; // REFRESH-DISABLED
            // Варианты которые ловим: разные пробелы, табы, типы комментариев (// или /* */),
            // двойной маркер, маркер в любом месте после ;.
            $fallbacks = [
                // Максимально гибкий — \h это горизонтальный whitespace (пробелы+табы)
                // .* до конца строки чтобы поймать всё после ; включая двойные маркеры
                ['~(\$redirect_enabled\s*=\s*)0(\s*;)[^\r\n]*REFRESH-DISABLED[^\r\n]*~',
                 '${1}1${2}', 'flexible_eol'],
                // Маркер /* REFRESH-DISABLED */ (block comment)
                ['~(\$redirect_enabled\s*=\s*)0(\s*;)\s*/\*\s*REFRESH-DISABLED\s*\*/~',
                 '${1}1${2}', 'block_comment'],
                // Самый широкий — игнорирует ВСЕ символы между 0; и REFRESH-DISABLED, в пределах строки
                ['~(\$redirect_enabled\s*=\s*)0(\s*;)[^\n]{0,80}REFRESH-DISABLED~',
                 '${1}1${2}', 'wide_match'],
            ];
        } elseif ($ruleId === 'htaccess_redirect_play') {
            $fallbacks = [
                // \h гибкий пробел, маркер в любой форме
                ['~^([\t ]*)#\s*REFRESH-DISABLED[^\r\n]*?(Redirect\s+30[12]\s+/\S+\s+\S+)[\t ]*$~mi',
                 '${1}${2}', 'flexible_marker'],
            ];
        } elseif ($ruleId === 'php_index_handle_request') {
            $fallbacks = [
                ['~^([\t ]*)//\s*REFRESH-DISABLED[^\r\n]*?(handleRequest\s*\(\s*\$\w+\s*\)\s*;)[\t ]*$~mi',
                 '${1}${2}', 'flexible_marker'],
            ];
        } elseif ($ruleId === 'php_site_redirect_array_enabled') {
            $fallbacks = [
                // Маркер /* REFRESH-DISABLED */ — основной regex уже это ловит, но более гибко
                ["~('redirect'\s*=>\s*\[[^\]]*?'enabled'\s*=>\s*)0(\s*,)[^\r\n]*REFRESH-DISABLED[^\r\n]*~s",
                 '${1}1${2}', 'flexible_eol'],
            ];
        }

        if (empty($fallbacks)) {
            return null;
        }

        foreach ($fallbacks as [$pattern, $replacement, $patternName]) {
            $newContent = @preg_replace($pattern, $replacement, $content, -1, $count);
            if ($newContent === null) continue; // regex error — пропускаем
            if ($count > 0 && $newContent !== $content) {
                return [
                    'content' => $newContent,
                    'count' => $count,
                    'pattern' => $patternName,
                ];
            }
        }

        return null;
    }
}
