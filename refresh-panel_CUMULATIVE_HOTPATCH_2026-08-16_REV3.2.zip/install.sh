#!/usr/bin/env bash
# REV3.2 cumulative hotpatch installer (поверх установленного REV3.1). Только код: 4 файла + 1 новый CLI.
# НИКАКИХ миграций/таблиц. При несовпадении baseline SHA — СТОП (§24).
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="${1:-}"
[ -z "$TARGET" ] && { echo "usage: install.sh /path/to/panel-root"; exit 2; }
[ -d "$TARGET/app/Services" ] || { echo "ОШИБКА: '$TARGET' не похоже на корень панели (нет app/Services)"; exit 2; }
ID="rev32_$(date +%s)_$$"; BK="$TARGET/.rev32_backup_$ID"; mkdir -p "$BK/app/Services"
FILES="app/Services/RefreshOrchestrator.php app/Services/RedirectToggler.php app/Services/SiteVerifier.php app/Services/DiagnosticCatalog.php"

echo "== §24: проверка baseline SHA (должно совпасть с установленным REV3.1) =="
fail=0
while read -r sha f; do
  [ -z "$sha" ] && continue
  cur=$(sha256sum "$TARGET/$f" 2>/dev/null | cut -d' ' -f1)
  if [ "$cur" != "$sha" ]; then echo "  [MISMATCH] $f (ожидался REV3.1 baseline)"; fail=1; else echo "  [OK] $f"; fi
done < "$HERE/BASE_SHA256.txt"
[ "$fail" = 1 ] && { echo "СТОП: baseline не соответствует REV3.1 — установка отменена, дерево не тронуто."; exit 3; }

echo "== backup изменяемых файлов =="
for f in $FILES; do cp "$TARGET/$f" "$BK/$f"; done
echo "  backup: $BK"

echo "== применяю payload (4 файла + bin/repair_stuck_job.php) =="
restore(){ echo "ОШИБКА — откатываю из backup"; for f in $FILES; do cp "$BK/$f" "$TARGET/$f"; done; rm -f "$TARGET/bin/repair_stuck_job.php"; }
for f in $FILES; do
  cp "$HERE/payload/$f" "$TARGET/$f"
  php -l "$TARGET/$f" >/dev/null 2>&1 || { echo "  php -l FAIL: $f"; restore; exit 4; }
done
mkdir -p "$TARGET/bin"; cp "$HERE/payload/bin/repair_stuck_job.php" "$TARGET/bin/repair_stuck_job.php"
php -l "$TARGET/bin/repair_stuck_job.php" >/dev/null 2>&1 || { echo "php -l FAIL cli"; restore; exit 4; }
echo "  применено."

echo "== обязательные тесты (FAIL=0) =="
TDB="${RP_TEST_DB_NAME:-}"
if [ -n "${RP_DB_SOCKET:-}" ] && [ -n "$TDB" ]; then
  RP_APP_TREE="$TARGET" RP_DB_NAME="$TDB" bash "$HERE/tests/run_all.sh" >/tmp/${ID}_tests.out 2>&1
  trc=$?; tail -6 /tmp/${ID}_tests.out
  [ "$trc" != 0 ] && { echo "ТЕСТЫ УПАЛИ — откатываю"; restore; exit 5; }
else
  echo "  (RP_DB_SOCKET/RP_TEST_DB_NAME не заданы — прогоняю только pure-suites)"
  for t in test_legacy_index test_eval_disable test_preflight_classify test_preflight_decide test_roundtrip test_diag_codes; do
    php "$HERE/tests/$t.php" >/dev/null 2>&1 || { echo "  suite FAIL: $t"; restore; exit 5; }
  done
  echo "  pure-suites OK"
fi

echo ""
echo "INSTALL_OK REV3.2. backup=$BK"
echo "ВАЖНО: сбросьте OPcache для изменённых PHP (reload php-fpm ИЛИ opcache_reset), иначе старый байткод останется."
echo "Затем: php $TARGET/bin/repair_stuck_job.php --job=227 --reason=redirect-disable-retry   (вернёт зависшую #227 на переигрывание)"
