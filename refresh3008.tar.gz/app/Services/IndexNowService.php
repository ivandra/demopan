<?php
/**
 * IndexNowService — best-effort уведомление Yandex IndexNow о новых URL.
 *
 * ТЗ IndexNow hotfix (2026-08-17). Обязанности строго ограничены:
 *   - deriveKey():     стабильный per-site key (HMAC от app_key, domain-separated);
 *   - keyFileName():   имя key-файла;
 *   - normalizeUrls(): фильтр URL (same-host https, без sitemap/robots/reg/verifier/key);
 *   - probeKey():      публичная HTTPS-проверка key-файла (trusted TLS + host + body===key);
 *   - submit():        POST https://yandex.com/indexnow с семантикой ответов.
 *
 * Service НЕ пишет refresh_jobs, НЕ меняет stage, НЕ трогает сайт по FTP,
 * НЕ работает с Webmaster OAuth, НЕ шлёт Telegram. Только key/validation/probe/HTTP.
 * key и app_key наружу не отдаёт и не логирует.
 *
 * PHP 8.0-совместимо (без enum/readonly/named-args-в-рантайме и т.п.).
 */
class IndexNowService
{
    /** Официальный endpoint Yandex IndexNow. */
    public const ENDPOINT = 'https://yandex.com/indexnow';

    /** Максимум URL за один POST (контракт IndexNow). */
    public const MAX_URLS = 10000;

    /** Таймауты публичного probe/submit. */
    private const CONNECT_TIMEOUT = 3;
    private const TOTAL_TIMEOUT   = 8;

    /**
     * Стабильный key на уровне site_id: HMAC-SHA256 от app_key c domain separation.
     * app_key пуст → '' (вызывающий трактует как disabled, без исключения).
     * Длина 32 hex-символа: удовлетворяет требованию IndexNow (8..128, [A-Za-z0-9-]).
     */
    public function deriveKey(int $siteId): string
    {
        $appKey = (string)$this->appKey();
        if ($appKey === '') {
            return '';
        }
        return substr(
            hash_hmac('sha256', 'refresh-panel:indexnow:site:' . $siteId, $appKey),
            0,
            32
        );
    }

    /** Имя key-файла на сайте: "<key>.txt". */
    public function keyFileName(string $key): string
    {
        return $key . '.txt';
    }

    /** Валиден ли key по требованиям IndexNow (8..128, [A-Za-z0-9-]). */
    public function isKeyValid(string $key): bool
    {
        return (bool)preg_match('~^[A-Za-z0-9\-]{8,128}$~', $key);
    }

    /**
     * Нормализация URL перед отправкой: оставить только валидные absolute
     * https URL c host EXACTLY = $newDomain; убрать дубликаты и служебные пути.
     *
     * @param string   $newDomain хост нового домена (без схемы), напр. "7k1008.top"
     * @param string[] $urls
     * @return string[] отфильтрованный список (<= MAX_URLS)
     */
    public function normalizeUrls(string $newDomain, array $urls): array
    {
        $host = $this->normalizeHost($newDomain);
        if ($host === '') {
            return [];
        }

        $out = [];
        $seen = [];
        foreach ($urls as $u) {
            if (!is_string($u)) {
                continue;
            }
            $u = trim($u);
            if ($u === '') {
                continue;
            }

            $parts = @parse_url($u);
            if ($parts === false || empty($parts['scheme']) || empty($parts['host'])) {
                continue;
            }
            // только https
            if (strtolower((string)$parts['scheme']) !== 'https') {
                continue;
            }
            // host EXACTLY new_domain (www трактуем как другой host — не подмешиваем)
            if ($this->normalizeHost((string)$parts['host']) !== $host) {
                continue;
            }

            $path = (string)($parts['path'] ?? '/');
            if ($path === '') {
                $path = '/';
            }
            if ($this->isExcludedPath($path)) {
                continue;
            }

            // канонический вид для дедупликации: scheme+host+path(+query), без fragment
            $canonHost = $host;
            $query = isset($parts['query']) && $parts['query'] !== '' ? '?' . $parts['query'] : '';
            $canon = 'https://' . $canonHost . $path . $query;

            $key = strtolower($canon);
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $out[] = $canon;

            if (count($out) >= self::MAX_URLS) {
                break;
            }
        }

        return $out;
    }

    /**
     * Публичная HTTPS-проверка key-файла. Успех ТОЛЬКО если:
     *   trusted TLS + HTTP 200 + финальный host === new_domain + trim(body) === key.
     * Никаких redirect на другой host, HTML, meta-refresh, JS, 3xx/403/404.
     *
     * @return array{ready:bool, http:int, reason:string, final_host:string}
     */
    public function probeKey(string $host, string $key): array
    {
        $host = $this->normalizeHost($host);
        if ($host === '' || $key === '') {
            return ['ready' => false, 'http' => 0, 'reason' => 'bad_args', 'final_host' => ''];
        }
        $url = 'https://' . $host . '/' . $this->keyFileName($key);

        $res = $this->httpGetNoRedirect($url);
        $finalHost = $this->normalizeHost($res['final_host'] ?? '');

        // any redirect / non-200 → not ready
        if ($res['http'] !== 200) {
            return ['ready' => false, 'http' => (int)$res['http'], 'reason' => $res['reason'] ?: 'not_200', 'final_host' => $finalHost];
        }
        if ($finalHost !== $host) {
            return ['ready' => false, 'http' => 200, 'reason' => 'host_mismatch', 'final_host' => $finalHost];
        }
        $body = (string)($res['body'] ?? '');
        if (trim($body) !== $key) {
            return ['ready' => false, 'http' => 200, 'reason' => 'body_mismatch', 'final_host' => $finalHost];
        }
        return ['ready' => true, 'http' => 200, 'reason' => 'ok', 'final_host' => $finalHost];
    }

    /**
     * POST в IndexNow. Возвращает классифицированный результат.
     * accepted=true для 200/202. Различаем key_verified (200) vs pending (202).
     * 400/422 → terminal (disabled/invalid_payload). 403 → bounded retry.
     * 429/5xx/network/timeout → transient.
     *
     * @param string   $host
     * @param string   $key
     * @param string[] $urls уже нормализованные
     * @return array{accepted:bool, http:int, key_verified:bool, terminal:bool,
     *               retry:bool, reason:string}
     */
    public function submit(string $host, string $key, array $urls): array
    {
        $host = $this->normalizeHost($host);
        if ($host === '' || $key === '' || empty($urls)) {
            return $this->r(false, 0, false, false, false, 'bad_args');
        }
        if (count($urls) > self::MAX_URLS) {
            $urls = array_slice($urls, 0, self::MAX_URLS);
        }

        $payload = [
            'host'        => $host,
            'key'         => $key,
            'keyLocation' => 'https://' . $host . '/' . $this->keyFileName($key),
            'urlList'     => array_values($urls),
        ];
        $body = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($body === false) {
            return $this->r(false, 0, false, true, false, 'json_encode_failed');
        }

        $res = $this->httpPostJson(self::ENDPOINT, $body);
        $http = (int)$res['http'];

        if ($http === 200) {
            return $this->r(true, 200, true, false, false, 'accepted_verified');
        }
        if ($http === 202) {
            return $this->r(true, 202, false, false, false, 'accepted_pending');
        }
        if ($http === 429) {
            return $this->r(false, 429, false, false, true, 'rate_limited');
        }
        if ($http === 403) {
            // key отклонён/недоступен — bounded retry (не terminal), но требует повторного probe.
            return $this->r(false, 403, false, false, true, 'key_rejected');
        }
        if ($http === 400 || $http === 422) {
            return $this->r(false, $http, false, true, false, 'invalid_payload');
        }
        if ($http >= 500 && $http < 600) {
            return $this->r(false, $http, false, false, true, 'server_error');
        }
        if ($http === 0) {
            // network / timeout / TLS
            return $this->r(false, 0, false, false, true, $res['reason'] ?: 'network_error');
        }
        // прочие коды — трактуем консервативно как transient (не terminal, refresh не ломаем)
        return $this->r(false, $http, false, false, true, 'unexpected_http');
    }

    // ───────────────────────── internal ─────────────────────────

    /** Читает app_key из конфигурации (не логируется). Вынесено для тестовой подмены. */
    protected function appKey(): string
    {
        if (function_exists('config')) {
            return (string)config('app_key', '');
        }
        return '';
    }

    /** Нормализация host: lowercase, срез порта/пробелов, без www не трогаем (www — другой host). */
    private function normalizeHost(string $h): string
    {
        $h = trim(strtolower($h));
        if ($h === '') {
            return '';
        }
        // если передали URL — вытащим host
        if (strpos($h, '://') !== false) {
            $p = @parse_url($h);
            $h = strtolower((string)($p['host'] ?? ''));
        }
        // срезать порт
        if (($pos = strpos($h, ':')) !== false) {
            $h = substr($h, 0, $pos);
        }
        return trim($h, " \t\n\r\0\x0B.");
    }

    /** Служебные пути, которые IndexNow слать не должен. */
    private function isExcludedPath(string $path): bool
    {
        $p = strtolower($path);
        if ($p === '/robots.txt') return true;
        if ($p === '/sitemap.xml') return true;
        if (preg_match('~^/sitemap[^/]*\.xml$~', $p)) return true;      // /sitemap*.xml
        if (preg_match('~\.txt$~', $p) && preg_match('~^/[a-f0-9]{32}\.txt$~', $p)) return true; // IndexNow key file
        if (preg_match('~^/yandex_[^/]*\.html$~', $p)) return true;     // Yandex verifier
        if ($p === '/reg' || strpos($p, '/reg/') === 0) return true;    // /reg, /reg/*
        return false;
    }

    /**
     * HTTP GET без follow-redirect (для key probe). Возвращает http/body/final_host/reason.
     * Вынесено protected для мока в тестах.
     *
     * @return array{http:int, body:string, final_host:string, reason:string}
     */
    protected function httpGetNoRedirect(string $url)
    {
        if (!function_exists('curl_init')) {
            return ['http' => 0, 'body' => '', 'final_host' => '', 'reason' => 'no_curl'];
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,          // редирект на другой host = not ready
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_CONNECTTIMEOUT => self::CONNECT_TIMEOUT,
            CURLOPT_TIMEOUT        => self::TOTAL_TIMEOUT,
            CURLOPT_USERAGENT      => 'RefreshPanel-IndexNow/1.0',
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);

        if ($errno !== 0) {
            $reason = ($errno === CURLE_OPERATION_TIMEDOUT) ? 'timeout'
                : (($errno === CURLE_SSL_CACERT || $errno === CURLE_SSL_PEER_CERTIFICATE || $errno === CURLE_PEER_FAILED_VERIFICATION) ? 'tls_error' : 'network_error');
            return ['http' => 0, 'body' => '', 'final_host' => '', 'reason' => $reason];
        }
        $fp = @parse_url($effective);
        $finalHost = strtolower((string)($fp['host'] ?? ''));
        return ['http' => $http, 'body' => (string)$body, 'final_host' => $finalHost, 'reason' => 'ok'];
    }

    /**
     * HTTP POST JSON в IndexNow. Не follow redirect к другому host.
     * Вынесено protected для мока в тестах.
     *
     * @return array{http:int, reason:string}
     */
    protected function httpPostJson(string $url, string $jsonBody)
    {
        if (!function_exists('curl_init')) {
            return ['http' => 0, 'reason' => 'no_curl'];
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $jsonBody,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_CONNECTTIMEOUT => self::CONNECT_TIMEOUT,
            CURLOPT_TIMEOUT        => self::TOTAL_TIMEOUT,
            CURLOPT_USERAGENT      => 'RefreshPanel-IndexNow/1.0',
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json; charset=utf-8'],
        ]);
        $resp = curl_exec($ch);
        $errno = curl_errno($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        unset($resp); // тело для решения не нужно; key в нём отсутствует, но не храним из осторожности

        if ($errno !== 0) {
            $reason = ($errno === CURLE_OPERATION_TIMEDOUT) ? 'timeout' : 'network_error';
            return ['http' => 0, 'reason' => $reason];
        }
        return ['http' => $http, 'reason' => 'ok'];
    }

    /** @return array{accepted:bool,http:int,key_verified:bool,terminal:bool,retry:bool,reason:string} */
    private function r(bool $accepted, int $http, bool $keyVerified, bool $terminal, bool $retry, string $reason): array
    {
        return [
            'accepted'     => $accepted,
            'http'         => $http,
            'key_verified' => $keyVerified,
            'terminal'     => $terminal,
            'retry'        => $retry,
            'reason'       => $reason,
        ];
    }
}
