// Real HTTP/UI regressions for the corrections to the supplied package.
export async function verifyRevision({page, base, check, auth, state, manifest}) {
  await auth();
  const s = await state();
  check('existing region component and infoblock reused',
    s.collections.regions.class_id === 223 && s.collections.regions.cc_id === 57);

  for (const [url, layout] of [['/','home'], ['/o-nas/','about'], ['/blog/','blog'],
      ['/kontakty/','contacts'], ['/o-nas/spetsialisty/','specialists'], ['/o-nas/foto/','gallery']]) {
    await page.goto(base + url);
    check('inherited child layout ' + layout, await page.locator(`[data-zhp-layout="${layout}"]`).count() === 1);
    check('test banner absent ' + url, !/Тестовая версия сайта|Демонстрационные контакты/.test(await page.locator('body').innerText()));
  }
  await page.goto(base + '/');
  check('footer year comes from runtime', (await page.locator('.footer__copy').innerText()).includes(String(new Date().getFullYear())));

  const homeArticle = await page.locator('.blog__item h3 a').first().getAttribute('href');
  let response = await page.goto(new URL(homeArticle, base).href);
  check('home article opens full inherited view', response.status() === 200 && await page.locator('.article-page').count() === 1 && await page.locator('h1').count() === 1);
  check('full article has actual body', (await page.locator('.article-page__left').innerText()).length > 300);
  await page.goto(base + '/blog/');
  const labels = await page.locator('[data-article-category]').allTextContents();
  check('blog has article categories', labels.map(x=>x.trim()).join('|') === 'Все статьи|Подросткам|Родителям|Специалистам');
  const featured = await page.locator('.articles-block a').filter({hasText:'Читать'}).getAttribute('href');
  response = await page.goto(new URL(featured, base).href);
  check('featured article opens full inherited view', response.status() === 200 && await page.locator('.article-page').count() === 1);
  for (const category of ['teens','parents','specialists']) {
    await page.goto(base + '/blog/?category=' + category);
    check('article filter ' + category, await page.locator(`[data-article-category="${category}"]`).evaluate(e=>e.classList.contains('specialists-block__filter--active')));
  }
  await page.goto(base + '/o-nas/');
  const teamTitles = await page.locator('.team__item-desc').allTextContents();
  check('team positions come from specialist fields', teamTitles[0].trim() === manifest.collections.specialists.records[0].position);

  async function editRecord(collection, id, changes) {
    await page.goto(base + `/netcat/message.php?inside_admin=1&catalogue=1&sub=${collection.sub_id}&cc=${collection.cc_id}&message=${id}&isModal=1`);
    const field = page.locator('[name="'+Object.keys(changes)[0]+'"]').first();
    const previous = await field.evaluate((element, changes)=>Object.fromEntries(
      Object.keys(changes).map(name=>[name,element.form.elements.namedItem(name)?.value])
    ), changes);
    const response = await field.evaluate(async (element, changes)=>{
      const form=element.form, data=new FormData(form);data.set('partial','1');
      for(const [key,value] of Object.entries(changes)) data.set(key,value);
      const response=await fetch(form.action,{method:'POST',body:data});
      return {status:response.status,html:await response.text()};
    }, changes);
    check('native editor accepted '+Object.keys(changes).join(', '), response.status === 200 && !response.html.includes('Fatal error'));
    return previous;
  }

  await auth();
  const article=s.collections.articles, articleId=s.seeded[article.cc_id+':0'];
  const dateChanges={f_date_day:'17',f_date_month:'11',f_date_year:'2027'};
  const oldDate=await editRecord(article,articleId,dateChanges);
  for(const [url, selector] of [['/blog/','.articles-block .blog__item-meta'],
      ['/','.blog__item-meta']]) {
    await page.goto(new URL(url,base).href);
    check('native article date updates '+url, (await page.locator(selector).first().innerText()).includes('17.11.2027'));
  }
  const datedArticle = await page.locator('.blog__item h3 a').first().getAttribute('href');
  check('native edit preserves article URL keyword', datedArticle === homeArticle);
  await page.goto(new URL(datedArticle,base).href);
  check('native article date updates full page', (await page.locator('.article-preview .blog__item-meta').innerText()).includes('17.11.2027'));
  await editRecord(article,articleId,oldDate);

  const region=s.collections.regions;
  const oldPhone=await editRecord(region,1,{f_phone:'+7 (999) 222-33-44'});
  await page.goto(base+'/kontakty/');
  check('phone edited in original component updates page', (await page.locator('body').innerText()).includes('+7 (999) 222-33-44'));
  check('original region hours render line breaks', !(await page.locator('main').innerText()).includes('<br'));
  await page.goto('http://spb.lifepodrostka.ru:8080/kontakty/');
  check('region phone edit does not leak to other domain', !(await page.locator('body').innerText()).includes('+7 (999) 222-33-44'));
  await page.goto(base+'/_zhp_auth.php');
  await editRecord(region,1,oldPhone);

  await page.goto(base+'/_zhp_state.php?settings=set');
  await page.goto(base+'/blog/');
  check('child layout setting is rendered', (await page.locator('.footer__copy').innerText()).includes('Проверка настройки дочернего макета'));
  await page.goto(new URL(homeArticle,base).href);
  check('full article inherits section layout settings', (await page.locator('.article-page__aside-title').innerText()) === 'Поддержка из настроек макета');
  check('related articles use shared records', await page.locator('.article-page__related-item').count() === manifest.collections.articles.records.length-1);
  check('article keeps original sidebar design', await page.locator('.article-page__banner img').count() === 1);
  await page.goto(base+'/');
  check('child layout override is scoped to its section', !(await page.locator('.footer__copy').innerText()).includes('Проверка настройки дочернего макета'));
  await page.goto(base+'/_zhp_state.php?settings=reset');
}
