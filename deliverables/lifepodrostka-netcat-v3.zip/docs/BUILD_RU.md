# Сборка и тестирование

Рабочий пакет находится в `netcat-integration`, примеры пользователя рядом
с ним не изменяются. Для сборки нужны Python и beautifulsoup4.

Из корня репозитория:

```sh
python3 netcat-integration/build/native.py
python3 netcat-integration/build/installer.py
python3 netcat-integration/build/package.py
```

Входные HTML — `build/reference-layout`, смысловые данные —
`build/source-content.json`. `native.py` создаёт штатные компоненты;
`revision.py` содержит исправления относительно приложенного v2.
`installer.py` собирает PHP-установщик и SHA-256 списка загружаемых файлов.
Python не участвует в обработке запросов сайта.

## Воспроизведение стенда

Проверено с PHP 8.3.36, MariaDB 10.11, Playwright 1.62.1 и Chromium 153
(@sparticuz/chromium 153.0.0). Python-зависимости: beautifulsoup4 4.15.0,
PyMySQL 1.2.3. Тесты используют только изолированную папку
`/workspace/netcat-runtime/site` и локальную БД `lifepodr`.

Dockerfile: `tests/Dockerfile`. В управляемой среде перед сетевой сборкой
следует прочитать cloud-environment-runtime и сохранить настройки прокси/CA.
Пример сборки с предоставленным доверенным CA:

```sh
docker build --secret id=proxy_ca,src=/etc/ssl/certs/ca-certificates.crt \
  -t netcat-qa-php:8.3 -f netcat-integration/tests/Dockerfile .
docker network create netcat-qa
docker run --rm -d --name netcat-qa-db --network netcat-qa \
  -p 127.0.0.1:23307:3306 -e MARIADB_ALLOW_EMPTY_ROOT_PASSWORD=1 \
  -e MARIADB_DATABASE=lifepodr mariadb:10.11 --sql-mode=
```

Создайте `/workspace/netcat-runtime/site`, затем запустите PHP:

```sh
docker run --rm -d --name netcat-qa-web --network netcat-qa \
  -p 127.0.0.1:8080:8080 --mount type=bind,src=/workspace,dst=/workspace \
  -e DOCUMENT_ROOT=/workspace/netcat-runtime/site \
  -e LP_TEST_ROOT=/workspace/netcat-runtime/site netcat-qa-php:8.3 \
  php -S 0.0.0.0:8080 -t /workspace/netcat-runtime/site \
  /workspace/demopan/netcat-integration/tests/router.php
```

Дождитесь готовности MariaDB. `tests/run.py` удаляет и заново создаёт
только тестовую БД `lifepodr` и содержимое этой тестовой папки. Не запускайте
его с путями или контейнерами рабочего сайта. Пустой пароль используется
только в этом локальном стенде с привязкой порта к loopback.

`NETCAT_CHROMIUM_MODULE` указывает на модуль
`@sparticuz/chromium/build/index.js`. В Codex Playwright находится через
`CODEX_PRIMARY_RUNTIME_NODE_MODULES`; при обычной локальной установке можно
использовать Playwright из `node_modules` (см. код тестов).

```sh
python3 netcat-integration/tests/run.py --sql /путь/postroisvo_zhizn.sql
python3 netcat-integration/tests/run.py --upgrade --sql /путь/postroisvo_zhizn.sql
node netcat-integration/tests/smoke.mjs
```

Прогоны выполняются **последовательно**: у них общая тестовая БД.
Первый начинает с оригинала; второй устанавливает приложенный v2, вносит
редакторское изменение и обновляет его. Сохранность старых таблиц проверяется
до намеренного редактирования через формы; после него отдельно сверяются
нетронутые данные и ожидаемые результаты редактирования.

`prepare.py` создаёт временные точки входа администратора только на стенде.
Их нельзя переносить на хостинг. При завершении стенд можно остановить:

```sh
docker stop netcat-qa-web netcat-qa-db
docker network rm netcat-qa
```
