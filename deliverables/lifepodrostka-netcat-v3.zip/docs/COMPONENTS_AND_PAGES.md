# Компоненты, поля и страницы v3

22 новых базовых компонента и 23 шаблона компонентов. Региональный псевдоним установщика `zhp_regions` ссылается на существующий компонент **223**, инфоблок **57**; отдельная таблица регионов не создаётся.

| Компонент | Ключ | Поля |
| --- | --- | --- |
| Карточки и преимущества | `zhp_cards` | `name` — Название; `text` — Описание; `img` — Изображение или иконка; `img_mobile` — Мобильное изображение; `link` — Ссылка |
| Баннер страницы | `zhp_banner` | `name` — Заголовок; `label` — Надзаголовок; `text` — Описание; `img` — Основное изображение; `button` — Текст первой кнопки; `link` — Ссылка первой кнопки; `button2` — Текст второй кнопки; `link2` — Ссылка второй кнопки; `trust_text` — Подпись блока доверия |
| Основатель проекта | `zhp_founder` | `fio` — ФИО; `position` — Должность / подпись; `img` — Фотография; `bio` — Описание; `achievements` — Достижения |
| Видео | `zhp_video` | `name` — Заголовок; `text` — Описание; `link` — Ссылка на видео; `label` — Надзаголовок; `img` — Обложка видео |
| Программа | `zhp_program` | `name` — Заголовок; `label` — Надзаголовок; `text` — Вступление; `directions_title` — Заголовок направлений; `directions` — Направления программы; `support_title` — Заголовок сопровождения; `support` — Содержание сопровождения; `benefits` — Преимущества программы; `img` — Иллюстрация программы |
| Содержание услуги | `zhp_program_service` | `name` — Заголовок; `label` — Надзаголовок; `text` — Вступление; `directions_title` — Заголовок направлений; `directions` — Направления программы; `support_title` — Заголовок сопровождения; `support` — Содержание сопровождения |
| Группа для родителей | `zhp_parent_group` | `name` — Заголовок; `text` — Описание; `button` — Текст кнопки |
| Как связаться | `zhp_first_step` | `name` — Заголовок; `text` — Описание; `label` — Надзаголовок; `img` — Иллюстрация; `action1_title` — Карточка 1 — заголовок; `action1_text` — Карточка 1 — описание; `action2_title` — Карточка 2 — заголовок; `action2_text` — Карточка 2 — описание; `action3_title` — Карточка 3 — заголовок; `action3_text` — Карточка 3 — описание |
| Социальные сети | `zhp_socials` | `name` — Заголовок; `text` — Описание; `subtitle` — Подзаголовок; `instagram_img` — INSTAGRAM — изображение 1; `instagram_img2` — INSTAGRAM — изображение 2; `vk_img` — VK — изображение 1; `vk_img2` — VK — изображение 2; `telegram_img` — TELEGRAM — изображение 1; `telegram_img2` — TELEGRAM — изображение 2; `youtube_img` — YOUTUBE — изображение 1; `youtube_img2` — YOUTUBE — изображение 2 |
| Специалисты | `zhp_specialists` | `fio` — ФИО; `position` — Должность / специализация; `img` — Фотография; `intro` — Краткое описание; `bio` — О специалисте; `personalquote` — Цитата; `stats` — Город, формат и опыт; `details` — Сведения о приёме; `methods` — Методы и подходы; `education` — Образование; `diploms` — Документы и сертификаты; `category` — Категории фильтра (через пробел) |
| Статьи | `zhp_articles` | `name` — Заголовок; `intro` — Анонс; `text` — Текст статьи; `img` — Изображение; `date` — Дата публикации; `readtime` — Время чтения; `category` — Категория (teens / parents / specialists) |
| Отзывы | `zhp_reviews` | `name` — Имя; `role` — Подпись; `text` — Текст отзыва; `img` — Аватар |
| Вопросы и ответы | `zhp_faq` | `question` — Вопрос; `answer` — Ответ |
| Дипломы и сертификаты | `zhp_certificates` | `name` — Название документа; `img` — Изображение документа; `file` — Файл для скачивания |
| Фотогалерея | `zhp_gallery` | `name` — Подпись фотографии; `img` — Фотография; `category` — Категория (classes / events / team / more) |
| Текстовый блок | `zhp_text` | `name` — Заголовок; `text` — Текст |
| Контакты | `zhp_contacts` | `name` — Заголовок; `text` — Вступление |
| Калькулятор стоимости | `zhp_calculator` | `name` — Заголовок; `text` — Описание; `days_min` — Минимум суток; `days_max` — Максимум суток; `days` — Суток по умолчанию; `rate_min` — Минимальная ставка; `rate_max` — Максимальная ставка; `rate` — Ставка по умолчанию; `img` — Иллюстрация калькулятора; `img_mobile` — Иллюстрация на телефоне |
| Вопросы квиза | `zhp_quiz` | `question` — Вопрос; `answers` — Варианты ответа (по одному на строку) |
| Подписка на рассылку | `zhp_subscription` | `name` — Заголовок; `text` — Описание |
| Регионы (существующий №223) | `zhp_regions` | `main_domain` — Домен без протокола и пути; `city` — Город; `inCity` — Город: где? (в Москве); `cityRP` — Город: откуда? (Москвы); `cityDP` — Город: кому? (Москве); `address` — Адрес; `phone` — Телефон; `email` — Email для посетителей; `regim` — Время работы; `max` — MAX; `telegram` — Telegram; `whatsapp` — WhatsApp; `vk` — VK; `youtube` — YouTube; `instagram` — Instagram; `mapcode` — Код карты; `email_to` — Получатель заявок; `email_from` — Отправитель писем; `email_enabled` — Отправлять заявки на email |
| Заявки | `zhp_leads` | `name` — Имя; `phone` — Телефон; `email` — Email; `contact` — Контакт для связи; `message` — Сообщение; `form_type` — Источник формы; `page_url` — Страница; `domain` — Домен; `utm` — UTM-метки; `answers` — Ответы квиза; `request_key` — Ключ отправки; `delivery` — Статус письма; `consent` — Согласие на обработку данных |
| Как нас найти | `zhp_location` | `name` — Заголовок; `text` — Описание |

## Инфоблоки страниц

| Путь | Дочерний макет | Инфоблоки |
| --- | --- | --- |
| `/` | home | Верхний баннер, Основатель проекта, Видео о проекте, Программа, Группа для родителей, Калькулятор стоимости, Вопросы квиза, Как связаться, Для кого, Этапы, Что предлагает проект, Специалисты, Отзывы, Дипломы и сертификаты, Статьи, Социальные сети, Подписка на рассылку |
| `/o-nas/` | about | О проекте — первый экран, О проекте — вступление, Ценности проекта, Подросткам и родителям, Как проходит работа, Команда |
| `/blog/` | blog | Рекомендуемая статья, Статьи, Подписка на рассылку |
| `/kontakty/` | contacts | Контакты, Вопросы и ответы, Как нас найти |
| `/o-nas/spetsialisty/` | specialists | Заголовок страницы, Специалисты, Дипломы и сертификаты, Подписка на рассылку |
| `/o-nas/foto/` | gallery | Заголовок галереи, Фотографии, Подписка на рассылку |
| `/o-nas/otzyvy/` | inner | Отзывы |
| `/o-nas/voprosy-i-otvety/` | inner | Вопросы и ответы |
| `/o-nas/sertifikaty/` | inner | Дипломы и сертификаты |
| `/regions/` | inner |  |
| `/zayavki/` | success |  |
| `/nastroiki-proekta/` | inner |  |
| `/politika-konfidentsialnosti/` | inner | Текст страницы |
| `/policy/` | inner | Текст страницы |
| `/404/` | error | Текст страницы |
| `/podrostkam/` | inner | Текст страницы |
| `/podrostkam/trevoga-i-perezhivaniya/` | service | Баннер услуги, Содержание услуги, Причины трудностей, Как мы помогаем, Как проходит работа, Специалисты |
| `/podrostkam/trevoga-i-perezhivaniya/trevozhnye-mysli-i-strahi/` | inner | Текст страницы |
| `/podrostkam/trevoga-i-perezhivaniya/stress-i-silnye-perezhivaniya/` | inner | Текст страницы |
| `/podrostkam/neuverennost-v-sebe/` | inner | Текст страницы |
| `/podrostkam/neuverennost-v-sebe/sravnenie-sebya-s-drugimi/` | inner | Текст страницы |
| `/podrostkam/neuverennost-v-sebe/strah-neudachi-i-oshibok/` | inner | Текст страницы |
| `/podrostkam/neuverennost-v-sebe/rabota-nad-samootsenkoy/` | inner | Текст страницы |
| `/podrostkam/otnosheniya-s-roditelyami/` | inner | Текст страницы |
| `/podrostkam/otnosheniya-s-roditelyami/konflikty-i-sposoby-ih-resheniya/` | inner | Текст страницы |
| `/podrostkam/otnosheniya-s-roditelyami/kak-govorit-o-slozhnom/` | inner | Текст страницы |
| `/podrostkam/emotsionalnye-perepady-i-trudnosti-s-upravleniem-emotsiyami/` | inner | Текст страницы |
| `/podrostkam/emotsionalnye-perepady-i-trudnosti-s-upravleniem-emotsiyami/raspoznavanie-svoih-emotsiy/` | inner | Текст страницы |
| `/podrostkam/emotsionalnye-perepady-i-trudnosti-s-upravleniem-emotsiyami/tehniki-samoregulyatsii/` | inner | Текст страницы |
| `/podrostkam/emotsionalnye-perepady-i-trudnosti-s-upravleniem-emotsiyami/kogda-stoit-obratitsya-za-podderzhkoy/` | inner | Текст страницы |
| `/podrostkam/ucheba-i-motivatsiya/` | inner | Текст страницы |
| `/podrostkam/poisk-sebya/` | inner | Текст страницы |
| `/roditelyam/` | inner | Текст страницы |
| `/spetsialistam/` | inner | Текст страницы |
| `/materialy/` | inner | Текст страницы |
| `/testy/` | inner | Текст страницы |
| `/vebinary/` | inner | Текст страницы |

Главная: 17 инфоблоков; «О проекте»: 6; блог: 3. Число отличается от Medelta, потому что сохранено смысловое разбиение предоставленной новой вёрстки.
Данные специалистов и статей общие для списков, подборок и подробных страниц.
Шаблоны подборок имеют собственный `RecordTemplateFull.html`, включающий родительский через `$nc_parent_field_path`.

`zhp_articles_related` — шаблон связанных статей без дублирования записей.
`zhp_articles.support_img` — файловое поле иллюстрации поддержки в статье.
