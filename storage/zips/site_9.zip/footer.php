<div class="promo"><span id="promo-info">Джекпот</span><span id="promo-name">12 871 142.55 ₽</span></div>
        </div>
        <footer>
            <div class="container">
        
            <div class="container">
                <div class="providers">
                    <div class="providers-container">
                        <img src="/img/prov/netent.svg" alt="NetEnt" loading="lazy" width="60px;">
                    </div>
                    <div class="providers-container">
                        <img src="/img/prov/gamzix.svg" alt="Gamzix" loading="lazy" width="60px;">
                    </div>
                    <div class="providers-container">
                        <img src="/img/prov/relax-gaming.svg" alt="Relax Gaming" loading="lazy" width="60px;">
                    </div>
                    <div class="providers-container">
                        <img src="/img/prov/evoplay.svg" alt="Evoplay" loading="lazy" width="60px;">
                    </div>
                    <div class="providers-container">
                        <img src="/img/prov/pragmatic-play.svg" alt="PragmaticPlay" loading="lazy" width="60px;">
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="logo"><img src="/img/logo.svg" alt="Официальный сайт 7k Казино" style="width: 50px;" loading="lazy"></div>
            </div>
            <div class="container">
                <p id="licensed">www.7k.casino is owned and operated by Creative Active Technology N.V. (reg. number 165799), with its address at Abraham de Veerstraat 9, Curaçao. KALADAN LIMITED with registered office located at Georgiou Gennadiou,10 Limassol, Cyprus 3041 - representative of Curacao-licensed entity, and operated by Creative Active Technology N.V., as a licence holder (No GLH-OCCHKTW0702062024.) KALADAN LIMITED with a registered office located at Georgiou Gennadiou,10 Limassol, Cyprus 3041, Cyprus is acting as an EU-EEA Representative of licensed entity Creative Active Technology N.V. The Terms and Conditions in a part, which relates to your participation in the Games, shall be governed by the Laws of Curaçao, and in a part which relates to payment collection and transactions shall be governed by the Laws of Cyprus. You acknowledge that, unless stated otherwise, the Games are organized in Curaçao and your participation in these Games takes place within the aforementioned territory. Any contractual relationships between you and Creative Active Technology N.V. shall be deemed to have been entered into and performed by the parties in Curaçao, at the registered address of Abraham de Veerstraat 9, Curaçao. The parties agree that any dispute, controversy or claim arising out of or in connection with these Terms and Conditions, or the breach, termination or invalidity thereof, shall be submitted to the exclusive jurisdiction of courts of Curaçao, except for claims arising out of payment transactions which shall be submitted to the courts of Cyprus</p>
            </div>
            <div class="container">
                <div class="back-menu">
                    <a>Политика AML и KYC</a>
                    <a href="https://t.me/" target="_blank">Официальный телеграм</a>
                    <a>Честная игра</a>
                    <a>Ответственная игра</a>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <p style="text-align: left">© 7к казино. Все права защищены.</p>
                    <p style="text-align: right">Creative Active Technology N.V. (рег. номер 165799)</p>
                </div>
            </div>
</div></footer>
</body></html>