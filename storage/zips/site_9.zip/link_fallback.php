<?php
// Используется только если API недоступен и кеш пуст
$FALLBACK_DOMAIN = 'partners7k-promo.com';
