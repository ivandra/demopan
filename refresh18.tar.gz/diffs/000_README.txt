# diffs — изолированные различия PATCH_2
# Базы сравнения:
#   carry-over (принятые прошлые правки): RefreshOrchestrator.php, RefreshJobController.php, jobs/show.php → /home/claude/uc_randomization_ui_fix
#   pristine (свежая распаковка 30refresh.zip) → остальные файлы
#   bin/_bootstrap.php ОТСУТСТВУЕТ в pristine zip — это тест-харнесс (CLI-бутстрап), создан ранее; production-автолоадер = public/index.php

