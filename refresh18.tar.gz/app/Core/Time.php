<?php

/**
 * Time::msk() — единый helper для отображения серверных DATETIME в МСК.
 *
 * Контекст архитектуры (v18.1.25+):
 *   - PHP запускается в UTC (date_default_timezone_set('UTC') в public/index.php)
 *   - MySQL принудительно установлен в UTC (DB::connect() делает SET time_zone='+00:00')
 *   - Все timestamp в БД (created_at, stage_started_at, next_run_at, last_checked_at и т.д.)
 *     хранятся в UTC. Это обязательно для корректной работы cron-логики, retry-задержек,
 *     сравнения времени между джобами и т.д.
 *   - Но человек-оператор в МСК (UTC+3). Для UI поэтому конвертируем UTC → МСК
 *     ТОЛЬКО на отображение, ничего в БД не меняя.
 *
 * Эта утилита унифицирует конвертацию во всех views/controllers.
 * Раньше каждый view определял свой $fmtMsk closure — теперь один статический helper.
 */
class Time
{
    /**
     * Конвертировать UTC datetime-строку из БД в человекочитаемый МСК.
     *
     * @param string|null $serverDatetime Строка вида '2026-05-12 16:00:00' (UTC)
     * @param string $format Формат вывода (по умолчанию 'Y-m-d H:i')
     * @param bool $appendLabel Добавлять ' МСК' в конце
     * @return string
     */
    public static function msk(?string $serverDatetime, string $format = 'Y-m-d H:i', bool $appendLabel = true): string
    {
        if ($serverDatetime === null || $serverDatetime === ''
            || $serverDatetime === '0000-00-00 00:00:00') {
            return '?';
        }
        try {
            // Явно указываем UTC, чтобы не зависеть от php default
            // (он сейчас UTC, но мало ли — лучше be explicit).
            $dt = new \DateTime($serverDatetime, new \DateTimeZone('UTC'));
            $dt->setTimezone(new \DateTimeZone('Europe/Moscow'));
            return $dt->format($format) . ($appendLabel ? ' МСК' : '');
        } catch (\Throwable $e) {
            return $serverDatetime;
        }
    }

    /**
     * Короткая версия — секунды тоже показываем. Полезно для events/log.
     */
    public static function mskFull(?string $serverDatetime): string
    {
        return self::msk($serverDatetime, 'Y-m-d H:i:s', true);
    }

    /**
     * Только дата + время без секунд и без 'МСК' (для tooltip'ов и UI с экономией места).
     */
    public static function mskShort(?string $serverDatetime): string
    {
        return self::msk($serverDatetime, 'Y-m-d H:i', false);
    }

    /**
     * Текущее время в МСК для подписей "сейчас XX:YY МСК".
     */
    public static function nowMsk(string $format = 'Y-m-d H:i:s'): string
    {
        return (new \DateTime('now', new \DateTimeZone('Europe/Moscow')))->format($format);
    }
}
