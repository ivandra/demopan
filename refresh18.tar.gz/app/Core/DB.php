<?php

class DB
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo instanceof PDO) return self::$pdo;
        self::$pdo = self::connect();
        return self::$pdo;
    }

    public static function reset(): void
    {
        self::$pdo = null;
    }

    public static function reconnect(): PDO
    {
        self::$pdo = null;
        self::$pdo = self::connect();
        return self::$pdo;
    }

    public static function withReconnect(callable $fn)
    {
        try {
            return $fn(self::pdo());
        } catch (PDOException $e) {
            $msg = $e->getMessage();
            $needReconnect =
                stripos($msg, 'server has gone away') !== false ||
                stripos($msg, 'Packets out of order') !== false ||
                stripos($msg, 'Lost connection') !== false ||
                stripos($msg, 'MySQL server has gone away') !== false;

            if (!$needReconnect) throw $e;

            self::reset();
            return $fn(self::pdo());
        }
    }

    private static function connect(): PDO
    {
        $cfg = require Paths::appRoot() . '/config/db.php';

        $host = (string)($cfg['host'] ?? 'localhost');
        $port = (int)($cfg['port'] ?? 3306);
        $name = (string)($cfg['db'] ?? ($cfg['name'] ?? ''));
        $user = (string)($cfg['user'] ?? '');
        $pass = (string)($cfg['pass'] ?? '');

        if ($name === '' || $user === '') {
            throw new RuntimeException('DB config missing: check config/db.php');
        }

        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";

        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_PERSISTENT         => false,
        ]);
        $pdo->exec("SET NAMES utf8mb4");
        // v18.1.25: ВАЖНО — заставляем MySQL отдавать NOW()/DATE_ADD/etc в UTC.
        // PHP уже в UTC (date_default_timezone_set('UTC') в public/index.php).
        // Без этого MySQL использует timezone сервера (часто МСК на VPS в России),
        // и next_run_at писался в МСК но потом PHP интерпретировал его как UTC
        // через strtotime() → UI показывал "через 89 минут" хотя на самом деле
        // через 30 секунд. Cron picker работал правильно (всё в MySQL),
        // ломалось только отображение.
        $pdo->exec("SET time_zone = '+00:00'");
        return $pdo;
    }
}
