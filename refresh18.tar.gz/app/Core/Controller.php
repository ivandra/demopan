<?php

abstract class Controller
{
    protected function view(string $path, array $data = []): void
    {
        $data['__view'] = $path;
        extract($data);
        $layout = Paths::appRoot() . '/app/Views/layout.php';
        require $layout;
    }

    protected function viewRaw(string $path, array $data = []): void
    {
        extract($data);
        $file = Paths::appRoot() . '/app/Views/' . ltrim($path, '/') . '.php';
        require $file;
    }

    protected function flash(string $type, string $message): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        if (!isset($_SESSION['flash']) || !is_array($_SESSION['flash'])) {
            $_SESSION['flash'] = [];
        }
        if (!isset($_SESSION['flash'][$type]) || !is_array($_SESSION['flash'][$type])) {
            $_SESSION['flash'][$type] = [];
        }
        $_SESSION['flash'][$type][] = $message;
    }

    protected function redirect(string $url): void
    {
        if (!headers_sent()) {
            header('Location: ' . $url, true, 302);
            exit;
        }
        echo '<meta http-equiv="refresh" content="0;url=' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">';
        exit;
    }

    protected function requireAuth(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        if (empty($_SESSION['auth']) || $_SESSION['auth'] !== true) {
            $this->redirect('/login');
        }
    }

    protected function jsonOk(array $data = []): void
    {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => true] + $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    protected function jsonErr(string $msg, int $code = 400): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * v25.2-a1.6.4.1 PATCH_2 (§18): session-bound CSRF token.
     * Токен привязан к сессии пользователя.
     */
    protected function csrfToken(): string
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /**
     * Проверить CSRF-токен из POST. При неверном/отсутствующем — HTTP 403 и
     * НЕМЕДЛЕННЫЙ выход (никаких side-effect: ни FTP, ни UPDATE не выполняются).
     */
    protected function requireCsrf(): void
    {
        if (!$this->csrfValid()) {
            http_response_code(403);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'CSRF token invalid';
            exit;
        }
    }

    /** Валиден ли CSRF-токен (тестируемое ядро requireCsrf). */
    public function csrfValid(): bool
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $sent = (string)($_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
        $have = (string)($_SESSION['csrf_token'] ?? '');
        return $have !== '' && $sent !== '' && hash_equals($have, $sent);
    }
}
