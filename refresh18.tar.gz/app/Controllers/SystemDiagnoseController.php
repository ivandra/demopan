<?php

class SystemDiagnoseController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();

        // PHP info
        $phpVersion = PHP_VERSION;
        $extensions = ['pdo_mysql', 'openssl', 'curl', 'ftp', 'mbstring', 'json'];
        $extStatus = [];
        foreach ($extensions as $e) {
            $extStatus[$e] = extension_loaded($e);
        }

        // App version markers
        $appKey = (string)config('app_key', '');
        $hasAppKey = $appKey !== '' && $appKey !== 'CHANGE_ME_TO_RANDOM_32_CHARS_STRING_XYZ';

        // v18.1.20: cron_state — критично для понимания работает ли крон вообще
        $cronStates = $this->loadCronStates();

        // v18.1.20: подсчёт джоб которые ждут крона
        $pendingJobs = $this->loadPendingJobs();

        // Syntax check all PHP files of the panel
        $appRoot = Paths::appRoot();
        $phpFiles = $this->findPhpFiles($appRoot);
        $syntaxIssues = [];
        $syntaxOk = [];
        foreach ($phpFiles as $f) {
            $rel = str_replace($appRoot . '/', '', $f);
            $check = $this->checkPhpSyntax($f);
            if ($check['ok']) {
                $syntaxOk[] = ['file' => $rel, 'lines' => $check['lines'], 'size' => $check['size']];
            } else {
                $syntaxIssues[] = ['file' => $rel, 'error' => $check['error'], 'lines' => $check['lines'], 'size' => $check['size']];
            }
        }

        // Storage check
        $storageWritable = is_writable(Paths::storageRoot());
        $sessionsDir = Paths::storage('sessions');
        $sessionsWritable = is_writable($sessionsDir);

        $this->view('system/diagnose', [
            'phpVersion' => $phpVersion,
            'extStatus' => $extStatus,
            'hasAppKey' => $hasAppKey,
            'syntaxOk' => $syntaxOk,
            'syntaxIssues' => $syntaxIssues,
            'storageWritable' => $storageWritable,
            'sessionsWritable' => $sessionsWritable,
            'sessionsDir' => $sessionsDir,
            'cronStates' => $cronStates,
            'pendingJobs' => $pendingJobs,
            'webmasterRouting' => $this->loadWebmasterRoutingDiagnostics(),
        ]);
    }

    /**
     * ТЗ047 §50: диагностика исходящей маршрутизации Yandex.Webmaster (DB-часть).
     * Проверяет консистентность пула/default и ссылочную целостность назначений.
     */
    private function loadWebmasterRoutingDiagnostics(): array
    {
        $out = ['available' => false, 'checks' => [], 'pool' => []];
        try {
            $pdo = DB::pdo();
            // таблицы могут отсутствовать до применения миграции 047
            $has = $pdo->query("SHOW TABLES LIKE 'webmaster_outbound_ips'")->fetch();
            if (!$has) return $out;
            $out['available'] = true;

            $defCount = (int)$pdo->query("SELECT COUNT(*) FROM webmaster_outbound_ips WHERE is_default=1 AND is_enabled=1")->fetchColumn();
            $defIp = $pdo->query("SELECT ip_address FROM webmaster_outbound_ips WHERE is_default=1 AND is_enabled=1 LIMIT 1")->fetchColumn();
            $out['checks'][] = ['label' => 'Default IP существует и включён', 'ok' => ($defCount >= 1),
                'detail' => $defIp ? (string)$defIp : 'нет'];
            $out['checks'][] = ['label' => 'Ровно один enabled default (count=1)', 'ok' => ($defCount === 1),
                'detail' => "count={$defCount}"];

            foreach ($pdo->query("SELECT ip_address, label, is_enabled FROM webmaster_outbound_ips ORDER BY is_default DESC, id ASC")->fetchAll() as $ip) {
                $out['pool'][] = ['ip' => (string)$ip['ip_address'], 'label' => (string)$ip['label'],
                    'enabled' => ((int)$ip['is_enabled'] === 1)];
            }

            $missing = (int)$pdo->query(
                "SELECT COUNT(*) FROM yandex_webmaster_accounts a
                  WHERE a.outbound_ip_id IS NOT NULL
                    AND NOT EXISTS (SELECT 1 FROM webmaster_outbound_ips i WHERE i.id=a.outbound_ip_id)"
            )->fetchColumn();
            $disabled = (int)$pdo->query(
                "SELECT COUNT(*) FROM yandex_webmaster_accounts a
                   JOIN webmaster_outbound_ips i ON i.id=a.outbound_ip_id WHERE i.is_enabled=0"
            )->fetchColumn();
            $out['checks'][] = ['label' => 'Аккаунтов с несуществующей ссылкой IP', 'ok' => ($missing === 0), 'detail' => (string)$missing];
            $out['checks'][] = ['label' => 'Аккаунтов на выключенном assigned IP', 'ok' => ($disabled === 0), 'detail' => (string)$disabled];

            // Архитектурный инвариант: единый transport присутствует (роутинг централизован).
            $out['checks'][] = ['label' => 'Raw Yandex cURL bypass (единый transport)', 'ok' => class_exists('YandexWebmasterHttpTransport'),
                'detail' => class_exists('YandexWebmasterHttpTransport') ? 'transport активен' : 'transport отсутствует'];
        } catch (\Throwable $e) {
            $out['error'] = $e->getMessage();
        }
        return $out;
    }

    /**
     * v18.1.20: ручной запуск cron из UI диагностики.
     *
     * Делает HTTP-вызов на /cron?token=... своему же сайту и показывает ответ.
     * Это самый надёжный способ убедиться что cron-эндпоинт жив. Если хостинг-cron
     * не работает, оператор увидит здесь нормальный ответ и поймёт что проблема
     * не в коде, а в настройке cron на хостинге.
     */
    public function runCron(): void
    {
        $this->requireAuth();

        $token = (string)config('cron.token', '');
        if ($token === '') {
            $this->flash('error',
                'cron.token не настроен в config — нечего вызывать. Проверь config/app.php');
            $this->redirect('/system/diagnose');
        }

        // Используем тот же домен на котором мы сейчас работаем
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $url = $scheme . '://' . $host . '/cron?token=' . rawurlencode($token);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60, // step джобы может занять время
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_USERAGENT => 'refresh-panel-diagnose-cron-trigger/1.0',
        ]);
        $startedAt = microtime(true);
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $elapsed = (int)((microtime(true) - $startedAt) * 1000);
        curl_close($ch);

        if ($body === false) {
            $this->flash('error',
                "Ручной запуск cron упал: curl error: {$err}");
        } else {
            // Маскируем токен в URL для отображения
            $urlMasked = preg_replace('~token=[^&]+~', 'token=***', $url);
            $bodySafe = mb_substr((string)$body, 0, 2000);
            $msg = "✓ Cron вызван (HTTP {$httpCode}, {$elapsed} мс). URL: {$urlMasked}\n\n"
                 . "Ответ:\n" . $bodySafe;
            $this->flash('success', $msg);
        }

        $this->redirect('/system/diagnose');
    }

    /**
     * v18.1.28: ручное обновление балансов Namecheap + XMLStock.
     * Дёргается из status-bar в шапке (POST /system/balance/refresh).
     */
    public function refreshBalances(): void
    {
        $this->requireAuth();

        try {
            $checker = new BalanceCheckService();
            $results = $checker->checkAll('manual');

            $okCount = 0; $lowCount = 0; $errCount = 0;
            $details = [];
            foreach ($results as $key => $r) {
                if (empty($r['ok'])) {
                    $errCount++;
                    $details[] = "✗ {$key}: " . (string)($r['error'] ?? '?');
                    continue;
                }
                if (($r['status'] ?? '') === 'low') {
                    $lowCount++;
                    $bal = number_format((float)$r['balance'], 2);
                    $details[] = "⚠ {$key}: {$bal} {$r['currency']} (НИЖЕ порога)";
                } else {
                    $okCount++;
                    $bal = number_format((float)$r['balance'], 2);
                    $details[] = "✓ {$key}: {$bal} {$r['currency']}";
                }
            }

            $summary = "Балансы обновлены: ✓ {$okCount}, ⚠ {$lowCount}, ✗ {$errCount}.\n" .
                       implode("\n", $details);
            $this->flash($errCount > 0 ? 'warning' : 'success', $summary);
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка обновления балансов: ' . $e->getMessage());
        }

        // Возвращаемся туда откуда нажали
        $referer = (string)($_SERVER['HTTP_REFERER'] ?? '/');
        $this->redirect($referer);
    }

    /** v18.1.20: загрузить состояния всех cron'ов. */
    private function loadCronStates(): array
    {
        try {
            $rows = DB::pdo()->query(
                "SELECT cron_name, last_run_at, last_ok, last_error, stats_json,
                        TIMESTAMPDIFF(SECOND, last_run_at, NOW()) AS seconds_ago
                 FROM cron_state
                 ORDER BY cron_name"
            )->fetchAll();
            return $rows ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** v18.1.20: список джоб ждущих крон. */
    private function loadPendingJobs(): array
    {
        try {
            $rows = DB::pdo()->query(
                "SELECT id, old_domain, new_domain, stage, stage_status,
                        next_run_at,
                        TIMESTAMPDIFF(SECOND, IFNULL(stage_finished_at, created_at), NOW()) AS waiting_sec
                 FROM refresh_jobs
                 WHERE stage NOT IN ('done','failed','cancelled','superseded')
                   AND (
                       (stage_status IN ('pending','ok') AND (next_run_at IS NULL OR next_run_at <= NOW()))
                       OR (stage_status = 'running' AND stage_started_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE))
                       OR (stage_status = 'awaiting_user' AND next_run_at IS NOT NULL AND next_run_at <= NOW())
                   )
                 ORDER BY id"
            )->fetchAll();
            return $rows ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function findPhpFiles(string $dir): array
    {
        $out = [];
        $skip = ['/storage/', '/.git/'];
        $rdi = new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS);
        $rii = new RecursiveIteratorIterator($rdi);
        foreach ($rii as $f) {
            if (!$f->isFile()) continue;
            $path = $f->getPathname();
            if (substr($path, -4) !== '.php') continue;
            $skipThis = false;
            foreach ($skip as $s) {
                if (strpos($path, $s) !== false) { $skipThis = true; break; }
            }
            if ($skipThis) continue;
            $out[] = $path;
        }
        sort($out);
        return $out;
    }

    private function checkPhpSyntax(string $file): array
    {
        $size = (int)@filesize($file);
        $content = @file_get_contents($file);
        if ($content === false) {
            return ['ok' => false, 'error' => 'Не удалось прочитать файл', 'lines' => 0, 'size' => $size];
        }
        $lines = substr_count($content, "\n") + 1;

        // Use php -l if available
        $phpBinary = $this->detectPhpBinary();
        if ($phpBinary !== null) {
            $tmp = @tempnam(sys_get_temp_dir(), 'rfr_lint_');
            if ($tmp) {
                @file_put_contents($tmp, $content);
                $cmd = escapeshellcmd($phpBinary) . ' -l ' . escapeshellarg($tmp) . ' 2>&1';
                $out = @shell_exec($cmd);
                @unlink($tmp);
                if ($out !== null) {
                    if (stripos($out, 'No syntax errors') !== false) {
                        return ['ok' => true, 'lines' => $lines, 'size' => $size];
                    }
                    return ['ok' => false, 'error' => trim($out), 'lines' => $lines, 'size' => $size];
                }
            }
        }

        // Fallback: токен-чек через php_check_syntax (deprecated) или
        // попробуем подгрузить через выгрузку в include с output buffering.
        // Самый надёжный без php -l — token_get_all с подавлением.
        $err = null;
        set_error_handler(function ($severity, $message, $file, $line) use (&$err) {
            $err = "PHP error: {$message} ({$file}:{$line})";
        });
        try {
            $tokens = @token_get_all($content, TOKEN_PARSE);
        } catch (Throwable $e) {
            restore_error_handler();
            return ['ok' => false, 'error' => $e->getMessage(), 'lines' => $lines, 'size' => $size];
        }
        restore_error_handler();
        if ($err !== null) {
            return ['ok' => false, 'error' => $err, 'lines' => $lines, 'size' => $size];
        }
        return ['ok' => true, 'lines' => $lines, 'size' => $size];
    }

    private function detectPhpBinary(): ?string
    {
        $candidates = ['php', '/usr/bin/php', '/usr/local/bin/php'];
        foreach ($candidates as $c) {
            $check = @shell_exec(escapeshellcmd($c) . ' -v 2>&1');
            if ($check && stripos($check, 'PHP') !== false) {
                return $c;
            }
        }
        return null;
    }
}
