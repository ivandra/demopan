<?php

class InstallController extends Controller
{
    public function show(): void
    {
        // Проверим что DB вообще доступна
        $dbOk = false;
        $dbError = '';
        try {
            DB::pdo()->query("SELECT 1");
            $dbOk = true;
        } catch (Throwable $e) {
            $dbError = $e->getMessage();
        }

        // Список миграций и их статус
        $migrator = new Migrator();
        $list = $migrator->listMigrations();
        $applied = [];
        if ($dbOk) {
            try { $applied = $migrator->appliedNames(); } catch (Throwable $e) {}
        }

        $this->viewRaw('install/index', [
            'dbOk' => $dbOk,
            'dbError' => $dbError,
            'migrations' => $list,
            'applied' => $applied,
        ]);
    }

    public function run(): void
    {
        try {
            $migrator = new Migrator();
            $report = $migrator->migrate();
        } catch (Throwable $e) {
            $this->flash('error', 'Не удалось применить миграции: ' . $e->getMessage());
            $this->redirect('/install');
        }

        if (empty($report['ok'])) {
            $this->flash('error', 'Миграции применены частично. Ошибки: ' . implode('; ', $report['errors']));
            $this->redirect('/install');
        }

        $msg = empty($report['ran'])
            ? 'Все миграции уже были применены'
            : 'Применены миграции: ' . implode(', ', $report['ran']);
        $this->flash('success', $msg . '. Установка завершена.');
        $this->redirect('/login');
    }
}
