<?php

/**
 * Контроллер проверки и сохранения OAuth-токенов Yandex.Webmaster.
 *
 * Маршруты:
 *   GET  /system/webmaster-tokens          — главная страница (форма + список)
 *   POST /system/webmaster-tokens/check    — AJAX: проверка токена через API Webmaster
 *   POST /system/webmaster-tokens/save     — сохранить токен в БД
 *   POST /system/webmaster-tokens/delete   — удалить аккаунт
 *   POST /system/webmaster-tokens/recheck  — перепроверить уже сохранённый токен
 *
 * Используется для Шага 2 в инструкции получения OAuth-токенов: ты получаешь
 * токены через Implicit Flow на oauth.yandex.ru, потом приходишь сюда, вставляешь
 * каждый — панель проверяет и сохраняет.
 *
 * В v15 этот контроллер расширится UI для Code Flow (кнопка «Подключить через
 * Яндекс»).
 */
class WebmasterTokenController extends Controller
{
    /** Главная страница */
    public function index(): void
    {
        $this->requireAuth();
        $pdo = DB::pdo();
        // Аккаунты + адрес назначенного исходящего IP (или NULL=DEFAULT).
        $rows = $pdo->query(
            "SELECT a.*, i.ip_address AS outbound_ip_address, i.is_enabled AS outbound_ip_enabled
               FROM yandex_webmaster_accounts a
               LEFT JOIN webmaster_outbound_ips i ON i.id = a.outbound_ip_id
              ORDER BY a.is_default DESC, a.id ASC"
        )->fetchAll();

        // Пул исходящих IP + счётчики назначений (§22/§34).
        $ips = $pdo->query("SELECT * FROM webmaster_outbound_ips ORDER BY is_default DESC, id ASC")->fetchAll();
        $counts = [];
        foreach ($pdo->query("SELECT outbound_ip_id, COUNT(*) c FROM yandex_webmaster_accounts GROUP BY outbound_ip_id")->fetchAll() as $cr) {
            $counts[$cr['outbound_ip_id'] === null ? 'null' : (int)$cr['outbound_ip_id']] = (int)$cr['c'];
        }
        $defaultIp = null; $defaultId = null;
        foreach ($ips as $ip) { if ((int)$ip['is_default'] === 1 && (int)$ip['is_enabled'] === 1) { $defaultIp = $ip['ip_address']; $defaultId = (int)$ip['id']; } }

        $this->view('system/webmaster_tokens', [
            'rows' => $rows,
            'ips' => $ips,
            'ip_counts' => $counts,
            'default_ip' => $defaultIp,
            'default_ip_id' => $defaultId,
            'csrf' => $this->csrfToken(),
        ]);
    }

    /**
     * AJAX endpoint для проверки токена через API Webmaster.
     * Возвращает JSON: { ok, user_id, hosts: [{host_id, ascii_host_url, verified}], error }
     */
    public function check(): void
    {
        $this->requireAuth();

        $token = trim((string)($_POST['access_token'] ?? ''));
        if ($token === '') {
            $this->jsonErr('Токен пустой', 400);
            return;
        }

        // PATCH 047 §26: выбранный исходящий IP (или DEFAULT) — проверяем токен ИМЕННО через него.
        $ipId = isset($_POST['outbound_ip_id']) && $_POST['outbound_ip_id'] !== '' ? (int)$_POST['outbound_ip_id'] : null;
        try {
            $sel = $this->outboundIpForNewToken($ipId);
        } catch (WebmasterTransportException $e) {
            $this->jsonErr('Исходящий IP: ' . $e->getMessage(), 400);
            return;
        }
        $expectedIp = $sel['ip'];
        $ctx = ['webmaster_account_id' => 0, 'refresh_job_id' => null, 'stage' => 'token_check'];

        // 1) Получаем user_id
        $userResp = $this->apiCall('GET', '/v4/user', $token, $expectedIp, $ctx);

        if (!$userResp['ok']) {
            $this->jsonErr(
                'Не удалось проверить токен через ' . $expectedIp . ': ' . $userResp['error'],
                $userResp['http_code'] ?: 400
            );
            return;
        }

        $userData = json_decode($userResp['body'], true);
        $userId = (int)($userData['user_id'] ?? 0);
        if ($userId <= 0) {
            $this->jsonErr('API не вернул user_id', 400);
            return;
        }

        // 2) Получаем список сайтов через ТОТ ЖЕ IP
        $hostsResp = $this->apiCall('GET', "/v4/user/{$userId}/hosts", $token, $expectedIp, $ctx);

        $hosts = [];
        if ($hostsResp['ok']) {
            $hostsData = json_decode($hostsResp['body'], true);
            if (is_array($hostsData) && !empty($hostsData['hosts']) && is_array($hostsData['hosts'])) {
                foreach ($hostsData['hosts'] as $h) {
                    if (!is_array($h)) continue;
                    $hosts[] = [
                        'host_id' => (string)($h['host_id'] ?? ''),
                        'unicode_host_url' => (string)($h['unicode_host_url'] ?? $h['ascii_host_url'] ?? ''),
                        'ascii_host_url' => (string)($h['ascii_host_url'] ?? ''),
                        'verified' => (bool)($h['verified'] ?? false),
                    ];
                }
            }
        }

        $this->jsonOk([
            'user_id' => $userId,
            'host_count' => count($hosts),
            'hosts' => array_slice($hosts, 0, 20), // первые 20 для UI
            'has_more' => count($hosts) > 20,
            // §26/§53: явно показываем, ЧЕРЕЗ КАКОЙ IP проверено.
            'outbound_ip_id' => $sel['id'],
            'outbound_ip_expected' => $expectedIp,
            'outbound_ip_actual' => (string)$userResp['actual_local_ip'],
            'source_ip_verified' => (bool)$userResp['source_ip_verified'],
        ]);
    }

    /** Сохранить новый аккаунт в БД */
    public function save(): void
    {
        $this->requireAuth();

        $token = trim((string)($_POST['access_token'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $label = trim((string)($_POST['label'] ?? ''));
        $note = trim((string)($_POST['note'] ?? ''));
        $isDefault = !empty($_POST['is_default']) ? 1 : 0;
        // expires_in приходит из Implicit Flow (по дефолту 1 год)
        $expiresInSec = (int)($_POST['expires_in'] ?? 31536000);

        if ($token === '' || $email === '') {
            $this->flash('error', 'Email и токен обязательны');
            $this->redirect('/system/webmaster-tokens');
            return;
        }

        // PATCH 047 §27: НЕ доверяем hidden-полю. Заново резолвим выбранный IP на сервере
        // и повторно валидируем токен именно через него.
        $ipId = isset($_POST['outbound_ip_id']) && $_POST['outbound_ip_id'] !== '' ? (int)$_POST['outbound_ip_id'] : null;
        try {
            $sel = $this->outboundIpForNewToken($ipId);
        } catch (WebmasterTransportException $e) {
            $this->flash('error', 'Исходящий IP: ' . $e->getMessage());
            $this->redirect('/system/webmaster-tokens');
            return;
        }
        $expectedIp = $sel['ip'];
        $ctx = ['webmaster_account_id' => 0, 'refresh_job_id' => null, 'stage' => 'token_save'];

        // Проверяем токен ещё раз перед сохранением — через выбранный IP
        $userResp = $this->apiCall('GET', '/v4/user', $token, $expectedIp, $ctx);
        if (!$userResp['ok']) {
            $this->flash('error', 'Токен невалиден (через ' . $expectedIp . '): ' . $userResp['error']);
            $this->redirect('/system/webmaster-tokens');
            return;
        }
        $userData = json_decode($userResp['body'], true);
        $userId = (int)($userData['user_id'] ?? 0);
        if ($userId <= 0) {
            $this->flash('error', 'API не вернул user_id');
            $this->redirect('/system/webmaster-tokens');
            return;
        }

        // Проверяем количество сайтов через тот же IP
        $hostCount = 0;
        $hostsResp = $this->apiCall('GET', "/v4/user/{$userId}/hosts", $token, $expectedIp, $ctx);
        if ($hostsResp['ok']) {
            $hostsData = json_decode($hostsResp['body'], true);
            if (is_array($hostsData) && !empty($hostsData['hosts'])) {
                $hostCount = count($hostsData['hosts']);
            }
        }

        $expiresAt = (new DateTime('now'))->modify('+' . max(60, $expiresInSec) . ' seconds')->format('Y-m-d H:i:s');

        // Сбросить is_default у других если этот = default
        if ($isDefault) {
            DB::pdo()->exec("UPDATE yandex_webmaster_accounts SET is_default=0");
        }

        // Upsert по email (PATCH 047: сохраняем outbound_ip_id + снапшот подтверждённого IP)
        $st = DB::pdo()->prepare(
            "INSERT INTO yandex_webmaster_accounts
                (label, email, yandex_user_id, access_token_enc, token_expires_at,
                 flow_type, is_default, last_validated_at, last_validation_ok,
                 host_count, note, outbound_ip_id,
                 last_outbound_ip_expected, last_outbound_ip_actual, last_outbound_verified_at, last_outbound_ok)
             VALUES (?, ?, ?, ?, ?, 'implicit', ?, NOW(), 1, ?, ?, ?, ?, ?, NOW(), 1)
             ON DUPLICATE KEY UPDATE
                label = VALUES(label),
                yandex_user_id = VALUES(yandex_user_id),
                access_token_enc = VALUES(access_token_enc),
                token_expires_at = VALUES(token_expires_at),
                is_default = VALUES(is_default),
                last_validated_at = NOW(),
                last_validation_ok = 1,
                last_validation_error = NULL,
                host_count = VALUES(host_count),
                note = VALUES(note),
                outbound_ip_id = VALUES(outbound_ip_id),
                last_outbound_ip_expected = VALUES(last_outbound_ip_expected),
                last_outbound_ip_actual = VALUES(last_outbound_ip_actual),
                last_outbound_verified_at = NOW(),
                last_outbound_ok = 1"
        );

        $st->execute([
            $label !== '' ? $label : $email,
            $email,
            $userId,
            Crypto::encrypt($token),
            $expiresAt,
            $isDefault,
            $hostCount,
            $note !== '' ? $note : null,
            $sel['id'],
            $expectedIp,
            (string)$userResp['actual_local_ip'],
        ]);

        $this->flash('success',
            "Аккаунт {$email} сохранён (user_id={$userId}, сайтов: {$hostCount}, исходящий IP {$expectedIp})");
        $this->redirect('/system/webmaster-tokens');
    }

    /** Удалить аккаунт */
    public function delete(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->flash('error', 'Не указан id');
            $this->redirect('/system/webmaster-tokens');
            return;
        }
        $block = $this->accountDeleteBlockReason($id);
        if ($block !== null) {
            $this->flash('error', "Нельзя удалить Webmaster account #{$id}. " . $block);
            $this->redirect('/system/webmaster-tokens');
            return;
        }
        DB::pdo()->prepare("DELETE FROM yandex_webmaster_accounts WHERE id=?")->execute([$id]);
        $this->flash('success', 'Аккаунт удалён');
        $this->redirect('/system/webmaster-tokens');
    }

    /**
     * PATCH 048 §25/§26: до удаления аккаунта проверить, что к нему нет постоянно
     * привязанных сайтов и нет активных джоб с immutable-snapshot этого аккаунта.
     * Возвращает человекочитаемую причину-запрет или null (можно удалять).
     */
    private function accountDeleteBlockReason(int $accountId): ?string
    {
        $pdo = DB::pdo();
        try {
            $col = $pdo->query("SHOW COLUMNS FROM sites_managed LIKE 'webmaster_account_id'");
            if ($col && $col->fetch()) {
                $sites = (int)$pdo->query(
                    "SELECT COUNT(*) FROM sites_managed WHERE webmaster_account_id = " . (int)$accountId
                )->fetchColumn();
                if ($sites > 0) {
                    return "К аккаунту #{$accountId} постоянно привязано сайтов: {$sites}. "
                        . "Сначала переназначьте или снимите привязку этих сайтов.";
                }
            }
        } catch (\Throwable $e) { /* до миграции 048 колонки нет — пропускаем */ }
        $activeJobs = (int)$pdo->query(
            "SELECT COUNT(*) FROM refresh_jobs
              WHERE webmaster_account_override_id = " . (int)$accountId . "
                AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->fetchColumn();
        if ($activeJobs > 0) {
            return "Аккаунт #{$accountId} используется активными джобами: {$activeJobs} "
                . "(у них зафиксирован snapshot этого аккаунта). Дождитесь их завершения.";
        }
        return null;
    }

    /** Перепроверить уже сохранённый токен */
    public function recheck(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->flash('error', 'Не указан id');
            $this->redirect('/system/webmaster-tokens');
            return;
        }

        $st = DB::pdo()->prepare("SELECT * FROM yandex_webmaster_accounts WHERE id=?");
        $st->execute([$id]);
        $row = $st->fetch();
        if (!$row) {
            $this->flash('error', 'Аккаунт не найден');
            $this->redirect('/system/webmaster-tokens');
            return;
        }

        try {
            $token = Crypto::decrypt((string)$row['access_token_enc']);
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось расшифровать токен: ' . $e->getMessage());
            $this->redirect('/system/webmaster-tokens');
            return;
        }

        // PATCH 047 §14/§65: existing recheck использует assigned/default IP (resolver).
        try {
            $resolved = (new WebmasterOutboundIpResolver())->resolveForAccount($id);
        } catch (WebmasterTransportException $e) {
            DB::pdo()->prepare(
                "UPDATE yandex_webmaster_accounts
                 SET last_validated_at=NOW(), last_validation_ok=0, last_validation_error=?,
                     last_outbound_ok=0, last_outbound_error=?
                 WHERE id=?"
            )->execute([mb_substr($e->getMessage(), 0, 500), mb_substr($e->getMessage(), 0, 500), $id]);
            $this->flash('error', 'Исходящий IP: ' . $e->getMessage());
            $this->redirect('/system/webmaster-tokens');
            return;
        }
        $expectedIp = $resolved['ip_address'];
        $ctx = ['webmaster_account_id' => $id, 'refresh_job_id' => null, 'stage' => 'token_recheck'];

        $userResp = $this->apiCall('GET', '/v4/user', $token, $expectedIp, $ctx);

        if (!$userResp['ok']) {
            DB::pdo()->prepare(
                "UPDATE yandex_webmaster_accounts
                 SET last_validated_at=NOW(), last_validation_ok=0, last_validation_error=?,
                     last_outbound_ip_expected=?, last_outbound_ip_actual=?, last_outbound_ok=?, last_outbound_error=?
                 WHERE id=?"
            )->execute([
                mb_substr($userResp['error'], 0, 500), $expectedIp,
                (string)$userResp['actual_local_ip'],
                $userResp['source_ip_verified'] ? 1 : 0,
                $userResp['source_ip_verified'] ? null : mb_substr($userResp['error'], 0, 500),
                $id,
            ]);
            $this->flash('error', "Токен невалиден (через {$expectedIp}): {$userResp['error']}");
            $this->redirect('/system/webmaster-tokens');
            return;
        }

        $userData = json_decode($userResp['body'], true);
        $userId = (int)($userData['user_id'] ?? 0);

        $hostCount = 0;
        $hostsResp = $this->apiCall('GET', "/v4/user/{$userId}/hosts", $token, $expectedIp, $ctx);
        if ($hostsResp['ok']) {
            $hostsData = json_decode($hostsResp['body'], true);
            if (is_array($hostsData) && !empty($hostsData['hosts'])) {
                $hostCount = count($hostsData['hosts']);
            }
        }

        DB::pdo()->prepare(
            "UPDATE yandex_webmaster_accounts
             SET last_validated_at=NOW(), last_validation_ok=1, last_validation_error=NULL,
                 yandex_user_id=?, host_count=?,
                 last_outbound_ip_expected=?, last_outbound_ip_actual=?, last_outbound_verified_at=NOW(),
                 last_outbound_ok=1, last_outbound_error=NULL
             WHERE id=?"
        )->execute([$userId, $hostCount, $expectedIp, (string)$userResp['actual_local_ip'], $id]);

        $this->flash('success', "Токен валиден через {$expectedIp}. user_id={$userId}, сайтов: {$hostCount}");
        $this->redirect('/system/webmaster-tokens');
    }

    // ═══════════════════════ PATCH 047: управление пулом исходящих IP ═══════════════════════

    private static function validIpv4(string $ip): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
    }

    /** §24: добавить IP в пул (IPv4-only). */
    public function ipAdd(): void
    {
        $this->requireAuth(); $this->requireCsrf();
        $ip = trim((string)($_POST['ip_address'] ?? ''));
        $label = trim((string)($_POST['label'] ?? ''));
        if (!self::validIpv4($ip)) { $this->flash('error', 'Некорректный IPv4: ' . $ip); $this->redirect('/system/webmaster-tokens'); return; }
        try {
            DB::pdo()->prepare(
                "INSERT INTO webmaster_outbound_ips (ip_address, label, is_enabled, is_default)
                 VALUES (?, ?, 0, 0) ON DUPLICATE KEY UPDATE label=VALUES(label)"
            )->execute([$ip, $label]);
            // §24: до подтверждения probe IP остаётся is_enabled=0.
            $this->flash('success', "IP {$ip} добавлен (выключен — включите после проверки).");
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось добавить IP: ' . $e->getMessage());
        }
        $this->redirect('/system/webmaster-tokens');
    }

    /** §24: включить/выключить IP. Disable assigned IP → аккаунты FAIL CLOSED (не тихий default). */
    public function ipToggle(): void
    {
        $this->requireAuth(); $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        $enable = !empty($_POST['enable']) ? 1 : 0;
        if ($id <= 0) { $this->flash('error', 'Не указан id'); $this->redirect('/system/webmaster-tokens'); return; }
        $pdo = DB::pdo();
        $row = $pdo->query("SELECT * FROM webmaster_outbound_ips WHERE id=" . (int)$id)->fetch();
        if (!$row) { $this->flash('error', 'IP не найден'); $this->redirect('/system/webmaster-tokens'); return; }
        // Нельзя выключить единственный enabled default (иначе NULL-аккаунты FAIL CLOSED массово).
        if (!$enable && (int)$row['is_default'] === 1) {
            $this->flash('error', 'Нельзя выключить DEFAULT IP. Сначала назначьте другой default.');
            $this->redirect('/system/webmaster-tokens'); return;
        }
        $assigned = (int)$pdo->query("SELECT COUNT(*) FROM yandex_webmaster_accounts WHERE outbound_ip_id=" . (int)$id)->fetchColumn();
        // §15: включение требует свежего успешного live-probe (local==expected И public==expected).
        if ($enable) {
            $probe = $this->probePoolIp($row);
            if (empty($probe['ok'])) {
                $this->flash('error', "IP {$row['ip_address']} НЕ включён: проверка не пройдена "
                    . "(local=" . ($probe['local_ip'] ?: '—') . ", public=" . ($probe['public_ip'] ?: '—')
                    . ($probe['error'] ? ", {$probe['error']}" : '') . "). Сначала добейтесь успешного probe.");
                $this->redirect('/system/webmaster-tokens');
                return;
            }
        }
        $pdo->prepare("UPDATE webmaster_outbound_ips SET is_enabled=? WHERE id=?")->execute([$enable, $id]);
        if (!$enable && $assigned > 0) {
            $this->flash('success', "IP {$row['ip_address']} выключен. {$assigned} аккаунт(ов) теперь FAIL CLOSED (тихого перехода на default НЕ будет) — переназначьте их.");
        } else {
            $this->flash('success', "IP {$row['ip_address']} " . ($enable ? 'включён' : 'выключен') . '.');
        }
        $this->redirect('/system/webmaster-tokens');
    }

    /** §16/§55: назначить DEFAULT транзакционно (ровно один enabled default). */
    public function ipSetDefault(): void
    {
        $this->requireAuth(); $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { $this->flash('error', 'Не указан id'); $this->redirect('/system/webmaster-tokens'); return; }
        $pdo = DB::pdo();
        $row = $pdo->query("SELECT * FROM webmaster_outbound_ips WHERE id=" . (int)$id)->fetch();
        if (!$row) { $this->flash('error', 'IP не найден'); $this->redirect('/system/webmaster-tokens'); return; }
        if ((int)$row['is_enabled'] !== 1) { $this->flash('error', 'DEFAULT нельзя назначить выключенному IP.'); $this->redirect('/system/webmaster-tokens'); return; }
        try {
            $pdo->beginTransaction();
            $pdo->exec("UPDATE webmaster_outbound_ips SET is_default=0");
            $pdo->prepare("UPDATE webmaster_outbound_ips SET is_default=1 WHERE id=?")->execute([$id]);
            $pdo->commit();
            $nullAccounts = (int)$pdo->query("SELECT COUNT(*) FROM yandex_webmaster_accounts WHERE outbound_ip_id IS NULL")->fetchColumn();
            $this->flash('success', "DEFAULT установлен: {$row['ip_address']}. Затронуто аккаунтов на DEFAULT: {$nullAccounts}.");
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось сменить default: ' . $e->getMessage());
        }
        $this->redirect('/system/webmaster-tokens');
    }

    /** §24: удалить IP. Запрещено, если назначен аккаунтам. */
    public function ipDelete(): void
    {
        $this->requireAuth(); $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { $this->flash('error', 'Не указан id'); $this->redirect('/system/webmaster-tokens'); return; }
        $pdo = DB::pdo();
        $assigned = (int)$pdo->query("SELECT COUNT(*) FROM yandex_webmaster_accounts WHERE outbound_ip_id=" . (int)$id)->fetchColumn();
        if ($assigned > 0) {
            $this->flash('error', "Этот IP назначен {$assigned} аккаунтам. Сначала переназначьте их.");
            $this->redirect('/system/webmaster-tokens'); return;
        }
        $isDefault = (int)($pdo->query("SELECT is_default FROM webmaster_outbound_ips WHERE id=" . (int)$id)->fetchColumn());
        if ($isDefault === 1) { $this->flash('error', 'Нельзя удалить DEFAULT IP.'); $this->redirect('/system/webmaster-tokens'); return; }
        $pdo->prepare("DELETE FROM webmaster_outbound_ips WHERE id=?")->execute([$id]);
        $this->flash('success', 'IP удалён.');
        $this->redirect('/system/webmaster-tokens');
    }

    /** §11/§51: probe IP (bind/TLS к Yandex + public egress). Read-only, JSON. */
    public function ipProbe(): void
    {
        $this->requireAuth(); $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        $pdo = DB::pdo();
        // §14: при explicit id проверяем IP ДАЖЕ если он выключен (иначе новый IP нельзя
        // проверить до включения). Без id — только включённые.
        $rows = $id > 0
            ? $pdo->query("SELECT * FROM webmaster_outbound_ips WHERE id=" . (int)$id)->fetchAll()
            : $pdo->query("SELECT * FROM webmaster_outbound_ips WHERE is_enabled=1 ORDER BY id")->fetchAll();
        $out = [];
        foreach ($rows as $r) { $out[] = $this->probePoolIp($r); }
        $this->jsonOk(['results' => $out]);
    }

    /** §29/§57: назначить IP аккаунту с read-only тестом + транзакционным CAS. */
    public function assignIp(): void
    {
        $this->requireAuth(); $this->requireCsrf();
        $accountId = (int)($_POST['account_id'] ?? 0);
        $ipId = (int)($_POST['ip_id'] ?? 0);
        if ($accountId <= 0 || $ipId <= 0) { $this->jsonErr('account_id и ip_id обязательны', 400); return; }
        $res = $this->assignOne($accountId, $ipId);
        if ($res['ok']) $this->jsonOk($res); else $this->jsonErr($res['error'] ?? 'assign failed', 400);
    }

    /** §32: массовое назначение (per-account тест; fail не блокирует остальных). */
    public function bulkAssign(): void
    {
        $this->requireAuth(); $this->requireCsrf();
        $ids = $_POST['account_ids'] ?? [];
        $ipId = (int)($_POST['ip_id'] ?? 0);
        if (!is_array($ids) || empty($ids) || $ipId <= 0) { $this->jsonErr('account_ids[] и ip_id обязательны', 400); return; }
        $applied = 0; $failed = [];
        foreach ($ids as $aid) {
            $aid = (int)$aid; if ($aid <= 0) continue;
            $r = $this->assignOne($aid, $ipId);
            if ($r['ok']) $applied++; else $failed[] = ['account_id' => $aid, 'error' => $r['error'] ?? 'fail'];
        }
        $this->jsonOk(['applied' => $applied, 'failed' => $failed]);
    }

    /** §30: read-only проверка одного аккаунта через назначенный IP. JSON. */
    public function accountCheck(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { $this->jsonErr('Не указан id', 400); return; }
        $res = $this->probeAccount($id);
        $this->jsonOk($res);
    }

    /** §31: последовательная read-only проверка всех аккаунтов. JSON-матрица. */
    public function checkAllAccounts(): void
    {
        $this->requireAuth();
        $ids = DB::pdo()->query("SELECT id FROM yandex_webmaster_accounts ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
        $matrix = [];
        foreach ($ids as $aid) { $matrix[] = $this->probeAccount((int)$aid); }
        $this->jsonOk(['accounts' => $matrix]);
    }

    /** §51: комплексный read-only gate маршрутизации Webmaster. JSON. */
    public function routingCheck(): void
    {
        $this->requireAuth();
        $pdo = DB::pdo();
        $report = ['pool' => [], 'accounts' => [], 'summary' => []];

        $defCount = (int)$pdo->query("SELECT COUNT(*) FROM webmaster_outbound_ips WHERE is_default=1 AND is_enabled=1")->fetchColumn();
        $report['summary']['default_ok'] = ($defCount === 1);
        $report['summary']['default_count'] = $defCount;
        $def = $pdo->query("SELECT ip_address FROM webmaster_outbound_ips WHERE is_default=1 AND is_enabled=1 LIMIT 1")->fetchColumn();
        $report['summary']['default_ip'] = $def ?: null;

        $poolPass = 0; $poolFail = 0;
        foreach ($pdo->query("SELECT * FROM webmaster_outbound_ips WHERE is_enabled=1 ORDER BY id")->fetchAll() as $r) {
            $pr = $this->probePoolIp($r);
            $report['pool'][] = $pr;
            if (!empty($pr['ok'])) $poolPass++; else $poolFail++;
        }
        $accPass = 0; $accFail = 0; $mismatches = 0;
        foreach ($pdo->query("SELECT id FROM yandex_webmaster_accounts ORDER BY id")->fetchAll(PDO::FETCH_COLUMN) as $aid) {
            $pr = $this->probeAccount((int)$aid);
            $report['accounts'][] = $pr;
            if (!empty($pr['ok'])) $accPass++; else $accFail++;
            if (!empty($pr['source_ip_verified']) === false && !empty($pr['expected'])) { /* not verified */ }
            if (isset($pr['source_ip_verified']) && $pr['source_ip_verified'] === false) $mismatches++;
        }
        $disabledRefs = (int)$pdo->query(
            "SELECT COUNT(*) FROM yandex_webmaster_accounts a
               JOIN webmaster_outbound_ips i ON i.id=a.outbound_ip_id
              WHERE i.is_enabled=0"
        )->fetchColumn();
        $missingRefs = (int)$pdo->query(
            "SELECT COUNT(*) FROM yandex_webmaster_accounts a
              WHERE a.outbound_ip_id IS NOT NULL
                AND NOT EXISTS (SELECT 1 FROM webmaster_outbound_ips i WHERE i.id=a.outbound_ip_id)"
        )->fetchColumn();
        $report['summary']['accounts_pass'] = $accPass;
        $report['summary']['accounts_fail'] = $accFail;
        $report['summary']['source_mismatches'] = $mismatches;
        $report['summary']['disabled_assignments'] = $disabledRefs;
        $report['summary']['missing_assignments'] = $missingRefs;
        $report['summary']['pool_pass'] = $poolPass;
        $report['summary']['pool_fail'] = $poolFail;
        // §17: pool probe failures ВХОДЯТ в общий вердикт (4/4 IP PASS — часть gate).
        $report['summary']['overall_pass'] = ($report['summary']['default_ok'] && $poolFail === 0
            && $accFail === 0 && $disabledRefs === 0 && $missingRefs === 0);

        $this->jsonOk($report);
    }

    /** §40: последние 100 записей аудита (фильтры account/ip/only_errors/job). JSON. */
    public function auditLog(): void
    {
        $this->requireAuth();
        $pdo = DB::pdo();
        $where = []; $args = [];
        if (!empty($_GET['account_id'])) { $where[] = 'webmaster_account_id=?'; $args[] = (int)$_GET['account_id']; }
        if (!empty($_GET['ip'])) { $where[] = 'expected_outbound_ip=?'; $args[] = (string)$_GET['ip']; }
        if (!empty($_GET['job_id'])) { $where[] = 'refresh_job_id=?'; $args[] = (int)$_GET['job_id']; }
        if (!empty($_GET['only_errors'])) { $where[] = "result <> 'success'"; }
        $sql = "SELECT id, request_uid, webmaster_account_id, refresh_job_id, stage, method, endpoint,
                       expected_outbound_ip, actual_local_ip, remote_ip, source_ip_verified, http_code,
                       curl_errno, duration_ms, result, error_summary, created_at
                  FROM webmaster_api_request_log";
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $sql .= ' ORDER BY id DESC LIMIT 100';
        $st = $pdo->prepare($sql); $st->execute($args);
        $this->jsonOk(['rows' => $st->fetchAll()]);
    }

    // ── внутренние помощники ──

    /** Назначить IP одному аккаунту: read-only тест через целевой IP + транзакционный CAS. */
    protected function assignOne(int $accountId, int $ipId): array
    {
        $pdo = DB::pdo();
        $acc = $pdo->query("SELECT * FROM yandex_webmaster_accounts WHERE id=" . (int)$accountId)->fetch();
        if (!$acc) return ['ok' => false, 'error' => "Аккаунт #{$accountId} не найден"];
        $ip = $pdo->query("SELECT * FROM webmaster_outbound_ips WHERE id=" . (int)$ipId)->fetch();
        if (!$ip) return ['ok' => false, 'error' => "IP id={$ipId} не найден"];
        if ((int)$ip['is_enabled'] !== 1) return ['ok' => false, 'error' => "IP {$ip['ip_address']} выключен"];

        // Read-only тест через НОВЫЙ IP (§29): expected==actual → только тогда commit.
        try {
            $token = Crypto::decrypt((string)$acc['access_token_enc']);
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => 'Не удалось расшифровать токен: ' . $e->getMessage()];
        }
        $r = $this->apiCall('GET', '/v4/user', $token, (string)$ip['ip_address'],
            ['webmaster_account_id' => $accountId, 'refresh_job_id' => null, 'stage' => 'assign_ip_test']);
        if (!$r['ok'] || !$r['source_ip_verified']) {
            return ['ok' => false, 'error' => 'Проверка через ' . $ip['ip_address'] . ' не пройдена: ' . ($r['error'] ?? 'source IP не подтверждён'),
                    'expected' => $ip['ip_address'], 'actual' => $r['actual_local_ip'] ?? ''];
        }
        // Транзакционный CAS: не затираем при параллельном изменении.
        $oldId = $acc['outbound_ip_id'];
        try {
            $pdo->beginTransaction();
            if ($oldId === null) {
                $st = $pdo->prepare("UPDATE yandex_webmaster_accounts SET outbound_ip_id=?, last_outbound_ip_expected=?, last_outbound_ip_actual=?, last_outbound_verified_at=NOW(), last_outbound_ok=1, last_outbound_error=NULL WHERE id=? AND outbound_ip_id IS NULL");
                $st->execute([$ipId, $ip['ip_address'], $r['actual_local_ip'], $accountId]);
            } else {
                $st = $pdo->prepare("UPDATE yandex_webmaster_accounts SET outbound_ip_id=?, last_outbound_ip_expected=?, last_outbound_ip_actual=?, last_outbound_verified_at=NOW(), last_outbound_ok=1, last_outbound_error=NULL WHERE id=? AND outbound_ip_id=?");
                $st->execute([$ipId, $ip['ip_address'], $r['actual_local_ip'], $accountId, (int)$oldId]);
            }
            if ($st->rowCount() !== 1) { $pdo->rollBack(); return ['ok' => false, 'error' => 'Назначение изменилось параллельно — повторите']; }
            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            return ['ok' => false, 'error' => 'DB: ' . $e->getMessage()];
        }
        return ['ok' => true, 'account_id' => $accountId, 'ip' => $ip['ip_address'],
                'expected' => $ip['ip_address'], 'actual' => $r['actual_local_ip']];
    }

    /** Read-only проверка аккаунта через resolver-IP. */
    private function probeAccount(int $accountId): array
    {
        $pdo = DB::pdo();
        $acc = $pdo->query("SELECT id,email,label,outbound_ip_id,access_token_enc FROM yandex_webmaster_accounts WHERE id=" . (int)$accountId)->fetch();
        if (!$acc) return ['account_id' => $accountId, 'ok' => false, 'error' => 'not_found'];
        try {
            $resolved = (new WebmasterOutboundIpResolver())->resolveForAccount($accountId);
        } catch (WebmasterTransportException $e) {
            return ['account_id' => $accountId, 'email' => $acc['email'], 'ok' => false,
                    'expected' => null, 'actual' => null, 'source_ip_verified' => false, 'error' => $e->getMessage()];
        }
        $expected = $resolved['ip_address'];
        try { $token = Crypto::decrypt((string)$acc['access_token_enc']); }
        catch (\Throwable $e) { return ['account_id' => $accountId, 'email' => $acc['email'], 'ok' => false, 'expected' => $expected, 'error' => 'decrypt_failed']; }
        $r = $this->apiCall('GET', '/v4/user', $token, $expected,
            ['webmaster_account_id' => $accountId, 'refresh_job_id' => null, 'stage' => 'account_check']);
        // снапшот
        try {
            $pdo->prepare("UPDATE yandex_webmaster_accounts SET last_outbound_ip_expected=?, last_outbound_ip_actual=?, last_outbound_verified_at=NOW(), last_outbound_ok=?, last_outbound_error=? WHERE id=?")
                ->execute([$expected, $r['actual_local_ip'] ?? '', ($r['ok'] && $r['source_ip_verified']) ? 1 : 0,
                           ($r['ok'] && $r['source_ip_verified']) ? null : mb_substr((string)($r['error'] ?? ''), 0, 500), $accountId]);
        } catch (\Throwable $e) { /* ignore */ }
        return ['account_id' => $accountId, 'email' => $acc['email'], 'source' => $resolved['source'],
                'expected' => $expected, 'actual' => $r['actual_local_ip'] ?? '',
                'source_ip_verified' => (bool)($r['source_ip_verified'] ?? false),
                'http_code' => $r['http_code'] ?? 0, 'ok' => (bool)($r['ok'] && ($r['source_ip_verified'] ?? false)),
                'error' => $r['ok'] ? null : ($r['error'] ?? null)];
    }

    /**
     * §11.1/§11.2: probe пул-IP. bind/TLS к Yandex (tokenless, 401 ок) + public egress (ipify).
     * В песочнице без сети вернёт ошибку — это host-only operational-проверка.
     */
    protected function probePoolIp(array $ipRow): array
    {
        $ip = (string)$ipRow['ip_address'];
        $localOk = false; $remoteOk = false; $publicIp = null; $httpCode = 0; $error = null; $localIp = '';
        $remoteIp = '';
        try {
            $res = $this->poolTransport()->request('GET', '/v4/user', '', $ip, [], null,
                ['webmaster_account_id' => 0, 'refresh_job_id' => null, 'stage' => 'ip_probe']);
            $httpCode = (int)$res['http_code']; $localIp = (string)$res['actual_local_ip'];
            $remoteIp = (string)($res['remote_ip'] ?? '');
            $localOk = (bool)$res['source_ip_verified']; $remoteOk = $remoteIp !== '';
        } catch (WebmasterTransportException $e) {
            $rr = $e->getResult(); $httpCode = (int)($rr['http_code'] ?? 0); $localIp = (string)($rr['actual_local_ip'] ?? '');
            $remoteIp = (string)($rr['remote_ip'] ?? '');
            // tokenless 401 при verified source — это ОК как network probe (§11.1).
            $localOk = (bool)($rr['source_ip_verified'] ?? false);
            $remoteOk = $remoteIp !== '';
            if (!$localOk) $error = $e->getReason() . ': ' . $e->getMessage();
        }
        // public egress (ipify) через тот же интерфейс (не webmaster host).
        $publicIp = $this->egressProbe($ip);
        // §16: строгий pool-test — local==expected И public==expected. public=null → НЕ pass.
        $ok = $localOk && ($localIp === $ip) && ($publicIp === $ip);
        if ($publicIp === null && $error === null) {
            $error = 'public egress (ipify) не подтверждён — INCONCLUSIVE';
        }
        try {
            DB::pdo()->prepare(
                "UPDATE webmaster_outbound_ips SET last_probe_at=NOW(), last_probe_ok=?, last_probe_local_ip=?,
                    last_probe_public_ip=?, last_probe_remote_ip=?, last_probe_http_code=?, last_probe_error=? WHERE id=?"
            )->execute([$ok ? 1 : 0, $localIp ?: null, $publicIp, $remoteIp ?: null, $httpCode ?: null, $error, (int)$ipRow['id']]);
        } catch (\Throwable $e) { /* ignore */ }
        return ['id' => (int)$ipRow['id'], 'ip' => $ip, 'label' => (string)$ipRow['label'],
                'is_default' => (int)$ipRow['is_default'] === 1, 'ok' => $ok, 'local_ip' => $localIp,
                'public_ip' => $publicIp, 'http_code' => $httpCode, 'error' => $error];
    }

    /** Транспорт для probe пула — seam для тестируемости без сети. */
    protected function poolTransport(): YandexWebmasterHttpTransport
    {
        return new YandexWebmasterHttpTransport();
    }

    /** ipify egress через CURLOPT_INTERFACE (не webmaster host — вне scope architecture gate). */
    protected function egressProbe(string $ip): ?string
    {
        $ch = curl_init('https://api.ipify.org');
        if ($ch === false) return null;
        curl_setopt_array($ch, [
            CURLOPT_INTERFACE => $ip, CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 12,
            CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $body = curl_exec($ch);
        curl_close($ch);
        $body = is_string($body) ? trim($body) : '';
        return self::validIpv4($body) ? $body : null;
    }

    /**
     * PATCH 047 §45: вызов к Webmaster API через ЕДИНЫЙ transport с жёсткой привязкой IP.
     * $pathOrUrl принимается и как path, и как полный URL (host отбрасывается — анти-SSRF).
     * @return array { ok, http_code, body, error, actual_local_ip, source_ip_verified, expected_outbound_ip }
     */
    protected function apiCall(string $method, string $pathOrUrl, string $token, string $expectedIp, array $context = []): array
    {
        $path = $pathOrUrl;
        if (preg_match('~^https?://[^/]+(/.*)$~i', $pathOrUrl, $m)) {
            $path = $m[1];
        }
        try {
            $res = (new YandexWebmasterHttpTransport())->request(
                $method, $path, $token, $expectedIp, [], null, $context
            );
        } catch (WebmasterTransportException $e) {
            $r = $e->getResult();
            return [
                'ok' => false,
                'http_code' => (int)($r['http_code'] ?? 0),
                'body' => (string)($r['body'] ?? ''),
                'error' => $e->getMessage(),
                'reason' => $e->getReason(),
                'actual_local_ip' => (string)($r['actual_local_ip'] ?? ''),
                'source_ip_verified' => (bool)($r['source_ip_verified'] ?? false),
                'expected_outbound_ip' => $expectedIp,
            ];
        }

        $httpCode = (int)$res['http_code'];
        if ($httpCode === 401) {
            return ['ok' => false, 'http_code' => 401, 'body' => (string)$res['body'],
                    'error' => 'Unauthorized — токен невалиден или истёк',
                    'actual_local_ip' => (string)$res['actual_local_ip'],
                    'source_ip_verified' => (bool)$res['source_ip_verified'],
                    'expected_outbound_ip' => $expectedIp];
        }
        if ($httpCode === 403) {
            return ['ok' => false, 'http_code' => 403, 'body' => (string)$res['body'],
                    'error' => 'Forbidden — у токена нет нужных прав (webmaster:hostinfo)',
                    'actual_local_ip' => (string)$res['actual_local_ip'],
                    'source_ip_verified' => (bool)$res['source_ip_verified'],
                    'expected_outbound_ip' => $expectedIp];
        }
        if (!$res['ok']) {
            $errMsg = "HTTP {$httpCode}";
            $body = (string)$res['body'];
            if ($body !== '') {
                $j = json_decode($body, true);
                if (is_array($j) && !empty($j['error_message'])) $errMsg .= ': ' . $j['error_message'];
                elseif (is_array($j) && !empty($j['error_code'])) $errMsg .= ': ' . $j['error_code'];
            }
            return ['ok' => false, 'http_code' => $httpCode, 'body' => $body, 'error' => $errMsg,
                    'actual_local_ip' => (string)$res['actual_local_ip'],
                    'source_ip_verified' => (bool)$res['source_ip_verified'],
                    'expected_outbound_ip' => $expectedIp];
        }

        return ['ok' => true, 'http_code' => $httpCode, 'body' => (string)$res['body'], 'error' => null,
                'actual_local_ip' => (string)$res['actual_local_ip'],
                'source_ip_verified' => (bool)$res['source_ip_verified'],
                'expected_outbound_ip' => $expectedIp];
    }

    /**
     * Разрешить исходящий IP для нового токена: выбранный outbound_ip_id (enabled) или DEFAULT.
     * @return array{id:int, ip:string}
     * @throws WebmasterTransportException RESOLVE_FAILED
     */
    private function outboundIpForNewToken(?int $ipId): array
    {
        $resolver = new WebmasterOutboundIpResolver();
        if ($ipId !== null && $ipId > 0) {
            $st = DB::pdo()->prepare("SELECT id, ip_address, is_enabled FROM webmaster_outbound_ips WHERE id=? LIMIT 1");
            $st->execute([$ipId]);
            $r = $st->fetch();
            if (!$r) {
                throw new WebmasterTransportException(WebmasterTransportException::RESOLVE_FAILED,
                    "Выбранный исходящий IP (id={$ipId}) не найден в пуле");
            }
            if ((int)$r['is_enabled'] !== 1) {
                throw new WebmasterTransportException(WebmasterTransportException::RESOLVE_FAILED,
                    "Выбранный исходящий IP {$r['ip_address']} выключен");
            }
            return ['id' => (int)$r['id'], 'ip' => (string)$r['ip_address']];
        }
        $def = $resolver->resolveDefault();
        return ['id' => (int)$def['id'], 'ip' => (string)$def['ip_address']];
    }
}
