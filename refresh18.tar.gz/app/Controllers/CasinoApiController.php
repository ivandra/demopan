<?php

/**
 * CasinoApiController — endpoint'ы /api/v1/casino/* для casino-panel'и.
 *
 * B1 endpoints:
 *   POST /api/v1/casino/projects/register
 *   GET  /api/v1/casino/projects
 *   GET  /api/v1/casino/projects/show?id=X
 *
 * B2 endpoints (новые):
 *   POST /api/v1/casino/buy/start            — старт покупки root-домена
 *   GET  /api/v1/casino/runs/show?run_id=X   — статус операции для поллинга
 */
class CasinoApiController
{
    // ==================== B1 ====================

    public function register(): void
    {
        $client = ApiAuth::require('casino.write');

        $raw = (string)file_get_contents('php://input');
        $input = json_decode($raw, true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        $required = ['main_host', 'docroot'];
        foreach ($required as $f) {
            if (empty($input[$f])) ApiAuth::abort(400, 'missing_field', "Field '$f' is required");
        }

        try {
            $projectId = CasinoProjectStore::registerOrUpdate($input, (int)$client['id']);
            if (isset($input['sites']) && is_array($input['sites'])) {
                CasinoProjectStore::setSites($projectId, $input['sites']);
            }
            // v0.5-fix10: если передан root_domain — записываем явно (для синка из casino-panel
            // когда юзер нажал "использовать домен панели" чтобы починить рассинхрон).
            if (!empty($input['root_domain'])) {
                CasinoProjectStore::setRootDomain($projectId, (string)$input['root_domain']);
            }
        } catch (Throwable $e) {
            ApiAuth::abort(500, 'register_failed', $e->getMessage());
        }

        $project = CasinoProjectStore::loadProject($projectId);
        ApiAuth::ok(['project' => CasinoProjectStore::toApiArray($project)]);
    }

    public function list(): void
    {
        $client = ApiAuth::require('casino.read');
        $projects = CasinoProjectStore::listProjects((int)$client['id']);
        $out = [];
        foreach ($projects as $p) $out[] = CasinoProjectStore::toApiArray($p);
        ApiAuth::ok(['projects' => $out]);
    }

    public function show(): void
    {
        $client = ApiAuth::require('casino.read');
        $id = (int)($_GET['id'] ?? 0);
        $extId = (string)($_GET['external_id'] ?? '');
        if ($id > 0) {
            $project = CasinoProjectStore::loadProject($id);
        } elseif ($extId !== '') {
            $project = CasinoProjectStore::loadProjectByExternal((int)$client['id'], $extId);
        } else {
            ApiAuth::abort(400, 'bad_id', 'Param id or external_id required');
        }
        if (!$project) ApiAuth::abort(404, 'not_found', 'Project not found');
        // Самовосстановление root_domain (если покупка прошла, но не записалась)
        $project = $this->ensureRootDomain($project);
        ApiAuth::ok(['project' => CasinoProjectStore::toApiArray($project)]);
    }

    // ==================== B2 — Покупка root-домена ====================

    /**
     * POST /api/v1/casino/buy/start
     * Body (JSON):
     *   {
     *     "external_id": "kazik1",   ← project external_id (из B1 registration)
     *     "base_word": "kazik",
     *     "tlds": [".casino", ".com"],
     *     "max_price_usd": 50,
     *     "registrar_account_id": 2,
     *     "registrar_contact_id": 2,
     *     "vps_ip": "95.129.234.20"
     *   }
     * Response:
     *   { "ok": true, "run_id": "buy_61b25_84212f" }
     */
    public function buyStart(): void
    {
        $client = ApiAuth::require('casino.deploy');

        $raw = (string)file_get_contents('php://input');
        $input = json_decode($raw, true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        $extId = (string)($input['external_id'] ?? '');
        if ($extId === '') ApiAuth::abort(400, 'missing_field', "Field 'external_id' required");

        $project = CasinoProjectStore::loadProjectByExternal((int)$client['id'], $extId);
        if (!$project) ApiAuth::abort(404, 'project_not_found', "Project with external_id='$extId' not found. Register it first via /api/v1/casino/projects/register.");

        $required = ['base_word', 'tlds', 'max_price_usd', 'registrar_account_id', 'registrar_contact_id', 'vps_ip'];
        foreach ($required as $f) {
            if (!isset($input[$f]) || $input[$f] === '' || (is_array($input[$f]) && empty($input[$f]))) {
                ApiAuth::abort(400, 'missing_field', "Field '$f' required");
            }
        }

        try {
            $runId = CasinoRunStore::create((int)$project['id'], 'buy', $input);
        } catch (Throwable $e) {
            ApiAuth::abort(500, 'create_run_failed', $e->getMessage());
        }

        // Запускаем обработку run В ФОНЕ — не ждём cron. Ответ клиенту отдаётся
        // сразу, run выполняется после закрытия соединения (casino-panel поллит статус).
        self::runInBackground($runId);

        ApiAuth::ok(['run_id' => $runId, 'message' => 'Run started.']);
    }

    /**
     * Выполнить run в фоне: отдаём HTTP-ответ клиенту, затем продолжаем обработку
     * уже без подвешенного соединения. Так покупка (30-60с на проверку доменов)
     * не упирается в таймаут запроса и не требует внешнего cron.
     */
    private static function runInBackground(string $runId): void
    {
        // Дать клиенту получить JSON и отпустить соединение
        if (function_exists('fastcgi_finish_request')) {
            // ответ уже будет отправлен через ApiAuth::ok() в вызывающем методе —
            // но ok() делает exit. Поэтому регистрируем shutdown ПЕРЕД ok().
        }
        register_shutdown_function(function () use ($runId) {
            @ignore_user_abort(true);
            @set_time_limit(300);
            if (function_exists('fastcgi_finish_request')) {
                @fastcgi_finish_request();
            }
            try {
                (new CasinoRunner())->tickRun($runId);
            } catch (Throwable $e) {
                @error_log('[casino runInBackground] ' . $e->getMessage());
            }
        });
    }

    /**
     * GET /api/v1/casino/runs/show?run_id=X
     * Response:
     *   {
     *     "ok": true,
     *     "run": { "run_id":"...", "kind":"buy", "state":"running"|"done"|"failed",
     *              "progress":75, "message":"Покупка kazik5.casino за $1.99",
     *              "events":[ {ts,level,message}, ... ],
     *              "output": {...},  ← на state=done
     *              "error":"..." }   ← на state=failed
     *   }
     */
    public function runsShow(): void
    {
        ApiAuth::require('casino.read');

        $runId = (string)($_GET['run_id'] ?? '');
        if ($runId === '') ApiAuth::abort(400, 'missing_field', "Param 'run_id' required");

        $run = CasinoRunStore::loadByRunId($runId);
        if (!$run) ApiAuth::abort(404, 'run_not_found', "Run '$runId' not found");

        ApiAuth::ok(['run' => CasinoRunStore::toApiArray($run, true)]);
    }

    /**
     * GET /api/v1/casino/server/vps-ip?fp_server=X
     * Определяет VPS IP как Hub (pickServerIpForSite):
     *   1) extra_ips[0] из fastpanel_servers (если есть)
     *   2) host из fastpanel_servers (если это IP)
     * Это надёжнее чем site['ips'] из FastPanel API (тот может вернуть
     * назначенный сайту IP интерфейса, а не реальный VPS).
     */
    public function vpsIp(): void
    {
        ApiAuth::require('casino.read');
        $fpServer = (int)($_GET['fp_server'] ?? 0);
        if ($fpServer <= 0) ApiAuth::abort(400, 'bad_request', 'fp_server required');

        $st = DB::pdo()->prepare("SELECT host, extra_ips FROM fastpanel_servers WHERE id = ?");
        $st->execute([$fpServer]);
        $r = $st->fetch();
        if (!$r) ApiAuth::abort(404, 'not_found', "fp_server #$fpServer not found");

        $ipRe = '~^(?:\d{1,3}\.){3}\d{1,3}$~';
        $ip = '';

        // (1) extra_ips
        $extra = trim((string)($r['extra_ips'] ?? ''));
        if ($extra !== '') {
            foreach (preg_split('~[,\s]+~', $extra) as $v) {
                $v = trim($v);
                if ($v !== '' && preg_match($ipRe, $v)) { $ip = $v; break; }
            }
        }

        // (2) host (strip scheme/port)
        if ($ip === '') {
            $host = (string)($r['host'] ?? '');
            $host = preg_replace('~^https?://~i', '', $host);
            $host = preg_replace('~:\d+$~', '', $host);
            $host = trim($host);
            if (preg_match($ipRe, $host)) $ip = $host;
        }

        // Полный список доступных IP (для dropdown смены IP, как Hub getAvailableIpsForSite):
        // extra_ips + host(если IP). Уникальные.
        $ips = [];
        if ($extra !== '') {
            foreach (preg_split('~[,\s]+~', $extra) as $v) {
                $v = trim($v);
                if ($v !== '' && preg_match($ipRe, $v)) $ips[] = $v;
            }
        }
        $host2 = (string)($r['host'] ?? '');
        $host2 = preg_replace('~^https?://~i', '', $host2);
        $host2 = preg_replace('~:\d+$~', '', $host2);
        $host2 = trim($host2);
        if (preg_match($ipRe, $host2)) $ips[] = $host2;
        $ips = array_values(array_unique($ips));

        if ($ip === '') ApiAuth::abort(404, 'no_ip', 'Не удалось определить VPS IP из fastpanel_servers (host не IP, extra_ips пуст)');

        ApiAuth::ok(['fp_server' => $fpServer, 'ip' => $ip, 'ips' => $ips]);
    }

    /**
     * Самовосстановление root_domain если он пуст в casino_projects.
     * Источники (по приоритету):
     *   1) последний успешный buy-run проекта (result_json.domain)
     *   2) Namecheap getDomainInfo по main_host (владеем ли доменом)
     *   3) DNS: main_host резолвится на vps_ip проекта → значит куплен
     * При находке — записывает через CasinoProjectStore::setRootDomain.
     * Возвращает обновлённый проект (массив) либо исходный.
     */
    private function ensureRootDomain(array $project): array
    {
        if (!empty($project['root_domain'])) return $project;
        $projectId = (int)$project['id'];
        $found = '';

        // 1) из последнего успешного buy-run
        try {
            $runs = CasinoRunStore::listRunsForProject($projectId, 50);
            foreach ($runs as $r) {
                if (($r['kind'] ?? '') !== 'buy' || ($r['state'] ?? '') !== 'done') continue;
                $res = json_decode((string)($r['result_json'] ?? ''), true);
                if (is_array($res) && !empty($res['domain'])) { $found = (string)$res['domain']; break; }
            }
        } catch (Throwable $e) {}

        // 2) Namecheap — реально ли владеем main_host
        if ($found === '' && !empty($project['main_host'])) {
            try {
                $regId = (int)($project['registrar_account_id'] ?? 0);
                if ($regId > 0) {
                    $st = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id=?");
                    $st->execute([$regId]);
                    $acc = $st->fetch();
                    if ($acc) {
                        $endpoint = (int)($acc['is_sandbox'] ?? 0) === 1
                            ? config('namecheap.endpoint_sandbox', 'https://api.sandbox.namecheap.com/xml.response')
                            : config('namecheap.endpoint', 'https://api.namecheap.com/xml.response');
                        $nc = new NamecheapClient(
                            $endpoint,
                            (string)$acc['api_user'],
                            Crypto::decrypt((string)$acc['api_key_enc']),
                            (string)$acc['username'],
                            (string)$acc['client_ip'],
                            30
                        );
                        // getDomainInfo бросит исключение если домен НЕ наш
                        $nc->getDomainInfo((string)$project['main_host']);
                        $found = (string)$project['main_host']; // не бросило → владеем
                    }
                }
            } catch (Throwable $e) { /* не владеем или ошибка — идём дальше */ }
        }

        // 3) DNS: main_host резолвится на наш vps_ip
        if ($found === '' && !empty($project['main_host']) && !empty($project['vps_ip'])) {
            $resolved = @gethostbynamel((string)$project['main_host']) ?: [];
            if (in_array((string)$project['vps_ip'], $resolved, true)) {
                $found = (string)$project['main_host'];
            }
        }

        if ($found !== '') {
            try {
                CasinoProjectStore::setRootDomain($projectId, $found);
                $reload = CasinoProjectStore::loadProject($projectId);
                if ($reload) return $reload;
                $project['root_domain'] = $found;
                $project['status'] = 'domain_bought';
            } catch (Throwable $e) {}
        }
        return $project;
    }

    /**
     * GET /api/v1/casino/server/resolve-site?fp_server=X&host=kazik7.casino
     * Лёгкое автоопределение: 1 запрос simpleSites() (без построения тяжёлого
     * кеша с детализацией каждого сайта — это могло занимать >30с и давать таймаут).
     * Находит vhost по server_name, затем 1 запрос site() для owner + IP.
     * Возвращает {fp_site_id, owner, owner_id, vps_ip, server_name}.
     */
    public function resolveSite(): void
    {
        ApiAuth::require('casino.read');
        $fpServer = (int)($_GET['fp_server'] ?? 0);
        $host     = strtolower(trim((string)($_GET['host'] ?? '')));
        if ($fpServer <= 0) ApiAuth::abort(400, 'bad_request', 'fp_server required');
        if ($host === '')   ApiAuth::abort(400, 'bad_request', 'host required');

        // FastPanel client напрямую (без FastpanelSearchService — он строит тяжёлый кеш)
        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $st->execute([$fpServer]);
        $srv = $st->fetch();
        if (!$srv) ApiAuth::abort(404, 'not_found', "fp_server #{$fpServer} not found");

        try {
            $pass = Crypto::decrypt((string)$srv['password_enc']);
            $fp = new FastpanelClient(
                (string)$srv['host'],
                (bool)($srv['verify_tls'] ?? false),
                (int)config('fastpanel.timeout', 30)
            );
            $fp->login((string)$srv['username'], $pass);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'fp_login_failed', $e->getMessage());
        }

        // 1 запрос: список всех сайтов (lightweight)
        $fpSiteId = 0; $serverName = ''; $ownerUsername = '';
        try {
            $list = $fp->simpleSites();
            if (is_array($list)) {
                // точное совпадение server_name
                foreach ($list as $s) {
                    if (!is_array($s)) continue;
                    $sn = strtolower((string)($s['server_name'] ?? $s['domain'] ?? ''));
                    if ($sn === $host) {
                        $fpSiteId = (int)($s['id'] ?? 0);
                        $serverName = (string)($s['server_name'] ?? $s['domain'] ?? '');
                        if (isset($s['owner']) && is_array($s['owner'])) {
                            $ownerUsername = (string)($s['owner']['username'] ?? '');
                        } elseif (isset($s['owner_name'])) {
                            $ownerUsername = (string)$s['owner_name'];
                        }
                        break;
                    }
                }
            }
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'fp_simplesites_failed', $e->getMessage());
        }

        if ($fpSiteId <= 0) {
            ApiAuth::abort(404, 'site_not_found', "Сайт '{$host}' не найден на FastPanel #{$fpServer}");
        }

        // 1 запрос: детали сайта для IP (+ owner если в simpleSites не было)
        $vpsIp = '';
        try {
            $detail = $fp->site($fpSiteId);
            if (is_array($detail)) {
                // owner
                if ($ownerUsername === '' && isset($detail['owner']) && is_array($detail['owner'])) {
                    $ownerUsername = (string)($detail['owner']['username'] ?? '');
                }
                // IP: разные места в разных версиях FastPanel
                foreach (['ip_addr', 'ip', 'ipv4', 'address'] as $f) {
                    if (!empty($detail[$f]) && is_string($detail[$f])) { $vpsIp = $detail[$f]; break; }
                }
                if ($vpsIp === '') {
                    foreach (['ips', 'ip_addrs'] as $key) {
                        if (!empty($detail[$key]) && is_array($detail[$key])) {
                            $first = $detail[$key][0];
                            if (is_string($first)) { $vpsIp = $first; break; }
                            if (is_array($first)) {
                                foreach (['ip', 'address', 'value', 'ipv4'] as $f) {
                                    if (!empty($first[$f])) { $vpsIp = (string)$first[$f]; break 2; }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Throwable $e) { /* не критично, IP фолбэкнём ниже */ }

        // Резерв IP: host сервера если IP
        if ($vpsIp === '') {
            $h = preg_replace('~^https?://~i', '', (string)$srv['host']);
            $h = preg_replace('~:\d+$~', '', $h);
            if (preg_match('~^(?:\d{1,3}\.){3}\d{1,3}$~', $h)) $vpsIp = $h;
        }

        // owner id по username
        $ownerId = 0;
        if ($ownerUsername !== '') {
            try {
                $u = $fp->userByName($ownerUsername);
                if (is_array($u) && isset($u['id'])) $ownerId = (int)$u['id'];
            } catch (Throwable $e) { /* ignore */ }
        }

        ApiAuth::ok([
            'fp_server'   => $fpServer,
            'fp_site_id'  => $fpSiteId,
            'server_name' => $serverName,
            'owner'       => $ownerUsername,
            'owner_id'    => $ownerId,
            'vps_ip'      => $vpsIp,
        ]);
    }

    /**
     * GET /api/v1/casino/runs/tick — watchdog. Подхватывает зависшие queued-runs
     * (если фоновый запуск не сработал). Вызывается из casino-cron каждую минуту.
     * Возвращает {ok, picked, processed, failed}.
     */
    public function runsTick(): void
    {
        ApiAuth::require('casino.deploy');
        $stats = (new CasinoRunner())->tick(3);
        ApiAuth::ok($stats);
    }

    /**
     * POST /api/v1/casino/cron/setup
     * Body: { "external_id":"kazik7", "command":"...optional..." }
     * Создаёт cron-задачу в FastPanel (через его REST API) для casino-cron.
     * Команда по умолчанию запускает cron-multisite-runner.php проекта.
     */
    public function cronSetup(): void
    {
        $client = ApiAuth::require('casino.deploy');

        $raw = (string)file_get_contents('php://input');
        $input = json_decode($raw, true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        $extId = (string)($input['external_id'] ?? '');
        if ($extId === '') ApiAuth::abort(400, 'missing_field', "Field 'external_id' required");

        $project = CasinoProjectStore::loadProjectByExternal((int)$client['id'], $extId);
        if (!$project) ApiAuth::abort(404, 'project_not_found', "Project '$extId' not found");

        $fpServerId = (int)($project['fp_server_id'] ?? 0);
        $fpSiteId   = (int)($project['fp_site_id'] ?? 0);
        $docroot    = (string)($project['docroot'] ?? '');
        if ($fpServerId <= 0 || $fpSiteId <= 0) ApiAuth::abort(400, 'no_fp', 'У проекта нет fp_server_id/fp_site_id');

        // Команда крона
        $command = (string)($input['command'] ?? '');
        if ($command === '') {
            // По умолчанию: запуск casino-runner проекта (генерация + watchdog)
            $phpBin = (string)($input['php_bin'] ?? '/usr/bin/php');
            if ($docroot !== '') {
                $command = $phpBin . ' -q ' . rtrim($docroot, '/') . '/casino-panel/cron-multisite-runner.php';
            } else {
                ApiAuth::abort(400, 'no_docroot', 'docroot пуст и command не задан — нечего запускать');
            }
        }

        // Креды FastPanel
        $stmt = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $stmt->execute([$fpServerId]);
        $server = $stmt->fetch();
        if (!$server) ApiAuth::abort(404, 'fp_server_not_found', "fp_server #{$fpServerId} not found");

        try {
            $password = Crypto::decrypt((string)$server['password_enc']);
            $cron = new CasinoFastpanelCron(
                (string)$server['host'],
                (bool)($server['verify_tls'] ?? false),
                (int)config('fastpanel.timeout', 30)
            );
            $cron->login((string)$server['username'], $password);

            // owner (id владельца сайта)
            $owner = (int)($input['owner'] ?? 0);
            if ($owner <= 0) $owner = $cron->detectOwner($fpSiteId, (string)$server['username']);
            if ($owner <= 0) {
                $diag = $cron->debugOwnerInfo($fpSiteId);
                ApiAuth::abort(500, 'no_owner',
                    'Не удалось определить owner. site keys: ' .
                    (is_array($diag['site']) ? implode(',', array_keys($diag['site'])) : 'n/a') .
                    ' | users: ' .
                    (is_array($diag['users']) ? json_encode(array_slice(is_array($diag['users']['data'] ?? null) ? $diag['users']['data'] : $diag['users'], 0, 3), JSON_UNESCAPED_UNICODE) : 'n/a')
                );
            }

            // Проверка дублей — нет ли уже такой команды
            $already = false;
            try {
                foreach ($cron->listJobs() as $j) {
                    if (!is_array($j)) continue;
                    if (trim((string)($j['command'] ?? '')) === trim($command)) { $already = true; break; }
                }
            } catch (Throwable $e) { /* ignore list errors */ }

            if ($already) {
                ApiAuth::ok(['created' => false, 'message' => 'Cron с такой командой уже существует', 'command' => $command, 'owner' => $owner]);
            }

            $schedule = is_array($input['schedule'] ?? null) ? $input['schedule'] : ['minute' => '*/1'];
            $res = $cron->createJob($command, $fpSiteId, $owner, $schedule, true);

            ApiAuth::ok([
                'created' => true,
                'command' => $command,
                'owner'   => $owner,
                'vhost'   => $fpSiteId,
                'job'     => $res,
            ]);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'cron_create_failed', $e->getMessage());
        }
    }

    /**
     * GET /api/v1/casino/domain/check?domain=kazik7.casino&account_id=2&max_price=12
     * Лайв-проверка ОДНОГО домена перед покупкой (как на Hub).
     * Response:
     *   { "ok":true, "check": {
     *       "domain":"kazik7.casino", "available":true, "premium":false,
     *       "owned_by_us":false,        ← резолвится ли на наш VPS / есть ли в нашем Namecheap
     *       "min_price":31.98, "regular_price":..., "your_price":..., "coupon_price":...,
     *       "decision":"available"|"unavailable"|"too_expensive"|"owned",
     *       "max_price":12
     *   }}
     */
    public function domainCheck(): void
    {
        $client = ApiAuth::require('casino.read');

        $domain    = strtolower(trim((string)($_GET['domain'] ?? '')));
        $accountId = (int)($_GET['account_id'] ?? 0);
        $maxPrice  = (float)($_GET['max_price'] ?? 0);
        $vpsIp     = (string)($_GET['vps_ip'] ?? '');

        if ($domain === '' || !preg_match('~^[a-z0-9][a-z0-9.\-]+\.[a-z]{2,}$~', $domain)) {
            ApiAuth::abort(400, 'bad_domain', 'Param domain invalid');
        }
        if ($accountId <= 0) ApiAuth::abort(400, 'missing_field', 'Param account_id required');

        // hard cap из config — потолок
        $hardCap = (float)config('namecheap.max_price_usd', 12.0);
        if ($maxPrice <= 0 || $maxPrice > $hardCap) $maxPrice = $hardCap;

        // Грузим аккаунт
        $stmt = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'");
        $stmt->execute([$accountId]);
        $account = $stmt->fetch();
        if (!$account) ApiAuth::abort(404, 'account_not_found', "Account #$accountId not found");

        try {
            $apiKey = Crypto::decrypt((string)$account['api_key_enc']);
            $endpoint = !empty($account['is_sandbox'])
                ? (string)config('namecheap.endpoint_sandbox', 'https://api.sandbox.namecheap.com/xml.response')
                : (string)config('namecheap.endpoint', 'https://api.namecheap.com/xml.response');
            $nc = new NamecheapClient(
                $endpoint,
                (string)$account['api_user'],
                $apiKey,
                (string)($account['username'] ?? ''),
                (string)$account['client_ip'],
                (int)config('namecheap.timeout', 30)
            );
        } catch (Throwable $e) {
            ApiAuth::abort(500, 'client_init_failed', 'NamecheapClient init: ' . $e->getMessage());
        }

        // checkDomain — основной вызов. Если падает он — без него нет смысла.
        try {
            $check = $nc->checkDomain($domain);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'check_domain_failed', 'checkDomain: ' . $e->getMessage());
        }
        $available = (bool)($check['available'] ?? false);
        $premium   = (bool)($check['premium'] ?? false);

        try {
            [$sldX, $tld] = $nc->splitSldTld($domain);
        } catch (Throwable $e) {
            $tld = '';
        }

        // Цены — отдельный safe-вызов. Если упадёт, домен всё равно показываем (цена unknown).
        $regular = $your = $coupon = $minPrice = null;
        $priceError = '';
        try {
            $variants = $nc->getPricingRegister1YVariants($tld);
            $regular = isset($variants['regular_price']) && is_numeric($variants['regular_price']) ? (float)$variants['regular_price'] : null;
            $your    = isset($variants['your_price'])    && is_numeric($variants['your_price'])    ? (float)$variants['your_price']    : null;
            $coupon  = isset($variants['coupon_price'])  && is_numeric($variants['coupon_price'])  ? (float)$variants['coupon_price']  : null;
            $cands = [];
            foreach ([$coupon, $your, $regular] as $p) if (is_numeric($p)) $cands[] = (float)$p;
            $minPrice = !empty($cands) ? min($cands) : ((isset($variants['min_price']) && is_numeric($variants['min_price'])) ? (float)$variants['min_price'] : null);
        } catch (Throwable $e) {
            $priceError = $e->getMessage();
        }

        // Проверка владения — отдельный safe-вызов
        $ownedByUs = false;
        if ($vpsIp !== '') {
            $resolvedIps = @gethostbynamel($domain) ?: [];
            if (in_array($vpsIp, $resolvedIps, true)) $ownedByUs = true;
        }
        if (!$ownedByUs && !$available) {
            // Домен занят — возможно нами. getDomainInfo бросит исключение если НЕ наш — это норма.
            try {
                $info = $nc->getDomainInfo($domain);
                if (!empty($info) && (!empty($info['DomainName']) || !empty($info['@DomainName']) || !empty($info['domain_name']))) {
                    $ownedByUs = true;
                }
            } catch (Throwable $e) {
                // не наш домен — это ожидаемо, не ошибка
            }
        }

        // Решение
        if ($ownedByUs) {
            $decision = 'owned';
        } elseif (!$available) {
            $decision = 'unavailable';
        } elseif ($minPrice !== null && $minPrice > $maxPrice) {
            $decision = 'too_expensive';
        } elseif ($minPrice === null) {
            $decision = 'price_unknown'; // свободен, но цену не определили
        } else {
            $decision = 'available';
        }

        ApiAuth::ok(['check' => [
            'domain'        => $domain,
            'tld'           => $tld,
            'available'     => $available,
            'premium'       => $premium,
            'owned_by_us'   => $ownedByUs,
            'min_price'     => $minPrice,
            'regular_price' => $regular,
            'your_price'    => $your,
            'coupon_price'  => $coupon,
            'max_price'     => $maxPrice,
            'decision'      => $decision,
            'price_error'   => $priceError,
        ]]);
    }

    /**
     * POST /api/v1/casino/subdomains/start
     * Body: { "external_id":"kazik7", "subdomains":["arkada.kazik7.casino",...], "ssl_email":"..." }
     * Создаёт run kind='subdomains'.
     */
    public function subdomainsStart(): void
    {
        $client = ApiAuth::require('casino.deploy');

        $raw = (string)file_get_contents('php://input');
        $input = json_decode($raw, true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        $extId = (string)($input['external_id'] ?? '');
        if ($extId === '') ApiAuth::abort(400, 'missing_field', "Field 'external_id' required");

        $project = CasinoProjectStore::loadProjectByExternal((int)$client['id'], $extId);
        if (!$project) ApiAuth::abort(404, 'project_not_found', "Project '$extId' not found");
        if (empty($project['root_domain'])) ApiAuth::abort(400, 'no_root_domain', 'Root-домен не куплен. Сначала B2 (buy).');

        try {
            $runId = CasinoRunStore::create((int)$project['id'], 'subdomains', $input);
        } catch (Throwable $e) {
            ApiAuth::abort(500, 'create_run_failed', $e->getMessage());
        }

        self::runInBackground($runId);

        ApiAuth::ok(['run_id' => $runId, 'message' => 'Subdomains run started.']);
    }

    /**
     * POST /api/v1/casino/server/update-ip  (синхронно, как Hub updateIp)
     * Body JSON: {fp_server, fp_site_id, domain, new_ip, subdomains[], registrar_account_id, update_root}
     * Меняет IP в трёх местах:
     *   1) Namecheap DNS — A(@) [если update_root] + A всех поддоменов → new_ip
     *   2) FastPanel — алиасы *.<domain> + www.<domain> (на случай если слетели)
     *   3) Возвращает new_ip чтобы casino-panel записал в project.json
     * Возвращает {dns_ok, fp_ok, new_ip, updated_records, errors[]}.
     */
    public function updateIp(): void
    {
        ApiAuth::require('casino.write');

        $body = json_decode((string)file_get_contents('php://input'), true) ?: [];
        $fpServer  = (int)($body['fp_server'] ?? 0);
        $fpSiteId  = (int)($body['fp_site_id'] ?? 0);
        $domain    = strtolower(trim((string)($body['domain'] ?? '')));
        $newIp     = trim((string)($body['new_ip'] ?? ''));
        $accountId = (int)($body['registrar_account_id'] ?? 0);
        $updateRoot= !empty($body['update_root']);
        $subs      = is_array($body['subdomains'] ?? null) ? $body['subdomains'] : [];

        $ipRe = '~^(?:\d{1,3}\.){3}\d{1,3}$~';
        if ($domain === '')             ApiAuth::abort(400, 'bad_request', 'domain required');
        if (!preg_match($ipRe, $newIp)) ApiAuth::abort(400, 'bad_ip', 'new_ip invalid');

        $errors = [];
        $dnsOk = false;
        $fpOk  = false;
        $fpIpChanged = false;
        $updatedRecords = [];

        // нормализуем labels поддоменов (без точек/домена)
        $labels = [];
        foreach ($subs as $s) {
            $l = strtolower(trim((string)$s));
            $l = preg_replace('~\.' . preg_quote($domain, '~') . '$~', '', $l);
            $l = trim($l, '. ');
            if ($l !== '' && $l !== '_default' && $l !== '_main') $labels[$l] = true;
        }
        $labels = array_keys($labels);

        // ---- 1) DNS Namecheap ----
        if ($accountId > 0) {
            try {
                $stmt = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'");
                $stmt->execute([$accountId]);
                $account = $stmt->fetch();
                if (!$account) throw new RuntimeException("registrar account #$accountId not found");

                $apiKey = Crypto::decrypt((string)$account['api_key_enc']);
                $endpoint = !empty($account['is_sandbox'])
                    ? (string)config('namecheap.endpoint_sandbox', 'https://api.sandbox.namecheap.com/xml.response')
                    : (string)config('namecheap.endpoint', 'https://api.namecheap.com/xml.response');
                $nc = new NamecheapClient(
                    $endpoint, (string)$account['api_user'], $apiKey,
                    (string)($account['username'] ?? ''), (string)$account['client_ip'],
                    (int)config('namecheap.timeout', 30)
                );

                [$sld, $tld] = $nc->splitSldTld($domain);
                $existing = $nc->getHosts($sld, $tld);

                // guard: если хостов подозрительно мало — не трогаем (как Hub guardHostsBeforeSet)
                if (count($existing) === 0) {
                    throw new RuntimeException('getHosts вернул 0 записей — отказ во избежание стирания DNS');
                }

                $labelsMap = array_fill_keys($labels, true);
                $out = [];
                $seen = [];
                foreach ($existing as $h) {
                    if (!is_array($h)) continue;
                    $host = strtolower(trim((string)($h['host'] ?? '')));
                    $type = strtoupper(trim((string)($h['type'] ?? '')));
                    $addr = trim((string)($h['address'] ?? ''));
                    if ($host === '' || $type === '') continue;

                    // A-запись корня
                    if ($type === 'A' && $host === '@' && $updateRoot) {
                        $h['address'] = $newIp;
                        $updatedRecords[] = '@';
                    }
                    // A-запись поддомена из нашего списка
                    if ($type === 'A' && isset($labelsMap[$host])) {
                        $h['address'] = $newIp;
                        $updatedRecords[] = $host;
                        $seen[$host] = true;
                    }
                    $out[] = $h;
                }
                // добавим отсутствующие поддомены как новые A-записи
                foreach ($labels as $l) {
                    if (empty($seen[$l])) {
                        $out[] = ['host' => $l, 'type' => 'A', 'address' => $newIp, 'ttl' => 300];
                        $updatedRecords[] = $l . ' (new)';
                    }
                }

                $nc->setHosts($sld, $tld, $out);
                $dnsOk = true;
            } catch (Throwable $e) {
                $errors[] = 'DNS: ' . $e->getMessage();
            }
        } else {
            $errors[] = 'DNS: registrar_account_id не задан — DNS пропущен';
        }

        // ---- 2) FastPanel: меняем IP самого сайта (updateSite ips) + конкретные алиасы ----
        if ($fpServer > 0 && $fpSiteId > 0) {
            try {
                $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
                $st->execute([$fpServer]);
                $server = $st->fetch();
                if (!$server) throw new RuntimeException("fp_server #$fpServer not found");

                $password = Crypto::decrypt((string)$server['password_enc']);
                $fp = new FastpanelClient(
                    (string)$server['host'],
                    (bool)($server['verify_tls'] ?? false),
                    (int)config('fastpanel.timeout', 30)
                );
                $fp->login((string)$server['username'], $password);

                // 2a. IP сайта в FastPanel: updateSite с ips=[['ip'=>newIp]] (формат как в createSite Hub)
                try {
                    $fp->updateSite($fpSiteId, ['ips' => [['ip' => $newIp]]]);
                    $fpIpChanged = true;
                } catch (Throwable $e) {
                    $errors[] = 'FastPanel IP сайта: ' . $e->getMessage();
                }

                // 2b. Конкретные алиасы-зеркала на каждый поддомен (без www, без wildcard)
                $fpAliases = [];
                foreach ($labels as $lb) {
                    $fpAliases[] = $lb . '.' . $domain;
                }
                $fpAliases = array_values(array_unique($fpAliases));
                if (!empty($fpAliases)) {
                    try {
                        $fp->setSiteAliasesExact($fpSiteId, $fpAliases);
                    } catch (Throwable $e) {
                        $errors[] = 'FastPanel алиасы: ' . $e->getMessage();
                    }
                }
                $fpOk = true;
            } catch (Throwable $e) {
                $errors[] = 'FastPanel: ' . $e->getMessage();
            }
        }

        ApiAuth::ok([
            'dns_ok'          => $dnsOk,
            'fp_ok'           => $fpOk,
            'fp_ip_changed'   => $fpIpChanged,
            'new_ip'          => $newIp,
            'updated_records' => $updatedRecords,
            'errors'          => $errors,
        ]);
    }

    /* =========================================================
       WEBMASTER (B4) — Яндекс.Вебмастер для casino-проектов
       ========================================================= */

    /**
     * Общий резолв для вебмастер-методов: проект по external_id, account_id
     * (из тела запроса или из проекта), сервис. Возвращает [project, service, accountId].
     */
    private function wmResolve(array $input, int $clientId): array
    {
        $extId = (string)($input['external_id'] ?? '');
        if ($extId === '') ApiAuth::abort(400, 'missing_field', "Field 'external_id' required");

        $project = CasinoProjectStore::loadProjectByExternal($clientId, $extId);
        if (!$project) ApiAuth::abort(404, 'project_not_found', "Project external_id='$extId' not found");

        $accountId = (int)($input['account_id'] ?? 0);
        if ($accountId <= 0) $accountId = (int)($project['webmaster_account_id'] ?? 0);
        if ($accountId <= 0) ApiAuth::abort(400, 'missing_account', 'webmaster account_id not set (передай account_id или задай webmaster_account_id у проекта)');

        return [$project, new CasinoWebmasterService($accountId), $accountId];
    }

    /** Нормализуем host_url для Яндекса: схема обязательна. */
    private function wmHostUrl(array $input): string
    {
        $h = trim((string)($input['host_url'] ?? ''));
        if ($h === '') ApiAuth::abort(400, 'missing_field', "Field 'host_url' required");
        if (!preg_match('~^https?://~i', $h)) $h = 'https://' . ltrim($h, '/');
        return $h;
    }

    /**
     * POST webmaster/add-host  {external_id, host_url, account_id?}
     * Добавляет хост в Вебмастер (или находит существующий). Авто-шаг после публикации.
     */
    public function webmasterAddHost(): void
    {
        $client = ApiAuth::require('casino.write');
        $input  = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        [, $svc] = $this->wmResolve($input, (int)$client['id']);
        $hostUrl = $this->wmHostUrl($input);

        try {
            $userId = $svc->getUserId();
            $res    = $svc->getOrCreateHostId($userId, $hostUrl);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'webmaster_error', $e->getMessage());
        }
        ApiAuth::ok([
            'user_id'         => $userId,
            'host_id'         => $res['host_id'],
            'host_url'        => $hostUrl,
            'already_existed' => $res['already_existed'],
        ]);
    }

    /**
     * POST webmaster/verify  {external_id, host_url, account_id?}
     * Кладёт verification-файл в КОРЕНЬ docroot проекта и запускает проверку прав.
     * Авто-шаг после add-host. Статус потом опрашивается через webmaster/verify-status.
     */
    /**
     * POST webmaster/prepare  {external_id, host_url, account_id?}
     * Добавляет хост (если надо) и возвращает имя+содержимое verification-файла.
     * ФАЙЛ НЕ ПИШЕТ: refresh стоит на другом сервере и не имеет доступа к docroot
     * сайта. Файл пишет casino-panel локально в свой docroot, затем зовёт verify.
     */
    public function webmasterPrepare(): void
    {
        $client = ApiAuth::require('casino.write');
        $input  = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        [, $svc] = $this->wmResolve($input, (int)$client['id']);
        $hostUrl = $this->wmHostUrl($input);

        try {
            $userId = $svc->getUserId();
            $host   = $svc->getOrCreateHostId($userId, $hostUrl);
            $verif  = $svc->getHtmlFileVerifier($userId, $host['host_id']);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'webmaster_error', $e->getMessage());
        }
        ApiAuth::ok([
            'user_id'              => $userId,
            'host_id'              => $host['host_id'],
            'host_url'             => $hostUrl,
            'already_existed'      => $host['already_existed'],
            'verification_file'    => $verif['file'],
            'verification_content' => $verif['content'],
            'verification_url'     => rtrim($hostUrl, '/') . '/' . $verif['file'],
        ]);
    }

    /**
     * POST webmaster/verify  {external_id, host_url, account_id?}
     * Запускает проверку прав (verifyHost) + возвращает текущий статус.
     * Предполагает, что verification-файл УЖЕ положен casino-panel в docroot.
     */
    public function webmasterVerify(): void
    {
        $client = ApiAuth::require('casino.write');
        $input  = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        [, $svc] = $this->wmResolve($input, (int)$client['id']);
        $hostUrl = $this->wmHostUrl($input);

        try {
            $userId = $svc->getUserId();
            $host   = $svc->getOrCreateHostId($userId, $hostUrl);
            $hostId = $host['host_id'];
            $svc->verifyHost($userId, $hostId, 'HTML_FILE');
            $status = $svc->verificationStatus($userId, $hostId);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'webmaster_error', $e->getMessage());
        }
        ApiAuth::ok([
            'user_id'  => $userId,
            'host_id'  => $hostId,
            'host_url' => $hostUrl,
            'state'    => $status['state'],
            'verified' => $status['verified'],
        ]);
    }

    /**
     * GET/POST webmaster/verify-status  {external_id, host_url, account_id?}
     * Опрос статуса проверки прав (VERIFIED / IN_PROGRESS / FAILED). casino-panel поллит.
     */
    public function webmasterVerifyStatus(): void
    {
        $client = ApiAuth::require('casino.read');
        $input  = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($input)) $input = $_GET;

        [, $svc] = $this->wmResolve($input, (int)$client['id']);
        $hostUrl = $this->wmHostUrl($input);
        try {
            $userId = $svc->getUserId();
            $host   = $svc->getOrCreateHostId($userId, $hostUrl);
            $status = $svc->verificationStatus($userId, $host['host_id']);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'webmaster_error', $e->getMessage());
        }
        ApiAuth::ok([
            'host_id'  => $host['host_id'],
            'host_url' => $hostUrl,
            'state'    => $status['state'],
            'verified' => $status['verified'],
        ]);
    }

    /**
     * POST webmaster/recrawl  {external_id, host_url, urls:[...], account_id?}
     * Ручной шаг: отправить URL на переобход.
     */
    public function webmasterRecrawl(): void
    {
        $client = ApiAuth::require('casino.write');
        $input  = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        [, $svc] = $this->wmResolve($input, (int)$client['id']);
        $hostUrl = $this->wmHostUrl($input);
        $urls    = is_array($input['urls'] ?? null) ? $input['urls'] : [];
        if (!$urls) ApiAuth::abort(400, 'missing_field', "Field 'urls' (array) required");

        try {
            $userId = $svc->getUserId();
            $host   = $svc->getOrCreateHostId($userId, $hostUrl);
            $res    = $svc->recrawlUrls($userId, $host['host_id'], $urls);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'webmaster_error', $e->getMessage());
        }
        ApiAuth::ok($res);
    }

    /**
     * POST webmaster/sitemap  {external_id, host_url, sitemap_url, account_id?}
     * Ручной шаг: добавить sitemap.
     */
    public function webmasterSitemap(): void
    {
        $client = ApiAuth::require('casino.write');
        $input  = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        [, $svc] = $this->wmResolve($input, (int)$client['id']);
        $hostUrl     = $this->wmHostUrl($input);
        $sitemapUrl  = trim((string)($input['sitemap_url'] ?? ''));
        if ($sitemapUrl === '') $sitemapUrl = rtrim($hostUrl, '/') . '/sitemap.xml';

        try {
            $userId = $svc->getUserId();
            $host   = $svc->getOrCreateHostId($userId, $hostUrl);
            $res    = $svc->addSitemap($userId, $host['host_id'], $sitemapUrl);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'webmaster_error', $e->getMessage());
        }
        ApiAuth::ok(['sitemap_url' => $sitemapUrl, 'result' => $res]);
    }

    /**
     * POST webmaster/robots  {external_id, host_url, account_id?}
     * "Подтверждение" robots.txt = HTTP-проверка доступности {host}/robots.txt
     * (у Яндекса нет API для этого — см. CasinoWebmasterService::confirmRobots).
     */
    public function webmasterRobots(): void
    {
        $client = ApiAuth::require('casino.write');
        $input  = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($input)) ApiAuth::abort(400, 'bad_json', 'POST body must be JSON');

        [, $svc] = $this->wmResolve($input, (int)$client['id']);
        $hostUrl = $this->wmHostUrl($input);
        try {
            $res = $svc->confirmRobots($hostUrl);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'webmaster_error', $e->getMessage());
        }
        ApiAuth::ok([
            'ok_robots'  => $res['ok'],
            'http'       => $res['http'],
            'robots_url' => $res['robots_url'],
            'result'     => $res,
        ]);
    }
}
