<?php

/**
 * Cron-эндпоинт для запуска оркестратора.
 *
 * Вызывается так:
 *   wget -O /dev/null -t 1 -q 'https://refresh-panel.seotop-one.ru/cron?token=XXX'
 *
 * Раз в минуту хостинг-cron должен пинговать этот URL.
 *
 * v18.1.29: ПАРАЛЛЕЛЬНАЯ ОБРАБОТКА ДЖОБ.
 *
 * Раньше cron обрабатывал ОДНУ джобу за tick — все остальные ждали в очереди.
 * Теперь cron:
 *  1. Проверяет токен
 *  2. Берёт PICKING LOCK (короткий, ~10ms)
 *  3. SELECT'ит до N джоб (default 5, configurable через cron.max_jobs_per_tick)
 *  4. Отпускает PICKING LOCK
 *  5. Для каждой джобы:
 *     - Берёт PER-JOB LOCK (если не получилось — другой воркер уже обрабатывает,
 *       пропускаем)
 *     - Обрабатывает один step через RefreshOrchestrator
 *     - Отпускает PER-JOB LOCK
 *
 * Это означает:
 *  - До 5 джоб обрабатываются ЗА ОДИН cron tick (sequential внутри PHP-процесса,
 *    но это всё равно 5x ускорение для пайплайна)
 *  - Параллельные cron-вызовы (если хостинг-cron агрессивный, или мы добавим
 *    "agressive mode" с пингом каждые 10 сек) автоматически делят джобы между
 *    собой через PER-JOB LOCK
 *  - Manual `⚡ Шаг сейчас` тоже параллельно с cron — но защищён от race
 *    через тот же PER-JOB LOCK
 *
 * Возвращает plain text — для wget это и нужно.
 *
 * Защита от утечки: если токен неверный — 403, никакой инфы наружу.
 */
class CronController extends Controller
{
    public function run(): void
    {
        header('Content-Type: text/plain; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow');

        $token = (string)($_GET['token'] ?? '');
        $guard = new CronGuard('refresh_orchestrator');

        if (!$guard->checkToken($token)) {
            http_response_code(403);
            echo "forbidden\n";
            return;
        }

        // v18.1.29: PICKING LOCK — короткий лок только на момент SELECT'а
        if (!$guard->acquirePickingLock()) {
            // 5 секунд таймаут вышел — что-то странное, не наше дело
            echo "busy_picking\n";
            return;
        }

        // PATCH 047 §20: ретенция аудита Webmaster API (30 дней). Троттлинг ~1/100 тиков,
        // чтобы не удалять на каждом запуске. Не влияет на подбор джоб.
        try {
            if (class_exists('YandexWebmasterHttpTransport') && random_int(1, 100) === 1) {
                YandexWebmasterHttpTransport::purgeOlderThanDays(30);
            }
        } catch (\Throwable $e) { /* ретеншн не должен влиять на cron */ }

        // v18.1.29: max_jobs_per_tick читается из БД (AppSettings) — оператор
        // может менять через UI. Fallback на config/app.php если в БД нет
        // (миграция 018 не применена). Дополнительный fallback на default = 5.
        $configDefault = (int)config('cron.max_jobs_per_tick', CronGuard::DEFAULT_MAX_JOBS_PER_TICK);
        $maxJobs = AppSettings::getInt('cron.max_jobs_per_tick', $configDefault);
        $maxJobs = max(1, min(50, $maxJobs));

        $stats = [
            'started_at' => date('c'),
            'max_jobs_per_tick' => $maxJobs,
            'jobs_picked' => 0,
            'jobs_processed' => 0,
            'jobs_skipped_lock' => 0,
            'job_results' => [],
        ];

        try {
            // 1) SELECT следующих джоб под picking-lock'ом
            $jobs = $guard->pickJobs($maxJobs);
            $stats['jobs_picked'] = count($jobs);

            // Отпускаем picking-lock СРАЗУ, до тяжёлой обработки.
            // Это позволяет параллельным cron-tick'ам брать следующие батчи
            // (если у нас 50 джоб и батч 5 — следующий tick возьмёт ещё 5
            // других, потому что наши уже под per-job lock'ом).
            $guard->releasePickingLock();

            if (empty($jobs)) {
                echo "idle: no pending jobs\n";
                $this->maybeRunHourlyBalanceCheck($stats);
                $this->autoStopAbandonedPollers($stats);
                $this->maybeRunRelocationIndexPoll($stats);
                $this->maybeAutoCloseInactiveJobs($stats);
                $this->maybeRunTrustedSslReconciler($stats);
                $this->maybeNotifyAwaitingJobs($stats);
                $this->maybeRunBanMonitoring($stats);
                $guard->finishOk($stats);
                return;
            }

            echo "picked " . count($jobs) . " job(s) (max_per_tick={$maxJobs})\n";

            // 2) Обрабатываем КАЖДУЮ под её собственным per-job lock'ом
            $orch = new RefreshOrchestrator();
            foreach ($jobs as $job) {
                $jobId = (int)$job['id'];
                $jobGuard = CronGuard::forJob($jobId);

                if (!$jobGuard->acquireJobLock()) {
                    // Другой cron-tick / manual runStep сейчас обрабатывает эту
                    // джобу. Пропускаем — он закончит и сохранит state.
                    $stats['jobs_skipped_lock']++;
                    echo "  job_id={$jobId}: locked by another worker, skipping\n";
                    continue;
                }

                try {
                    echo "  job_id={$jobId} stage={$job['stage']} status={$job['stage_status']}\n";

                    // v18.1.29: Stale-running recovery — между picking и acquire
                    // могла измениться ситуация. Перечитаем актуальное состояние.
                    $freshJob = $this->reloadJob($jobId);
                    if (!$freshJob) {
                        echo "    skipped: job disappeared\n";
                        continue;
                    }

                    // Не подхватывать те которые уже завершены (если другой
                    // воркер или оператор успел между нашим pick и lock).
                    // v24.2 (B2): cancelled/superseded — тоже терминальные.
                    if (JobLifecycleService::isTerminal((string)$freshJob['stage'])) {
                        echo "    skipped: stage={$freshJob['stage']}\n";
                        continue;
                    }

                    // Stalled running recovery
                    if ($freshJob['stage_status'] === 'running') {
                        echo "    warning: stalled running task, resetting to pending\n";
                        DB::pdo()->prepare(
                            "UPDATE refresh_jobs SET stage_status='pending' WHERE id=?"
                        )->execute([$jobId]);
                        $freshJob['stage_status'] = 'pending';
                    }

                    $orch->step($freshJob);

                    // Прочитаем итоговое состояние
                    $st = DB::pdo()->prepare(
                        "SELECT stage, stage_status FROM refresh_jobs WHERE id=?"
                    );
                    $st->execute([$jobId]);
                    $after = $st->fetch();

                    $stats['jobs_processed']++;
                    $stats['job_results'][] = [
                        'job_id' => $jobId,
                        'from_stage' => (string)$freshJob['stage'],
                        'from_status' => (string)$freshJob['stage_status'],
                        'to_stage' => $after['stage'] ?? '?',
                        'to_status' => $after['stage_status'] ?? '?',
                    ];

                    echo "    → stage={$after['stage']} status={$after['stage_status']}\n";
                } catch (\Throwable $e) {
                    // Ошибка обработки одной джобы — НЕ блокируем остальные
                    $msg = $e->getMessage();
                    error_log("CronController job {$jobId} step failed: " . $msg);
                    echo "    error: " . $msg . "\n";
                    $stats['job_results'][] = [
                        'job_id' => $jobId,
                        'error' => $msg,
                    ];
                } finally {
                    $jobGuard->releaseJobLock();
                }
            }

            echo "ok\n";

            // v18.1.28: после основной работы — фоновая проверка балансов
            $this->maybeRunHourlyBalanceCheck($stats);

            // v18.1.38: авто-стоп брошенных джоб-опросов (защита от вечного слива XMLStock)
            $this->autoStopAbandonedPollers($stats);

            // v22: фоновая проверка индекса выполняется на КАЖДОМ тике, а не только
            // когда очередь пуста — иначе на постоянно занятой панели суточная
            // проверка откладывалась бы неопределённо долго.
            $this->maybeRunRelocationIndexPoll($stats);
            // v25.2-a1 (§Блокер 3): критический путь активной job НЕ зависит от
            // /cron/ssl — основной cron сам двигает выпуск trusted SSL на каждом тике.
            $this->maybeAutoCloseInactiveJobs($stats);
                $this->maybeRunTrustedSslReconciler($stats);
            $this->maybeNotifyAwaitingJobs($stats);
            $this->maybeRunBanMonitoring($stats);

            $guard->finishOk($stats);
        } catch (\Throwable $e) {
            $msg = $e->getMessage();
            error_log("CronController: " . $msg);
            echo "error: " . $msg . "\n";
            $guard->finishError($msg);
            // На всякий случай освободим picking-lock если он почему-то остался
            $guard->releasePickingLock();
        }
    }

    /**
     * §15: фоновый ban worker (gated: processing_enabled && global XMLStock enabled)
     * + notification outbox worker (не зависит от XMLStock и monitor.next_check_at).
     * Ошибка одного элемента не роняет cron; ошибки сохраняются в summary.
     */
    private function maybeRunBanMonitoring(array &$stats): void
    {
        try {
            $ban = (new BanMonitorService())->runDue(0); // 0 → cron_batch_limit из настроек
            $notif = (new BanMonitorNotificationService())->runDue(20);
            $stats['ban_monitoring'] = array_merge($ban, [
                'notifications_sent' => (int)($notif['sent'] ?? 0),
                'notification_retries' => (int)($notif['retried'] ?? 0),
                'notifications_failed' => (int)($notif['failed'] ?? 0),
            ]);
        } catch (\Throwable $e) {
            $stats['ban_monitoring'] = ['error' => $e->getMessage()];
            error_log('[ban-monitor] ' . $e->getMessage());
        }
    }

    /**
     * v18.1.29: Перечитать актуальное состояние джобы (после взятия per-job
     * lock'а). Это нужно потому что между picking (SELECT) и acquire (GET_LOCK)
     * могло пройти время, и другой воркер мог изменить статус.
     */
    private function reloadJob(int $jobId): ?array
    {
        try {
            $st = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE id = ?");
            $st->execute([$jobId]);
            $row = $st->fetch();
            return $row ?: null;
        } catch (\Throwable $e) {
            error_log("CronController::reloadJob({$jobId}) failed: " . $e->getMessage());
            return null;
        }
    }

    /**
     * v18.1.28: Проверка балансов Namecheap и XMLStock.
     * Запускается 1 раз в час (когда last_checked_at >= 1 час назад).
     * Не блокирует cron — все ошибки ловятся и логируются.
     */
    /**
     * v22: суточная фоновая проверка индекса для раздела «Переезды».
     *
     * Отдельного состояния не нужно: запрос кандидатов сам ограничивает частоту
     * (index_checked_at старше интервала). Проверяются только те переезды, для
     * которых СЕЙЧАС не выполняется встроенная XMLStock-проверка внутри
     * final_monitoring — иначе платный лимит тратился бы дважды.
     */
    /**
     * v23: напоминание о джобах, ожидающих действия оператора дольше 3 суток.
     *
     * Логика блокировки создания джоб НЕ меняется — это только напоминание.
     * Само по себе оно закрывает основную часть проблемы: раньше такие джобы
     * не были видны, и сайт мог простаивать месяцами незамеченным.
     */
    /**
     * v25.2-a1.6.4: авто-закрытие джоб после N дней непрерывного ожидания
     * оператора. Раз в час (throttle), под отдельным advisory lock
     * rfp_jobs_auto_close (четыре параллельных cron не дублируют batch).
     * Вызывается ДО reconciler и notify, чтобы просроченная джоба не получила
     * ещё один SSL-тик/напоминание. После batch — SSL auto-archive + один summary.
     */
    private function maybeAutoCloseInactiveJobs(array &$stats): void
    {
        try {
            if (!AppSettings::getBool('jobs.auto_close_enabled', true)) {
                return;
            }
            $intervalMin = max(15, min(1440, AppSettings::getInt('jobs.auto_close_interval_minutes', 60)));
            $lastRun = AppSettings::getInt('jobs.auto_close_last_run_at', 0);
            if ($lastRun > 0 && (time() - $lastRun) < $intervalMin * 60) {
                return; // ещё не время
            }

            // Сериализация: только один cron-процесс выполняет batch.
            $pdo = DB::pdo();
            $lock = $pdo->prepare("SELECT GET_LOCK('rfp_jobs_auto_close', 0)");
            $lock->execute();
            if ((int)$lock->fetchColumn() !== 1) {
                return; // другой процесс уже закрывает
            }
            try {
                // Повторная проверка throttle под локом.
                $lastRun = AppSettings::getInt('jobs.auto_close_last_run_at', 0);
                if ($lastRun > 0 && (time() - $lastRun) < $intervalMin * 60) {
                    return;
                }
                AppSettings::setInt('jobs.auto_close_last_run_at', time());

                $days = max(1, min(365, AppSettings::getInt('jobs.auto_close_days', 30)));
                $batch = max(1, min(200, AppSettings::getInt('jobs.auto_close_batch', 50)));
                $res = JobLifecycleService::autoCloseInactiveJobs($days, $batch);

                if (($res['count'] ?? 0) > 0) {
                    $stats['auto_close'] = $res;
                    echo "  auto-close: закрыто джоб=" . (int)$res['count'] . "\n";

                    // §9: сразу убираем SSL-домены закрытых джоб из «Активных».
                    try { (new DomainSslStatusRepository())->autoArchiveStale(); }
                    catch (\Throwable $e) { error_log('auto-close SSL archive failed: ' . $e->getMessage()); }

                    // §11: один summary на весь batch (best effort, после commit).
                    $this->sendAutoCloseSummary($res['closed'] ?? []);
                }
            } finally {
                $rel = $pdo->prepare("SELECT RELEASE_LOCK('rfp_jobs_auto_close')");
                $rel->execute();
            }
        } catch (\Throwable $e) {
            // Никогда не роняем основной cron из-за авто-close.
            error_log('CronController auto-close failed: ' . $e->getMessage());
        }
    }

    /** §11: единый Telegram-summary по закрытым джобам (не по одной на джобу). */
    private function sendAutoCloseSummary(array $closed): void
    {
        if (empty($closed)) return;
        try {
            $n = count($closed);
            $lines = ["🧹 Автоматически закрыто {$n} неактивных джоб", ''];
            foreach (array_slice($closed, 0, 30) as $c) {
                $dom = (string)($c['domain'] ?? '');
                $lines[] = "#{$c['id']} {$dom} — ожидала {$c['idle_days']} дн."
                    . ($c['target'] === 'done' ? ' (завершена)' : ' (отменена)');
            }
            if ($n > 30) $lines[] = "…и ещё " . ($n - 30);
            (new TelegramService())->send(implode("\n", $lines));
        } catch (\Throwable $e) {
            error_log('auto-close summary telegram failed: ' . $e->getMessage());
        }
    }

    private function maybeNotifyAwaitingJobs(array &$stats): void
    {
        try {
            $days = AppSettings::getInt('jobs.awaiting_notify_days', AwaitingActionService::NOTIFY_AFTER_DAYS);
            $days = max(1, min(60, $days));
            $res = AwaitingActionService::notifyLongWaiting($days);
            if (!empty($res['sent'])) {
                $stats['awaiting_jobs_notify'] = $res;
                echo "  awaiting jobs notify: отправлено, джоб=" . (int)($res['count'] ?? 0) . "\n";
            }
        } catch (\Throwable $e) {
            error_log('CronController awaiting jobs notify failed: ' . $e->getMessage());
        }
    }

    /**
     * v25.2-a1 (§Блокер 1/2/3): фактический выпуск trusted SSL из ОСНОВНОГО cron.
     * Тонкая обёртка — вся логика в TrustedSslReconciler (переиспользует
     * SslIssuerService::pollLetsEncrypt). Обрабатывает несколько активных джоб,
     * ожидающих trusted SSL, на каждом тике. Не зависит от /cron/ssl.
     */
    private function maybeRunTrustedSslReconciler(array &$stats): void
    {
        try {
            if (!AppSettings::getBool('ssl.reconciler_enabled', true)) {
                $stats['ssl_reconciler'] = ['skipped' => 'disabled'];
                return;
            }
            $limit = max(1, min(10, AppSettings::getInt('ssl.reconciler_batch', 3)));
            $reconciler = new TrustedSslReconciler();
            $r = $reconciler->runTick($limit);
            $stats['ssl_reconciler'] = $r;
            if (($r['processed'] ?? 0) > 0) {
                echo "  trusted SSL reconciler: processed={$r['processed']}, issued={$r['issued']}, pending={$r['pending']}, fatal={$r['fatal']}\n";
            }
        } catch (\Throwable $e) {
            // Никогда не роняем основной cron из-за reconciler.
            error_log('CronController trusted SSL reconciler failed: ' . $e->getMessage());
            $stats['ssl_reconciler'] = ['error' => $e->getMessage()];
        }
    }

    private function maybeRunRelocationIndexPoll(array &$stats): void
    {
        try {
            $intervalHours = AppSettings::getInt('relocation.index_poll_interval_hours', 24);
            $intervalHours = max(1, min(720, $intervalHours));
            $batch = AppSettings::getInt('relocation.index_poll_batch', 25);
            $batch = max(1, min(200, $batch));

            $candidates = RelocationIndexChecker::pollCandidates($intervalHours, $batch);
            if (empty($candidates)) {
                return;
            }

            // H11: до 25 последовательных HTTP-запросов внутри основного cron могут
            // занять минуты. Ограничиваем общее время батча, остаток уйдёт в следующий
            // тик (кандидаты сортируются по давности проверки, ничего не потеряется).
            $maxSeconds = AppSettings::getInt('relocation.index_poll_max_seconds', 60);
            $maxSeconds = max(5, min(600, $maxSeconds));
            $startedAt = microtime(true);

            // Баланс XMLStock проверяем ОДИН раз на батч, а не перед каждым доменом.
            $balanceLow = false;
            try {
                if (class_exists('BalanceCheckService')) {
                    $br = (new BalanceCheckService())->checkOne('xmlstock', 'relocation_index_poll', 'default');
                    $balanceLow = (!empty($br['ok']) && ($br['status'] ?? '') === 'low');
                }
            } catch (\Throwable $e) {
                $balanceLow = false;
            }
            if ($balanceLow) {
                $stats['relocation_index_poll'] = ['skipped' => 'low_balance'];
                echo "  relocation index poll: пропущен — баланс XMLStock ниже порога\n";
                return;
            }

            $done = 0; $indexed = 0; $errors = 0; $skipped = 0; $stoppedByTime = false;
            foreach ($candidates as $c) {
                if ((microtime(true) - $startedAt) >= $maxSeconds) {
                    $stoppedByTime = true;
                    break;
                }
                $res = RelocationIndexChecker::check(
                    (int)$c['id'], (string)$c['new_domain'], 'cron', null, true
                );
                $done++;
                if (!empty($res['skipped']))            $skipped++;
                elseif (($res['status'] ?? '') === 'indexed')     $indexed++;
                elseif (($res['status'] ?? '') === 'check_error') $errors++;
            }

            $stats['relocation_index_poll'] = [
                'checked' => $done, 'indexed' => $indexed,
                'errors'  => $errors, 'skipped' => $skipped,
                'interval_hours' => $intervalHours,
                'stopped_by_time' => $stoppedByTime,
            ];
            echo "  relocation index poll: checked={$done}, indexed={$indexed}, errors={$errors}, skipped={$skipped}"
               . ($stoppedByTime ? " (лимит времени, остаток в следующем тике)" : "") . "\n";

        } catch (\Throwable $e) {
            // Таблицы может ещё не быть (миграция 023 не применена) — не роняем cron.
            error_log('CronController relocation index poll failed: ' . $e->getMessage());
        }
    }

    private function maybeRunHourlyBalanceCheck(array &$stats): void
    {
        try {
            $st = DB::pdo()->query("SELECT service, account_label, last_checked_at FROM balance_current");
            $rows = $st->fetchAll();
            if (empty($rows)) return;

            $needCheck = false;
            $thresholdSec = 3600;
            foreach ($rows as $r) {
                if (empty($r['last_checked_at'])) { $needCheck = true; break; }
                $age = time() - strtotime((string)$r['last_checked_at']);
                if ($age >= $thresholdSec) { $needCheck = true; break; }
            }

            if (!$needCheck) return;

            $checker = new BalanceCheckService();
            $results = $checker->checkAll('cron');

            $stats['balance_check'] = [];
            foreach ($results as $key => $r) {
                $stats['balance_check'][$key] = [
                    'status'  => (string)($r['status'] ?? '?'),
                    'balance' => isset($r['balance']) ? (float)$r['balance'] : null,
                    'currency'=> (string)($r['currency'] ?? ''),
                    'alert_sent' => (bool)($r['alert_sent'] ?? false),
                ];
            }
            echo "  balance check: " . count($results) . " service(s) checked\n";
        } catch (\Throwable $e) {
            error_log("CronController hourly balance check failed: " . $e->getMessage());
            echo "  balance check failed: " . $e->getMessage() . "\n";
        }
    }

    /**
     * v18.1.38: АВТО-СТОП брошенных джоб-опросов.
     *
     * Проблема: стадии index_watching / final_monitoring опрашивают индексацию
     * бесконечно (v18.1.22 убрал таймаут). Если домен так и не индексируется /
     * переезд не подтверждается — джоба висит месяцами и продолжает жечь запросы
     * к XMLStock по 1/сутки. Каждая такая брошенная джоба = постоянный фоновый
     * расход, который копится.
     *
     * Решение: если polling-стадия идёт дольше порога (по умолчанию 30 дней) —
     * переводим джобу в awaiting_user + next_run_at=NULL (cron её больше НЕ берёт,
     * опрос останавливается, XMLStock перестаёт тратиться) и один раз шлём TG.
     * Оператор видит джобу в списке awaiting и может возобновить её вручную
     * (кнопки перезапуска мониторинга/индексации в карточке джобы или
     * «Возобновить» на странице /xmlstock).
     *
     * Порог настраивается через AppSettings ключ 'cron.abandoned_poller_days'
     * (0 = функция отключена). Джобы, поставленные на паузу оператором вручную
     * (next_run_at = pause-sentinel), НЕ трогаем.
     */
    /**
     * v18.1.38: контроль долго висящих джоб-опросов.
     *
     * Стадии index_watching / final_monitoring опрашивают индексацию/переезд
     * бесконечно (v18.1.22 убрал таймаут) и тратят XMLStock. Если стадия идёт
     * дольше порога (по умолчанию 30 дней):
     *
     *   • move-режимы (move_indexed / move_simple): подтверждение переезда от
     *     Яндекса может прийти поздно и оно критично — НЕ останавливаем. Раз в
     *     период шлём напоминание «висит долго» со ссылкой на страницу
     *     мониторинга (/xmlstock), где оператор сам ставит стоп.
     *
     *   • остальные (index_watching / refresh): считаем джобу брошенной →
     *     авто-стоп: awaiting_user + next_run_at=NULL (cron её больше НЕ берёт,
     *     опрос прекращается) + однократный TG. Возобновление — вручную.
     *
     * Порог — AppSettings 'cron.abandoned_poller_days' (0 = функция отключена).
     * Джобы, поставленные на паузу вручную (next_run_at = pause-sentinel), не трогаем.
     *
     * ВАЖНО: возраст стадии берём из АРТЕФАКТОВ (started_at / started_at_unix),
     * а НЕ из колонки stage_started_at — она сбрасывается в NOW() на каждом тике.
     */
    private function autoStopAbandonedPollers(array &$stats): void
    {
        try {
            $days = AppSettings::getInt('cron.abandoned_poller_days', 30);
            if ($days <= 0) {
                return; // функция отключена
            }
            $thresholdSec = $days * 86400;

            // Sentinel паузы со страницы /xmlstock — такие джобы не считаем брошенными.
            $pauseSentinel = '2900-01-01 00:00:00';

            // ВАЖНО: НЕ используем stage_started_at как возраст стадии — он сбрасывается
            // в NOW() на КАЖДОМ тике опроса (setStatus(...,'stage_started_at')). Реальное
            // начало polling-стадии хранится ОДИН раз в артефактах:
            //   index_watching_stage.started_at     (unix int)
            //   final_monitoring_stage.started_at_unix (unix int) / .started_at (datetime)
            // Поэтому тянем кандидатов и считаем возраст в PHP по артефактам.
            $st = DB::pdo()->prepare(
                "SELECT id, old_domain, new_domain, stage, mode, created_at, artifacts_json
                 FROM refresh_jobs
                 WHERE stage IN ('index_watching','final_monitoring')
                   AND stage_status IN ('pending','ok')
                   AND (next_run_at IS NULL OR next_run_at < ?)
                 ORDER BY id ASC
                 LIMIT 200"
            );
            $st->execute([$pauseSentinel]);
            $candidates = $st->fetchAll() ?: [];

            if (empty($candidates)) {
                return;
            }

            $now = time();
            $stopped = [];
            $notified = [];

            // Ссылка на страницу мониторинга (для TG) — оператор сам ставит стоп.
            $panelUrl = rtrim((string)config('app.url', 'https://refresh-panel.seotop-one.ru'), '/');
            $monitorLink = $panelUrl . '/xmlstock';

            foreach ($candidates as $job) {
                $jobId = (int)$job['id'];
                $stage = (string)$job['stage'];
                $mode  = (string)($job['mode'] ?? 'refresh');

                // Определяем реальное начало стадии из артефактов.
                $artifactsJson = (string)($job['artifacts_json'] ?? '');
                $startUnix = $this->pollingStageStartUnix($stage, $artifactsJson);
                // Fallback — created_at джобы (грубая нижняя граница, если артефакт пуст).
                if ($startUnix <= 0 && !empty($job['created_at'])) {
                    $startUnix = strtotime((string)$job['created_at']) ?: 0;
                }
                if ($startUnix <= 0) {
                    continue; // не смогли определить возраст — не трогаем
                }

                $ageSec = $now - $startUnix;
                if ($ageSec < $thresholdSec) {
                    continue; // ещё не брошена
                }
                $ageDays = (int)floor($ageSec / 86400);

                $oldDom = (string)$job['old_domain'];
                $newDom = (string)$job['new_domain'];
                $stageKey = $stage === 'final_monitoring' ? 'final_monitoring_stage' : 'index_watching_stage';

                // move_indexed / move_simple: ПОДТВЕРЖДЕНИЕ ПЕРЕЕЗДА от Яндекса может
                // прийти поздно и оно критично — АВТОМАТИЧЕСКИ НЕ ОСТАНАВЛИВАЕМ.
                // Вместо этого раз в период (порог) шлём напоминание «висит долго»
                // со ссылкой на страницу мониторинга, где оператор сам ставит стоп.
                $isMove = in_array($mode, ['move_indexed', 'move_simple'], true);

                if ($isMove) {
                    // Anti-spam: напоминаем не чаще одного раза за период (порог).
                    $lastAlert = 0;
                    $a = json_decode($artifactsJson, true);
                    if (is_array($a)) {
                        $la = (string)($a[$stageKey]['long_running_alert_last_at'] ?? '');
                        if ($la !== '') $lastAlert = strtotime($la) ?: 0;
                    }
                    if ($lastAlert > 0 && ($now - $lastAlert) < $thresholdSec) {
                        continue; // недавно уже напоминали
                    }

                    // Отметка в артефактах (чтобы не спамить)
                    try {
                        // v24.3 (H2): stale-guard — кандидат выбран заранее,
                        // джобу могли закрыть/завершить; терминальную не трогаем.
                        $stFlag = DB::pdo()->prepare(
                            "UPDATE refresh_jobs SET
                                artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                             WHERE id = ?
                               AND stage IN ('index_watching','final_monitoring')
                               AND stage NOT IN ('done','failed','cancelled','superseded')"
                        );
                        $stFlag->execute([
                            json_encode([$stageKey => [
                                'long_running_alert_last_at' => date('Y-m-d H:i:s'),
                                'long_running_age_days'      => $ageDays,
                            ]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                            $jobId,
                        ]);
                        if ($stFlag->rowCount() !== 1) {
                            // v24.3 (H2): джоба ушла из polling-стадии (закрыта/
                            // завершена) — напоминание неактуально, пропускаем.
                            echo "  long-running move poller: job_id={$jobId} state changed, skip\n";
                            continue;
                        }
                    } catch (\Throwable $e) {
                        error_log("CronController longRunning job {$jobId} DB flag failed: " . $e->getMessage());
                        continue;
                    }

                    try {
                        $logger = new JobEventLogger($jobId);
                        $logger->warn($stage,
                            "Мониторинг переезда идёт уже {$ageDays} дн. (порог {$days} дн.), " .
                            "переезд ещё не подтверждён. Автоматически НЕ останавливаем (move-режим). " .
                            "Если нужно прекратить опрос — поставь стоп на странице XMLStock: {$monitorLink}");
                    } catch (\Throwable $e) {}

                    try {
                        $tg = new TelegramService();
                        $tg->notifyImportant($jobId,
                            'Мониторинг переезда висит долго',
                            "Старый: <code>" . htmlspecialchars($oldDom, ENT_QUOTES, 'UTF-8') . "</code>\n" .
                            "Новый:  <code>" . htmlspecialchars($newDom, ENT_QUOTES, 'UTF-8') . "</code>\n" .
                            "Режим: <b>{$mode}</b>, стадия: <b>{$stage}</b>\n" .
                            "Идёт: <b>{$ageDays} дн.</b> (порог {$days} дн.), переезд ещё не подтверждён Яндексом.\n\n" .
                            "Мы НЕ останавливаем автоматически — подтверждение переезда может прийти позже. " .
                            "Но всё это время тратится XMLStock. Если хочешь остановить опрос вручную — " .
                            "открой страницу мониторинга и нажми стоп:\n" .
                            "<a href=\"" . htmlspecialchars($monitorLink, ENT_QUOTES, 'UTF-8') . "\">Мониторинг XMLStock</a>"
                        );
                    } catch (\Throwable $e) {
                        error_log("CronController longRunning job {$jobId} TG failed: " . $e->getMessage());
                    }

                    $notified[] = ['job_id' => $jobId, 'stage' => $stage, 'age_days' => $ageDays, 'action' => 'notify_only'];
                    echo "  long-running move poller (notify only): job_id={$jobId} stage={$stage} age={$ageDays}d\n";
                    continue;
                }

                // Остальные (index_watching / refresh) — брошены → авто-стоп.
                $reason = "{$stage}: авто-стоп после {$ageDays} дн. без результата " .
                          "(порог {$days} дн.). Опрос XMLStock остановлен, чтобы не тратить lim впустую.";

                // Останавливаем: awaiting_user + next_run_at=NULL → cron больше не берёт.
                try {
                    // v24.3 (H2): stale-guard — между выборкой кандидатов и этим
                    // UPDATE джобу могли закрыть; терминальную не перезаписываем.
                    $stStop = DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET
                            stage_status = 'awaiting_user',
                            stage_error = ?,
                            stage_finished_at = NOW(),
                            next_run_at = NULL
                         WHERE id = ?
                           AND stage IN ('index_watching','final_monitoring')
                           AND stage NOT IN ('done','failed','cancelled','superseded')"
                    );
                    $stStop->execute([mb_substr($reason, 0, 1000), $jobId]);
                    if ($stStop->rowCount() !== 1) {
                        echo "  auto-stop: job_id={$jobId} state changed, skip\n";
                        continue;
                    }

                    // Пометка в артефактах (для UI/истории), не критично если упадёт.
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET
                            artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                         WHERE id = ?
                           AND stage NOT IN ('done','failed','cancelled','superseded')"
                    )->execute([
                        json_encode([$stageKey => [
                            'auto_stopped_at'     => date('Y-m-d H:i:s'),
                            'auto_stopped_reason' => $reason,
                            'auto_stopped_age_days' => $ageDays,
                        ]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        $jobId,
                    ]);
                } catch (\Throwable $e) {
                    error_log("CronController autoStop job {$jobId} DB update failed: " . $e->getMessage());
                    continue;
                }

                // Событие в лог джобы (если логгер доступен).
                try {
                    $logger = new JobEventLogger($jobId);
                    $logger->warn($stage,
                        "Авто-стоп: стадия идёт {$ageDays} дн. (порог {$days} дн.) без результата. " .
                        "Опрос остановлен, XMLStock по этой джобе больше не тратится. " .
                        "Чтобы продолжить — возобнови вручную (карточка джобы или страница XMLStock).");
                } catch (\Throwable $e) {}

                // Telegram — один раз (после стопа джоба выходит из pending, повторно не выберется).
                try {
                    $tg = new TelegramService();
                    $tg->notifyImportant($jobId,
                        'Опрос остановлен — брошенная джоба',
                        "Старый: <code>" . htmlspecialchars($oldDom, ENT_QUOTES, 'UTF-8') . "</code>\n" .
                        "Новый:  <code>" . htmlspecialchars($newDom, ENT_QUOTES, 'UTF-8') . "</code>\n" .
                        "Стадия: <b>{$stage}</b>\n" .
                        "Идёт: <b>{$ageDays} дн.</b> (порог {$days} дн.) без результата.\n\n" .
                        "Опрос индексации остановлен, чтобы не тратить XMLStock впустую. " .
                        "Джоба переведена в «ожидает оператора». Возобновить можно вручную:\n" .
                        "<a href=\"" . htmlspecialchars($monitorLink, ENT_QUOTES, 'UTF-8') . "\">Мониторинг XMLStock</a> " .
                        "или в карточке джобы (перезапуск мониторинга/индексации)."
                    );
                } catch (\Throwable $e) {
                    error_log("CronController autoStop job {$jobId} TG failed: " . $e->getMessage());
                }

                $stopped[] = ['job_id' => $jobId, 'stage' => $stage, 'age_days' => $ageDays];
                echo "  auto-stopped abandoned poller: job_id={$jobId} stage={$stage} age={$ageDays}d\n";
            }

            if (!empty($stopped)) {
                $stats['auto_stopped_pollers'] = $stopped;
            }
            if (!empty($notified)) {
                $stats['long_running_notified'] = $notified;
            }
        } catch (\Throwable $e) {
            error_log("CronController autoStopAbandonedPollers failed: " . $e->getMessage());
            echo "  auto-stop check failed: " . $e->getMessage() . "\n";
        }
    }

    /**
     * v18.1.38: реальное начало polling-стадии (unix) из артефактов джобы.
     * Возвращает 0 если определить не удалось.
     */
    private function pollingStageStartUnix(string $stage, string $artifactsJson): int
    {
        if ($artifactsJson === '') return 0;
        $a = json_decode($artifactsJson, true);
        if (!is_array($a)) return 0;

        if ($stage === 'final_monitoring') {
            $s = $a['final_monitoring_stage'] ?? [];
            $u = (int)($s['started_at_unix'] ?? 0);
            if ($u > 0) return $u;
            if (!empty($s['started_at'])) return strtotime((string)$s['started_at']) ?: 0;
            return 0;
        }

        // index_watching_stage.started_at — unix int
        $s = $a['index_watching_stage'] ?? [];
        $u = (int)($s['started_at'] ?? 0);
        // started_at может быть и datetime-строкой в некоторых старых записях
        if ($u <= 0 && !empty($s['started_at']) && !is_numeric($s['started_at'])) {
            $u = strtotime((string)$s['started_at']) ?: 0;
        }
        return $u > 0 ? $u : 0;
    }

    /**
     * v25.1-b (§6): SSL-мониторинг cron. Проверяет домены, которым пора
     * (по next_check_at), и обрабатывает пачку текущего batch «Проверить все».
     * Каждый домен — под advisory-lock rfp_ssl_<sha1>, без двойной проверки.
     * Ограничено ssl.max_checks_per_tick.
     */
    public function runSsl(): void
    {
        header('Content-Type: text/plain; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow');

        $token = (string)($_GET['token'] ?? '');
        $guard = new CronGuard('ssl_monitor');
        if (!$guard->checkToken($token)) {
            http_response_code(403);
            echo "forbidden\n";
            return;
        }
        if (!AppSettings::getBool('ssl.monitor_enabled', true)) {
            echo "ssl_monitor_disabled\n";
            return;
        }

        $max = max(1, AppSettings::getInt('ssl.max_checks_per_tick', 10));
        $repo = new DomainSslStatusRepository();
        $ctrl = new SslController();
        $processed = 0;

      try {
        // v25.1-b1: enrol только новые домены активных джоб (НЕ импорт sites_managed),
        // и авто-архив залётных старых записей (наследие тестовой версии).
        // v25.1-b1.2 (§2.3): страховочный enrolment — только активные джобы,
        // достигшие aliases_added или позже. Основной путь — enrolment прямо в
        // aliases_added; это подстраховка на случай сбоя между стадией и upsert.
        $enrolled = $repo->ensureActiveJobDomains();
        $archived = $repo->autoArchiveStale();

        // 1) Пачка текущего batch (приоритет — виден прогресс пользователю).
        $batchId = $repo->currentRunningBatchId();
        if ($batchId !== null) {
            $chunk = $repo->claimBatchChunk($batchId, $max);
            foreach ($chunk as $row) {
                if ($processed >= $max) break;
                $domain = (string)$row['domain'];
                $outcome = $this->sslCheckOneLocked($ctrl, $domain);
                // b1.1: помечаем done ТОЛЬКО при реальном исходе.
                if ($outcome['result'] === 'checked') {
                    $repo->markBatchDomainDone($batchId, $domain);
                    $processed++;
                } elseif ($outcome['result'] === 'fatal_error') {
                    // Есть сохранённый error-result — считаем обработанным.
                    $repo->markBatchDomainError($batchId, $domain, (string)$outcome['error']);
                    $processed++;
                } else {
                    // lock_busy / temporary_error → обратно в очередь, done НЕ трогаем.
                    $repo->requeueBatchDomain($batchId, $domain, $outcome['error'] ?? null);
                }
            }
        }

        // 2) Плановые проверки по next_check_at (оставшийся бюджет).
        if ($processed < $max) {
            $due = $repo->dueForCron($max - $processed);
            foreach ($due as $row) {
                if ($processed >= $max) break;
                $out = $this->sslCheckOneLocked($ctrl, (string)$row['domain']);
                if ($out['result'] === 'checked' || $out['result'] === 'fatal_error') $processed++;
                // lock_busy/temporary — просто попробуем в следующий tick (next_check_at не сдвинут).
            }
        }

        echo "ssl_checked={$processed} enrolled={$enrolled} archived={$archived}\n";
        // v25.2-b (§Блокер 3): heartbeat SSL-cron сохраняется ВСЕГДА, даже при 0 доменов.
        $guard->finishOk(['checked' => $processed, 'enrolled' => $enrolled, 'archived' => $archived]);
      } catch (\Throwable $e) {
        error_log('CronController runSsl failed: ' . $e->getMessage());
        echo "error: " . $e->getMessage() . "\n";
        $guard->finishError($e->getMessage());
      }
    }

    /**
     * Одна SSL-проверка домена под advisory-lock. b1.1: возвращает исход
     * ['result'=>'checked'|'lock_busy'|'temporary_error'|'fatal_error', 'error'=>?str].
     * - lock busy → 'lock_busy' (домен уже проверяется другим процессом);
     * - проверка прошла (любой статус, включая unreachable) → 'checked';
     * - исключение: транзиентное (timeout/connection/5xx/deadlock) → 'temporary_error';
     *   иначе сохраняем error-result и → 'fatal_error'.
     */
    private function sslCheckOneLocked(SslController $ctrl, string $domain): array
    {
        $lock = SslController::lockName($domain);
        try {
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, ?)");
            $st->execute([substr($lock, 0, 64), 0]);
            if ((int)$st->fetchColumn() !== 1) return ['result' => 'lock_busy', 'error' => null];
        } catch (\Throwable $e) {
            return ['result' => 'temporary_error', 'error' => 'lock_error: ' . $e->getMessage()];
        }
        try {
            $ctrl->runCheckForDomain($domain, 'cron');
            return ['result' => 'checked', 'error' => null];
        } catch (\Throwable $e) {
            $msg = $e->getMessage();
            error_log('ssl cron check failed for ' . $domain . ': ' . $msg);
            $low = mb_strtolower($msg);
            $transient = false;
            foreach (['timeout','timed out','connection','could not resolve','network','deadlock',
                      'try again','temporarily','500','502','503','504','gateway','reset by peer',
                      'lock wait','server has gone away'] as $needle) {
                if (mb_strpos($low, $needle) !== false) { $transient = true; break; }
            }
            if ($transient) return ['result' => 'temporary_error', 'error' => $msg];
            // Фатально: сохраняем реальный error-result, чтобы batch двигался.
            try {
                $repo = new DomainSslStatusRepository();
                $repo->saveResult([
                    'domain' => $domain, 'status' => DomainSslCheckService::S_UNREACHABLE,
                    'reason' => 'check_exception', 'error_message' => mb_substr($msg, 0, 512),
                    'technical_ready' => 0, 'site_reachable' => 0, 'checked_at' => date('Y-m-d H:i:s'),
                    'check_source' => 'cron',
                ]);
            } catch (\Throwable $e2) { /* даже это не удалось — вернём fatal */ }
            return ['result' => 'fatal_error', 'error' => $msg];
        } finally {
            try { DB::pdo()->prepare("SELECT RELEASE_LOCK(?)")->execute([substr($lock, 0, 64)]); } catch (\Throwable $e) {}
        }
    }
}
