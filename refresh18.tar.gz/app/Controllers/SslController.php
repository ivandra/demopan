<?php

/**
 * v25.1-b: контроллер вкладки SSL.
 *
 * Маршруты (ТЗ §4.1):
 *   GET  /ssl                 — таблица + сводка + прогресс batch
 *   GET  /ssl/show            — подробности проверки одного домена (§4.6)
 *   POST /ssl/check           — ручная проверка одного домена (§5)
 *   POST /ssl/check-all       — поставить все домены в batch (§5.1)
 *   POST /ssl/batch-progress  — AJAX-прогресс batch (JSON)
 *   POST /ssl/batch-stop      — остановить batch (отменить не начатые)
 *
 * Все POST — только после авторизации, под advisory-lock домена
 * rfp_ssl_<sha1(domain)> (для одиночной проверки), без двойной проверки.
 */
class SslController extends Controller
{
    /** Имя advisory-lock по домену (ТЗ §4.1). */
    public static function lockName(string $domain): string
    {
        return 'rfp_ssl_' . sha1(strtolower(trim($domain)));
    }

    public function index(): void
    {
        $this->requireAuth();
        $repo = new DomainSslStatusRepository();

        $filters = [
            'scope'        => in_array(($_GET['scope'] ?? 'active'), ['archived', 'all'], true) ? ($_GET['scope']) : 'active',
            'q'            => trim((string)($_GET['q'] ?? '')),
            'status'       => trim((string)($_GET['status'] ?? '')),
            'availability' => trim((string)($_GET['availability'] ?? '')),
            'source'       => trim((string)($_GET['source'] ?? '')),
            'batch'        => trim((string)($_GET['batch'] ?? '')),
            'server_id'    => (int)($_GET['server_id'] ?? 0),   // ТЗ 040 §8.4
        ];
        $allowedPer = [25, 50, 100];
        $perPage = (int)($_GET['per'] ?? 25);
        if (!in_array($perPage, $allowedPer, true)) $perPage = 25;
        $page = max(1, (int)($_GET['page'] ?? 1));

        $paged = $repo->listDomainsPaged($filters, $page, $perPage);
        $summary = $repo->summary(['server_id' => (int)($filters['server_id'] ?? 0)]);
        $batchId = $repo->currentRunningBatchId();
        $batch = $batchId !== null ? $repo->batchProgress($batchId) : null;

        $this->view('ssl/index', [
            'rows' => $paged['rows'],
            'total' => $paged['total'],
            'page' => $page,
            'perPage' => $perPage,
            'filters' => $filters,
            'summary' => $summary,
            'batch' => $batch,
            'cronHeartbeat' => $repo->cronHeartbeat(),
            'servers' => ServerBadgePresenter::serversForFilter(),
            'serverFilter' => (int)$filters['server_id'],
            'badgeBySite' => (new ServerBadgePresenter())->badgeMapBySite(),
        ]);
    }

    public function show(): void
    {
        $this->requireAuth();
        $domain = strtolower(trim((string)($_GET['domain'] ?? '')));
        if ($domain === '') { $this->redirect('/ssl'); return; }
        $repo = new DomainSslStatusRepository();
        // v25.1-b1.2.1: передаём SSL-запись как $sslRow, НЕ $status. Имя $status
        // перезаписывается в layout.php (вывод балансов) до подключения вью, из-за
        // чего внутри ssl/show.php $status оказывался строкой → HTTP 500.
        $sslRow = $repo->getByDomain($domain);

        if (!is_array($sslRow)) {
            http_response_code(404);
            $this->view('ssl/show', [
                'domain' => $domain,
                'sslRow' => null,
                'history' => [],
                'not_found' => true,
                'serverBadge' => null,
            ]);
            return;
        }

        // ТЗ 040 §9.4/§9.6: бейдж сервера готовит контроллер (не View).
        // ТЗ 040 FINAL-3 §3.7: сервер по effective site = COALESCE(d.site_id, j.site_id),
        // чтобы SSL-запись, связанная только через job_id, тоже нашла сервер и бейдж.
        $serverBadge = null;
        $sbSt = DB::pdo()->prepare(
            "SELECT fps.ui_badge_code, fps.ui_badge_label, fps.ui_badge_color, fps.title AS server_title
               FROM domain_ssl_statuses d
               LEFT JOIN refresh_jobs j ON j.id = d.job_id
               LEFT JOIN sites_managed s ON s.id = COALESCE(d.site_id, j.site_id)
               LEFT JOIN fastpanel_servers fps ON fps.id = s.fastpanel_server_id
              WHERE d.domain = ?"
        );
        $sbSt->execute([$domain]);
        if ($sbRow = $sbSt->fetch()) $serverBadge = (new ServerBadgePresenter())->fromRow($sbRow);

        $this->view('ssl/show', [
            'domain' => $domain,
            'sslRow' => $sslRow,
            'history' => $repo->historyForDomain($domain, 20),
            'not_found' => false,
            'serverBadge' => $serverBadge,
        ]);
    }

    /** Ручная проверка одного домена (§5). */
    public function check(): void
    {
        $this->requireAuth();
        $domain = strtolower(trim((string)($_POST['domain'] ?? '')));
        $isAjax = !empty($_POST['ajax']);
        if ($domain === '') {
            if ($isAjax) $this->jsonErr('empty domain');
            $this->flash('error', 'Не указан домен'); $this->redirect('/ssl'); return;
        }

        // ТЗ 041 §5.2: разовая проверка не подключает домен неявно. Домен должен
        // уже существовать в мониторинге — иначе просим «Добавить домен».
        $repo0 = new DomainSslStatusRepository();
        if ($repo0->getByDomain($domain) === null) {
            $msg = 'Домен не подключён к SSL-мониторингу. Сначала используйте действие «Добавить домен».';
            if ($isAjax) $this->jsonErr($msg);
            $this->flash('error', $msg); $this->redirect('/ssl'); return;
        }

        // Advisory lock — не проверяем один домен параллельно (§4.1, §15.10).
        $lock = self::lockName($domain);
        if (!$this->acquireLock($lock)) {
            if ($isAjax) $this->jsonErr('Домен уже проверяется', 409);
            $this->flash('error', 'Домен уже проверяется другим процессом'); $this->redirect('/ssl/show?domain=' . urlencode($domain)); return;
        }
        try {
            // §5.2: разовая проверка — источник manual_check, тип мониторинга не меняется.
            $result = $this->runCheckForDomain($domain, DomainSslStatusRepository::SOURCE_MANUAL_CHECK);
        } finally {
            $this->releaseLock($lock);
        }

        if ($isAjax) {
            $repo = new DomainSslStatusRepository();
            $this->jsonOk(['status' => $repo->getByDomain($domain)]);
        }
        $this->flash('success', 'Проверка выполнена: ' . $domain);
        $this->redirect('/ssl/show?domain=' . urlencode($domain));
    }

    /** «Проверить все» — batch через cron (§5.1). Не запускает долгих запросов. */
    public function checkAll(): void
    {
        $this->requireAuth();
        $repo = new DomainSslStatusRepository();
        try {
            $batchId = $repo->startBatch($this->currentUserLabel());
        } catch (\Throwable $e) {
            // b1.1.1: не удалось получить lock запуска — просим повторить, batch не создаём.
            if (!empty($_POST['ajax'])) $this->jsonErr('Запуск занят, повторите попытку', 409);
            $this->flash('error', 'Запуск массовой проверки занят другим процессом. Повторите попытку.');
            $this->redirect('/ssl');
            return;
        }
        if (!empty($_POST['ajax'])) {
            $this->jsonOk(['batch' => $repo->batchProgress($batchId)]);
        }
        $this->flash('success', 'Массовая проверка поставлена в очередь');
        $this->redirect('/ssl');
    }

    /** AJAX-прогресс batch (§5.1). */
    public function batchProgress(): void
    {
        $this->requireAuth();
        $repo = new DomainSslStatusRepository();
        $batchId = (int)($_POST['batch_id'] ?? 0);
        if ($batchId <= 0) { $batchId = (int)($repo->currentRunningBatchId() ?? 0); }
        if ($batchId <= 0) { $this->jsonOk(['batch' => null]); }
        $this->jsonOk(['batch' => $repo->batchProgress($batchId)]);
    }

    /** Остановить batch — отменить только ещё не начатые (§5.1). */
    public function batchStop(): void
    {
        $this->requireAuth();
        $repo = new DomainSslStatusRepository();
        $batchId = (int)($_POST['batch_id'] ?? 0);
        if ($batchId <= 0) { $batchId = (int)($repo->currentRunningBatchId() ?? 0); }
        if ($batchId > 0) $repo->stopBatch($batchId);
        if (!empty($_POST['ajax'])) $this->jsonOk(['stopped' => $batchId]);
        $this->flash('success', 'Массовая проверка остановлена');
        $this->redirect('/ssl');
    }

    /** v25.1-b1: добавить домен в мониторинг вручную. */
    public function addDomain(): void
    {
        $this->requireAuth();
        $domain = strtolower(trim((string)($_POST['domain'] ?? '')));
        // простая валидация доменного имени
        if ($domain === '' || !preg_match('~^(?=.{1,253}$)([a-z0-9](-?[a-z0-9])*\.)+[a-z]{2,}$~', $domain)) {
            $this->flash('error', 'Некорректный домен'); $this->redirect('/ssl'); return;
        }
        $repo = new DomainSslStatusRepository();
        [$siteId, $jobId] = array_slice($this->resolveDomainContext($domain), 0, 2);

        // §2.2/§3.1: идемпотентный upsert, привязка site_id/job_id, next_check_at=NOW.
        $repo->enrollDomain($domain, $siteId, $jobId, 'manual', true);

        // §3.3: попытаться проверить сразу под domain-lock БЕЗ ожидания. Глобальный
        // batch НЕ создаём. При занятом локе / временной ошибке — остаётся
        // not_checked + next_check_at=NOW(), заберёт ближайший /cron/ssl.
        $checkedNow = false;
        $lock = self::lockName($domain);
        if ($this->acquireLock($lock)) {
            try {
                // §5.4: явное закрепление уже сделано enrollDomain выше; проверка —
                // разовая (manual_check), она не меняет тип мониторинга.
                $this->runCheckForDomain($domain, DomainSslStatusRepository::SOURCE_MANUAL_CHECK);
                $checkedNow = true;
            } catch (\Throwable $e) {
                // transient — оставляем в очереди cron
            } finally {
                $this->releaseLock($lock);
            }
        }

        // §3.4: redirect на /ssl (не на /ssl/show), понятное сообщение.
        if ($checkedNow) {
            $this->flash('success', 'Домен добавлен в мониторинг. Проверка выполнена: ' . $domain);
        } else {
            $this->flash('success', 'Домен добавлен в мониторинг. Проверка поставлена в очередь: ' . $domain);
        }
        $this->redirect('/ssl');
    }

    /** v25.1-b1: отключить мониторинг (в архив). */
    public function archive(): void
    {
        $this->requireAuth();
        $domain = strtolower(trim((string)($_POST['domain'] ?? '')));
        if ($domain !== '') (new DomainSslStatusRepository())->archiveDomain($domain);
        if (!empty($_POST['ajax'])) $this->jsonOk([]);
        $this->flash('success', 'Домен отключён от мониторинга');
        $this->redirect('/ssl');
    }

    /** v25.1-b1: вернуть домен в мониторинг. */
    public function unarchive(): void
    {
        $this->requireAuth();
        $domain = strtolower(trim((string)($_POST['domain'] ?? '')));
        if ($domain !== '') (new DomainSslStatusRepository())->unarchiveDomain($domain);
        if (!empty($_POST['ajax'])) $this->jsonOk([]);
        $this->flash('success', 'Домен возвращён в мониторинг');
        $this->redirect('/ssl');
    }

    /** v25.1-b1: удалить домен из списка (история сохраняется без подтверждения). */
    public function remove(): void
    {
        $this->requireAuth();
        $domain = strtolower(trim((string)($_POST['domain'] ?? '')));
        $withHistory = !empty($_POST['with_history']);
        if ($domain !== '') (new DomainSslStatusRepository())->removeDomain($domain, $withHistory);
        if (!empty($_POST['ajax'])) $this->jsonOk([]);
        $this->flash('success', 'Домен удалён из списка' . ($withHistory ? ' вместе с историей' : ''));
        $this->redirect('/ssl');
    }

    /**
     * Выполнить проверку домена, сохранить результат и (§5) при технической
     * готовности активной джобы — толкнуть pipeline под job-lock.
     * Публичный метод: используется и cron'ом.
     */
    public function runCheckForDomain(string $domain, string $source): array
    {
        $domain = strtolower(trim($domain));
        $repo = new DomainSslStatusRepository();
        [$siteId, $jobId, $probeToken] = $this->resolveDomainContext($domain);

        // ТЗ 041 §5.3: разовая проверка НЕ подключает домен и не меняет
        // manual_added/monitoring_enabled/monitoring_suppressed/enrolled_source.
        // Явное подключение выполняют только addDomain()/unarchive().

        $svc = new DomainSslCheckService();
        $result = $svc->check($domain, $siteId, $jobId, $probeToken, $source);
        $repo->saveResult($result);

        // §5: если активная джоба уже удовлетворяет technical_ready — толкнуть pipeline.
        if ($jobId !== null && (int)($result['technical_ready'] ?? 0) === 1) {
            $this->nudgePipelineIfTechnicalReady($jobId);
        }
        return $result;
    }

    /** Достаём site_id/job_id/probe_token для домена (активная джоба в приоритете). */
    private function resolveDomainContext(string $domain): array
    {
        $siteId = null; $jobId = null; $probeToken = null;
        $inTerminal = "'" . implode("','", DomainSslStatusRepository::TERMINAL_STAGES) . "'";
        $st = DB::pdo()->prepare(
            "SELECT id, site_id, artifacts_json FROM refresh_jobs
              WHERE new_domain=? AND stage NOT IN ($inTerminal)
              ORDER BY id DESC LIMIT 1"
        );
        $st->execute([$domain]);
        $job = $st->fetch(PDO::FETCH_ASSOC);
        if ($job) {
            $jobId = (int)$job['id'];
            $siteId = $job['site_id'] !== null ? (int)$job['site_id'] : null;
            $arts = json_decode((string)($job['artifacts_json'] ?? ''), true) ?: [];
            $probeToken = (string)($arts['domain_readiness_stage']['probe_token'] ?? '') ?: null;
        }
        if ($siteId === null) {
            $s = DB::pdo()->prepare("SELECT id FROM sites_managed WHERE current_domain=? LIMIT 1");
            $s->execute([$domain]);
            $sid = $s->fetchColumn();
            if ($sid !== false) $siteId = (int)$sid;
        }
        return [$siteId, $jobId, $probeToken];
    }

    /** §5: под job-lock перечитать джобу, выставить готовность, next_run_at=NOW(). */
    private function nudgePipelineIfTechnicalReady(int $jobId): void
    {
        $lock = 'rfp_job_' . $jobId;
        if (!$this->acquireLock($lock)) return; // джоба сейчас обрабатывается — не мешаем
        try {
            $st = DB::pdo()->prepare("SELECT stage, domain_technical_ready_at FROM refresh_jobs WHERE id=?");
            $st->execute([$jobId]);
            $job = $st->fetch(PDO::FETCH_ASSOC);
            if (!$job) return;
            if (in_array((string)$job['stage'], DomainSslStatusRepository::TERMINAL_STAGES, true)) return;

            // Выставим techical_ready и разбудим стадию, если ещё не стоит.
            DB::pdo()->prepare(
                "UPDATE refresh_jobs
                    SET domain_technical_ready_at = COALESCE(domain_technical_ready_at, NOW()),
                        domain_readiness_state = COALESCE(domain_readiness_state, 'technical_ready'),
                        next_run_at = NOW()
                  WHERE id = ? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
        } finally {
            $this->releaseLock($lock);
        }
    }

    /* ==================== helpers ==================== */

    private function acquireLock(string $name): bool
    {
        try {
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, ?)");
            $st->execute([substr($name, 0, 64), 0]);
            return ((int)$st->fetchColumn() === 1);
        } catch (\Throwable $e) { return false; }
    }

    private function releaseLock(string $name): void
    {
        try {
            DB::pdo()->prepare("SELECT RELEASE_LOCK(?)")->execute([substr($name, 0, 64)]);
        } catch (\Throwable $e) {}
    }

    private function currentUserLabel(): ?string
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        return isset($_SESSION['user']) ? (string)$_SESSION['user'] : 'operator';
    }
}
