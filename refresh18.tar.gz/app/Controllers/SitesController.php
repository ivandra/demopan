<?php

class SitesController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();

        $q = trim((string)($_GET['q'] ?? ''));
        $serverFilter = (int)($_GET['server_id'] ?? 0);
        $sql = "SELECT s.*, fps.title AS server_title, fps.host AS server_host,
                       fps.id AS server_id, fps.ui_badge_code, fps.ui_badge_label, fps.ui_badge_color
                FROM sites_managed s
                LEFT JOIN fastpanel_servers fps ON fps.id = s.fastpanel_server_id";
        $params = [];
        $conds = [];
        if ($q !== '') {
            $conds[] = "(s.current_domain LIKE ? OR s.note LIKE ?)";
            $params[] = '%' . $q . '%'; $params[] = '%' . $q . '%';
        }
        if ($serverFilter > 0) {                       // §8.4: фильтр по server_id
            $conds[] = "s.fastpanel_server_id = ?";
            $params[] = $serverFilter;
        }
        if ($conds) $sql .= " WHERE " . implode(' AND ', $conds);
        $sql .= " ORDER BY s.id DESC";

        $st = DB::pdo()->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll();

        $this->view('sites/index', [
            'rows' => $rows, 'q' => $q,
            'servers' => ServerBadgePresenter::serversForFilter(),
            'serverFilter' => $serverFilter,
        ]);
    }

    public function importForm(): void
    {
        $this->requireAuth();
        $servers = DB::pdo()->query("SELECT * FROM fastpanel_servers ORDER BY title")->fetchAll();

        $serverId = (int)($_GET['server_id'] ?? 0);
        if ($serverId === 0 && !empty($servers)) {
            $serverId = (int)$servers[0]['id'];
        }

        $q = trim((string)($_GET['q'] ?? ''));
        $results = [];
        $cacheInfo = null;
        $error = null;

        if ($serverId > 0) {
            try {
                $svc = new FastpanelSearchService($serverId);
                $cacheInfo = $svc->cacheInfo();
                $results = $svc->search($q, 30);
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
        }

        $this->view('sites/import', [
            'servers' => $servers,
            'serverId' => $serverId,
            'q' => $q,
            'results' => $results,
            'cacheInfo' => $cacheInfo,
            'error' => $error,
        ]);
    }

    public function importRefreshCache(): void
    {
        $this->requireAuth();
        $serverId = (int)($_POST['server_id'] ?? 0);
        if ($serverId <= 0) {
            $this->flash('error', 'Не указан сервер');
            $this->redirect('/sites/import');
        }
        try {
            $svc = new FastpanelSearchService($serverId);
            $cnt = $svc->refreshCache();
            $this->flash('success', "Список сайтов обновлён: {$cnt} шт.");
        } catch (Throwable $e) {
            $this->flash('error', 'Не удалось обновить список: ' . $e->getMessage());
        }
        $this->redirect('/sites/import?server_id=' . $serverId);
    }

    public function importPreview(): void
    {
        $this->requireAuth();
        $serverId = (int)($_GET['server_id'] ?? 0);
        $fpSiteId = (int)($_GET['fp_site_id'] ?? 0);
        if ($serverId <= 0 || $fpSiteId <= 0) {
            $this->jsonErr('bad params');
        }
        try {
            $svc = new FastpanelSearchService($serverId);
            $detail = $svc->getSiteDetail($fpSiteId);
            // ТЗ «Единый безопасный выбор IP» §8.2: preview показывает ИМЕННО тот IP,
            // который сохранит импорт — единый метод, не $detail['vps_ip'] напрямую.
            // Ошибка выбора IP не должна ломать превью алиасов/владельца — показываем её в поле.
            $previewIp = ''; $ipError = null;
            try { $previewIp = $svc->selectAllowedVpsIp($detail); }
            catch (\RuntimeException $e) { $ipError = $e->getMessage(); }
            $this->jsonOk(['site' => [
                'fp_site_id'  => $detail['fp_site_id'],
                'server_name' => $detail['server_name'],
                'last_alias'  => $detail['last_alias'],
                'aliases'     => $detail['aliases'],
                'owner'       => $detail['owner'],
                'vps_ip'      => $previewIp,
                'ip_error'    => $ipError,
                'index_dir'   => $detail['index_dir'],
            ]]);
        } catch (Throwable $e) {
            $this->jsonErr($e->getMessage());
        }
    }

    public function importDo(): void
    {
        $this->requireAuth();
        $serverId = (int)($_POST['server_id'] ?? 0);
        $fpSiteId = (int)($_POST['fp_site_id'] ?? 0);
        if ($serverId <= 0 || $fpSiteId <= 0) {
            $this->flash('error', 'Не указан сайт');
            $this->redirect('/sites/import');
        }

        try {
            $svc = new FastpanelSearchService($serverId);
            $res = $svc->importOne($fpSiteId);

            if (empty($res['ok'])) {
                $this->flash('error', 'Не удалось добавить: ' . ($res['error'] ?? '?'));
                $this->redirect('/sites/import?server_id=' . $serverId);
            }

            $msg = $res['is_new'] ? 'Сайт добавлен.' : 'Сайт обновлён.';
            if (!empty($res['ftp_created'])) {
                $msg .= ' FTP-аккаунт создан.';
            } else {
                $msg .= ' FTP создать не удалось — заполните вручную в карточке.';
            }
            if (!empty($res['config_synced'])) {
                $msg .= ' config.php прочитан.';
            } elseif (!empty($res['ftp_created'])) {
                $msg .= ' config.php прочитать не удалось — попробуйте кнопку "Синхронизировать" в карточке.';
            }
            if (!empty($res['errors'])) {
                $msg .= ' Замечания: ' . implode('; ', array_slice($res['errors'], 0, 3));
            }

            $this->flash('success', $msg);
            $this->redirect('/sites/show?id=' . (int)$res['site_id']);
        } catch (Throwable $e) {
            $this->flash('error', 'Исключение: ' . $e->getMessage());
            $this->redirect('/sites/import?server_id=' . $serverId);
        }
    }

    /**
     * v21: сохранение ПЕРСОНАЛЬНЫХ параметров маски для сайта.
     * Пишется в sites_managed.mask_settings_json. use_global=1 → работают глобальные.
     */
    public function saveMask(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        if ($id < 1) { $this->flash('error', 'Не указан сайт'); $this->redirect('/sites'); }

        if (!empty($_POST['use_global'])) {
            // Вернуть сайт на общие настройки
            try {
                $st = DB::pdo()->prepare("UPDATE sites_managed SET mask_settings_json = NULL WHERE id = ?");
                $st->execute([$id]);
                $this->flash('success', 'Сайт переведён на общие настройки маски.');
            } catch (\Throwable $e) {
                $this->flash('error', 'Ошибка: ' . $e->getMessage() . ' (применена ли миграция 022?)');
            }
            $this->redirect('/sites/show?id=' . $id);
        }

        $strategy = (string)($_POST['mask_strategy'] ?? 'number');
        if (!in_array($strategy, ['number', 'letter'], true)) $strategy = 'number';

        $step = max(1, min(1000, (int)($_POST['mask_step'] ?? 1)));
        $noDigit = max(0, min(999999, (int)($_POST['mask_no_digit_start'] ?? 2)));

        $abc = strtolower(preg_replace('~[^A-Za-z]~', '', (string)($_POST['mask_letter_alphabet'] ?? '')));
        if ($abc === '') $abc = 'abcdefghijklmnopqrstuvwxyz';

        $prefix = preg_replace('~[^A-Za-z0-9_\-]~', '', (string)($_POST['mask_prefix'] ?? ''));
        $prefix = substr((string)$prefix, 0, 16);

        $cfg = [
            'use_global'       => 0,
            'strategy'         => $strategy,
            'step'             => $step,
            'pad_zeros'        => !empty($_POST['mask_pad_zeros']) ? 1 : 0,
            'no_digit_start'   => $noDigit,
            'letter_alphabet'  => $abc,
            'letter_wrap'      => !empty($_POST['mask_letter_wrap']) ? 1 : 0,
            'sync_with_domain' => !empty($_POST['mask_sync_with_domain']) ? 1 : 0,
            'prefix_enabled'   => !empty($_POST['mask_prefix_enabled']) ? 1 : 0,
            'prefix'           => $prefix,
        ];

        try {
            $st = DB::pdo()->prepare("UPDATE sites_managed SET mask_settings_json = ? WHERE id = ?");
            $st->execute([json_encode($cfg, JSON_UNESCAPED_UNICODE), $id]);
            $this->flash('success', 'Персональные настройки маски сохранены (стратегия: ' . $strategy . ').');
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка сохранения: ' . $e->getMessage() . ' (применена ли миграция 022?)');
        }
        $this->redirect('/sites/show?id=' . $id);
    }

    public function show(): void
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        $site = $this->loadSite($id);

        // ТЗ 040 §9.4/§9.6: бейдж сервера готовит контроллер (не View).
        $serverBadge = null;
        if (!empty($site['fastpanel_server_id'])) {
            $sbSt = DB::pdo()->prepare("SELECT ui_badge_code, ui_badge_label, ui_badge_color, title AS server_title FROM fastpanel_servers WHERE id=?");
            $sbSt->execute([(int)$site['fastpanel_server_id']]);
            if ($sbRow = $sbSt->fetch()) $serverBadge = (new ServerBadgePresenter())->fromRow($sbRow);
        }

        $config = [];
        if (!empty($site['config_parsed_json'])) {
            $config = json_decode((string)$site['config_parsed_json'], true) ?: [];
        }

        $aliases = [];
        if (!empty($site['aliases'])) {
            $aliases = json_decode((string)$site['aliases'], true) ?: [];
        }

        $domainHistory = [];
        if (!empty($site['domain_history'])) {
            $domainHistory = json_decode((string)$site['domain_history'], true) ?: [];
        }

        // Превью маски (v21: персональные настройки сайта + sub_id от нового домена)
        $mask = DomainMaskService::forSite($site);
        $nextDomain = $mask->nextDomain($site['current_domain']);

        // v21: sub_id ищем во ВСЕХ полях конфига (не только internal_reg_url —
        // у части сайтов он пустой, а sub_id лежит в base_new_url/base_second_url)
        $subInfo   = $mask->extractSubIdFromConfig(is_array($config) ? $config : []);
        $oldSubId  = (string)$subInfo['sub_id'];
        $subIdField = (string)$subInfo['field'];
        // v4 (H6): если в разных полях конфига разные sub_id — показываем оператору.
        $subIdConflict = is_array($subInfo['conflict'] ?? null) ? $subInfo['conflict'] : [];
        $nextSubId = $oldSubId !== '' ? $mask->subIdForDomain($oldSubId, $nextDomain) : '';
        $maskOpts = $mask->options();

        // v4 (H10): «персональные» — только если JSON валиден И use_global не выставлен.
        // Раньше признак считался по факту непустой строки: при битом JSON или
        // {"use_global":1} сервис работал на глобальных, а UI показывал «персональные».
        $maskIsPerSite = false;
        $maskJsonRaw = trim((string)($site['mask_settings_json'] ?? ''));
        if ($maskJsonRaw !== '') {
            $decoded = json_decode($maskJsonRaw, true);
            $maskIsPerSite = (is_array($decoded) && empty($decoded['use_global']));
        }

        // Активная джоба
        $st = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE site_id=? AND stage NOT IN ('done','failed','cancelled','superseded') ORDER BY id DESC LIMIT 1");
        $st->execute([$id]);
        $activeJob = $st->fetch();

        // История джоб
        $st = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE site_id=? ORDER BY id DESC LIMIT 20");
        $st->execute([$id]);
        $jobs = $st->fetchAll();

        $this->view('sites/show', [
            'site' => $site,
            'serverBadge' => $serverBadge,
            'csrfToken' => $this->csrfToken(),
            'config' => $config,
            'aliases' => $aliases,
            'domainHistory' => $domainHistory,
            'nextDomain' => $nextDomain,
            'nextSubId' => $nextSubId,
            'oldSubId' => $oldSubId,
            'maskOpts' => $maskOpts,
            'subIdField' => $subIdField,
            'subIdConflict' => $subIdConflict,
            'maskIsPerSite' => $maskIsPerSite,
            'activeJob' => $activeJob,
            'jobs' => $jobs,
        ]);
    }

    public function syncConfig(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $site = $this->loadSite($id);

        try {
            $svc = new SiteConfigSyncService();
            $res = $svc->syncFromVps($id);
            if (empty($res['ok'])) {
                $this->flash('error', 'Не удалось прочитать config.php: ' . ($res['error'] ?? '?'));
            } else {
                $cnt = is_array($res['data']) ? count($res['data']) : 0;
                $this->flash('success', "config.php синхронизирован. Полей распознано: {$cnt}. Шаблон: " . ($res['kind'] ?? '?'));
            }
        } catch (ParseError $e) {
            // Один из PHP-файлов панели содержит синтаксическую ошибку.
            $this->flash('error',
                'PHP ParseError: ' . $e->getMessage() . ' в ' . $e->getFile() . ':' . $e->getLine() .
                ' — откройте /system/diagnose чтобы увидеть какой файл повреждён');
        } catch (Throwable $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/sites/show?id=' . $id);
    }

    /**
     * Повторная попытка создать FTP-аккаунт через FastPanel API.
     * Если упало — заворачиваем пользователя на /diagnose, где видны причины.
     */
    public function createFtp(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);

        $serverId = (int)($site['fastpanel_server_id'] ?? 0);
        $fpSiteId = (int)($site['fp_site_id'] ?? 0);
        if ($serverId <= 0 || $fpSiteId <= 0) {
            $this->flash('error', 'Сайт без привязки к FastPanel');
            $this->redirect('/sites/show?id=' . $id);
        }

        try {
            $svc = new FastpanelSearchService($serverId);
            $res = $svc->createFtpForExistingSite($id);
            if (!empty($res['ok'])) {
                $this->flash('success', 'FTP-аккаунт создан: ' . $res['user'] . '. Сейчас попробую прочитать config.php.');
                // Сразу пробуем sync
                try {
                    $sync = new SiteConfigSyncService();
                    $r = $sync->syncFromVps($id);
                    if (!empty($r['ok'])) {
                        $cnt = is_array($r['data']) ? count($r['data']) : 0;
                        $this->flash('success', "config.php прочитан. Полей распознано: {$cnt}.");
                    } else {
                        $this->flash('warning', 'FTP создан, но config.php не прочитан: ' . ($r['error'] ?? '?'));
                    }
                } catch (Throwable $e) {
                    $this->flash('warning', 'FTP создан, но config.php не прочитан: ' . $e->getMessage());
                }
            } else {
                // Сохранили лог, отправляем на диагностику
                $err = $res['error'] ?? '?';
                $this->flash('error',
                    'Не удалось создать FTP. Полный ответ FastPanel сохранён в лог импорта. ' .
                    'Откройте "Диагностика" чтобы увидеть детали. Кратко: ' . mb_substr($err, 0, 200));
            }
        } catch (Throwable $e) {
            $this->flash('error', 'Исключение: ' . $e->getMessage());
        }
        $this->redirect('/sites/diagnose?id=' . $id);
    }

    /**
     * Диагностическая страница: показывает сырой JSON от FP API и лог импорта.
     */
    public function diagnose(): void
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        $site = $this->loadSite($id);

        $rawJson = null;
        if (!empty($site['fp_raw_json'])) {
            $rawJson = json_decode((string)$site['fp_raw_json'], true);
        }

        $importLog = null;
        if (!empty($site['import_log'])) {
            $importLog = json_decode((string)$site['import_log'], true);
        }

        $this->view('sites/diagnose', [
            'site' => $site,
            'rawJson' => $rawJson,
            'importLog' => $importLog,
        ]);
    }

    public function editForm(): void
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        $site = $this->loadSite($id);
        $servers = DB::pdo()->query("SELECT id, title, host FROM fastpanel_servers ORDER BY title")->fetchAll();
        $regs = DB::pdo()->query("SELECT id, provider, username FROM registrar_accounts ORDER BY id DESC")->fetchAll();
        $contacts = DB::pdo()->query("SELECT id, label, first_name, last_name FROM registrar_contacts ORDER BY id DESC")->fetchAll();
        $this->view('sites/edit', [
            'site' => $site,
            'servers' => $servers,
            'regs' => $regs,
            'contacts' => $contacts,
        ]);
    }

    public function update(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);

        $domain = trim((string)($_POST['current_domain'] ?? $site['current_domain']));
        $vpsIp = trim((string)($_POST['vps_ip'] ?? ''));
        $note = (string)($_POST['note'] ?? '');
        $configPath = trim((string)($_POST['config_remote_path'] ?? ''));
        // v17.10: update_url больше не в форме edit (переехал на /sites/show в отдельный блок)
        $regAcc = (int)($_POST['registrar_account_id'] ?? 0) ?: null;
        $regCtc = (int)($_POST['registrar_contact_id'] ?? 0) ?: null;

        $ftpHost = trim((string)($_POST['ftp_host'] ?? ''));
        $ftpUser = trim((string)($_POST['ftp_user'] ?? ''));
        $ftpPass = (string)($_POST['ftp_pass'] ?? '');

        $sql = "UPDATE sites_managed SET
            current_domain=?, vps_ip=?, note=?, config_remote_path=?,
            registrar_account_id=?, registrar_contact_id=?,
            ftp_host=?, ftp_user=?";
        $params = [$domain, $vpsIp, $note, $configPath,
                   $regAcc, $regCtc, $ftpHost, $ftpUser];
        if ($ftpPass !== '') {
            $sql .= ", ftp_pass_enc=?";
            $params[] = Crypto::encrypt($ftpPass);
        }
        $sql .= " WHERE id=?";
        $params[] = $id;

        DB::pdo()->prepare($sql)->execute($params);

        $this->flash('success', 'Сохранено');
        $this->redirect('/sites/show?id=' . $id);
    }

    /**
     * v17.2: Toggle redirect_enabled — дёргает FTP И ставит флаг.
     *
     * При ВЫКЛЮЧЕНИИ:
     *   1. Запускает RedirectToggler::disable() — выключает редирект на сайте
     *      (правит .htaccess / config.php через FTP, делает snapshots)
     *   2. Сохраняет state в sites_managed.redirect_toggle_state_json
     *   3. Ставит redirect_enabled = 0
     *
     * При ВКЛЮЧЕНИИ:
     *   1. Берёт сохранённый state из redirect_toggle_state_json
     *   2. Запускает RedirectToggler::enable($state) — восстанавливает редирект
     *   3. Очищает state, ставит redirect_enabled = 1
     *
     * Важно:
     *   - Также влияет на стадию redirect_enable в будущих джобах
     *     (если 0 — стадия пропускается)
     *   - Если включение упало (FTP/код сбойный) — оставляем state, чтобы
     *     можно было нажать «Включить» ещё раз
     */
    public function toggleRedirectEnabled(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);

        $current = (int)($site['redirect_enabled'] ?? 1);
        $new = $current === 1 ? 0 : 1;

        // === Создаём виртуальную "джобу" для логгирования ===
        // RedirectToggler требует jobId и JobEventLogger. Создаём
        // системную "manual_toggle" pseudo-job — пишет в site_events_log сайта.
        $pseudoJobId = 0;  // 0 = manual operation, без реальной джобы
        $log = new JobEventLogger($pseudoJobId);  // если jobId=0, лог пойдёт в error_log

        $toggler = new RedirectToggler();
        $error = null;

        try {
            if ($new === 0) {
                // === ВЫКЛЮЧАЕМ ===
                $log->info('manual_toggle',
                    "Пользователь нажал «Выключить редирект» на сайте #{$id}. Дёргаю FTP...");

                $disableResult = $toggler->disable($id, $pseudoJobId, $log);

                if (empty($disableResult['ok'])) {
                    $errs = $disableResult['errors'] ?? [];
                    throw new \RuntimeException(
                        'RedirectToggler::disable вернул ok=false. Ошибки: ' .
                        json_encode($errs, JSON_UNESCAPED_UNICODE)
                    );
                }

                // Сохраняем state в БД для последующего enable()
                $stateData = [
                    'disabled_at' => date('Y-m-d H:i:s'),
                    'disabled_by_user' => true,
                    'disabled_state' => $disableResult,
                ];

                DB::pdo()->prepare(
                    "UPDATE sites_managed SET
                        redirect_enabled = 0,
                        redirect_toggle_state_json = ?
                     WHERE id = ?"
                )->execute([
                    json_encode($stateData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $id,
                ]);

                $appliedCount = count($disableResult['applied_rules'] ?? []);
                $msg = "🔴 Редирект ВЫКЛЮЧЕН на сайте (применено {$appliedCount} правил). " .
                       "Также не будет включаться в будущих джобах.";
                $this->flash('success', $msg);
            } else {
                // === ВКЛЮЧАЕМ ===
                $log->info('manual_toggle',
                    "Пользователь нажал «Включить редирект» на сайте #{$id}. Восстанавливаю...");

                // Достаём saved state
                $stateJson = (string)($site['redirect_toggle_state_json'] ?? '');
                if ($stateJson === '') {
                    // Нет state — значит редирект был выключен НЕ через эту кнопку
                    // (возможно через джобу или ручное вмешательство). Просто ставим флаг,
                    // не дёргаем FTP — мы не знаем что и как включать.
                    DB::pdo()->prepare(
                        "UPDATE sites_managed SET redirect_enabled = 1 WHERE id = ?"
                    )->execute([$id]);
                    $this->flash('warning',
                        '⚠ Флаг redirect_enabled установлен в 1, но FTP не дёргался — ' .
                        'нет сохранённого state предыдущего выключения. ' .
                        'Если редирект на сайте сейчас выключен — поправь руками или запусти джобу.');
                    $this->redirect('/sites/show?id=' . $id);
                    return;
                }

                $stateData = json_decode($stateJson, true) ?: [];
                $disabledState = $stateData['disabled_state'] ?? null;

                if (!$disabledState) {
                    throw new \RuntimeException(
                        'redirect_toggle_state_json пуст или некорректен (нет disabled_state)'
                    );
                }

                $enableResult = $toggler->enable($id, $pseudoJobId, $disabledState, $log);

                if (empty($enableResult['ok'])) {
                    $errs = $enableResult['errors'] ?? [];
                    throw new \RuntimeException(
                        'RedirectToggler::enable вернул ok=false. Ошибки: ' .
                        json_encode($errs, JSON_UNESCAPED_UNICODE)
                    );
                }

                // Очищаем state и ставим флаг
                DB::pdo()->prepare(
                    "UPDATE sites_managed SET
                        redirect_enabled = 1,
                        redirect_toggle_state_json = NULL
                     WHERE id = ?"
                )->execute([$id]);

                $restoredCount = count($enableResult['restored_rules'] ?? []);
                $msg = "✅ Редирект ВКЛЮЧЁН на сайте (восстановлено {$restoredCount} правил)";
                $this->flash('success', $msg);
            }
        } catch (\Throwable $e) {
            $log->error('manual_toggle', 'Toggle упал: ' . $e->getMessage());
            $this->flash('error',
                'Не удалось переключить редирект через FTP: ' . $e->getMessage() .
                '. Флаг в БД НЕ изменён (можно попробовать снова или поправить руками).');
        }

        $this->redirect('/sites/show?id=' . $id);
    }

    /**
     * v17.10: сохранение update_classes_url для сайта.
     *
     * Принимает path вида "/update_classes.php?token=secret".
     * Если введён полный URL (https://...) — автоматически обрезает схему+хост,
     * остаётся только path+query.
     *
     * Сохраняется в sites_managed.update_classes_url. Используется в стадии
     * update_classes_call: при выполнении подставляется домен текущего нового домена.
     *
     * Если поле пустое — стадия попробует /update_classes.php через FTP в корне
     * сайта; если и там нет — пропустит.
     */
    public function saveUpdateClassesUrl(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);

        $rawInput = trim((string)($_POST['update_classes_url'] ?? ''));
        // §8.1 (v3): способ подтверждения ОБЯЗАТЕЛЕН и НЕ имеет fallback.
        // Пустой/неизвестный контракт → ошибка, БД не меняется. Backend НЕ
        // подменяет выбор оператора скрытым json_ok_true.
        $contract = trim((string)($_POST['uc_verification_contract'] ?? ''));
        $allowedContracts = ['json_ok_true', 'exact_marker', 'ftp_profile'];
        // Валидация контракта нужна только когда задаётся непустой URL (custom).
        if ($rawInput !== '' && !in_array($contract, $allowedContracts, true)) {
            $this->flash('error', 'Выберите способ подтверждения результата.');
            $this->redirect('/sites/show?id=' . $id . '#uc-randomization');
            return;
        }
        // §8.2: exact_marker требует непустую строку.
        if ($rawInput !== '' && $contract === 'exact_marker') {
            $mk = trim((string)($_POST['uc_verification_marker'] ?? ''));
            if ($mk === '') {
                $this->flash('error', 'Укажите контрольную строку.');
                $this->redirect('/sites/show?id=' . $id . '#uc-randomization');
                return;
            }
            if (mb_strlen($mk) > 255) {
                $this->flash('error', 'Контрольная строка слишком длинная (максимум 255 символов).');
                $this->redirect('/sites/show?id=' . $id . '#uc-randomization');
                return;
            }
        }
        // §8.2: marker хранится ТОЛЬКО для exact_marker, иначе NULL.
        $contractMarker = ($contract === 'exact_marker')
            ? trim((string)($_POST['uc_verification_marker'] ?? '')) : '';

        // Нормализуем: если ввели полный URL — отрезаем схему+хост.
        // ТЗ 039 §8.1: относительный path всегда собирается только с НОВЫМ доменом
        // джобы; полный чужой host вызов не переживёт (host-guard в executor).
        $normalized = $this->normalizeUpdateClassesPath($rawInput);

        // §10.4: валидация до сохранения. Небезопасный path не сохраняем.
        if ($normalized !== '' && (
            strpos($normalized, '..') !== false
            || strpos($normalized, "\0") !== false
            || preg_match('~\s~', $normalized)
            || !preg_match('~^/[\x21-\x7e]+$~', $normalized))) {
            $this->flash('error',
                'Path не сохранён: недопустимые символы. Разрешён обычный путь вида /variant-refresh.php?k=SECRET.');
            $this->redirect('/sites/show?id=' . $id);
        }

        try {
            if ($normalized === '') {
                // Очистка = возврат к автоопределению (live-инспекция при следующей джобе).
                DB::pdo()->prepare(
                    "UPDATE sites_managed SET update_classes_url = '', uc_mode = 'auto',
                        uc_capability = 'unknown', uc_detection_json = NULL, uc_detected_at = NULL,
                        uc_verification_contract = NULL, uc_verification_marker = NULL
                      WHERE id = ?"
                )->execute([$id]);
                $this->flash('success',
                    '🎲 Кастомный путь очищен. Режим — автоматический: применимость будет проверена по FTP при следующей джобе или по кнопке «Проверить рандомизацию».');
            } else {
                // ТЗ 039 §6/§10.4: непустой проверенный path = режим custom.
                $det = json_encode([
                    'checked_at' => date('Y-m-d H:i:s'),
                    'source' => 'operator_custom_path',
                    'custom_path' => $normalized,
                    'reason' => 'operator_saved_custom_path',
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                DB::pdo()->prepare(
                    "UPDATE sites_managed SET update_classes_url = ?, uc_mode = 'custom',
                        uc_capability = 'custom', uc_detection_json = ?, uc_detected_at = NOW(),
                        uc_verification_contract = ?, uc_verification_marker = ?
                      WHERE id = ?"
                )->execute([$normalized, $det, $contract, ($contractMarker !== '' ? $contractMarker : null), $id]);
                // §8.4: audit изменения custom-настроек. Секрет URL и полный marker
                // НЕ пишем — только факт наличия и маскированный путь.
                $maskedPath = preg_replace('~([?&](?:k|token|secret|key)=)[^&]+~i', '$1***', $normalized);
                @error_log('[audit] ' . json_encode([
                    'event'          => 'uc_custom_settings_changed',
                    'site_id'        => $id,
                    'path'           => $maskedPath,
                    'contract'       => $contract,
                    'marker_present' => ($contractMarker !== ''),
                    'changed_by'     => (int)($_SESSION['user']['id'] ?? 0),
                    'changed_at'     => date('Y-m-d H:i:s'),
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                if ($normalized !== $rawInput) {
                    $this->flash('success',
                        "🎲 Сохранено как '{$normalized}' (режим: кастомный адрес). Полный URL обрезан до path — домен подставляется из new_domain джобы. Перед вызовом выполняется pre-flight правильного vhost.");
                } else {
                    $this->flash('success', "🎲 Сохранено: {$normalized} (режим: кастомный адрес). Перед вызовом выполняется pre-flight правильного vhost.");
                }
            }
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось сохранить: ' . $e->getMessage());
        }

        $this->redirect('/sites/show?id=' . $id);
    }

    /**
     * ТЗ 039 §7.2: кнопка «Проверить рандомизацию» на карточке сайта.
     * Read-only FTP-инспекция + запись uc_capability/uc_detection_json.
     */
    public function checkRandomization(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);
        try {
            $res = $this->makeRandomizationInspector()->inspectAndPersist($id);
            $cap = (string)($res['capability'] ?? 'ftp_error');
            $reason = (string)($res['detection']['reason'] ?? '');
            switch ($cap) {
                case SiteRandomizationInspector::CAP_VARIANT_REFRESH:
                case SiteRandomizationInspector::CAP_UPDATE_CLASSES:
                    $this->flash('success', '🎲 Рандомизация используется. Найденный механизм: '
                        . SiteRandomizationInspector::mechanismLabel($cap) . '.');
                    break;
                case SiteRandomizationInspector::CAP_CONFIRMED_ABSENT:
                    $this->flash('success', '🎲 На этом сайте рандомизация классов не используется (скрипты не найдены). В джобах этап будет пропускаться автоматически.');
                    break;
                case SiteRandomizationInspector::CAP_CONFLICT:
                    $this->flash('warning', '🎲 Требует проверки: найдены сразу несколько скриптов рандомизации. Автоматический запуск запрещён, разберитесь какой из них действующий.');
                    break;
                case SiteRandomizationInspector::CAP_NEEDS_REVIEW:
                    $this->flash('warning', '🎲 Требует проверки: найден файл рандомизации, но панель не смогла подтвердить, что он подходит этому сайту'
                        . ($reason === 'manual_secret_missing' ? ' (в config.php не найден непустой manual_secret)' : '')
                        . '. Скрипт запускаться не будет.');
                    break;
                default:
                    $this->flash('error', '🎲 FTP-проверка не завершилась — статус рандомизации не обновлён. Проверьте доступность FTP и повторите.');
            }
        } catch (\Throwable $e) {
            $this->flash('error', 'Проверка не выполнена: ' . $e->getMessage());
        }
        $this->redirect('/sites/show?id=' . $id);
    }

    /**
     * ТЗ 039 §10: переключение режима рандомизации сайта (auto ↔ disabled).
     * Режим custom устанавливается только сохранением проверенного path.
     */
    public function setUcMode(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        $mode = (string)($_POST['uc_mode'] ?? '');
        $comment = trim((string)($_POST['comment'] ?? ''));
        $site = $this->loadSite($id);
        if (!in_array($mode, ['auto', 'disabled'], true)) {
            $this->flash('error', 'Недопустимый режим.');
            $this->redirect('/sites/show?id=' . $id);
        }
        if ($mode === 'disabled' && $comment === '') {
            $this->flash('error', 'Причина обязательна: укажите, почему рандомизация отключается для этого сайта.');
            $this->redirect('/sites/show?id=' . $id);
        }
        try {
            $det = json_encode([
                'checked_at' => date('Y-m-d H:i:s'),
                'source' => 'operator_mode_change',
                'mode' => $mode,
                'comment' => mb_substr($comment, 0, 300),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($mode === 'disabled') {
                DB::pdo()->prepare(
                    "UPDATE sites_managed SET uc_mode='disabled', uc_detection_json=?, uc_detected_at=NOW() WHERE id=?"
                )->execute([$det, $id]);
                $this->flash('success', '🎲 Рандомизация для сайта отключена. В джобах этап будет пропускаться с пометкой «отключена оператором».');
            } else {
                DB::pdo()->prepare(
                    "UPDATE sites_managed SET uc_mode='auto', uc_capability='unknown', uc_detection_json=?, uc_detected_at=NOW() WHERE id=?"
                )->execute([$det, $id]);
                $this->flash('success', '🎲 Режим — автоматический. Применимость будет проверена по FTP при следующей джобе или по кнопке «Проверить рандомизацию».');
            }
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось изменить режим: ' . $e->getMessage());
        }
        $this->redirect('/sites/show?id=' . $id);
    }

    /** seam для тестов. */
    protected function makeRandomizationInspector(): SiteRandomizationInspector
    {
        return new SiteRandomizationInspector();
    }

    /**
     * PATCH_5 (P0.7): сохранить multisite subsite (uc_site_subroot). Валидация:
     * subroot существует по FTP и его config.php относится к домену текущего сайта.
     * Пустое значение → сброс (панель попробует автоопределение из sites/_hostmap.php).
     */
    /**
     * PATCH_6 (P0.9): каноникализация subsite. Возвращает 'sites/<slug>' или null, если
     * ввод небезопасен/некорректен. Разрешено: '<slug>' или 'sites/<slug>', slug ^[A-Za-z0-9_-]+$.
     * Запрещено: '.', '..', вложенные '/', '\', URL-encoding, null-байты, повторные sites/.
     */
    public static function normalizeSubrootSlug(string $raw): ?string
    {
        $raw = trim($raw);
        if ($raw === '') return null;
        if (rawurldecode($raw) !== $raw) return null;                 // URL-кодировка
        if (strpos($raw, '..') !== false) return null;
        if (strpos($raw, '\\') !== false) return null;
        if (strpos($raw, "\0") !== false) return null;
        $slug = (strpos($raw, 'sites/') === 0) ? substr($raw, 6) : $raw;
        if (strpos($slug, '/') !== false) return null;                // вложенные / (в т.ч. sites/sites/..)
        if (!preg_match('~^[A-Za-z0-9_-]+$~', $slug)) return null;
        return 'sites/' . $slug;
    }

    public function saveMultisiteSubroot(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);
        $raw = trim((string)($_POST['uc_site_subroot'] ?? ''));
        if ($raw === '') {
            DB::pdo()->prepare("UPDATE sites_managed SET uc_site_subroot = NULL WHERE id = ?")->execute([$id]);
            $this->flash('success', '🌐 Subsite очищен. Панель попробует автоопределить его из sites/_hostmap.php по домену.');
            $this->redirect('/sites/show?id=' . $id);
            return;
        }
        $base = self::normalizeSubrootSlug($raw);
        if ($base === null) {
            http_response_code(400);
            $this->flash('error', '🌐 Недопустимый subsite: один сегмент [A-Za-z0-9_-] или sites/<slug>; запрещены "..", вложенные "/", "\\", URL-кодировка, повторные sites/.');
            $this->redirect('/sites/show?id=' . $id);
            return;
        }

        $ok = false; $reason = '';
        try {
            $ftp = new FtpService((string)$site['ftp_host'], (string)$site['ftp_user'], Crypto::decrypt((string)$site['ftp_pass_enc']));
            $ftp->connect();
            try {
                if (!$ftp->fileExists($base . '/config.php')) { $reason = 'в ' . $base . ' нет config.php'; }
                else {
                    $cfg = mb_strtolower((string)($ftp->tryGetContent($base . '/config.php') ?? ''));
                    $dom = mb_strtolower(trim((string)($site['current_domain'] ?? '')));
                    if ($dom !== '' && strpos($cfg, $dom) !== false) $ok = true;
                    else $reason = 'config.php субсайта не относится к домену ' . $dom . ' (возможно выбран чужой subsite)';
                }
            } finally { $ftp->disconnect(); }
        } catch (\Throwable $e) { $reason = 'FTP недоступен: ' . $e->getMessage(); }

        if (!$ok) {
            $this->flash('error', '🌐 Subsite не сохранён: ' . $reason . '. Запуск при неоднозначном/неподтверждённом subsite запрещён.');
            $this->redirect('/sites/show?id=' . $id);
            return;
        }
        DB::pdo()->prepare("UPDATE sites_managed SET uc_site_subroot = ? WHERE id = ?")->execute([$base, $id]);
        $this->flash('success', "🌐 Multisite subsite сохранён и подтверждён: {$base}");
        $this->redirect('/sites/show?id=' . $id);
    }

    /** PATCH_5 (P0.7): автоопределение subsite из sites/_hostmap.php по домену (подсказка UI). */
    public function detectMultisiteSubroot(int $id): ?array
    {
        try {
            $site = $this->loadSite($id);
            $ftp = new FtpService((string)$site['ftp_host'], (string)$site['ftp_user'], Crypto::decrypt((string)$site['ftp_pass_enc']));
            $ftp->connect();
            try {
                $c = (string)($ftp->tryGetContent('sites/_hostmap.php') ?? '');
                if ($c === '') return null;
                $pairs = [];
                if (preg_match_all("~['\\\"]([A-Za-z0-9.\\-]+)['\\\"]\\s*=>\\s*['\\\"]([A-Za-z0-9_\\-]+)['\\\"]~", $c, $mm, PREG_SET_ORDER)) {
                    foreach ($mm as $m) $pairs[mb_strtolower($m[1])] = $m[2];
                }
                $dom = mb_strtolower(trim((string)($site['current_domain'] ?? '')));
                foreach ([$dom, 'www.' . $dom] as $h) { if (isset($pairs[$h])) return ['host' => $h, 'slug' => $pairs[$h], 'base' => 'sites/' . $pairs[$h]]; }
            } finally { $ftp->disconnect(); }
        } catch (\Throwable $e) {}
        return null;
    }

    /**
     * v17.10: нормализация ввода update_classes_url.
     *
     * Если path-only (например "/update_classes.php?token=X") — возвращаем как есть
     *   (только проверяем что начинается со слеша).
     * Если полный URL (https://example.com/path?q=1) — отрезаем всё до пути.
     * Если пустая строка — возвращаем '' (сброс).
     */
    private function normalizeUpdateClassesPath(string $input): string
    {
        $input = trim($input);
        if ($input === '') return '';

        // Если выглядит как URL со схемой
        if (preg_match('~^https?://~i', $input)) {
            $parts = parse_url($input);
            $path = (string)($parts['path'] ?? '');
            $query = (string)($parts['query'] ?? '');
            if ($path === '') $path = '/';
            return $path . ($query !== '' ? '?' . $query : '');
        }

        // Path-only — добавляем ведущий слеш если нет
        if ($input[0] !== '/') $input = '/' . $input;
        return $input;
    }

    public function delete(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        DB::pdo()->prepare("DELETE FROM refresh_job_events WHERE job_id IN (SELECT id FROM refresh_jobs WHERE site_id=?)")->execute([$id]);
        DB::pdo()->prepare("DELETE FROM refresh_jobs WHERE site_id=?")->execute([$id]);
        DB::pdo()->prepare("DELETE FROM webmaster_hosts WHERE site_id=?")->execute([$id]);
        DB::pdo()->prepare("DELETE FROM sites_managed WHERE id=?")->execute([$id]);
        $this->flash('success', 'Сайт удалён из панели');
        $this->redirect('/sites');
    }

    public function createManualForm(): void
    {
        $this->requireAuth();
        $servers = DB::pdo()->query("SELECT * FROM fastpanel_servers ORDER BY title")->fetchAll();
        $this->view('sites/create_manual', ['servers' => $servers]);
    }

    public function createManualDo(): void
    {
        $this->requireAuth();
        $domain = trim((string)($_POST['current_domain'] ?? ''));
        $serverId = (int)($_POST['fastpanel_server_id'] ?? 0) ?: null;
        $vpsIp = trim((string)($_POST['vps_ip'] ?? ''));
        $owner = trim((string)($_POST['fp_site_owner'] ?? ''));
        $indexDir = trim((string)($_POST['fp_index_dir'] ?? ''));

        if ($domain === '') {
            $this->flash('error', 'Домен обязателен');
            $this->redirect('/sites/create-manual');
        }

        $st = DB::pdo()->prepare("INSERT INTO sites_managed
            (fastpanel_server_id, current_domain, vps_ip, fp_site_owner, fp_index_dir, status)
            VALUES (?, ?, ?, ?, ?, 'manual')");
        $st->execute([$serverId, $domain, $vpsIp, $owner, $indexDir]);
        $id = (int)DB::pdo()->lastInsertId();
        $this->flash('success', 'Сайт добавлен. Заполните FTP и синхронизируйте config.php');
        $this->redirect('/sites/show?id=' . $id);
    }

    /**
     * Очистка устаревших записей import_log для данного сайта.
     * Используется когда в логе остались сообщения от старых неудачных
     * попыток импорта/FTP, а текущее состояние сайта уже исправно.
     */
    /**
     * Перечитать данные сайта из FastPanel API и обновить vps_ip, aliases,
     * fp_index_dir, fp_raw_json. Не пересоздаёт FTP, не трогает config.php.
     *
     * Используется для починки устаревших данных — например когда vps_ip
     * был получен ДО фикса v8 (где находили IP в `address` вместо `ips[].ip`).
     */
    public function refreshFromFastpanel(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);

        $serverId = (int)($site['fastpanel_server_id'] ?? 0);
        $fpSiteId = (int)($site['fp_site_id'] ?? 0);
        if ($serverId <= 0 || $fpSiteId <= 0) {
            $this->flash('error', 'У сайта не задан FP server или fp_site_id');
            $this->redirect('/sites/show?id=' . $id);
        }

        try {
            // Используем FastpanelSearchService — у него есть готовый getSiteDetail
            $svc = new FastpanelSearchService($serverId);
            $detail = $svc->getSiteDetail($fpSiteId);

            // ТЗ «Единый безопасный выбор IP» §8.3: единый метод + правило стабильности
            // (сохранённый допустимый IP не переключается зря). Ошибка IP → НИКАКОГО
            // UPDATE (ни vps_ip, ни прочих полей частично). Старый vps_ip остаётся.
            $currentIp = trim((string)($site['vps_ip'] ?? ''));
            try {
                $vpsIp = $svc->selectAllowedVpsIp($detail, $currentIp !== '' ? $currentIp : null);
            } catch (\RuntimeException $e) {
                $this->flash('error', 'Обновление остановлено: ' . $e->getMessage() . ' Данные сайта не изменены.');
                $this->redirect('/sites/show?id=' . $id);
                return;
            }
            $owner = (string)($detail['owner'] ?? '');
            $indexDir = (string)($detail['index_dir'] ?? '');
            $aliases = $detail['aliases'] ?? [];
            $rawDetail = $detail['raw'] ?? [];

            // Обновляем
            $upd = DB::pdo()->prepare(
                "UPDATE sites_managed SET
                    vps_ip = COALESCE(NULLIF(?, ''), vps_ip),
                    fp_site_owner = COALESCE(NULLIF(?, ''), fp_site_owner),
                    fp_index_dir = COALESCE(NULLIF(?, ''), fp_index_dir),
                    aliases = ?,
                    fp_raw_json = ?
                 WHERE id = ?"
            );
            $upd->execute([
                $vpsIp,
                $owner,
                $indexDir,
                json_encode($aliases, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                json_encode($rawDetail, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $id,
            ]);

            $changes = [];
            if ($vpsIp && $vpsIp !== ($site['vps_ip'] ?? '')) {
                $changes[] = "vps_ip: " . ($site['vps_ip'] ?: '—') . " → {$vpsIp}";
            }
            $oldAliasCount = count(json_decode((string)($site['aliases'] ?? ''), true) ?: []);
            if (count($aliases) !== $oldAliasCount) {
                $changes[] = "aliases: {$oldAliasCount} → " . count($aliases);
            }
            if ($indexDir && $indexDir !== ($site['fp_index_dir'] ?? '')) {
                $changes[] = "index_dir: обновлён";
            }

            $msg = empty($changes)
                ? 'Данные с FP свежие, ничего не изменилось.'
                : 'Обновлено: ' . implode('; ', $changes);
            $this->flash('success', $msg);
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось получить данные с FP: ' . $e->getMessage());
        }
        $this->redirect('/sites/show?id=' . $id);
    }

    public function clearImportLog(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);
        $st = DB::pdo()->prepare("UPDATE sites_managed SET import_log=NULL WHERE id=?");
        $st->execute([$id]);
        $this->flash('success', 'История импорта очищена');
        $this->redirect('/sites/show?id=' . $id);
    }

    /**
     * v18.1: переключение выпуска Let's Encrypt сертификата для сайта.
     *
     * Эта галка контролирует, выполняется ли стадия ssl_le_polling в pipeline.
     * Default = 0 (выключено) — самоподписной SSL достаточен для DDoS-Guard origin.
     *
     * Если включить — следующая джоба будет проходить полный pipeline с LE-выпуском
     * через FastPanel API после verify_replacement (обычно 1-3 минуты polling'а).
     *
     * Простая SQL-операция, без побочных эффектов на FTP/FastPanel.
     */
    public function toggleSslLeEnabled(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);

        $current = (int)($site['ssl_le_enabled'] ?? 0);
        $new = $current === 1 ? 0 : 1;

        try {
            DB::pdo()->prepare(
                "UPDATE sites_managed SET ssl_le_enabled = ? WHERE id = ?"
            )->execute([$new, $id]);

            if ($new === 1) {
                $this->flash('success',
                    "✓ Let's Encrypt включён для сайта. Следующая джоба будет выпускать LE сертификат " .
                    "после стадии verify_replacement (обычно 1-3 минуты polling'а).");
            } else {
                $this->flash('success',
                    "✓ Let's Encrypt выключен для сайта. Следующая джоба пропустит стадию ssl_le_polling " .
                    "и будет использовать только самоподписной SSL.");
            }
        } catch (\Throwable $e) {
            $this->flash('error',
                'Не удалось переключить ssl_le_enabled: ' . $e->getMessage() .
                '. Возможно миграция 013 не применена.');
        }

        $this->redirect('/sites/show?id=' . $id);
    }

    /**
     * v18.1.2: переключение автоматической правки robots.php для сайта.
     *
     * Если включено — на стадии verify_replacement при провале robots_php_logic
     * проверки система через FTP перезапишет robots.php рекомендуемым шаблоном
     * (с проверкой sameHost против $domain). Без вмешательства оператора.
     *
     * Если выключено (default) — джоба уходит в awaiting_user, оператор сам
     * правит файл.
     */
    public function toggleAutopatchRobots(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        $site = $this->loadSite($id);

        // v18.1.2: default = 1 (включено). Для toggle логики если значение
        // отсутствует или = 1 → текущее «включено», переключаем на 0.
        $current = (int)($site['autopatch_robots_php'] ?? 1);
        $new = $current === 1 ? 0 : 1;

        try {
            DB::pdo()->prepare(
                "UPDATE sites_managed SET autopatch_robots_php = ? WHERE id = ?"
            )->execute([$new, $id]);

            if ($new === 1) {
                $this->flash('success',
                    "✓ Autopatch robots.php включён обратно (default). На стадии verify_replacement " .
                    "при провале robots_php_logic проверки система автоматически перезапишет robots.php.");
            } else {
                $this->flash('success',
                    "✓ Autopatch robots.php выключен для этого сайта. При некорректном файле джоба будет " .
                    "уходить в awaiting_user — оператор будет править файл руками. " .
                    "Включи обратно если кастомизация в robots.php не нужна.");
            }
        } catch (\Throwable $e) {
            $this->flash('error',
                'Не удалось переключить autopatch_robots_php: ' . $e->getMessage() .
                '. Возможно миграция 014 не применена.');
        }

        $this->redirect('/sites/show?id=' . $id);
    }

    private function loadSite(int $id): array
    {
        if ($id <= 0) { $this->flash('error', 'Сайт не найден'); $this->redirect('/sites'); }
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $site = $st->fetch();
        if (!$site) { $this->flash('error', 'Сайт не найден'); $this->redirect('/sites'); }
        return $site;
    }

    /**
     * PATCH 048: сохранить/снять ПОСТОЯННУЮ привязку сайта к аккаунту Yandex.Webmaster.
     * Локальная настройка панели: НЕ создаёт джобу, НЕ вызывает Webmaster mutations, НЕ трогает
     * site_webmaster_links (§11). account_id=0 → снять привязку (NULL). UPDATE только после проверок.
     */
    public function saveWebmasterAccount(): void
    {
        $this->requireAuth();
        $this->requireCsrf();

        $siteId = (int)($_POST['site_id'] ?? 0);
        $accountId = (int)($_POST['webmaster_account_id'] ?? 0); // 0 = снять привязку

        $pdo = DB::pdo();
        // 1) site_id существует.
        $siteSt = $pdo->prepare("SELECT id, webmaster_account_id FROM sites_managed WHERE id=?");
        $siteSt->execute([$siteId]);
        $site = $siteSt->fetch();
        if (!$site) {
            $this->flash('error', 'Сайт не найден');
            $this->redirect('/sites');
            return;
        }
        $oldAccountId = ($site['webmaster_account_id'] !== null) ? (int)$site['webmaster_account_id'] : null;

        // 2) Если привязываем к аккаунту — строгая валидация (§8/§24). Произвольный ID не принимаем.
        $newAccountId = null;
        if ($accountId > 0) {
            $acc = $pdo->prepare(
                "SELECT id, email, access_token_enc FROM yandex_webmaster_accounts WHERE id=?"
            );
            $acc->execute([$accountId]);
            $accRow = $acc->fetch();
            if (!$accRow) {
                $this->flash('error', "Webmaster account #{$accountId} не найден — привязка не изменена.");
                $this->redirect('/sites/show?id=' . $siteId);
                return;
            }
            if (empty($accRow['access_token_enc'])) {
                $this->flash('error', "У Webmaster account #{$accountId} нет токена — привязка не изменена. Перевыпустите токен.");
                $this->redirect('/sites/show?id=' . $siteId);
                return;
            }
            $newAccountId = $accountId;
        }

        // 3) UPDATE только после всех проверок. site_webmaster_links НЕ трогаем.
        $pdo->prepare("UPDATE sites_managed SET webmaster_account_id=? WHERE id=?")
            ->execute([$newAccountId, $siteId]);

        // 4) История изменения привязки (§27).
        try {
            $pdo->prepare(
                "INSERT INTO site_webmaster_assignment_log
                    (site_id, old_webmaster_account_id, new_webmaster_account_id, source)
                 VALUES (?, ?, ?, 'site_page')"
            )->execute([$siteId, $oldAccountId, $newAccountId]);
        } catch (\Throwable $e) { /* лог необязателен для успеха операции */ }

        // 5) Сообщение оператору (§10).
        if ($newAccountId === null) {
            $this->flash('success', '✓ Постоянная привязка Webmaster снята. Для следующих джоб используется Auto.');
        } else {
            $email = '';
            try {
                $e = $pdo->prepare("SELECT email FROM yandex_webmaster_accounts WHERE id=?");
                $e->execute([$newAccountId]); $email = (string)($e->fetchColumn() ?: '');
            } catch (\Throwable $ex) { /* ignore */ }
            $this->flash('success', "✓ Webmaster сайта сохранён: #{$newAccountId}" . ($email !== '' ? " · {$email}" : '')
                . '. Смена привязки не переносит текущий домен между аккаунтами — применяется к следующим джобам.');
        }
        $this->redirect('/sites/show?id=' . $siteId);
    }
}
