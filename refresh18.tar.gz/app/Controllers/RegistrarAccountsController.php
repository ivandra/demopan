<?php

class RegistrarAccountsController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        $rows = DB::pdo()->query("SELECT * FROM registrar_accounts ORDER BY id DESC")->fetchAll();
        $this->view('registrar_accounts/index', ['rows' => $rows]);
    }

    public function createForm(): void
    {
        $this->requireAuth();
        $this->view('registrar_accounts/create', []);
    }

    public function store(): void
    {
        $this->requireAuth();
        $apiUser = trim((string)($_POST['api_user'] ?? ''));
        $apiKey = (string)($_POST['api_key'] ?? '');
        $username = trim((string)($_POST['username'] ?? ''));
        $clientIp = trim((string)($_POST['client_ip'] ?? ''));
        $sandbox = !empty($_POST['is_sandbox']) ? 1 : 0;
        $isDefault = !empty($_POST['is_default']) ? 1 : 0;

        if ($apiUser === '' || $apiKey === '' || $username === '' || $clientIp === '') {
            $this->flash('error', 'Все поля обязательны');
            $this->redirect('/registrar/accounts/create');
        }

        if ($isDefault) {
            DB::pdo()->exec("UPDATE registrar_accounts SET is_default=0");
        }

        $st = DB::pdo()->prepare("INSERT INTO registrar_accounts
            (provider, is_sandbox, api_user, api_key_enc, username, client_ip, is_default)
            VALUES ('namecheap', ?, ?, ?, ?, ?, ?)");
        $st->execute([$sandbox, $apiUser, Crypto::encrypt($apiKey), $username, $clientIp, $isDefault]);

        $this->flash('success', 'Аккаунт регистратора добавлен');
        $this->redirect('/registrar/accounts');
    }

    public function delete(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        DB::pdo()->prepare("DELETE FROM registrar_accounts WHERE id=?")->execute([$id]);
        $this->flash('success', 'Удалён');
        $this->redirect('/registrar/accounts');
    }
}
