<?php

/**
 * ApiClientController — UI управления API-ключами (для админа refresh-panel'и).
 *
 * Маршруты:
 *   GET  /api-clients          — список ключей
 *   POST /api-clients/create   — создать новый (secret показывается ОДИН раз)
 *   POST /api-clients/revoke   — заблокировать ключ
 *   GET  /api-clients/test     — встроенная страница тестирования API
 */
class ApiClientController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();

        try {
            $rows = DB::pdo()->query(
                "SELECT id, label, key_prefix, scopes, last_used_at, last_used_ip,
                        revoked_at, note, created_at
                 FROM api_clients ORDER BY id DESC"
            )->fetchAll();
        } catch (Throwable $e) {
            // Таблица не создана
            $rows = [];
            $this->flash('error', 'Таблица api_clients ещё не мигрирована. Открой /settings и нажми «Применить миграции».');
        }

        // Достаём только-что-созданный ключ из сессии (показываем один раз)
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $newSecret = $_SESSION['__new_api_secret'] ?? null;
        unset($_SESSION['__new_api_secret']);

        $this->view('api_clients/index', [
            'rows'      => $rows,
            'newSecret' => $newSecret,
            'scopeList' => $this->knownScopes(),
        ]);
    }

    public function create(): void
    {
        $this->requireAuth();
        $label = trim((string)($_POST['label'] ?? ''));
        $scopes = $_POST['scopes'] ?? [];
        if (!is_array($scopes)) $scopes = [];
        $note = trim((string)($_POST['note'] ?? ''));

        if ($label === '') {
            $this->flash('error', 'Имя клиента обязательно');
            $this->redirect('/api-clients');
        }

        // Валидация scope'ов
        $known = array_keys($this->knownScopes());
        $scopes = array_values(array_filter($scopes, function ($s) use ($known) {
            return $s === '*' || in_array($s, $known, true);
        }));
        if (empty($scopes)) {
            $this->flash('error', 'Выбери хотя бы один scope');
            $this->redirect('/api-clients');
        }

        $rawKey = ApiAuth::generateKey();
        $prefix = ApiAuth::keyPrefix($rawKey);
        $hash   = ApiAuth::hashKey($rawKey);

        try {
            $ins = DB::pdo()->prepare(
                "INSERT INTO api_clients(label, key_prefix, key_hash, scopes, note)
                 VALUES (?,?,?,?,?)"
            );
            $ins->execute([$label, $prefix, $hash, implode(',', $scopes), $note]);
        } catch (Throwable $e) {
            $this->flash('error', 'Ошибка создания: ' . $e->getMessage());
            $this->redirect('/api-clients');
        }

        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION['__new_api_secret'] = $rawKey;
        $this->flash('ok', 'Ключ создан. Он показан ниже один раз — скопируй и сохрани в безопасном месте.');
        $this->redirect('/api-clients');
    }

    public function revoke(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->flash('error', 'bad id');
            $this->redirect('/api-clients');
        }
        try {
            $st = DB::pdo()->prepare(
                "UPDATE api_clients SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?"
            );
            $st->execute([$id]);
            $this->flash('ok', 'Ключ заблокирован');
        } catch (Throwable $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/api-clients');
    }

    public function unrevoke(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $this->flash('error', 'bad id');
            $this->redirect('/api-clients');
        }
        try {
            $st = DB::pdo()->prepare(
                "UPDATE api_clients SET revoked_at = NULL WHERE id = ?"
            );
            $st->execute([$id]);
            $this->flash('ok', 'Ключ разблокирован');
        } catch (Throwable $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/api-clients');
    }

    public function test(): void
    {
        $this->requireAuth();
        $this->view('api_clients/test', []);
    }

    public function knownScopes(): array
    {
        return [
            'webmaster.read'         => 'Список Yandex-аккаунтов (без токенов)',
            'webmaster.credentials'  => 'Выдача access_token Yandex Webmaster',
            'registrar.read'         => 'Список Namecheap-аккаунтов и контактов',
            'registrar.credentials'  => 'Выдача Namecheap api_key',
            'fastpanel.read'         => 'Список FastPanel-серверов',
            'fastpanel.jwt'          => 'Логин на FP и выдача JWT',
            'server.resolve'         => 'Резолв IP сайта по fp_server/fp_site',
            'appsettings.read'       => 'Публичные настройки (max_price и т.п.)',
            'casino.read'            => '[Casino] Чтение своих проектов',
            'casino.write'           => '[Casino] Регистрация / обновление проекта',
            'casino.deploy'          => '[Casino] Старт операций (buy/subs/ssl/webmaster/cron)',
        ];
    }
}
