<?php

/**
 * ТЗ 040 FINAL §5/§6: управление FastPanel-серверами.
 *
 * Серверный профиль хранит ТОЛЬКО маркировку (badge) и безопасный итог
 * read-only проверки подключения. НЕ вводит серверный Webmaster, режим
 * активности сервера и IP сайтов по умолчанию (§3.1–§3.3). CSRF на всех POST,
 * безопасное удаление в транзакции с блокировкой строки и fail-closed
 * проверкой зависимостей. Пароль/секреты не логируются и не возвращаются.
 */
class FastpanelServerController extends Controller
{
    /** Тестовый шов: фабрика FastPanel-клиента (тесты подменяют без сети). */
    protected function makeClient(string $host, bool $verifyTls): FastpanelClient
    {
        return new FastpanelClient($host, $verifyTls, 15);
    }

    public function index(): void
    {
        $this->requireAuth();
        $rows = DB::pdo()->query("SELECT * FROM fastpanel_servers ORDER BY id DESC")->fetchAll();
        $counts = [];
        foreach (DB::pdo()->query("SELECT fastpanel_server_id sid, COUNT(*) n FROM sites_managed GROUP BY fastpanel_server_id") as $r) {
            $counts[(int)$r['sid']] = (int)$r['n'];
        }
        $this->view('servers/index', [
            'rows' => $rows,
            'siteCounts' => $counts,
            'csrfToken' => $this->csrfToken(),
        ]);
    }

    public function createForm(): void
    {
        $this->requireAuth();
        $this->view('servers/create', ['csrfToken' => $this->csrfToken()]);
    }

    public function editForm(): void
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $st->execute([$id]);
        $server = $st->fetch();
        if (!$server) { $this->flash('error', 'Сервер не найден'); $this->redirect('/servers'); return; }
        // ТЗ 042 §3.1: предметное имя $server (не $row) — layout использует $row в
        // цикле балансов и затирал бы переданную строку сервера.
        $this->view('servers/edit', ['server' => $server, 'csrfToken' => $this->csrfToken()]);
    }

    public function store(): void
    {
        $this->requireAuth();
        $this->requireCsrf();

        $password = (string)($_POST['password'] ?? '');
        if ($password === '') {
            $this->flash('error', 'Пароль обязателен при создании');
            $this->redirect('/servers/create');
        }

        $prof = $this->collectProfile($_POST, null);
        if (!$prof['ok']) { $this->flash('error', $prof['error']); $this->redirect('/servers/create'); }
        $f = $prof['fields'];

        $st = DB::pdo()->prepare("INSERT INTO fastpanel_servers
            (title, host, username, password_enc, extra_ips, verify_tls,
             ui_badge_code, ui_badge_label, ui_badge_color)
            VALUES (?,?,?,?,?,?,?,?,?)");
        try {
            $st->execute([
                $f['title'], $f['host'], $f['username'], Crypto::encrypt($password), $f['extra_ips'], $f['verify_tls'],
                $f['ui_badge_code'], $f['ui_badge_label'], $f['ui_badge_color'],
            ]);
        } catch (\PDOException $e) {
            // §3.10 race: уникальный индекс поймал конкурентный дубль — не 500, без SQL.
            if ($e->getCode() === '23000') {
                $this->flash('error', 'Сервер с таким FastPanel host уже существует.');
                $this->redirect('/servers/create');
            }
            throw $e;
        }

        $this->flash('success', 'Сервер добавлен');
        $this->redirect('/servers');
    }

    public function update(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { $this->flash('error', 'bad id'); $this->redirect('/servers'); }

        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $st->execute([$id]);
        $existing = $st->fetch();
        if (!$existing) { $this->flash('error', 'Сервер не найден'); $this->redirect('/servers'); }

        $prof = $this->collectProfile($_POST, $existing);
        if (!$prof['ok']) { $this->flash('error', $prof['error']); $this->redirect('/servers/edit?id=' . $id); }
        $f = $prof['fields'];

        $password = (string)($_POST['password'] ?? '');
        if ($password !== '') {
            // §5.2: непустой пароль — меняем; пустой — оставляем прежний.
            $sql = "UPDATE fastpanel_servers SET title=?, host=?, username=?, password_enc=?, extra_ips=?, verify_tls=?,
                    ui_badge_code=?, ui_badge_label=?, ui_badge_color=? WHERE id=?";
            $args = [$f['title'], $f['host'], $f['username'], Crypto::encrypt($password), $f['extra_ips'], $f['verify_tls'],
                     $f['ui_badge_code'], $f['ui_badge_label'], $f['ui_badge_color'], $id];
        } else {
            $sql = "UPDATE fastpanel_servers SET title=?, host=?, username=?, extra_ips=?, verify_tls=?,
                    ui_badge_code=?, ui_badge_label=?, ui_badge_color=? WHERE id=?";
            $args = [$f['title'], $f['host'], $f['username'], $f['extra_ips'], $f['verify_tls'],
                     $f['ui_badge_code'], $f['ui_badge_label'], $f['ui_badge_color'], $id];
        }
        try {
            DB::pdo()->prepare($sql)->execute($args);
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {
                $this->flash('error', 'Сервер с таким FastPanel host уже существует.');
                $this->redirect('/servers/edit?id=' . $id);
            }
            throw $e;
        }

        $this->flash('success', 'Сервер обновлён');
        $this->redirect('/servers');
    }

    /**
     * §5.6: удаление сервера. Разрешено ТОЛЬКО если одновременно
     * sites_managed=0, fp_sites_cache=0, активных refresh_jobs через сайты=0.
     * Проверка и DELETE — в ОДНОЙ транзакции, строка заблокирована FOR UPDATE,
     * проверка зависимостей fail-closed (любая ошибка → откат, удаление отменено).
     */
    public function delete(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { $this->flash('error', 'bad id'); $this->redirect('/servers'); }

        $pdo = DB::pdo();
        $notFound = false; $blocked = null; $failClosed = false;

        // Транзакция + блокировка строки. Побочные эффекты (flash/redirect) —
        // СТРОГО после транзакции, чтобы они не попадали в catch и не мешали
        // откату. Проверка зависимостей fail-closed (§5.6).
        $pdo->beginTransaction();
        try {
            $lock = $pdo->prepare("SELECT id FROM fastpanel_servers WHERE id=? FOR UPDATE");
            $lock->execute([$id]);
            if (!$lock->fetchColumn()) {
                $notFound = true;
            } else {
                // НИКАКОГО catch(Throwable){return 0}: ошибка запроса поднимается
                // наверх → откат и «удаление отменено» (fail-closed).
                $sites = (int)$this->countDep($pdo, "SELECT COUNT(*) FROM sites_managed WHERE fastpanel_server_id=?", $id);
                $cache = (int)$this->countDep($pdo, "SELECT COUNT(*) FROM fp_sites_cache WHERE fastpanel_server_id=?", $id);
                $active = (int)$this->countDep($pdo,
                    "SELECT COUNT(*) FROM refresh_jobs j
                     JOIN sites_managed s ON s.id = j.site_id
                     WHERE s.fastpanel_server_id=? AND j.closed_at IS NULL
                       AND j.stage NOT IN ('done','failed','cancelled')", $id);

                if ($sites > 0 || $cache > 0 || $active > 0) {
                    $blocked = ['sites' => $sites, 'cache' => $cache, 'active' => $active];
                } else {
                    $pdo->prepare("DELETE FROM fastpanel_servers WHERE id=?")->execute([$id]);
                }
            }
            if ($notFound || $blocked !== null) { $pdo->rollBack(); }
            else { $pdo->commit(); }
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('server delete dependency check failed: ' . $e->getMessage());
            $failClosed = true;
        }

        if ($failClosed) {
            $this->flash('error', 'Не удалось проверить зависимости сервера. Удаление отменено.');
            $this->redirect('/servers');
        }
        if ($notFound) { $this->flash('error', 'Сервер не найден'); $this->redirect('/servers'); }
        if ($blocked !== null) {
            $this->flash('error',
                "Сервер используется {$blocked['sites']} сайтами. Кеш FastPanel: {$blocked['cache']} записей. " .
                "Активных джоб: {$blocked['active']}. Удаление запрещено.");
            $this->redirect('/servers');
        }

        $this->flash('success', 'Сервер удалён');
        $this->redirect('/servers');
    }

    /** §6: read-only preflight. POST, CSRF. Возвращает безопасную сводку. */
    public function testConnection(): void
    {
        // ТЗ 042 §5: endpoint ВСЕГДА отвечает JSON при штатно обрабатываемых
        // исходах. Диагностический request_id в каждом ответе и в логах.
        $requestId = 'fp-' . bin2hex(random_bytes(4));
        try {
            // §5.3 JSON-аутентификация: истёкшая сессия → JSON 401 (не HTML redirect).
            $this->requireJsonAuth($requestId);
            // §5.4 JSON-CSRF: недействительный токен → JSON 403 (не text/plain).
            if (!$this->csrfValid()) {
                $this->jsonErrRid('CSRF-токен недействителен. Обновите страницу.', 403, $requestId);
            }
            // §5.5 проверка ID.
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) {
                $this->jsonErrRid('Некорректный ID FastPanel-сервера.', 400, $requestId);
            }
            $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
            $st->execute([$id]);
            $row = $st->fetch();
            if (!$row) {
                $this->jsonErrRid('FastPanel-сервер не найден.', 404, $requestId);
            }

            $res = $this->runPreflight($row);
            $res['request_id'] = $requestId;

            // §5.6 безопасное JSON-кодирование деталей (ошибка кодирования → верхний catch → 500).
            $detailsJson = json_encode(
                $res,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR
            );

            // §5.7 сохранить безопасный итог. Ошибка сохранения → верхний catch → 500,
            // ложный PASS не возвращаем.
            $upd = DB::pdo()->prepare("UPDATE fastpanel_servers
                SET last_tested_at = NOW(), last_test_ok = ?, last_test_error = ?, last_test_details_json = ? WHERE id=?");
            $upd->execute([
                $res['ok'] ? 1 : 0,
                $res['ok'] ? null : mb_substr((string)($res['error'] ?? 'unknown'), 0, 1000),
                $detailsJson,
                $id,
            ]);

            if (!empty($res['ok'])) {
                $this->jsonOkRid($res, $requestId);
            }
            $this->jsonErrRid((string)($res['error'] ?? 'preflight failed'), 400, $requestId);
        } catch (\Throwable $e) {
            $safeMessage = $this->safeError((string)$e->getMessage());
            error_log(sprintf(
                '[%s] FastPanel test failed: %s in %s:%d',
                $requestId, $safeMessage, basename((string)$e->getFile()), (int)$e->getLine()
            ));
            $this->jsonErrRid('Внутренняя ошибка проверки FastPanel. Код: ' . $requestId, 500, $requestId);
        }
    }

    // ── ТЗ 042 §5: JSON-хелперы endpoint (локальные, чтобы не менять общий Controller) ──

    /** §5.3: JSON-аутентификация для AJAX-endpoint (без HTML-redirect на /login). */
    protected function requireJsonAuth(string $requestId): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
        if (empty($_SESSION['auth']) || $_SESSION['auth'] !== true) {
            $this->jsonErrRid('Сессия истекла. Обновите страницу и войдите снова.', 401, $requestId);
        }
    }

    /** Безопасный JSON-ответ (UTF-8 substitute), с request_id. Завершает запрос. */
    protected function jsonRespond(array $payload, int $code): void
    {
        if (!headers_sent()) {
            http_response_code($code);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    protected function jsonOkRid(array $data, string $requestId): void
    {
        $data['ok'] = true;
        $data['request_id'] = $requestId;
        $this->jsonRespond($data, 200);
    }

    protected function jsonErrRid(string $msg, int $code, string $requestId): void
    {
        $this->jsonRespond(['ok' => false, 'error' => $this->safeError($msg), 'request_id' => $requestId], $code);
    }

    // ── helpers ─────────────────────────────────────────────────────────

    /**
     * §6.1: preflight. Читает /api/me, /api/sites/simple и detail первого сайта
     * (если есть). НИЧЕГО не создаёт/не меняет на FastPanel (§6.2).
     * @return array безопасная сводка (без секретов, §6.3)
     */
    protected function runPreflight(array $server): array
    {
        $host = (string)$server['host'];
        $t0 = microtime(true);
        $fail = function (string $msg) use ($host, $t0): array {
            return [
                'ok' => false,
                'error' => $this->safeError($msg),
                'panel_host' => $host,
                'duration_ms' => (int)round((microtime(true) - $t0) * 1000),
            ];
        };
        try {
            $pass = Crypto::decrypt((string)$server['password_enc']);
            $client = $this->makeClient($host, (bool)$server['verify_tls']);
            $client->login((string)$server['username'], $pass);
            unset($pass);

            // §3.3 валидация /api/me: массив, непустой, есть непустой идентификатор.
            $me = $client->me();
            if (!is_array($me) || empty($me)) return $fail('FastPanel /api/me вернул неизвестную или пустую структуру.');
            $user = '';
            foreach (['username', 'name', 'login', 'email'] as $f) {
                if (!empty($me[$f]) && is_string($me[$f])) { $user = trim($me[$f]); break; }
            }
            if ($user === '') return $fail('FastPanel /api/me не содержит идентификатор пользователя.');

            // §3 (аудит ver3): единый контракт списка сайтов — тот же нормализатор,
            // что и в refreshCache. Preflight не должен принимать то, что импорт не умеет.
            $sites = $client->simpleSites();
            $list = FastpanelSearchService::normalizeSimpleSitesPayload($sites);
            if ($list === null) {
                return $fail('FastPanel /api/sites/simple вернул неизвестную структуру списка сайтов.');
            }
            $count = count($list);

            // §3.3: пустой список — единственный случай, где detail_read=false при PASS.
            if ($count === 0) {
                return [
                    'ok' => true, 'authenticated_user' => $user, 'sites_count' => 0,
                    'site_detail_read' => false, 'panel_host' => $host,
                    'duration_ms' => (int)round((microtime(true) - $t0) * 1000),
                ];
            }

            // §3.3/§3: обязательный валидный ID первого сайта (id/site_id/ID) — тем же
            // экстрактором, что использует refreshCache.
            $first = $list[0] ?? null;
            $firstId = is_array($first) ? FastpanelSearchService::extractSimpleSiteId($first) : 0;
            if ($firstId <= 0) return $fail('FastPanel: у первого сайта отсутствует валидный ID.');

            // §3.3: detail первого сайта — непустой массив с распознаваемой сущностью.
            $d = $client->site($firstId);
            if (!is_array($d) || empty($d)) return $fail('FastPanel вернул пустой или непригодный detail первого сайта.');
            $detailIdOk = false;
            foreach (['id', 'site_id', 'ID'] as $f) {
                if (isset($d[$f]) && (int)$d[$f] === $firstId) { $detailIdOk = true; break; }
            }
            $entityOk = false;
            foreach (['server_name', 'domain', 'virtualhost', 'owner'] as $f) {
                if (!empty($d[$f])) { $entityOk = true; break; }
            }
            if (!$detailIdOk && !$entityOk) {
                return $fail('FastPanel detail первого сайта не распознан (нет ID и базовой сущности сайта).');
            }

            // §3.3 инвариант: sites_count>0 ⇒ site_detail_read=true.
            return [
                'ok' => true, 'authenticated_user' => $user, 'sites_count' => $count,
                'site_detail_read' => true, 'panel_host' => $host,
                'duration_ms' => (int)round((microtime(true) - $t0) * 1000),
            ];
        } catch (\Throwable $e) {
            return $fail($e->getMessage());
        }
    }

    /** true, если массив — список (последовательные целочисленные ключи с 0). */
    private static function isList($a): bool
    {
        if (!is_array($a)) return false;
        if ($a === []) return true;
        return array_keys($a) === range(0, count($a) - 1);
    }

    /** Вычистить возможный секрет из текста ошибки и ограничить длину (§6.3). */
    private function safeError(string $msg): string
    {
        $msg = preg_replace('~(?i)(authorization|bearer|token|password|jwt)\s*[:=]?\s*\S+~', '$1 ***', $msg);
        return mb_substr(trim((string)$msg), 0, 900);
    }

    /**
     * Собрать и провалидировать профиль из POST (§5). Только разрешённые поля:
     * title, host, username, extra_ips, verify_tls, badge. Ни Webmaster, ни
     * активности, ни default_site_ip.
     */
    protected function collectProfile(array $post, ?array $existing): array
    {
        $err = function (string $m) { return ['ok' => false, 'fields' => [], 'error' => $m]; };

        $title = trim((string)($post['title'] ?? ''));
        $username = trim((string)($post['username'] ?? ''));
        $verifyTls = !empty($post['verify_tls']) ? 1 : 0;

        // §3.11 длины: title 1-100, username 1-100.
        if ($title === '' || mb_strlen($title) > 100) return $err('Название: 1–100 символов');
        if ($username === '' || mb_strlen($username) > 100) return $err('Логин: 1–100 символов');

        // host §3.10: единый нормализатор, canonical ≤ 255.
        $hn = ServerProfileValidator::normalizeHost((string)($post['host'] ?? ''));
        if (!$hn['ok']) return $err('Host: ' . $hn['error']);
        $host = $hn['host'];
        if (strlen($host) > 255) return $err('Host слишком длинный (>255)');

        // дубликат canonical host (кроме себя) §3.10
        $dupSt = DB::pdo()->prepare("SELECT COUNT(*) FROM fastpanel_servers WHERE host=? AND id<>?");
        $dupSt->execute([$host, (int)($existing['id'] ?? 0)]);
        if ((int)$dupSt->fetchColumn() > 0) {
            return $err('Сервер с таким FastPanel host уже существует.');
        }

        // §3.11 extra_ips: каждый непустой токен — валидный IPv4, иначе весь профиль
        // отклоняется. Разделители: запятая/;/пробел/таб/перенос строки. Дедуп с
        // сохранением порядка; literal host-IP убирается из extra; без DNS lookup.
        $rawExtra = (string)($post['extra_ips'] ?? '');
        $tokens = preg_split('~[,;\s]+~', trim($rawExtra), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $extraList = [];
        foreach ($tokens as $tok) {
            if (filter_var($tok, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) {
                return $err("Некорректный IP в «Дополнительные IP»: {$tok}. Профиль не сохранён.");
            }
            if (!in_array($tok, $extraList, true)) $extraList[] = $tok;
        }
        // убрать literal host-IP из extra (если host — IPv4)
        $hostIp = (new FastpanelServerIpPolicy())->hostIp($host);
        if ($hostIp !== '') $extraList = array_values(array_filter($extraList, fn($ip) => $ip !== $hostIp));
        $extraCanonical = implode(', ', $extraList);

        // badge §5.4 / §3.11 длины
        $badgeCode = trim((string)($post['ui_badge_code'] ?? ''));
        $badgeLabel = trim((string)($post['ui_badge_label'] ?? ''));
        $badgeColor = trim((string)($post['ui_badge_color'] ?? ''));
        if ($badgeCode !== '' && !ServerProfileValidator::validBadgeCode($badgeCode)) {
            return $err('Код бейджа: 1–8 символов, только буквы/цифры/_-');
        }
        if (mb_strlen($badgeLabel) > 64) return $err('Подпись бейджа: не более 64 символов');
        if ($badgeColor !== '' && !ServerProfileValidator::validColor($badgeColor)) {
            return $err('Цвет бейджа должен быть в формате #RRGGBB');
        }

        return ['ok' => true, 'error' => null, 'fields' => [
            'title' => $title,
            'host' => $host,
            'username' => $username,
            'extra_ips' => $extraCanonical,
            'verify_tls' => $verifyTls,
            'ui_badge_code' => $badgeCode !== '' ? $badgeCode : null,
            'ui_badge_label' => $badgeLabel !== '' ? $badgeLabel : null,
            'ui_badge_color' => $badgeColor !== '' ? $badgeColor : null,
        ]];
    }

    /**
     * Счётчик зависимости. НАМЕРЕННО без catch: ошибка запроса должна
     * подниматься наверх, где delete() откатит транзакцию (fail-closed §5.6).
     */
    protected function countDep(PDO $pdo, string $sql, int $id): int
    {
        $st = $pdo->prepare($sql);
        $st->execute([$id]);
        return (int)$st->fetchColumn();
    }
}
