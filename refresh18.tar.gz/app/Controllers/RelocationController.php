<?php

/**
 * RelocationController — раздел «Переезды».
 *
 * Показывает переезды move_indexed / move_simple. Режим refresh в раздел не
 * входит: в панели это перевыставление, а не переезд, даже если технически
 * домен тоже меняется. Критерий отбора однозначный — refresh_jobs.mode.
 *
 * Доступ — как у раздела джоб: любой авторизованный (в панели одна общая
 * учётная запись, ролей нет). Ручные действия журналируются в
 * refresh_job_events со стадией 'relocation' с указанием логина оператора.
 */
class RelocationController extends Controller
{
    /** Быстрые вкладки списка. */
    const TABS = [
        'all'         => 'Все',
        'active'      => 'Активные',
        'overdue'     => 'Просроченные',
        'indexed'     => 'В индексе',
        'not_indexed' => 'Без индекса',
        'completed'   => 'Завершённые',
        'cancelled'   => 'Отменённые',
    ];

    public function index(): void
    {
        $this->requireAuth();

        $tab       = (string)($_GET['tab'] ?? 'all');
        if (!isset(self::TABS[$tab])) $tab = 'all';

        $q         = trim((string)($_GET['q'] ?? ''));
        $mode      = (string)($_GET['mode'] ?? '');
        $idxStatus = (string)($_GET['index_status'] ?? '');
        $sort      = (string)($_GET['sort'] ?? 'started_desc');

        $rows = $this->fetchRows($tab, $q, $mode, $idxStatus, $sort);

        // Счётчики для вкладок
        $counts = [];
        foreach (array_keys(self::TABS) as $t) {
            $counts[$t] = count($this->fetchRows($t, '', '', '', 'started_desc', true));
        }

        $this->view('relocations/index', [
            'rows'      => $rows,
            'tab'       => $tab,
            'tabs'      => self::TABS,
            'counts'    => $counts,
            'q'         => $q,
            'mode'      => $mode,
            'idxStatus' => $idxStatus,
            'sort'      => $sort,
            'servers'      => ServerBadgePresenter::serversForFilter(),
            'serverFilter' => (int)($_GET['server_id'] ?? 0),
            'badgeBySite'  => (new ServerBadgePresenter())->badgeMapBySite(),
        ]);
    }

    public function show(): void
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);

        $row = $this->fetchOne($id);
        if (!$row) {
            $this->flash('error', 'Переезд не найден');
            $this->redirect('/relocations');
        }

        // ТЗ 040 FINAL-3 §3.6/§9.6: бейдж из полей baseSelect (effective_site_id),
        // а не отдельным SQL. Контроллер готовит данные, не View.
        $serverBadge = (new ServerBadgePresenter())->fromRow($row);

        $this->view('relocations/show', [
            'r'       => $row,
            'serverBadge' => $serverBadge,
            'checks'  => RelocationService::checkHistory($id, 50),
            'events'  => $this->loadRelocationEvents((int)$row['job_id']),
        ]);
    }

    /* ==================== ДЕЙСТВИЯ ==================== */

    public function savePlannedAt(): void
    {
        $this->requireAuth();
        $id  = (int)($_POST['id'] ?? 0);
        $val = trim((string)($_POST['planned_at'] ?? ''));

        $res = RelocationService::changePlannedAt($id, str_replace('T', ' ', $val), RelocationService::currentUser());
        if (!empty($res['ok'])) {
            $this->flash('success', 'Плановая дата обновлена. Дата старта не изменилась.');
        } else {
            $this->flash('error', (string)($res['error'] ?? 'Не удалось обновить'));
        }
        $this->redirect('/relocations/show?id=' . $id);
    }

    public function checkNow(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);

        $row = $this->fetchOne($id);
        if (!$row) {
            $this->flash('error', 'Переезд не найден');
            $this->redirect('/relocations');
        }

        $user = RelocationService::currentUser();
        RelocationService::logAction((int)$row['job_id'], 'manual_check_requested', ['user' => $user]);

        $res = RelocationIndexChecker::check($id, (string)$row['new_domain'], 'manual', $user);

        if (!empty($res['skipped'])) {
            // v22.2: причина пропуска показывается конкретная. Раньше низкий баланс
            // и активная проверка pipeline отображались как «занятый lock».
            $reason = (string)($res['skip_reason'] ?? 'lock_busy');
            RelocationService::logAction((int)$row['job_id'],
                'manual_check_skipped_' . $reason,
                ['user' => $user, 'comment' => (string)$res['message']]);
            $this->flash('warning', (string)$res['message'] . ' — платный запрос не отправлен.');
        } elseif (!empty($res['ok'])) {
            $this->flash('success', 'XMLStock: ' . $res['message']);
        } else {
            $this->flash('error', 'XMLStock: ' . $res['message']);
        }

        $this->redirect('/relocations/show?id=' . $id);
    }

    public function cancel(): void
    {
        $this->requireAuth();
        $id      = (int)($_POST['id'] ?? 0);
        $comment = trim((string)($_POST['comment'] ?? ''));

        $res = RelocationService::cancel($id, $comment, RelocationService::currentUser());
        if (!empty($res['ok'])) {
            $this->flash('success', 'Учёт переезда отменён. Джоба при этом не изменена.');
        } else {
            $this->flash('error', (string)($res['error'] ?? 'Не удалось отменить'));
        }
        $this->redirect('/relocations/show?id=' . $id);
    }

    /* ==================== ВЫБОРКА ==================== */

    private function baseSelect(): string
    {
        // ТЗ 040 FINAL-3 §3.6: effective_site_id = COALESCE(job.site_id,
        // snapshot_json.site_id). Историю нельзя терять после удаления джобы —
        // сервер/бейдж определяются по snapshot, если джоба удалена.
        // LEFT JOIN — джоба может быть удалена; тогда данные берутся из snapshot_json.
        return "SELECT r.*,
                       j.id           AS job_id_present,
                       j.site_id      AS job_site_id,
                       COALESCE(
                           j.site_id,
                           CAST(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(r.snapshot_json, '$.site_id')), '') AS UNSIGNED)
                       )              AS effective_site_id,
                       s.fastpanel_server_id AS server_id,
                       fps.title      AS server_title,
                       fps.ui_badge_code, fps.ui_badge_label, fps.ui_badge_color,
                       j.mode         AS job_mode,
                       j.old_domain   AS job_old_domain,
                       j.new_domain   AS job_new_domain,
                       j.stage        AS job_stage,
                       j.stage_status AS job_stage_status,
                       j.created_at   AS job_created_at
                  FROM site_relocations r
                  LEFT JOIN refresh_jobs j ON j.id = r.job_id
                  LEFT JOIN sites_managed s ON s.id = COALESCE(
                           j.site_id,
                           CAST(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(r.snapshot_json, '$.site_id')), '') AS UNSIGNED)
                       )
                  LEFT JOIN fastpanel_servers fps ON fps.id = s.fastpanel_server_id";
    }

    private function fetchOne(int $id): ?array
    {
        $st = DB::pdo()->prepare($this->baseSelect() . " WHERE r.id = ?");
        $st->execute([$id]);
        $row = $st->fetch();
        if (!is_array($row)) return null;
        return RelocationService::enrich($row);
    }

    /**
     * @param bool $countOnly для счётчиков вкладок (без поиска и сортировки)
     */
    private function fetchRows(
        string $tab, string $q, string $mode, string $idxStatus, string $sort, bool $countOnly = false
    ): array {
        $where = [];
        $args  = [];

        // Раздел показывает ТОЛЬКО move-режимы. Для удалённых джоб режим берём
        // из snapshot_json, поэтому условие допускает j.mode IS NULL.
        $where[] = "COALESCE(j.mode, JSON_UNQUOTE(JSON_EXTRACT(r.snapshot_json,'$.mode')))"
                 . " IN ('move_indexed','move_simple')";

        if ($q !== '') {
            $where[] = "(j.old_domain LIKE ? OR j.new_domain LIKE ? OR r.snapshot_json LIKE ?)";
            $like = '%' . $q . '%';
            $args[] = $like; $args[] = $like; $args[] = $like;
        }
        if ($mode !== '' && in_array($mode, RelocationService::MOVE_MODES, true)) {
            // H8: при удалённой джобе режим известен только из snapshot_json.
            $where[] = "COALESCE(j.mode, JSON_UNQUOTE(JSON_EXTRACT(r.snapshot_json,'$.mode'))) = ?";
            $args[] = $mode;
        }
        if ($idxStatus !== '' && in_array($idxStatus, RelocationService::INDEX_STATUSES, true)) {
            $where[] = "r.index_status = ?";
            $args[] = $idxStatus;
        }

        // ТЗ 040 FINAL-3 §3.6: фильтр по серверу через effective_site_id
        // (baseSelect JOIN-ит sites_managed s по COALESCE(job.site_id, snapshot.site_id)),
        // поэтому исторические переезды с удалённой джобой не теряются.
        $serverFilter = (int)($_GET['server_id'] ?? 0);
        if ($serverFilter > 0) {
            $where[] = "s.fastpanel_server_id = ?";
            $args[] = $serverFilter;
        }

        switch ($tab) {
            case 'active':
                $where[] = "r.cancelled_at IS NULL AND r.move_completed_at IS NULL";
                break;
            case 'overdue':
                $where[] = "r.cancelled_at IS NULL AND r.move_completed_at IS NULL AND r.planned_at < NOW()";
                break;
            case 'indexed':
                $where[] = "r.index_status = 'indexed'";
                break;
            case 'not_indexed':
                $where[] = "r.index_status = 'not_indexed'";
                break;
            case 'completed':
                $where[] = "r.move_completed_at IS NOT NULL";
                break;
            case 'cancelled':
                $where[] = "r.cancelled_at IS NOT NULL";
                break;
        }

        // H8: сортировка по старту тоже должна учитывать snapshot удалённой джобы.
        $startExpr = "COALESCE(j.created_at, "
                   . "STR_TO_DATE(JSON_UNQUOTE(JSON_EXTRACT(r.snapshot_json,'$.job_created_at')), '%Y-%m-%d %H:%i:%s'))";
        $orderMap = [
            'started_desc'   => $startExpr . ' DESC, r.id DESC',
            'started_asc'    => $startExpr . ' ASC, r.id ASC',
            'planned_desc'   => 'r.planned_at DESC',
            'planned_asc'    => 'r.planned_at ASC',
            'completed_desc' => 'r.move_completed_at IS NULL, r.move_completed_at DESC',
            'indexed_desc'   => 'r.first_indexed_at IS NULL, r.first_indexed_at DESC',
        ];
        $order = $orderMap[$sort] ?? $orderMap['started_desc'];

        $sql = $this->baseSelect()
             . (count($where) ? ' WHERE ' . implode(' AND ', $where) : '')
             . ' ORDER BY ' . $order
             . ' LIMIT 500';

        $st = DB::pdo()->prepare($sql);
        $st->execute($args);
        $rows = $st->fetchAll() ?: [];

        $out = [];
        foreach ($rows as $row) {
            $out[] = RelocationService::enrich($row);
        }

        // Сортировка по задержке — только в PHP (значение вычисляемое)
        if (!$countOnly && $sort === 'delay_desc') {
            usort($out, function ($a, $b) {
                return ($b['delay']['sort'] ?? 0) <=> ($a['delay']['sort'] ?? 0);
            });
        }

        return $out;
    }

    /** События раздела по джобе — для карточки. */
    private function loadRelocationEvents(int $jobId): array
    {
        try {
            $st = DB::pdo()->prepare(
                "SELECT * FROM refresh_job_events
                  WHERE job_id = ? AND stage = 'relocation'
                  ORDER BY created_at DESC, id DESC
                  LIMIT 50"
            );
            $st->execute([$jobId]);
            return $st->fetchAll() ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }
}
