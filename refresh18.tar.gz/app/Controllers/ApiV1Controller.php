<?php

/**
 * ApiV1Controller — /api/v1/* endpoints для внешних потребителей.
 *
 * Все методы:
 *   1. Через ApiAuth::require('<scope>') проверяют ключ
 *   2. Возвращают JSON через ApiAuth::ok() или ApiAuth::abort()
 *   3. НЕ требуют сессии (header-auth only)
 *
 * Конвенции:
 *   - Все списки возвращаются как {ok:true, items:[...]}
 *   - Все «выдачи credentials» как {ok:true, ...поля}
 *   - При ошибке всегда {ok:false, error:'kind', message:'...'} + HTTP 4xx
 */
class ApiV1Controller
{
    // ============== GET /api/v1/me ==============
    /** Базовая проверка ключа. Не требует никакого scope. */
    public function me(): void
    {
        $client = ApiAuth::require('');
        ApiAuth::ok([
            'client_id' => $client['id'],
            'label'     => $client['label'],
            'scopes'    => $client['scopes'],
            'panel'     => 'refresh-panel',
            'api_version' => 'v1',
        ]);
    }

    // ============== GET /api/v1/webmaster/accounts ==============
    /** Список Yandex-аккаунтов БЕЗ токенов. */
    public function webmasterAccounts(): void
    {
        ApiAuth::require('webmaster.read');
        $rows = DB::pdo()->query(
            "SELECT id, label, email, yandex_user_id, flow_type, is_default,
                    host_count, last_validated_at, last_validation_ok, note
             FROM yandex_webmaster_accounts
             ORDER BY is_default DESC, id ASC"
        )->fetchAll();

        $items = [];
        foreach ($rows as $r) {
            $items[] = [
                'id'                  => (int)$r['id'],
                'label'               => (string)$r['label'],
                'email'               => (string)$r['email'],
                'yandex_user_id'      => $r['yandex_user_id'] ? (string)$r['yandex_user_id'] : '',
                'flow_type'           => (string)$r['flow_type'],
                'is_default'          => (int)$r['is_default'] === 1,
                'host_count'          => (int)$r['host_count'],
                'last_validated_at'   => $r['last_validated_at'],
                'last_validation_ok'  => (int)$r['last_validation_ok'] === 1,
                'note'                => $r['note'],
            ];
        }
        ApiAuth::ok(['items' => $items]);
    }

    // ============== GET /api/v1/webmaster/accounts/{id}/credentials ==============
    /**
     * Расшифровывает токен и отдаёт. Для implicit flow refresh не делается
     * (токен живёт 1 год, обновляется в UI). Для code flow — было бы место
     * сделать рефреш, но в текущей БД таких аккаунтов нет.
     */
    public function webmasterCredentials(int $id): void
    {
        ApiAuth::require('webmaster.credentials');

        $st = DB::pdo()->prepare(
            "SELECT * FROM yandex_webmaster_accounts WHERE id = ?"
        );
        $st->execute([$id]);
        $r = $st->fetch();
        if (!$r) ApiAuth::abort(404, 'not_found', "Account #$id not found");

        try {
            $accessToken = Crypto::decrypt((string)$r['access_token_enc']);
        } catch (Throwable $e) {
            ApiAuth::abort(500, 'decrypt_failed', $e->getMessage());
        }

        $expiresAt = $r['token_expires_at'] ?? null;
        $secondsLeft = null;
        if ($expiresAt) {
            $ts = strtotime((string)$expiresAt);
            if ($ts !== false) $secondsLeft = max(0, $ts - time());
        }

        ApiAuth::ok([
            'account_id'      => (int)$r['id'],
            'label'           => (string)$r['label'],
            'email'           => (string)$r['email'],
            'yandex_user_id'  => (string)($r['yandex_user_id'] ?? ''),
            'access_token'    => $accessToken,
            'flow_type'       => (string)$r['flow_type'],
            'expires_at'      => $expiresAt,
            'seconds_left'    => $secondsLeft,
        ]);
    }

    // ============== POST /api/v1/webmaster/test-token?id=X ==============
    /**
     * Server-side проверка токена: refresh-panel.php дёргает Yandex.Webmaster
     * API напрямую (минуя браузер) — обходит CORS-блокировку тест-страницы.
     *
     * Возвращает { ok, yandex_user_id, http_code, raw_response } чтобы тест-UI
     * мог показать что токен реально рабочий.
     */
    public function webmasterTestToken(int $id): void
    {
        ApiAuth::require('webmaster.credentials');

        $st = DB::pdo()->prepare(
            "SELECT * FROM yandex_webmaster_accounts WHERE id = ?"
        );
        $st->execute([$id]);
        $r = $st->fetch();
        if (!$r) ApiAuth::abort(404, 'not_found', "Account #$id not found");

        try {
            $accessToken = Crypto::decrypt((string)$r['access_token_enc']);
        } catch (Throwable $e) {
            ApiAuth::abort(500, 'decrypt_failed', $e->getMessage());
        }

        // PATCH 047 §46: тестируем сохранённый аккаунт через ЕДИНЫЙ transport + resolver
        // (жёсткая привязка исходящего IP). Никакого raw cURL/fallback.
        try {
            $resolved = (new WebmasterOutboundIpResolver())->resolveForAccount((int)$r['id']);
        } catch (WebmasterTransportException $e) {
            ApiAuth::ok([
                'token_valid'         => false,
                'ok'                  => false,
                'outbound_ip_source'  => null,
                'outbound_ip_expected'=> null,
                'outbound_ip_actual'  => null,
                'source_ip_verified'  => false,
                'error'               => $e->getMessage(),
                'account_id'          => (int)$r['id'],
                'account_email'       => (string)$r['email'],
            ]);
            return;
        }
        $expectedIp = $resolved['ip_address'];

        $httpCode = 0; $curlErr = null; $parsed = null; $actualIp = ''; $srcVerified = false;
        try {
            $res = (new YandexWebmasterHttpTransport())->request(
                'GET', '/v4/user', $accessToken, $expectedIp, [], null,
                ['webmaster_account_id' => (int)$r['id'], 'refresh_job_id' => null, 'stage' => 'api_test_token']
            );
            $httpCode = (int)$res['http_code'];
            $actualIp = (string)$res['actual_local_ip'];
            $srcVerified = (bool)$res['source_ip_verified'];
            $parsed = json_decode((string)$res['body'], true);
        } catch (WebmasterTransportException $e) {
            $rr = $e->getResult();
            $httpCode = (int)($rr['http_code'] ?? 0);
            $actualIp = (string)($rr['actual_local_ip'] ?? '');
            $srcVerified = (bool)($rr['source_ip_verified'] ?? false);
            $curlErr = $e->getReason() . ': ' . $e->getMessage();
        }

        $isOk = ($httpCode === 200 && is_array($parsed) && !empty($parsed['user_id']) && $srcVerified);

        if ($isOk) {
            try {
                DB::pdo()->prepare(
                    "UPDATE yandex_webmaster_accounts
                     SET last_validated_at = CURRENT_TIMESTAMP, last_validation_ok = 1,
                         last_outbound_ip_expected = ?, last_outbound_ip_actual = ?,
                         last_outbound_verified_at = CURRENT_TIMESTAMP, last_outbound_ok = 1, last_outbound_error = NULL
                     WHERE id = ?"
                )->execute([$expectedIp, $actualIp, (int)$r['id']]);
            } catch (Throwable $e) { /* ignore */ }
        }

        ApiAuth::ok([
            'ok'                   => $isOk,
            'token_valid'          => $isOk,
            'http_code'            => $httpCode,
            'curl_error'           => $curlErr,
            'outbound_ip_source'   => $resolved['source'],
            'outbound_ip_expected' => $expectedIp,
            'outbound_ip_actual'   => $actualIp !== '' ? $actualIp : null,
            'source_ip_verified'   => $srcVerified,
            'yandex_user_id'       => is_array($parsed) ? ($parsed['user_id'] ?? null) : null,
            'response'             => is_array($parsed) ? $parsed : ['raw' => ''],
            'account_id'           => (int)$r['id'],
            'account_email'        => (string)$r['email'],
        ]);
    }

    // ============== GET /api/v1/registrar/accounts ==============
    /** Список Namecheap-аккаунтов БЕЗ api_key. */
    public function registrarAccounts(): void
    {
        ApiAuth::require('registrar.read');
        $rows = DB::pdo()->query(
            "SELECT id, provider, is_sandbox, api_user, username, client_ip, is_default, created_at
             FROM registrar_accounts
             ORDER BY is_default DESC, id ASC"
        )->fetchAll();

        $items = [];
        foreach ($rows as $r) {
            $items[] = [
                'id'         => (int)$r['id'],
                'provider'   => (string)$r['provider'],
                'is_sandbox' => (int)$r['is_sandbox'] === 1,
                'api_user'   => (string)$r['api_user'],
                'username'   => (string)$r['username'],
                'client_ip'  => (string)$r['client_ip'],
                'is_default' => (int)$r['is_default'] === 1,
                'created_at' => $r['created_at'],
            ];
        }
        ApiAuth::ok(['items' => $items]);
    }

    // ============== GET /api/v1/registrar/accounts/{id}/credentials ==============
    public function registrarCredentials(int $id): void
    {
        ApiAuth::require('registrar.credentials');

        $st = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id = ?");
        $st->execute([$id]);
        $r = $st->fetch();
        if (!$r) ApiAuth::abort(404, 'not_found', "Registrar account #$id not found");

        try {
            $apiKey = Crypto::decrypt((string)$r['api_key_enc']);
        } catch (Throwable $e) {
            ApiAuth::abort(500, 'decrypt_failed', $e->getMessage());
        }

        ApiAuth::ok([
            'account_id' => (int)$r['id'],
            'provider'   => (string)$r['provider'],
            'is_sandbox' => (int)$r['is_sandbox'] === 1,
            'endpoint'   => (int)$r['is_sandbox'] === 1
                ? 'https://api.sandbox.namecheap.com/xml.response'
                : 'https://api.namecheap.com/xml.response',
            'api_user'   => (string)$r['api_user'],
            'api_key'    => $apiKey,
            'username'   => (string)$r['username'],
            'client_ip'  => (string)$r['client_ip'],
        ]);
    }

    // ============== GET /api/v1/registrar/contacts ==============
    /** Контакты для WHOIS — всё открыто (как в БД, без шифрования). */
    public function registrarContacts(): void
    {
        ApiAuth::require('registrar.read');
        $rows = DB::pdo()->query(
            "SELECT * FROM registrar_contacts ORDER BY id ASC"
        )->fetchAll();

        $items = [];
        foreach ($rows as $r) {
            $items[] = [
                'id'             => (int)$r['id'],
                'label'          => (string)$r['label'],
                'env'            => (string)$r['env'],
                'first_name'     => (string)$r['first_name'],
                'last_name'      => (string)$r['last_name'],
                'organization'   => (string)$r['organization'],
                'address1'       => (string)$r['address1'],
                'address2'       => (string)$r['address2'],
                'city'           => (string)$r['city'],
                'state_province' => (string)$r['state_province'],
                'postal_code'    => (string)$r['postal_code'],
                'country'        => (string)$r['country'],
                'phone'          => (string)$r['phone'],
                'email'          => (string)$r['email'],
            ];
        }
        ApiAuth::ok(['items' => $items]);
    }

    // ============== GET /api/v1/fastpanel/servers ==============
    public function fastpanelServers(): void
    {
        ApiAuth::require('fastpanel.read');
        $rows = DB::pdo()->query(
            "SELECT id, title, host, username, extra_ips, verify_tls, created_at
             FROM fastpanel_servers ORDER BY id ASC"
        )->fetchAll();

        $items = [];
        foreach ($rows as $r) {
            $items[] = [
                'id'         => (int)$r['id'],
                'title'      => (string)$r['title'],
                'host'       => (string)$r['host'],
                'username'   => (string)$r['username'],
                'extra_ips'  => (string)($r['extra_ips'] ?? ''),
                'verify_tls' => (int)$r['verify_tls'] === 1,
                'created_at' => $r['created_at'],
            ];
        }
        ApiAuth::ok(['items' => $items]);
    }

    // ============== POST /api/v1/fastpanel/servers/{id}/jwt ==============
    /**
     * Логинится на FP и отдаёт свежий JWT. Casino-panel использует его
     * для прямых вызовов FastPanel API (jobs, sites, и т.п.).
     */
    public function fastpanelJwt(int $id): void
    {
        ApiAuth::require('fastpanel.jwt');

        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id = ?");
        $st->execute([$id]);
        $r = $st->fetch();
        if (!$r) ApiAuth::abort(404, 'not_found', "FastPanel server #$id not found");

        try {
            $password = Crypto::decrypt((string)$r['password_enc']);
        } catch (Throwable $e) {
            ApiAuth::abort(500, 'decrypt_failed', $e->getMessage());
        }

        try {
            $client = new FastpanelClient(
                (string)$r['host'],
                (int)$r['verify_tls'] === 1,
                20
            );
            $client->login((string)$r['username'], $password);

            // FastpanelClient хранит токен в private $this->token — достаём через me() proxy.
            // Но проще — экспортируем токен через reflection или просто перевыполним login руками.
            $ref = new ReflectionClass($client);
            $prop = $ref->getProperty('token');
            $prop->setAccessible(true);
            $token = (string)$prop->getValue($client);
            if ($token === '') {
                ApiAuth::abort(500, 'no_token', 'FP login returned empty token');
            }
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'fp_login_failed', $e->getMessage());
        }

        // FP JWT обычно живёт 3600 сек; считаем 50 минут «безопасным» сроком
        ApiAuth::ok([
            'server_id'    => (int)$r['id'],
            'host'         => (string)$r['host'],
            'jwt'          => $token,
            'expires_in'   => 3000,
            'issued_at'    => time(),
        ]);
    }

    // ============== GET /api/v1/fastpanel/find-vhost?server_id=X&host=Y ==============
    /**
     * Найти FastPanel vhost по доменному имени.
     * Возвращает {exact_match: {fp_site_id, server_name, owner}, suggestions: [...]}
     *
     * Используется casino-panel'ю для авто-определения FP-site-id текущего проекта
     * (чтобы пользователь не лазал в URL FastPanel'и).
     */
    public function fastpanelFindVhost(): void
    {
        ApiAuth::require('fastpanel.read');

        $serverId = (int)($_GET['server_id'] ?? 0);
        $host = strtolower(trim((string)($_GET['host'] ?? '')));
        if ($serverId <= 0 || $host === '') {
            ApiAuth::abort(400, 'bad_request', 'server_id and host query params required');
        }

        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id = ?");
        $st->execute([$serverId]);
        $srv = $st->fetch();
        if (!$srv) ApiAuth::abort(404, 'not_found', "FastPanel server #$serverId not found");

        try {
            $password = Crypto::decrypt((string)$srv['password_enc']);
            $client = new FastpanelClient((string)$srv['host'], (int)$srv['verify_tls'] === 1, 20);
            $client->login((string)$srv['username'], $password);
            $list = $client->simpleSites();
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'fp_api_failed', $e->getMessage());
        }

        if (!is_array($list)) {
            ApiAuth::abort(502, 'fp_bad_response', 'simpleSites returned non-array');
        }

        $exactMatch = null;
        $suggestions = [];

        // Нормализованный target — убираем www. на всякий
        $target = preg_replace('~^www\.~i', '', $host);

        foreach ($list as $s) {
            if (!is_array($s)) continue;
            $id = (int)($s['id'] ?? 0);
            $serverName = strtolower((string)($s['server_name'] ?? $s['domain'] ?? ''));
            if ($id <= 0 || $serverName === '') continue;

            $owner = '';
            if (isset($s['owner']) && is_array($s['owner'])) {
                $owner = (string)($s['owner']['username'] ?? '');
            } elseif (isset($s['owner_name'])) {
                $owner = (string)$s['owner_name'];
            }

            $row = [
                'fp_site_id'  => $id,
                'server_name' => $serverName,
                'owner'       => $owner,
            ];

            // Точное совпадение
            $normalizedServerName = preg_replace('~^www\.~i', '', $serverName);
            if ($normalizedServerName === $target) {
                $exactMatch = $row;
                continue;
            }

            // Близкие — domain.com vs sub.domain.com и т.п.
            if (stripos($serverName, $target) !== false || stripos($target, $serverName) !== false) {
                $suggestions[] = $row;
            }
        }

        // Ограничим suggestions топ-10
        $suggestions = array_slice($suggestions, 0, 10);

        ApiAuth::ok([
            'host'        => $host,
            'server_id'   => $serverId,
            'exact_match' => $exactMatch,
            'suggestions' => $suggestions,
            'total_sites' => count($list),
        ]);
    }


    /**
     * Резолвит IP сайта в FastPanel: ?fp_server=X&fp_site=Y
     * Использует FastpanelClient.site() и берёт ips[0].ip.
     */
    public function serverSiteIp(): void
    {
        ApiAuth::require('server.resolve');

        $fpServer = (int)($_GET['fp_server'] ?? 0);
        $fpSite   = (int)($_GET['fp_site']   ?? 0);
        if ($fpServer <= 0 || $fpSite <= 0) {
            ApiAuth::abort(400, 'bad_request', 'fp_server and fp_site query params required');
        }

        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id = ?");
        $st->execute([$fpServer]);
        $r = $st->fetch();
        if (!$r) ApiAuth::abort(404, 'not_found', "FastPanel server #$fpServer not found");

        try {
            $password = Crypto::decrypt((string)$r['password_enc']);
            $client = new FastpanelClient(
                (string)$r['host'],
                (int)$r['verify_tls'] === 1,
                20
            );
            $client->login((string)$r['username'], $password);
            $site = $client->site($fpSite);
        } catch (Throwable $e) {
            ApiAuth::abort(502, 'fp_api_failed', $e->getMessage());
        }

        $ip = '';
        if (!empty($site['ips']) && is_array($site['ips'])) {
            foreach ($site['ips'] as $ipRow) {
                if (!empty($ipRow['ip']) && filter_var($ipRow['ip'], FILTER_VALIDATE_IP)) {
                    $ip = (string)$ipRow['ip'];
                    break;
                }
            }
        }
        if ($ip === '') {
            ApiAuth::abort(404, 'no_ip', 'No IP found in site response');
        }

        ApiAuth::ok([
            'fp_server' => $fpServer,
            'fp_site'   => $fpSite,
            'ip'        => $ip,
            'server_name' => (string)($site['server_name'] ?? ''),
        ]);
    }

    // ============== GET /api/v1/app-settings/domain ==============
    /** Публичные настройки покупки доменов (max_price и т.п.) */
    public function appSettingsDomain(): void
    {
        ApiAuth::require('appsettings.read');

        $publicKeys = [
            'domain.candidates_per_tick'  => ['default' => 30,  'type' => 'int'],
            'domain.candidates_max_total' => ['default' => 200, 'type' => 'int'],
            'domain.max_price_usd'        => ['default' => 15,  'type' => 'float'],
            'domain.years'                => ['default' => 1,   'type' => 'int'],
        ];
        $out = [];
        foreach ($publicKeys as $key => $cfg) {
            $val = $cfg['default'];
            try {
                if (class_exists('AppSettings')) {
                    if ($cfg['type'] === 'int')   $val = AppSettings::getInt($key, (int)$cfg['default']);
                    elseif ($cfg['type'] === 'float') $val = AppSettings::getFloat($key, (float)$cfg['default']);
                }
            } catch (Throwable $e) {
                // fall back to default
            }
            $out[$key] = $val;
        }
        ApiAuth::ok(['settings' => $out]);
    }
}
