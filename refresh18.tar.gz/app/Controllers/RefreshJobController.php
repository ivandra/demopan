<?php

/**
 * Контроллер refresh-джоб (перевыставления доменов).
 *
 * Маршруты:
 *   GET  /jobs              → index() — список всех джоб
 *   POST /jobs/start        → start() — создать джобу для site_id
 *   GET  /jobs/show?id=N    → show()  — карточка джобы (live прогресс, auto-refresh)
 *   POST /jobs/cancel       → cancel() — отменить активную джобу (поставить failed)
 *   POST /jobs/retry        → retry()  — повторить failed-стадию
 *   POST /jobs/run-step     → runStep() — ручной "пинок" обработчика (для отладки)
 */
class RefreshJobController extends Controller
{
    /**
     * Список джоб.
     */
    public function index(): void
    {
        $this->requireAuth();
        $filter = (string)($_GET['filter'] ?? 'all');

        $where = '';
        $params = [];
        $conds = [];
        if ($filter === 'active') {
            $conds[] = "j.stage NOT IN ('done','failed','cancelled','superseded')";
        } elseif ($filter === 'done') {
            $conds[] = "j.stage = 'done'";
        } elseif ($filter === 'failed') {
            $conds[] = "j.stage = 'failed'";
        } elseif ($filter === 'awaiting') {
            // v23: джобы, ожидающие действия оператора. Пока джоба в этом статусе,
            // для её сайта нельзя создать новую — логику блокировки не меняем,
            // но такие джобы должно быть видно.
            $conds[] = "j.stage_status = 'awaiting_user'
                        AND j.stage NOT IN ('done','failed','cancelled','superseded')";
        } elseif ($filter === 'scheduled') {
            // v18-fix: специальный фильтр — только запланированные на будущее
            $conds[] = "j.stage = 'queued'
                        AND j.stage_status = 'pending'
                        AND j.next_run_at IS NOT NULL
                        AND j.next_run_at > NOW()";
        }
        // ТЗ 040 §9.5: фильтр по серверу (через сайт джобы).
        $serverFilter = (int)($_GET['server_id'] ?? 0);
        if ($serverFilter > 0) {
            $conds[] = "s.fastpanel_server_id = ?";
            $params[] = $serverFilter;
        }
        if ($conds) $where = "WHERE " . implode(' AND ', $conds);

        // ТЗ 040 §9.6: JOIN серверных полей (badge наследуется через сайт).
        $sql = "SELECT j.*, s.current_domain, s.fastpanel_server_id AS site_server_id,
                       fps.id AS server_id, fps.title AS server_title,
                       fps.ui_badge_code, fps.ui_badge_label, fps.ui_badge_color
                FROM refresh_jobs j
                LEFT JOIN sites_managed s ON s.id = j.site_id
                LEFT JOIN fastpanel_servers fps ON fps.id = s.fastpanel_server_id
                {$where}
                ORDER BY j.id DESC
                LIMIT 200";
        $st = DB::pdo()->prepare($sql);
        $st->execute($params);
        $jobs = $st->fetchAll();

        // v23 / §3.4: счётчик ожидающих действий с учётом серверного фильтра.
        // Семантика awaiting_user НЕ меняется — только добавляется фильтр по серверу.
        if ($serverFilter > 0) {
            try {
                $awStmt = DB::pdo()->prepare(
                    "SELECT COUNT(*) FROM refresh_jobs j
                       JOIN sites_managed s ON s.id = j.site_id
                      WHERE j.stage_status = 'awaiting_user'
                        AND j.stage NOT IN ('done','failed','cancelled','superseded')
                        AND s.fastpanel_server_id = ?"
                );
                $awStmt->execute([$serverFilter]);
                $awaitingCount = (int)$awStmt->fetchColumn();
            } catch (\Throwable $e) { $awaitingCount = 0; }
        } else {
            $awaitingCount = AwaitingActionService::countAwaiting();
        }
        $awaitingInfo = [];
        foreach ($jobs as $j) {
            if ((string)($j['stage_status'] ?? '') === 'awaiting_user'
                && !in_array((string)$j['stage'], ['done','failed'], true)) {
                $d = AwaitingActionService::describeExpectedAction(
                    (string)$j['stage'], (string)($j['stage_error'] ?? '')
                );
                $waited = strtotime((string)($j['updated_at'] ?? '')) ?: time();
                $awaitingInfo[(int)$j['id']] = [
                    'action'  => $d['action'],
                    'hint'    => $d['hint'],
                    'waiting' => AwaitingActionService::humanDuration(time() - $waited),
                ];
            }
        }

        // v18-fix / §3.4: scheduled-блок вверху — JOIN серверных полей (badge)
        // и тот же серверный фильтр, что и основной список.
        $scheduledJobs = [];
        try {
            $schedWhere = '';
            $schedParams = [];
            if ($serverFilter > 0) { $schedWhere = " AND s.fastpanel_server_id = ?"; $schedParams[] = $serverFilter; }
            $stSched = DB::pdo()->prepare(
                "SELECT j.*, s.current_domain, s.fastpanel_server_id AS site_server_id,
                        fps.id AS server_id, fps.title AS server_title,
                        fps.ui_badge_code, fps.ui_badge_label, fps.ui_badge_color
                 FROM refresh_jobs j
                 LEFT JOIN sites_managed s ON s.id = j.site_id
                 LEFT JOIN fastpanel_servers fps ON fps.id = s.fastpanel_server_id
                 WHERE j.stage = 'queued'
                   AND j.stage_status = 'pending'
                   AND j.next_run_at IS NOT NULL
                   AND j.next_run_at > NOW()
                   {$schedWhere}
                 ORDER BY j.next_run_at ASC
                 LIMIT 50"
            );
            $stSched->execute($schedParams);
            $scheduledJobs = $stSched->fetchAll();
        } catch (\Throwable $e) {
            // не критично, пустой массив
        }

        $this->view('jobs/index', [
            'jobs' => $jobs,
            'filter' => $filter,
            'scheduledJobs' => $scheduledJobs,
                    'awaitingCount' => $awaitingCount,
            'awaitingInfo' => $awaitingInfo,
            'servers' => ServerBadgePresenter::serversForFilter(),
            'serverFilter' => $serverFilter,
        ]);
    }

    /**
     * Создать джобу для перевыставления данного сайта.
     */
    /**
     * PATCH 048 §16/§21: единая точка precedence для snapshot Webmaster-аккаунта джобы.
     * job override (явный выбор оператора) → site binding (постоянная привязка) → auto (NULL).
     * Оба override и binding превращаются в refresh_jobs.webmaster_account_override_id.
     * @return array{account_id: ?int, source: string}
     */
    protected function resolveWebmasterSnapshot(?int $postOverride, int $siteBinding): array
    {
        if ($postOverride !== null && $postOverride > 0) {
            return ['account_id' => $postOverride, 'source' => 'job_override'];
        }
        if ($siteBinding > 0) {
            return ['account_id' => $siteBinding, 'source' => 'site_binding'];
        }
        return ['account_id' => null, 'source' => 'auto'];
    }

    public function start(): void
    {
        $this->requireAuth();
        $siteId = (int)($_POST['site_id'] ?? 0);

        // Загружаем сайт
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$siteId]);
        $site = $st->fetch();
        if (!$site) {
            $this->flash('error', 'Сайт не найден');
            $this->redirect('/sites');
        }

        // Проверка что у сайта есть всё нужное
        if (empty($site['current_domain'])) {
            $this->flash('error', 'У сайта не задан current_domain');
            $this->redirect('/sites/show?id=' . $siteId);
        }

        // v24.2 (B1): ВСЕ параметры запуска разбираются и валидируются ДО
        // проверки конфликта. Раньше $mode использовался в redirect'е на
        // экран конфликта раньше своего вычисления: PHP писал notice,
        // параметр в URL был пуст, select выбирал первый вариант 'refresh',
        // и «Закрыть старую и создать новую» игнорировала выбор оператора.

        // v17: Опциональный override Webmaster-аккаунта
        $wmOverride = (int)($_POST['webmaster_account_override_id'] ?? 0);
        if ($wmOverride < 1) $wmOverride = null;

        // PATCH 048 §16/§21: фиксируем target Webmaster в момент создания джобы.
        // Precedence: 1) явный выбор оператора в launch-form (job override);
        //             2) постоянная привязка сайта (sites_managed.webmaster_account_id);
        //             3) Auto (NULL) — текущий resolve по старому домену.
        // Оба «1» и «2» превращаются в refresh_jobs.webmaster_account_override_id, чтобы
        // не переписывать существующий Webmaster-pipeline. Snapshot immutable (§17).
        $siteBinding = (isset($site['webmaster_account_id']) && $site['webmaster_account_id'] !== null)
            ? (int)$site['webmaster_account_id'] : 0;
        $wmSnap = $this->resolveWebmasterSnapshot($wmOverride, $siteBinding);
        $wmOverride = $wmSnap['account_id'];
        $wmSource = $wmSnap['source'];

        // v18: режим джобы — refresh / move_indexed / move_simple
        $modeRaw = (string)($_POST['mode'] ?? 'refresh');
        $mode = in_array($modeRaw, JobLifecycleService::ALLOWED_MODES, true)
            ? $modeRaw : 'refresh';

        // v18-fix: опциональный отложенный старт (время в Europe/Moscow).
        // v24.2: разбор вынесен в parseScheduleAt() — тот же код использует
        // /jobs/supersede, чтобы отложенный старт переживал экран конфликта.
        $scheduleAtRaw = trim((string)($_POST['schedule_at'] ?? ''));
        $sched = $this->parseScheduleAt($scheduleAtRaw);
        if ($sched['error'] !== null) {
            $this->flash('error', $sched['error']);
            $this->redirect('/sites/show?id=' . $siteId);
        }
        $scheduleAt = $sched['ts'];                    // unix ts либо null
        $scheduleAtForSql = $sched['sql'];             // DATETIME либо null
        $scheduleAtMskDisplay = $sched['display'];     // "ГГГГ-ММ-ДД ЧЧ:ММ МСК" либо null

        // Проверим, нет ли уже активной джобы для этого сайта
        $existing = DB::pdo()->prepare(
            "SELECT id FROM refresh_jobs
             WHERE site_id = ? AND stage NOT IN ('done','failed','cancelled','superseded')
             LIMIT 1"
        );
        $existing->execute([$siteId]);
        $activeId = (int)$existing->fetchColumn();
        if ($activeId > 0) {
            // v24: вместо общего отказа показываем экран конфликта с действиями.
            // Для awaiting_user там доступна замена, для работающей — только отказ.
            // v24.2 (H1): исходные параметры запуска (режим, WM override,
            // отложенный старт) проносятся на экран конфликта и дальше в
            // /jobs/supersede — оператор видит и подтверждает именно их.
            $this->redirect('/jobs/conflict?site_id=' . $siteId . '&job_id=' . $activeId
                . '&mode=' . urlencode($mode)
                . ($wmOverride !== null ? '&wm_override=' . (int)$wmOverride : '')
                . ($scheduleAtRaw !== '' ? '&schedule_at=' . urlencode($scheduleAtRaw) : ''));
        }

        // Извлекаем sub_id из конфига сайта (если есть)
        $oldSubId = '';
        $newSubId = '';
        $config = [];
        if (!empty($site['config_parsed_json'])) {
            $config = json_decode((string)$site['config_parsed_json'], true) ?: [];
        }
        if (!empty($config)) {
            // v21: маска с персональными настройками сайта (mask_settings_json)
            $mask = DomainMaskService::forSite($site);
            // sub_id ищем во всех полях конфига: у части сайтов internal_reg_url пустой,
            // а sub_id лежит в base_new_url / base_second_url.
            $subInfo  = $mask->extractSubIdFromConfig($config);
            $oldSubId = (string)$subInfo['sub_id'];
            if ($oldSubId !== '') {
                // Новый домен на этом этапе ещё НЕ известен (покупается позже),
                // поэтому здесь только предварительное значение — автономный инкремент.
                // Авторитетный sub_id пересчитывается из купленного домена
                // в DomainPurchaseService (v21: sync_with_domain).
                $newSubId = $mask->nextSubId($oldSubId);
            }
        }

        // Создаём запись джобы
        $oldDomain = (string)$site['current_domain'];
        // Параметры $mode / $wmOverride / $scheduleAt* разобраны выше,
        // до проверки конфликта (v24.2/B1).

        $ins = DB::pdo()->prepare(
            "INSERT INTO refresh_jobs
             (site_id, old_domain, new_domain, old_sub_id, new_sub_id,
              webmaster_account_override_id, mode,
              stage, stage_status, next_run_at, artifacts_json, created_at,
              pipeline_revision, trusted_ssl_gate_required)
             VALUES (?, ?, '', ?, ?, ?, ?, 'queued', 'pending', ?, ?, NOW(),
                     'ssl_before_webmaster_v1', 1)"
        );

        // v4 (B1, B5): фиксируем ЭФФЕКТИВНЫЕ параметры маски на всю джобу.
        // Без этого разные стадии читали настройки заново: покупка вообще работала
        // на глобальных (игнорируя персональные настройки сайта), а изменение
        // настроек оператором во время очереди приводило к тому, что одна джоба
        // проходила стадии с разными стратегиями.
        $maskSnapshot = [];
        try {
            $maskSnapshot = DomainMaskService::forSite($site)->snapshotPayload();
        } catch (\Throwable $e) {
            $maskSnapshot = [];
        }
        $artifactsInit = json_encode(
            [
                'mask_options_snapshot' => $maskSnapshot,
                // PATCH 048 §20: понятный снапшот выбранного target-аккаунта + источник выбора.
                'webmaster_target_snapshot' => [
                    'account_id' => $wmOverride,          // null = auto
                    'source' => $wmSource,                // job_override | site_binding | auto
                    'site_binding_account_id' => ($siteBinding > 0 ? $siteBinding : null),
                ],
            ],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        $ins->execute([
            $siteId, $oldDomain, $oldSubId, $newSubId, $wmOverride, $mode,
            $scheduleAtForSql, // NULL → сразу, иначе указанное время
            $artifactsInit,
        ]);
        $jobId = (int)DB::pdo()->lastInsertId();

        // §7: eligibility ban-monitoring присваивается в общем пути создания джобы.
        // При enrollment ON — текущая generation; иначе NULL (джоба не поставит monitor).
        try { (new BanMonitoringSettingsRepository())->assignEligibility($jobId); }
        catch (\Throwable $e) { error_log('[ban-monitor eligibility] ' . $e->getMessage()); }

        // v22: учёт переезда. Только move_indexed / move_simple — режим refresh
        // это перевыставление, а не переезд, и в раздел не попадает.
        // Новый домен на этом этапе ещё не куплен, поэтому snapshot_json будет
        // дописан после его фиксации (DomainPurchaseService).
        if (in_array($mode, RelocationService::MOVE_MODES, true)) {
            try {
                RelocationService::createForJob($jobId, RelocationService::currentUser());
            } catch (\Throwable $e) {
                // H9: учёт не должен мешать запуску джобы, но и исчезать молча
                // не имеет права — иначе move-джоба уйдёт в работу без записи
                // в разделе, и причину никто не найдёт.
                error_log("RelocationService::createForJob job={$jobId} failed: " . $e->getMessage());
                $this->flash('warning',
                    'Джоба создана, но запись в разделе «Переезды» не появилась: ' . $e->getMessage()
                    . '. Проверьте, применена ли миграция 023.');
            }
        }

        // Стартовое событие в лог
        $log = new JobEventLogger($jobId);
        $modeRu = [
            'refresh'      => 'перевыставление',
            'move_indexed' => 'переезд (с индексацией)',
            'move_simple'  => 'переезд (без индексации)',
        ][$mode] ?? $mode;
        $msg = "Джоба создана. Режим: {$modeRu}. Старый домен: {$oldDomain}";
        if ($oldSubId !== '') $msg .= ", старый sub_id: {$oldSubId} → новый: {$newSubId}";
        if ($wmOverride !== null) {
            $msg .= ". Webmaster override account #{$wmOverride}";
        }
        if ($scheduleAt !== null) {
            $msg .= ". ⏰ Запланирован старт на {$scheduleAtMskDisplay} (через "
                  . $this->formatRelativeTime($scheduleAt - time()) . ")";
        }
        $log->info('queued', $msg);

        $flashMsg = "Джоба #{$jobId} ({$modeRu}) создана. ";
        if ($scheduleAt !== null) {
            $flashMsg .= "⏰ Старт запланирован на {$scheduleAtMskDisplay} "
                       . "(через " . $this->formatRelativeTime($scheduleAt - time()) . ")";
        } else {
            $flashMsg .= "Cron возьмёт её в обработку в течение минуты.";
        }
        $this->flash('success', $flashMsg);
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v24.2 (B1/H1): разбор поля «отложенный старт» (datetime-local, МСК).
     *
     * Единая точка для /jobs/start и /jobs/supersede — правила одинаковые:
     *  - пустая строка → старт сразу (все значения null);
     *  - <2 минут до сейчас → старт сразу;
     *  - >30 дней вперёд → ошибка;
     *  - нечитаемый формат → ошибка.
     *
     * @return array{ts:?int, sql:?string, display:?string, error:?string}
     */
    private function parseScheduleAt(string $raw): array
    {
        $out = ['ts' => null, 'sql' => null, 'display' => null, 'error' => null];
        $raw = trim($raw);
        if ($raw === '') return $out;

        try {
            $tzMsk = new \DateTimeZone('Europe/Moscow');
            // v24.3 (H4): строгий разбор. DateTimeImmutable('2026-08-32')
            // молча нормализовал несуществующую дату в 1 сентября — оператор
            // получал не то время, которое ввёл. createFromFormat +
            // getLastErrors отвергает и мусор, и «перелив» дат.
            $normalized = str_replace('T', ' ', $raw); // datetime-local: T или пробел
            $dt = false;
            foreach (['Y-m-d H:i:s', 'Y-m-d H:i'] as $fmt) {
                $cand = \DateTimeImmutable::createFromFormat('!' . $fmt, $normalized, $tzMsk);
                $errs = \DateTimeImmutable::getLastErrors();
                $bad = is_array($errs)
                    && (($errs['warning_count'] ?? 0) > 0 || ($errs['error_count'] ?? 0) > 0);
                if ($cand !== false && !$bad) { $dt = $cand; break; }
            }
            if ($dt === false) {
                $out['error'] = "Не понял формат времени: '{$raw}'. Ожидается ГГГГ-ММ-ДД ЧЧ:ММ (существующая дата)";
                return $out;
            }
            $ts = $dt->getTimestamp();
            $display = $dt->format('Y-m-d H:i') . ' МСК';
        } catch (\Throwable $e) {
            $out['error'] = "Не понял формат времени: '{$raw}'. Ожидается ГГГГ-ММ-ДД ЧЧ:ММ";
            return $out;
        }

        // <2 минут до сейчас — стартуем сразу, откладывать нет смысла
        if ($ts <= time() + 120) return $out;

        if ($ts > time() + (30 * 86400)) {
            $out['error'] = 'Дата старта слишком далеко в будущем (максимум 30 дней)';
            return $out;
        }

        $out['ts'] = $ts;
        // В БД пишем DATETIME в серверном TZ — cron-picker сравнивает с NOW().
        $out['sql'] = date('Y-m-d H:i:s', $ts);
        $out['display'] = $display;
        return $out;
    }

    /**
     * v18-fix: форматирует разницу в секундах в человеко-читаемое "через X".
     */
    private function formatRelativeTime(int $secondsUntil): string
    {
        if ($secondsUntil < 60)  return "{$secondsUntil} сек";
        if ($secondsUntil < 3600) {
            $m = (int)round($secondsUntil / 60);
            return "{$m} мин";
        }
        if ($secondsUntil < 86400) {
            $h = round($secondsUntil / 3600, 1);
            return "{$h} ч";
        }
        $d = round($secondsUntil / 86400, 1);
        return "{$d} дн";
    }

    /**
     * v18-fix: форматирует серверный DATETIME в "ГГГГ-ММ-ДД ЧЧ:ММ МСК".
     * Используется для логов и UI чтобы оператор всегда видел МСК.
     */
    private function formatServerTimeAsMsk(string $serverDatetime): string
    {
        if ($serverDatetime === '' || $serverDatetime === '0000-00-00 00:00:00') return '?';
        try {
            // DateTime интерпретирует строку в default TZ (серверном),
            // потом конвертируем в МСК для отображения
            $dt = new \DateTime($serverDatetime);
            $dt->setTimezone(new \DateTimeZone('Europe/Moscow'));
            return $dt->format('Y-m-d H:i') . ' МСК';
        } catch (\Throwable $e) {
            return $serverDatetime; // fallback
        }
    }

    /**
     * Карточка джобы — live прогресс с auto-refresh.
     */
    public function show(): void
    {
        $this->requireAuth();
        $jobId = (int)($_GET['id'] ?? 0);
        $job = $this->loadJob($jobId);

        // ТЗ 040 §9.4/§9.6: данные бейджа сервера готовит контроллер (не View).
        $serverBadge = null;
        if (!empty($job['site_id'])) {
            $sbSt = DB::pdo()->prepare(
                "SELECT fps.ui_badge_code, fps.ui_badge_label, fps.ui_badge_color, fps.title AS server_title
                   FROM sites_managed s
                   LEFT JOIN fastpanel_servers fps ON fps.id = s.fastpanel_server_id
                  WHERE s.id = ?"
            );
            $sbSt->execute([(int)$job['site_id']]);
            $sbRow = $sbSt->fetch();
            if ($sbRow) $serverBadge = (new ServerBadgePresenter())->fromRow($sbRow);
        }

        // Сайт
        $stSite = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $stSite->execute([(int)$job['site_id']]);
        $site = $stSite->fetch();

        // Список событий
        $stEv = DB::pdo()->prepare(
            "SELECT * FROM refresh_job_events WHERE job_id=? ORDER BY id DESC LIMIT 200"
        );
        $stEv->execute([$jobId]);
        $events = $stEv->fetchAll();

        // Прогресс — индекс текущей стадии в pipeline КОНКРЕТНОГО режима
        // v18: вместо STAGES_ORDER (который содержит ВСЕ стадии всех режимов)
        // берём только те стадии, через которые пройдёт эта джоба
        // v18.1: учитываем ssl_le_enabled — джоба сайта где LE выключен,
        // не должна показывать стадию ssl_le_polling в прогресс-баре.
        $jobMode = (string)($job['mode'] ?? 'refresh');
        $sslLeEnabled = (bool)($site['ssl_le_enabled'] ?? 0);
        $stages = RefreshOrchestrator::pipelineStagesFor($jobMode, $sslLeEnabled);
        $currentIdx = array_search($job['stage'], $stages, true);
        if ($currentIdx === false) {
            // На всякий случай (deprecated стадия типа wm_old_removed) —
            // ищем в полном STAGES_ORDER, но в UI всё равно покажем pipeline режима
            $currentIdx = 0;
        }
        $totalStages = count($stages);
        $progressPct = $job['stage'] === 'done'
            ? 100
            : (int)floor(($currentIdx / max($totalStages - 1, 1)) * 100);

        // Auto-refresh: только если джоба активна и НЕ ждёт пользователя.
        // v17.9: при awaiting_user пользователь работает с формами/кнопками,
        // постоянное обновление мешает (теряется фокус, скрывается dropdown).
        // v24.2 (B4): закрытые (cancelled/superseded) — терминальные, карточка
        // статична и не должна перезагружаться каждые 5 секунд.
        $isInactive = JobLifecycleService::isTerminal((string)$job['stage'])
            || (string)$job['stage_status'] === 'awaiting_user';
        $autoRefresh = !$isInactive;

        // Артефакты для отладки
        $artifacts = null;
        if (!empty($job['artifacts_json'])) {
            $artifacts = json_decode((string)$job['artifacts_json'], true);
        }

        // v17.7: список Webmaster аккаунтов для UI выбора override
        $webmasterAccounts = [];
        try {
            $stAcc = DB::pdo()->query(
                "SELECT id, label, email, note, host_count
                 FROM yandex_webmaster_accounts
                 WHERE access_token_enc IS NOT NULL AND access_token_enc <> ''
                 ORDER BY is_default DESC, host_count DESC"
            );
            $webmasterAccounts = $stAcc->fetchAll();
        } catch (\Throwable $e) {
            // не критично — кнопка просто будет disabled
        }

        // v25.2-a1.5 (§наблюдаемость): статус крона на карточке джобы.
        $cronHeartbeat = [];
        try { $cronHeartbeat = (new DomainSslStatusRepository())->cronHeartbeat(); } catch (\Throwable $e) {}

        // a1.6 §8: три таймера next-check конкретной джобы.
        // Патч сводной панели §5: для терминальной джобы таймеры НЕ формируем.
        $jobTimers = [];
        if (!JobLifecycleService::isTerminal((string)$job['stage'])) {
        try {
            $now = time();
            $mkIn = function ($ts) use ($now) {
                if ($ts === null) return null;
                $t = is_numeric($ts) ? (int)$ts : strtotime((string)$ts);
                if (!$t) return null;
                $d = $t - $now;
                if ($d <= 0) return 'сейчас';
                if ($d < 60) return 'через ' . $d . ' сек';
                if ($d < 3600) return 'через ' . round($d / 60) . ' мин';
                return 'через ' . round($d / 3600, 1) . ' ч';
            };
            // Следующий запуск основного job-цикла
            if (!empty($job['next_run_at'])) {
                $jobTimers[] = ['label' => 'Следующий запуск job', 'value' => $mkIn($job['next_run_at'])];
            }
            // Следующая SSL-проверка (throttle ssl_issue_next_poll_at)
            if (!empty($job['ssl_issue_next_poll_at'])) {
                $jobTimers[] = ['label' => 'Следующая SSL-проверка', 'value' => $mkIn($job['ssl_issue_next_poll_at'])];
            }
            // Следующий Yandex poll — только пока webmaster_gate ОТКРЫТ (Яндекс
            // реально ещё опрашивается). После confirmed_at/skip/verified polling
            // не идёт — показываем, что ждём только SSL.
            $wv = $artifacts['wm_verified_stage'] ?? [];
            if (($job['stage'] ?? '') === 'wm_verified' && empty($wv['ok'])) {
                $wmGateOpen = empty($wv['confirmed_at'])
                    && empty($wv['skipped_by_operator'])
                    && !in_array((string)($wv['verification_state'] ?? ''), ['verified', 'success'], true);
                if ($wmGateOpen && !empty($wv['submitted_at'])) {
                    $jobTimers[] = ['label' => 'Следующий Yandex poll', 'value' => $mkIn($job['next_run_at'] ?? null)];
                } elseif (!$wmGateOpen) {
                    $jobTimers[] = ['label' => 'Yandex', 'value' => 'подтверждено — ожидается только SSL'];
                }
            }
        } catch (\Throwable $e) { $jobTimers = []; }
        } // /терминальная джоба — без таймеров

        // §1: фактический SSL-статус нового домена готовит контроллер (единый источник).
        $sslStatus = null;
        if (!empty($job['new_domain'])) {
            try {
                $sslStatus = (new DomainSslStatusRepository())->getByDomain((string)$job['new_domain']);
            } catch (\Throwable $e) { $sslStatus = null; }
        }

        // §12/§17: read-only данные ban-monitor + eligibility джобы.
        $banMonitor = null; $banChecks = []; $banCounts = ['today' => 0, 'total' => 0];
        $banEligible = ['eligible' => false, 'generation' => null, 'eligible_since' => null, 'enrollment_on' => false];
        try {
            $banRepo = new BanMonitorRepository();
            $banMonitor = $banRepo->getBySourceJob($jobId);
            if ($banMonitor) {
                $banChecks = $banRepo->recentChecks((int)$banMonitor['id'], 10);
                $banCounts = (new XmlStockUsageRepository())->monitorCounts((int)$banMonitor['id']);
            }
            $setRepo = new BanMonitoringSettingsRepository();
            $bset = $setRepo->get();
            $banEligible = [
                'eligible' => $setRepo->isEligible($job),
                'generation' => $job['ban_monitor_generation'] ?? null,
                'eligible_since' => $job['ban_monitor_eligible_at'] ?? null,
                'enrollment_on' => $setRepo->enrollmentEnabled(),
                // §7.2: различие «создана до активации» / «enrollment был выключен».
                'activation_min_job_id' => $bset['activation_min_job_id'] !== null ? (int)$bset['activation_min_job_id'] : null,
                'activation_started_at' => $bset['activation_started_at'] ?? null,
                'job_created_at' => $job['created_at'] ?? null,
            ];
        } catch (\Throwable $e) { /* карточка не должна ронять страницу джобы */ }

        // HOTFIX: серверное решение о доступности «Завершить джобу вручную».
        $manualPipeline = RefreshOrchestrator::pipelineStagesFor((string)($job['mode'] ?? 'refresh'), false);
        $manualCompletionEligibility = (new ManualJobCompletionEligibility())->evaluate($job, $manualPipeline);
        $manualCompletion = is_array($artifacts) ? ($artifacts['manual_completion'] ?? null) : null;

        $this->view('jobs/show', [
            'job' => $job,
            'site' => $site,
            'events' => $events,
            'stages' => $stages,
            'manualCompletionEligibility' => $manualCompletionEligibility,
            'manualCompletion' => $manualCompletion,
            'currentIdx' => $currentIdx,
            'progressPct' => $progressPct,
            'autoRefresh' => $autoRefresh,
            'artifacts' => $artifacts,
            'webmasterAccounts' => $webmasterAccounts,
            'cronHeartbeat' => $cronHeartbeat,
            'jobTimers' => $jobTimers,
            'csrfToken' => $this->csrfToken(),
            'ucVerifyPolicy' => RefreshOrchestrator::manualVerificationPolicy($job),
            'ucSkipPolicy' => RefreshOrchestrator::manualSkipPolicy($job),
            'banMonitor' => $banMonitor,
            'banChecks' => $banChecks,
            'banCounts' => $banCounts,
            'banEligible' => $banEligible,
            'serverBadge' => $serverBadge,
            'sslStatus' => $sslStatus,
        ]);
    }

    /**
     * Отменить джобу (перевести в failed).
     */
    public function cancel(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        // v24.2 (B4): requireResumable — закрытую (cancelled/superseded)
        // джобу это действие раньше ПЕРЕЗАПИСЫВАЛО в failed, уничтожая
        // семантику закрытия и связь superseded_by_job_id.
        $job = $this->loadJob($jobId, true);

        // v24.3 (B1): awaiting_user серверно запрещён для старого маршрута.
        // UI кнопку прячет, но прямой POST (старая вкладка, автоматизация)
        // позволял закрыть ожидающую джобу БЕЗ обязательной причины, без
        // closed_at/closed_by/lifecycle-события и без автоотмены переезда —
        // move-джоба в failed оставалась в платном XMLStock-поллинге.
        if ((string)$job['stage_status'] === 'awaiting_user') {
            $this->flash('error',
                'Джоба #' . $jobId . ' ожидает действия оператора. Старое действие '
                . '«Отменить» для неё запрещено: используйте «Закрыть джобу» '
                . '(/jobs/close) с обязательной причиной — оно корректно закроет '
                . 'джобу и связанный учёт переезда.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        if (JobLifecycleService::isTerminal((string)$job['stage'])) {
            $this->flash('warning', 'Джоба уже завершена ('
                . JobLifecycleService::stageLabel((string)$job['stage']) . ')');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // v24.2 (B4): SQL-guard — даже при гонке терминальную джобу не тронем.
        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage = 'failed',
                stage_status = 'failed',
                stage_error = 'Отменено пользователем',
                stage_finished_at = NOW()
             WHERE id = ?
               AND stage NOT IN (" . JobLifecycleService::terminalSqlList() . ")"
        );
        $st->execute([$jobId]);
        if ($st->rowCount() !== 1) {
            $this->flash('warning', 'Джоба уже завершена — отмена не потребовалась');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        $log = new JobEventLogger($jobId);
        $log->warn($job['stage'], 'Джоба отменена пользователем');

        $this->flash('success', 'Джоба отменена');
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v18.1.17: пометить move-джобу как успешно завершённую вручную.
     *
     * Используется когда move_poll_status не может проверить статус
     * автоматически (нет webmaster аккаунта), а оператор знает что переезд
     * фактически прошёл (или хочет завершить джобу и оставить новый домен
     * без слежения за статусом склейки).
     *
     * Разрешено ТОЛЬКО:
     *   - mode = move_indexed / move_simple (refresh-джобы завершаются автоматически)
     *   - stage = move_poll_status или move_submit_request
     *   - stage_status = awaiting_user / failed
     *
     * Действие:
     *   - stage = 'done', stage_status = 'ok'
     *   - в артефактах сохраняем флаг manual_done с timestamp
     *   - запись в event log с понятным сообщением
     */
    public function markDone(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true); // v24.2 (B4)

        $mode = (string)($job['mode'] ?? 'refresh');
        $stage = (string)$job['stage'];
        $status = (string)$job['stage_status'];

        if (!in_array($mode, ['move_indexed', 'move_simple'], true)) {
            $this->flash('error',
                'Ручное завершение доступно только для джоб в режиме переезда (move). ' .
                'Текущий режим: ' . $mode);
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // v18.1.30: добавлен final_monitoring (с v18.1.23 он заменил move_poll_status)
        $allowedStages = ['move_poll_status', 'move_submit_request', 'final_monitoring'];
        if (!in_array($stage, $allowedStages, true)) {
            $this->flash('error',
                'Ручное завершение доступно только на стадиях ' .
                'move_poll_status / move_submit_request / final_monitoring. ' .
                'Текущая стадия: ' . $stage);
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // v18.1.30: добавлены pending/ok — между tick'ами polling'а статус часто pending,
        // оператор не должен ждать чтобы завершить вручную
        $allowedStatuses = ['awaiting_user', 'failed', 'pending', 'ok'];
        if (!in_array($status, $allowedStatuses, true)) {
            $this->flash('error',
                'Ручное завершение недоступно когда стадия активно выполняется (running). ' .
                'Подожди ~30 секунд и попробуй снова. ' .
                'Текущий статус: ' . JobEventLogger::statusLabel($status));
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // v18.1.30: per-job lock — защита от race с cron-обработкой.
        // Если cron сейчас обрабатывает эту же джобу — ждать или повторить позже.
        $jobGuard = CronGuard::forJob($jobId);
        if (!$jobGuard->acquireJobLock()) {
            $this->flash('warning',
                'Джоба сейчас обрабатывается cron\'ом. ' .
                'Подожди ~30 секунд и нажми ✅ Завершить снова — ' .
                'либо просто открой джобу, возможно она уже завершилась автоматически.');
            $this->redirect('/jobs/show?id=' . $jobId);
            return;
        }

        try {
            // Перечитаем актуальное состояние — между нашим loadJob и acquireJobLock
            // могло пройти время. Если cron только что сделал step — состояние могло
            // измениться.
            $freshJob = $this->loadJob($jobId);
            $freshStage = (string)$freshJob['stage'];
            $freshStatus = (string)$freshJob['stage_status'];

            // Проверим что состояние всё ещё допустимое
            if (!in_array($freshStage, $allowedStages, true)) {
                throw new \RuntimeException(
                    "Состояние изменилось между загрузкой и подтверждением. " .
                    "Текущая стадия: {$freshStage} (была {$stage}). " .
                    "Возможно cron уже сменил стадию. Обнови страницу."
                );
            }
            if (in_array($freshStage, ['done', 'failed'], true)) {
                throw new \RuntimeException("Джоба уже завершена (stage={$freshStage}).");
            }

            // Используем актуальные значения для записи в артефакты
            $job = $freshJob;
            $stage = $freshStage;
            $status = $freshStatus;

            // Сохраняем в артефактах метку что джоба завершена руками.
            // v18.1.30: пишем в правильную секцию — зависит от стадии откуда завершают.
            $artifacts = !empty($job['artifacts_json'])
                ? (json_decode((string)$job['artifacts_json'], true) ?: [])
                : [];

            // Определяем целевую секцию артефактов
            $artifactKey = ($stage === 'final_monitoring')
                ? 'final_monitoring_stage'
                : 'move_poll_status_stage';

            $artifacts[$artifactKey] = ($artifacts[$artifactKey] ?? []) + [];
            $artifacts[$artifactKey]['manual_done'] = true;
            $artifacts[$artifactKey]['manual_done_at'] = date('Y-m-d H:i:s');
            $artifacts[$artifactKey]['manual_done_from_stage'] = $stage;
            $artifacts[$artifactKey]['manual_done_from_status'] = $status;

            // Дополнительно сохраним контекст: был ли уже индекс на момент завершения
            // (это часто причина почему оператор решил завершить вручную)
            if (!empty($artifacts['final_monitoring_stage']['last_index_pages'])) {
                $artifacts[$artifactKey]['manual_done_index_pages_at_completion'] =
                    (int)$artifacts['final_monitoring_stage']['last_index_pages'];
            }

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage = 'done',
                    stage_status = 'ok',
                    stage_error = NULL,
                    stage_finished_at = NOW(),
                    next_run_at = NULL,
                    artifacts_json = ?
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);

            $log = new JobEventLogger($jobId);
            $log->warn($stage,
                "Джоба завершена вручную оператором (статус был {$status} на стадии {$stage}). " .
                "Новый домен {$job['new_domain']} оставлен как текущий. " .
                "Автоматический мониторинг отключён.");

            // Обновляем current_domain в sites_managed на новый
            try {
                DB::pdo()->prepare(
                    "UPDATE sites_managed SET current_domain = ? WHERE id = ?"
                )->execute([$job['new_domain'], $job['site_id']]);
            } catch (\Throwable $e) {
                $log->warn($stage,
                    'Не удалось обновить current_domain: ' . $e->getMessage());
            }

            $this->flash('success',
                'Джоба завершена вручную. Новый домен ' . $job['new_domain'] . ' оставлен активным.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось завершить джобу: ' . $e->getMessage());
        } finally {
            $jobGuard->releaseJobLock();
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * PATCH_3 (§8/§9/§12): «✅ Проверить уже выполненный рандом». CSRF; lock →
     * reload fresh → re-check policy (TOCTOU); реальный HTTP 409 при недопустимом
     * состоянии (без redirect); FTP verify один раз (в сервисе).
     */
    public function verifyUniquificationManual(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $jobId = (int)($_POST['id'] ?? 0);

        // Предварительная проверка (для быстрого 409 без взятия lock).
        $job = $this->loadJob($jobId, true);
        if (!RefreshOrchestrator::manualVerificationPolicy($job)['allowed']) {
            $this->httpConflict('Действие недоступно для текущего состояния джобы.');
            return;
        }

        $jobGuard = CronGuard::forJob($jobId);
        if (!$jobGuard->acquireJobLock()) {
            $this->flash('error', 'Джоба сейчас обрабатывается (cron или ручной шаг). Подождите ~30 секунд и повторите.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        try {
            // §8 TOCTOU: перечитываем СВЕЖУЮ строку под lock и проверяем повторно.
            $fresh = $this->loadJob($jobId, true);
            if (!RefreshOrchestrator::manualVerificationPolicy($fresh)['allowed']) {
                $jobGuard->releaseJobLock();
                $this->httpConflict('Состояние джобы изменилось — действие больше недопустимо.');
                return;
            }
            $log = new JobEventLogger($jobId);
            $res = (new RefreshOrchestrator())->recoverUpdateClassesByFtp($jobId, $log);
            $outcome = (string)($res['outcome'] ?? '');
            $settle = (string)($res['settle'] ?? '');
            if ($outcome === 'verified' && in_array($settle, ['applied','already_settled'], true)) {
                $log->info('update_classes_call', 'update_classes_manual_verified: ' . ($res['details'] ?? ''));
                $this->flash('success', 'Рандом подтверждён по FTP — стадия закрыта, pipeline продолжится. ' . ($res['details'] ?? ''));
            } elseif ($outcome === 'already_settled') {
                $this->flash('success', 'Рандомизация уже подтверждена ранее — состояние не изменялось.');
            } elseif ($settle === 'state_conflict') {
                $this->flash('error', 'Состояние джобы изменилось во время проверки — изменения не применены.');
            } else {
                $this->flash('error',
                    'FTP-проверка: ' . $outcome . '. Стадия оставлена в ожидании оператора. ' . ($res['details'] ?? ''));
            }
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка FTP-проверки: ' . $e->getMessage());
        } finally {
            $jobGuard->releaseJobLock();
        }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * ТЗ 039 §10.2: «Отключить рандомизацию для этого сайта и продолжить».
     * Устанавливает sites_managed.uc_mode='disabled' (причина обязательна),
     * завершает стадию текущей джобы БЕЗ verified_at и пишет audit-запись в той
     * же транзакции (аналог skipUpdateClasses). Verified_at не заполняется.
     */
    public function disableRandomizationForSite(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $jobId = (int)($_POST['id'] ?? 0);
        $confirm = (string)($_POST['confirm'] ?? '');
        $comment = trim((string)($_POST['comment'] ?? ''));

        if ($confirm !== 'yes') {
            $this->flash('error', 'Требуется подтверждение отключения рандомизации для сайта.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        if ($comment === '') {
            $this->flash('error', 'Причина обязательна: укажите, почему рандомизация отключается для этого сайта (пишется в audit).');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        $jobGuard = CronGuard::forJob($jobId);
        if (!$jobGuard->acquireJobLock()) {
            $this->flash('error', 'Джоба сейчас обрабатывается. Подождите ~30 секунд и повторите.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        $pdo = DB::pdo();
        $ownTx = !$pdo->inTransaction();
        try {
            if ($ownTx) $pdo->beginTransaction();
            $st = $pdo->prepare("SELECT id, site_id, stage, stage_status, uc_execution_state, artifacts_json, php_uniquification_verified_at FROM refresh_jobs WHERE id=? FOR UPDATE");
            $st->execute([$jobId]);
            $fresh = $st->fetch(PDO::FETCH_ASSOC);
            if (!$fresh) { throw new \RuntimeException('Джоба не найдена'); }
            if ((string)$fresh['stage'] !== 'update_classes_call' || !empty($fresh['php_uniquification_verified_at'])) {
                if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
                $this->flash('error', 'Действие доступно только на этапе рандомизации до её подтверждения.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
            $siteId = (int)$fresh['site_id'];
            $prevExec = (string)($fresh['uc_execution_state'] ?? '');
            $attempted = in_array($prevExec, ['started','ambiguous','completed'], true);

            // Стадия завершается: not_applicable если вызовов не было; operator_skipped
            // если вызов уже был (результат не подтверждён — это фиксируется).
            $newExec = $attempted ? 'operator_skipped' : 'completed';
            $patch = ['update_classes_stage' => [
                'outcome' => $attempted ? 'operator_skipped' : 'not_applicable',
                'disabled_by_operator' => true,
                'site_uc_mode_set_disabled' => true,
                'decided_at' => date('Y-m-d H:i:s'),
                'comment' => mb_substr($comment, 0, 500),
            ]];
            $upd = $pdo->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'ok', stage_error = NULL, stage_finished_at = NOW(), next_run_at = NOW(),
                    uc_execution_state = ?,
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                 WHERE id = ? AND stage = 'update_classes_call'
                   AND php_uniquification_verified_at IS NULL
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $upd->execute([$newExec, json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
            if ($upd->rowCount() !== 1) {
                if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
                $this->flash('error', 'Не выполнено: состояние джобы изменилось между чтением и записью.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
            // Site-level настройка — в той же транзакции.
            $det = json_encode([
                'checked_at' => date('Y-m-d H:i:s'),
                'source' => 'operator_disable_from_job',
                'job_id' => $jobId,
                'comment' => mb_substr($comment, 0, 300),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $pdo->prepare("UPDATE sites_managed SET uc_mode='disabled', uc_detection_json=?, uc_detected_at=NOW() WHERE id=?")
                ->execute([$det, $siteId]);
            // Обязательный audit тем же $pdo той же транзакцией (как в skipUpdateClasses).
            $auditStmt = $pdo->prepare(
                "INSERT INTO refresh_job_events (job_id, stage, level, message, payload_json)
                 VALUES (?, 'update_classes_call', 'warn', ?, ?)"
            );
            $auditOk = $auditStmt->execute([
                $jobId,
                'Оператор отключил рандомизацию для сайта и продолжил джобу. Причина: ' . $comment,
                json_encode(['event_code' => 'uc.site_disabled_by_operator', 'site_id' => $siteId,
                             'previous_execution_state' => $prevExec,
                             'comment' => mb_substr($comment, 0, 500)],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
            if (!$auditOk || $auditStmt->rowCount() !== 1) {
                throw new \RuntimeException('audit_write_failed: отключение не фиксируется без audit-записи');
            }
            if ($ownTx) $pdo->commit();
            $this->flash('success', 'Рандомизация для сайта отключена, джоба продолжает выполнение. Настройка сохранится и для следующих джоб этого сайта.');
        } catch (\Throwable $e) {
            if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось: ' . $e->getMessage());
        } finally {
            $jobGuard->releaseJobLock();
        }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /** PATCH_3 (§9): реальный HTTP 409 (без redirect), без side-effect. */
    private function httpConflict(string $msg): void
    {
        http_response_code(409);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><meta charset="utf-8"><title>409 Conflict</title>'
            . '<p>' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</p>'
            . '<p><a href="/jobs/show?id=' . (int)($_POST['id'] ?? 0) . '">← назад к джобе</a></p>';
        exit;
    }

    /**
     * PATCH_2 (§16/§18): «⏭ Пропустить рандомизацию» — CSRF + BEGIN + SELECT FOR
     * UPDATE + повторная проверка stage/status + условный UPDATE + rowCount +
     * COMMIT. Пропуск НЕ является verification (verified_at не заполняется).
     */
    public function skipUpdateClasses(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $jobId = (int)($_POST['id'] ?? 0);
        $confirm = (string)($_POST['confirm'] ?? '');
        $comment = trim((string)($_POST['comment'] ?? ''));

        if ($confirm !== 'yes') {
            $this->flash('error', 'Требуется подтверждение пропуска рандомизации.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        if ($comment === '') {
            // §skip-reason: причина обязательна — пропуск фиксируется в audit.
            $this->flash('error', 'Комментарий обязателен: укажите причину пропуска рандомизации (пишется в audit).');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        $jobGuard = CronGuard::forJob($jobId);
        if (!$jobGuard->acquireJobLock()) {
            $this->flash('error', 'Джоба сейчас обрабатывается. Подождите ~30 секунд и повторите.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        $pdo = DB::pdo();
        $ownTx = !$pdo->inTransaction();
        try {
            if ($ownTx) $pdo->beginTransaction();
            // §16: читаем состояние ПОД lock (FOR UPDATE), а не до него.
            $st = $pdo->prepare("SELECT id, stage, stage_status, uc_execution_state, artifacts_json, php_uniquification_verified_at FROM refresh_jobs WHERE id=? FOR UPDATE");
            $st->execute([$jobId]);
            $fresh = $st->fetch(PDO::FETCH_ASSOC);
            if (!$fresh) { throw new \RuntimeException('Джоба не найдена'); }
            // §gate-fix: единый предикат допустимости skip (совпадает с UI). Skip доступен
            // только в состоянии вмешательства (execution_state/outcome не пусты либо
            // awaiting_user); в нейтральном ожидании доступности — запрещён.
            if (!RefreshOrchestrator::manualSkipPolicy($fresh)['allowed']) {
                if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
                $this->flash('error', 'Пропуск сейчас недоступен: рандомизация ещё не запускалась (нейтральное ожидание доступности) либо уже разрешена. Состояние могло измениться.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
            $patch = ['update_classes_stage' => [
                'outcome' => 'operator_skipped',
                'skipped_by_operator' => true,
                'skipped_at' => date('Y-m-d H:i:s'),
                'comment' => mb_substr($comment, 0, 500),
            ]];
            $upd = $pdo->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'ok', stage_error = NULL, stage_finished_at = NOW(), next_run_at = NOW(),
                    uc_execution_state = 'operator_skipped',
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                 WHERE id = ? AND stage = 'update_classes_call'
                   AND php_uniquification_verified_at IS NULL
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $upd->execute([json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
            if ($upd->rowCount() !== 1) {
                if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
                $this->flash('error', 'Пропуск не выполнен (состояние изменилось между чтением и записью).');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
            // §audit-fix: audit пишем НАПРЯМУЮ тем же $pdo в ТОЙ ЖЕ транзакции.
            // JobEventLogger::write() глотает исключения (try/catch→error_log), поэтому
            // для ОБЯЗАТЕЛЬНОГО audit он не годится: UPDATE мог бы закоммититься без
            // записи. operator_skipped не существует без audit-записи — при ошибке
            // INSERT бросаем исключение, и внешний catch откатывает UPDATE.
            $auditStmt = $pdo->prepare(
                "INSERT INTO refresh_job_events (job_id, stage, level, message, payload_json)
                 VALUES (?, 'update_classes_call', 'warn', ?, ?)"
            );
            $auditOk = $auditStmt->execute([
                $jobId,
                'update_classes_operator_skipped. Комментарий: ' . $comment,
                json_encode(['action' => 'operator_skipped', 'comment' => mb_substr($comment, 0, 500)],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
            if (!$auditOk || $auditStmt->rowCount() !== 1) {
                throw new \RuntimeException('audit_write_failed: operator_skipped не фиксируется без audit-записи');
            }
            if ($ownTx) $pdo->commit();
            $this->flash('success', 'Рандомизация пропущена оператором. Pipeline продолжится.');
        } catch (\Throwable $e) {
            if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось пропустить рандомизацию: ' . $e->getMessage());
        } finally {
            $jobGuard->releaseJobLock();
        }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * Повторить упавшую стадию.
     */
    public function retry(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        if ($job['stage_status'] !== 'failed' && $job['stage'] !== 'failed') {
            $this->flash('warning', 'Можно повторить только упавшую стадию');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // Если вся джоба зафейлилась — возобновляем со стадии где упало
        // (в нашей схеме при fail мы ставим stage='failed', а реальная стадия
        // — в той записи которая упала. Поэтому смотрим в события)
        $resumeStage = (string)$job['stage'];
        if ($resumeStage === 'failed') {
            // Найти последнюю стадию из событий
            $st = DB::pdo()->prepare(
                "SELECT stage FROM refresh_job_events
                 WHERE job_id=? AND stage NOT IN ('','failed')
                 ORDER BY id DESC LIMIT 1"
            );
            $st->execute([$jobId]);
            $last = (string)$st->fetchColumn();
            if ($last !== '') $resumeStage = $last;
            else $resumeStage = 'queued';
        }

        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage = ?,
                stage_status = 'pending',
                stage_error = NULL,
                stage_started_at = NULL,
                stage_finished_at = NULL,
                next_run_at = NULL
             WHERE id = ?"
        )->execute([$resumeStage, $jobId]);

        $log = new JobEventLogger($jobId);
        $log->info($resumeStage, "Retry: возвращаем стадию '{$resumeStage}' в pending");

        $this->flash('success', "Джоба возобновлена со стадии '{$resumeStage}'");
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.0-a1 (B3): «Проверить сейчас» — оператор форсирует немедленную
     * readiness-проверку домена, застрявшего в awaiting_user после timeout.
     * Разрешено ТОЛЬКО для update_classes_call + awaiting_user. Под job-lock,
     * с перечитыванием и terminal-guard. Сбрасывает окно readiness и streak,
     * чтобы отсчёт timeout пошёл заново, и ставит next_run_at=NOW().
     */
    public function readinessCheckNow(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        $err = $this->assertReadinessActionable($job);
        if ($err !== null) {
            $this->flash('warning', $err);
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) {
            $this->flash('warning', 'Джоба сейчас обрабатывается. Подождите ~30 сек и повторите.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        try {
            $fresh = $this->loadJob($jobId, true);
            $err = $this->assertReadinessActionable($fresh);
            if ($err !== null) {
                $this->flash('warning', $err);
                $this->redirect('/jobs/show?id=' . $jobId);
            }

            // Сброс окна readiness: новый отсчёт timeout + обнуление streak.
            $arts = json_decode((string)($fresh['artifacts_json'] ?? ''), true) ?: [];
            $stage = $arts['domain_readiness_stage'] ?? [];
            $stage['started_at_unix'] = time();
            $stage['started_at'] = date('Y-m-d H:i:s');
            $stage['streak'] = 0;
            $stage['reset_by'] = RelocationService::currentUser();
            $stage['reset_at'] = date('Y-m-d H:i:s');

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    stage_error = NULL,
                    domain_https_ready_at = NULL,
                    domain_readiness_success_streak = 0,
                    next_run_at = NOW(),
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                 WHERE id = ?
                   AND stage = 'update_classes_call'
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                json_encode(['domain_readiness_stage' => $stage], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);

            (new JobEventLogger($jobId))->info('domain_readiness',
                'Оператор запросил немедленную проверку готовности (окно timeout сброшено).');
            $this->flash('success', 'Проверка готовности запущена — обновите страницу через несколько секунд.');
        } finally {
            $guard->releaseJobLock();
        }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.0-a1 (B3): «Продолжить ожидание» — вернуть застрявшую после timeout
     * джобу в цикл проверок, НЕ сбрасывая накопленный прогресс (streak
     * сохраняется). Окно timeout продлевается от текущего момента, чтобы джоба
     * снова не улетела в awaiting_user мгновенно. Те же ограничения и lock.
     */
    public function readinessContinueWaiting(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        $err = $this->assertReadinessActionable($job);
        if ($err !== null) {
            $this->flash('warning', $err);
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) {
            $this->flash('warning', 'Джоба сейчас обрабатывается. Подождите ~30 сек и повторите.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        try {
            $fresh = $this->loadJob($jobId, true);
            $err = $this->assertReadinessActionable($fresh);
            if ($err !== null) {
                $this->flash('warning', $err);
                $this->redirect('/jobs/show?id=' . $jobId);
            }

            // Продлеваем окно timeout от «сейчас», streak сохраняем как есть.
            $arts = json_decode((string)($fresh['artifacts_json'] ?? ''), true) ?: [];
            $stage = $arts['domain_readiness_stage'] ?? [];
            $stage['started_at_unix'] = time();          // новый отсчёт окна
            $stage['continued_by'] = RelocationService::currentUser();
            $stage['continued_at'] = date('Y-m-d H:i:s');
            $keepStreak = (int)($stage['streak'] ?? 0);

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    stage_error = NULL,
                    next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND),
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                 WHERE id = ?
                   AND stage = 'update_classes_call'
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                DomainReadinessService::normalIntervalSec(),
                json_encode(['domain_readiness_stage' => $stage], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);

            (new JobEventLogger($jobId))->info('domain_readiness',
                "Оператор продлил ожидание готовности (streak сохранён: {$keepStreak}, окно timeout продлено).");
            $this->flash('success', 'Ожидание готовности продлено — проверки продолжатся автоматически.');
        } finally {
            $guard->releaseJobLock();
        }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.0-b: проверка применимости wm_added host-действия.
     * @return string|null null если можно, иначе текст ошибки.
     */
    private function assertWmHostActionable(array $job): ?string
    {
        if (JobLifecycleService::isTerminal((string)$job['stage'])) {
            return 'Джоба уже завершена — действие недоступно.';
        }
        if ((string)$job['stage'] !== 'wm_added') {
            return 'Действие доступно только на стадии добавления host в Вебмастер.';
        }
        if ((string)$job['stage_status'] !== 'awaiting_user') {
            return 'Джоба сейчас не ожидает решения оператора по host.';
        }
        return null;
    }

    /** v25.0-b: «Проверить сейчас» — форсировать опрос списка hosts. */
    public function wmHostCheckNow(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);
        $err = $this->assertWmHostActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) {
            $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertWmHostActionable($fresh)) !== null) {
                $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId);
            }
            // Сброс окна ожидания host + немедленный запуск.
            $arts = json_decode((string)($fresh['artifacts_json'] ?? ''), true) ?: [];
            $stage = $arts['wm_added_stage'] ?? [];
            $stage['poll_started_unix'] = time();
            $stage['reset_by'] = RelocationService::currentUser();
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL, next_run_at=NOW(),
                    artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                 WHERE id=? AND stage='wm_added' AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                json_encode(['wm_added_stage' => $stage], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
            (new JobEventLogger($jobId))->info('wm_added', 'Оператор запросил немедленную проверку host (окно сброшено).');
            $this->flash('success', 'Проверка host запущена — обновите страницу через несколько секунд.');
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /** v25.0-b: «Продолжить ожидание» host — продлить окно, вернуть в poll. */
    public function wmHostContinueWaiting(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);
        $err = $this->assertWmHostActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) {
            $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertWmHostActionable($fresh)) !== null) {
                $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId);
            }
            $arts = json_decode((string)($fresh['artifacts_json'] ?? ''), true) ?: [];
            $stage = $arts['wm_added_stage'] ?? [];
            $stage['poll_started_unix'] = time(); // новый отсчёт окна
            $stage['continued_by'] = RelocationService::currentUser();
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL,
                    next_run_at=DATE_ADD(NOW(), INTERVAL ? SECOND),
                    artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                 WHERE id=? AND stage='wm_added' AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                WmHostPollingService::intervalSec(),
                json_encode(['wm_added_stage' => $stage], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
            (new JobEventLogger($jobId))->info('wm_added', 'Оператор продлил ожидание host (окно продлено).');
            $this->flash('success', 'Ожидание host продлено — проверки продолжатся автоматически.');
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.0-b: «Подтвердить вручную» host_id — аварийное действие.
     * Требует обязательный комментарий; пишет запись в историю.
     */
    public function wmHostManualConfirm(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $hostId = trim((string)($_POST['host_id'] ?? ''));
        $comment = trim((string)($_POST['comment'] ?? ''));
        $job = $this->loadJob($jobId, true);
        $err = $this->assertWmHostActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }
        if ($hostId === '') { $this->flash('warning', 'Укажите host_id для ручного подтверждения.'); $this->redirect('/jobs/show?id=' . $jobId); }
        if (mb_strlen($comment) < 3) { $this->flash('warning', 'Ручное подтверждение требует комментарий (причину).'); $this->redirect('/jobs/show?id=' . $jobId); }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) {
            $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertWmHostActionable($fresh)) !== null) {
                $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId);
            }
            $arts = json_decode((string)($fresh['artifacts_json'] ?? ''), true) ?: [];
            $resolve = $arts['wm_account_resolve_stage'] ?? [];
            $accountId = (int)($resolve['new_account_id'] ?? ($arts['wm_added_stage']['account_id'] ?? 0));
            $userId = (string)($arts['wm_added_stage']['user_id'] ?? '');
            $newDomain = trim((string)$fresh['new_domain']);
            $operator = RelocationService::currentUser();

            if ($accountId <= 0 || $userId === '') {
                $this->flash('warning', 'Нет account_id/user_id в артефактах — ручное подтверждение невозможно.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }

            (new WmHostPollingService())->manualConfirm(
                $jobId, $accountId, $userId, $hostId, $newDomain, $operator, $comment, new JobEventLogger($jobId)
            );
            $this->flash('success', "Host_id {$hostId} подтверждён вручную. Джоба продолжит выполнение.");
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.0-a1 (B3): проверка, что readiness-действие применимо к джобе.
     * @return string|null null если можно, иначе текст ошибки.
     */
    private function assertReadinessActionable(array $job): ?string
    {
        if (JobLifecycleService::isTerminal((string)$job['stage'])) {
            return 'Джоба уже завершена — действие недоступно.';
        }
        if ((string)$job['stage'] !== 'update_classes_call') {
            return 'Действие доступно только на стадии проверки готовности домена.';
        }
        if ((string)$job['stage_status'] !== 'awaiting_user') {
            return 'Джоба сейчас не ожидает решения оператора по готовности.';
        }
        if (!empty($job['domain_https_ready_at'])) {
            return 'Домен уже подтверждён как готовый — действие не требуется.';
        }
        return null;
    }

    /**
     * Ручной "пинок" обработчика — для отладки, если cron ещё не настроен.
     * Делает один шаг через RefreshOrchestrator.
     */
    public function runStep(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        // HOTFIX terminal guard: «Шаг сейчас» на терминальной джобе (в т.ч. завершённой
        // вручную) не запускает pipeline — просто возврат. completed_manual не оживает.
        if (JobLifecycleService::isTerminal((string)($job['stage'] ?? ''))) {
            $this->flash('warning', 'Джоба уже завершена — шаг не выполняется.');
            $this->redirect('/jobs/show?id=' . $jobId);
            return;
        }

        // v18-fix: если у джобы next_run_at в будущем (scheduled-старт),
        // оператор хочет запустить раньше — сбрасываем next_run_at чтобы
        // step() не пропустил.
        $nextRunAt = $job['next_run_at'] ?? null;
        if ($nextRunAt !== null && $nextRunAt !== '' && strtotime((string)$nextRunAt) > time()) {
            try {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET next_run_at = NULL WHERE id = ?"
                )->execute([$jobId]);
                // обновим в локальной копии тоже — чтобы step() видел корректное состояние
                $job['next_run_at'] = null;

                // Для лога: показываем оригинальное время в МСК
                $nextRunMsk = $this->formatServerTimeAsMsk((string)$nextRunAt);

                $log = new JobEventLogger($jobId);
                $log->info('queued',
                    "Оператор запустил scheduled-джобу раньше времени (было: {$nextRunMsk})");
            } catch (\Throwable $e) {
                $this->flash('error', 'Не удалось сбросить scheduled старт: ' . $e->getMessage());
                $this->redirect('/jobs/show?id=' . $jobId);
            }
        }

        // v18.1.29: PER-JOB LOCK — защита от race с cron-обработкой.
        // Если cron сейчас обрабатывает эту же джобу — не дёргаем step повторно.
        $jobGuard = CronGuard::forJob($jobId);
        if (!$jobGuard->acquireJobLock()) {
            $this->flash('warning',
                'Джоба сейчас обрабатывается cron\'ом или другим воркером. ' .
                'Подожди ~30 секунд и попробуй снова, либо просто открой её — ' .
                'если step уже выполнился, в логе будут новые события.');
            $this->redirect('/jobs/show?id=' . $jobId);
            return;
        }

        try {
            // Перечитываем актуальное состояние — между нашим loadJob и acquireJobLock
            // могло пройти время и состояние могло измениться (cron между моментами).
            $freshJob = $this->loadJob($jobId);
            $orch = new RefreshOrchestrator();
            $orch->step($freshJob);
            $this->flash('success', "Шаг выполнен. Откройте лог чтобы увидеть результат.");
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка: ' . $e->getMessage());
        } finally {
            $jobGuard->releaseJobLock();
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * Полностью удалить джобу из БД вместе со всеми событиями.
     * Cascade на refresh_job_events делается явно (FK без ON DELETE CASCADE).
     *
     * Используется для очистки тестовых/упавших джоб. Активные джобы
     * (stage NOT IN done/failed) сначала надо отменить — но мы и активные
     * разрешаем удалять, потому что для тестов это удобно.
     */
    public function delete(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId);

        // v24.2 (H4): нельзя удалить джобу, на которую ссылается закрытая
        // (superseded) джоба — иначе связь повиснет на несуществующем ID,
        // а идемпотентный повтор supersede вернёт «новую» джобу-призрак.
        try {
            $stRef = DB::pdo()->prepare(
                "SELECT id FROM refresh_jobs WHERE superseded_by_job_id = ? LIMIT 1"
            );
            $stRef->execute([$jobId]);
            $refId = (int)$stRef->fetchColumn();
            if ($refId > 0) {
                $this->flash('error',
                    "Нельзя удалить джобу #{$jobId}: она создана взамен закрытой джобы "
                    . "#{$refId} (superseded_by_job_id). Сначала удалите закрытую джобу "
                    . "#{$refId} — тогда ссылка исчезнет вместе с ней.");
                $this->redirect('/jobs/show?id=' . $jobId);
            }
        } catch (\Throwable $e) {
            // Колонка появляется миграцией 024; до неё ссылок нет — проверку пропускаем.
            $msg = $e->getMessage();
            $colMissing = (stripos($msg, 'superseded_by_job_id') !== false)
                && (stripos($msg, 'Unknown column') !== false || stripos($msg, 'not exist') !== false);
            if (!$colMissing) {
                $this->flash('error',
                    "Не удалось проверить связи замены для джобы #{$jobId}: {$msg}. Удаление отменено.");
                $this->redirect('/jobs/show?id=' . $jobId);
            }
        }

        // v22: запрет удаления джобы с НЕЗАВЕРШЁННЫМ переездом.
        // Внешних ключей в схеме панели нет, поэтому проверка программная.
        // Завершённый или отменённый переезд удалению не мешает: запись
        // в site_relocations переживает удаление джобы за счёт snapshot_json.
        try {
            $rel = RelocationService::findByJobId($jobId);
            if ($rel && empty($rel['cancelled_at']) && empty($rel['move_completed_at'])) {
                $snap = json_decode((string)($rel['snapshot_json'] ?? ''), true);
                $oldD = is_array($snap) ? (string)($snap['old_domain'] ?? '') : (string)($job['old_domain'] ?? '');
                $newD = is_array($snap) ? (string)($snap['new_domain'] ?? '') : (string)($job['new_domain'] ?? '');
                $pair = ($oldD !== '' || $newD !== '')
                    ? (' ' . ($oldD !== '' ? $oldD : '?') . ' → ' . ($newD !== '' ? $newD : '?'))
                    : '';

                $this->flash('error',
                    "Нельзя удалить джобу #{$jobId}: с ней связан незавершённый переезд{$pair}. " .
                    "Сначала дождитесь завершения переезда или отмените его в разделе «Переезды»."
                );
                $this->redirect('/jobs/show?id=' . $jobId);
            }

            // v22.2: переезд завершён или отменён — удаление разрешено, но запись
            // должна пережить джобу. Гарантируем полный snapshot ДО удаления:
            // если досохранение после покупки домена когда-то упало, раздел
            // потерял бы сайт, режим, домены и дату старта.
            if ($rel) {
                $snapRes = RelocationService::ensureSnapshotComplete((int)$rel['id']);
                if (empty($snapRes['ok'])) {
                    $this->flash('error',
                        "Нельзя удалить джобу #{$jobId}: не удалось сохранить данные переезда " .
                        "(" . $snapRes['error'] . "). Иначе раздел «Переезды» потеряет историю."
                    );
                    $this->redirect('/jobs/show?id=' . $jobId);
                }
            }
        } catch (\Throwable $e) {
            // H10: раньше здесь был fail-open — ЛЮБАЯ ошибка отключала защиту.
            // Пропускаем только отсутствие таблицы (окно до применения миграции),
            // всё остальное блокирует удаление, чтобы не потерять данные молча.
            $msg = $e->getMessage();
            $tableMissing = (stripos($msg, "site_relocations") !== false)
                && (stripos($msg, "doesn't exist") !== false || stripos($msg, 'not exist') !== false);
            if (!$tableMissing) {
                error_log("Relocation delete-guard failed for job={$jobId}: " . $msg);
                $this->flash('error',
                    "Не удалось проверить связанный переезд для джобы #{$jobId}: " . $msg
                    . '. Удаление отменено.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
        }

        try {
            $pdo = DB::pdo();
            $pdo->beginTransaction();

            // v25.0-a1 (H2): probe-файл готовности удаляем ДО удаления джобы —
            // ProbeFileManager берёт token из artifacts_json, которого после
            // DELETE уже не будет. Best-effort, вне транзакции БД.
            try {
                if (class_exists('ProbeFileManager')) {
                    (new ProbeFileManager())->removeForJob($jobId, null);
                }
            } catch (\Throwable $e) {
                error_log("delete(): probe cleanup failed for job {$jobId}: " . $e->getMessage());
            }

            // 1. События джобы
            $stEv = $pdo->prepare("DELETE FROM refresh_job_events WHERE job_id=?");
            $stEv->execute([$jobId]);
            $eventsDeleted = $stEv->rowCount();

            // v25.0-b: per-URL recrawl-записи джобы.
            try {
                $pdo->prepare("DELETE FROM refresh_job_recrawl_urls WHERE job_id=?")->execute([$jobId]);
            } catch (\Throwable $e) {
                // таблицы может не быть (миграция 026 не применена) — не критично
            }

            // 2. Сама джоба
            $stJob = $pdo->prepare("DELETE FROM refresh_jobs WHERE id=?");
            $stJob->execute([$jobId]);

            $pdo->commit();

            $oldDomain = (string)($job['old_domain'] ?? '?');
            $this->flash('success',
                "Джоба #{$jobId} ({$oldDomain}) удалена. Событий удалено: {$eventsDeleted}.");
        } catch (\Throwable $e) {
            try { DB::pdo()->rollBack(); } catch (\Throwable $e2) {}
            $this->flash('error', 'Не удалось удалить джобу: ' . $e->getMessage());
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // После удаления — на список джоб
        $this->redirect('/jobs');
    }

    /**
     * Пользователь нажал "✅ Я поправил, продолжить" на джобе со статусом
     * awaiting_user. Переводит status: awaiting_user → ok, чтобы оркестратор
     * на следующем тике cron'а перешёл на следующую стадию.
     */
    public function approveContinue(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true); // v24.2 (B4)

        if ((string)$job['stage_status'] !== 'awaiting_user') {
            $this->flash('error',
                'Джоба не в статусе «ждёт оператора» (сейчас: ' . JobEventLogger::statusLabel((string)$job['stage_status']) . ')');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // v25.2-a1.6.4.1 (§8): для update_classes_call обычный «Я поправил» ЗАПРЕЩЁН.
        // Нельзя закрывать стадию рандомизации без реальной FTP-проверки применения
        // (иначе gate откроется при php_uniquification_verified_at=NULL). Оператора
        // направляем на «Проверить уже выполненный рандом» или явный «Пропустить».
        if ((string)$job['stage'] === 'update_classes_call') {
            $this->flash('error',
                'Для стадии рандомизации классов обычное подтверждение недоступно. '
                . 'Используйте «✅ Проверить уже выполненный рандом и продолжить» '
                . '(FTP-проверка применения) или «⏭ Пропустить рандомизацию» (с подтверждением).');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        try {
            $stage = (string)$job['stage'];

            // v18.1.13: специальный кейс — redirect_enable awaiting из-за провала smoke-test.
            // Оператор поправил Apache/opcache/CDN и хочет чтобы pipeline переисполнил
            // smoke-test заново (не пропустил его). Сбрасываем smoke_attempt в артефактах
            // и переводим стадию в 'pending' — стадия retry заново, начиная с попытки #1.
            // Также сбрасываем post_validation_failed и remaining_markers на случай если
            // они были (но обычно при awaiting из-за smoke они пустые).
            $isSmokeRetry = false;
            if ($stage === 'redirect_enable') {
                $artifacts = !empty($job['artifacts_json'])
                    ? (json_decode((string)$job['artifacts_json'], true) ?: [])
                    : [];
                $smokeAttempt = (int)($artifacts['redirect_enabled_stage']['smoke_attempt'] ?? 0);
                $hadSmokeFail = isset($artifacts['redirect_enabled_stage']['smoke_test'])
                    && empty($artifacts['redirect_enabled_stage']['smoke_test']['ok']);
                $hadEnableOk = !empty($artifacts['redirect_enabled_stage']['ok'])
                    && empty($artifacts['redirect_enabled_stage']['remaining_markers'])
                    && empty($artifacts['redirect_enabled_stage']['post_validation_failed']);

                if ($smokeAttempt > 0 && $hadSmokeFail && $hadEnableOk) {
                    $isSmokeRetry = true;
                    // Сбрасываем счётчик попыток + результат — пусть стадия начнёт smoke заново
                    $artifacts['redirect_enabled_stage']['smoke_attempt'] = 0;
                    unset($artifacts['redirect_enabled_stage']['smoke_test']);
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET
                            artifacts_json = ?,
                            stage_status = 'pending',
                            stage_error = NULL,
                            next_run_at = NULL
                         WHERE id = ?
                           AND stage NOT IN ('cancelled','superseded')"
                    )->execute([
                        json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        $jobId,
                    ]);

                    $log = new JobEventLogger($jobId);
                    $log->info('redirect_enable',
                        "Пользователь подтвердил «Я поправил» — сбрасываю smoke_attempt и " .
                        "запускаю smoke-test заново (с попытки #1).");

                    $this->flash('success',
                        'Smoke-test будет переисполнен заново. Cron подхватит в течение минуты.');
                    $this->redirect('/jobs/show?id=' . $jobId);
                }
            }

            // ТЗ044 §6: generic «Я поправил» больше НЕ ставит слепо ok.
            // Решение принимает allowlist-policy по стадии и её постусловиям.
            $artifactsAll = !empty($job['artifacts_json']) ? (json_decode((string)$job['artifacts_json'], true) ?: []) : [];
            $action = OperatorContinuationPolicy::actionFor($stage, $job, $artifactsAll);
            $log = new JobEventLogger($jobId);

            if ($action === OperatorContinuationPolicy::DEDICATED_ACTION_REQUIRED) {
                $this->flash('error', 'Для этой стадии обычное подтверждение недоступно — используйте выделенное действие стадии.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
            if ($action === OperatorContinuationPolicy::BLOCK_INVALID_STATE) {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage='analyze_site', stage_status='pending', stage_error=NULL, next_run_at=NULL
                     WHERE id=? AND stage NOT IN ('cancelled','superseded')"
                )->execute([$jobId]);
                $log->warn($stage, 'Оператор нажал «продолжить», но replacement_plan отсутствует — возврат на analyze_site (без ok).');
                $this->flash('error', 'Продолжение заблокировано: нет корректного replacement_plan. Стадия будет пересобрана анализом.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
            if ($action === OperatorContinuationPolicy::RETRY_SAME_STAGE) {
                // awaiting_user → pending ТОЙ ЖЕ стадии (реальный повтор, НЕ ok)
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL, next_run_at=NULL
                     WHERE id=? AND stage NOT IN ('cancelled','superseded')"
                )->execute([$jobId]);
                $label = $stage === 'analyze_site' ? 'анализ сайта' : ('«' . $stage . '»');
                $log->info($stage, 'Оператор подтвердил — повторяю стадию ' . $label . ' заново (pending, не ok).');
                $this->flash('success', 'Стадия будет переисполнена заново (🔁). Cron подхватит в течение минуты.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }

            // ADVANCE_CONFIRMED — только для явного allowlist'а
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'ok',
                    stage_error = NULL,
                    stage_finished_at = NOW()
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([$jobId]);

            $log->info((string)$job['stage'],
                "Пользователь подтвердил продолжение (allowlist stage, статус был awaiting_user)");

            $this->flash('success',
                'Джоба продолжена. Cron подхватит её в течение минуты.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось продолжить: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v18.1.19: подтвердить редирект вручную (smoke timeout, но оператор проверил
     * в браузере что редирект работает).
     *
     * Отличие от approveContinue:
     *   - approveContinue («Я поправил») — СБРАСЫВАЕТ smoke_attempt и запускает
     *     smoke-test заново. Полезно когда оператор поправил Apache/opcache/CDN.
     *     Если причина в сети панель↔VPS — это даст бесконечный loop awaiting_user.
     *
     *   - confirmRedirectManually («Проверил вручную, пропусти smoke») —
     *     записывает smoke_test.manual_confirm = true и сразу идёт на следующую
     *     стадию. Для случая когда автоматический smoke в принципе не может пройти
     *     (firewall между панелью и VPS, специфика DDoS-Guard и т.п.), но
     *     оператор открыл /play в браузере и видит 302 на партнёрку.
     *
     * Разрешено ТОЛЬКО:
     *   - stage = redirect_enable
     *   - stage_status = awaiting_user
     *   - smoke_test реально упал (smoke_attempt > 0, smoke_test.ok = false)
     */
    public function confirmRedirectManually(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true); // v24.2 (B4)

        if ((string)$job['stage'] !== 'redirect_enable') {
            $this->flash('error',
                'Ручное подтверждение редиректа доступно только на стадии redirect_enable. ' .
                'Текущая стадия: ' . $job['stage']);
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        if ((string)$job['stage_status'] !== 'awaiting_user') {
            $this->flash('error',
                'Доступно только когда джоба «ждёт оператора» (сейчас: ' . JobEventLogger::statusLabel((string)$job['stage_status']) . ')');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        $artifacts = !empty($job['artifacts_json'])
            ? (json_decode((string)$job['artifacts_json'], true) ?: [])
            : [];

        $smokeAttempt = (int)($artifacts['redirect_enabled_stage']['smoke_attempt'] ?? 0);
        $hadSmokeFail = isset($artifacts['redirect_enabled_stage']['smoke_test'])
            && empty($artifacts['redirect_enabled_stage']['smoke_test']['ok']);

        if ($smokeAttempt === 0 || !$hadSmokeFail) {
            $this->flash('error',
                'Smoke-test ещё не выполнялся или не провалился. ' .
                'Используй обычную «Я поправил, продолжить» вместо ручного подтверждения.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        try {
            // Записываем manual_confirm в smoke_test и переводим стадию в ok
            $artifacts['redirect_enabled_stage']['smoke_test'] = [
                'ok' => true,
                'reason' => 'Подтверждено оператором вручную (smoke с панели не дозвонился, ' .
                            'но оператор проверил редирект в браузере)',
                'http_code' => 0,
                'manual_confirm' => true,
                'manual_confirm_at' => date('Y-m-d H:i:s'),
                'previous_attempts' => $smokeAttempt,
                'previous_reason' => $artifacts['redirect_enabled_stage']['smoke_test']['reason'] ?? 'unknown',
            ];

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = ?,
                    stage_status = 'ok',
                    stage_error = NULL,
                    stage_finished_at = NOW(),
                    next_run_at = NULL
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);

            $log = new JobEventLogger($jobId);
            $log->warn('redirect_enable',
                "Оператор подтвердил редирект вручную (smoke с панели не дозвонился, " .
                "но проверено в браузере). Стадия завершена, cron перейдёт на следующую.");

            $this->flash('success',
                'Редирект подтверждён вручную. Cron перейдёт на следующую стадию в течение минуты.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось подтвердить: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v17.5: пропустить текущую стадию.
     *
     * Используется когда стадия в awaiting_user, и пользователь решил что эту стадию
     * выполнять не нужно (например старый домен реально нигде нет в Webmaster).
     *
     * Логика:
     *   1. Помечает текущую стадию как 'skipped' в логе событий (для аудита)
     *   2. Определяет куда прыгать:
     *      - wm_account_resolve → redirect_enable (skip ВСЕХ webmaster-стадий, т.к. без
     *        аккаунта они не выполнятся, индексация не проверится)
     *      - все остальные стадии → следующая по STAGES_ORDER
     *   3. Ставит новую стадию с pending, cron подхватит
     *
     * Запрещено для:
     *   - queued, domain_purchasing, aliases_added, ssl_self_signed_first
     *   - redirect_disable, analyze_site, config_replaced, verify_replacement
     *   - ssl_le_polling
     *   (это критичные стадии — пропуск приведёт к разрушенному pipeline)
     */
    public function skipStage(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true); // v24.2 (B4)

        if ((string)$job['stage_status'] !== 'awaiting_user') {
            $this->flash('error',
                'Пропустить можно только стадию в awaiting_user (сейчас: ' . $job['stage_status'] . ')');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        $currentStage = (string)$job['stage'];
        $mode = (string)($job['mode'] ?? 'refresh');

        // Whitelist стадий которые пропускать ОПАСНО
        $forbiddenStages = [
            'queued', 'domain_purchasing', 'aliases_added', 'ssl_self_signed_first',
            'redirect_disable', 'analyze_site', 'config_replaced', 'verify_replacement',
            'ssl_le_polling',
            // P0 §4.6: публичный trusted-SSL gate НЕПРОПУСКАЕМ — вход в Webmaster
            // с недоверенным сертификатом запрещён (fatal сам уводит в awaiting_user).
            'trusted_ssl_gate',
        ];
        if (in_array($currentStage, $forbiddenStages, true)) {
            $this->flash('error',
                "Стадию '{$currentStage}' нельзя пропускать — это критичная часть pipeline. " .
                "Используй retry или rebuild-plan вместо skip.");
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // Определяем следующую стадию
        $nextStage = $this->resolveSkipNextStage($currentStage, $mode);
        if ($nextStage === null) {
            // Последняя стадия — skip = считаем done
            try {
                $log = new JobEventLogger($jobId);
                $log->warn($currentStage,
                    "⏭ Пользователь пропустил стадию '{$currentStage}' (последняя). Джоба → done.");

                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET
                        stage = 'done',
                        stage_status = 'ok',
                        stage_error = NULL,
                        stage_finished_at = NOW()
                     WHERE id = ?
                       AND stage NOT IN ('cancelled','superseded')"
                )->execute([$jobId]);

                $this->flash('success', "Стадия '{$currentStage}' пропущена. Джоба переведена в done.");
            } catch (\Throwable $e) {
                $this->flash('error', 'Не удалось завершить джобу: ' . $e->getMessage());
            }
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        try {
            $log = new JobEventLogger($jobId);

            // Помечаем что стадия пропущена пользователем (для аудита в БД)
            $log->warn($currentStage,
                "⏭ Пользователь пропустил стадию '{$currentStage}'. " .
                "Перехожу сразу на '{$nextStage}'.");

            // Если skip wm_account_resolve — нужно объяснить что webmaster-стадии тоже скипаются
            if ($currentStage === 'wm_account_resolve') {
                $log->warn($currentStage,
                    "Cascade skip: webmaster-стадии (wm_added, wm_verified, wm_sitemap, " .
                    "wm_recrawl, index_watching, wm_old_removed) тоже будут пропущены, " .
                    "т.к. без resolved аккаунта они не выполнятся.");
            }

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage = ?,
                    stage_status = 'pending',
                    stage_error = NULL,
                    stage_started_at = NULL,
                    stage_finished_at = NULL,
                    next_run_at = NULL
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([$nextStage, $jobId]);

            $this->flash('success',
                "Стадия '{$currentStage}' пропущена. Cron подхватит '{$nextStage}' в течение минуты.");
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось пропустить: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v17.5/v18: определяет на какую стадию прыгать после skip.
     *
     * Особенности:
     *   - skip wm_account_resolve в refresh   → прыгаем на redirect_enable
     *   - skip wm_account_resolve в move_*    → прыгаем на move_htaccess_redirect
     *     (пропускаем все webmaster-стадии, т.к. без resolved аккаунта они бесполезны)
     *   - skip остальных стадий               → следующая по nextStageFor
     */
    private function resolveSkipNextStage(string $currentStage, string $mode = 'refresh'): ?string
    {
        // Особый случай: skip wm_account_resolve = skip всего Webmaster-блока.
        // P0 §4.8: ТОЛЬКО ВПЕРЁД на post-Webmaster стадию. Возврат на
        // redirect_enable/move_htaccess_redirect образовал бы цикл через
        // trusted_ssl_gate → wm_account_resolve (после переноса redirect_enable
        // ДО wm-блока в v18.1 старое значение вело назад).
        if ($currentStage === 'wm_account_resolve') {
            if ($mode === 'move_indexed' || $mode === 'move_simple') {
                return 'move_submit_request';
            }
            return 'index_watching';
        }

        // v18: для остальных используем общую логику nextStage с учётом mode
        $next = RefreshOrchestrator::nextStageFor($currentStage, $mode);
        if ($next === null) return null;
        if ($next === 'done' || $next === 'failed') return null;
        return $next;
    }

    /**
     * v17.7: установить override Webmaster аккаунта для джобы которая стоит в awaiting_user
     * на стадии wm_account_resolve (или ранее по ошибке).
     *
     * Логика:
     *   1. Принимает jobId и accountId (из формы UI)
     *   2. Проверяет что аккаунт существует в БД
     *   3. Записывает webmaster_account_override_id в refresh_jobs
     *   4. Сбрасывает стадию на wm_account_resolve / pending
     *      (cron подхватит, увидит override → пройдёт через override-ветку)
     *
     * Отличие от skipStage: не выбрасывает webmaster-стадии, а пускает их с override.
     * Старый домен НЕ удалится (потому что не найден), но новый домен будет добавлен
     * в указанный аккаунт + indexed + расследим всё.
     *
     * Не удаляет джобу — купленный домен, DNS, SSL, замены остаются.
     */
    /**
     * CAS-условие override (P0, ревью v2): применяется ТОЛЬКО из двух явных
     * awaiting-состояний; для джоб новой ревизии дополнительно требует пройденный
     * trusted-SSL gate прямо в WHERE (защита и от гонки с adopt).
     * ЕДИНСТВЕННЫЙ источник истины для guarded UPDATE — использовать и в тестах.
     */
    private const WM_OVERRIDE_CAS_SQL =
        "UPDATE refresh_jobs SET
            webmaster_account_override_id = ?,
            stage = 'wm_account_resolve',
            stage_status = 'pending',
            stage_error = NULL,
            stage_started_at = NULL,
            stage_finished_at = NULL,
            next_run_at = NOW(),
            artifacts_json = JSON_REMOVE(
                JSON_SET(
                    COALESCE(artifacts_json,'{}'),
                    '$.move_poll_status_stage.awaiting_no_account', false
                ),
                '$.move_poll_status_stage.awaiting_reason'
            )
         WHERE id = ?
           AND (
                 (stage = 'wm_account_resolve' AND stage_status = 'awaiting_user')
              OR (stage = 'move_poll_status'  AND stage_status = 'awaiting_user'
                  AND JSON_EXTRACT(artifacts_json, '$.move_poll_status_stage.awaiting_no_account') = true)
           )
           AND (trusted_ssl_gate_required = 0
                OR (trusted_ssl_gate_completed_at IS NOT NULL
                    AND JSON_EXTRACT(artifacts_json, '$.trusted_ssl_gate.ok') = true))";

    public function setWebmasterOverride(): void
    {
        $this->requireAuth();
        $this->requireCsrf(); // P0 ревью v2: изменяющий pipeline POST — только с CSRF
        $jobId = (int)($_POST['id'] ?? 0);
        $accountId = (int)($_POST['account_id'] ?? 0);
        $job = $this->loadJob($jobId, true); // v24.2 (B4)

        // P0 §4.6: override не обходит trusted-SSL gate (дружелюбное сообщение;
        // строгая защита продублирована в WHERE CAS-запроса).
        if ((int)($job['trusted_ssl_gate_required'] ?? 0) === 1) {
            $artsJson = json_decode((string)($job['artifacts_json'] ?? ''), true) ?: [];
            if (empty($artsJson['trusted_ssl_gate']['ok']) || empty($job['trusted_ssl_gate_completed_at'])) {
                $this->flash('warning', 'Webmaster-override запрещён: публичный доверенный SSL ещё не подтверждён (trusted_ssl_gate). Дождитесь закрытия gate.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
        }

        // P0 (ревью v2): override разрешён ТОЛЬКО из двух явных состояний —
        //  1) wm_account_resolve + awaiting_user (аккаунт не определён перед добавлением);
        //  2) move_poll_status + awaiting_user + artifacts.move_poll_status_stage.awaiting_no_account
        //     (переезд ожидается, аккаунт потерян).
        // Из любых иных стадий (wm_added/wm_verified/wm_recrawl/index_watching/
        // final_monitoring/…) запрос отклоняется БЕЗ изменения джобы: возврат
        // продвинувшейся джобы в wm_account_resolve повторно открывал бы
        // Webmaster-контур и повторял внешние действия в Yandex.
        $stageNow = (string)($job['stage'] ?? '');
        $statusNow = (string)($job['stage_status'] ?? '');
        $artsNow = json_decode((string)($job['artifacts_json'] ?? ''), true) ?: [];
        $allowed =
            ($stageNow === 'wm_account_resolve' && $statusNow === 'awaiting_user')
            || ($stageNow === 'move_poll_status' && $statusNow === 'awaiting_user'
                && !empty($artsNow['move_poll_status_stage']['awaiting_no_account']));
        if (!$allowed) {
            $this->flash('warning',
                "Override Webmaster доступен только когда джоба ЖДЁТ выбора аккаунта " .
                "(wm_account_resolve/awaiting_user или переезд без аккаунта). " .
                "Текущее состояние: «{$stageNow}/{$statusNow}» — запрос отклонён, джоба не изменена.");
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        if ($accountId <= 0) {
            $this->flash('error', 'Не выбран Webmaster аккаунт');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // Проверяем что аккаунт существует
        try {
            $st = DB::pdo()->prepare(
                "SELECT id, label, email FROM yandex_webmaster_accounts WHERE id = ?"
            );
            $st->execute([$accountId]);
            $account = $st->fetch();
            if (!$account) {
                $this->flash('error', "Webmaster аккаунт #{$accountId} не найден в БД");
                $this->redirect('/jobs/show?id=' . $jobId);
            }
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка проверки аккаунта: ' . $e->getMessage());
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        $accountLabel = (string)($account['label'] ?: $account['email'] ?: "id={$accountId}");

        // Job-lock + compare-and-set: состояние проверяется ПОВТОРНО в самом UPDATE;
        // rowCount=1 — единственный признак успеха. Гонка (стадия сменилась между
        // чтением и UPDATE) даёт rowCount=0 → джоба НЕ откатывается.
        $lockName = 'rfp_job_override_' . $jobId;
        $locked = false; $outcome = 'error'; $errMsg = '';
        try {
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, 5)");
            $st->execute([$lockName]);
            $locked = ((int)$st->fetchColumn() === 1);
            if (!$locked) {
                $outcome = 'busy';
            } else {
                $upd = DB::pdo()->prepare(self::WM_OVERRIDE_CAS_SQL);
                $upd->execute([$accountId, $jobId]);
                if ($upd->rowCount() !== 1) {
                    // Гонка: состояние сменилось между чтением и UPDATE — джоба не тронута.
                    $outcome = 'raced';
                } else {
                    $outcome = 'ok';
                    $log = new JobEventLogger($jobId);
                    $log->warn($stageNow,
                        "Пользователь установил override Webmaster аккаунта: #{$accountId} ({$accountLabel}). " .
                        "Стадия wm_account_resolve будет запущена заново. Новый домен будет добавлен в этот аккаунт. " .
                        "Старый домен НЕ будет удалён из Webmaster (т.к. не был найден) — это нормально."
                    );
                }
            }
        } catch (\Throwable $e) {
            $outcome = 'error'; $errMsg = $e->getMessage();
        } finally {
            if ($locked) {
                try { DB::pdo()->prepare("SELECT RELEASE_LOCK(?)")->execute([$lockName]); } catch (\Throwable $e2) {}
            }
        }

        if ($outcome === 'ok') {
            $this->flash('success',
                "Override Webmaster установлен: #{$accountId} ({$accountLabel}). " .
                "Cron подхватит джобу и продолжит pipeline в течение минуты.");
        } elseif ($outcome === 'raced') {
            $this->flash('warning',
                'Состояние джобы уже изменилось (например, cron продолжил pipeline) — override НЕ применён, джоба не изменена. Обновите страницу.');
        } elseif ($outcome === 'busy') {
            $this->flash('error', 'Джоба сейчас обрабатывается — попробуйте ещё раз через несколько секунд.');
        } else {
            $this->flash('error', 'Не удалось установить override: ' . $errMsg);
        }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v18: пользователь нажал "✅ Я подал заявку на переезд" в карточке джобы.
     *
     * Используется в стадии move_submit_request (move_indexed/move_simple).
     * После нажатия pipeline переходит на move_poll_status — там cron каждые
     * 5-10 мин проверяет main_mirror через Webmaster API.
     */
    public function acknowledgeMove(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true); // v24.2 (B4)

        $stage = (string)$job['stage'];
        $status = (string)$job['stage_status'];

        if ($stage !== 'move_submit_request') {
            $this->flash('error',
                "Это действие доступно только в стадии 'move_submit_request' (сейчас: '{$stage}')");
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        if ($status !== 'awaiting_user') {
            $this->flash('error',
                "Это действие доступно только в awaiting_user (сейчас: '{$status}')");
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        try {
            // Записываем ack_at в artifacts
            $artifacts = json_decode((string)($job['artifacts_json'] ?? '{}'), true) ?: [];
            if (!isset($artifacts['move_submit_request_stage'])) {
                $artifacts['move_submit_request_stage'] = [];
            }
            $artifacts['move_submit_request_stage']['ack_at'] = date('Y-m-d H:i:s');

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = ?,
                    stage_status = 'ok',
                    stage_error = NULL,
                    stage_finished_at = NOW(),
                    next_run_at = NULL
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([json_encode($artifacts, JSON_UNESCAPED_UNICODE), $jobId]);

            $log = new JobEventLogger($jobId);
            $log->ok('move_submit_request',
                '✅ Пользователь подтвердил подачу заявки на переезд. Pipeline → move_poll_status.');

            $this->flash('success',
                'Подтверждено. Cron начнёт проверять статус переезда в течение минуты ' .
                '(заявка обычно обрабатывается Yandex 30-40 минут).');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось подтвердить: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v18: пользователь нажал "✅ Я отправил на удаление" в карточке джобы.
     *
     * Используется в стадии old_delurl_notify (только refresh).
     * После нажатия pipeline переводит джобу в done.
     */
    public function acknowledgeDelurl(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        $stage = (string)$job['stage'];
        $status = (string)$job['stage_status'];

        if ($stage !== 'old_delurl_notify') {
            $this->flash('error',
                "Это действие доступно только в стадии 'old_delurl_notify' (сейчас: '{$stage}')");
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        if ($status !== 'awaiting_user') {
            $this->flash('error',
                "Это действие доступно только в awaiting_user (сейчас: '{$status}')");
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        try {
            // ack_at в artifacts
            $artifacts = json_decode((string)($job['artifacts_json'] ?? '{}'), true) ?: [];
            if (!isset($artifacts['old_delurl_notify_stage'])) {
                $artifacts['old_delurl_notify_stage'] = [];
            }
            $artifacts['old_delurl_notify_stage']['ack_at'] = date('Y-m-d H:i:s');

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = ?,
                    stage_status = 'ok',
                    stage_error = NULL,
                    stage_finished_at = NOW(),
                    next_run_at = NULL
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([json_encode($artifacts, JSON_UNESCAPED_UNICODE), $jobId]);

            $log = new JobEventLogger($jobId);
            $log->ok('old_delurl_notify',
                '✅ Пользователь подтвердил отправку URL в "Удаление страниц из поиска". Джоба завершается.');

            $this->flash('success',
                'Подтверждено. Cron завершит джобу (→ done) в течение минуты.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось подтвердить: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * Пользователь нажал "🔁 Пересобрать план" на джобе в awaiting_user.
     *
     * Возвращает джобу на стадию analyze_site со статусом pending. Cron
     * пересоберёт план (с актуальными правилами PlanBuilder-а) и применит.
     *
     * Полезно когда:
     *   - В код добавлены новые правила (например v14d с whole_file_replace)
     *     и хочется пересобрать план для зависшей джобы.
     *   - В исходных файлах сайта произошли изменения.
     *
     * При этом snapshots от предыдущего применения СОХРАНЯЮТСЯ — если
     * новый план хуже старого, можно откатить.
     */
    public function rebuildPlan(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true); // v24.2 (B4)

        // Разрешаем нажимать как из awaiting_user так и из failed
        $allowedStatuses = ['awaiting_user', 'failed', 'ok'];
        if (!in_array((string)$job['stage_status'], $allowedStatuses, true)) {
            $this->flash('error',
                'Пересборка доступна только из awaiting_user/failed/ok (сейчас: ' . $job['stage_status'] . ')');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        try {
            // v18.1.16 КОРНЕВОЙ ФИКС: при rebuildPlan тоже нужно очищать
            // redirect_enabled_stage. Иначе skipEnable пропустит enable при
            // повторном проходе (так как state в артефактах остался от первой попытки).
            //
            // Также очищаем остальные стадии после analyze_site чтобы UI
            // не показывал старые данные.
            $artifacts = !empty($job['artifacts_json'])
                ? (json_decode((string)$job['artifacts_json'], true) ?: [])
                : [];

            $stagesToClear = [
                'redirect_enabled_stage',   // КРИТИЧНО для v18.1.13-skipEnable
                'analyze_stage',
                'config_replaced_stage',
                'verify_stage',
                'update_classes_stage',
                // ВАЖНО: redirect_disabled_stage НЕ очищаем — disable уже сделал маркеры
                // в файле, и redirect_enable должен их видеть в applied_rules.
                // Очищать его опасно — потеряем track что нужно восстанавливать.
            ];
            foreach ($stagesToClear as $key) {
                unset($artifacts[$key]);
            }

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage = 'analyze_site',
                    stage_status = 'pending',
                    stage_error = NULL,
                    stage_started_at = NULL,
                    stage_finished_at = NULL,
                    next_run_at = NULL,
                    artifacts_json = ?
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);

            $log = new JobEventLogger($jobId);
            $log->warn((string)$job['stage'],
                "Пользователь запросил пересборку плана. Возврат на analyze_site, статус pending. " .
                "Артефакты redirect_enabled/analyze/config_replaced/verify/update_classes очищены. " .
                "Cron подхватит в течение минуты.");

            $this->flash('success',
                'План будет пересобран. Cron подхватит джобу в течение минуты, ' .
                'analyze_site → config_replaced → verify_replacement пойдут по новой.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось пересобрать план: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * Пользователь нажал "↩️ Откатить snapshot" на джобе.
     * Восстанавливает файлы на VPS из snapshot'ов через ReplacementApplier.
     * После отката — переводит джобу в failed с понятным сообщением.
     */
    public function rollback(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true); // v24.2 (B4)

        // Берём snapshots и base_path из artifacts
        $artifacts = [];
        if (!empty($job['artifacts_json'])) {
            $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
        }
        $snapshots = $artifacts['config_replaced_stage']['snapshots'] ?? [];
        $basePath = $artifacts['replacement_plan']['base_path'] ?? null;

        if (empty($snapshots)) {
            $this->flash('error',
                'У этой джобы нет snapshot\'ов для отката (стадия config_replaced не выполнялась)');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // v24.3 (B2): откат меняет ФАЙЛЫ САЙТА и current_domain — это внешние
        // действия, SQL-guard финального UPDATE их не защищает. Поэтому:
        //  1) берём тот же advisory lock rfp_job_<id>, что cron/runStep и
        //     lifecycle-сервис — пока откат идёт, закрыть/заменить джобу нельзя
        //     (и наоборот: во время закрытия откат не стартует);
        //  2) после захвата перечитываем джобу — состояние могло измениться,
        //     пока ждали, и закрытая джоба не должна трогать сайт.
        $jobGuard = CronGuard::forJob($jobId);
        if (!$jobGuard->acquireJobLock()) {
            $this->flash('warning',
                'Джоба #' . $jobId . ' прямо сейчас обрабатывается (cron, ручной шаг '
                . 'или закрытие). Подождите ~30 секунд и повторите откат.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        try {
            $freshJob = $this->loadJob($jobId, true); // redirect при закрытой — лок
                                                      // освободится с закрытием соединения
            if (JobLifecycleService::isTerminal((string)$freshJob['stage'])
                && (string)$freshJob['stage'] !== 'failed') {
                // failed откатывать можно (штатный сценарий), done/closed — нет.
                $this->flash('error',
                    'Джоба уже завершена (' . $freshJob['stage'] . ') — откат недоступен.');
                $this->redirect('/jobs/show?id=' . $jobId);
            }
            $job = $freshJob;

            $this->rollbackLocked($jobId, $job, $artifacts, $snapshots, $basePath);
        } finally {
            $jobGuard->releaseJobLock();
        }
    }

    /**
     * v24.3 (B2): тело отката, выполняется строго под rfp_job_<id> lock.
     * Вынесено из rollback(), логика не менялась.
     */
    private function rollbackLocked(int $jobId, array $job, array $artifacts, array $snapshots, $basePath): void
    {
        $log = new JobEventLogger($jobId);
        $log->warn('rollback',
            'Пользователь запросил откат. Восстанавливаю файлы из snapshot\'ов: ' .
            implode(', ', array_keys($snapshots)));

        // v25.0-a1 (H2): при откате readiness сбрасывается (pipeline вернётся на
        // ssl_self_signed_first), поэтому старый probe-файл готовности удаляем —
        // новый цикл зальёт свой с новым токеном. Best-effort, под job-lock'ом.
        try {
            if (class_exists('ProbeFileManager')) {
                (new ProbeFileManager())->removeForJob($jobId, $log);
            }
        } catch (\Throwable $e) {
            error_log("rollback(): probe cleanup failed for job {$jobId}: " . $e->getMessage());
        }

        try {
            $applier = new ReplacementApplier();
            $result = $applier->rollback((int)$job['site_id'], $jobId, $snapshots, $log, $basePath);

            if (!empty($result['ok'])) {
                $log->ok('rollback',
                    'Откат replacement-замен успешен. Восстановлено файлов: ' . count($result['restored']));

                // v18.1.8: ВАЖНО — также откатываем redirect_disable snapshot'ы.
                // ReplacementApplier::rollback восстанавливает файлы из *.before.txt (они
                // были сделаны ПОСЛЕ redirect_disable → содержат '# REFRESH-DISABLED:' префиксы).
                // Поэтому ПОСЛЕ replacement-rollback'а нужно ещё восстановить *.before-disable.txt
                // (которые сделаны до redirect_disable → без префиксов).
                //
                // Иначе:
                //   - Файлы откатились с REFRESH-DISABLED префиксами
                //   - Pipeline сбросился на ssl_self_signed_first
                //   - redirect_disable снова запустился, но preg_replace не нашёл маркеры
                //     (они уже закомментированы)
                //   - applied_rules = []
                //   - redirect_enable увидел пустой list → "нечего включать" → молча ok
                //   - Префикс остался → редирект выключен → партнёрка не работает
                //
                // Этот блок защищает от такого сценария.
                $disabledState = $artifacts['redirect_disabled_stage'] ?? [];
                $disabledSnapshots = $disabledState['snapshots'] ?? [];
                $disabledBasePath = $disabledState['base_path'] ?? $basePath;

                if (!empty($disabledSnapshots)) {
                    $log->info('rollback',
                        'Также откатываю redirect_disable snapshot\'ы (снять REFRESH-DISABLED маркеры): ' .
                        implode(', ', array_keys($disabledSnapshots)));
                    try {
                        // ReplacementApplier::rollback универсальный — может откатить любые snapshot'ы
                        // если передать в правильной структуре.
                        $disableRollbackResult = $applier->rollback(
                            (int)$job['site_id'],
                            $jobId,
                            $disabledSnapshots,
                            $log,
                            $disabledBasePath
                        );
                        if (!empty($disableRollbackResult['ok'])) {
                            $log->ok('rollback',
                                '✓ REFRESH-DISABLED маркеры сняты. Восстановлено файлов: ' .
                                count($disableRollbackResult['restored']));
                        } else {
                            $log->warn('rollback',
                                'Откат REFRESH-DISABLED не удался: ' .
                                implode('; ', $disableRollbackResult['errors'] ?? []));
                        }
                    } catch (\Throwable $e) {
                        $log->warn('rollback',
                            'Откат REFRESH-DISABLED упал с exception: ' . $e->getMessage() .
                            '. Файлы могли остаться с префиксами — проверь .htaccess вручную.');
                    }
                } else {
                    $log->info('rollback',
                        'redirect_disable snapshots отсутствуют — пропускаю (видимо disable не выполнялся).');
                }

                // Возвращаем current_domain в БД на старый
                try {
                    DB::pdo()->prepare(
                        "UPDATE sites_managed SET current_domain = ? WHERE id = ?"
                    )->execute([$job['old_domain'], $job['site_id']]);
                } catch (\Throwable $e) {
                    $log->warn('rollback', 'Не удалось вернуть current_domain: ' . $e->getMessage());
                }

                // v18-fix: после rollback'а нужно дать возможность ПОВТОРИТЬ pipeline
                // (а не помечать сразу как failed). Файлы откачены к состоянию ДО
                // config_replaced, значит логически мы вернулись на стадию между
                // ssl_self_signed_first (последняя стадия которая ничего не меняла
                // на сайте) и redirect_disable. Сбрасываем stage на ssl_self_signed_first
                // в статусе ok — следующий тик cron'а через nextStageFor пойдёт в
                // redirect_disable → analyze_site → config_replaced → verify_replacement,
                // как при свежей джобе.
                //
                // ВАЖНО: артефакты verify_stage и config_replaced_stage и т.п. ОЧИЩАЕМ —
                // иначе UI продолжит показывать старые значения (особенно failed_checks
                // от прежней попытки), что создаст путаницу.
                try {
                    // Очистим старые артефакты этих стадий
                    $artifacts = !empty($job['artifacts_json'])
                        ? (json_decode((string)$job['artifacts_json'], true) ?: [])
                        : [];

                    // Очищаем артефакты которые относятся к стадиям ПОСЛЕ ssl_self_signed_first
                    // (они должны переиграться)
                    //
                    // v18.1.16 КОРНЕВОЙ ФИКС: redirect_enabled_stage НУЖНО очищать тоже!
                    // Иначе v18.1.13-skipEnable увидит что в артефактах уже есть
                    // restored_rules от ПРОШЛОЙ попытки и пропустит enable.
                    // Disable отработает заново, поставит =0; // REFRESH-DISABLED,
                    // а enable пропустится и файл останется выключенным.
                    // Это РЕАЛЬНАЯ причина зависания джобы #14.
                    $stagesToClear = [
                        'redirect_disabled_stage',
                        'redirect_enabled_stage',   // v18.1.16: КРИТИЧНО
                        'analyze_stage',
                        'config_replaced_stage',
                        'verify_stage',
                        'ssl_le_stage',
                        'update_classes_stage',
                        'domain_readiness_stage',   // v25.0-a1 (H2): readiness переиграется
                        'wm_added_stage',           // v25.0-b: host polling переиграется
                        'wm_recrawl_stage',         // v25.0-b: recrawl-сводка сбрасывается
                    ];
                    foreach ($stagesToClear as $key) {
                        unset($artifacts[$key]);
                    }
                    // v25.0-b: per-URL recrawl-очередь тоже сбрасываем — она
                    // переигрывается заново при повторном проходе стадии.
                    try {
                        if (class_exists('RecrawlUrlRepository')) {
                            RecrawlUrlRepository::clearForJob($jobId);
                        }
                    } catch (\Throwable $e) {
                        error_log("rollback: recrawl clear failed for job {$jobId}: " . $e->getMessage());
                    }
                    // Помечаем что был rollback (для UI)
                    $artifacts['rollback_history'] = $artifacts['rollback_history'] ?? [];
                    $artifacts['rollback_history'][] = [
                        'at' => date('Y-m-d H:i:s'),
                        'restored_files' => array_keys($snapshots),
                    ];

                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET
                            stage = 'ssl_self_signed_first',
                            stage_status = 'ok',
                            stage_error = NULL,
                            stage_started_at = NULL,
                            stage_finished_at = NOW(),
                            domain_https_ready_at = NULL,
                            domain_readiness_success_streak = 0,
                            php_uniquification_verified_at = NULL,
                            artifacts_json = ?,
                            next_run_at = NOW()
                         WHERE id = ?
                           AND stage NOT IN ('cancelled','superseded')"
                    )->execute([
                        json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        $jobId,
                    ]);

                    $log->info('rollback',
                        'Stage сброшен на ssl_self_signed_first, артефакты verify/config_replaced/ssl_le/update_classes очищены. ' .
                        'Cron подхватит и пойдёт по pipeline заново (redirect_disable → analyze_site → config_replaced → verify_replacement).');
                } catch (\Throwable $e) {
                    $log->warn('rollback', 'Не удалось сбросить stage: ' . $e->getMessage());
                }

                $this->flash('success',
                    'Откат успешен. Восстановлено файлов: ' . count($result['restored']) .
                    '. Pipeline сброшен — cron перезапустит замены через минуту.');

                // v18.1.7: smoke-test после rollback — проверяем что сайт реально отвечает.
                // Файлы откатили, но если есть проблема с opcache / FPM-кешем — сайт может
                // всё равно не работать. Лучше показать оператору сразу.
                $this->runRollbackSmokeTest($job, $log);
            } else {
                $errs = !empty($result['errors']) ? implode('; ', $result['errors']) : 'unknown';
                $log->error('rollback', "Откат не удался: {$errs}");
                $this->flash('error', "Откат не удался: {$errs}");
            }
        } catch (\Throwable $e) {
            $log->error('rollback', 'Exception: ' . $e->getMessage());
            $this->flash('error', 'Откат упал: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v18.1.7: Smoke-test после rollback.
     *
     * После того как файлы восстановлены — проверяем curl'ом что сайт реально отвечает.
     * Это ловит ситуации когда:
     *   - opcache PHP держит старую (битую) версию config.php → нужен restart FPM
     *   - FastPanel cache держит старый redirect → нужен сброс
     *   - Файлы откачены ОК, но что-то ещё (Cloudflare?) держит сломанное состояние
     *
     * Не блокирует rollback (он уже прошёл). Просто добавляет flash с warning'ом.
     *
     * Делаем 2 проверки:
     *   1. Старый домен — должен отвечать 200 (после rollback редирект отключён,
     *      сайт должен показывать контент любому)
     *   2. Новый домен — тоже должен отвечать 200
     *
     * Если хотя бы один проверка падает (timeout/5xx/PHP warnings в HTML) —
     * показываем warning flash с подсказкой про opcache/FPM.
     */
    private function runRollbackSmokeTest(array $job, JobEventLogger $log): void
    {
        $oldDomain = trim((string)($job['old_domain'] ?? ''));
        $newDomain = trim((string)($job['new_domain'] ?? ''));
        if ($oldDomain === '' && $newDomain === '') return;

        $issues = [];
        $checked = [];

        foreach ([$oldDomain, $newDomain] as $domain) {
            if ($domain === '') continue;
            $url = 'https://' . $domain . '/';
            $checked[] = $domain;

            // curl с -k (игнор self-signed), таймаутом 8 сек, follow redirects до 3
            $cmd = sprintf(
                'curl -ksSL --max-redirs 3 -m 8 -w "\n__HTTP_CODE__:%%{http_code}__" %s 2>&1',
                escapeshellarg($url)
            );
            $output = shell_exec($cmd);
            if ($output === null) {
                $issues[] = "{$domain}: curl упал (нет вывода)";
                continue;
            }

            // Извлекаем HTTP-код
            $httpCode = 0;
            if (preg_match('~__HTTP_CODE__:(\d+)__~', $output, $m)) {
                $httpCode = (int)$m[1];
                $output = preg_replace('~\n?__HTTP_CODE__:\d+__\s*$~', '', $output);
            }

            if ($httpCode === 0) {
                $issues[] = "{$domain}: curl не получил ответ (timeout?)";
                continue;
            }
            if ($httpCode >= 500) {
                $issues[] = "{$domain}: HTTP {$httpCode} (server error)";
                continue;
            }
            if ($httpCode >= 400 && $httpCode !== 403) {
                // 403 норм для случаев когда есть IP-фильтрация
                $issues[] = "{$domain}: HTTP {$httpCode}";
                continue;
            }

            // Проверяем что в HTML нет PHP warnings/notices
            // (это типичный признак испорченного config.php или opcache)
            $bodyExcerpt = mb_substr((string)$output, 0, 50000); // первые 50 KB
            $phpProblems = [];
            if (preg_match('~<b>(?:Warning|Notice|Fatal error|Parse error)</b>~i', $bodyExcerpt)) {
                $phpProblems[] = 'PHP warnings/notices в HTML';
            }
            if (stripos($bodyExcerpt, 'Undefined variable') !== false) {
                $phpProblems[] = 'Undefined variable в HTML';
            }
            if (stripos($bodyExcerpt, '<?php') !== false) {
                $phpProblems[] = 'PHP-теги в HTML (PHP не парсит файл)';
            }
            if (!empty($phpProblems)) {
                $issues[] = "{$domain}: HTTP {$httpCode}, но " . implode(', ', $phpProblems);
                continue;
            }

            $log->info('rollback', "Smoke-test ✓ {$domain}: HTTP {$httpCode}");
        }

        if (empty($issues)) {
            $log->ok('rollback',
                "Smoke-test пройден: " . implode(', ', $checked) . " отвечают корректно");
            $this->flash('success',
                "✓ Smoke-test после отката пройден: " . implode(', ', $checked) . " отвечают корректно (HTTP 200, без PHP warnings).");
        } else {
            $log->warn('rollback',
                "Smoke-test НЕ пройден: " . implode('; ', $issues));
            $this->flash('warning',
                "⚠ Откат файлов прошёл успешно, но smoke-test показал проблемы: " .
                implode('; ', $issues) .
                ". Возможно нужен сброс opcache или перезапуск PHP-FPM в FastPanel " .
                "(Серверы → PHP → Перезапустить).");
        }
    }

    /**
     * v18.1.7: Скачать все snapshot'ы джобы как .tar.gz.
     *
     * Полезно если оператор хочет сохранить копию snapshot'ов в безопасное место
     * (другой сервер, локальный диск) — на случай если автоматический rollback
     * не сработает или директория snapshots будет удалена.
     *
     * Стримит .tar.gz прямо в браузер. Файлы берутся из storage/snapshots/job_{id}/.
     */
    public function downloadSnapshots(): void
    {
        $this->requireAuth();
        $jobId = (int)($_GET['id'] ?? 0);
        $job = $this->loadJob($jobId);

        // Найти директорию snapshot'ов
        $artifacts = !empty($job['artifacts_json'])
            ? (json_decode((string)$job['artifacts_json'], true) ?: [])
            : [];

        $snapshotDir = $artifacts['config_replaced_stage']['snapshot_dir'] ?? '';
        $snapshots = $artifacts['config_replaced_stage']['snapshots'] ?? [];

        if ($snapshotDir === '' || empty($snapshots)) {
            $this->flash('error', 'У этой джобы нет snapshot\'ов для скачивания.');
            $this->redirect('/jobs/show?id=' . $jobId);
            return;
        }

        if (!is_dir($snapshotDir)) {
            $this->flash('error',
                'Директория snapshot\'ов не найдена на диске: ' . $snapshotDir .
                '. Возможно она была удалена. Восстановление через панель невозможно — ищи файлы в FastPanel-бэкапах.');
            $this->redirect('/jobs/show?id=' . $jobId);
            return;
        }

        $oldDomain = (string)($job['old_domain'] ?? 'unknown');
        $tarName = "snapshots_job_{$jobId}_" . preg_replace('~[^a-z0-9.-]~i', '_', $oldDomain) .
                   '_' . date('Ymd_His') . '.tar.gz';

        // Создаём tar.gz во временной директории
        $tmpFile = tempnam(sys_get_temp_dir(), 'snap_') . '.tar.gz';
        $cmd = sprintf(
            'cd %s && tar czf %s . 2>&1',
            escapeshellarg($snapshotDir),
            escapeshellarg($tmpFile)
        );
        $output = shell_exec($cmd);

        if (!is_file($tmpFile) || filesize($tmpFile) === 0) {
            @unlink($tmpFile);
            $this->flash('error',
                'Не удалось создать архив: ' . trim((string)$output));
            $this->redirect('/jobs/show?id=' . $jobId);
            return;
        }

        // Стримим в браузер
        header('Content-Type: application/gzip');
        header('Content-Disposition: attachment; filename="' . $tarName . '"');
        header('Content-Length: ' . filesize($tmpFile));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        readfile($tmpFile);
        @unlink($tmpFile);
        exit;
    }

    /**
     * Пользователь нажал "🔁 Повторить SSL polling".
     *
     * Возвращает джобу на стадию ssl_le_polling для новой попытки выпуска LE.
     * Сбрасывает state polling-а в artifacts (cert_id=null, tick_count=0)
     * чтобы при следующем тике запросился НОВЫЙ cert (если предыдущий был
     * stuck) или переиспользовался существующий рабочий.
     *
     * Полезно когда:
     *   - Полная джоба завершилась (done) с self-signed, а LE не выпустился
     *   - Прошло время и DDoS-Guard уже сам мог выпустить cert
     *   - В FP UI вручную довыпущен cert и нужно убедиться что pipeline увидит
     */
    /**
     * Пользователь нажал "🔁 Повторить self-signed".
     *
     * Возвращает джобу на стадию ssl_self_signed_first для новой попытки.
     * Сбрасывает ssl_self_signed_stage в artifacts (старый сохраняется в
     * ssl_self_signed_stage_history[]).
     *
     * Полезно когда:
     *   - При первом проходе self-signed упал (например credentials баг как
     *     в v14b до fix2) — теперь после фикса можно поставить корректно
     *   - Текущий cert повреждён или просрочен и хочется пересоздать
     */
    /**
     * v14i: «🔁 Повторить verify» — для случаев когда verify упал из-за DNS race
     * (new_http: Could not resolve host) и пользователь хочет ещё раз попробовать
     * вместо того чтобы решать через "Я поправил, продолжить" или "Откатить".
     *
     * Возвращает джобу со статуса awaiting_user обратно на verify_replacement
     * с pending — cron подхватит через минуту. Сбрасывает auto_retry_count
     * чтобы при auto-retry заново было 3 попытки.
     */
    public function retryVerify(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        try {
            $artifacts = [];
            if (!empty($job['artifacts_json'])) {
                $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
            }

            // Сбрасываем auto_retry_count в verify_stage чтобы получить ещё 3 попытки
            if (!empty($artifacts['verify_stage'])) {
                $artifacts['verify_stage']['auto_retry_count'] = 0;
            }

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage = 'verify_replacement',
                    stage_status = 'pending',
                    stage_error = NULL,
                    stage_started_at = NULL,
                    stage_finished_at = NULL,
                    next_run_at = NULL,
                    artifacts_json = ?
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId
            ]);

            $log = new JobEventLogger($jobId);
            $log->warn((string)$job['stage'],
                'Пользователь запросил повтор verify. Возврат на verify_replacement, ' .
                'auto_retry_count сброшен. Cron подхватит в течение минуты.');

            $this->flash('success',
                'Стадия verify_replacement будет запущена заново. Cron через минуту.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось перезапустить verify: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    public function retrySelfSigned(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        try {
            $artifacts = [];
            if (!empty($job['artifacts_json'])) {
                $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
            }
            // Сохраняем старый state в history, обнуляем текущий
            if (!empty($artifacts['ssl_self_signed_stage'])) {
                $artifacts['ssl_self_signed_stage_history'][] = $artifacts['ssl_self_signed_stage'];
                $artifacts['ssl_self_signed_stage'] = null;
            }

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage = 'ssl_self_signed_first',
                    stage_status = 'pending',
                    stage_error = NULL,
                    stage_started_at = NULL,
                    stage_finished_at = NULL,
                    next_run_at = NULL,
                    artifacts_json = ?
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId
            ]);

            $log = new JobEventLogger($jobId);
            $log->warn((string)$job['stage'],
                'Пользователь запросил повтор self-signed. Возврат на стадию ssl_self_signed_first. ' .
                'Cron подхватит в течение минуты.');

            $this->flash('success',
                'Стадия ssl_self_signed_first будет запущена заново. ' .
                'Если live cert уже есть на :443 — она пропустится автоматически. ' .
                'Cron подхватит джобу через минуту.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось перезапустить self-signed: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    public function retrySsl(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        // Сбрасываем state polling-а в artifacts чтобы стадия начала заново
        try {
            $artifacts = [];
            if (!empty($job['artifacts_json'])) {
                $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
            }
            // Сохраняем старый state для истории, обнуляем текущий
            if (!empty($artifacts['ssl_le_stage'])) {
                $artifacts['ssl_le_stage_history'][] = $artifacts['ssl_le_stage'];
                $artifacts['ssl_le_stage'] = null;
            }

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage = 'ssl_le_polling',
                    stage_status = 'pending',
                    stage_error = NULL,
                    stage_started_at = NULL,
                    stage_finished_at = NULL,
                    next_run_at = NULL,
                    artifacts_json = ?
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId
            ]);

            $log = new JobEventLogger($jobId);
            $log->warn((string)$job['stage'],
                'Пользователь запросил повтор SSL polling. Возврат на стадию ssl_le_polling, ' .
                'state сброшен. Cron подхватит в течение минуты.');

            $this->flash('success',
                'Стадия ssl_le_polling будет запущена заново. Cron подхватит джобу через минуту.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось перезапустить SSL: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.2-a1.4 (§Блокер 2): «Я исправил проблему — возобновить автоматический
     * выпуск». Под rfp_job_<id>: очищает ssl_le_stage.fatal и связанные поля,
     * ssl_issue_next_poll_at=NOW; stage_status=pending+next_run=NOW если стадия
     * ждёт SSL. ACME-state/cert_id/TXT/resume НЕ сбрасываются.
     */
    public function sslResumeAuto(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);
        $err = $this->assertSslActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) { $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.'); $this->redirect('/jobs/show?id=' . $jobId); }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertSslActionable($fresh)) !== null) { $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId); }
            $this->clearSslFatalFlags($jobId);
            $waitsSsl = in_array((string)$fresh['stage'], ['ssl_le_polling', 'wm_verified', 'trusted_ssl_gate'], true); // P0 §4.6: «Проверить SSL сейчас» будит и trusted_ssl_gate
            if ($waitsSsl) {
                DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL, ssl_issue_next_poll_at=NOW(), next_run_at=NOW() WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
            } else {
                DB::pdo()->prepare("UPDATE refresh_jobs SET ssl_issue_next_poll_at=NOW() WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
            }
            (new JobEventLogger($jobId))->ok((string)$fresh['stage'], 'Оператор возобновил автоматический выпуск SSL (fatal очищен). Reconciler подхватит джобу.');
            $this->flash('success', 'Автоматический выпуск SSL возобновлён — reconciler запустит выпуск в течение минуты.');
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /** v25.2-a1.4: очистить SSL-fatal/skip флаги в artifacts (для возобновления). */
    private function clearSslFatalFlags(int $jobId): void
    {
        try {
            // JSON_MERGE_PATCH с null-членами УДАЛЯЕТ ключи (портируемо в MariaDB),
            // сохраняя cert_id/ACME-state. CAST(? AS JSON) в этой версии не поддержан.
            $nullPatch = ['ssl_le_stage' => [
                'fatal' => null, 'fatal_reason' => null, 'fatal_message' => null, 'fatal_at' => null,
                'skipped_by_operator' => null, 'skipped_at' => null, 'skipped_by' => null,
                'skip_comment' => null, 'last_alert_key' => null,
            ]];
            DB::pdo()->prepare("UPDATE refresh_jobs SET artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id=?")
                ->execute([json_encode($nullPatch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
        } catch (\Throwable $e) { /* best-effort */ }
    }

    /**
     * v25.2-a1.3 (§Пункт 3): «Я установил сертификат вручную — проверить».
     * Под настоящим rfp_job_<id>: строгая TLS-проверка; trusted+hostname_valid →
     * сохранить SSL result, очистить transient SSL error, pending+next_run=NOW.
     * Не считаем успех слепо: при непрохождении — точная причина, фон продолжает.
     */
    public function sslVerifyInstalled(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);
        $err = $this->assertSslActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) {
            $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertSslActionable($fresh)) !== null) { $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId); }
            $domain = trim((string)$fresh['new_domain']);
            $siteId = (int)$fresh['site_id'];
            $log = new JobEventLogger($jobId);

            $check = new DomainSslCheckService();
            $r = $check->check($domain, $siteId, $jobId, null, 'manual_operator');
            (new DomainSslStatusRepository())->saveResult($r);

            $isTrusted = (($r['status'] ?? '') === DomainSslCheckService::S_TRUSTED)
                && !empty($r['hostname_valid']) && empty($r['is_self_signed']);
            if ($isTrusted) {
                // §Блокер 2: при ручном trusted очищаем старые fatal/skip флаги.
                $this->clearSslFatalFlags($jobId);
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL, next_run_at=NOW()
                      WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([$jobId]);
                $log->ok((string)$fresh['stage'], 'Оператор: ручная проверка SSL — trusted подтверждён, pipeline продолжает работу.');
                $this->flash('success', 'SSL trusted подтверждён вручную — джоба продолжит выполнение.');
            } else {
                // §Блокер 2: текст зависит от фактического состояния fatal/skip.
                $arts = json_decode((string)($fresh['artifacts_json'] ?? ''), true) ?: [];
                $sle = $arts['ssl_le_stage'] ?? [];
                $reason = (string)($r['reason'] ?? ($r['status'] ?? 'не trusted'));
                if (!empty($sle['fatal'])) {
                    $tail = 'Автоматический выпуск остановлен (fatal). Исправьте проблему и нажмите «Возобновить автоматический выпуск».';
                } elseif (!empty($sle['skipped_by_operator'])) {
                    $tail = 'Автоматический выпуск пропущен оператором.';
                } else {
                    $tail = 'Автоматический выпуск продолжается в фоне.';
                }
                $log->warn((string)$fresh['stage'], 'Оператор: ручная проверка SSL не прошла (' . $reason . '). ' . $tail);
                $this->flash('warning', 'Проверка показала: ' . $reason . '. ' . $tail);
            }
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.2-a1.3 (§Пункт 3): «Проверить SSL сейчас». ssl_issue_next_poll_at=NOW;
     * next_run_at=NOW только если текущая стадия ждёт SSL. НЕ сбрасывает ACME-state.
     */
    public function sslCheckNow(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);
        $err = $this->assertSslActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }
        // v25.2-a1.4: под настоящим rfp_job_<id>, чтобы ручной NOW() не потерялся в гонке с cron.
        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) { $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.'); $this->redirect('/jobs/show?id=' . $jobId); }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertSslActionable($fresh)) !== null) { $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId); }
            $waitsSsl = in_array((string)$fresh['stage'], ['ssl_le_polling', 'wm_verified', 'trusted_ssl_gate'], true); // P0 §4.6: «Проверить SSL сейчас» будит и trusted_ssl_gate
            if ($waitsSsl) {
                DB::pdo()->prepare("UPDATE refresh_jobs SET ssl_issue_next_poll_at=NOW(), next_run_at=NOW() WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
            } else {
                DB::pdo()->prepare("UPDATE refresh_jobs SET ssl_issue_next_poll_at=NOW() WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
            }
            (new JobEventLogger($jobId))->info((string)$fresh['stage'], 'Оператор запросил внеочередную проверку SSL (ACME-state сохранён).');
            $this->flash('success', 'Проверка SSL запланирована немедленно — обновите страницу через несколько секунд.');
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.2-a1.3 (§Пункт 3): «Пропустить SSL» — отдельный маршрут (не generic
     * skipStage). Требует подтверждение+комментарий; пишет skipped_by_operator в
     * artifacts + event log; SSL больше не блокирует джобу.
     */
    public function sslSkip(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $comment = trim((string)($_POST['comment'] ?? ''));
        $job = $this->loadJob($jobId, true);
        // P0 §4.6: «Пропустить SSL» не может открыть дорогу в Webmaster —
        // на стадии trusted_ssl_gate пропуск запрещён; ручного «считать SSL
        // доверенным» без реальной публичной проверки не существует.
        if ((string)($job['stage'] ?? '') === 'trusted_ssl_gate') {
            $this->flash('warning', 'Стадию публичного trusted-SSL gate пропустить нельзя: вход в Webmaster с недоверенным сертификатом запрещён. Дождитесь выпуска сертификата или используйте «Проверить SSL сейчас».');
            $this->redirect('/jobs/show?id=' . $jobId);
        }
        $err = $this->assertSslActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }
        if (mb_strlen($comment) < 3) { $this->flash('warning', 'Пропуск SSL требует комментарий (причину).'); $this->redirect('/jobs/show?id=' . $jobId); }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) { $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.'); $this->redirect('/jobs/show?id=' . $jobId); }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertSslActionable($fresh)) !== null) { $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId); }
            $operator = RelocationService::currentUser();
            $stage = (string)$fresh['stage'];
            // a1.6 §7: закрываем ТОЛЬКО ssl_gate. Стадия wm_verified завершится сама,
            // когда закроется и webmaster_gate (verified/skip) — логика в оркестраторе.
            $patch = ['ssl_le_stage' => [
                'skipped_by_operator' => true, 'skipped_at' => date('Y-m-d H:i:s'),
                'skipped_by' => $operator, 'skip_comment' => mb_substr($comment, 0, 500),
            ]];
            if ($stage === 'ssl_le_polling') {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage_status='ok', stage_finished_at=NOW(), stage_error=NULL, next_run_at=NOW(),
                        artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                      WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
                (new JobEventLogger($jobId))->warn($stage, 'Оператор ПРОПУСТИЛ SSL (' . mb_substr($comment, 0, 120) . '). Сайт может остаться с недоверенным сертификатом.');
                $this->flash('success', 'SSL пропущен по решению оператора. Мониторинг SSL домена продолжится отдельно.');
            } else {
                // wm_verified: закрываем ssl_gate, стадия идёт дальше своим ходом
                // (webmaster-контур продолжается; стадия завершится по обоим gate).
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL, next_run_at=NOW(),
                        artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                      WHERE id=? AND stage='wm_verified' AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
                (new JobEventLogger($jobId))->warn($stage, 'Оператор ПРОПУСТИЛ SSL (' . mb_substr($comment, 0, 120) . '). ssl_gate закрыт; Webmaster-контур продолжается.');
                $this->flash('success', 'SSL пропущен. Webmaster-верификация продолжается; стадия завершится после её подтверждения.');
            }
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v25.2-a1.3 (§Пункт 4): «Я подтвердил права вручную — проверить» (Webmaster).
     * Внеочередной poll (без повторного submit). walker сам пропустит сделанные подэтапы.
     */
    public function wmVerifyManual(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);
        $err = $this->assertWmVerifiedActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) { $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.'); $this->redirect('/jobs/show?id=' . $jobId); }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertWmVerifiedActionable($fresh)) !== null) { $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId); }
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL, next_run_at=NOW()
                  WHERE id=? AND stage='wm_verified' AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            (new JobEventLogger($jobId))->info('wm_verified', 'Оператор: ручная проверка подтверждения — внеочередной poll (без повторного submit).');
            $this->flash('success', 'Проверка статуса Webmaster запущена — обновите страницу через несколько секунд.');
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /** v25.2-a1.3 (§Пункт 4): «Проверить статус сейчас» (Webmaster) — только next_run=NOW. */
    public function wmVerifiedCheckNow(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);
        $err = $this->assertWmVerifiedActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }
        // v25.2-a1.4: под настоящим rfp_job_<id>.
        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) { $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.'); $this->redirect('/jobs/show?id=' . $jobId); }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertWmVerifiedActionable($fresh)) !== null) { $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId); }
            DB::pdo()->prepare("UPDATE refresh_jobs SET next_run_at=NOW() WHERE id=? AND stage='wm_verified' AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
            (new JobEventLogger($jobId))->info('wm_verified', 'Оператор запросил внеочередную проверку статуса Webmaster.');
            $this->flash('success', 'Проверка статуса запланирована немедленно.');
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /** v25.2-a1.3 (§Пункт 4): «Пропустить подтверждение Webmaster» — с комментарием и audit log. */
    public function wmVerifiedSkip(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $comment = trim((string)($_POST['comment'] ?? ''));
        $job = $this->loadJob($jobId, true);
        $err = $this->assertWmVerifiedActionable($job);
        if ($err !== null) { $this->flash('warning', $err); $this->redirect('/jobs/show?id=' . $jobId); }
        if (mb_strlen($comment) < 3) { $this->flash('warning', 'Пропуск подтверждения требует комментарий (причину).'); $this->redirect('/jobs/show?id=' . $jobId); }

        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) { $this->flash('warning', 'Джоба обрабатывается. Повторите через ~30 сек.'); $this->redirect('/jobs/show?id=' . $jobId); }
        try {
            $fresh = $this->loadJob($jobId, true);
            if (($e = $this->assertWmVerifiedActionable($fresh)) !== null) { $this->flash('warning', $e); $this->redirect('/jobs/show?id=' . $jobId); }
            $operator = RelocationService::currentUser();
            // a1.6 §7: закрываем ТОЛЬКО webmaster_gate. Стадию НЕ форсим в ok —
            // оркестратор завершит её, когда закроется и ssl_gate (trusted/skip).
            $patch = ['wm_verified_stage' => [
                'skipped_by_operator' => true,
                'skipped_at' => date('Y-m-d H:i:s'),
                'skipped_by' => $operator,
                'skip_comment' => mb_substr($comment, 0, 500),
            ]];
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL, next_run_at=NOW(),
                    artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                  WHERE id=? AND stage='wm_verified' AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
            (new JobEventLogger($jobId))->warn('wm_verified', 'Оператор ПРОПУСТИЛ подтверждение Webmaster (' . mb_substr($comment, 0, 120) . '). webmaster_gate закрыт; стадия завершится после trusted SSL.');
            $this->flash('success', 'Подтверждение Webmaster пропущено. Стадия завершится после готовности SSL (или его пропуска).');
        } finally { $guard->releaseJobLock(); }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /** v25.2-a1.3: SSL-действие применимо, если джоба на SSL-ожидающей стадии и не терминальна. */
    private function assertSslActionable(array $job): ?string
    {
        if (JobLifecycleService::isTerminal((string)$job['stage'])) return 'Джоба уже завершена — действие недоступно.';
        // P0 §4.6: «Проверить SSL сейчас»/«возобновить выпуск» работают и на стадии
        // публичного trusted-SSL gate (ставят ближайший poll).
        if (!in_array((string)$job['stage'], ['ssl_le_polling', 'wm_verified', 'trusted_ssl_gate'], true)) {
            return 'Действие доступно только пока джоба ожидает SSL (ssl_le_polling / trusted_ssl_gate / wm_verified).';
        }
        return null;
    }

    /** v25.2-a1.3: WM-verified-действие применимо, если джоба на wm_verified и не терминальна. */
    private function assertWmVerifiedActionable(array $job): ?string
    {
        if (JobLifecycleService::isTerminal((string)$job['stage'])) return 'Джоба уже завершена — действие недоступно.';
        if ((string)$job['stage'] !== 'wm_verified') return 'Действие доступно только на стадии подтверждения Webmaster (wm_verified).';
        return null;
    }

    /**
     * v17.1: перезапустить index_watching с нуля.
     * Обнуляет state, ставит стадию = index_watching, status = pending.
     * Cron подхватит и заново начнёт 30-минутный polling.
     */
    public function retryIndexWatching(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        // v18.1.21: разрешаем перезапуск из любой стадии (включая done) —
        // иногда оператор хочет повторно отследить когда сайт попадёт в индекс,
        // даже если джоба формально завершилась.
        try {
            $artifacts = [];
            if (!empty($job['artifacts_json'])) {
                $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
            }
            // Сохраняем старый state как history
            if (!empty($artifacts['index_watching_stage'])) {
                $artifacts['index_watching_stage_history'][] = $artifacts['index_watching_stage'];
                $artifacts['index_watching_stage'] = null;
            }

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage = 'index_watching',
                    stage_status = 'pending',
                    stage_error = NULL,
                    stage_started_at = NULL,
                    stage_finished_at = NULL,
                    next_run_at = NULL,
                    artifacts_json = ?
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId
            ]);

            $log = new JobEventLogger($jobId);
            $log->warn((string)$job['stage'],
                'Оператор перезапустил мониторинг индексации. State сброшен, новый 30-мин polling начнётся.');

            $this->flash('success',
                'Мониторинг индексации перезапущен. Cron подхватит через минуту.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось перезапустить мониторинг индексации: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v18.1.23: перезапустить финальный мониторинг (move-режимы).
     *
     * Объединяет старые retryMovePolling + retryIndexWatching для move-джоб:
     * новая стадия final_monitoring параллельно проверяет (а) индексацию и
     * (б) статус переезда. Возврат на эту стадию из любой точки — включая
     * done/failed/awaiting_user.
     */
    public function retryFinalMonitoring(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        $mode = (string)($job['mode'] ?? 'refresh');
        if ($mode !== 'move_indexed' && $mode !== 'move_simple') {
            $this->flash('error',
                'Финальный мониторинг доступен только для move-режимов. ' .
                'Текущий режим: ' . JobEventLogger::modeLabel($mode));
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        try {
            $artifacts = [];
            if (!empty($job['artifacts_json'])) {
                $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
            }
            // Сохраняем старый state в history (на случай если хотим увидеть что было)
            if (!empty($artifacts['final_monitoring_stage'])) {
                $artifacts['final_monitoring_stage_history'][] = $artifacts['final_monitoring_stage'];
                $artifacts['final_monitoring_stage'] = null;
            }
            // Также чистим устаревшие стейты index_watching/move_poll_status,
            // чтобы новые тики не путали оператора старыми данными.
            if (!empty($artifacts['index_watching_stage'])) {
                $artifacts['index_watching_stage_history'][] = $artifacts['index_watching_stage'];
                $artifacts['index_watching_stage'] = null;
            }
            if (!empty($artifacts['move_poll_status_stage'])) {
                $artifacts['move_poll_status_stage_history'][] = $artifacts['move_poll_status_stage'];
                $artifacts['move_poll_status_stage'] = null;
            }

            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage = 'final_monitoring',
                    stage_status = 'pending',
                    stage_error = NULL,
                    stage_started_at = NULL,
                    stage_finished_at = NULL,
                    next_run_at = NULL,
                    artifacts_json = ?
                 WHERE id = ?
                   AND stage NOT IN ('cancelled','superseded')"
            )->execute([
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId
            ]);

            $log = new JobEventLogger($jobId);
            $log->warn((string)$job['stage'],
                'Оператор перезапустил финальный мониторинг (final_monitoring). ' .
                'Стейт сброшен, polling начнётся заново. Проверяются ОБА сигнала: индекс + статус переезда.');

            $this->flash('success',
                'Финальный мониторинг перезапущен. Cron подхватит через минуту, проверяются индексация и переезд параллельно.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось перезапустить финальный мониторинг: ' . $e->getMessage());
        }

        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /**
     * v18.1.21 — DEPRECATED с v18.1.23.
     * Старая отдельная кнопка «Перезапустить мониторинг переезда».
     * Теперь move-джобы должны использовать retryFinalMonitoring (final_monitoring
     * заменяет отдельные index_watching + move_poll_status).
     * Метод оставлен для совместимости со старыми ссылками.
     */
    public function retryMovePolling(): void
    {
        $this->requireAuth();
        $jobId = (int)($_POST['id'] ?? 0);
        $job = $this->loadJob($jobId, true);

        $mode = (string)($job['mode'] ?? 'refresh');
        if ($mode !== 'move_indexed' && $mode !== 'move_simple') {
            $this->flash('error',
                'Мониторинг переезда доступен только для move-режимов. ' .
                'Текущий режим: ' . JobEventLogger::modeLabel($mode));
            $this->redirect('/jobs/show?id=' . $jobId);
        }

        // v18.1.23: проксируем на финальный мониторинг
        $_POST['id'] = $jobId;
        $this->retryFinalMonitoring();
    }

    /**
     * @param bool $requireResumable v24: для действий, способных возобновить джобу
     *        (retry, runStep, acknowledgeDelurl и т. п.). Терминальные джобы
     *        (cancelled / superseded) возобновлению не подлежат.
     */
    /**
     * v24: экран конфликта — у сайта уже есть незавершённая джоба.
     */
    public function conflict(): void
    {
        $this->requireAuth();
        $siteId = (int)($_GET['site_id'] ?? 0);
        $jobId  = (int)($_GET['job_id'] ?? 0);

        // v24.2 (H1): параметры исходного запуска, пронесённые из /jobs/start.
        // Оператор выбирал их на карточке сайта — экран конфликта показывает
        // и передаёт дальше именно их, а не молчаливые дефолты.
        $modeRaw = (string)($_GET['mode'] ?? 'refresh');
        $mode = in_array($modeRaw, JobLifecycleService::ALLOWED_MODES, true)
            ? $modeRaw : 'refresh';
        $wmOverride = (int)($_GET['wm_override'] ?? 0);
        if ($wmOverride < 1) $wmOverride = 0;
        $scheduleAtRaw = trim((string)($_GET['schedule_at'] ?? ''));
        $sched = $this->parseScheduleAt($scheduleAtRaw);
        // Ошибку формата не считаем фатальной для экрана конфликта:
        // покажем предупреждение, параметр в форму не пронесём.
        $scheduleWarning = $sched['error'];
        if ($sched['error'] !== null) $scheduleAtRaw = '';

        // Подпись WM-аккаунта для отображения (если override задан)
        $wmLabel = '';
        if ($wmOverride > 0) {
            try {
                $stw = DB::pdo()->prepare(
                    "SELECT label, email FROM yandex_webmaster_accounts WHERE id = ?");
                $stw->execute([$wmOverride]);
                $acc = $stw->fetch();
                if ($acc) {
                    $wmLabel = (string)($acc['label'] ?: $acc['email'] ?: '');
                } else {
                    // Аккаунт удалили, пока оператор ходил по экранам —
                    // не проносим несуществующий id дальше.
                    $scheduleWarning = trim(($scheduleWarning ?? '') === ''
                        ? "Webmaster-аккаунт #{$wmOverride} не найден — override сброшен."
                        : $scheduleWarning . " Webmaster-аккаунт #{$wmOverride} не найден — override сброшен.");
                    $wmOverride = 0;
                }
            } catch (\Throwable $e) {
                $wmOverride = 0;
            }
        }

        $st = DB::pdo()->prepare(
            "SELECT j.*, s.current_domain
               FROM refresh_jobs j
               LEFT JOIN sites_managed s ON s.id = j.site_id
              WHERE j.id = ?"
        );
        $st->execute([$jobId]);
        $job = $st->fetch();

        if (!$job) {
            $this->flash('error', 'Конфликтующая джоба не найдена');
            $this->redirect('/sites');
        }

        $closable = JobLifecycleService::isClosable($job);
        $await = null;
        if ((string)$job['stage_status'] === 'awaiting_user') {
            $d = AwaitingActionService::describeExpectedAction(
                (string)$job['stage'], (string)($job['stage_error'] ?? '')
            );
            $waited = strtotime((string)($job['updated_at'] ?? '')) ?: time();
            $await = [
                'action'  => $d['action'],
                'hint'    => $d['hint'],
                'waiting' => AwaitingActionService::humanDuration(time() - $waited),
            ];
        }

        $this->view('jobs/conflict', [
            'job'      => $job,
            'siteId'   => $siteId,
            'mode'     => $mode,
            'closable' => $closable,
            'await'    => $await,
            // v24.2 (H1)
            'wmOverride'      => $wmOverride,
            'wmLabel'         => $wmLabel,
            'scheduleAtRaw'   => $scheduleAtRaw,
            'scheduleDisplay' => $sched['display'],
            'scheduleWarning' => $scheduleWarning,
        ]);
    }

    /**
     * v24: закрыть старую джобу и создать новую — атомарно.
     */
    public function supersede(): void
    {
        $this->requireAuth();
        $oldJobId = (int)($_POST['old_job_id'] ?? 0);
        $comment  = trim((string)($_POST['comment'] ?? ''));

        // v24.2 (H2): whitelist режима на сервере. Сервис проверит ещё раз
        // (defense in depth), но здесь оператор получает внятную ошибку
        // с возвратом на экран конфликта, а не общий отказ.
        $modeRaw = (string)($_POST['mode'] ?? 'refresh');
        if (!in_array($modeRaw, JobLifecycleService::ALLOWED_MODES, true)) {
            $this->flash('error', 'Недопустимый режим новой джобы: ' . $modeRaw);
            $this->redirect('/jobs/conflict?site_id=' . (int)($_POST['site_id'] ?? 0)
                . '&job_id=' . $oldJobId);
        }
        $mode = $modeRaw;

        // v24.2 (H1): параметры исходного запуска — WM override и отложенный
        // старт — переживают конфликтный сценарий и валидируются заново.
        $wmOverride = (int)($_POST['webmaster_account_override_id'] ?? 0);
        if ($wmOverride > 0) {
            $stw = DB::pdo()->prepare("SELECT id FROM yandex_webmaster_accounts WHERE id = ?");
            $stw->execute([$wmOverride]);
            if (!$stw->fetchColumn()) {
                $this->flash('error', "Webmaster-аккаунт #{$wmOverride} не найден");
                $this->redirect('/jobs/conflict?site_id=' . (int)($_POST['site_id'] ?? 0)
                    . '&job_id=' . $oldJobId . '&mode=' . urlencode($mode));
            }
        } else {
            $wmOverride = null;
        }

        $scheduleAtRaw = trim((string)($_POST['schedule_at'] ?? ''));
        $sched = $this->parseScheduleAt($scheduleAtRaw);
        if ($sched['error'] !== null) {
            $this->flash('error', $sched['error']);
            $this->redirect('/jobs/conflict?site_id=' . (int)($_POST['site_id'] ?? 0)
                . '&job_id=' . $oldJobId . '&mode=' . urlencode($mode)
                . ($wmOverride !== null ? '&wm_override=' . (int)$wmOverride : ''));
        }

        $old = $this->loadJob($oldJobId);
        $siteId = (int)$old['site_id'];

        $site = $this->loadSite($siteId);
        if (!$site) {
            $this->flash('error', 'Сайт не найден');
            $this->redirect('/jobs');
        }

        // Параметры новой джобы собираем ДО транзакции: внутри неё
        // никаких внешних обращений быть не должно.
        $config = [];
        try {
            $config = json_decode((string)($site['config_parsed_json'] ?? ''), true) ?: [];
        } catch (\Throwable $e) {
            $config = [];
        }

        $oldSubId = '';
        $newSubId = '';
        try {
            $mask = DomainMaskService::forSite($site);
            $info = $mask->extractSubIdFromConfig($config);
            $oldSubId = (string)$info['sub_id'];
            if ($oldSubId !== '') $newSubId = $mask->nextSubId($oldSubId);
        } catch (\Throwable $e) {
            // sub_id не критичен для создания джобы
        }

        $maskSnapshot = [];
        try {
            $maskSnapshot = DomainMaskService::forSite($site)->snapshotPayload();
        } catch (\Throwable $e) {
            $maskSnapshot = [];
        }

        $res = JobLifecycleService::supersedeAndCreate(
            $oldJobId,
            [
                'site_id'    => $siteId,
                'old_domain' => (string)$site['current_domain'],
                'old_sub_id' => $oldSubId,
                'new_sub_id' => $newSubId,
                // v24.2 (H1): параметры исходного запуска, подтверждённые
                // оператором на экране конфликта.
                'webmaster_account_override_id' => $wmOverride,
                'mode'       => $mode,
                'next_run_at'=> $sched['sql'],
                'artifacts_json' => json_encode(
                    ['mask_options_snapshot' => $maskSnapshot],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                ),
            ],
            RelocationService::currentUser(),
            $comment
        );

        if (empty($res['ok'])) {
            $this->flash('error', 'Замена не выполнена: ' . $res['error']);
            $this->redirect('/jobs/conflict?site_id=' . $siteId . '&job_id=' . $oldJobId
                . '&mode=' . urlencode($mode)
                . ($wmOverride !== null ? '&wm_override=' . (int)$wmOverride : '')
                . ($scheduleAtRaw !== '' ? '&schedule_at=' . urlencode($scheduleAtRaw) : ''));
        }

        // v22: учёт переезда для move-режимов — уже ПОСЛЕ коммита.
        $relocWarn = '';
        if (in_array($mode, RelocationService::MOVE_MODES, true)) {
            try {
                RelocationService::createForJob((int)$res['new_job_id'], RelocationService::currentUser());
            } catch (\Throwable $e) {
                // v24.3 (H3): переезд старой джобы уже автоотменён в транзакции,
                // а записи для новой не появилось — молчать нельзя, иначе
                // move-джоба уйдёт в работу невидимой для раздела «Переезды».
                error_log('supersede: createForJob failed: ' . $e->getMessage());
                $relocWarn = 'Новая джоба создана, но запись в разделе «Переезды» '
                    . 'не появилась: ' . $e->getMessage()
                    . '. Проверьте миграцию 023; запись можно досоздать через '
                    . 'bin/backfill_relocations.php.';
            }
        }
        if ($relocWarn !== '') {
            $this->flash('warning', $relocWarn);
        }

        $paramNote = '';
        if ($wmOverride !== null) $paramNote .= " WM override #{$wmOverride}.";
        if ($sched['display'] !== null) $paramNote .= " ⏰ Старт: {$sched['display']}.";

        $this->flash('success', !empty($res['already'])
            ? ('Замена уже была выполнена ранее — открыта джоба #' . (int)$res['new_job_id'])
            : ('Старая джоба #' . $oldJobId . ' закрыта, создана новая #'
               . (int)$res['new_job_id'] . '.' . $paramNote));
        $this->redirect('/jobs/show?id=' . (int)$res['new_job_id']);
    }

    /**
     * v24: ручная отмена джобы без создания новой.
     */
    public function cancelJob(): void
    {
        $this->requireAuth();
        $jobId   = (int)($_POST['job_id'] ?? 0);
        $comment = (string)($_POST['comment'] ?? '');

        $res = JobLifecycleService::cancel($jobId, $comment, RelocationService::currentUser());

        if (empty($res['ok'])) {
            $this->flash('error', 'Отмена не выполнена: ' . $res['error']);
        } else {
            $this->flash('success', 'Джоба #' . $jobId . ' отменена. Сайт освобождён для новых джоб.');
        }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

    /** v24: строка сайта для сборки параметров новой джобы. */
    private function loadSite(int $siteId): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$siteId]);
        $row = $st->fetch();
        return is_array($row) ? $row : null;
    }

    private function loadJob(int $id, bool $requireResumable = false): array
    {
        if ($id <= 0) {
            $this->flash('error', 'Джоба не найдена');
            $this->redirect('/jobs');
        }
        $st = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE id=?");
        $st->execute([$id]);
        $job = $st->fetch();
        if (!$job) {
            $this->flash('error', 'Джоба не найдена');
            $this->redirect('/jobs');
        }

        // v24: закрытую джобу нельзя возобновить никаким действием.
        if ($requireResumable) {
            $deny = JobLifecycleService::denyResumeReason($job);
            if ($deny !== null) {
                $this->flash('error', $deny);
                $this->redirect('/jobs/show?id=' . $id);
            }
        }
        return $job;
    }

    /**
     * HOTFIX «Завершить джобу вручную» — POST /jobs/manual-complete.
     * POST-only (route), CSRF, authorization (requireAuth). Backend — источник истины:
     * eligibility и завершение выполняются в сервисе под lock/транзакцией с повторной
     * проверкой. Из запроса принимаются ТОЛЬКО job_id и comment (не status/stage/operator/
     * skipped/timestamp). Отдаёт JSON.
     */
    public function manualComplete(): void
    {
        $this->requireAuth();
        $this->requireCsrf();

        $jobId    = (int)($_POST['job_id'] ?? $_POST['id'] ?? 0);
        $comment  = (string)($_POST['comment'] ?? '');
        // Оператор — строковый логин панели (RelocationService::currentUser / $_SESSION['user']).
        $operator = (string)(RelocationService::currentUser() ?? ($_SESSION['user'] ?? $_SESSION['login'] ?? ''));

        if ($jobId <= 0) { $this->jsonErr('bad_job_id', 400); }

        // Backend re-check под lock/транзакцией. Реальный pipeline режима джобы —
        // чтобы список пропущенных стадий соответствовал refresh/move.
        $eventSink = function (int $jid, string $evt, string $stage, string $msg, array $payload): void {
            (new JobEventLogger($jid))->info($stage, $msg, ['event' => $evt] + $payload);
        };
        $pipelineProvider = function (array $job): array {
            return RefreshOrchestrator::pipelineStagesFor((string)($job['mode'] ?? 'refresh'), false);
        };
        $svc = new ManualJobCompletionService(DB::pdo(), new ManualJobCompletionEligibility(), $eventSink, $pipelineProvider);
        $res = $svc->complete($jobId, $operator, $comment);

        if (!empty($res['ok'])) {
            $this->jsonOk([
                'already_completed' => (bool)($res['already_completed'] ?? false),
                'already_terminal'  => (bool)($res['already_terminal'] ?? false),
                'completion_mode'   => $res['completion_mode'] ?? null,
                'skipped_stages'    => $res['skipped_stages'] ?? [],
            ]);
        }
        // отказ: 409 (not allowed) / 422 (comment) / 404 / 500
        $code = (int)($res['http'] ?? 400);
        header('Content-Type: application/json; charset=utf-8');
        http_response_code($code);
        echo json_encode([
            'ok'      => false,
            'code'    => $res['code'] ?? 'manual_completion_error',
            'reasons' => $res['reasons'] ?? [],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    /**
     * ТЗ044 §12.4 (BLOCKER 5) — «🛠 Восстановить джобу без повторной покупки».
     * Использует тот же JobRecoveryService, что и CLI. Без confirm — показывает dry-run
     * предпросмотр (live read-only факты). С confirm=1 — применяет (возврат на analyze_site,
     * domains.create НИКОГДА не вызывается).
     */
    public function recoverJob(): void
    {
        $this->requireAuth();
        $this->requireCsrf(); // P0-1: state-changing POST — обязательный CSRF
        $jobId = (int)($_POST['id'] ?? ($_GET['id'] ?? 0));
        $confirm = (int)($_POST['confirm'] ?? 0) === 1;
        $job = $this->loadJob($jobId, true);

        // P0-3: серверная eligibility (не полагаемся на presentation-layer). Только failed/awaiting_user.
        if (!in_array((string)$job['stage_status'], ['failed', 'awaiting_user'], true)) {
            $this->flash('error', 'Восстановление доступно только для джоб в статусе «ошибка» или «ждёт оператора» '
                . '(сейчас: ' . JobEventLogger::statusLabel((string)$job['stage_status']) . ').');
            $this->redirect('/jobs/show?id=' . $jobId);
            return;
        }

        $svc = new JobRecoveryService(DB::pdo());

        if (!$confirm) {
            // dry-run предпросмотр — без lock, только чтение
            $sib = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE site_id = ?");
            $sib->execute([(int)$job['site_id']]);
            $summary = $svc->recover($job, $sib->fetchAll(), false);
            if (!empty($summary['blocked'])) {
                $extra = isset($summary['conflict_job_id']) ? ' (конфликт с джобой #' . (int)$summary['conflict_job_id'] . ')' : '';
                if (($summary['class'] ?? '') === JobRecoveryService::SUPERSEDED && $summary['newer_job_id']) {
                    $extra .= ' — актуальна джоба #' . (int)$summary['newer_job_id'];
                }
                $this->flash('error', 'Восстановление невозможно: ' . (string)$summary['block_reason'] . $extra);
                $this->redirect('/jobs/show?id=' . $jobId);
                return;
            }
            $_SESSION['recover_preview'][$jobId] = $summary;
            $this->flash('info', 'Предпросмотр восстановления джобы #' . $jobId
                . ': класс «' . (string)$summary['class'] . '», возврат на «' . (string)$summary['return_stage']
                . '», повторная покупка домена ЗАПРЕЩЕНА. Подтвердите, чтобы применить.');
            $this->redirect('/jobs/show?id=' . $jobId . '&recover_preview=1');
            return;
        }

        // P0-2: APPLY строго под per-job lock (rfp_job_<id>), с re-read job/siblings под локом.
        $guard = CronGuard::forJob($jobId);
        if (!$guard->acquireJobLock()) {
            $this->flash('error', 'Джоба сейчас обрабатывается (занят per-job lock). Повторите позже — изменения НЕ внесены.');
            $this->redirect('/jobs/show?id=' . $jobId);
            return;
        }
        try {
            $jobLocked = $this->loadJob($jobId, true); // свежее чтение под локом
            $sib = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE site_id = ?");
            $sib->execute([(int)$jobLocked['site_id']]);
            $applied = $svc->recover($jobLocked, $sib->fetchAll(), true); // внутри: FOR UPDATE + CAS + rowCount==1
        } finally {
            $guard->releaseJobLock();
        }

        unset($_SESSION['recover_preview'][$jobId]);
        if (!empty($applied['applied'])) {
            $this->flash('success', 'Джоба #' . $jobId . ' восстановлена без повторной покупки: '
                . 'возврат на «' . (string)$applied['return_stage'] . '», домен НЕ покупался, downstream-артефакты очищены.');
        } else {
            $reason = (string)($applied['block_reason'] ?? 'unknown');
            $this->flash('error', 'Не удалось применить восстановление джобы #' . $jobId . ': ' . $reason . '. Изменения НЕ внесены.');
        }
        $this->redirect('/jobs/show?id=' . $jobId);
    }

}
