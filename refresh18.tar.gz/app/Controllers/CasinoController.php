<?php

/**
 * CasinoController — admin UI для casino-projects в refresh-panel.
 *
 * Маршруты:
 *   GET  /casino                — список проектов
 *   GET  /casino/show?id=X      — детали (sites + runs + events)
 *   POST /casino/delete         — удалить проект (вместе с sites + runs)
 *
 * Это «зеркало» того, что видит пользователь в casino-panel'и, но с возможностью
 * подсмотреть детали для дебага и аудита.
 *
 * Сами «делай» кнопки появятся в B2-B5 (buy/subs/ssl/webmaster/cron).
 */
class CasinoController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        try {
            $rows = CasinoProjectStore::listProjects();
        } catch (Throwable $e) {
            $rows = [];
            $this->flash('error', 'Таблица casino_projects не создана. Применяй миграцию 021.');
        }
        // Подсасываем имя api_client'а для каждой строки
        $apiClients = [];
        try {
            $st = DB::pdo()->query("SELECT id, label, key_prefix FROM api_clients");
            foreach ($st->fetchAll() as $a) $apiClients[(int)$a['id']] = $a;
        } catch (Throwable $e) { /* ok */ }

        $this->view('casino/index', ['rows' => $rows, 'apiClients' => $apiClients]);
    }

    public function show(): void
    {
        $this->requireAuth();
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) { $this->flash('error', 'bad id'); $this->redirect('/casino'); }

        $project = CasinoProjectStore::loadProject($id);
        if (!$project) { $this->flash('error', "Project #$id not found"); $this->redirect('/casino'); }

        $sites = CasinoProjectStore::loadSites($id);
        $runs  = CasinoRunStore::listRunsForProject($id);

        // Сводим имена аккаунтов
        $accountNames = $this->loadAccountNames($project);

        $this->view('casino/show', [
            'project'      => $project,
            'sites'        => $sites,
            'runs'         => $runs,
            'accountNames' => $accountNames,
        ]);
    }

    public function delete(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { $this->flash('error', 'bad id'); $this->redirect('/casino'); }

        try {
            DB::pdo()->beginTransaction();
            $runs = DB::pdo()->prepare("SELECT run_id FROM casino_runs WHERE project_id = ?");
            $runs->execute([$id]);
            foreach ($runs->fetchAll(PDO::FETCH_COLUMN) as $rid) {
                DB::pdo()->prepare("DELETE FROM casino_run_events WHERE run_id = ?")->execute([$rid]);
            }
            DB::pdo()->prepare("DELETE FROM casino_runs WHERE project_id = ?")->execute([$id]);
            DB::pdo()->prepare("DELETE FROM casino_project_sites WHERE project_id = ?")->execute([$id]);
            DB::pdo()->prepare("DELETE FROM casino_projects WHERE id = ?")->execute([$id]);
            DB::pdo()->commit();
            $this->flash('ok', "Project #$id удалён");
        } catch (Throwable $e) {
            DB::pdo()->rollBack();
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/casino');
    }

    private function loadAccountNames(array $project): array
    {
        $out = [];
        try {
            if (!empty($project['webmaster_account_id'])) {
                $st = DB::pdo()->prepare("SELECT label, email FROM yandex_webmaster_accounts WHERE id=?");
                $st->execute([$project['webmaster_account_id']]);
                $r = $st->fetch();
                if ($r) $out['webmaster'] = $r['label'] . ' (' . $r['email'] . ')';
            }
            if (!empty($project['registrar_account_id'])) {
                $st = DB::pdo()->prepare("SELECT api_user, is_sandbox FROM registrar_accounts WHERE id=?");
                $st->execute([$project['registrar_account_id']]);
                $r = $st->fetch();
                if ($r) $out['registrar'] = $r['api_user'] . ($r['is_sandbox'] ? ' (sandbox)' : ' (prod)');
            }
            if (!empty($project['registrar_contact_id'])) {
                $st = DB::pdo()->prepare("SELECT label, env FROM registrar_contacts WHERE id=?");
                $st->execute([$project['registrar_contact_id']]);
                $r = $st->fetch();
                if ($r) $out['contact'] = $r['label'] . ' / ' . $r['env'];
            }
            if (!empty($project['fp_server_id'])) {
                $st = DB::pdo()->prepare("SELECT title, host FROM fastpanel_servers WHERE id=?");
                $st->execute([$project['fp_server_id']]);
                $r = $st->fetch();
                if ($r) $out['fastpanel'] = $r['title'] . ' (' . $r['host'] . ')';
            }
        } catch (Throwable $e) { /* ok */ }
        return $out;
    }
}
