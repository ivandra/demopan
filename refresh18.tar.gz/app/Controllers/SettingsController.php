<?php

class SettingsController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        $tg = (new TelegramService())->getSettings();

        // Migrations status
        $migrator = new Migrator();
        try {
            $applied = $migrator->appliedNames();
        } catch (Throwable $e) {
            $applied = [];
        }
        $list = $migrator->listMigrations();

        // v21: текущие параметры маски генерации (домен / sub_id)
        $maskOpts = (new DomainMaskService())->options();

        $this->view('settings/index', [
            'tg' => $tg,
            'migrations' => $list,
            'applied' => $applied,
            'maskOpts' => $maskOpts,
        ]);
    }

    public function migrate(): void
    {
        $this->requireAuth();
        $migrator = new Migrator();
        $report = $migrator->migrate();
        if (empty($report['ok'])) {
            $this->flash('error', 'Миграции применены частично. Ошибки: ' . implode('; ', $report['errors']));
        } else {
            if (empty($report['ran'])) {
                $this->flash('success', 'Все миграции уже применены');
            } else {
                $this->flash('success', 'Применены миграции: ' . implode(', ', $report['ran']));
            }
        }
        $this->redirect('/settings');
    }

    public function saveTelegram(): void
    {
        $this->requireAuth();
        $svc = new TelegramService();
        $svc->saveSettings([
            'enabled'              => !empty($_POST['enabled']),
            'chat_id'              => (string)($_POST['chat_id'] ?? ''),
            'bot_token'            => (string)($_POST['bot_token'] ?? ''),
            'notify_on_stage_ok'   => !empty($_POST['notify_on_stage_ok']),
            'notify_on_stage_fail' => !empty($_POST['notify_on_stage_fail']),
            'notify_on_done'       => !empty($_POST['notify_on_done']),
            // v14h: фильтры для масштаба
            'min_level'            => (string)($_POST['min_level'] ?? 'milestones'),
            'ok_per_stage_limit'   => (int)($_POST['ok_per_stage_limit'] ?? 1),
            'job_summary_enabled'  => !empty($_POST['job_summary_enabled']),
            // v18.1.28: список @usernames для упоминания в balance-low алертах
            'mention_usernames'    => (string)($_POST['mention_usernames'] ?? ''),
        ]);
        $this->flash('success', 'Настройки Telegram сохранены');
        $this->redirect('/settings');
    }

    /**
     * v18.1.28: сохранение balance threshold'ов.
     * POST поля: namecheap_threshold (USD), xmlstock_threshold (RUB).
     */
    public function saveBalanceThresholds(): void
    {
        $this->requireAuth();
        $nameCheapThr = max(0.0, (float)($_POST['namecheap_threshold'] ?? 100.0));
        $xmlStockThr = max(0.0, (float)($_POST['xmlstock_threshold'] ?? 100.0));
        try {
            DB::pdo()->prepare("UPDATE balance_current SET threshold=?
                WHERE service='namecheap' AND account_label='default'")->execute([$nameCheapThr]);
            DB::pdo()->prepare("UPDATE balance_current SET threshold=?
                WHERE service='xmlstock' AND account_label='default'")->execute([$xmlStockThr]);
            $this->flash('success',
                'Пороги балансов сохранены: Namecheap = $' . number_format($nameCheapThr, 2) .
                ', XMLStock = ' . number_format($xmlStockThr, 2) . ' ₽');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось сохранить пороги: ' . $e->getMessage());
        }
        $this->redirect('/settings');
    }

    /**
     * v18.1.31: настройки поиска доменов при покупке.
     */
    /** v25.2-a1.6.4: настройки авто-закрытия неактивных джоб. */
    public function saveJobsSettings(): void
    {
        $this->requireAuth();
        try {
            AppSettings::setBool('jobs.auto_close_enabled', !empty($_POST['jobs_auto_close_enabled']));
            AppSettings::setInt('jobs.auto_close_days', max(1, min(365, (int)($_POST['jobs_auto_close_days'] ?? 30))));
            AppSettings::setInt('jobs.auto_close_batch', max(1, min(200, (int)($_POST['jobs_auto_close_batch'] ?? 50))));
            AppSettings::setInt('jobs.auto_close_interval_minutes', max(15, min(1440, (int)($_POST['jobs_auto_close_interval_minutes'] ?? 60))));
            $this->flash('success', 'Настройки авто-закрытия джоб сохранены.');
        } catch (\Throwable $e) {
            try { AppSettings::clearCache(); } catch (\Throwable $e3) {}
            $this->flash('error', 'Ошибка сохранения: ' . $e->getMessage());
        }
        $this->redirect('/settings');
    }

    /** v25.1-b (§12): настройки SSL-мониторинга и webmaster verification. */
    public function saveSslSettings(): void
    {
        $this->requireAuth();
        try {
            AppSettings::setBool('ssl.monitor_enabled', !empty($_POST['ssl_monitor_enabled']));
            AppSettings::setInt('ssl.max_checks_per_tick', max(1, min(200, (int)($_POST['ssl_max_checks_per_tick'] ?? 10))));
            AppSettings::setInt('ssl.pending_interval_seconds', max(15, (int)($_POST['ssl_pending_interval_seconds'] ?? 60)));
            AppSettings::setInt('ssl.self_signed_interval_seconds', max(15, (int)($_POST['ssl_self_signed_interval_seconds'] ?? 90)));
            AppSettings::setInt('ssl.trusted_interval_minutes', max(10, (int)($_POST['ssl_trusted_interval_minutes'] ?? 720)));
            AppSettings::setInt('ssl.expiring_days_warning', max(1, (int)($_POST['ssl_expiring_days_warning'] ?? 30)));
            AppSettings::setInt('ssl.expiring_days_critical', max(1, (int)($_POST['ssl_expiring_days_critical'] ?? 7)));
            AppSettings::setInt('ssl.history_retention_days', max(1, (int)($_POST['ssl_history_retention_days'] ?? 90)));
            AppSettings::setInt('wm.verification_warning_minutes', max(1, (int)($_POST['wm_verification_warning_minutes'] ?? 60)));
            $this->flash('success', 'Настройки SSL-мониторинга сохранены.');
        } catch (\Throwable $e) {
            try { AppSettings::clearCache(); } catch (\Throwable $e3) {}
            $this->flash('error', 'Ошибка сохранения: ' . $e->getMessage());
        }
        $this->redirect('/settings');
    }

    public function saveDomainSearchSettings(): void
    {
        $this->requireAuth();

        $perTick = (int)($_POST['candidates_per_tick'] ?? 30);
        $perTick = max(1, min(200, $perTick));

        $maxTotal = (int)($_POST['candidates_max_total'] ?? 200);
        $maxTotal = max(1, min(10000, $maxTotal));

        try {
            $ok1 = AppSettings::setInt('domain.candidates_per_tick', $perTick);
            $ok2 = AppSettings::setInt('domain.candidates_max_total', $maxTotal);
            if ($ok1 && $ok2) {
                $this->flash('success',
                    "Настройки поиска сохранены: за tick — {$perTick}, общий потолок — {$maxTotal}.");
            } else {
                $this->flash('error',
                    'Не удалось сохранить — проверь что миграция 018 (app_settings) применена.');
            }
        } catch (\Throwable $e) {
            // v5 (P7): откат при исключении в любой точке, включая commit().
            try {
                if (DB::pdo()->inTransaction()) DB::pdo()->rollBack();
            } catch (\Throwable $e2) {
                // откат невозможен — сообщаем оператору в основном сообщении
            }
            try { AppSettings::clearCache(); } catch (\Throwable $e3) {}
            $this->flash('error', 'Ошибка сохранения: ' . $e->getMessage());
        }
        $this->redirect('/settings');
    }

    /**
     * v21: параметры генерации домена / sub_id (маска).
     * Единый движок DomainMaskService используется и для домена, и для sub_id.
     */
    public function saveMaskSettings(): void
    {
        $this->requireAuth();

        $strategy = (string)($_POST['mask_strategy'] ?? 'number');
        if (!in_array($strategy, ['number', 'letter'], true)) $strategy = 'number';

        $step = (int)($_POST['mask_step'] ?? 1);
        $step = max(1, min(1000, $step));

        $noDigitStart = (int)($_POST['mask_no_digit_start'] ?? 2);
        $noDigitStart = max(0, min(999999, $noDigitStart));

        $alphabet = strtolower(preg_replace('~[^A-Za-z]~', '', (string)($_POST['mask_letter_alphabet'] ?? '')));
        if ($alphabet === '') $alphabet = 'abcdefghijklmnopqrstuvwxyz';

        $padZeros   = !empty($_POST['mask_pad_zeros']);
        $letterWrap = !empty($_POST['mask_letter_wrap']);
        $syncDomain = !empty($_POST['mask_sync_with_domain']);
        $prefixOn   = !empty($_POST['mask_prefix_enabled']);
        $prefix     = substr((string)preg_replace('~[^A-Za-z0-9_\-]~', '', (string)($_POST['mask_prefix'] ?? '')), 0, 16);

        try {
            // v5 (P7): транзакция ОБЯЗАТЕЛЬНА. Раньше сбой beginTransaction()
            // проглатывался, и девять записей шли без атомарности — при ошибке
            // посередине часть настроек уже была сохранена.
            $pdo = DB::pdo();
            if ($pdo->inTransaction()) {
                throw new \RuntimeException('Транзакция уже открыта — сохранение прервано.');
            }
            if (!$pdo->beginTransaction()) {
                throw new \RuntimeException('Не удалось начать транзакцию — настройки не сохранены.');
            }

            $ok = AppSettings::setRaw('mask.strategy', $strategy)
                && AppSettings::setInt('mask.step', $step)
                && AppSettings::setBool('mask.pad_zeros', $padZeros)
                && AppSettings::setInt('mask.no_digit_start', $noDigitStart)
                && AppSettings::setRaw('mask.letter_alphabet', $alphabet)
                && AppSettings::setBool('mask.letter_wrap', $letterWrap)
                && AppSettings::setBool('mask.sync_with_domain', $syncDomain)
                && AppSettings::setBool('mask.prefix_enabled', $prefixOn)
                && AppSettings::setRaw('mask.prefix', $prefix);

            if ($ok) {
                $pdo->commit();
            } else {
                $pdo->rollBack();
            }
            // Кэш сбрасываем только после завершённой транзакции.
            AppSettings::clearCache();

            if ($ok) {
                // Показываем оператору живой пример на текущих параметрах
                $mask = new DomainMaskService();
                $demo = $mask->subIdForDomain('7k5212', '7k5265.casino');
                $this->flash('success',
                    "Параметры маски сохранены (стратегия: {$strategy}, шаг: {$step}). "
                    . "Пример синхронизации: sub 7k5212 + домен 7k5265 → {$demo}");
            } else {
                $this->flash('error',
                    'Не удалось сохранить — проверь что миграция 018 (app_settings) применена.');
            }
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка сохранения: ' . $e->getMessage());
        }
        $this->redirect('/settings');
    }

    /**
     * v18.1.29: сохранение настроек cron (max_jobs_per_tick и др).
     * Хранится в БД (таблица app_settings), не в config/app.php.
     */
    public function saveCronSettings(): void
    {
        $this->requireAuth();

        $maxJobs = (int)($_POST['max_jobs_per_tick'] ?? 5);
        $maxJobs = max(1, min(50, $maxJobs));

        try {
            $ok = AppSettings::setInt('cron.max_jobs_per_tick', $maxJobs);
            if ($ok) {
                $this->flash('success',
                    "Настройки cron сохранены: за один tick будет обрабатываться до {$maxJobs} джоб параллельно.");
            } else {
                $this->flash('error',
                    'Не удалось сохранить — проверь что миграция 018 применена ' .
                    '(/settings → Применить миграции).');
            }
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка сохранения: ' . $e->getMessage());
        }
        $this->redirect('/settings');
    }

    public function testTelegram(): void
    {
        $this->requireAuth();
        $svc = new TelegramService();
        $ok = $svc->send("✅ <b>Тестовое сообщение из refresh-panel</b>\nДата: " . date('Y-m-d H:i:s'));
        if ($ok) {
            $this->flash('success', 'Тестовое сообщение отправлено');
        } else {
            $this->flash('error', 'Не удалось отправить (проверьте настройки и token/chat_id)');
        }
        $this->redirect('/settings');
    }

    /**
     * v17.1: сохранение настроек xmlstock.com.
     */
    public function saveXmlstock(): void
    {
        $this->requireAuth();

        $enabled = !empty($_POST['enabled']) ? 1 : 0;
        $endpointXml = trim((string)($_POST['endpoint_xml'] ?? 'https://xmlstock.com/yandexlive/xml/'));
        if ($endpointXml === '') $endpointXml = 'https://xmlstock.com/yandexlive/xml/';
        $userId = trim((string)($_POST['user_id'] ?? ''));
        $apiKey = trim((string)($_POST['api_key'] ?? ''));
        $dailyQuota = max(0, (int)($_POST['daily_quota_limit'] ?? 1000));
        // v18.1.28: опциональный balance_endpoint
        $balanceEndpoint = trim((string)($_POST['balance_endpoint'] ?? ''));

        try {
            DB::pdo()->prepare(
                "UPDATE xmlstock_settings SET
                    enabled = ?, endpoint_xml = ?, user_id = ?, api_key = ?,
                    daily_quota_limit = ?, updated_at = NOW()
                 WHERE id = 1"
            )->execute([$enabled, $endpointXml, $userId, $apiKey, $dailyQuota]);

            // v18.1.28: balance_endpoint обновляем отдельно, если колонка есть
            // (миграция 016 могла не примениться на старой БД).
            try {
                $colExists = DB::pdo()->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'xmlstock_settings'
                    AND COLUMN_NAME = 'balance_endpoint'")->fetchColumn();
                if ((int)$colExists > 0) {
                    DB::pdo()->prepare("UPDATE xmlstock_settings SET balance_endpoint = ? WHERE id = 1")
                        ->execute([$balanceEndpoint]);
                }
            } catch (\Throwable $e) {
                // miграция 016 не применена — игнорируем
            }

            $this->flash('success', 'Настройки xmlstock.com сохранены');
        } catch (\Throwable $e) {
            $this->flash('error', 'Не удалось сохранить: ' . $e->getMessage());
        }
        $this->redirect('/settings');
    }

    /**
     * v17.1: тестовый запрос к xmlstock с текущими настройками.
     */
    public function testXmlstock(): void
    {
        $this->requireAuth();

        $testHost = trim((string)($_POST['test_host'] ?? 'yandex.ru'));
        if ($testHost === '') $testHost = 'yandex.ru';

        try {
            $check = new XmlStockIndexCheck();
            if (!$check->isAvailable()) {
                $this->flash('error', 'xmlstock не настроен (enabled=0 или нет ключей)');
                $this->redirect('/settings');
                return;
            }
            // §12: ручной тест ТОЛЬКО через central service (purpose=manual_test, виден на /xmlstock).
            $dom = explode('/', preg_replace('~^https?://~', '', $testHost))[0];
            $exec = (new XmlStockRequestService())->execute(
                new XmlStockRequestContext('manual_test', $dom, null, null, null, null, null, 'operator'));
            if (!empty($exec['ok']) || !empty($exec['replayed'])) {
                $result = (array)($exec['result'] ?? []);
            } else {
                $result = ['ok' => false, 'indexed' => false, 'pages_indexed' => 0, 'method' => 'xmlstock',
                           'error' => (string)($exec['error'] ?? 'usage_unavailable'), 'message' => 'xmlstock ledger unavailable'];
            }

            // Запоминаем результат validation
            DB::pdo()->prepare(
                "UPDATE xmlstock_settings SET
                    last_validated_at = NOW(),
                    last_validation_ok = ?,
                    last_validation_error = ?
                 WHERE id = 1"
            )->execute([
                !empty($result['ok']) ? 1 : 0,
                mb_substr((string)($result['message'] ?? ''), 0, 500),
            ]);

            if (!empty($result['ok'])) {
                $msg = "✅ Тест успешен: {$result['message']}";
                $this->flash('success', $msg);
            } else {
                $msg = "⚠ Ошибка: " . ($result['message'] ?? 'unknown');
                $this->flash('error', $msg);
            }
        } catch (\Throwable $e) {
            $this->flash('error', 'Тест упал: ' . $e->getMessage());
        }
        $this->redirect('/settings');
    }
}
