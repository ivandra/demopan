<?php

class AuthController extends Controller
{
    public function loginForm(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        if (!empty($_SESSION['auth'])) {
            $this->redirect('/');
        }
        $this->viewRaw('auth/login', ['error' => null]);
    }

    public function login(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $u = (string)($_POST['username'] ?? '');
        $p = (string)($_POST['password'] ?? '');

        $cfgU = (string)config('auth.username', '');
        $cfgP = (string)config('auth.password', '');

        if ($u === $cfgU && $p === $cfgP && $cfgU !== '' && $cfgP !== '') {
            $_SESSION['auth'] = true;
            $_SESSION['user'] = $u;
            $this->redirect('/');
        }

        $this->viewRaw('auth/login', ['error' => 'Неверный логин или пароль']);
    }

    public function logout(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION = [];
        @session_destroy();
        $this->redirect('/login');
    }
}
