<?php

class RegistrarContactsController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        $rows = DB::pdo()->query("SELECT * FROM registrar_contacts ORDER BY id DESC")->fetchAll();
        $this->view('registrar_contacts/index', ['rows' => $rows]);
    }

    public function createForm(): void
    {
        $this->requireAuth();
        $this->view('registrar_contacts/create', []);
    }

    public function store(): void
    {
        $this->requireAuth();
        $fields = ['label','first_name','last_name','organization','address1','address2','city','state_province','postal_code','country','phone','email'];
        $vals = [];
        foreach ($fields as $f) $vals[$f] = trim((string)($_POST[$f] ?? ''));

        if ($vals['first_name'] === '' || $vals['last_name'] === '' || $vals['address1'] === '' ||
            $vals['city'] === '' || $vals['postal_code'] === '' || $vals['country'] === '' ||
            $vals['phone'] === '' || $vals['email'] === '') {
            $this->flash('error', 'Заполните обязательные поля');
            $this->redirect('/registrar/contacts/create');
        }

        $st = DB::pdo()->prepare("INSERT INTO registrar_contacts
            (label, first_name, last_name, organization, address1, address2, city, state_province, postal_code, country, phone, email)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $st->execute([
            $vals['label'] ?: 'default',
            $vals['first_name'], $vals['last_name'], $vals['organization'],
            $vals['address1'], $vals['address2'], $vals['city'], $vals['state_province'],
            $vals['postal_code'], $vals['country'], $vals['phone'], $vals['email'],
        ]);
        $this->flash('success', 'Контакт добавлен');
        $this->redirect('/registrar/contacts');
    }

    public function delete(): void
    {
        $this->requireAuth();
        $id = (int)($_POST['id'] ?? 0);
        DB::pdo()->prepare("DELETE FROM registrar_contacts WHERE id=?")->execute([$id]);
        $this->flash('success', 'Удалён');
        $this->redirect('/registrar/contacts');
    }
}
