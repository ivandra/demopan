<?php

/**
 * v25.2-a1.6.4: непрерывное ожидание действия оператора.
 *
 *  awaiting_user_since — момент, когда джоба ОСТАНОВИЛАСЬ и стала ждать человека.
 *      НЕ updated_at (его дёргают SSL reconciler / retry-guard каждые 30с) и НЕ
 *      последнее событие. Обнуляется при реальном возобновлении, ставится заново
 *      при новом простое. По нему считается 30-дневный авто-close.
 *
 * Backfill выполняется в PHP (json_decode на строку), чтобы не зависеть от
 * поведения JSON-функций/STR_TO_DATE на конкретной версии MariaDB.
 * Отдельная идемпотентная миграция; НЕ редактирует 024–032.
 */
return [
    'name' => '033_jobs_awaiting_user_since',

    'up' => [
        function (PDO $pdo) {
            $col = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE 'awaiting_user_since'");
            if (!$col || !$col->fetch()) {
                $pdo->exec("ALTER TABLE refresh_jobs
                    ADD COLUMN awaiting_user_since DATETIME NULL
                    COMMENT 'v25.2-a1.6.4: непрерывное ожидание действия оператора'");
            }
            $idx = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'refresh_jobs'
                    AND INDEX_NAME = 'idx_jobs_awaiting_since'"
            )->fetchColumn();
            if ((int)$idx === 0) {
                $pdo->exec("ALTER TABLE refresh_jobs
                    ADD INDEX idx_jobs_awaiting_since (stage_status, awaiting_user_since)");
            }

            // --- Backfill существующих awaiting_user строк (PHP, JSON-safe) ---
            $terminal = "'done','failed','cancelled','superseded'";
            $rows = $pdo->query(
                "SELECT id, artifacts_json, stage_started_at, created_at
                   FROM refresh_jobs
                  WHERE stage_status = 'awaiting_user'
                    AND stage NOT IN ($terminal)
                    AND awaiting_user_since IS NULL"
            )->fetchAll(PDO::FETCH_ASSOC);

            $upd = $pdo->prepare("UPDATE refresh_jobs SET awaiting_user_since = ? WHERE id = ?");
            foreach ($rows as $r) {
                $since = null;
                $art = [];
                if (!empty($r['artifacts_json'])) {
                    $decoded = json_decode((string)$r['artifacts_json'], true);
                    if (is_array($decoded)) $art = $decoded;
                }
                // Приоритет источников (§4).
                $candidates = [
                    $art['old_delurl_notify_stage']['awaiting_since'] ?? null,
                    $art['index_watching_stage']['auto_stopped_at'] ?? null,
                    $art['final_monitoring_stage']['auto_stopped_at'] ?? null,
                    $r['stage_started_at'] ?? null,
                    $r['created_at'] ?? null,
                ];
                foreach ($candidates as $c) {
                    if ($c === null || $c === '') continue;
                    $ts = strtotime((string)$c);
                    if ($ts !== false && $ts > 0) { $since = date('Y-m-d H:i:s', $ts); break; }
                }
                if ($since !== null) {
                    $upd->execute([$since, (int)$r['id']]);
                }
            }
        },
    ],
];
