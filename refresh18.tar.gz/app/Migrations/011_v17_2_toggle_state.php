<?php

/**
 * v17.2: redirect_toggle_state_json — JSON-state для UI toggle redirect.
 *
 * v17.3 self-healing: дополнительно создаёт redirect_enabled и update_classes_url
 * если их нет (на случай если миграция 008 не применялась — например, файл миграции
 * не был залит на прод когда применяли v17.x).
 *
 * Поле redirect_toggle_state_json:
 *   Когда пользователь нажимает «Выключить редирект» на /sites/show,
 *   выполняется RedirectToggler::disable() через FTP, и результат
 *   (snapshots, applied_rules) сохраняется в это поле — чтобы при
 *   последующем «Включить» можно было восстановить из snapshot'а.
 *
 *   Структура JSON:
 *   {
 *     "disabled_at": "2026-05-06 14:30:00",
 *     "disabled_by_user": true,
 *     "disabled_state": {  // результат RedirectToggler::disable()
 *       "ok": true,
 *       "applied_rules": [...],
 *       "snapshots": {...},
 *       "base_path": "..."
 *     }
 *   }
 *   При включении — поле очищается (state=null).
 *
 * NB: Эта миграция использует MySQL процедурный синтаксис чтобы быть idempotent —
 * не падает если колонка уже существует.
 */
return [
    'name' => '011_v17_2_toggle_state',

    'up' => [
        // === SELF-HEAL: гарантируем что v16 поля существуют ===
        // Если миграция 008 не применялась (файл пропущен при заливке v17.x),
        // эти ALTER создадут поля. Если уже есть — IF NOT EXISTS пропустит.
        // Используем процедурный подход через хранимые процедуры так как
        // MySQL <8.0.29 не поддерживает IF NOT EXISTS в ALTER TABLE ADD COLUMN.

        // 1. redirect_enabled (из миграции 008)
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_011_a",
        "CREATE PROCEDURE _refresh_panel_add_col_011_a()
         BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'sites_managed'
                  AND COLUMN_NAME = 'redirect_enabled'
            ) THEN
                ALTER TABLE sites_managed
                    ADD COLUMN redirect_enabled TINYINT(1) NOT NULL DEFAULT 1
                        COMMENT 'Toggle редиректа: 1=включён, 0=пользователь выключил';
            END IF;
         END",
        "CALL _refresh_panel_add_col_011_a()",
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_011_a",

        // 2. update_classes_url (из миграции 008)
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_011_b",
        "CREATE PROCEDURE _refresh_panel_add_col_011_b()
         BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'sites_managed'
                  AND COLUMN_NAME = 'update_classes_url'
            ) THEN
                ALTER TABLE sites_managed
                    ADD COLUMN update_classes_url VARCHAR(512) NOT NULL DEFAULT ''
                        COMMENT 'v16: кастомный URL для вызова рандома классов';
            END IF;
         END",
        "CALL _refresh_panel_add_col_011_b()",
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_011_b",

        // 3. webmaster_account_override_id в refresh_jobs (из миграции 008)
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_011_c",
        "CREATE PROCEDURE _refresh_panel_add_col_011_c()
         BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'refresh_jobs'
                  AND COLUMN_NAME = 'webmaster_account_override_id'
            ) THEN
                ALTER TABLE refresh_jobs
                    ADD COLUMN webmaster_account_override_id INT NULL DEFAULT NULL
                        COMMENT 'v16/v17: override Webmaster аккаунт для нового домена';
            END IF;
         END",
        "CALL _refresh_panel_add_col_011_c()",
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_011_c",

        // === Главное поле этой миграции ===
        // 4. redirect_toggle_state_json — JSON-state от RedirectToggler::disable()
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_011_d",
        "CREATE PROCEDURE _refresh_panel_add_col_011_d()
         BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'sites_managed'
                  AND COLUMN_NAME = 'redirect_toggle_state_json'
            ) THEN
                ALTER TABLE sites_managed
                    ADD COLUMN redirect_toggle_state_json LONGTEXT DEFAULT NULL
                        COMMENT 'v17.2: JSON state от RedirectToggler::disable() при ручном выключении через UI';
            END IF;
         END",
        "CALL _refresh_panel_add_col_011_d()",
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_011_d",
    ],
];
