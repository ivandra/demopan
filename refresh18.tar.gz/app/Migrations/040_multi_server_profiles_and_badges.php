<?php

/**
 * 040_multi_server_profiles_and_badges (ТЗ 040 FINAL §4)
 *
 * Готовит панель к безопасному добавлению второго FastPanel-сервера обычным
 * способом. Добавляет ТОЛЬКО поля маркировки сайтов и безопасный итог
 * read-only проверки подключения. НЕ вводит серверный Webmaster, режим
 * активности сервера и IP сайтов по умолчанию (§3.1–§3.3, §4.1).
 *
 * ТОЛЬКО схема/дефолты. При установке ЗАПРЕЩЕНЫ и НЕ выполняются: FastPanel
 * API, HTTP/FTP, Yandex API, Namecheap, изменение sites_managed/refresh_jobs/
 * Webmaster/регистратора, добавление нового VPS (§4.3).
 *
 * Все 60 существующих сайтов остаются на сервере #1; badge сервера #1 = NULL,
 * то есть UI выглядит как до патча. Пароль/данные «VPS RU Fake» не используются.
 *
 * Уникальность host гарантируется на уровне БД (uq_fastpanel_servers_host).
 * Перед созданием индекса проверяется наличие дубликатов: при их наличии
 * миграция завершается понятной ошибкой, НИЧЕГО не удаляя и не объединяя (§4.2).
 *
 * Идемпотентна: колонки — через information_schema.COLUMNS, индекс — через
 * information_schema.STATISTICS (как 027/028/038/039).
 */

$colMissing = function (PDO $pdo, string $table, string $col): bool {
    $st = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $st->execute([$table, $col]);
    return (int)$st->fetchColumn() === 0;
};
$colExists = function (PDO $pdo, string $table, string $col) use ($colMissing): bool {
    return !$colMissing($pdo, $table, $col);
};
$indexMissing = function (PDO $pdo, string $table, string $index): bool {
    $st = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.STATISTICS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?"
    );
    $st->execute([$table, $index]);
    return (int)$st->fetchColumn() === 0;
};

// Только badge + безопасный итог теста (§4.1).
$columns = [
    'ui_badge_code'          => "ADD COLUMN ui_badge_code VARCHAR(8) NULL",
    'ui_badge_label'         => "ADD COLUMN ui_badge_label VARCHAR(64) NULL",
    'ui_badge_color'         => "ADD COLUMN ui_badge_color VARCHAR(7) NULL",
    'last_tested_at'         => "ADD COLUMN last_tested_at DATETIME NULL",
    'last_test_ok'           => "ADD COLUMN last_test_ok TINYINT(1) NULL",
    'last_test_error'        => "ADD COLUMN last_test_error VARCHAR(1000) NULL",
    'last_test_details_json' => "ADD COLUMN last_test_details_json LONGTEXT NULL",
];

return [
    'up' => [
        // §3.10 шаг 1-6: нормализация host'ов ДО любого DDL. Единый нормализатор.
        function (PDO $pdo) {
            require_once __DIR__ . '/../Services/FastpanelHostNormalizer.php';
            $rows = $pdo->query("SELECT id, host FROM fastpanel_servers ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
            $canon = []; $byNorm = [];
            foreach ($rows as $r) {
                $n = FastpanelHostNormalizer::normalize((string)$r['host']);
                if (!$n['ok']) {
                    throw new RuntimeException(
                        "Миграция 040 остановлена до DDL: host сервера #{$r['id']} невалиден "
                        . "('{$r['host']}': {$n['error']}). Данные не изменены. Исправьте host и повторите."
                    );
                }
                $canon[(int)$r['id']] = $n['host'];
                $byNorm[$n['host']][] = (int)$r['id'];
            }
            foreach ($byNorm as $normHost => $ids) {
                if (count($ids) > 1) {
                    throw new RuntimeException(
                        "Миграция 040 остановлена: серверы #" . implode(' и #', $ids)
                        . " нормализуются в один host {$normHost}. Данные не удалены. "
                        . "Устраните дубликат и повторите миграцию."
                    );
                }
            }
            // §3.10 шаг 6: обновить host там, где canonical отличается (без удаления/слияния)
            $upd = $pdo->prepare("UPDATE fastpanel_servers SET host=? WHERE id=? AND host<>?");
            foreach ($rows as $r) {
                $c = $canon[(int)$r['id']];
                if ((string)$r['host'] !== $c) $upd->execute([$c, (int)$r['id'], $c]);
            }
        },
        // §4.1 шаг 7: badge/test колонки идемпотентно.
        function (PDO $pdo) use ($colMissing, $columns) {
            foreach ($columns as $col => $ddl) {
                if ($colMissing($pdo, 'fastpanel_servers', $col)) {
                    $pdo->exec("ALTER TABLE fastpanel_servers {$ddl}");
                }
            }
        },
        // §3.10 шаг 8: уникальный индекс. Коллизии уже исключены выше;
        // здесь дополнительно проверяем literal-дубликаты для идемпотентности.
        function (PDO $pdo) use ($indexMissing) {
            if (!$indexMissing($pdo, 'fastpanel_servers', 'uq_fastpanel_servers_host')) {
                return;
            }
            $dups = $pdo->query(
                "SELECT host, GROUP_CONCAT(id ORDER BY id) ids, COUNT(*) n
                   FROM fastpanel_servers GROUP BY host HAVING n > 1"
            )->fetchAll(PDO::FETCH_ASSOC);
            if ($dups) {
                $lines = [];
                foreach ($dups as $d) $lines[] = "host='{$d['host']}' → id: {$d['ids']}";
                throw new RuntimeException(
                    "Миграция 040 остановлена: дубликаты host. Данные не изменены. "
                    . "Конфликты: " . implode('; ', $lines)
                );
            }
            $pdo->exec("CREATE UNIQUE INDEX uq_fastpanel_servers_host ON fastpanel_servers(host)");
        },
        // §4.3: backfill server #1 — badge = NULL by design (no data change).
        function (PDO $pdo) { /* no-op */ },
    ],
    'down' => [
        function (PDO $pdo) use ($indexMissing) {
            if (!$indexMissing($pdo, 'fastpanel_servers', 'uq_fastpanel_servers_host')) {
                $pdo->exec("DROP INDEX uq_fastpanel_servers_host ON fastpanel_servers");
            }
        },
        function (PDO $pdo) use ($colExists, $columns) {
            foreach (array_keys($columns) as $col) {
                if ($colExists($pdo, 'fastpanel_servers', $col)) {
                    $pdo->exec("ALTER TABLE fastpanel_servers DROP COLUMN {$col}");
                }
            }
        },
    ],
];
