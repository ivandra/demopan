<?php

/**
 * v25.1-a: ядро pipeline — техническая доступность домена отдельно от строгой
 * HTTPS-готовности.
 *
 * Причина: публичный 301/302/307/308 на HTTPS того же нового домена (в т.ч. с
 * YandexBot UA) ИЛИ живой HTTPS 2xx/3xx (даже self-signed) означает, что сайт
 * технически доступен и pipeline может продолжаться (PHP-уникализация и далее).
 * Прежде gate требовал строгий HTTPS 200 + trusted SSL + probe × 2, из-за чего
 * доступный домен с self-signed зря блокировался.
 *
 * Новое поле `domain_technical_ready_at` становится gate к PHP-уникализации.
 * Старое `domain_https_ready_at` СОХРАНЯЕТ смысл строгой HTTPS-готовности
 * (нужно для verification/recrawl) и НЕ переиспользуется.
 *
 * Миграции 025/026 НЕ изменяются. Шаги идемпотентны. Полноценный SSL-мониторинг
 * (таблицы domain_ssl_statuses / domain_ssl_check_history, вкладка) — отдельной
 * миграцией 028 в патче v25.1-b.
 */
return [
    'name' => '027_pipeline_technical_readiness',

    'up' => [
        // 1) Новые колонки refresh_jobs (каждая проверяется отдельно).
        function (PDO $pdo) {
            $cols = [
                'domain_technical_ready_at' => "ADD COLUMN domain_technical_ready_at DATETIME DEFAULT NULL
                    COMMENT 'v25.1: момент технической доступности (301→HTTPS/HTTPS 2xx-3xx). GATE к PHP-уникализации'",
                'domain_readiness_state' => "ADD COLUMN domain_readiness_state VARCHAR(32) DEFAULT NULL
                    COMMENT 'v25.1: состояние readiness (technical_ready/checking/...)'",
                'domain_readiness_reason' => "ADD COLUMN domain_readiness_reason VARCHAR(64) DEFAULT NULL
                    COMMENT 'v25.1: причина последнего readiness-решения'",
                'domain_http_location' => "ADD COLUMN domain_http_location VARCHAR(2048) DEFAULT NULL
                    COMMENT 'v25.1: Location из публичного HTTP-редиректа'",
                'domain_yandexbot_http_code' => "ADD COLUMN domain_yandexbot_http_code INT DEFAULT NULL
                    COMMENT 'v25.1: HTTP-код ответа домена на запрос с YandexBot UA'",
                'domain_yandexbot_location' => "ADD COLUMN domain_yandexbot_location VARCHAR(2048) DEFAULT NULL
                    COMMENT 'v25.1: Location из ответа YandexBot'",
                'domain_ssl_state' => "ADD COLUMN domain_ssl_state VARCHAR(32) DEFAULT NULL
                    COMMENT 'v25.1: SSL-состояние (not_checked/no_tls/self_signed/trusted/hostname_mismatch/expired/...)'",
                'domain_ssl_trusted_at' => "ADD COLUMN domain_ssl_trusted_at DATETIME DEFAULT NULL
                    COMMENT 'v25.1: момент появления доверенного SSL'",
                'domain_ssl_last_checked_at' => "ADD COLUMN domain_ssl_last_checked_at DATETIME DEFAULT NULL
                    COMMENT 'v25.1: время последней SSL-проверки'",
            ];
            foreach ($cols as $name => $ddl) {
                $st = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE " . $pdo->quote($name));
                if ($st && $st->fetch()) continue;
                $pdo->exec("ALTER TABLE refresh_jobs " . $ddl);
            }
        },

        // 2) Индексы (идемпотентно).
        function (PDO $pdo) {
            $indexes = [
                'idx_stage_status_next' => "ADD KEY idx_stage_status_next (stage, stage_status, next_run_at)",
                'idx_ssl_state_checked' => "ADD KEY idx_ssl_state_checked (domain_ssl_state, domain_ssl_last_checked_at)",
            ];
            foreach ($indexes as $name => $ddl) {
                $chk = $pdo->query(
                    "SELECT COUNT(*) FROM information_schema.STATISTICS
                      WHERE TABLE_SCHEMA = DATABASE()
                        AND TABLE_NAME = 'refresh_jobs'
                        AND INDEX_NAME = " . $pdo->quote($name)
                )->fetchColumn();
                if ((int)$chk === 0) {
                    $pdo->exec("ALTER TABLE refresh_jobs " . $ddl);
                }
            }
        },

        // 3) Backfill: если строгая готовность уже стояла — считаем технически
        //    готовым тем же временем (обратная совместимость, ТЗ 3.3).
        function (PDO $pdo) {
            $pdo->exec(
                "UPDATE refresh_jobs
                    SET domain_technical_ready_at = domain_https_ready_at
                  WHERE domain_https_ready_at IS NOT NULL
                    AND domain_technical_ready_at IS NULL"
            );
        },

        // 4) Одноразовое безопасное восстановление зависших transient-джоб
        //    (ТЗ §10). Только wm_verified + awaiting_user, где причина —
        //    временная (timeout/IN_PROGRESS/NONE/INTERNAL_ERROR/5xx/429/SSL/файл).
        //    НЕ трогаем terminal, OAuth 401/403, FTP-реквизиты, ручные остановки.
        function (PDO $pdo) {
            // Признаки НЕвосстановимых причин в stage_error — не возобновляем.
            $blockers = ['401', '403', 'oauth', 'токен', 'ftp', 'реквизит',
                         'credential', 'аккаунт удал', 'account', 'вручную', 'manual', 'отмен'];
            $rows = $pdo->query(
                "SELECT id, COALESCE(stage_error,'') err FROM refresh_jobs
                  WHERE stage = 'wm_verified' AND stage_status = 'awaiting_user'
                    AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->fetchAll(PDO::FETCH_ASSOC);
            $upd = $pdo->prepare(
                "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL, next_run_at=NOW()
                  WHERE id = ? AND stage = 'wm_verified' AND stage_status = 'awaiting_user'"
            );
            foreach ($rows as $r) {
                $err = mb_strtolower((string)$r['err']);
                $blocked = false;
                foreach ($blockers as $b) { if ($err !== '' && mb_strpos($err, $b) !== false) { $blocked = true; break; } }
                if ($blocked) continue; // реальная неисправимая ошибка — оставляем оператору
                $upd->execute([(int)$r['id']]);
                // Событие в лог (если таблица есть).
                try {
                    $pdo->prepare(
                        "INSERT INTO refresh_job_events (job_id, level, stage, message, created_at)
                         VALUES (?, 'info', 'wm_verified', 'Автоматически возобновлено после установки v25.1 (транзиентное ожидание)', NOW())"
                    )->execute([(int)$r['id']]);
                } catch (\Throwable $e) { /* лог не критичен */ }
            }
        },
    ],
];
