<?php

/**
 * Миграция 017 (v18.1.28):
 *   Cleanup дубликатов в balance_current.
 *
 * Контекст:
 *   В предыдущей версии после-after-purchase trigger в DomainPurchaseService
 *   передавал в BalanceCheckService::checkOne() **username** Namecheap-аккаунта
 *   (например 'rodion.minskoff') как accountLabel. А cron и initial-INSERT
 *   использовали 'default'. Результат: в balance_current две записи на один
 *   и тот же аккаунт, обе видны в status-bar (дубль).
 *
 *   В v18.1.28 baseline ввели canonical-label логику (canonicalAccountLabel),
 *   которая резолвит username → 'default' если это is_default=1 аккаунт.
 *   Теперь нужно удалить старые "duplicate" записи из БД.
 *
 * Стратегия:
 *   1) Для каждой пары (service='namecheap', account_label=username) проверить
 *      — соответствует ли label is_default=1 prod-аккаунту?
 *   2) Если ДА — удалить эту запись (canonical-версия 'default' остаётся).
 *   3) Если 'default' записи нет — переименовать username-запись в 'default'.
 *
 *   xmlstock — резерв на случай если в будущем тоже появятся дубли.
 *   Для него canonical всегда 'default', поэтому удаляем все !='default' записи.
 */

return [
    'name' => '017_v18_1_28_cleanup_balance_duplicates',

    'up' => [
        function ($pdo) {
            // === namecheap: дедупликация по is_default=1 ===
            // Находим все username-записи в balance_current
            $st = $pdo->query(
                "SELECT bc.account_label
                 FROM balance_current bc
                 WHERE bc.service = 'namecheap'
                   AND bc.account_label != 'default'"
            );
            $usernameLabels = $st->fetchAll(PDO::FETCH_COLUMN);

            foreach ($usernameLabels as $label) {
                // Этот username — это is_default=1 аккаунт?
                $st2 = $pdo->prepare(
                    "SELECT id, is_default FROM registrar_accounts
                     WHERE provider='namecheap' AND username=? AND COALESCE(is_sandbox,0)=0 LIMIT 1"
                );
                $st2->execute([$label]);
                $acc = $st2->fetch();
                if (!$acc || (int)$acc['is_default'] !== 1) {
                    continue; // не is_default — оставляем (может быть отдельный аккаунт)
                }

                // Есть ли уже запись 'default' для namecheap?
                $st3 = $pdo->prepare(
                    "SELECT account_label FROM balance_current
                     WHERE service='namecheap' AND account_label='default' LIMIT 1"
                );
                $st3->execute();
                $hasDefault = (bool)$st3->fetchColumn();

                if ($hasDefault) {
                    // 'default' уже есть → username-запись — дубль, удаляем
                    $pdo->prepare(
                        "DELETE FROM balance_current
                         WHERE service='namecheap' AND account_label=?"
                    )->execute([$label]);
                } else {
                    // 'default' записи нет — переименовываем username → 'default'
                    $pdo->prepare(
                        "UPDATE balance_current SET account_label='default'
                         WHERE service='namecheap' AND account_label=?"
                    )->execute([$label]);
                }
            }

            // === xmlstock: canonical всегда 'default' ===
            // Если есть xmlstock с label != 'default' — это дубль или ошибка.
            $st4 = $pdo->query(
                "SELECT account_label FROM balance_current
                 WHERE service='xmlstock' AND account_label != 'default'"
            );
            $extras = $st4->fetchAll(PDO::FETCH_COLUMN);
            foreach ($extras as $label) {
                $st5 = $pdo->prepare(
                    "SELECT account_label FROM balance_current
                     WHERE service='xmlstock' AND account_label='default' LIMIT 1"
                );
                $st5->execute();
                $hasDefault = (bool)$st5->fetchColumn();
                if ($hasDefault) {
                    $pdo->prepare(
                        "DELETE FROM balance_current
                         WHERE service='xmlstock' AND account_label=?"
                    )->execute([$label]);
                } else {
                    $pdo->prepare(
                        "UPDATE balance_current SET account_label='default'
                         WHERE service='xmlstock' AND account_label=?"
                    )->execute([$label]);
                }
            }
        },
    ],
];
