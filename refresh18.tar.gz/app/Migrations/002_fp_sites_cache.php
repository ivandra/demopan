<?php

/**
 * Миграция 002: кеш списка сайтов с FastPanel-серверов.
 * Используется для быстрого поиска без обращения к API на каждый запрос.
 */

return [
    'name' => '002_fp_sites_cache',

    'up' => [
        "CREATE TABLE IF NOT EXISTS fp_sites_cache (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            fastpanel_server_id INT NOT NULL,
            fp_site_id INT NOT NULL,
            server_name VARCHAR(255) NOT NULL,
            owner_username VARCHAR(64) NOT NULL DEFAULT '',
            raw_json LONGTEXT,
            cached_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_srv_site (fastpanel_server_id, fp_site_id),
            INDEX idx_server_name (server_name),
            INDEX idx_cache (fastpanel_server_id, cached_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ],
];
