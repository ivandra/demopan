<?php

/**
 * 039_randomization_capability_and_operator_ui (ТЗ 039, часть B §6, §21)
 *
 * Только схема/дефолты. При установке ЗАПРЕЩЕНЫ и НЕ выполняются: FTP, HTTP,
 * Yandex API, XMLStock, Telegram, создание monitor, изменение стадий джоб,
 * backfill capability. Существующие сайты получают uc_capability='unknown'
 * (DEFAULT); статус уточняется лениво при следующей синхронизации/джобе.
 *
 * Идемпотентна: каждый шаг проверяет information_schema перед ALTER.
 */

$colMissing = function (PDO $pdo, string $table, string $col): bool {
    $st = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $st->execute([$table, $col]);
    return (int)$st->fetchColumn() === 0;
};
$colExists = function (PDO $pdo, string $table, string $col) use ($colMissing): bool {
    return !$colMissing($pdo, $table, $col);
};

return [
    'up' => [
        // §6: режим рандомизации на уровне сайта (auto|disabled|custom).
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'sites_managed', 'uc_mode')) {
                $pdo->exec("ALTER TABLE sites_managed
                    ADD COLUMN uc_mode VARCHAR(16) NOT NULL DEFAULT 'auto' AFTER uc_site_subroot");
            }
        },
        // §6: последняя подтверждённая применимость (unknown|confirmed_absent|
        // variant_refresh|update_classes|custom|needs_review|conflict|ftp_error).
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'sites_managed', 'uc_capability')) {
                $pdo->exec("ALTER TABLE sites_managed
                    ADD COLUMN uc_capability VARCHAR(32) NOT NULL DEFAULT 'unknown' AFTER uc_mode");
            }
        },
        // §6: технические детали детекции (файлы, сигнатуры, fingerprint,
        // наличие секрета, root/subroot, причина результата).
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'sites_managed', 'uc_detection_json')) {
                $pdo->exec("ALTER TABLE sites_managed
                    ADD COLUMN uc_detection_json LONGTEXT NULL AFTER uc_capability");
            }
        },
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'sites_managed', 'uc_detected_at')) {
                $pdo->exec("ALTER TABLE sites_managed
                    ADD COLUMN uc_detected_at DATETIME NULL AFTER uc_detection_json");
            }
        },
        // §7.2: способ подтверждения результата custom-скрипта
        // (json_ok_true|exact_marker|ftp_profile). NULL = не настроен.
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'sites_managed', 'uc_verification_contract')) {
                $pdo->exec("ALTER TABLE sites_managed
                    ADD COLUMN uc_verification_contract VARCHAR(255) NULL AFTER uc_detected_at");
            }
        },
        // §7.2: конкретная строка-маркер для contract=exact_marker.
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'sites_managed', 'uc_verification_marker')) {
                $pdo->exec("ALTER TABLE sites_managed
                    ADD COLUMN uc_verification_marker VARCHAR(255) NULL AFTER uc_verification_contract");
            }
        },
        // §10.1/§10.2 (v3): миграция НЕ угадывает формат ответа по имени
        // update_classes.php. Безопасные правила:
        //   variant-refresh.php → contract=json_ok_true (variant отдаёт JSON ok=true);
        //   update_classes.php с УЖЕ сохранённым точным marker → сохранить exact_marker;
        //   update_classes.php БЕЗ доказанного marker → needs_review, contract=NULL, HTTP=0;
        //   произвольный URL → needs_review.
        // Универсальный общий маркер УДАЛЁН (§9.1) — общий текст не доказывает успех.
        // Только локальный SQL, без FTP/HTTP/инспекции. Идемпотентно (uc_mode='auto').
        // Не перезаписывает сайты с уже выбранным contract/marker.
        function (PDO $pdo) {
            $pdo->exec("UPDATE sites_managed
                SET uc_mode = 'custom',
                    uc_capability = CASE
                        WHEN update_classes_url LIKE '%variant-refresh.php%' THEN 'custom'
                        WHEN uc_verification_contract = 'exact_marker'
                             AND TRIM(COALESCE(uc_verification_marker,'')) <> '' THEN 'custom'
                        ELSE 'needs_review'
                    END,
                    uc_verification_contract = CASE
                        WHEN uc_verification_contract IS NOT NULL AND uc_verification_contract <> '' THEN uc_verification_contract
                        WHEN update_classes_url LIKE '%variant-refresh.php%' THEN 'json_ok_true'
                        ELSE NULL
                    END
                WHERE TRIM(COALESCE(update_classes_url, '')) <> ''
                  AND COALESCE(uc_mode, 'auto') = 'auto'");
        },
    ],
    'down' => [
        // Откат удаляет ТОЛЬКО новые колонки 039; данные других миграций не трогает.
        function (PDO $pdo) use ($colExists) {
            foreach (['uc_verification_marker', 'uc_verification_contract', 'uc_detected_at', 'uc_detection_json', 'uc_capability', 'uc_mode'] as $c) {
                if ($colExists($pdo, 'sites_managed', $c)) {
                    $pdo->exec("ALTER TABLE sites_managed DROP COLUMN {$c}");
                }
            }
        },
    ],
];
