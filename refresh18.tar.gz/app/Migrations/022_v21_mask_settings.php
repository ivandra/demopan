<?php

/**
 * v21: персональные настройки маски генерации на каждый сайт.
 *
 * Глобальные параметры живут в app_settings (ключи mask.*).
 * Эта колонка позволяет переопределить их для конкретного сайта — например,
 * у одного сотрудника sub_id считается по буквам
 * (A_azino_777df_casino → A_azino_777dg_casino) и включён префикс 'A_',
 * а у остальных работает обычный числовой инкремент.
 *
 * Формат mask_settings_json:
 * {
 *   "use_global": 0,        // 1 — игнорировать персональные, брать глобальные
 *   "strategy": "letter",   // number | letter
 *   "step": 1,
 *   "pad_zeros": 1,
 *   "no_digit_start": 2,
 *   "letter_alphabet": "abcdefghijklmnopqrstuvwxyz",
 *   "letter_wrap": 1,
 *   "sync_with_domain": 1,  // число sub_id брать из нового домена
 *   "prefix_enabled": 0,
 *   "prefix": "A_"
 * }
 *
 * NULL или use_global=1 — сайт работает на глобальных настройках.
 *
 * Шаг сделан callable: 'ADD COLUMN IF NOT EXISTS' не поддерживается
 * старыми MySQL/MariaDB, поэтому проверяем наличие колонки вручную.
 */
return [
    'name' => '022_v21_mask_settings',

    'up' => [
        function (PDO $pdo) {
            $st = $pdo->query("SHOW COLUMNS FROM sites_managed LIKE 'mask_settings_json'");
            if ($st && $st->fetch()) {
                return; // колонка уже есть — миграция идемпотентна
            }
            $pdo->exec(
                "ALTER TABLE sites_managed
                    ADD COLUMN mask_settings_json TEXT DEFAULT NULL
                    COMMENT 'v21: персональные параметры маски генерации домена/sub_id; NULL = глобальные'"
            );
        },
    ],
];
