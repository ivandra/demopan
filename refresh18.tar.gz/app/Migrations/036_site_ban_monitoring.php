<?php

/**
 * 036: фоновый мониторинг выпадения доменов из индекса (ban-monitoring) + централь-
 * ный журнал расхода XMLStock. Три новые таблицы, изолированы от refresh_jobs/
 * sites_managed/site_relocations (rollback их не трогает). Идемпотентно.
 */
return [
    'name' => '036_site_ban_monitoring',

    'up' => [
        function (PDO $pdo) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS site_ban_monitors (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                site_id BIGINT UNSIGNED NULL,
                source_job_id BIGINT UNSIGNED NOT NULL,
                domain VARCHAR(255) NOT NULL,
                indexed_at DATETIME NOT NULL,
                monitoring_starts_at DATETIME NOT NULL,
                next_check_at DATETIME NULL,
                last_check_at DATETIME NULL,
                last_positive_at DATETIME NOT NULL,
                last_positive_pages INT UNSIGNED NOT NULL DEFAULT 1,
                first_negative_at DATETIME NULL,
                last_negative_at DATETIME NULL,
                state VARCHAR(32) NOT NULL DEFAULT 'waiting_12h',
                negative_streak TINYINT UNSIGNED NOT NULL DEFAULT 0,
                insurance_checks_done TINYINT UNSIGNED NOT NULL DEFAULT 0,
                technical_error_count INT UNSIGNED NOT NULL DEFAULT 0,
                last_pages_indexed INT UNSIGNED NOT NULL DEFAULT 0,
                series_no INT UNSIGNED NOT NULL DEFAULT 0,
                probable_notified_at DATETIME NULL,
                recovered_notified_at DATETIME NULL,
                confirmed_notified_at DATETIME NULL,
                telegram_retry_at DATETIME NULL,
                last_result_json LONGTEXT NULL,
                last_error VARCHAR(1000) NULL,
                stopped_at DATETIME NULL,
                stop_reason VARCHAR(64) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_ban_monitor_job_domain (source_job_id, domain),
                KEY idx_ban_monitor_due (state, next_check_at),
                KEY idx_ban_monitor_domain (domain),
                KEY idx_ban_monitor_site (site_id),
                KEY idx_ban_monitor_job (source_job_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        },
        function (PDO $pdo) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS xmlstock_request_log (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                request_uuid CHAR(36) NOT NULL,
                requested_at DATETIME NOT NULL,
                completed_at DATETIME NULL,
                purpose VARCHAR(32) NOT NULL,
                phase VARCHAR(32) NULL,
                initiated_by VARCHAR(24) NOT NULL DEFAULT 'cron',
                source_job_id BIGINT UNSIGNED NULL,
                site_id BIGINT UNSIGNED NULL,
                monitor_id BIGINT UNSIGNED NULL,
                domain VARCHAR(255) NOT NULL,
                sequence_no TINYINT UNSIGNED NULL,
                status VARCHAR(24) NOT NULL DEFAULT 'reserved',
                result VARCHAR(24) NULL,
                pages_indexed INT UNSIGNED NULL,
                http_code INT NULL,
                provider_code VARCHAR(64) NULL,
                duration_ms INT UNSIGNED NULL,
                assumed_charged TINYINT(1) NOT NULL DEFAULT 0,
                request_cost_rub DECIMAL(12,4) NULL,
                message VARCHAR(1000) NULL,
                response_excerpt VARCHAR(1000) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_xmlstock_request_uuid (request_uuid),
                KEY idx_xmlstock_usage_time (requested_at),
                KEY idx_xmlstock_usage_purpose (purpose, requested_at),
                KEY idx_xmlstock_usage_job (source_job_id, requested_at),
                KEY idx_xmlstock_usage_monitor (monitor_id, requested_at),
                KEY idx_xmlstock_usage_domain (domain, requested_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        },
        function (PDO $pdo) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS site_ban_monitor_checks (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                monitor_id BIGINT UNSIGNED NOT NULL,
                xmlstock_request_log_id BIGINT UNSIGNED NULL,
                checked_at DATETIME NOT NULL,
                phase VARCHAR(32) NOT NULL,
                sequence_no TINYINT UNSIGNED NULL,
                series_no INT UNSIGNED NOT NULL DEFAULT 0,
                result VARCHAR(24) NOT NULL,
                pages_indexed INT UNSIGNED NULL,
                xmlstock_ok TINYINT(1) NOT NULL DEFAULT 0,
                message VARCHAR(1000) NULL,
                error_code VARCHAR(128) NULL,
                response_json LONGTEXT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_ban_checks_monitor (monitor_id, checked_at),
                KEY idx_ban_checks_request (xmlstock_request_log_id),
                CONSTRAINT fk_ban_checks_monitor
                    FOREIGN KEY (monitor_id) REFERENCES site_ban_monitors(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        },
    ],

    // down: удалить только новые таблицы (refresh_jobs/sites_managed/site_relocations не трогаем).
    'down' => [
        function (PDO $pdo) { $pdo->exec("DROP TABLE IF EXISTS site_ban_monitor_checks"); },
        function (PDO $pdo) { $pdo->exec("DROP TABLE IF EXISTS xmlstock_request_log"); },
        function (PDO $pdo) { $pdo->exec("DROP TABLE IF EXISTS site_ban_monitors"); },
    ],
];
