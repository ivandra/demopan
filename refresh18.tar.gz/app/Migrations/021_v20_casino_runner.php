<?php

/**
 * v20: casino-runner модуль — таблицы для приёма проектов от casino-panel'и
 * и хранения операций (buy/subs/ssl/webmaster/cron).
 *
 * Архитектура: casino-panel выступает в роли UI, refresh-panel выступает
 * в роли исполнителя. Связь — HTTPS + Bearer api_key (из v19 миграции).
 *
 * casino_projects     — описание проекта (15 сайтов на одном root-домене)
 * casino_project_sites — список сайтов внутри проекта (slug, brand, host, …)
 * casino_runs         — операции (long-running jobs), которые гоняются через
 *                       существующий cron-механизм refresh-panel'и
 */
return [
    'name' => '021_v20_casino_runner',

    'up' => [
        "CREATE TABLE IF NOT EXISTS casino_projects (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            api_client_id INT NOT NULL COMMENT 'Кто зарегистрировал — ссылка на api_clients.id',
            external_id VARCHAR(64) NOT NULL DEFAULT '' COMMENT 'project_id со стороны casino-panel (опционально)',
            label VARCHAR(128) NOT NULL DEFAULT '' COMMENT 'Человеко-читаемое имя',
            main_host VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'Главный host (kazik2600.casino)',
            docroot VARCHAR(512) NOT NULL DEFAULT '' COMMENT 'Путь docroot на VPS',
            vps_ip VARCHAR(45) DEFAULT NULL COMMENT 'IP сервера (для DNS A-записей)',

            /* Привязки к существующим аккаунтам refresh-panel'и */
            webmaster_account_id INT DEFAULT NULL,
            registrar_account_id INT DEFAULT NULL,
            registrar_contact_id INT DEFAULT NULL,
            fp_server_id INT DEFAULT NULL,
            fp_site_id INT DEFAULT NULL,

            /* Состояние проекта */
            root_domain VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'Купленный root-домен (заполняется после buy)',
            root_domain_purchased_at DATETIME DEFAULT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'registered' COMMENT 'registered|domain_bought|subs_ready|wm_added|done|failed',

            note TEXT DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

            UNIQUE KEY uq_client_external (api_client_id, external_id),
            KEY idx_main_host (main_host),
            KEY idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='v20: casino-проекты, переданные из casino-panel в refresh-panel для деплоя'",

        "CREATE TABLE IF NOT EXISTS casino_project_sites (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            project_id INT NOT NULL,
            site_slug VARCHAR(64) NOT NULL COMMENT 'slug внутри проекта (например _main, atom)',
            brand VARCHAR(64) NOT NULL DEFAULT '',
            host VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'Поддомен или main_host',
            path_prefix VARCHAR(32) NOT NULL DEFAULT 'en',
            path_repeats INT NOT NULL DEFAULT 11,
            subid VARCHAR(128) NOT NULL DEFAULT '',
            is_main TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1 для _main',

            /* Состояния отдельных стадий */
            dns_status VARCHAR(32) NOT NULL DEFAULT 'pending' COMMENT 'pending|added|failed',
            dns_error TEXT DEFAULT NULL,
            fp_alias_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            fp_alias_error TEXT DEFAULT NULL,
            ssl_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            ssl_error TEXT DEFAULT NULL,
            wm_host_id VARCHAR(128) NOT NULL DEFAULT '',
            wm_verified TINYINT(1) NOT NULL DEFAULT 0,
            wm_error TEXT DEFAULT NULL,

            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

            UNIQUE KEY uq_project_slug (project_id, site_slug),
            KEY idx_project (project_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='v20: per-site строки проекта (15 штук на проект)'",

        "CREATE TABLE IF NOT EXISTS casino_runs (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            run_id VARCHAR(32) NOT NULL COMMENT 'Публичный идентификатор для поллинга',
            project_id INT NOT NULL,
            kind VARCHAR(32) NOT NULL COMMENT 'buy|subs|ssl|webmaster|cron',
            state VARCHAR(32) NOT NULL DEFAULT 'queued' COMMENT 'queued|running|done|failed|cancelled',
            input_json LONGTEXT COMMENT 'параметры операции',
            result_json LONGTEXT COMMENT 'результат когда done',
            progress INT NOT NULL DEFAULT 0 COMMENT '0-100',
            last_message TEXT DEFAULT NULL,
            error TEXT DEFAULT NULL,
            tick_count INT NOT NULL DEFAULT 0 COMMENT 'сколько раз cron брал этот run в обработку',
            started_at DATETIME DEFAULT NULL,
            finished_at DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

            UNIQUE KEY uq_run_id (run_id),
            KEY idx_project_kind (project_id, kind),
            KEY idx_state (state)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='v20: long-running операции для casino-проектов'",

        "CREATE TABLE IF NOT EXISTS casino_run_events (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            run_id VARCHAR(32) NOT NULL,
            ts DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            level VARCHAR(16) NOT NULL DEFAULT 'info' COMMENT 'info|ok|warn|error',
            message TEXT NOT NULL,
            payload_json LONGTEXT DEFAULT NULL,
            KEY idx_run_id (run_id),
            KEY idx_ts (ts)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='v20: события (лог) операций — для UI прогресса и аудита'",
    ],
];
