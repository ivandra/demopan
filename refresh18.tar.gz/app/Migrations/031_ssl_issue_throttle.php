<?php

/**
 * v25.2-a1: throttle-таймер выпуска trusted SSL. TrustedSslReconciler выдерживает
 * интервал между тиками issuance для одной джобы (частые cron-тики не должны
 * штурмовать ACME create-order). Отдельная идемпотентная миграция; НЕ редактирует
 * 027–030.
 */
return [
    'name' => '031_ssl_issue_throttle',

    'up' => [
        function (PDO $pdo) {
            $st = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE 'ssl_issue_next_poll_at'");
            if (!$st || !$st->fetch()) {
                $pdo->exec("ALTER TABLE refresh_jobs
                    ADD COLUMN ssl_issue_next_poll_at DATETIME NULL
                    COMMENT 'v25.2-a1: не запускать issuance-тик раньше этого времени'");
            }
            $chk = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'refresh_jobs'
                    AND INDEX_NAME = 'idx_ssl_issue_next_poll'"
            )->fetchColumn();
            if ((int)$chk === 0) {
                $pdo->exec("ALTER TABLE refresh_jobs ADD KEY idx_ssl_issue_next_poll (ssl_issue_next_poll_at)");
            }
        },
    ],
];
