<?php

/**
 * v17.1: Настройки внешних сервисов проверки индексации.
 *
 * 1. xmlstock_settings — таблица одной строки с настройками xmlstock.com
 *    (платный сервис XML Search API Yandex). Если enabled=1 и ключи заданы,
 *    становится основным методом проверки индекса.
 *
 * 2. Расширяем site_webmaster_links новыми полями:
 *    - last_index_check_method — каким методом был последний успешный check
 *    - last_index_check_at — таймштамп последней проверки
 *
 * 3. Добавляем поле index_watching_settings_id (зарезервированно на будущее)
 */
return [
    'name' => '010_v17_1_index_check',

    'up' => [
        // 1. Таблица настроек xmlstock
        "CREATE TABLE IF NOT EXISTS xmlstock_settings (
            id INT NOT NULL DEFAULT 1 PRIMARY KEY,
            enabled TINYINT(1) NOT NULL DEFAULT 0,
            endpoint_xml VARCHAR(255) NOT NULL DEFAULT 'https://xmlstock.com/yandexlive/xml/',
            user_id VARCHAR(64) NOT NULL DEFAULT '' COMMENT 'xmlstock user (login)',
            api_key VARCHAR(128) NOT NULL DEFAULT '' COMMENT 'xmlstock key',
            daily_quota_limit INT NOT NULL DEFAULT 1000 COMMENT 'Информационно — для UI',
            queries_today INT NOT NULL DEFAULT 0 COMMENT 'Счётчик запросов за сегодня',
            queries_today_date DATE DEFAULT NULL,
            last_validated_at DATETIME DEFAULT NULL,
            last_validation_ok TINYINT(1) NOT NULL DEFAULT 0,
            last_validation_error VARCHAR(500) NOT NULL DEFAULT '',
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='v17.1: настройки xmlstock.com — платная XML Search API для быстрой проверки индекса'",

        "INSERT IGNORE INTO xmlstock_settings (id, enabled) VALUES (1, 0)",

        // 2. Поля для UI и логики в site_webmaster_links
        "ALTER TABLE site_webmaster_links
            ADD COLUMN last_index_check_method VARCHAR(64) NOT NULL DEFAULT ''
                COMMENT 'v17.1: каким методом было определено indexed=1'
            AFTER indexed_pages_count",

        "ALTER TABLE site_webmaster_links
            ADD COLUMN last_index_check_at DATETIME DEFAULT NULL
                COMMENT 'v17.1: время последней проверки индекса'
            AFTER last_index_check_method",
    ],
];
