<?php

/**
 * Миграция 001: первичные таблицы panel "refresh".
 *
 * Запускать через /admin/migrate (UI) или CLI:
 *   php public/migrate.php
 */

return [
    'name' => '001_init',

    'up' => [
        // ---------- 1) Серверы FastPanel ----------
        "CREATE TABLE IF NOT EXISTS fastpanel_servers (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(100) NOT NULL,
            host VARCHAR(255) NOT NULL,
            username VARCHAR(100) NOT NULL,
            password_enc TEXT NOT NULL,
            extra_ips TEXT,
            verify_tls TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // ---------- 2) Аккаунты регистраторов (Namecheap) ----------
        "CREATE TABLE IF NOT EXISTS registrar_accounts (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            provider VARCHAR(32) NOT NULL DEFAULT 'namecheap',
            is_sandbox TINYINT(1) NOT NULL DEFAULT 0,
            api_user VARCHAR(64) NOT NULL,
            api_key_enc TEXT NOT NULL,
            username VARCHAR(64) NOT NULL,
            client_ip VARCHAR(64) NOT NULL,
            is_default TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_provider (provider),
            INDEX idx_default (is_default)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 3) Контакты регистратора ----------
        "CREATE TABLE IF NOT EXISTS registrar_contacts (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            label VARCHAR(64) NOT NULL DEFAULT 'default',
            first_name VARCHAR(64) NOT NULL,
            last_name VARCHAR(64) NOT NULL,
            organization VARCHAR(128) NOT NULL DEFAULT '',
            address1 VARCHAR(128) NOT NULL,
            address2 VARCHAR(128) NOT NULL DEFAULT '',
            city VARCHAR(64) NOT NULL,
            state_province VARCHAR(64) NOT NULL DEFAULT '',
            postal_code VARCHAR(32) NOT NULL,
            country VARCHAR(2) NOT NULL,
            phone VARCHAR(32) NOT NULL,
            email VARCHAR(128) NOT NULL,
            env ENUM('prod','sandbox') NOT NULL DEFAULT 'prod',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_label (label)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 4) Управляемые сайты ----------
        "CREATE TABLE IF NOT EXISTS sites_managed (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,

            /* Идентификация на FP */
            fastpanel_server_id INT DEFAULT NULL,
            fp_site_id INT DEFAULT NULL,
            fp_site_owner VARCHAR(64) NOT NULL DEFAULT '',
            fp_index_dir VARCHAR(255) DEFAULT NULL,

            /* Текущий активный домен */
            current_domain VARCHAR(255) NOT NULL,
            vps_ip VARCHAR(45) DEFAULT NULL,

            /* История доменов (JSON массив всех доменов сайта по времени) */
            domain_history LONGTEXT,

            /* Алиасы — список FQDN, которые висят на этом сайте в FP */
            aliases LONGTEXT,

            /* Распарсенный config.php */
            config_remote_path VARCHAR(512) NOT NULL DEFAULT '',
            config_parsed_json LONGTEXT,
            config_template_kind VARCHAR(64) NOT NULL DEFAULT '',
            config_last_synced_at DATETIME DEFAULT NULL,

            /* Update url - секретный URL для вызова update_classes.php */
            update_url VARCHAR(512) NOT NULL DEFAULT '',
            update_last_called_at DATETIME DEFAULT NULL,

            /* Регистратор/контакт по умолчанию для покупки нового домена */
            registrar_account_id INT DEFAULT NULL,
            registrar_contact_id INT DEFAULT NULL,

            /* FTP */
            ftp_user VARCHAR(64) DEFAULT NULL,
            ftp_pass_enc TEXT,
            ftp_host VARCHAR(255) DEFAULT NULL,
            ftp_last_ok_at DATETIME DEFAULT NULL,

            /* Состояние */
            status VARCHAR(32) NOT NULL DEFAULT 'imported',
            note TEXT,

            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

            UNIQUE KEY uq_fp_site (fastpanel_server_id, fp_site_id),
            INDEX idx_domain (current_domain),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 5) Refresh-джобы (заявки на перевыставление) ----------
        "CREATE TABLE IF NOT EXISTS refresh_jobs (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            site_id INT NOT NULL,

            old_domain VARCHAR(255) NOT NULL,
            new_domain VARCHAR(255) NOT NULL DEFAULT '',
            old_sub_id VARCHAR(128) NOT NULL DEFAULT '',
            new_sub_id VARCHAR(128) NOT NULL DEFAULT '',
            new_yandex_verification VARCHAR(64) NOT NULL DEFAULT '',

            /* стадия пайплайна */
            stage VARCHAR(32) NOT NULL DEFAULT 'queued',
            /* стадии:
               queued
               domain_purchasing
               dns_configuring
               aliases_added
               ssl_issuing
               config_replaced
               update_called
               wm_added
               wm_verified
               wm_sitemap
               wm_robots
               wm_recrawl
               index_watching
               done
               failed
            */

            stage_status VARCHAR(16) NOT NULL DEFAULT 'pending', /* pending|running|ok|failed */
            stage_error TEXT,
            stage_started_at DATETIME DEFAULT NULL,
            stage_finished_at DATETIME DEFAULT NULL,
            next_run_at DATETIME DEFAULT NULL,

            /* JSON со снимками промежуточных артефактов: pricing, FP responses, recrawl quotas */
            artifacts_json LONGTEXT,

            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

            INDEX idx_site (site_id),
            INDEX idx_stage (stage, stage_status, next_run_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 6) Лог событий refresh-job (для UI) ----------
        "CREATE TABLE IF NOT EXISTS refresh_job_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            job_id INT NOT NULL,
            stage VARCHAR(32) NOT NULL DEFAULT '',
            level VARCHAR(16) NOT NULL DEFAULT 'info', /* info|warn|error|ok */
            message TEXT NOT NULL,
            payload_json LONGTEXT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_job (job_id, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 7) Webmaster settings (token + telegram) ----------
        "CREATE TABLE IF NOT EXISTS webmaster_settings (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            client_id VARCHAR(255) NOT NULL DEFAULT '',
            client_secret_enc TEXT,
            access_token_enc TEXT,
            refresh_token_enc TEXT,
            token_expires_at DATETIME DEFAULT NULL,
            user_id VARCHAR(64) NOT NULL DEFAULT '',
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 8) Webmaster hosts per site ----------
        "CREATE TABLE IF NOT EXISTS webmaster_hosts (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            site_id INT NOT NULL,
            job_id INT DEFAULT NULL,
            host_url VARCHAR(255) NOT NULL,
            host_id_yandex VARCHAR(128) NOT NULL DEFAULT '',
            verification_status VARCHAR(32) NOT NULL DEFAULT 'none', /* none|file_uploaded|verifying|verified|failed */
            verification_file_name VARCHAR(128) NOT NULL DEFAULT '',
            verification_file_content TEXT,
            sitemap_status VARCHAR(32) NOT NULL DEFAULT 'none',
            robots_status VARCHAR(32) NOT NULL DEFAULT 'none',
            last_recrawl_at DATETIME DEFAULT NULL,
            indexed_status VARCHAR(32) NOT NULL DEFAULT 'unknown', /* unknown|not_indexed|indexed */
            indexed_detected_at DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_site_host (site_id, host_url),
            INDEX idx_indexed (indexed_status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 9) Telegram settings ----------
        "CREATE TABLE IF NOT EXISTS telegram_settings (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            bot_token_enc TEXT,
            chat_id VARCHAR(64) NOT NULL DEFAULT '',
            enabled TINYINT(1) NOT NULL DEFAULT 0,
            notify_on_stage_ok TINYINT(1) NOT NULL DEFAULT 1,
            notify_on_stage_fail TINYINT(1) NOT NULL DEFAULT 1,
            notify_on_done TINYINT(1) NOT NULL DEFAULT 1,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 10) Cron state ----------
        "CREATE TABLE IF NOT EXISTS cron_state (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            cron_name VARCHAR(64) NOT NULL,
            last_run_at DATETIME DEFAULT NULL,
            last_ok TINYINT(1) NOT NULL DEFAULT 0,
            last_error TEXT,
            stats_json LONGTEXT,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_cron (cron_name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // ---------- 11) Migrations log ----------
        "CREATE TABLE IF NOT EXISTS migrations (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(128) NOT NULL UNIQUE,
            applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ],
];
