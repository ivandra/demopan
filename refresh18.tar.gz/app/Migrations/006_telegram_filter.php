<?php

return [
    'name' => '006_telegram_filter',

    'up' => [
        // Уровень фильтра Telegram-уведомлений.
        // Возможные значения:
        //   'all'         — всё (как было, шумно)
        //   'milestones'  — только переходы стадий + ошибки + done (по умолчанию для масштаба)
        //   'errors_only' — только error/failed/awaiting_user
        //   'off'         — Telegram выключен (можно и через enabled=0, но удобно отдельно)
        "ALTER TABLE telegram_settings
            ADD COLUMN min_level VARCHAR(20) NOT NULL DEFAULT 'milestones'
                COMMENT 'Уровень фильтра Telegram: all/milestones/errors_only/off'",

        // Сколько ok-уведомлений на одну стадию максимум (per-job).
        // По умолчанию 1 — то есть каждая стадия джобы триггерит максимум одно ok-сообщение.
        "ALTER TABLE telegram_settings
            ADD COLUMN ok_per_stage_limit INT NOT NULL DEFAULT 1
                COMMENT 'Сколько ok-сообщений на стадию максимум (per job)'",

        // Job-summary: одно сообщение в конце джобы вместо россыпи ok'ов.
        // По умолчанию TRUE — мы шлём итог при done. ok-уведомления при этом
        // фильтруются.
        "ALTER TABLE telegram_settings
            ADD COLUMN job_summary_enabled TINYINT(1) NOT NULL DEFAULT 1
                COMMENT 'Если 1 — шлём итог джобы при done вместо отдельных ok'",
    ],
];
