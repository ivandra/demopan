<?php

/**
 * v16: посайтовые настройки.
 *
 * 1. redirect_enabled — toggle включён/выключен редирект на сайте (persistent).
 *    Логика:
 *      - 1 = редирект на сайте включён (как сейчас по дефолту)
 *      - 0 = редирект выключен пользователем через UI кнопку
 *
 *    При запуске новой джобы:
 *      - Если 0 → стадия `redirect_enable` пропускается (не возвращаем редирект)
 *      - Если 1 → как раньше, возвращаем после verify
 *
 *    Это нужно когда сайт «в процессе индексации» и редирект надо держать выключенным
 *    долго — чтобы Webmaster не редиректил.
 *
 * 2. update_classes_url — опциональный кастомный URL для вызова рандома классов.
 *    Логика:
 *      - Если задан → стадия `update_classes_call` дёргает именно его
 *      - Если пуст → проверяем наличие update_classes.php через FTP в корне сайта,
 *        и если есть — дёргаем https://<new_domain>/update_classes.php
 *
 *    Стадия выполняется после ssl_le_polling, перед wm_added (или перед redirect_enable
 *    в v16 без Webmaster).
 *
 * 3. update_last_called_at — таймштамп последнего успешного вызова. Просто для UI.
 *    (поле уже есть в таблице из старых миграций — не трогаем)
 *
 * Также в этой миграции:
 *
 * 4. webmaster_account_override_id — опциональное поле джобы. Если задано,
 *    при v17 wm_account_resolve использует именно этот аккаунт для добавления
 *    нового домена (вместо «того же где старый»). Стадия wm_old_removed удалит
 *    старый домен из своего исходного аккаунта.
 */
return [
    'name' => '008_v16_quickfixes',

    'up' => [
        // 1. Toggle редиректа на карточке сайта
        "ALTER TABLE sites_managed
            ADD COLUMN redirect_enabled TINYINT(1) NOT NULL DEFAULT 1
                COMMENT 'Toggle редиректа: 1=включён, 0=пользователь выключил'
            AFTER status",

        // 2. update_classes_url — кастомный URL для рандома (если есть)
        // Поле update_url уже существует — переименовываю смысл, но оно
        // используется FpSyncService под другое. Завожу отдельное.
        "ALTER TABLE sites_managed
            ADD COLUMN update_classes_url VARCHAR(512) NOT NULL DEFAULT ''
                COMMENT 'v16: кастомный URL для вызова рандома классов (если задан, используется вместо update_classes.php)'
            AFTER update_url",

        // 4. webmaster_account_override_id в джобе
        "ALTER TABLE refresh_jobs
            ADD COLUMN webmaster_account_override_id INT NULL DEFAULT NULL
                COMMENT 'v16/v17: если задан — добавлять новый домен в этот аккаунт Webmaster (вместо same)'",

        // 5. update_classes_stage в artifacts — НЕ требует ALTER (json в artifacts_json)
    ],
];
