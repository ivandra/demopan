<?php

return [
    'name' => '003_sites_import_log',

    'up' => [
        // Лог последнего импорта/синка (JSON массив событий)
        "ALTER TABLE sites_managed
            ADD COLUMN import_log LONGTEXT NULL AFTER note,
            ADD COLUMN fp_raw_json LONGTEXT NULL AFTER import_log",
    ],
];
