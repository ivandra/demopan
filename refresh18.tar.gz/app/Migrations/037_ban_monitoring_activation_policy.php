<?php

/**
 * 037 (PATCH_2): активация «только новые джобы» + общие настройки/policy snapshot +
 * Telegram outbox + exactly-once execution-state в журнале + UNIQUE check→request.
 *
 * Forward-only, идемпотентно. Не редактирует 036. Без backfill: не присваивает
 * generation историческим джобам и не создаёт monitor. Legacy active monitor,
 * созданные v1-патчем, останавливаются БЕЗ XMLStock HTTP и БЕЗ Telegram
 * (stop_reason='v2_cutover_no_backfill'); их checks/usage сохраняются.
 */
return [
    'name' => '037_ban_monitoring_activation_policy',

    'up' => [
        // 1. singleton ban_monitoring_settings (enrollment OFF).
        function (PDO $pdo) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS ban_monitoring_settings (
                id TINYINT UNSIGNED NOT NULL,
                enrollment_enabled TINYINT(1) NOT NULL DEFAULT 0,
                processing_enabled TINYINT(1) NOT NULL DEFAULT 1,
                activation_generation INT UNSIGNED NOT NULL DEFAULT 0,
                activation_started_at DATETIME NULL,
                activation_min_job_id BIGINT UNSIGNED NULL,
                policy_version INT UNSIGNED NOT NULL DEFAULT 1,
                initial_delay_minutes INT UNSIGNED NOT NULL DEFAULT 720,
                regular_interval_minutes INT UNSIGNED NOT NULL DEFAULT 30,
                probable_negative_count INT UNSIGNED NOT NULL DEFAULT 3,
                confirm_interval_minutes INT UNSIGNED NOT NULL DEFAULT 10,
                insurance_negative_count INT UNSIGNED NOT NULL DEFAULT 3,
                insurance_interval_minutes INT UNSIGNED NOT NULL DEFAULT 10,
                technical_error_retry_minutes INT UNSIGNED NOT NULL DEFAULT 30,
                cron_batch_limit INT UNSIGNED NOT NULL DEFAULT 5,
                telegram_retry_minutes INT UNSIGNED NOT NULL DEFAULT 10,
                telegram_max_attempts INT UNSIGNED NOT NULL DEFAULT 20,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("INSERT IGNORE INTO ban_monitoring_settings (id, enrollment_enabled, processing_enabled) VALUES (1, 0, 1)");
        },

        // 2. eligibility-поля refresh_jobs (NULL по умолчанию, без backfill).
        function (PDO $pdo) {
            $addCol = function (string $table, string $col, string $ddl) use ($pdo) {
                $st = $pdo->query("SHOW COLUMNS FROM `{$table}` LIKE " . $pdo->quote($col));
                if (!$st || !$st->fetch()) $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN {$ddl}");
            };
            $addCol('refresh_jobs', 'ban_monitor_generation', "ban_monitor_generation INT UNSIGNED NULL");
            $addCol('refresh_jobs', 'ban_monitor_eligible_at', "ban_monitor_eligible_at DATETIME NULL");
            $idx = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='refresh_jobs' AND INDEX_NAME='idx_refresh_jobs_ban_generation'")->fetchColumn();
            if ((int)$idx === 0) $pdo->exec("ALTER TABLE refresh_jobs ADD INDEX idx_refresh_jobs_ban_generation (ban_monitor_generation, id)");
        },

        // 3. generation + policy snapshot в site_ban_monitors.
        function (PDO $pdo) {
            $addCol = function (string $col, string $ddl) use ($pdo) {
                $st = $pdo->query("SHOW COLUMNS FROM site_ban_monitors LIKE " . $pdo->quote($col));
                if (!$st || !$st->fetch()) $pdo->exec("ALTER TABLE site_ban_monitors ADD COLUMN {$ddl}");
            };
            $addCol('activation_generation', "activation_generation INT UNSIGNED NOT NULL DEFAULT 0");
            $addCol('policy_version', "policy_version INT UNSIGNED NOT NULL DEFAULT 1");
            $addCol('policy_snapshot_json', "policy_snapshot_json LONGTEXT NULL");
            $addCol('banned_at', "banned_at DATETIME NULL");
            $addCol('paused_from_state', "paused_from_state VARCHAR(32) NULL");
            $addCol('paused_next_check_at', "paused_next_check_at DATETIME NULL");
            $addCol('blocked_reason', "blocked_reason VARCHAR(64) NULL");
            $addCol('blocked_notified_at', "blocked_notified_at DATETIME NULL");
        },

        // 4. Telegram outbox.
        function (PDO $pdo) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS ban_monitor_notifications (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                monitor_id BIGINT UNSIGNED NOT NULL,
                source_job_id BIGINT UNSIGNED NOT NULL,
                domain VARCHAR(255) NOT NULL,
                event_key VARCHAR(255) NOT NULL,
                kind VARCHAR(32) NOT NULL,
                payload_json LONGTEXT NOT NULL,
                rendered_text LONGTEXT NOT NULL,
                status VARCHAR(24) NOT NULL DEFAULT 'pending',
                attempts INT UNSIGNED NOT NULL DEFAULT 0,
                next_attempt_at DATETIME NOT NULL,
                last_attempt_at DATETIME NULL,
                sent_at DATETIME NULL,
                last_error VARCHAR(1000) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_ban_notification_event (event_key),
                KEY idx_ban_notification_due (status, next_attempt_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        },

        // 5. execution-state поля xmlstock_request_log (exactly-once).
        function (PDO $pdo) {
            $addCol = function (string $col, string $ddl) use ($pdo) {
                $st = $pdo->query("SHOW COLUMNS FROM xmlstock_request_log LIKE " . $pdo->quote($col));
                if (!$st || !$st->fetch()) $pdo->exec("ALTER TABLE xmlstock_request_log ADD COLUMN {$ddl}");
            };
            $addCol('execution_state', "execution_state VARCHAR(32) NOT NULL DEFAULT 'reserved'");
            $addCol('reserved_at', "reserved_at DATETIME NULL");
            $addCol('started_at', "started_at DATETIME NULL");
            $addCol('ambiguous_at', "ambiguous_at DATETIME NULL");
            $addCol('failed_before_http_at', "failed_before_http_at DATETIME NULL");
            $addCol('normalized_result_json', "normalized_result_json LONGTEXT NULL");
            $addCol('transport_error', "transport_error VARCHAR(1000) NULL");
            $addCol('http_attempted', "http_attempted TINYINT(1) NOT NULL DEFAULT 0");
            $addCol('replayed_from_log', "replayed_from_log TINYINT(1) NOT NULL DEFAULT 0");
            // существующие строки: reserved_at = requested_at если пусто
            $pdo->exec("UPDATE xmlstock_request_log SET reserved_at=requested_at WHERE reserved_at IS NULL");
            $idx = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='xmlstock_request_log' AND INDEX_NAME='idx_xmlstock_execstate'")->fetchColumn();
            if ((int)$idx === 0) $pdo->exec("ALTER TABLE xmlstock_request_log ADD INDEX idx_xmlstock_execstate (execution_state, requested_at)");
        },

        // 6. UNIQUE check → request-log (apply-once). Дедуп на всякий случай.
        function (PDO $pdo) {
            $has = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='site_ban_monitor_checks' AND INDEX_NAME='uq_ban_check_request'")->fetchColumn();
            if ((int)$has === 0) {
                // убрать дубли non-null request_log_id (оставить минимальный id)
                $pdo->exec("DELETE c1 FROM site_ban_monitor_checks c1
                            JOIN site_ban_monitor_checks c2
                              ON c1.xmlstock_request_log_id = c2.xmlstock_request_log_id
                             AND c1.xmlstock_request_log_id IS NOT NULL
                             AND c1.id > c2.id");
                $pdo->exec("ALTER TABLE site_ban_monitor_checks ADD UNIQUE KEY uq_ban_check_request (xmlstock_request_log_id)");
            }
        },

        // 7. waiting_12h → нейтральное waiting_initial_delay (совместимый переход).
        function (PDO $pdo) {
            $pdo->exec("UPDATE site_ban_monitors SET state='waiting_initial_delay' WHERE state='waiting_12h'");
        },

        // 8. v2-cutover: остановить legacy active monitor БЕЗ HTTP/Telegram.
        function (PDO $pdo) {
            $pdo->exec("UPDATE site_ban_monitors
                           SET state='stopped', next_check_at=NULL, stopped_at=NOW(),
                               stop_reason='v2_cutover_no_backfill'
                         WHERE state IN ('waiting_initial_delay','monitoring','confirming','insurance')");
        },

        // 9. Audit settings-действий (activation/policy/processing) — §18.2.
        function (PDO $pdo) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS ban_monitoring_audit (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                action VARCHAR(64) NOT NULL,
                object_type VARCHAR(32) NOT NULL DEFAULT 'settings',
                object_id BIGINT UNSIGNED NULL,
                operator VARCHAR(128) NULL,
                ip VARCHAR(64) NULL,
                user_agent VARCHAR(255) NULL,
                old_values LONGTEXT NULL,
                new_values LONGTEXT NULL,
                comment VARCHAR(1000) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_bma_action (action, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        },
    ],

    // down: только новые настройки/поля/таблицы; историю платных запросов не трогаем,
    // остановленные исторические monitor не оживляем (§5.4). Idempotent DROP/DROP COLUMN.
    'down' => [
        function (PDO $pdo) { $pdo->exec("DROP TABLE IF EXISTS ban_monitor_notifications"); },
        function (PDO $pdo) { $pdo->exec("DROP TABLE IF EXISTS ban_monitoring_audit"); },
        function (PDO $pdo) { $pdo->exec("DROP TABLE IF EXISTS ban_monitoring_settings"); },
        function (PDO $pdo) {
            $drop = function (string $table, string $col) use ($pdo) {
                $st = $pdo->query("SHOW COLUMNS FROM `{$table}` LIKE " . $pdo->quote($col));
                if ($st && $st->fetch()) { try { $pdo->exec("ALTER TABLE `{$table}` DROP COLUMN `{$col}`"); } catch (\Throwable $e) {} }
            };
            foreach (['ban_monitor_generation', 'ban_monitor_eligible_at'] as $c) $drop('refresh_jobs', $c);
            foreach (['activation_generation', 'policy_version', 'policy_snapshot_json', 'banned_at', 'paused_from_state', 'paused_next_check_at', 'blocked_reason', 'blocked_notified_at'] as $c) $drop('site_ban_monitors', $c);
            foreach (['execution_state', 'reserved_at', 'started_at', 'ambiguous_at', 'failed_before_http_at', 'normalized_result_json', 'transport_error', 'http_attempted', 'replayed_from_log'] as $c) $drop('xmlstock_request_log', $c);
        },
    ],
];
