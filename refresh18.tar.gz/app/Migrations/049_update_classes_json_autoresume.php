<?php

/**
 * HOTPATCH §7.8: идемпотентный data-fix ТОЛЬКО внутри Refresh Panel.
 *
 * Возвращает в 'pending' застрявшие ДО выполнения auto-джобы, которые встали в
 * awaiting_user ИМЕННО из-за update_classes_family_unresolved (старый registry не узнавал
 * новую JSON-версию update_classes.php). В БД этот и только этот случай маркируется
 * stage_error = 'update_classes: baseline_unavailable_unknown' (скрипт найден, но семейство
 * не распознано — не путать с custom_*, expected_physical_root_*, baseline_variant_state_*,
 * recovery_*, started_without_profile). После requeue новый registry распознаёт скрипт,
 * панель снимает baseline и делает ОДИН нормальный проверяемый запуск.
 *
 * Requeue РОВНО когда ОДНОВРЕМЕННО:
 *   stage = 'update_classes_call'
 *   stage_status = 'awaiting_user'
 *   stage_error = 'update_classes: baseline_unavailable_unknown'  (family_unresolved)
 *   uc_mode = auto           (sites_managed.uc_mode = 'auto' или NULL; custom/disabled — НЕТ)
 *   uc_execution_state ∈ {NULL,'','not_started'}   (started/ambiguous/completed — НЕТ)
 *   uc_execution_id пуст
 *   uc_execution_attempts = 0
 *   php_uniquification_verified_at IS NULL          (verified — НЕТ)
 *   artifacts_json.update_classes_stage.outcome пуст
 *   НЕ operator_skipped / skipped_by_operator
 *
 * §7.8: НИКАКОГО пустого catch — ошибка SQL data-fix ОБЯЗАНА останавливать установку.
 * Идемпотентна (после requeue строка уже не awaiting_user → 0 совпадений при повторе).
 * Пишет count в app_settings (audit) если таблица есть. Новых колонок не создаёт. Без хардкода.
 */
return [
    'name' => '049_update_classes_json_autoresume',

    'up' => [
        function (PDO $pdo): void {
            // §4.1 fail-closed: ЛЮБАЯ отсутствующая обязательная таблица/колонка → исключение,
            // установка останавливается, миграция НЕ регистрируется как успешная. Молчаливый
            // return запрещён (он бы дал «применено» без data-fix).
            $required = [
                'refresh_jobs' => ['stage','stage_status','stage_error','next_run_at',
                    'php_uniquification_verified_at','uc_execution_state','uc_execution_id',
                    'uc_execution_attempts','artifacts_json','site_id'],
                'sites_managed' => ['id','uc_mode','uc_detection_json'],
                'app_settings' => ['setting_key','setting_value','value_type','description'],
            ];
            foreach ($required as $table => $cols) {
                $tb = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
                if (!$tb || !$tb->fetch()) {
                    throw new \RuntimeException("Migration 049 schema mismatch: missing table {$table}");
                }
                foreach ($cols as $col) {
                    $st = $pdo->query("SHOW COLUMNS FROM {$table} LIKE " . $pdo->quote($col));
                    if (!$st || !$st->fetch()) {
                        throw new \RuntimeException("Migration 049 schema mismatch: missing column {$table}.{$col}");
                    }
                }
            }
            // uc_mode гарантированно есть (проверено выше) — все сайты как 'auto' НЕ считаем.
            $ucModeJoin = "LEFT JOIN sites_managed sm ON sm.id = j.site_id";
            $ucModeCond = "AND COALESCE(sm.uc_mode, 'auto') = 'auto'";

            $sql =
                "UPDATE refresh_jobs j
                 $ucModeJoin
                 SET j.stage_status = 'pending',
                     j.stage_error  = NULL,
                     j.next_run_at  = NOW()
                 WHERE j.stage = 'update_classes_call'
                   AND j.stage_status = 'awaiting_user'
                   -- РОВНО family_unresolved. baseline_unavailable_unknown возможен по разным
                   -- причинам strategy=unknown; поэтому требуем ПРОВАБЕЛЬНЫЙ признак family_unresolved.
                   -- Блокер 5 (REV2): признак берём ИЗ ЛЮБОГО источника —
                   --   (a) новый artifacts.update_classes_stage.baseline_reason (пишет новый код), ЛИБО
                   --   (b) существующий sites_managed.uc_detection_json.reason (реальные legacy-данные дампа).
                   -- Строки без НИ ОДНОГО из признаков НЕ requeue-им (fail-closed).
                   AND j.stage_error = 'update_classes: baseline_unavailable_unknown'
                   AND (
                        JSON_UNQUOTE(JSON_EXTRACT(j.artifacts_json, '$.update_classes_stage.baseline_reason'))
                            = 'update_classes_family_unresolved'
                     OR JSON_UNQUOTE(JSON_EXTRACT(sm.uc_detection_json, '$.reason'))
                            = 'update_classes_family_unresolved'
                   )
                   AND j.php_uniquification_verified_at IS NULL
                   AND (j.uc_execution_state IS NULL OR j.uc_execution_state = '' OR j.uc_execution_state = 'not_started')
                   AND (j.uc_execution_id IS NULL OR j.uc_execution_id = '')
                   AND (j.uc_execution_attempts IS NULL OR j.uc_execution_attempts = 0)
                   $ucModeCond
                   AND (
                        JSON_EXTRACT(j.artifacts_json, '$.update_classes_stage.outcome') IS NULL
                        OR JSON_UNQUOTE(JSON_EXTRACT(j.artifacts_json, '$.update_classes_stage.outcome')) = ''
                   )
                   AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(j.artifacts_json, '$.update_classes_stage.operator_skipped')), 'false') NOT IN ('true', '1')
                   AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(j.artifacts_json, '$.update_classes_stage.skipped_by_operator')), 'false') NOT IN ('true', '1')";

            // §7.8: БЕЗ catch — SQL-ошибка пробрасывается и останавливает установку.
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $affected = $stmt->rowCount();

            // Audit (идемпотентный): app_settings гарантированно есть (проверено в preflight).
            // INSERT не заглушаем — ошибка пробрасывается.
            $pdo->prepare(
                "INSERT INTO app_settings (setting_key, setting_value, value_type, description)
                 VALUES ('migration.049.last_requeued', ?, 'int', 'auto-resume family_unresolved requeued rows')
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
            )->execute([(string)$affected]);
        },
    ],

    // down: намеренно пусто — разовый безопасный requeue, откат не имеет смысла
    // (схему не создаёт, ok/verified_at не выставляет).
    'down' => [],
];
