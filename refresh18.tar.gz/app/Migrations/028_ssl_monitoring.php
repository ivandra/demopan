<?php

/**
 * v25.1-b: SSL-мониторинг — хранилище live-состояния SSL/доступности доменов,
 * история проверок и компактная таблица массовых прогонов «Проверить все».
 *
 * ВАЖНО:
 *  - ядровые поля pipeline (domain_technical_ready_at и др.) уже добавлены
 *    миграцией 027 — здесь НЕ дублируем;
 *  - существующую `ssl_attempt_log` (события ВЫПУСКА сертификата) НЕ трогаем;
 *  - миграции 025/026/027 не изменяются;
 *  - всё идемпотентно (CREATE TABLE IF NOT EXISTS, information_schema-гарды).
 *
 * Таблицы:
 *  - domain_ssl_statuses      — текущее состояние по домену (UNIQUE(domain));
 *  - domain_ssl_check_history — история проверок (для аудита, ретеншен);
 *  - domain_ssl_batches       — массовые прогоны «Проверить все» (прогресс/стоп).
 */
return [
    'name' => '028_ssl_monitoring',

    'up' => [
        // 1) Текущее состояние SSL/доступности по домену.
        function (PDO $pdo) {
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS domain_ssl_statuses (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    domain VARCHAR(255) NOT NULL,
                    site_id INT NULL,
                    job_id INT NULL,
                    dns_ok TINYINT(1) NOT NULL DEFAULT 0,
                    resolved_ips_json TEXT NULL,
                    http_code INT NULL,
                    http_location VARCHAR(2048) NULL,
                    yandexbot_http_code INT NULL,
                    yandexbot_location VARCHAR(2048) NULL,
                    https_initial_code INT NULL,
                    https_final_code INT NULL,
                    https_final_url VARCHAR(2048) NULL,
                    technical_ready TINYINT(1) NOT NULL DEFAULT 0,
                    site_reachable TINYINT(1) NOT NULL DEFAULT 0,
                    probe_ok TINYINT(1) NULL,
                    probe_http_code INT NULL,
                    tls_present TINYINT(1) NOT NULL DEFAULT 0,
                    tls_trusted TINYINT(1) NOT NULL DEFAULT 0,
                    is_self_signed TINYINT(1) NOT NULL DEFAULT 0,
                    hostname_valid TINYINT(1) NOT NULL DEFAULT 0,
                    issuer VARCHAR(512) NULL,
                    subject VARCHAR(512) NULL,
                    serial_number VARCHAR(128) NULL,
                    valid_from DATETIME NULL,
                    valid_to DATETIME NULL,
                    days_remaining INT NULL,
                    status VARCHAR(32) NOT NULL DEFAULT 'not_checked',
                    reason VARCHAR(128) NULL,
                    error_message VARCHAR(1024) NULL,
                    checked_at DATETIME NULL,
                    check_source VARCHAR(16) NULL,
                    next_check_at DATETIME NULL,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY uniq_domain (domain),
                    KEY idx_status_next (status, next_check_at),
                    KEY idx_site (site_id),
                    KEY idx_job (job_id)
                 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
        },

        // 2) История проверок (аудит). Ретеншен применяется сервисом.
        function (PDO $pdo) {
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS domain_ssl_check_history (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    domain VARCHAR(255) NOT NULL,
                    site_id INT NULL,
                    job_id INT NULL,
                    status VARCHAR(32) NOT NULL,
                    technical_ready TINYINT(1) NOT NULL DEFAULT 0,
                    http_code INT NULL,
                    https_final_code INT NULL,
                    tls_trusted TINYINT(1) NOT NULL DEFAULT 0,
                    is_self_signed TINYINT(1) NOT NULL DEFAULT 0,
                    reason VARCHAR(128) NULL,
                    result_json MEDIUMTEXT NULL,
                    check_source VARCHAR(16) NULL,
                    checked_by VARCHAR(64) NULL,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    KEY idx_domain_created (domain, created_at),
                    KEY idx_created (created_at)
                 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
        },

        // 3) Массовые прогоны «Проверить все» — компактно, с прогрессом/стопом.
        function (PDO $pdo) {
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS domain_ssl_batches (
                    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    status VARCHAR(16) NOT NULL DEFAULT 'running',
                    total INT NOT NULL DEFAULT 0,
                    queued INT NOT NULL DEFAULT 0,
                    checking INT NOT NULL DEFAULT 0,
                    done INT NOT NULL DEFAULT 0,
                    ok_count INT NOT NULL DEFAULT 0,
                    warn_count INT NOT NULL DEFAULT 0,
                    error_count INT NOT NULL DEFAULT 0,
                    started_by VARCHAR(64) NULL,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    KEY idx_status (status)
                 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
        },

        // 4) Привязка домена к batch + состояние очереди на статусе (для прогресса
        //    и корректной отмены «не начатых»). Колонки на domain_ssl_statuses.
        function (PDO $pdo) {
            $cols = [
                'batch_id' => "ADD COLUMN batch_id BIGINT UNSIGNED NULL COMMENT 'v25.1-b: текущий массовый прогон'",
                'batch_state' => "ADD COLUMN batch_state VARCHAR(16) NULL COMMENT 'v25.1-b: queued/checking/done в рамках batch'",
            ];
            foreach ($cols as $name => $ddl) {
                $st = $pdo->query("SHOW COLUMNS FROM domain_ssl_statuses LIKE " . $pdo->quote($name));
                if ($st && $st->fetch()) continue;
                $pdo->exec("ALTER TABLE domain_ssl_statuses " . $ddl);
            }
            // индекс для выборки очереди batch на cron-tick
            $chk = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'domain_ssl_statuses'
                    AND INDEX_NAME = 'idx_batch_state'"
            )->fetchColumn();
            if ((int)$chk === 0) {
                $pdo->exec("ALTER TABLE domain_ssl_statuses ADD KEY idx_batch_state (batch_id, batch_state)");
            }
        },
    ],
];
