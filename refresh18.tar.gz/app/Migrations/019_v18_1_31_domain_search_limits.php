<?php

/**
 * Миграция 019 (v18.1.31):
 *   Добавляет дефолтные значения в app_settings для domain.candidates_per_tick
 *   и domain.candidates_max_total.
 *
 *   Раньше: hardcoded MAX_ATTEMPTS=5 в DomainPurchaseService — джобы падали
 *   с all_candidates_failed когда подряд 5+ доменов заняты.
 *   Теперь: 30 за tick (продолжение в следующих tick'ах), потолок 200.
 *
 *   INSERT IGNORE — повторный запуск не перетирает уже измененные значения.
 */

return [
    'name' => '019_v18_1_31_domain_search_limits',

    'up' => [
        "INSERT IGNORE INTO app_settings (setting_key, setting_value, value_type, description) VALUES
            ('domain.candidates_per_tick', '30', 'int',
                'Сколько кандидатов проверять за один cron-tick. 1-200.'),
            ('domain.candidates_max_total', '200', 'int',
                'Жёсткий потолок общего числа проверенных доменов. После — остановка.')",
    ],
];
