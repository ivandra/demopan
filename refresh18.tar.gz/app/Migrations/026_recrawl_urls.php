<?php

/**
 * v25.0-b: таблица per-URL учёта отправки в переобход (recrawl) Яндекс.Вебмастера.
 *
 * Причина: стадия wm_recrawl отправляла URL «одним проходом» и писала общий
 * успех даже при частичной отправке; недосланные URL терялись, повторной
 * досылки не было, квота считалась в памяти. Заказчик прямо указал на этот
 * дефект: «не делает отправление в индекс». Нужен полноценный per-URL
 * lifecycle с досылкой до полного успеха.
 *
 * artifacts_json для этого не подходит: нужны атомарные попытки, защита от
 * двойной отправки двумя cron, выборка «готовых к следующей попытке», история
 * независимо от размера JSON. Поэтому — отдельная таблица.
 *
 * Статусы:
 *   pending        — запланирован, ещё не отправлялся;
 *   pending_quota  — не хватило дневной квоты, ждём следующего окна;
 *   retry          — временная ошибка, повтор по next_retry_at;
 *   accepted       — Яндекс принял URL в очередь переобхода (финальный успех);
 *   failed         — исчерпаны попытки (требует внимания оператора);
 *   excluded       — исключён по разрешённому правилу (тоже финальный).
 *
 * Миграции 023/024/025 НЕ изменяются. Шаги идемпотентны.
 */
return [
    'name' => '026_recrawl_urls',

    'up' => [
        function (PDO $pdo) {
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS refresh_job_recrawl_urls (
                    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    job_id INT NOT NULL,
                    url VARCHAR(2048) NOT NULL,
                    url_hash CHAR(40) NOT NULL
                        COMMENT 'sha1(url) — для UNIQUE, т.к. VARCHAR(2048) в индекс не влезает',
                    is_required TINYINT NOT NULL DEFAULT 1
                        COMMENT 'обязательный URL (главная/sitemap/ключевые) vs дополнительный',
                    role VARCHAR(24) NOT NULL DEFAULT 'page'
                        COMMENT 'home | sitemap | page — для gate завершения стадии',
                    status VARCHAR(16) NOT NULL DEFAULT 'pending'
                        COMMENT 'pending|pending_quota|retry|accepted|failed|excluded',
                    attempts INT NOT NULL DEFAULT 0,
                    last_http_code INT DEFAULT NULL,
                    last_page_http_code INT DEFAULT NULL
                        COMMENT 'v25.0-b1: HTTP-код preflight-проверки самой страницы',
                    last_api_http_code INT DEFAULT NULL
                        COMMENT 'v25.0-b1: HTTP-код ответа recrawl API',
                    last_api_error_code VARCHAR(48) DEFAULT NULL
                        COMMENT 'v25.0-b1: код ошибки API (URL_ALREADY_ADDED/QUOTA_EXCEEDED/...)',
                    task_id VARCHAR(128) DEFAULT NULL
                        COMMENT 'v25.0-b1: task_id из ответа recrawl API (доказательство приёма)',
                    api_accepted TINYINT NOT NULL DEFAULT 0,
                    accepted_at DATETIME DEFAULT NULL,
                    last_error VARCHAR(1000) DEFAULT NULL,
                    next_retry_at DATETIME DEFAULT NULL,
                    claimed_at DATETIME DEFAULT NULL
                        COMMENT 'v25.0-b1: когда строка захвачена (для восстановления stale __claimed)',
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY uq_job_url (job_id, url_hash),
                    KEY idx_job_status (job_id, status),
                    KEY idx_status_retry (status, next_retry_at),
                    KEY idx_claimed (status, claimed_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
        },
        // v25.0-b1: добить колонки, если таблица создана прежней версией 026.
        function (PDO $pdo) {
            $cols = [
                'last_page_http_code' => "ADD COLUMN last_page_http_code INT DEFAULT NULL",
                'last_api_http_code'  => "ADD COLUMN last_api_http_code INT DEFAULT NULL",
                'last_api_error_code' => "ADD COLUMN last_api_error_code VARCHAR(48) DEFAULT NULL",
                'task_id'             => "ADD COLUMN task_id VARCHAR(128) DEFAULT NULL",
                'claimed_at'          => "ADD COLUMN claimed_at DATETIME DEFAULT NULL",
            ];
            foreach ($cols as $name => $ddl) {
                $chk = $pdo->prepare(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS
                      WHERE TABLE_SCHEMA = DATABASE()
                        AND TABLE_NAME = 'refresh_job_recrawl_urls'
                        AND COLUMN_NAME = ?"
                );
                $chk->execute([$name]);
                if ((int)$chk->fetchColumn() === 0) {
                    $pdo->exec("ALTER TABLE refresh_job_recrawl_urls {$ddl}");
                }
            }
            // Индекс для stale-claims (idempotent).
            $idx = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE()
                    AND TABLE_NAME = 'refresh_job_recrawl_urls'
                    AND INDEX_NAME = 'idx_claimed'"
            )->fetchColumn();
            if ((int)$idx === 0) {
                $pdo->exec("ALTER TABLE refresh_job_recrawl_urls ADD KEY idx_claimed (status, claimed_at)");
            }
        },
    ],
];
