<?php

/**
 * v17: кеш привязки site → Webmaster account.
 *
 * Назначение: при первом запуске Webmaster-стадии для сайта мы пробегаем по
 * всем активным аккаунтам и ищем старый домен через getHosts(). Кто отдал —
 * запоминается тут. На последующих джобах берём из БД (без API-запроса).
 *
 * При смене аккаунта (override через форму джобы) — обновляем запись.
 */
return [
    'name' => '009_v17_webmaster',

    'up' => [
        "CREATE TABLE IF NOT EXISTS site_webmaster_links (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            site_id INT NOT NULL,
            domain VARCHAR(255) NOT NULL COMMENT 'Домен на момент привязки',
            webmaster_account_id INT NOT NULL,
            user_id VARCHAR(64) NOT NULL DEFAULT '' COMMENT 'Yandex userId (закешен)',
            host_id VARCHAR(128) NOT NULL DEFAULT '' COMMENT 'Yandex hostId (закешен, после addHost)',
            verified TINYINT(1) NOT NULL DEFAULT 0,
            verification_uin VARCHAR(64) NOT NULL DEFAULT '',
            verification_file VARCHAR(255) NOT NULL DEFAULT '',
            sitemap_added TINYINT(1) NOT NULL DEFAULT 0,
            recrawl_requested TINYINT(1) NOT NULL DEFAULT 0,
            indexed TINYINT(1) NOT NULL DEFAULT 0,
            indexed_pages_count INT NOT NULL DEFAULT 0,
            removed_at DATETIME DEFAULT NULL COMMENT 'Когда удалили из Webmaster (null = ещё активен)',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_site_domain (site_id, domain),
            KEY idx_account (webmaster_account_id),
            KEY idx_domain (domain)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='v17: кеш site→Webmaster account + состояние домена в нём'",

        // Расширяем index_watching состоянием
        // (artifacts_json и так может это держать — но имеет смысл хранить
        //  «является ли этот домен в данный момент в индексе» на уровне site_webmaster_links)
    ],
];
