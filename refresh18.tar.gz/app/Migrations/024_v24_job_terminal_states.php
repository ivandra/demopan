<?php

/**
 * v24: терминальные состояния джоб — cancelled и superseded.
 *
 * Причина: у джобы не было безопасного терминального статуса, кроме done и
 * failed. Джоба в stage_status='awaiting_user' считалась активной бессрочно,
 * из-за чего сайт оставался заблокированным для новых джоб месяцами
 * (на боевой панели так висело 7 сайтов, старейший — 57 суток).
 *
 * Просто игнорировать awaiting_user в блокирующем SELECT нельзя: старая джоба
 * остаётся исполняемой и после действия оператора или cron может продолжить
 * работу параллельно с новой — с одновременной записью в один docroot,
 * .htaccess, config.php и данные Вебмастера. Поэтому вводится явное закрытие.
 *
 * Значения кладём в существующее поле stage: done и failed уже являются
 * терминальными значениями этого же поля, отдельная колонка состояния создала
 * бы два источника правды.
 *
 *   cancelled  — оператор закрыл джобу вручную, новая НЕ создавалась;
 *   superseded — джоба закрыта и заменена новой (superseded_by_job_id).
 *
 * Миграция 023 не изменяется — она уже применена на рабочей панели.
 *
 * Шаги идемпотентны: повторный запуск ничего не ломает.
 */
return [
    'name' => '024_v24_job_terminal_states',

    'up' => [
        function (PDO $pdo) {
            $cols = [
                'superseded_by_job_id' => "ADD COLUMN superseded_by_job_id INT DEFAULT NULL
                    COMMENT 'v24: ID новой джобы, заменившей эту (только для stage=superseded)'",
                'closed_at' => "ADD COLUMN closed_at DATETIME DEFAULT NULL
                    COMMENT 'v24: когда джоба была закрыта оператором'",
                'closed_by' => "ADD COLUMN closed_by VARCHAR(64) DEFAULT NULL
                    COMMENT 'v24: логин оператора; числовых ID пользователей в панели нет'",
                'closed_reason' => "ADD COLUMN closed_reason VARCHAR(255) DEFAULT NULL
                    COMMENT 'v24: причина закрытия; для cancelled обязательна'",
            ];

            foreach ($cols as $name => $ddl) {
                $st = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE " . $pdo->quote($name));
                if ($st && $st->fetch()) {
                    continue; // колонка уже есть
                }
                $pdo->exec("ALTER TABLE refresh_jobs " . $ddl);
            }
        },

        function (PDO $pdo) {
            // Индекс для выборок «чем заменена» и для отчётов по закрытым джобам.
            $st = $pdo->query("SHOW INDEX FROM refresh_jobs WHERE Key_name = 'idx_superseded_by'");
            if ($st && $st->fetch()) {
                return;
            }
            $pdo->exec("ALTER TABLE refresh_jobs ADD INDEX idx_superseded_by (superseded_by_job_id)");
        },
    ],
];
