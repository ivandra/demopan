<?php

/**
 * 042_terminal_job_timers_and_ssl_sync (ТЗ «SSL сводка терминальной джобы»)
 *
 * Чистит исторические записи так, чтобы верхняя сводка терминальной джобы не
 * показывала процессные состояния и несуществующий «следующий SSL-poll».
 *
 * 1. Снять таймеры у всех терминальных джоб (done/failed/cancelled/superseded):
 *    next_run_at = NULL, ssl_issue_next_poll_at = NULL.
 * 2. Безопасно синхронизировать trusted SSL в поля джобы ТОЛЬКО при наличии
 *    реального подтверждения в domain_ssl_statuses (status='trusted' OR
 *    tls_trusted=1). domain_ssl_trusted_at не перетираем (COALESCE).
 *
 * НЕ заполняем массово domain_https_ready_at — у поля более строгая семантика,
 * его нельзя ставить только по факту done. НЕ добавляем колонок, НЕ удаляем строк,
 * без внешних вызовов. Идемпотентна: второй запуск меняет 0 строк.
 */

return [
    'up' => [
        // 1) снять таймеры у терминальных джоб
        function (PDO $pdo) {
            $pdo->exec(
                "UPDATE refresh_jobs
                    SET next_run_at = NULL, ssl_issue_next_poll_at = NULL
                  WHERE stage IN ('done','failed','cancelled','superseded')
                    AND (next_run_at IS NOT NULL OR ssl_issue_next_poll_at IS NOT NULL)"
            );
        },
        // 2) безопасная синхронизация trusted SSL только при реальном подтверждении
        function (PDO $pdo) {
            $pdo->exec(
                "UPDATE refresh_jobs j
                    JOIN domain_ssl_statuses s
                      ON s.domain = j.new_domain COLLATE utf8mb4_unicode_ci
                     SET j.domain_ssl_state = 'trusted',
                         j.domain_ssl_trusted_at = COALESCE(j.domain_ssl_trusted_at, s.checked_at)
                   WHERE j.stage = 'done'
                     AND j.stage_status = 'ok'
                     AND (s.status = 'trusted' OR s.tls_trusted = 1)
                     AND (j.domain_ssl_state <> 'trusted' OR j.domain_ssl_trusted_at IS NULL)"
            );
        },
    ],
    'down' => [
        // Обратный откат не требуется: таймеры терминальных джоб не несут смысла,
        // а trusted-синхронизация выставлена только по фактическому подтверждению.
        function (PDO $pdo) { /* no-op */ },
    ],
];
