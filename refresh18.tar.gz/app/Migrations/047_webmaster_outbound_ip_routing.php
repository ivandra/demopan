<?php

/**
 * PATCH 047: жёсткая привязка исходящего IPv4 к каждому аккаунту Yandex.Webmaster.
 *
 * Создаёт:
 *   - webmaster_outbound_ips     — управляемый пул исходящих IPv4 (данные, не хардкод);
 *   - webmaster_api_request_log  — аудит КАЖДОГО запроса к api.webmaster.yandex.net;
 *   - yandex_webmaster_accounts.outbound_ip_id (+ idx) — привязка аккаунта к IP;
 *   - yandex_webmaster_accounts.last_outbound_* — снапшот последней проверки для UI.
 *
 * Idempotent seed 4 текущих production-IP (default = 155.212.141.141). IP — данные БД,
 * редактируемые через UI; при миграции VPS меняются без правки PHP (§13/§60).
 * Существующие аккаунты остаются outbound_ip_id=NULL → resolver направит их на DEFAULT.
 */
return [
    'name' => '047_webmaster_outbound_ip_routing',

    'up' => [
        // 1) Пул исходящих IP.
        "CREATE TABLE IF NOT EXISTS webmaster_outbound_ips (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            ip_address VARCHAR(45) NOT NULL,
            label VARCHAR(255) NOT NULL DEFAULT '',
            is_enabled TINYINT(1) NOT NULL DEFAULT 1,
            is_default TINYINT(1) NOT NULL DEFAULT 0,
            last_probe_at DATETIME NULL,
            last_probe_ok TINYINT(1) NULL,
            last_probe_local_ip VARCHAR(45) NULL,
            last_probe_public_ip VARCHAR(45) NULL,
            last_probe_remote_ip VARCHAR(45) NULL,
            last_probe_http_code INT NULL,
            last_probe_error TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_webmaster_outbound_ip (ip_address)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // 2) Аудит каждого Webmaster API request.
        "CREATE TABLE IF NOT EXISTS webmaster_api_request_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            request_uid VARCHAR(64) NOT NULL,
            webmaster_account_id INT UNSIGNED NOT NULL,
            refresh_job_id INT UNSIGNED NULL,
            stage VARCHAR(64) NULL,
            method VARCHAR(10) NOT NULL,
            endpoint VARCHAR(255) NOT NULL,
            expected_outbound_ip VARCHAR(45) NOT NULL,
            actual_local_ip VARCHAR(45) NULL,
            remote_ip VARCHAR(45) NULL,
            source_ip_verified TINYINT(1) NOT NULL DEFAULT 0,
            http_code INT NULL,
            curl_errno INT NULL,
            duration_ms INT NULL,
            result ENUM('success','http_error','network_error','source_ip_mismatch') NOT NULL,
            error_summary VARCHAR(500) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_wm_api_account_time (webmaster_account_id, created_at),
            KEY idx_wm_api_job (refresh_job_id),
            KEY idx_wm_api_source_check (source_ip_verified, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        // 3) yandex_webmaster_accounts: привязка + снапшот.
        function (PDO $pdo) {
            $add = function (string $col, string $ddl) use ($pdo) {
                $st = $pdo->query("SHOW COLUMNS FROM yandex_webmaster_accounts LIKE '" . $col . "'");
                if (!$st || !$st->fetch()) {
                    $pdo->exec("ALTER TABLE yandex_webmaster_accounts " . $ddl);
                }
            };
            $add('outbound_ip_id',
                "ADD COLUMN outbound_ip_id INT UNSIGNED NULL COMMENT 'PATCH047: FK→webmaster_outbound_ips.id; NULL=DEFAULT из пула'");
            $add('last_outbound_ip_expected',
                "ADD COLUMN last_outbound_ip_expected VARCHAR(45) NULL COMMENT 'PATCH047: последний ожидаемый исходящий IP'");
            $add('last_outbound_ip_actual',
                "ADD COLUMN last_outbound_ip_actual VARCHAR(45) NULL COMMENT 'PATCH047: последний фактический CURLINFO_LOCAL_IP'");
            $add('last_outbound_verified_at',
                "ADD COLUMN last_outbound_verified_at DATETIME NULL COMMENT 'PATCH047: когда последний раз подтверждён IP'");
            $add('last_outbound_ok',
                "ADD COLUMN last_outbound_ok TINYINT(1) NULL COMMENT 'PATCH047: expected===actual в последней проверке'");
            $add('last_outbound_error',
                "ADD COLUMN last_outbound_error VARCHAR(500) NULL COMMENT 'PATCH047: последняя ошибка маршрутизации'");

            $idx = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'yandex_webmaster_accounts'
                    AND INDEX_NAME = 'idx_ywa_outbound_ip'"
            )->fetchColumn();
            if ((int)$idx === 0) {
                $pdo->exec("ALTER TABLE yandex_webmaster_accounts ADD INDEX idx_ywa_outbound_ip (outbound_ip_id)");
            }
        },

        // 4) Idempotent seed текущих production-IP (default = основной VPS IP).
        function (PDO $pdo) {
            $seed = [
                ['155.212.141.141', 'Основной IP VPS',   1],
                ['85.198.71.117',   'Webmaster IP 1',    0],
                ['159.194.239.127', 'Webmaster IP 2',    0],
                ['45.90.33.30',     'Webmaster IP 3',    0],
            ];
            $ins = $pdo->prepare(
                "INSERT INTO webmaster_outbound_ips (ip_address, label, is_enabled, is_default)
                 VALUES (?, ?, 1, ?)
                 ON DUPLICATE KEY UPDATE label = VALUES(label)"
            );
            foreach ($seed as [$ip, $label, $isDefault]) {
                $ins->execute([$ip, $label, $isDefault]);
            }
            // Инвариант «ровно один enabled default»: если после seed default!=1 — чиним на основной IP.
            $cnt = (int)$pdo->query(
                "SELECT COUNT(*) FROM webmaster_outbound_ips WHERE is_default=1 AND is_enabled=1"
            )->fetchColumn();
            if ($cnt !== 1) {
                $pdo->exec("UPDATE webmaster_outbound_ips SET is_default=0");
                $pdo->prepare("UPDATE webmaster_outbound_ips SET is_default=1, is_enabled=1 WHERE ip_address=?")
                    ->execute(['155.212.141.141']);
            }
        },
    ],
];
