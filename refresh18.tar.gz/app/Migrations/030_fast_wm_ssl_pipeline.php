<?php

/**
 * v25.2-a: быстрый WM/SSL pipeline. Диагностические колонки подэтапов стадии
 * wm_verified — минимальный набор для быстрых SQL-запросов, пробуждения джобы
 * и диагностики. Полное durable-состояние (uin/filename/content/sha256/method/
 * коды/ошибки) хранится в artifacts JSON (wm_verified_stage) — здесь НЕ дублируем.
 *
 * Отдельная идемпотентная миграция. НЕ редактирует 027/028/029.
 * SHOW COLUMNS / information_schema гарды — безопасно поверх любой базы.
 */
return [
    'name' => '030_fast_wm_ssl_pipeline',

    'up' => [
        function (PDO $pdo) {
            $cols = [
                'wm_verifier_uploaded_at'      => "ADD COLUMN wm_verifier_uploaded_at DATETIME NULL COMMENT 'v25.2: verifier залит по FTP'",
                'wm_verifier_public_at'        => "ADD COLUMN wm_verifier_public_at DATETIME NULL COMMENT 'v25.2: verifier публично доступен (нестрогий probe)'",
                'wm_verifier_strict_https_at'  => "ADD COLUMN wm_verifier_strict_https_at DATETIME NULL COMMENT 'v25.2: пройден строгий HTTPS-gate'",
                'wm_verification_submitted_at' => "ADD COLUMN wm_verification_submitted_at DATETIME NULL COMMENT 'v25.2: POST verification отправлен'",
                'wm_verification_last_state'   => "ADD COLUMN wm_verification_last_state VARCHAR(32) NULL COMMENT 'v25.2: последнее состояние верификации'",
                'wm_verification_last_poll_at' => "ADD COLUMN wm_verification_last_poll_at DATETIME NULL COMMENT 'v25.2: время последнего poll'",
                // v25.2 §4: фиксация факта запуска выпуска trusted SSL (идемпотентность).
                'ssl_issue_requested_at'       => "ADD COLUMN ssl_issue_requested_at DATETIME NULL COMMENT 'v25.2: запрошен выпуск trusted SSL (после aliases_added)'",
            ];
            foreach ($cols as $name => $ddl) {
                $st = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE " . $pdo->quote($name));
                if ($st && $st->fetch()) continue;
                $pdo->exec("ALTER TABLE refresh_jobs " . $ddl);
            }

            // Индекс для быстрого поиска джоб, ждущих подэтапы (диагностика/пробуждение).
            $chk = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'refresh_jobs'
                    AND INDEX_NAME = 'idx_wm_subphase'"
            )->fetchColumn();
            if ((int)$chk === 0) {
                $pdo->exec("ALTER TABLE refresh_jobs ADD KEY idx_wm_subphase (wm_verification_last_state, wm_verifier_strict_https_at)");
            }
        },
    ],
];
