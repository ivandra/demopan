<?php

/**
 * v18.1.2: добавляет колонку autopatch_robots_php в sites_managed.
 *
 * Стадия verify_replacement делает 5-ю проверку robots_php_logic (статический
 * анализ файла robots.php на наличие sameHost-защиты).
 *
 * Поведение при некорректном файле:
 *   - autopatch_robots_php = 1 (DEFAULT): система САМА перезаписывает
 *     robots.php рекомендуемым шаблоном через FTP и продолжает pipeline.
 *     Backup сохраняется в storage/snapshots/job_{N}/robots_php.before.txt
 *     и в .bak_TIMESTAMP файл рядом с оригиналом на FTP.
 *   - autopatch_robots_php = 0: джоба уходит в awaiting_user, оператор
 *     правит файл руками.
 *
 * Default = 1 (включено) — большинство шаблонов простые (1win-стиль),
 * автоматическая правка экономит время оператора. Для сайтов с кастомным
 * robots.php (блокировка отдельных user-agent'ов и т.п.) — выключай вручную
 * через UI карточки сайта.
 *
 * Идемпотентная — через хранимую процедуру с INFORMATION_SCHEMA проверкой.
 */
return [
    'name' => '014_v18_autopatch_robots_php',

    'up' => [
        // sites_managed.autopatch_robots_php
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_014",
        "CREATE PROCEDURE _refresh_panel_add_col_014()
         BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'sites_managed'
                  AND COLUMN_NAME = 'autopatch_robots_php'
            ) THEN
                ALTER TABLE sites_managed
                    ADD COLUMN autopatch_robots_php TINYINT(1) NOT NULL DEFAULT 1
                        COMMENT 'v18.1.2: автоматически перезаписывать robots.php если в файле нет sameHost-проверки (default=1, включено для всех; выключай вручную для сайтов с кастомным robots.php)';
            END IF;
         END",
        "CALL _refresh_panel_add_col_014()",
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_014",
    ],
];
