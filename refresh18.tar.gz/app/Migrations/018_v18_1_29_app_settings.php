<?php

/**
 * Миграция 018 (v18.1.29):
 *   Создаёт универсальную таблицу app_settings (key-value) для настроек
 *   которые оператор должен менять через UI, а не через config/app.php.
 *
 * Зачем не отдельная колонка где-то?
 *   - Гибкость: новые настройки добавляются без миграций (просто INSERT)
 *   - UI единый: всё в /settings
 *   - Версионирование: можно отслеживать когда что менялось (created_at, updated_at)
 *
 * Первая настройка которая туда едет: cron.max_jobs_per_tick (раньше была в
 * config/app.php → теперь в БД, оператор меняет через UI).
 *
 * AppSettings::get('key', $default) — типизированный helper.
 */

return [
    'name' => '018_v18_1_29_app_settings',

    'up' => [
        "CREATE TABLE IF NOT EXISTS app_settings (
            setting_key VARCHAR(64) NOT NULL PRIMARY KEY
                COMMENT 'cron.max_jobs_per_tick, cron.aggressive_mode, etc',
            setting_value TEXT NULL
                COMMENT 'значение в текстовом виде (для int/float/bool — string repr)',
            value_type ENUM('int','float','bool','string','json') NOT NULL DEFAULT 'string'
                COMMENT 'для UI и AppSettings::get<T> typed accessor',
            description VARCHAR(255) NULL
                COMMENT 'короткое описание для UI tooltip',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        COMMENT='Универсальные настройки приложения (key-value). v18.1.29'",

        // Заранее регистрируем настройки v18.1.29.
        // INSERT IGNORE — если уже есть (повторный запуск), не перезаписываем
        // (оператор мог изменить значение).
        "INSERT IGNORE INTO app_settings (setting_key, setting_value, value_type, description) VALUES
            ('cron.max_jobs_per_tick', '5', 'int',
                'Сколько джоб обрабатывать за один cron-tick. 1-50.')",
    ],
];
