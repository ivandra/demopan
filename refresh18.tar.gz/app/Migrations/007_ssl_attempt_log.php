<?php

/**
 * v15: журнал попыток создания LE-сертификатов.
 *
 * Используется в SslIssuerService::canAutoRestartGuarded для защиты от
 * Let's Encrypt rate-limits:
 *   - tooManyFailedAuthorizations (5/час) — guard 3 за час
 *   - exact set of identifiers (5/168ч)   — guard 4 за неделю
 *
 * event_type:
 *   'create_requested'  — мы вызвали createLetsEncryptCertificate
 *   'create_accepted'   — FP вернул нам cert_id
 *   'auto_restart'      — мы решили пересоздать застрявший cert
 *   'rate_limited'      — LE/FP вернул rate-limit
 *   'issued'            — cert успешно выпущен
 *   'manual_recreate'   — пользователь нажал "Принудительно создать заново"
 *   'awaiting_user'     — pipeline остановлен, ждём решения
 */
return [
    'name' => '007_ssl_attempt_log',

    'up' => [
        "CREATE TABLE IF NOT EXISTS ssl_attempt_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            job_id INT NOT NULL,
            site_id INT NOT NULL,
            domain VARCHAR(255) NOT NULL,
            cert_id INT DEFAULT NULL,
            event_type VARCHAR(32) NOT NULL,
            message TEXT DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_job (job_id),
            KEY idx_site_event (site_id, event_type, created_at),
            KEY idx_domain_event (domain, event_type, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
          COMMENT='v15: журнал попыток выпуска LE для guard rate-limit'",
    ],
];
