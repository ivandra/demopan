<?php

/**
 * Миграция 016 (v18.1.28):
 *   Добавляет колонку balance_endpoint в xmlstock_settings.
 *
 * Контекст: точный URL XMLStock balance API скрыт за авторизацией в их
 * личном кабинете. BalanceCheckService автоматически перебирает несколько
 * кандидатов; рабочий URL кешируется в эту колонку. Оператор также может
 * задать URL вручную через UI настроек (для случая когда автоподбор не
 * угадал нужный endpoint).
 */

/**
 * Helper: добавляет колонку только если её нет (idempotent на любой версии MySQL/MariaDB).
 */
$addColumnIfMissing = function ($pdo, string $table, string $column, string $columnDef): void {
    $st = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $st->execute([$table, $column]);
    if ((int)$st->fetchColumn() > 0) return;
    $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$columnDef}");
};

return [
    'name' => '016_v18_1_28_xmlstock_balance_endpoint',

    'up' => [
        function ($pdo) use ($addColumnIfMissing) {
            $addColumnIfMissing($pdo, 'xmlstock_settings', 'balance_endpoint',
                "VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'URL balance API XMLStock (auto-detected или задан вручную, v18.1.28)'");
        },
    ],
];
