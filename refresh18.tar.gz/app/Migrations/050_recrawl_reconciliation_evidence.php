<?php

/**
 * PATCH 048 (Gate W W6): evidence reconciliation переобхода + allowlist собственных редиректоров.
 *
 * Идемпотентно и fail-closed:
 *  - добавляет nullable-колонки в refresh_job_recrawl_urls (acceptance_source, yandex_task_state,
 *    yandex_added_time, reconciled_at, reconciliation_http_code) — только если их ещё нет;
 *  - добавляет app_settings 'wm.own_redirect_domains' (value_type=json) ТОЛЬКО при отсутствии ключа
 *    (существующее операторское значение не перезаписывается);
 *  - при отсутствии обязательной таблицы/колонки бросает исключение → установка останавливается,
 *    миграция НЕ регистрируется успешной. Пустые catch и молчаливый return запрещены.
 *
 * Без хардкода конкретного домена/job/site/account/IP/task-id (кроме дефолтного списка собственных
 * редиректоров — это конфигурация allowlist, а не привязка к конкретной джобе).
 */
return [
    'name' => '050_recrawl_reconciliation_evidence',

    'up' => [
        function (PDO $pdo): void {
            // --- fail-closed schema preflight ---
            $mustHave = [
                'refresh_job_recrawl_urls' => ['id', 'job_id', 'url', 'status', 'task_id',
                    'api_accepted', 'accepted_at', 'last_api_http_code'],
                'app_settings' => ['setting_key', 'setting_value', 'value_type', 'description'],
            ];
            foreach ($mustHave as $table => $cols) {
                $tb = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
                if (!$tb || !$tb->fetch()) {
                    throw new \RuntimeException("Migration 050 schema mismatch: missing table {$table}");
                }
                foreach ($cols as $col) {
                    $st = $pdo->query("SHOW COLUMNS FROM {$table} LIKE " . $pdo->quote($col));
                    if (!$st || !$st->fetch()) {
                        throw new \RuntimeException("Migration 050 schema mismatch: missing column {$table}.{$col}");
                    }
                }
            }

            // --- evidence columns (nullable, add-if-absent) ---
            $addCols = [
                'acceptance_source'        => "ADD COLUMN acceptance_source VARCHAR(24) DEFAULT NULL COMMENT 'post_202|post_409|queue_reconciled'",
                'yandex_task_state'        => "ADD COLUMN yandex_task_state VARCHAR(24) DEFAULT NULL",
                'yandex_added_time'        => "ADD COLUMN yandex_added_time VARCHAR(40) DEFAULT NULL",
                'reconciled_at'            => "ADD COLUMN reconciled_at DATETIME DEFAULT NULL",
                'reconciliation_http_code' => "ADD COLUMN reconciliation_http_code INT DEFAULT NULL COMMENT 'GET queue/task код, отдельно от POST'",
                // Блокер 1 (REV2): структурный тип ошибки для выбора stale-строк в reconciliation.
                // Не зависит от текста локализованного last_error.
                'error_kind'               => "ADD COLUMN error_kind VARCHAR(32) DEFAULT NULL COMMENT 'wrong_final_host|host_not_verified|redirect_blocked|... — структурный тип ошибки'",
            ];
            foreach ($addCols as $name => $ddl) {
                $chk = $pdo->query("SHOW COLUMNS FROM refresh_job_recrawl_urls LIKE " . $pdo->quote($name));
                if ($chk && $chk->fetch()) {
                    continue; // уже есть — идемпотентно пропускаем
                }
                $pdo->exec("ALTER TABLE refresh_job_recrawl_urls {$ddl}");
            }

            // --- Блокер 1/5 (REV2): детерминированный backfill error_kind для LEGACY-строк ---
            // Реальные упавшие строки (напр. #232) содержат ЛОКАЛИЗОВАННЫЙ текст без машинного маркера
            // и last_api_error_code=NULL. Нормализуем существующие сообщения в структурный error_kind,
            // чтобы новый reconciliation их видел. Идемпотентно (только где error_kind ещё NULL).
            $pdo->exec(
                "UPDATE refresh_job_recrawl_urls
                    SET error_kind = 'wrong_final_host'
                  WHERE error_kind IS NULL
                    AND ( last_api_error_code = 'WRONG_HOST'
                       OR last_error LIKE '%wrong_final_host%'
                       OR last_error LIKE '%WRONG_HOST%'
                       OR last_error LIKE '%редиректит на чужой host%'
                       OR last_error LIKE '%на чужой host%' )"
            );
            $pdo->exec(
                "UPDATE refresh_job_recrawl_urls
                    SET error_kind = 'host_not_verified'
                  WHERE error_kind IS NULL
                    AND ( last_api_error_code = 'HOST_NOT_VERIFIED'
                       OR last_error LIKE '%HOST_NOT_VERIFIED%'
                       OR last_error LIKE '%host не подтверждён%'
                       OR last_error LIKE '%не подтверждён в Webmaster%' )"
            );

            // --- allowlist собственных редиректоров: insert-if-absent (не перезаписывать оператора) ---
            $sel = $pdo->prepare("SELECT COUNT(*) FROM app_settings WHERE setting_key = 'wm.own_redirect_domains'");
            $sel->execute();
            if ((int)$sel->fetchColumn() === 0) {
                $default = json_encode(
                    ['dealredirectfast.com', 'flowtargetredirect.com', 'partners7k-promo.com'],
                    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
                );
                $pdo->prepare(
                    "INSERT INTO app_settings (setting_key, setting_value, value_type, description)
                     VALUES ('wm.own_redirect_domains', ?, 'json', 'Собственные редиректоры (allowlist для CloakedRedirectPolicy)')"
                )->execute([$default]);
            }

            // --- Блокер 1 (REV2) defense-in-depth: язык/кодировко-НЕЗАВИСИМЫЙ backfill ---
            // Кириллический LIKE выше хрупок при неверной кодировке соединения. Дополнительно:
            // failed-строка, чей last_error содержит ЛЮБОЙ домен из allowlist собственных редиректоров
            // (ASCII, не зависит от charset), — это отклонение wrong_final_host. Домены берём ИЗ КОНФИГА
            // (не хардкод): актуальный wm.own_redirect_domains.
            $alRow = $pdo->query("SELECT setting_value FROM app_settings WHERE setting_key='wm.own_redirect_domains'");
            $alJson = $alRow ? (string)$alRow->fetchColumn() : '';
            $ownDomains = json_decode($alJson, true);
            if (is_array($ownDomains)) {
                $upd = $pdo->prepare(
                    "UPDATE refresh_job_recrawl_urls
                        SET error_kind='wrong_final_host'
                      WHERE error_kind IS NULL AND status='failed'
                        AND last_error LIKE ?"
                );
                foreach ($ownDomains as $d) {
                    $d = trim((string)$d);
                    if ($d === '') continue;
                    $upd->execute(['%' . $d . '%']);
                }
            }
        },
    ],

    // down: убрать только добавленные evidence-колонки; настройку allowlist НЕ трогаем
    // (могла быть отредактирована оператором). Колонки удаляем idempotent-но.
    'down' => [
        function (PDO $pdo): void {
            foreach (['acceptance_source', 'yandex_task_state', 'yandex_added_time',
                      'reconciled_at', 'reconciliation_http_code', 'error_kind'] as $name) {
                $chk = $pdo->query("SHOW COLUMNS FROM refresh_job_recrawl_urls LIKE " . $pdo->quote($name));
                if ($chk && $chk->fetch()) {
                    $pdo->exec("ALTER TABLE refresh_job_recrawl_urls DROP COLUMN {$name}");
                }
            }
        },
    ],
];
