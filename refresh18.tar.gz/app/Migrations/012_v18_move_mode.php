<?php

/**
 * v18: режим джобы (refresh / move_indexed / move_simple).
 *
 * Добавляет одно поле refresh_jobs.mode со значением по умолчанию 'refresh',
 * чтобы все существующие джобы продолжили работать как раньше.
 *
 * Значения:
 *   - 'refresh'      — классическое перевыставление (как было до v18)
 *   - 'move_indexed' — переезд с индексацией нового сайта (Webmaster «Переезд сайта»)
 *   - 'move_simple'  — переезд без ожидания индексации
 *
 * Идемпотентная (через хранимую процедуру), как все миграции v17.x.
 */
return [
    'name' => '012_v18_move_mode',

    'up' => [
        // refresh_jobs.mode
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_012_a",
        "CREATE PROCEDURE _refresh_panel_add_col_012_a()
         BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'refresh_jobs'
                  AND COLUMN_NAME = 'mode'
            ) THEN
                ALTER TABLE refresh_jobs
                    ADD COLUMN mode VARCHAR(16) NOT NULL DEFAULT 'refresh'
                        COMMENT 'v18: refresh / move_indexed / move_simple';
            END IF;
         END",
        "CALL _refresh_panel_add_col_012_a()",
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_012_a",
    ],
];
