<?php

return [
    'name' => '004_sandbox_mode',

    'up' => [
        // Глобальный флаг "режим sandbox для Namecheap покупок".
        // Хранится в telegram_settings, потому что это одна "общая" таблица настроек панели.
        // По умолчанию 1 (sandbox), чтобы случайно не потратить деньги.
        "ALTER TABLE telegram_settings
            ADD COLUMN use_sandbox TINYINT(1) NOT NULL DEFAULT 1
                COMMENT 'Если 1 — Namecheap-покупки идут в sandbox-режиме'",

        // Если запись id=1 ещё не создана — создаём
        "INSERT IGNORE INTO telegram_settings (id, use_sandbox) VALUES (1, 1)",
    ],
];
