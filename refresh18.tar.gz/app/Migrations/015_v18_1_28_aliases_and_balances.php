<?php

/**
 * Миграция 015 (v18.1.28):
 *   1) Добавляет колонку aliases_text в fp_sites_cache для поиска по алиасам сайта.
 *   2) Создаёт таблицы balance_snapshots + balance_current для балансов
 *      Namecheap и XMLStock (статус-бар + cron + TG-алерты).
 *   3) Добавляет колонку mention_usernames в telegram_settings.
 *
 * v18.1.28 fix: некоторые версии MySQL/MariaDB не поддерживают
 * "ALTER TABLE ... ADD COLUMN IF NOT EXISTS ...". Чтобы миграция работала
 * на любой версии — используем callable с проверкой INFORMATION_SCHEMA.
 * Это требует Migrator с поддержкой callable (добавлено в v18.1.28).
 */

/**
 * Helper: добавляет колонку только если её нет (idempotent на любой версии MySQL/MariaDB).
 * Принимает PDO (без typehint для упрощения тестирования с mock'ами).
 */
$addColumnIfMissing = function ($pdo, string $table, string $column, string $columnDef): void {
    $st = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $st->execute([$table, $column]);
    if ((int)$st->fetchColumn() > 0) return; // уже есть
    $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$columnDef}");
};

return [
    'name' => '015_v18_1_28_aliases_and_balances',

    'up' => [
        // 1) Алиасы для поиска в FastPanel-кеше — через INFORMATION_SCHEMA
        function ($pdo) use ($addColumnIfMissing) {
            $addColumnIfMissing($pdo, 'fp_sites_cache', 'aliases_text',
                "TEXT NULL COMMENT 'Алиасы сайта через перевод строки для LIKE-поиска (v18.1.28)'");
        },

        // 2) Снапшоты балансов сервисов: Namecheap (USD), XMLStock (RUB)
        "CREATE TABLE IF NOT EXISTS balance_snapshots (
            id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            service VARCHAR(32) NOT NULL
                COMMENT 'namecheap | xmlstock',
            account_label VARCHAR(64) NOT NULL DEFAULT 'default'
                COMMENT 'для namecheap может быть несколько аккаунтов; xmlstock - один',
            balance DECIMAL(12, 4) NOT NULL DEFAULT 0
                COMMENT 'значение в валюте сервиса',
            currency VARCHAR(8) NOT NULL DEFAULT ''
                COMMENT 'USD | RUB',
            status ENUM('ok', 'low', 'error') NOT NULL DEFAULT 'ok'
                COMMENT 'low = ниже threshold; error = не смогли получить',
            error_message VARCHAR(512) NULL,
            checked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            trigger_source VARCHAR(32) NOT NULL DEFAULT 'cron'
                COMMENT 'cron | manual | after_purchase | after_index_check',
            tg_alert_sent TINYINT(1) NOT NULL DEFAULT 0
                COMMENT 'был ли отправлен TG-алерт по этому снапшоту',
            tg_alert_sent_at DATETIME NULL,
            INDEX idx_service_time (service, checked_at),
            INDEX idx_status_time (status, checked_at),
            INDEX idx_service_label (service, account_label)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        COMMENT='Снапшоты балансов внешних сервисов. v18.1.28'",

        // 3) Текущее состояние балансов (одна актуальная запись на service+label)
        "CREATE TABLE IF NOT EXISTS balance_current (
            service VARCHAR(32) NOT NULL,
            account_label VARCHAR(64) NOT NULL DEFAULT 'default',
            balance DECIMAL(12, 4) NOT NULL DEFAULT 0,
            currency VARCHAR(8) NOT NULL DEFAULT '',
            status ENUM('ok', 'low', 'error', 'unknown') NOT NULL DEFAULT 'unknown',
            threshold DECIMAL(12, 4) NOT NULL DEFAULT 0
                COMMENT 'граница low (100 для USD/Namecheap, 100 для RUB/XMLStock)',
            error_message VARCHAR(512) NULL,
            last_checked_at DATETIME NULL,
            last_ok_at DATETIME NULL
                COMMENT 'последняя дата когда мы смогли получить значение',
            last_low_alert_at DATETIME NULL
                COMMENT 'последняя отправка TG-алерта о низком балансе (anti-spam)',
            PRIMARY KEY (service, account_label)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        COMMENT='Текущее состояние балансов для UI status-bar. v18.1.28'",

        // 4) Заранее регистрируем threshold'ы (можно править в Settings UI)
        "INSERT IGNORE INTO balance_current (service, account_label, balance, currency, status, threshold, last_checked_at)
            VALUES
                ('namecheap', 'default', 0, 'USD', 'unknown', 100, NULL),
                ('xmlstock',  'default', 0, 'RUB', 'unknown', 100, NULL)",

        // 5) Telegram-упоминания участников для алертов о низком балансе
        function ($pdo) use ($addColumnIfMissing) {
            $addColumnIfMissing($pdo, 'telegram_settings', 'mention_usernames',
                "VARCHAR(512) NOT NULL DEFAULT '' COMMENT 'TG usernames для упоминания в balance-low алертах (v18.1.28)'");
        },
    ],
];
