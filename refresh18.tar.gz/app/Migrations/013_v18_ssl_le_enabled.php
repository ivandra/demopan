<?php

/**
 * v18.1: добавляет колонку ssl_le_enabled в sites_managed.
 *
 * До v18.1 стадия ssl_le_polling выполнялась всегда после verify_replacement —
 * выпуск Let's Encrypt сертификата через FastPanel API занимает ~1-3 мин и
 * не всегда нужен (для DDoS-Guard origin self-signed достаточно).
 *
 * После v18.1: галка в карточке сайта. Если выключена (default) — pipeline
 * пропускает ssl_le_polling. Если включена — выполняется как раньше.
 *
 * Default = 0 (выключено) — безопасный default, чтобы старые сайты с
 * самоподписанным SSL не получили внезапно LE-выпуск который может не сработать.
 *
 * Идемпотентная — через хранимую процедуру с INFORMATION_SCHEMA проверкой.
 */
return [
    'name' => '013_v18_ssl_le_enabled',

    'up' => [
        // sites_managed.ssl_le_enabled
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_013",
        "CREATE PROCEDURE _refresh_panel_add_col_013()
         BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'sites_managed'
                  AND COLUMN_NAME = 'ssl_le_enabled'
            ) THEN
                ALTER TABLE sites_managed
                    ADD COLUMN ssl_le_enabled TINYINT(1) NOT NULL DEFAULT 0
                        COMMENT 'v18.1: выпускать Lets Encrypt сертификат после замены (default=0)';
            END IF;
         END",
        "CALL _refresh_panel_add_col_013()",
        "DROP PROCEDURE IF EXISTS _refresh_panel_add_col_013",
    ],
];
