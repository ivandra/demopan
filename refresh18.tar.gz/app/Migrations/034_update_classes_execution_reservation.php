<?php

/**
 * v25.2-a1.6.4.1 PATCH_2: атомарное резервирование запуска update_classes.php.
 *
 * execution_state хранился в artifacts_json (update_classes_stage.execution_state),
 * но для fail-closed атомарного резервирования нужен реальный столбец: условный
 * UPDATE ... WHERE uc_execution_state IS NULL с проверкой rowCount()===1 —
 * единственный надёжный способ гарантировать «не более одного запуска на цикл»
 * даже при гонке cron-воркеров и при сбое записи.
 *
 * Идемпотентная миграция; backfill из artifacts для in-flight джоб.
 */
return [
    'name' => '034_update_classes_execution_reservation',

    'up' => [
        function (PDO $pdo) {
            $add = function (string $col, string $ddl) use ($pdo) {
                $st = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE '" . $col . "'");
                if (!$st || !$st->fetch()) {
                    $pdo->exec("ALTER TABLE refresh_jobs " . $ddl);
                }
            };
            $add('uc_execution_state',
                "ADD COLUMN uc_execution_state VARCHAR(20) NULL COMMENT 'PATCH_2: not_started|started|ambiguous|completed|verified|operator_skipped'");
            $add('uc_execution_id',
                "ADD COLUMN uc_execution_id VARCHAR(40) NULL COMMENT 'PATCH_2: id цикла выполнения update_classes'");
            $add('uc_execution_started_at',
                "ADD COLUMN uc_execution_started_at DATETIME NULL COMMENT 'PATCH_2: момент резервирования запуска'");
            $add('uc_execution_attempts',
                "ADD COLUMN uc_execution_attempts INT NOT NULL DEFAULT 0 COMMENT 'PATCH_2: число зарезервированных запусков'");

            $idx = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'refresh_jobs'
                    AND INDEX_NAME = 'idx_uc_exec'"
            )->fetchColumn();
            if ((int)$idx === 0) {
                $pdo->exec("ALTER TABLE refresh_jobs ADD INDEX idx_uc_exec (stage, uc_execution_state)");
            }

            // Backfill из artifacts для in-flight update_classes_call джоб.
            $rows = $pdo->query(
                "SELECT id, artifacts_json, php_uniquification_verified_at
                   FROM refresh_jobs
                  WHERE stage = 'update_classes_call'
                    AND (uc_execution_state IS NULL OR uc_execution_state = '')"
            )->fetchAll(PDO::FETCH_ASSOC);
            $upd = $pdo->prepare(
                "UPDATE refresh_jobs SET uc_execution_state=?, uc_execution_id=?, uc_execution_started_at=?, uc_execution_attempts=? WHERE id=?"
            );
            foreach ($rows as $r) {
                $art = [];
                if (!empty($r['artifacts_json'])) {
                    $d = json_decode((string)$r['artifacts_json'], true);
                    if (is_array($d)) $art = $d;
                }
                $uc = $art['update_classes_stage'] ?? [];
                $state = (string)($uc['execution_state'] ?? '');
                if ($state === '' && !empty($r['php_uniquification_verified_at'])) $state = 'verified';
                if ($state === '') continue; // не запускался — оставляем NULL (можно резервировать)

                // §16: неизвестное legacy execution_state НЕ должно случайно
                // разрешить новый HTTP-вызов и не должно ломать анти-повтор.
                // Любое незнакомое значение маппим в безопасное 'ambiguous'
                // (анти-повтор сработает, авто-HTTP заблокирован).
                $known = ['not_started','started','ambiguous','completed','verified','operator_skipped'];
                if (!in_array($state, $known, true)) $state = 'ambiguous';

                // §16: malformed / не-MySQL DATETIME в artifacts не должен падать в колонку.
                $startedRaw = (string)($uc['execution_started_at'] ?? '');
                $startedAt = null;
                if ($startedRaw !== '') {
                    $ts = strtotime($startedRaw);
                    if ($ts !== false) $startedAt = date('Y-m-d H:i:s', $ts);
                }
                $upd->execute([
                    $state,
                    (string)($uc['execution_id'] ?? '') ?: null,
                    $startedAt,
                    (int)($uc['execution_attempts'] ?? 0),
                    (int)$r['id'],
                ]);
            }
        },
    ],
    // PATCH_5 (P1.7): реальный идемпотентный rollback — удаляет добавленные колонки/индекс.
    'down' => [
        function (PDO $pdo) {
            // индекс
            try {
                $has = $pdo->query("SHOW INDEX FROM refresh_jobs WHERE Key_name='idx_uc_exec'")->fetch();
                if ($has) $pdo->exec("ALTER TABLE refresh_jobs DROP INDEX idx_uc_exec");
            } catch (\Throwable $e) {}
            foreach (['uc_execution_state','uc_execution_id','uc_execution_started_at','uc_execution_attempts'] as $col) {
                try {
                    $ex = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE " . $pdo->quote($col))->fetch();
                    if ($ex) $pdo->exec("ALTER TABLE refresh_jobs DROP COLUMN `$col`");
                } catch (\Throwable $e) {}
            }
        },
    ],
];
