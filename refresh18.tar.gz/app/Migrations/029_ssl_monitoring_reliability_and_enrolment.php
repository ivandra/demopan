<?php

/**
 * v25.1-b1.1: расширения SSL-мониторинга — enrolment, архив, надёжность batch,
 * anti-spam Telegram-алертов. Отдельная миграция (НЕ правка уже выпущенной 028),
 * потому что Migrator пропускает миграцию по имени: если 028 уже применялась,
 * добавленные в неё колонки не появятся. Поэтому все b1/b1.1-поля здесь.
 *
 * Идемпотентно (SHOW COLUMNS / information_schema гарды). На чистой базе:
 *   028 создаёт базовые SSL-таблицы → 029 добавляет расширения.
 * Поверх уже применённой 028 — 029 просто добавит недостающее.
 */
return [
    'name' => '029_ssl_monitoring_reliability_and_enrolment',

    'up' => [
        // 1) Колонки enrolment/архива (b1) + надёжности batch и алертов (b1.1).
        function (PDO $pdo) {
            $cols = [
                // enrolment / архив (b1)
                'monitoring_enabled' => "ADD COLUMN monitoring_enabled TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'b1: участвует в cron/списке'",
                'archived_at'        => "ADD COLUMN archived_at DATETIME NULL COMMENT 'b1: когда отправлен в архив'",
                'enrolled_source'    => "ADD COLUMN enrolled_source VARCHAR(24) NULL COMMENT 'b1: job|purchase|alias|readiness|manual'",
                'enrolled_at'        => "ADD COLUMN enrolled_at DATETIME NULL COMMENT 'b1: когда добавлен в мониторинг'",
                'manual_added'       => "ADD COLUMN manual_added TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'b1: добавлен вручную'",
                // надёжность batch (b1.1)
                'batch_claimed_at'   => "ADD COLUMN batch_claimed_at DATETIME NULL COMMENT 'b1.1: когда домен взят в проверку (для stale recovery)'",
                'batch_last_error'   => "ADD COLUMN batch_last_error VARCHAR(1024) NULL COMMENT 'b1.1: последняя ошибка проверки в batch'",
                // anti-spam Telegram (b1.1)
                'last_alert_key'     => "ADD COLUMN last_alert_key VARCHAR(32) NULL COMMENT 'b1.1: ключ последнего критического алерта'",
                'last_alert_sent_at' => "ADD COLUMN last_alert_sent_at DATETIME NULL COMMENT 'b1.1: когда отправлен последний алерт'",
            ];
            foreach ($cols as $name => $ddl) {
                $st = $pdo->query("SHOW COLUMNS FROM domain_ssl_statuses LIKE " . $pdo->quote($name));
                if ($st && $st->fetch()) continue;
                $pdo->exec("ALTER TABLE domain_ssl_statuses " . $ddl);
            }

            // Индексы.
            $idx = [
                'idx_monitoring'   => "ADD KEY idx_monitoring (monitoring_enabled, next_check_at)",
                'idx_batch_claimed'=> "ADD KEY idx_batch_claimed (batch_state, batch_claimed_at)",
            ];
            foreach ($idx as $name => $ddl) {
                $chk = $pdo->query(
                    "SELECT COUNT(*) FROM information_schema.STATISTICS
                      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'domain_ssl_statuses'
                        AND INDEX_NAME = " . $pdo->quote($name)
                )->fetchColumn();
                if ((int)$chk === 0) $pdo->exec("ALTER TABLE domain_ssl_statuses " . $ddl);
            }
        },

        // 2) Бэкофилл enrolled_at/source для строк, появившихся до b1 (если есть).
        function (PDO $pdo) {
            $pdo->exec(
                "UPDATE domain_ssl_statuses
                    SET enrolled_at = COALESCE(enrolled_at, created_at),
                        enrolled_source = COALESCE(enrolled_source, 'legacy')
                  WHERE enrolled_at IS NULL OR enrolled_source IS NULL"
            );
        },
    ],
];
