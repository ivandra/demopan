<?php

/**
 * v25.0-a: readiness-gate готовности нового домена.
 *
 * Причина: pipeline считал этап выполненным по факту ОТПРАВКИ команды
 * (Namecheap setHosts «прописал и ладно», FastPanel «принял SSL»), а не по
 * фактическому публичному результату. В итоге смена классов (PHP-уникализация)
 * и Вебмастер стартовали, когда домен ещё не отвечал публично: DNS не
 * пропагирован, SSL self-signed, HTTPS не 200. Это давало ложные PHP-ошибки и
 * заявки в Вебмастер, которые Яндекс отклонял.
 *
 * Идея (по приоритету заказчика): отслеживать код ответа домена. 301/302 —
 * «скоро будет 200», но идти дальше нельзя. Стабильный публичный HTTPS 200
 * (+ валидный SSL + probe-файл) — единственный gate к следующему этапу.
 *
 * Значения кладём НОВЫМИ колонками refresh_jobs (существующих эквивалентов
 * нет — проверено по дампу). Детальное состояние проверок (streak, коды,
 * сертификат, probe-token) живёт в artifacts_json.domain_readiness_stage —
 * STAGES_ORDER и бизнес-порядок не меняются.
 *
 * Миграции 023 и 024 НЕ изменяются — они уже применены на рабочей панели.
 * Шаги идемпотентны: повторный запуск ничего не ломает.
 */
return [
    'name' => '025_domain_readiness_webmaster_pipeline',

    'up' => [
        function (PDO $pdo) {
            // Колонки refresh_jobs. Проверяем каждую отдельно — повторный
            // запуск безопасен, частично применённая миграция дозаполнится.
            $cols = [
                'domain_http_initial_code' => "ADD COLUMN domain_http_initial_code INT DEFAULT NULL
                    COMMENT 'v25: исходный HTTP-код http://new/ без follow (0=нет DNS/connect, 301/302=скоро готов)'",
                'domain_https_final_code' => "ADD COLUMN domain_https_final_code INT DEFAULT NULL
                    COMMENT 'v25: финальный HTTPS-код https://new/ после ограниченного follow'",
                'domain_https_ready_at' => "ADD COLUMN domain_https_ready_at DATETIME DEFAULT NULL
                    COMMENT 'v25: момент подтверждённой готовности (streak достиг порога). GATE к PHP-уникализации'",
                'domain_readiness_success_streak' => "ADD COLUMN domain_readiness_success_streak INT NOT NULL DEFAULT 0
                    COMMENT 'v25: подряд успешных публичных проверок HTTPS 200+SSL+probe; сбрасывается при любом сбое'",
                'domain_readiness_last_checked_at' => "ADD COLUMN domain_readiness_last_checked_at DATETIME DEFAULT NULL
                    COMMENT 'v25: время последней readiness-проверки (для интервалов cron)'",
                'php_uniquification_verified_at' => "ADD COLUMN php_uniquification_verified_at DATETIME DEFAULT NULL
                    COMMENT 'v25: PHP-уникализация применена и подтверждена (php -l + HTTPS smoke). GATE к Вебмастеру'",
            ];

            foreach ($cols as $name => $ddl) {
                $st = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE " . $pdo->quote($name));
                if ($st && $st->fetch()) {
                    continue; // колонка уже есть
                }
                $pdo->exec("ALTER TABLE refresh_jobs " . $ddl);
            }
        },
    ],
];
