<?php

/**
 * v25.2-a1.6.3: устойчивое ручное подавление мониторинга + debounce Telegram.
 *
 *  monitoring_suppressed — оператор вручную отправил домен в Архив. cron НЕ
 *      возвращает такой домен автоматически (в отличие от job_terminal-архива).
 *  archived_reason        — 'operator' | 'job_terminal' (кто/почему архивировал).
 *  alert_recovery_since   — момент начала «выздоровления» (trusted-стрик) для
 *      stable-recovery: alert-ключ сбрасывается только после устойчивого trusted.
 *
 * Отдельная идемпотентная миграция; НЕ редактирует 028–031.
 */
return [
    'name' => '032_ssl_suppression_and_alert_debounce',

    'up' => [
        function (PDO $pdo) {
            $add = function (string $col, string $ddl) use ($pdo) {
                $st = $pdo->query("SHOW COLUMNS FROM domain_ssl_statuses LIKE '" . $col . "'");
                if (!$st || !$st->fetch()) {
                    $pdo->exec("ALTER TABLE domain_ssl_statuses " . $ddl);
                }
            };
            $add('monitoring_suppressed',
                "ADD COLUMN monitoring_suppressed TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'a1.6.3: ручной архив оператором — cron не возвращает'");
            $add('archived_reason',
                "ADD COLUMN archived_reason VARCHAR(32) NULL COMMENT 'a1.6.3: operator | job_terminal'");
            $add('alert_recovery_since',
                "ADD COLUMN alert_recovery_since DATETIME NULL COMMENT 'a1.6.3: начало trusted-стрика для stable-recovery алертов'");

            $chk = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'domain_ssl_statuses'
                    AND INDEX_NAME = 'idx_ssl_suppressed'"
            )->fetchColumn();
            if ((int)$chk === 0) {
                $pdo->exec("ALTER TABLE domain_ssl_statuses ADD KEY idx_ssl_suppressed (monitoring_suppressed)");
            }
        },
    ],
];
