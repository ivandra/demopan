<?php

return [
    'name' => '005_yandex_webmaster_accounts',

    'up' => [
        // Таблица аккаунтов Yandex Webmaster.
        // Готова к использованию в v15: импорт Implicit-токенов и Code Flow.
        "CREATE TABLE IF NOT EXISTS yandex_webmaster_accounts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            label VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'Человеко-читаемое имя для UI',
            email VARCHAR(255) NOT NULL COMMENT 'Email Яндекс-аккаунта',
            yandex_user_id BIGINT DEFAULT NULL COMMENT 'user_id из API /v4/user',
            access_token_enc TEXT NOT NULL COMMENT 'Зашифрованный access_token',
            refresh_token_enc TEXT DEFAULT NULL COMMENT 'Зашифрованный refresh_token (только Code Flow)',
            token_expires_at DATETIME DEFAULT NULL COMMENT 'Когда истекает access_token',
            flow_type VARCHAR(20) NOT NULL DEFAULT 'implicit' COMMENT 'implicit или code',
            is_default TINYINT(1) DEFAULT 0 COMMENT 'Использовать по умолчанию для новых сайтов',
            last_validated_at DATETIME DEFAULT NULL COMMENT 'Когда последний раз проверяли токен',
            last_validation_ok TINYINT(1) DEFAULT 1 COMMENT 'Результат последней проверки',
            last_validation_error TEXT DEFAULT NULL COMMENT 'Текст ошибки последней проверки',
            host_count INT DEFAULT 0 COMMENT 'Сколько сайтов в этом аккаунте по последней проверке',
            note TEXT DEFAULT NULL COMMENT 'Произвольная заметка',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_email (email),
            INDEX idx_default (is_default)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='Аккаунты Яндекс Webmaster для управления сайтами через API'",

        // Таблица настроек OAuth-приложения (одна запись id=1).
        // client_id и client_secret общие для всех аккаунтов.
        "CREATE TABLE IF NOT EXISTS yandex_oauth_settings (
            id INT PRIMARY KEY DEFAULT 1,
            client_id VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'ClientID приложения oauth.yandex.ru',
            client_secret_enc TEXT DEFAULT NULL COMMENT 'Зашифрованный Client secret',
            redirect_uri_implicit VARCHAR(500) NOT NULL DEFAULT 'https://oauth.yandex.ru/verification_code',
            redirect_uri_code VARCHAR(500) DEFAULT NULL COMMENT 'URL панели для Code Flow callback (v15)',
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='Настройки OAuth-приложения Yandex для рефреш-панели'",

        // Создаём запись id=1 если её нет
        "INSERT IGNORE INTO yandex_oauth_settings (id) VALUES (1)",
    ],
];
