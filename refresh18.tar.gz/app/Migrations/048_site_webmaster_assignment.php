<?php

/**
 * PATCH 048: постоянная привязка сайта к аккаунту Yandex.Webmaster.
 *
 * Добавляет:
 *   - sites_managed.webmaster_account_id (+ idx) — постоянная привязка сайта к
 *     yandex_webmaster_accounts.id. NULL = привязки нет (режим Auto по старому домену).
 *   - site_webmaster_assignment_log — история изменений привязки (§27).
 *
 * §4: НИКАКОГО автоматического backfill. Все существующие сайты остаются NULL —
 * оператор привязывает явно (site_webmaster_links = domain-level cache/history и НЕ
 * является источником постоянной привязки).
 */
return [
    'name' => '048_site_webmaster_assignment',

    'up' => [
        // 1) sites_managed.webmaster_account_id + индекс (идемпотентно).
        function (PDO $pdo) {
            $st = $pdo->query("SHOW COLUMNS FROM sites_managed LIKE 'webmaster_account_id'");
            if (!$st || !$st->fetch()) {
                $pdo->exec(
                    "ALTER TABLE sites_managed
                        ADD COLUMN webmaster_account_id INT NULL
                        COMMENT 'PATCH048: постоянная привязка сайта к yandex_webmaster_accounts.id; NULL=Auto'"
                );
            }
            $idx = $pdo->query(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sites_managed'
                    AND INDEX_NAME = 'idx_sites_webmaster_account'"
            )->fetchColumn();
            if ((int)$idx === 0) {
                $pdo->exec("ALTER TABLE sites_managed ADD INDEX idx_sites_webmaster_account (webmaster_account_id)");
            }
        },

        // 2) История изменения привязки (§27).
        "CREATE TABLE IF NOT EXISTS site_webmaster_assignment_log (
            id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            site_id INT NOT NULL,
            old_webmaster_account_id INT NULL,
            new_webmaster_account_id INT NULL,
            source VARCHAR(32) NOT NULL DEFAULT 'site_page',
            note VARCHAR(255) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_sw_assignment_site (site_id, created_at),
            KEY idx_sw_assignment_account (new_webmaster_account_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    ],
];
