<?php

/**
 * 041_ssl_completed_old_domain_cleanup (ТЗ 041 §10)
 *
 * Одноразовая очистка уже загрязнённых данных: старые домены успешно
 * завершённых джоб, которые всё ещё активны в SSL-мониторинге, не являются
 * текущим доменом сайта, не являются new_domain активной джобы и не закреплены
 * явно оператором (manual_added=1 AND enrolled_source='manual').
 *
 * НЕ добавляет колонок. НЕ удаляет строк. Историю (domain_ssl_check_history)
 * не трогает. НЕ вызывает HTTP/Telegram/FastPanel/Namecheap/Yandex.
 *
 * Идемпотентна: архивирует только monitoring_enabled=1 — при повторном запуске
 * такие строки уже отключены, поэтому 0 изменённых строк.
 *
 * Тот же единый predicate «operationally active job», что в
 * DomainSslStatusRepository (ensureActiveJobDomains/autoArchiveStale/
 * maybeSendTransitionAlert/archiveCompletedOldDomain) — не создаём 4-е
 * определение активности.
 */

return [
    'up' => [
        function (PDO $pdo) {
            $terminal = "'done','failed','cancelled','superseded'";
            $early    = "'queued','domain_purchasing'";

            // closed_at может отсутствовать на старой базе — проверяем через info-schema.
            $hasClosed = (function () use ($pdo): bool {
                $st = $pdo->prepare(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS
                      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'refresh_jobs'
                        AND COLUMN_NAME = 'closed_at'"
                );
                $st->execute();
                return (int)$st->fetchColumn() > 0;
            })();
            $closedCond = $hasClosed ? "AND j.closed_at IS NULL" : "";

            // §10.2 критерии кандидата + §10.3 то же изменение, что
            // archiveCompletedOldDomain(), но archived_reason='job_completed_cleanup'.
            $sql =
                "UPDATE domain_ssl_statuses s
                    SET s.monitoring_enabled = 0, s.monitoring_suppressed = 0, s.manual_added = 0,
                        s.archived_at = NOW(), s.archived_reason = 'job_completed_cleanup', s.next_check_at = NULL,
                        s.batch_id = NULL, s.batch_state = NULL, s.batch_claimed_at = NULL,
                        s.last_alert_key = NULL, s.last_alert_sent_at = NULL, s.alert_recovery_since = NULL
                  WHERE s.monitoring_enabled = 1
                    AND NOT (s.manual_added = 1 AND s.enrolled_source = 'manual')
                    AND EXISTS (
                        SELECT 1 FROM refresh_jobs cj
                         WHERE cj.old_domain = s.domain COLLATE utf8mb4_unicode_ci
                           AND cj.stage = 'done' AND cj.stage_status = 'ok'
                    )
                    AND NOT EXISTS (
                        SELECT 1 FROM sites_managed sm
                         WHERE sm.current_domain = s.domain COLLATE utf8mb4_unicode_ci
                    )
                    AND NOT EXISTS (
                        SELECT 1 FROM refresh_jobs j
                         WHERE j.new_domain = s.domain COLLATE utf8mb4_unicode_ci
                           AND j.stage NOT IN ($terminal)
                           $closedCond
                           AND j.stage NOT IN ($early)
                           AND NOT EXISTS (
                               SELECT 1 FROM refresh_jobs newer
                                WHERE newer.site_id = j.site_id AND newer.id > j.id
                           )
                    )";
            $pdo->exec($sql);
        },
    ],
    'down' => [
        // Очистка данных необратима автоматически: повторное включение
        // архивных доменов вслепую вернуло бы ту же ложную аварию. Откат не
        // требуется — строки и история сохранены, при необходимости оператор
        // возвращает конкретный домен через «Вернуть из архива».
        function (PDO $pdo) { /* no-op */ },
    ],
];
