<?php

/**
 * v19: API-ключи для внешних потребителей (Casino Panel, и т.п.).
 *
 * Хранение: secret в открытом виде НИКОГДА не сохраняется. Только sha256-хеш.
 * При создании ключа secret показывается ОДИН раз в UI и пользователь его копирует.
 *
 * scopes — массив строк через запятую. Сейчас определены:
 *   webmaster.read       — список аккаунтов (без токенов)
 *   webmaster.credentials — выдача access_token конкретного аккаунта
 *   registrar.read       — список Namecheap-аккаунтов и контактов
 *   registrar.credentials — выдача api_key + client_ip
 *   fastpanel.read       — список FastPanel-серверов
 *   fastpanel.jwt        — логин на FP и выдача JWT
 *   server.resolve       — резолв IP сайта по fp_server/fp_site
 *   appsettings.read     — публичные настройки (max_price для покупки и т.п.)
 *
 * Спец-значение "*" даёт доступ ко всем scopes.
 */
return [
    'name' => '020_v19_api_clients',

    'up' => [
        "CREATE TABLE IF NOT EXISTS api_clients (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            label VARCHAR(128) NOT NULL COMMENT 'Человеко-читаемое имя клиента',
            key_prefix VARCHAR(16) NOT NULL COMMENT 'Первые 8 символов ключа (для отображения)',
            key_hash CHAR(64) NOT NULL COMMENT 'sha256 от полного ключа',
            scopes TEXT NOT NULL DEFAULT '' COMMENT 'Список scope''ов через запятую, либо *',
            note TEXT DEFAULT NULL,
            last_used_at DATETIME DEFAULT NULL,
            last_used_ip VARCHAR(64) DEFAULT NULL,
            revoked_at DATETIME DEFAULT NULL COMMENT 'Если NOT NULL — ключ заблокирован',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_key_hash (key_hash),
            KEY idx_prefix (key_prefix),
            KEY idx_revoked (revoked_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
          COMMENT='v19: API-ключи для внешних потребителей refresh-panel'",
    ],
];
