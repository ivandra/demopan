<?php
/**
 * PATCH_5 (P0.7): штатная настройка multisite — subsite (site_subroot) на сайт.
 * Плюс таблица подтверждённых alias-доменов (P0.8).
 */
return [
    'up' => [
        function (PDO $pdo) {
            $ex = $pdo->query("SHOW COLUMNS FROM sites_managed LIKE 'uc_site_subroot'")->fetch();
            if (!$ex) $pdo->exec("ALTER TABLE sites_managed ADD COLUMN uc_site_subroot VARCHAR(255) NULL");
            $ex = $pdo->query("SHOW COLUMNS FROM sites_managed LIKE 'aliases_json'")->fetch();
            if (!$ex) $pdo->exec("ALTER TABLE sites_managed ADD COLUMN aliases_json TEXT NULL");
        },
        function (PDO $pdo) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS site_domain_aliases (
                id INT AUTO_INCREMENT PRIMARY KEY,
                site_id INT NOT NULL,
                alias_domain VARCHAR(255) NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_site_alias (site_id, alias_domain)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        },
    ],
    'down' => [
        function (PDO $pdo) {
            foreach (['uc_site_subroot','aliases_json'] as $col) {
                try { $ex = $pdo->query("SHOW COLUMNS FROM sites_managed LIKE " . $pdo->quote($col))->fetch();
                    if ($ex) $pdo->exec("ALTER TABLE sites_managed DROP COLUMN `$col`"); } catch (\Throwable $e) {}
            }
            try { $pdo->exec("DROP TABLE IF EXISTS site_domain_aliases"); } catch (\Throwable $e) {}
        },
    ],
];
