<?php

/**
 * v22: раздел «Переезды» — учёт переездов move_indexed / move_simple.
 *
 * site_relocations — тонкая таблица-компаньон к refresh_jobs. Сайт, режим,
 * старый и новый домены, дата старта НЕ дублируются — берутся JOIN'ом по job_id.
 * Хранится только то, чего в refresh_jobs нет: плановый срок, две write-once
 * даты (первое появление в индексе и подтверждение смены главного зеркала),
 * состояние проверки индекса, отмена и snapshot на случай удаления джобы.
 *
 * site_relocation_index_checks — структурированная история XMLStock-проверок.
 * Нужна, чтобы доказуемо определять источник результата: индексация
 * засчитывается ТОЛЬКО когда primary_method = 'xmlstock'; fallback Яндекс
 * Вебмастера внутри пайплайна на раздел не влияет.
 *
 * Поле называется trigger_type, а не trigger: TRIGGER — зарезервированное
 * слово MySQL, иначе потребовались бы обратные кавычки во всех запросах.
 *
 * Шаги сделаны callable: 'CREATE TABLE IF NOT EXISTS' поддерживается, но
 * проверка через SHOW TABLES даёт понятный лог и единообразие с миграцией 022.
 */
return [
    'name' => '023_v22_site_relocations',

    'up' => [
        function (PDO $pdo) {
            $st = $pdo->query("SHOW TABLES LIKE 'site_relocations'");
            if ($st && $st->fetch()) {
                return; // уже создана — миграция идемпотентна
            }
            $pdo->exec("
                CREATE TABLE site_relocations (
                    id                  INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    job_id              INT NOT NULL
                        COMMENT 'refresh_jobs.id; сайт, режим, домены, дата старта — JOIN по нему',

                    planned_at          DATETIME NOT NULL
                        COMMENT 'по умолчанию refresh_jobs.created_at + 14 суток; правится вручную',

                    first_indexed_at    DATETIME DEFAULT NULL
                        COMMENT 'write-once: первое подтверждение ИМЕННО XMLStock (primary_method=xmlstock)',
                    move_completed_at   DATETIME DEFAULT NULL
                        COMMENT 'write-once: подтверждение main_mirror(старый)=новый через MoveStatusChecker',

                    index_status        VARCHAR(16) NOT NULL DEFAULT 'unchecked'
                        COMMENT 'unchecked|not_indexed|indexed|check_error',
                    index_checked_at    DATETIME DEFAULT NULL
                        COMMENT 'обновляется ТОЛЬКО после фактически отправленного запроса к XMLStock',
                    index_error         VARCHAR(255) DEFAULT NULL,

                    cancelled_at        DATETIME DEFAULT NULL,
                    cancelled_by        VARCHAR(64) DEFAULT NULL
                        COMMENT 'логин оператора; в панели нет таблицы users, ID не существует',
                    comment             TEXT DEFAULT NULL
                        COMMENT 'обязателен при отмене — проверяется в сервисе и контроллере',

                    snapshot_json       TEXT DEFAULT NULL
                        COMMENT 'site_id, mode, old_domain, new_domain, job_created_at — чтобы пережить удаление джобы',

                    is_backfilled       TINYINT(1) NOT NULL DEFAULT 0,
                    backfill_notes      VARCHAR(255) DEFAULT NULL,

                    created_by          VARCHAR(64) DEFAULT NULL,
                    updated_by          VARCHAR(64) DEFAULT NULL,
                    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                    UNIQUE KEY uq_job (job_id),
                    KEY idx_planned (planned_at),
                    KEY idx_first_indexed (first_indexed_at),
                    KEY idx_move_completed (move_completed_at),
                    KEY idx_index_status (index_status),
                    KEY idx_cancelled (cancelled_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                  COMMENT='v22: учёт переездов move_indexed/move_simple'
            ");
        },

        function (PDO $pdo) {
            $st = $pdo->query("SHOW TABLES LIKE 'site_relocation_index_checks'");
            if ($st && $st->fetch()) {
                return;
            }
            $pdo->exec("
                CREATE TABLE site_relocation_index_checks (
                    id              INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    relocation_id   INT NOT NULL,
                    checked_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                    trigger_type    VARCHAR(16) NOT NULL
                        COMMENT 'pipeline|manual|cron (trigger — зарезервированное слово MySQL)',
                    source          VARCHAR(16) NOT NULL DEFAULT 'xmlstock',

                    ok              TINYINT(1) NOT NULL DEFAULT 0
                        COMMENT 'запрос выполнен корректно (не путать с indexed)',
                    indexed         TINYINT(1) NOT NULL DEFAULT 0,
                    pages_indexed   INT NOT NULL DEFAULT 0,

                    error_code      VARCHAR(64)  DEFAULT NULL
                        COMMENT 'curl_error|http_502|xmlstock_error_15|lock_busy|not_available|...',
                    error_message   VARCHAR(255) DEFAULT NULL,

                    created_by      VARCHAR(64) DEFAULT NULL COMMENT 'логин оператора при trigger_type=manual',
                    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                    KEY idx_relocation (relocation_id, checked_at),
                    KEY idx_checked_at (checked_at),
                    KEY idx_trigger (trigger_type)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                  COMMENT='v22: структурированная история XMLStock-проверок по переездам'
            ");
        },

        function (PDO $pdo) {
            $st = $pdo->query("SHOW TABLES LIKE 'site_relocation_history'");
            if ($st && $st->fetch()) {
                return;
            }
            // H5: журнал действий оператора. Дублирует записи из refresh_job_events,
            // потому что те физически удаляются вместе с джобой
            // (RefreshJobController::delete), а история переезда должна сохраняться.
            $pdo->exec("
                CREATE TABLE site_relocation_history (
                    id              INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    relocation_id   INT NOT NULL,
                    action          VARCHAR(48) NOT NULL
                        COMMENT 'planned_at_changed|relocation_cancelled|manual_check_requested|...',
                    actor           VARCHAR(64) DEFAULT NULL COMMENT 'логин оператора',
                    old_value       VARCHAR(255) DEFAULT NULL,
                    new_value       VARCHAR(255) DEFAULT NULL,
                    comment         VARCHAR(255) DEFAULT NULL,
                    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    KEY idx_relocation (relocation_id, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                  COMMENT='v22: история действий оператора по переездам'
            ");
        },
    ],
];
