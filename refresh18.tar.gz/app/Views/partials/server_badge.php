<?php
/**
 * ТЗ 040 §8.1: единый партиал бейджа сервера.
 *
 * Ожидает в области видимости ОДНО из:
 *   $badge    — уже посчитанный ServerBadgePresenter::present() (array|null)
 *   $badgeRow — сырая строка с полями ui_badge_code/label/color(+server_title/title)
 * Опционально:
 *   $badgeMode — 'compact' (по умолчанию, только код) | 'full' (код · подпись · сервер)
 *
 * Если бейджа нет (код пуст) — не выводит ничего (UI-09).
 * Цвет и цвет текста берутся ТОЛЬКО из presenter (строгая HEX-валидация),
 * произвольный CSS невозможен.
 */
if (!isset($badge)) {
    $badge = isset($badgeRow) && is_array($badgeRow)
        ? (new ServerBadgePresenter())->fromRow($badgeRow)
        : null;
}
$badgeMode = isset($badgeMode) && $badgeMode === 'full' ? 'full' : 'compact';

if ($badge):
    $text = $badgeMode === 'full' ? $badge['full'] : $badge['compact'];
    $style = 'background:' . $badge['color'] . ';color:' . $badge['text_color'];
?><span class="server-badge server-badge--<?= $badgeMode ?>" style="<?= htmlspecialchars($style, ENT_QUOTES, 'UTF-8') ?>" title="<?= htmlspecialchars($badge['title'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($text, ENT_QUOTES, 'UTF-8') ?></span><?php
endif;
// не оставляем висящих переменных для следующих include
unset($badge, $badgeMode);
if (isset($badgeRow)) unset($badgeRow);
