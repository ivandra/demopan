<?php
/**
 * ТЗ 040 §8.4: фильтр списков по серверу. Передаёт server_id (не текст «F»).
 *
 * Ожидает в области видимости:
 *   $servers       — ServerBadgePresenter::serversForFilter() (array)
 *   $serverFilter  — текущий выбранный id (int, 0 = все)
 * Сохраняет прочие GET-параметры (поиск/вкладки) скрытыми полями, кроме
 * server_id и page (страница сбрасывается при смене фильтра).
 */
$servers = $servers ?? [];
$serverFilter = (int)($serverFilter ?? 0);
if (!empty($servers)):
    $curPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
?>
<form method="get" action="<?= htmlspecialchars($curPath, ENT_QUOTES, 'UTF-8') ?>" class="server-filter">
    <?php foreach (($_GET ?? []) as $k => $v):
        if (in_array($k, ['server_id', 'page'], true)) continue;
        if (is_array($v)) continue; ?>
        <input type="hidden" name="<?= htmlspecialchars((string)$k, ENT_QUOTES, 'UTF-8') ?>" value="<?= htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8') ?>">
    <?php endforeach; ?>
    <label class="server-filter-label">Сервер:
        <select name="server_id" onchange="this.form.submit()">
            <option value="0">Все серверы</option>
            <?php foreach ($servers as $srv):
                $lbl = trim((string)($srv['title'] ?? ('#' . $srv['id'])));
                $code = trim((string)($srv['ui_badge_code'] ?? ''));
                if ($code !== '') $lbl = $code . ' · ' . $lbl;
            ?>
                <option value="<?= (int)$srv['id'] ?>" <?= $serverFilter === (int)$srv['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($lbl) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </label>
</form>
<?php endif; ?>
