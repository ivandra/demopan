<?php
/** @var string $__view */
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
$flash = $_SESSION['flash'] ?? [];
unset($_SESSION['flash']);

$nav = [
    '/'                        => 'Сайты',
    '/sites/import'            => 'Импорт',
    '/jobs'                    => 'Джобы',
    '/ssl'                     => 'SSL',
    '/relocations'             => 'Переезды',
    '/servers'                 => 'Серверы FP',
    '/registrar/accounts'      => 'Namecheap',
    '/registrar/contacts'      => 'Контакты',
    '/system/webmaster-tokens' => 'Webmaster',
    '/system/diagnose'         => 'Диагностика',
    '/xmlstock'                => 'XMLStock',
    '/settings'                => 'Настройки',
	 '/casino'                  => '🎰 Casino',
	'/api-clients'             => 'API-ключи',
];
$current = $_SERVER['REQUEST_URI'] ?? '/';
$currentPath = parse_url($current, PHP_URL_PATH) ?: '/';
?><!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Refresh Panel</title>
<link rel="stylesheet" href="/assets/admin.css">
</head>
<body>
<header class="hub-header">
    <div class="hub-header__inner">
        <a class="hub-logo" href="/">🔄 Refresh Panel</a>

        <!-- Десктоп: nav в обычном flow -->
        <nav class="hub-nav hub-nav--desktop">
            <?php foreach ($nav as $url => $label): ?>
                <a href="<?= htmlspecialchars($url) ?>" class="<?= ($currentPath === $url || ($url !== '/' && strpos($currentPath, $url) === 0)) ? 'is-active' : '' ?>"><?= htmlspecialchars($label) ?></a>
            <?php endforeach; ?>
        </nav>

        <!-- Мобильное burger-меню: details/summary, скрыто на десктопе -->
        <details class="hub-nav-mobile">
            <summary class="hub-burger"></summary>
            <nav class="hub-nav hub-nav--mobile">
                <?php foreach ($nav as $url => $label): ?>
                    <a href="<?= htmlspecialchars($url) ?>" class="<?= ($currentPath === $url || ($url !== '/' && strpos($currentPath, $url) === 0)) ? 'is-active' : '' ?>"><?= htmlspecialchars($label) ?></a>
                <?php endforeach; ?>
            </nav>
        </details>

        <a class="hub-logout" href="/logout">Выйти</a>
    </div>
</header>

<?php
// v18.1.28: status-bar с балансами Namecheap (USD) и XMLStock (RUB).
// Источник данных — таблица balance_current (обновляется cron'ом раз в час
// + после покупки + при старте index_watching).
// Если таблица отсутствует (миграция 015 не применена) — sub-bar скрывается.
//
// v18.1.28 defensive: для каждого сервиса показываем ОДНУ строку — самую свежую
// по last_checked_at. Защита от дубликатов в balance_current (могли остаться от
// до миграции 017, или если в БД явно создано несколько аккаунтов с разными
// account_label). Если миграция 017 применена — дубликатов уже нет, defensive
// никак не меняет вывод.
try {
    // ORDER BY: для каждой пары (service, account_label) самая свежая запись первая.
    // Затем в PHP оставляем по одной на service (предпочитаем 'default' если есть,
    // иначе самую свежую).
    $rawBalances = DB::pdo()->query(
        "SELECT * FROM balance_current
         ORDER BY service ASC,
                  CASE WHEN account_label = 'default' THEN 0 ELSE 1 END,
                  last_checked_at DESC"
    )->fetchAll();
    $balancesRows = [];
    $seenServices = [];
    // ТЗ 042 §3.3: не используем в layout слишком общее имя $row — оно затирало
    // переданные во View переменные (например $row сервера на /servers/edit).
    foreach ($rawBalances as $balanceRow) {
        $svcKey = (string)$balanceRow['service'];
        if (isset($seenServices[$svcKey])) continue;
        $seenServices[$svcKey] = true;
        $balancesRows[] = $balanceRow;
    }
} catch (\Throwable $e) {
    $balancesRows = [];
}
if (!empty($balancesRows)):
?>
<div class="hub-subbar" style="background: var(--bg-secondary, rgba(255,255,255,0.03));
     border-bottom: 1px solid var(--border, rgba(255,255,255,0.08));
     padding: 8px 16px; font-size: 0.85em;">
    <div class="hub-subbar__inner" style="max-width: 1400px; margin: 0 auto;
         display: flex; gap: 16px; flex-wrap: wrap; align-items: center;">
        <span class="muted" style="font-weight: 600;">Балансы:</span>
        <?php foreach ($balancesRows as $b):
            $svc = (string)$b['service'];
            $label = (string)$b['account_label'];
            $bal = (float)$b['balance'];
            $cur = (string)$b['currency'];
            $status = (string)$b['status'];
            $thr = (float)$b['threshold'];
            $lastCheckedAt = (string)($b['last_checked_at'] ?? '');
            $errMsg = (string)($b['error_message'] ?? '');

            // Цвет статуса
            $color = match ($status) {
                'ok'      => 'var(--success, #28a745)',
                'low'     => 'var(--warning, #ffc107)',
                'error'   => 'var(--danger, #dc3545)',
                'unknown' => 'var(--text-muted, #888)',
                default   => 'var(--text-muted, #888)',
            };
            $emoji = match ($status) {
                'ok'      => '✓',
                'low'     => '⚠',
                'error'   => '✗',
                'unknown' => '·',
                default   => '·',
            };

            // Форматируем баланс
            if ($status === 'unknown' || $lastCheckedAt === '') {
                $balStr = '—';
            } else {
                $balStr = $cur === 'USD'
                    ? '$' . number_format($bal, 2)
                    : ($cur === 'RUB' ? number_format($bal, 0) . ' ₽' : number_format($bal, 2) . ' ' . $cur);
            }

            // Title-tooltip
            $title = ucfirst($svc) . ($label !== 'default' ? " ({$label})" : '');
            if ($status === 'low') {
                $thrStr = $cur === 'USD' ? '$' . number_format($thr, 2) : number_format($thr, 0) . ' ' . $cur;
                $title .= "\nПорог: {$thrStr} — баланс ниже!";
            } elseif ($status === 'error') {
                $title .= "\nОшибка: " . $errMsg;
            }
            if ($lastCheckedAt !== '') {
                $title .= "\nПроверено: " . Time::msk($lastCheckedAt, 'Y-m-d H:i:s');
            }

            $svcName = $svc === 'namecheap' ? 'Namecheap' : ($svc === 'xmlstock' ? 'XMLStock' : ucfirst($svc));
        ?>
            <span title="<?= htmlspecialchars($title) ?>"
                  style="color: <?= $color ?>; white-space: nowrap;">
                <span style="opacity: 0.85;"><?= $emoji ?></span>
                <strong><?= htmlspecialchars($svcName) ?>:</strong>
                <?= htmlspecialchars($balStr) ?>
                <?php if ($status === 'low'): ?>
                    <span style="font-size: 0.85em; opacity: 0.75;">⚠ ниже порога</span>
                <?php endif; ?>
                <?php if ($status === 'error'): ?>
                    <span style="font-size: 0.85em; opacity: 0.75;">ошибка</span>
                <?php endif; ?>
            </span>
        <?php endforeach; ?>
        <span style="flex: 1;"></span>
        <form method="post" action="/system/balance/refresh" style="margin: 0;">
            <button type="submit" class="btn btn-sm btn-secondary"
                    style="font-size: 0.85em; padding: 2px 10px;"
                    title="Обновить балансы вручную">
                🔄 Обновить
            </button>
        </form>
    </div>
</div>
<?php endif; ?>

<main class="hub-main">
<?php foreach (['success' => 'success', 'error' => 'error', 'warning' => 'warning'] as $type => $cls): ?>
    <?php if (!empty($flash[$type])): ?>
        <?php foreach ((array)$flash[$type] as $msg): ?>
            <div class="hub-flash hub-flash--<?= $cls ?>"><?= htmlspecialchars((string)$msg) ?></div>
        <?php endforeach; ?>
    <?php endif; ?>
<?php endforeach; ?>

<?php
$viewFile = Paths::appRoot() . '/app/Views/' . $__view . '.php';
if (file_exists($viewFile)) {
    require $viewFile;
} else {
    echo '<div class="hub-flash hub-flash--error">View not found: ' . htmlspecialchars($__view) . '</div>';
}
?>
</main>

<footer class="hub-footer">
    <div class="hub-footer__inner">
        Refresh Panel β · <?= date('Y') ?>
    </div>
</footer>

<script src="/assets/admin.js" defer></script>
</body>
</html>
