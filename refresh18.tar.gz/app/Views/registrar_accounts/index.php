<h1 class="page-title">Аккаунты регистратора (Namecheap)</h1>

<div class="page-toolbar">
    <div></div>
    <div class="page-actions">
        <a href="/registrar/accounts/create" class="btn btn-primary">Добавить</a>
    </div>
</div>

<?php if (empty($rows)): ?>
    <div class="empty-state">
        <p>Аккаунтов нет. <a href="/registrar/accounts/create">Добавить</a> — нужно для покупки доменов.</p>
    </div>
<?php else: ?>
    <table class="hub-table">
        <thead><tr><th>#</th><th>Username</th><th>API user</th><th>Client IP</th><th>Sandbox</th><th>Default</th><th></th></tr></thead>
        <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= (int)$r['id'] ?></td>
                    <td><?= htmlspecialchars($r['username']) ?></td>
                    <td><?= htmlspecialchars($r['api_user']) ?></td>
                    <td><code><?= htmlspecialchars($r['client_ip']) ?></code></td>
                    <td><?= $r['is_sandbox'] ? '✓' : '—' ?></td>
                    <td><?= $r['is_default'] ? '★' : '—' ?></td>
                    <td>
                        <form method="post" action="/registrar/accounts/delete" onsubmit="return confirm('Удалить?');" style="display:inline">
                            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">×</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
