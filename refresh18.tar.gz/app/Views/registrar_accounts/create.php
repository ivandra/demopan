<h1 class="page-title"><a href="/registrar/accounts" class="back-link">← Аккаунты</a> Добавить аккаунт Namecheap</h1>

<form method="post" action="/registrar/accounts/create" class="form-card">
    <p class="muted small">Reg-аккаунт нужен только когда дойдём до этапа покупки доменов. Можно пока пропустить.</p>
    <label>API user (обычно совпадает с username)
        <input type="text" name="api_user" required>
    </label>
    <label>API key
        <input type="password" name="api_key" required>
    </label>
    <label>Username Namecheap
        <input type="text" name="username" required>
    </label>
    <label>Client IP (whitelist в Namecheap)
        <input type="text" name="client_ip" placeholder="IP вашего хостинга" required>
    </label>
    <label class="checkbox">
        <input type="checkbox" name="is_sandbox" value="1">
        Это sandbox API
    </label>
    <label class="checkbox">
        <input type="checkbox" name="is_default" value="1" checked>
        Сделать аккаунтом по умолчанию
    </label>
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <a href="/registrar/accounts" class="btn btn-secondary">Отмена</a>
</form>
