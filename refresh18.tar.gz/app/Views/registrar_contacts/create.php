<h1 class="page-title"><a href="/registrar/contacts" class="back-link">← Контакты</a> Добавить контакт</h1>

<form method="post" action="/registrar/contacts/create" class="form-card">
    <div class="form-grid">
        <label>Label (название профиля)<input type="text" name="label" value="default"></label>
        <label>First name *<input type="text" name="first_name" required></label>
        <label>Last name *<input type="text" name="last_name" required></label>
        <label>Organization<input type="text" name="organization"></label>
        <label>Address 1 *<input type="text" name="address1" required></label>
        <label>Address 2<input type="text" name="address2"></label>
        <label>City *<input type="text" name="city" required></label>
        <label>State / Province<input type="text" name="state_province"></label>
        <label>Postal code *<input type="text" name="postal_code" required></label>
        <label>Country (2 letter, e.g. US) *<input type="text" name="country" maxlength="2" required></label>
        <label>Phone (+1.555... format) *<input type="text" name="phone" required></label>
        <label>Email *<input type="email" name="email" required></label>
    </div>
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <a href="/registrar/contacts" class="btn btn-secondary">Отмена</a>
</form>
