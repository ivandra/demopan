<h1 class="page-title">Контакты регистратора</h1>

<div class="page-toolbar">
    <div></div>
    <div class="page-actions">
        <a href="/registrar/contacts/create" class="btn btn-primary">Добавить</a>
    </div>
</div>

<?php if (empty($rows)): ?>
    <div class="empty-state">
        <p>Контактов нет. Контакт нужен для регистрации доменов через Namecheap.</p>
    </div>
<?php else: ?>
    <table class="hub-table">
        <thead><tr><th>#</th><th>Label</th><th>Имя</th><th>Email</th><th>Страна</th><th></th></tr></thead>
        <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= (int)$r['id'] ?></td>
                    <td><?= htmlspecialchars($r['label']) ?></td>
                    <td><?= htmlspecialchars($r['first_name'] . ' ' . $r['last_name']) ?></td>
                    <td><?= htmlspecialchars($r['email']) ?></td>
                    <td><?= htmlspecialchars($r['country']) ?></td>
                    <td>
                        <form method="post" action="/registrar/contacts/delete" onsubmit="return confirm('Удалить?');" style="display:inline">
                            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger">×</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
