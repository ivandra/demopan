<h1 class="page-title">Сайты</h1>

<div class="page-toolbar">
    <form method="get" action="/sites" class="page-search">
        <input type="text" name="q" value="<?= htmlspecialchars($q ?? '') ?>" placeholder="Поиск по домену...">
        <?php // §3.5: сохранить выбранный сервер при поиске
        if (!empty($serverFilter)): ?>
            <input type="hidden" name="server_id" value="<?= (int)$serverFilter ?>">
        <?php endif; ?>
        <button type="submit" class="btn btn-secondary">Найти</button>
    </form>
    <?php include Paths::appRoot() . '/app/Views/partials/server_filter.php'; ?>
    <div class="page-actions">
        <a href="/sites/import" class="btn btn-primary">Импорт с FastPanel</a>
        <a href="/sites/create-manual" class="btn btn-secondary">Добавить вручную</a>
    </div>
</div>

<?php if (empty($rows)): ?>
    <div class="empty-state">
        <p>Сайтов пока нет.</p>
        <p>Сначала <a href="/servers">добавьте сервер FastPanel</a>, потом нажмите <a href="/sites/import">Импорт с FastPanel</a>.</p>
    </div>
<?php else: ?>
    <table class="hub-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Домен</th>
                <th>Сервер FP</th>
                <th>IP</th>
                <th>Статус</th>
                <th>Конфиг</th>
                <th>Алиасы</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $r): ?>
                <?php
                    $aliases = [];
                    if (!empty($r['aliases'])) $aliases = json_decode((string)$r['aliases'], true) ?: [];
                    $cfg = [];
                    if (!empty($r['config_parsed_json'])) $cfg = json_decode((string)$r['config_parsed_json'], true) ?: [];
                ?>
                <tr>
                    <td><?= (int)$r['id'] ?></td>
                    <td>
                        <?php $badgeRow = $r; $badgeMode = 'compact'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; ?>
                        <a href="/sites/show?id=<?= (int)$r['id'] ?>" class="link-strong"><?= htmlspecialchars($r['current_domain']) ?></a>
                        <?php if (!empty($cfg['title'])): ?>
                            <div class="muted small"><?= htmlspecialchars(mb_substr((string)$cfg['title'], 0, 60)) ?>…</div>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars((string)($r['server_title'] ?? '—')) ?></td>
                    <td><?= htmlspecialchars((string)($r['vps_ip'] ?? '')) ?></td>
                    <td><span class="pill pill-<?= htmlspecialchars((string)$r['status']) ?>"><?= htmlspecialchars((string)$r['status']) ?></span></td>
                    <td>
                        <?php if (!empty($cfg)): ?>
                            <span class="pill pill-ok">распознан</span>
                        <?php else: ?>
                            <span class="pill pill-warn">нет</span>
                        <?php endif; ?>
                    </td>
                    <td><?= count($aliases) ?></td>
                    <td>
                        <a href="/sites/show?id=<?= (int)$r['id'] ?>" class="btn btn-sm">Открыть</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
