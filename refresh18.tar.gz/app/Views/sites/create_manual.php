<h1 class="page-title">Добавить сайт вручную</h1>

<form method="post" action="/sites/create-manual" class="form-card">
    <p class="muted">Используйте этот вариант если автоимпорт с FastPanel не нашёл нужный сайт.</p>

    <label>Домен (https://...)
        <input type="text" name="current_domain" placeholder="https://example.com" required>
    </label>

    <label>Сервер FastPanel
        <select name="fastpanel_server_id">
            <option value="">— не привязан —</option>
            <?php foreach ($servers as $s): ?>
                <option value="<?= (int)$s['id'] ?>"><?= htmlspecialchars($s['title']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>

    <label>VPS IP
        <input type="text" name="vps_ip" placeholder="95.129.234.20">
    </label>

    <label>FastPanel owner (имя пользователя)
        <input type="text" name="fp_site_owner" placeholder="irwincasino7_usr">
    </label>

    <label>Index dir (корень сайта на VPS)
        <input type="text" name="fp_index_dir" placeholder="/var/www/owner/data/www/domain.com">
    </label>

    <button type="submit" class="btn btn-primary">Создать</button>
    <a href="/sites" class="btn btn-secondary">Отмена</a>
</form>
