<h1 class="page-title">
    <a href="/sites/show?id=<?= (int)$site['id'] ?>" class="back-link">← <?= htmlspecialchars($site['current_domain']) ?></a>
    Редактирование
</h1>

<form method="post" action="/sites/update" class="form-card">
    <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">

    <h2>Основное</h2>
    <label>Текущий домен
        <input type="text" name="current_domain" value="<?= htmlspecialchars($site['current_domain']) ?>" required>
    </label>
    <label>VPS IP
        <input type="text" name="vps_ip" value="<?= htmlspecialchars((string)($site['vps_ip'] ?? '')) ?>">
    </label>
    <label>Полный путь к config.php на VPS (если автодетект ошибается)
        <input type="text" name="config_remote_path" value="<?= htmlspecialchars((string)($site['config_remote_path'] ?? '')) ?>" placeholder="/var/www/owner/data/www/domain.com/config.php">
    </label>
    <label>Заметка
        <textarea name="note" rows="3"><?= htmlspecialchars((string)($site['note'] ?? '')) ?></textarea>
    </label>

    <h2>FTP доступ к сайту</h2>
    <p class="muted small">Нужен для чтения и записи config.php. FastPanel создаёт FTP-аккаунт на каждый сайт.</p>
    <label>FTP host (если пусто — берётся хост сервера FastPanel)
        <input type="text" name="ftp_host" value="<?= htmlspecialchars((string)($site['ftp_host'] ?? '')) ?>" placeholder="auto">
    </label>
    <label>FTP user
        <input type="text" name="ftp_user" value="<?= htmlspecialchars((string)($site['ftp_user'] ?? '')) ?>">
    </label>
    <label>FTP пароль
        <input type="password" name="ftp_pass" placeholder="<?= !empty($site['ftp_pass_enc']) ? '(оставьте пустым чтобы не менять)' : '' ?>">
    </label>

    <h2>Регистратор по умолчанию для перевыставления</h2>
    <label>Аккаунт Namecheap
        <select name="registrar_account_id">
            <option value="">— не указан —</option>
            <?php foreach ($regs as $r): ?>
                <option value="<?= (int)$r['id'] ?>" <?= (int)$r['id'] === (int)($site['registrar_account_id'] ?? 0) ? 'selected' : '' ?>>
                    #<?= (int)$r['id'] ?> — <?= htmlspecialchars($r['username']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Контакт регистратора
        <select name="registrar_contact_id">
            <option value="">— не указан —</option>
            <?php foreach ($contacts as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= (int)$c['id'] === (int)($site['registrar_contact_id'] ?? 0) ? 'selected' : '' ?>>
                    #<?= (int)$c['id'] ?> — <?= htmlspecialchars($c['first_name'] . ' ' . $c['last_name']) ?> (<?= htmlspecialchars($c['label']) ?>)
                </option>
            <?php endforeach; ?>
        </select>
    </label>

    <button type="submit" class="btn btn-primary">Сохранить</button>
    <a href="/sites/show?id=<?= (int)$site['id'] ?>" class="btn btn-secondary">Отмена</a>
</form>
