<?php
// §5.2.1 (v4): безопасная нормализация необязательных переменных View.
// Штатный контроллер обязан передавать эти значения (проверяется отдельно в
// integration-тесте); здесь — защита от Warning при неполном контракте, чтобы
// страница никогда не показывала PHP Warning в HTML.
$nextDomain = isset($nextDomain) ? (string)$nextDomain : '';
$oldSubId   = isset($oldSubId) ? (string)$oldSubId : '';
$nextSubId  = isset($nextSubId) ? (string)$nextSubId : '';
$subIdField = $subIdField ?? '';
$subIdConflict = is_array($subIdConflict ?? null) ? $subIdConflict : [];
$maskOpts   = is_array($maskOpts ?? null) ? $maskOpts : [];
// дефолты ключей maskOpts (§5.2: безопасная обработка, чтобы форма настроек
// маски никогда не давала Undefined array key при неполном контракте).
$maskOpts += [
    'strategy' => 'number', 'prefix' => '', 'step' => 1,
    'no_digit_start' => 0, 'letter_alphabet' => '',
    'sync_with_domain' => 0,
];
$aliases    = is_array($aliases ?? null) ? $aliases : [];
$config     = is_array($config ?? null) ? $config : [];
$monitors   = is_array($monitors ?? null) ? $monitors : [];
$events     = is_array($events ?? null) ? $events : [];
$jobs       = is_array($jobs ?? null) ? $jobs : [];
$recentJobs = is_array($recentJobs ?? null) ? $recentJobs : [];

$importLog = null;
if (!empty($site['import_log'])) {
    $importLog = json_decode((string)$site['import_log'], true);
}
$importErrors = [];
if (is_array($importLog)) {
    foreach ($importLog as $entry) {
        if (($entry['level'] ?? '') === 'error') $importErrors[] = $entry;
    }
}
?>
<h1 class="page-title">
    <a href="/sites" class="back-link">← Сайты</a>
    <?php // ТЗ 040 §9.4/§9.6: бейдж готовит контроллер ($serverBadge).
    if (!empty($serverBadge)) { $badge = $serverBadge; $badgeMode = 'full'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; } ?>
    <?= htmlspecialchars($site['current_domain']) ?>
</h1>

<div class="page-toolbar">
    <div class="hub-statusline">
        <div class="hub-statusline__left">
            <span class="hub-mini-pill <?= !empty($site['vps_ip']) ? 'is-ok' : 'is-bad' ?>">
                <span class="hub-mini-pill__dot"></span>
                <b>VPS</b>
                <span><?= htmlspecialchars((string)($site['vps_ip'] ?? '—')) ?></span>
            </span>
            <span class="hub-mini-pill <?= !empty($config) ? 'is-ok' : 'is-warn' ?>">
                <span class="hub-mini-pill__dot"></span>
                <b>config.php</b>
                <span><?= !empty($config) ? 'распознан' : 'нет' ?></span>
            </span>
            <span class="hub-mini-pill <?= !empty($site['ftp_user']) ? 'is-ok' : 'is-warn' ?>">
                <span class="hub-mini-pill__dot"></span>
                <b>FTP</b>
                <span><?= !empty($site['ftp_user']) ? 'настроен' : 'нет' ?></span>
            </span>
            <span class="hub-mini-pill is-info">
                <span class="hub-mini-pill__dot"></span>
                <b>Алиасы</b>
                <span><?= count($aliases) ?></span>
            </span>
            <span class="hub-mini-pill <?= $site['status'] === 'imported' ? 'is-ok' : 'is-info' ?>">
                <span class="hub-mini-pill__dot"></span>
                <b>Статус</b>
                <span><?= htmlspecialchars((string)$site['status']) ?></span>
            </span>
        </div>
    </div>
    <div class="page-actions">
        <a href="/sites/edit?id=<?= (int)$site['id'] ?>" class="btn btn-secondary">Редактировать</a>
        <a href="/sites/diagnose?id=<?= (int)$site['id'] ?>" class="btn btn-secondary">Диагностика</a>
        <?php if (!empty($site['fastpanel_server_id']) && !empty($site['fp_site_id'])): ?>
            <form method="post" action="/sites/refresh-from-fp" style="display:inline;"
                  title="Перечитать данные сайта из FastPanel API (vps_ip, aliases, fp_index_dir)">
                <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
                <button type="submit" class="btn btn-secondary">↻ Обновить с FP</button>
            </form>
        <?php endif; ?>
        <?php if (empty($site['ftp_user'])): ?>
            <form method="post" action="/sites/create-ftp" style="display:inline;">
                <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
                <button type="submit" class="btn btn-primary">Создать FTP</button>
            </form>
        <?php else: ?>
            <form method="post" action="/sites/sync-config" style="display:inline;">
                <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
                <button type="submit" class="btn btn-primary">Синхронизировать config.php</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($importErrors)): ?>
    <div class="hub-flash hub-flash--warning">
        <b>⚠️ При импорте были ошибки:</b>
        <ul style="margin: 8px 0 0 20px;">
            <?php foreach ($importErrors as $e): ?>
                <li><?= htmlspecialchars($e['msg'] ?? '?') ?></li>
            <?php endforeach; ?>
        </ul>
        <p style="margin: 8px 0 0 0; font-size: 0.9em;">
            <a href="/sites/diagnose?id=<?= (int)$site['id'] ?>">→ Открыть полную диагностику</a>
            &nbsp;·&nbsp;
            <form method="post" action="/sites/clear-import-log" style="display:inline;"
                  onsubmit="return confirm('Очистить старые записи import_log? Это уберёт это предупреждение, если ошибки уже не актуальны.');">
                <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
                <button type="submit" class="btn btn-link" style="background:none;border:none;padding:0;color:inherit;text-decoration:underline;cursor:pointer;font-size:inherit;">Очистить старый import_log</button>
            </form>
        </p>
    </div>
<?php endif; ?>

<?php if (!empty($activeJob)): ?>
    <div class="hub-flash hub-flash--warning">
        <b>Идёт перевыставление #<?= (int)$activeJob['id'] ?></b><br>
        Этап: <?= htmlspecialchars(JobEventPresenter::stageLabel((string)$activeJob['stage'])) ?>
        — <?= htmlspecialchars(JobEventPresenter::statusLabel((string)$activeJob['stage_status'])) ?><br>
        Старый домен: <?= htmlspecialchars($activeJob['old_domain']) ?> → новый: <?= htmlspecialchars($activeJob['new_domain'] ?: '(будет вычислен)') ?>
    </div>
<?php endif; ?>

<div class="grid-2">
    <section class="card">
        <h2>📡 FastPanel</h2>
        <dl class="kv">
            <dt>FP Site ID</dt><dd><?= (int)$site['fp_site_id'] ?></dd>
            <dt>Owner</dt><dd><?= htmlspecialchars((string)$site['fp_site_owner']) ?></dd>
            <dt>Index dir</dt><dd><code><?= htmlspecialchars((string)$site['fp_index_dir']) ?></code></dd>
            <dt>Сервер</dt><dd>#<?= (int)$site['fastpanel_server_id'] ?></dd>
            <?php if (!empty($site['ftp_user'])): ?>
                <dt>FTP user</dt><dd><code><?= htmlspecialchars((string)$site['ftp_user']) ?></code></dd>
                <dt>FTP host</dt><dd><code><?= htmlspecialchars((string)$site['ftp_host']) ?></code></dd>
            <?php endif; ?>
        </dl>
    </section>

    <section class="card">
        <h2>🔄 Маска перевыставления</h2>
        <dl class="kv">
            <dt>Текущий домен</dt><dd><b><?= htmlspecialchars($site['current_domain']) ?></b></dd>
            <dt>Следующий по маске</dt>
            <dd><b class="text-success"><?= htmlspecialchars((string)$nextDomain) ?></b></dd>
            <?php if ($oldSubId !== ''): ?>
                <dt>Текущий sub_id</dt>
                <dd>
                    <?= htmlspecialchars($oldSubId) ?>
                    <?php if (!empty($subIdField)): ?>
                        <span class="muted small">&nbsp;— из <code><?= htmlspecialchars($subIdField) ?></code></span>
                    <?php endif; ?>
                    <?php if (!empty($subIdConflict)): ?>
                        <div class="muted small" style="margin-top:4px; color:#f0a020;">
                            ⚠️ В разных полях конфига указаны РАЗНЫЕ sub_id:
                            <?php foreach ($subIdConflict as $f => $v): ?>
                                <code><?= htmlspecialchars($f) ?></code> = <code><?= htmlspecialchars($v) ?></code>&nbsp;
                            <?php endforeach; ?>
                            <br>Замена выполняется по значению из партнёрской ссылки; остальные останутся как есть.
                        </div>
                    <?php endif; ?>
                </dd>
                <dt>Новый sub_id</dt>
                <dd>
                    <b class="text-success"><?= htmlspecialchars($nextSubId) ?></b>
                    <?php if (!empty($maskOpts['sync_with_domain']) && ($maskOpts['strategy'] ?? '') === 'number'): ?>
                        <span class="muted small">&nbsp;— число синхронизировано с новым доменом</span>
                    <?php elseif (($maskOpts['strategy'] ?? '') === 'letter'): ?>
                        <span class="muted small">&nbsp;— буквенный счётчик (число не трогаем)</span>
                    <?php endif; ?>
                </dd>
            <?php else: ?>
                <dt>sub_id</dt>
                <dd class="muted small">
                    не найден в config.php (искали в internal_reg_url, base_new_url,
                    base_second_url, partner_override_url) — замена sub_id не выполняется
                </dd>
            <?php endif; ?>
        </dl>

        <?php $mo = isset($maskOpts) && is_array($maskOpts) ? $maskOpts : DomainMaskService::DEFAULTS; ?>
        <details class="technical-details" style="margin-top:10px">
            <summary class="muted small" style="cursor:pointer">
                ⚙️ Настройки маски для этого сайта —
                <?= !empty($maskIsPerSite) ? '<b>персональные</b>' : 'общие' ?>
                (стратегия: <code><?= htmlspecialchars((string)$mo['strategy']) ?></code><?php
                    if (!empty($mo['prefix_enabled']) && $mo['prefix'] !== '') {
                        echo ', префикс <code>' . htmlspecialchars((string)$mo['prefix']) . '</code>';
                    } ?>)
            </summary>
            <form method="post" action="/sites/mask" style="margin-top:10px; padding:10px; background:rgba(255,255,255,.03); border-radius:6px;">
                <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">

                <label style="display:block; margin-bottom:10px;">
                    <input type="checkbox" name="use_global" value="1" <?= empty($maskIsPerSite) ? 'checked' : '' ?>>
                    <strong>Использовать общие настройки</strong>
                    <span class="muted small">&nbsp;— снять галку, чтобы задать персональные для этого сайта</span>
                </label>

                <label style="display:block; max-width:340px; margin-bottom:10px;">
                    <strong>Стратегия</strong>
                    <select name="mask_strategy" style="width:100%; padding:6px;">
                        <option value="number" <?= ($mo['strategy'] === 'number' ? 'selected' : '') ?>>number — счётчик в числе</option>
                        <option value="letter" <?= ($mo['strategy'] === 'letter' ? 'selected' : '') ?>>letter — счётчик в буквах (число = бренд)</option>
                    </select>
                    <span class="muted small">
                        <code>letter</code> — для sub_id вида <code>A_azino_777df_casino</code>:
                        <code>777</code> не трогаем, сдвигается <code>df → dg</code>.
                    </span>
                </label>

                <label style="display:block; margin-bottom:10px;">
                    <input type="checkbox" name="mask_sync_with_domain" value="1" <?= (!empty($mo['sync_with_domain']) ? 'checked' : '') ?>>
                    <strong>Синхронизировать число sub_id с доменом</strong>
                    <span class="muted small">&nbsp;— sub_id всегда получает число нового домена (рекомендуется)</span>
                </label>

                <label style="display:block; margin-bottom:10px;">
                    <input type="checkbox" name="mask_prefix_enabled" value="1" <?= (!empty($mo['prefix_enabled']) ? 'checked' : '') ?>>
                    <strong>Префикс сотрудника</strong>
                    <input type="text" name="mask_prefix" value="<?= htmlspecialchars((string)$mo['prefix']) ?>"
                           placeholder="A_" maxlength="16" style="width:90px; padding:4px; margin-left:6px;">
                    <span class="muted small">&nbsp;— добавляется в начало sub_id, если его там нет</span>
                </label>

                <label style="display:block; max-width:200px; margin-bottom:10px;">
                    <strong>Шаг</strong>
                    <input type="number" name="mask_step" value="<?= (int)$mo['step'] ?>" min="1" max="1000" style="width:100%; padding:6px;">
                </label>

                <label style="display:block; max-width:200px; margin-bottom:10px;">
                    <strong>Если цифр нет</strong>
                    <input type="number" name="mask_no_digit_start" value="<?= (int)$mo['no_digit_start'] ?>" min="0" max="999999" style="width:100%; padding:6px;">
                </label>

                <label style="display:block; max-width:340px; margin-bottom:10px;">
                    <strong>Алфавит (для letter)</strong>
                    <input type="text" name="mask_letter_alphabet" value="<?= htmlspecialchars((string)$mo['letter_alphabet']) ?>" style="width:100%; padding:6px;">
                </label>

                <label style="display:block; margin-bottom:8px;">
                    <input type="checkbox" name="mask_pad_zeros" value="1" <?= (!empty($mo['pad_zeros']) ? 'checked' : '') ?>>
                    Сохранять ведущие нули
                </label>
                <label style="display:block; margin-bottom:12px;">
                    <input type="checkbox" name="mask_letter_wrap" value="1" <?= (!empty($mo['letter_wrap']) ? 'checked' : '') ?>>
                    Перенос букв (dz → ea)
                </label>

                <button type="submit" class="btn btn-primary">Сохранить для этого сайта</button>
            </form>
        </details>

        <?php
        // Активная джоба (передаётся из контроллера в $activeJob)
        $hasActiveJob = !empty($activeJob);
        $canStart = !$hasActiveJob && !empty($config); // нужен синхронизированный config

        // Sandbox-режим из настроек (v13b)
        $useSandbox = true;
        try {
            $st = DB::pdo()->query("SELECT use_sandbox FROM telegram_settings WHERE id=1");
            $r = $st->fetchColumn();
            $useSandbox = $r === false ? true : (int)$r === 1;
        } catch (Throwable $e) {
            // миграция 004 не применена — fallback
        }

        // IP куда пойдёт DNS (для предпросмотра)
        $dnsTargetIp = null;
        try {
            $resolver = new SiteIpResolver();
            $dnsTargetIp = $resolver->resolveOffline((int)$site['id']);
        } catch (\Throwable $e) {}
        ?>

<?php
            // ═══ PATCH 048: постоянная привязка сайта к Webmaster + данные для launch-select ═══
            $wmAccts = [];
            try {
                $stWm = DB::pdo()->query(
                    "SELECT a.id, a.label, a.email, a.note, a.host_count, a.is_default,
                            a.outbound_ip_id, a.last_outbound_ok,
                            i.ip_address AS outbound_ip_address, i.is_default AS outbound_ip_is_default,
                            i.is_enabled AS outbound_ip_enabled
                       FROM yandex_webmaster_accounts a
                       LEFT JOIN webmaster_outbound_ips i ON i.id = a.outbound_ip_id
                      WHERE a.access_token_enc IS NOT NULL AND a.access_token_enc <> ''
                      ORDER BY a.is_default DESC, a.host_count DESC"
                );
                $wmAccts = $stWm->fetchAll();
            } catch (\Throwable $e) {}
            // DEFAULT IP пула (для аккаунтов с outbound_ip_id = NULL).
            $poolDefaultIp = '';
            try {
                $poolDefaultIp = (string)(DB::pdo()->query(
                    "SELECT ip_address FROM webmaster_outbound_ips WHERE is_default=1 AND is_enabled=1 LIMIT 1"
                )->fetchColumn() ?: '');
            } catch (\Throwable $e) {}
            $siteBinding = (isset($site['webmaster_account_id']) && $site['webmaster_account_id'] !== null)
                ? (int)$site['webmaster_account_id'] : 0;
            // JS-карта: account_id → {ip, kind, ok}
            $wmIpMap = [];
            foreach ($wmAccts as $a) {
                $aid = (int)$a['id'];
                $ip = $a['outbound_ip_address'] ? (string)$a['outbound_ip_address'] : $poolDefaultIp;
                $kind = $a['outbound_ip_address'] ? 'ASSIGNED' : 'DEFAULT';
                $wmIpMap[$aid] = ['ip' => $ip, 'kind' => $kind, 'ok' => $a['last_outbound_ok']];
            }
            ?>
            <?php if (!empty($wmAccts)): ?>
            <div class="card" style="margin-top:12px; border:1px solid var(--border); border-radius:8px; padding:14px;">
                <h3 style="margin:0 0 10px 0;">🌐 Webmaster сайта</h3>
                <form method="post" action="/sites/save-webmaster-account" style="margin:0;">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken ?? '') ?>">
                    <input type="hidden" name="site_id" value="<?= (int)$site['id'] ?>">
                    <label class="muted small" style="display:block; margin-bottom:4px;">Закреплённый аккаунт</label>
                    <select name="webmaster_account_id" id="wm-binding-select" style="padding:6px 10px; min-width:360px;">
                        <option value="0" <?= $siteBinding === 0 ? 'selected' : '' ?>>— Не привязан / Авто —</option>
                        <?php foreach ($wmAccts as $acc):
                            $note = trim((string)($acc['note'] ?? '')); $email = (string)($acc['email'] ?? '');
                        ?>
                            <option value="<?= (int)$acc['id'] ?>" <?= $siteBinding === (int)$acc['id'] ? 'selected' : '' ?>>
                                #<?= (int)$acc['id'] ?> · <?= $note !== '' ? htmlspecialchars($note) . ' · ' : '' ?><?= htmlspecialchars($email) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div id="wm-binding-ip" class="muted small" style="margin:8px 0;"></div>
                    <div id="wm-binding-warn" class="small" style="margin:8px 0; color:var(--warning); display:none;">
                        ⚠ У выбранного аккаунта последняя IP-проверка неуспешна — рекомендуется «Проверить API / IP» на странице Webmaster-токенов перед привязкой.
                    </div>
                    <p class="muted small" style="margin:8px 0;">
                        Привязка определяет, куда попадут <strong>будущие новые домены</strong> сайта. Смена привязки
                        <strong>не переносит</strong> текущий домен между аккаунтами и не трогает существующие Webmaster-хосты —
                        применяется к следующим джобам.
                    </p>
                    <?php if (!empty($activeJob)): ?>
                    <p class="small" style="margin:8px 0; color:var(--warning);">
                        ⚠ У сайта есть активная джоба #<?= (int)$activeJob['id'] ?> — она уже зафиксировала свой Webmaster-аккаунт
                        и продолжит с ним. Сохранение привязки применится только к следующим джобам.
                    </p>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary btn-sm">Сохранить Webmaster</button>
                </form>
            </div>
            <script>
            (function(){
                var MAP = <?= json_encode($wmIpMap, JSON_UNESCAPED_UNICODE) ?>;
                var sel = document.getElementById('wm-binding-select');
                var ipBox = document.getElementById('wm-binding-ip');
                var warn = document.getElementById('wm-binding-warn');
                function upd(){
                    var id = sel ? sel.value : '0';
                    if (!id || id === '0' || !MAP[id]) {
                        ipBox.innerHTML = 'Новые джобы будут определять аккаунт по старому домену (Auto).';
                        warn.style.display = 'none'; return;
                    }
                    var m = MAP[id];
                    var okTxt = (m.ok === null || typeof m.ok === 'undefined') ? '' :
                        (Number(m.ok) === 1 ? ' · ✓ подтверждён' : ' · ⚠ последняя IP-проверка неуспешна');
                    ipBox.innerHTML = 'Исходящий IP: <code>' + (m.ip || '—') + '</code> · ' + m.kind + okTxt;
                    warn.style.display = (m.ok !== null && Number(m.ok) === 0) ? 'block' : 'none';
                }
                if (sel) { sel.addEventListener('change', upd); upd(); }
            })();
            </script>
            <?php endif; ?>

        <?php if ($hasActiveJob): ?>
            <div class="hub-flash hub-flash--warning" style="margin-top: 12px;">
                <b>Есть активная джоба #<?= (int)$activeJob['id'] ?></b> — стадия:
                <?= htmlspecialchars(JobEventPresenter::stageLabel((string)$activeJob['stage'])) ?>
                — <?= htmlspecialchars(JobEventPresenter::statusLabel((string)$activeJob['stage_status'])) ?>.
                <a href="/jobs/show?id=<?= (int)$activeJob['id'] ?>">→ Открыть</a>
            </div>
        <?php elseif ($canStart): ?>
            <?php
            // Текст для confirm()
            $modeLabel  = $useSandbox ? '🟡 SANDBOX (без денег)' : '🔴 PROD — РЕАЛЬНЫЕ ДЕНЬГИ';
            $confirmText = "Запустить перевыставление?\n\n";
            $confirmText .= "Старый домен: " . $site['current_domain'] . "\n";
            $confirmText .= "Новый по маске: " . $nextDomain . "\n";
            $confirmText .= "DNS A-запись: " . ($dnsTargetIp ?: 'НЕ ОПРЕДЕЛЁН') . "\n";
            $confirmText .= "Режим: " . $modeLabel . "\n\n";
            if (!$useSandbox) {
                $confirmText .= "⚠️ В Namecheap будет потрачено до \$" . config('namecheap.max_price_usd', 10) . " на домен.\n\n";
            }
            $confirmText .= "Панель обработает джобу в течение минуты.";
            ?>
            <div style="margin-top: 12px; padding: 8px 12px; background: var(--bg-elevated); border-radius: 4px; font-size: 0.9em;">
                <span class="muted">Режим:</span>
                <?php if ($useSandbox): ?>
                    <span style="color: var(--warning);"><b>🟡 SANDBOX</b></span>
                    <span class="muted">— тестовая покупка без денег</span>
                <?php else: ?>
                    <span style="color: var(--danger);"><b>🔴 PROD</b></span>
                    <span class="muted">— реальные деньги</span>
                <?php endif; ?>
                ·
                <span class="muted">DNS на:</span>
                <code><?= htmlspecialchars($dnsTargetIp ?: '— не определён —') ?></code>
                ·
                <a href="/settings" class="muted">изменить</a>
            </div>
            <form method="post" action="/jobs/start"
                  onsubmit="return confirm(<?= json_encode($confirmText, JSON_UNESCAPED_UNICODE) ?>);"
                  style="margin-top: 12px;">
                <input type="hidden" name="site_id" value="<?= (int)$site['id'] ?>">

                <!-- v17 / PATCH 048: Webmaster для этой джобы (one-job override) -->
                <?php /* $wmAccts и $siteBinding уже загружены выше (блок «Webmaster сайта») */ ?>
                <?php if (!empty($wmAccts)): ?>
                <div style="margin-bottom: 10px;">
                    <label class="muted small" style="display:block; margin-bottom: 4px;">
                        Webmaster для этой джобы
                    </label>
                    <select name="webmaster_account_override_id" style="padding: 4px 8px;">
                        <option value="0" <?= $siteBinding === 0 ? 'selected' : '' ?>>— Авто: определить по старому домену —</option>
                        <?php foreach ($wmAccts as $acc): ?>
                            <?php
                            // v17.8: показываем заметку (note) если есть, иначе label/email
                            $note = trim((string)($acc['note'] ?? ''));
                            $email = (string)($acc['email'] ?? '');
                            $hostCount = (int)$acc['host_count'];
                            // Русская плюрализация: 1 хост, 2-4 хоста, 5+ хостов (с учётом 11-14)
                            $hcMod10 = $hostCount % 10;
                            $hcMod100 = $hostCount % 100;
                            if ($hcMod100 >= 11 && $hcMod100 <= 14)      $hostWord = 'хостов';
                            elseif ($hcMod10 === 1)                       $hostWord = 'хост';
                            elseif ($hcMod10 >= 2 && $hcMod10 <= 4)       $hostWord = 'хоста';
                            else                                          $hostWord = 'хостов';
                            $isBinding = ($siteBinding === (int)$acc['id']);
                            ?>
                            <option value="<?= (int)$acc['id'] ?>" <?= $isBinding ? 'selected' : '' ?>>
                                #<?= (int)$acc['id'] ?> ·
                                <?php if ($note !== ''): ?>
                                    <?= htmlspecialchars($note) ?> · <?= htmlspecialchars($email) ?>
                                <?php else: ?>
                                    <?= htmlspecialchars($email) ?>
                                <?php endif; ?>
                                (<?= $hostCount ?> <?= $hostWord ?>)<?= $isBinding ? ' [привязка сайта]' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <span class="muted small" style="display:block; margin-top: 2px;">
                        Выбор здесь действует <strong>только для этой джобы</strong>. Чтобы изменить постоянную
                        привязку сайта — используйте «🌐 Webmaster сайта» выше.
                        Если выбран аккаунт — старый домен удалится со старого аккаунта, новый добавится в выбранный.
                    </span>
                </div>
                <?php endif; ?>

                <?php /* v18-fix: опциональный отложенный старт (Europe/Moscow) */ ?>
                <?php
                $nowMsk = (new \DateTime('now', new \DateTimeZone('Europe/Moscow')))->format('Y-m-d H:i');
                ?>
                <div style="margin-bottom: 10px; padding: 10px; background: rgba(255,255,255,0.03); border-radius: 6px;">
                    <label style="cursor:pointer; user-select:none;">
                        <input type="checkbox"
                               id="schedule_toggle_<?= (int)$site['id'] ?>"
                               onchange="document.getElementById('schedule_input_<?= (int)$site['id'] ?>').style.display = this.checked ? 'block' : 'none'; if(!this.checked){document.getElementById('schedule_at_<?= (int)$site['id'] ?>').value='';}"
                               style="margin-right: 6px;">
                        <span class="muted">⏰ Запланировать на время</span>
                    </label>
                    <div id="schedule_input_<?= (int)$site['id'] ?>" style="display:none; margin-top: 8px;">
                        <input type="datetime-local"
                               id="schedule_at_<?= (int)$site['id'] ?>"
                               name="schedule_at"
                               style="padding: 4px 8px; font-size: 14px;">
                        <span style="margin-left: 6px; padding: 2px 8px; background: rgba(58, 123, 213, 0.2); color:#3a7bd5; border-radius: 10px; font-size: 0.85em;">МСК</span>
                        <small class="muted" style="display:block; margin-top: 4px;">
                            Время указывается в Москве (Europe/Moscow). Панель запустит джобу
                            когда наступит указанный момент (с задержкой ≤1 мин). Сейчас в Москве:
                            <code><?= $nowMsk ?></code>
                        </small>
                    </div>
                </div>

                <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:4px;">
                    <button type="submit" name="mode" value="refresh"
                            class="btn btn-primary"
                            title="Перевыставление: покупаем новый домен, добавляем как алиас, переносим SEO через индексацию + редирект на партнёрку">
                        🔄 Перевыставить
                    </button>
                    <button type="submit" name="mode" value="move_indexed"
                            class="btn"
                            style="background:#3a7bd5; color:#fff;"
                            title="Переезд с индексацией: сначала индексируем новый, потом ставим 301 в .htaccess и подаём заявку через Webmaster">
                        🚚 Переезд (с индексацией)
                    </button>
                    <button type="submit" name="mode" value="move_simple"
                            class="btn"
                            style="background:#5a4fcf; color:#fff;"
                            title="Переезд без ожидания индексации: после wm_verified сразу 301 в .htaccess и заявка через Webmaster">
                        🚚 Переезд (без индексации)
                    </button>
                </div>
            </form>
            <details style="margin-top: 8px;">
                <summary class="muted small" style="cursor: pointer;">
                    ℹ️ Чем отличаются режимы?
                </summary>
                <div class="muted small" style="margin-top: 6px; padding: 8px; background: rgba(255,255,255,0.03); border-radius: 6px; line-height: 1.5;">
                    <b>🔄 Перевыставление</b> — классический режим. Покупаем новый домен → SSL →
                    замены в config.php → ждём индексации → включаем партнёрский редирект
                    через <code>$redirect_enabled=1</code> → шлём в TG список URL'ов старого
                    домена для ручной отправки в «Удаление страниц из поиска» Webmaster.
                    Старый домен остаётся как алиас, но через time выпадет из поиска.
                    <br><br>
                    <b>🚚 Переезд (с индексацией)</b> — для случаев когда хотим передать SEO с
                    одного домена на другой. Идём по основному процессу до конца индексации,
                    потом добавляем 301-редирект в <code>.htaccess</code> со старого домена на
                    новый и просим оператора подать заявку «Переезд сайта» в Webmaster.
                    Панель отслеживает, когда Яндекс обработает заявку (склейка зеркал сменится).
                    Старый домен НЕ удаляется ни откуда — он становится зеркалом нового.
                    <br><br>
                    <b>🚚 Переезд (без индексации)</b> — то же самое, но пропускаем sitemap,
                    recrawl и ожидание индексации. Полезно если новый сайт идентичен старому
                    и нет смысла ждать переиндексации — сразу подаём заявку и редиректим.
                    Партнёрский редирект через config.php в move-режимах НЕ включается.
                </div>
            </details>
        <?php else: ?>
            <p class="muted small">
                <?php if (empty($config)): ?>
                    Сначала синхронизируйте <code>config.php</code> — нужно знать <code>internal_reg_url</code>
                    для извлечения sub_id.
                <?php else: ?>
                    Запуск перевыставления будет доступен после синхронизации.
                <?php endif; ?>
            </p>
        <?php endif; ?>
    </section>
</div>

<section class="card">
    <h2>📄 Распознанные поля config.php</h2>
    <?php if (empty($config)): ?>
        <p class="muted">
            Конфиг ещё не синхронизирован.
            <?php if (empty($site['ftp_user'])): ?>
                Варианты:
            <?php else: ?>
                Нажмите <b>"Синхронизировать config.php"</b> чтобы прочитать его сейчас.
            <?php endif; ?>
        </p>
        <?php if (empty($site['ftp_user'])): ?>
            <ol class="muted" style="line-height: 1.7;">
                <li>Нажмите <b>"Создать FTP"</b> в шапке (создаст FTP через API FastPanel).</li>
                <li>Если FastPanel не даёт создать FTP — откройте <b>"Редактировать"</b>, введите данные уже созданного FTP-аккаунта руками, сохраните, потом нажмите <b>"Синхронизировать config.php"</b>.</li>
            </ol>
        <?php endif; ?>
    <?php else: ?>
        <table class="hub-table hub-table--kv">
            <?php foreach ($config as $k => $v): ?>
                <tr>
                    <th><?= htmlspecialchars((string)$k) ?></th>
                    <td><code><?= htmlspecialchars(is_string($v) ? mb_substr($v, 0, 200) : (string)$v) ?></code></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <?php if (!empty($site['config_remote_path'])): ?>
            <p class="muted small">Путь на VPS: <code><?= htmlspecialchars($site['config_remote_path']) ?></code></p>
        <?php endif; ?>
        <?php if (!empty($site['config_template_kind'])): ?>
            <p class="muted small">Шаблон: <code><?= htmlspecialchars($site['config_template_kind']) ?></code></p>
        <?php endif; ?>
    <?php endif; ?>
</section>

<section class="card">
    <h2>🌐 Алиасы (<?= count($aliases) ?>)</h2>
    <?php if (empty($aliases)): ?>
        <p class="muted">Нет.</p>
    <?php else: ?>
        <ul class="alias-list">
            <?php foreach ($aliases as $i => $a): ?>
                <li>
                    <code><?= htmlspecialchars((string)$a) ?></code>
                    <?php if ($i === count($aliases) - 1): ?>
                        <span class="pill pill-ok">last</span>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>

<!-- v17: Webmaster привязки сайта -->
<?php
$wmLinks = [];
try {
    $stWmL = DB::pdo()->prepare(
        "SELECT swl.*, ywa.label AS account_label, ywa.email AS account_email
         FROM site_webmaster_links swl
         LEFT JOIN yandex_webmaster_accounts ywa ON ywa.id = swl.webmaster_account_id
         WHERE swl.site_id = ?
         ORDER BY swl.removed_at IS NULL DESC, swl.updated_at DESC"
    );
    $stWmL->execute([(int)$site['id']]);
    $wmLinks = $stWmL->fetchAll();
} catch (\Throwable $e) {}
?>
<?php if (!empty($wmLinks)): ?>
<section class="card">
    <h2>🔍 Привязки в Yandex.Webmaster</h2>
    <table class="hub-table" style="width: 100%; font-size: 0.92em;">
        <thead>
            <tr>
                <th>Домен</th>
                <th>Аккаунт</th>
                <th>host_id</th>
                <th>Verified</th>
                <th>Sitemap</th>
                <th>Recrawl</th>
                <th>Indexed</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($wmLinks as $link): ?>
            <tr<?= !empty($link['removed_at']) ? ' style="opacity: 0.5;"' : '' ?>>
                <td><code><?= htmlspecialchars((string)$link['domain']) ?></code></td>
                <td>
                    <?php if (!empty($link['account_label'])): ?>
                        <?= htmlspecialchars((string)$link['account_label']) ?>
                    <?php else: ?>
                        <code>#<?= (int)$link['webmaster_account_id'] ?></code>
                    <?php endif; ?>
                </td>
                <td><code style="font-size:0.85em;"><?= htmlspecialchars((string)$link['host_id'] ?: '—') ?></code></td>
                <td><?= (int)$link['verified'] === 1 ? '✓' : '—' ?></td>
                <td><?= (int)$link['sitemap_added'] === 1 ? '✓' : '—' ?></td>
                <td><?= (int)$link['recrawl_requested'] === 1 ? '✓' : '—' ?></td>
                <td>
                    <?php if ((int)$link['indexed'] === 1): ?>
                        ✓ <small><?= (int)$link['indexed_pages_count'] ?>p</small>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (!empty($link['removed_at'])): ?>
                        <span style="color: var(--text-muted);">🗑 Удалён <?= htmlspecialchars(Time::msk((string)$link['removed_at'])) ?></span>
                    <?php else: ?>
                        <span style="color: var(--success);">Активен</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>
<?php endif; ?>

<!-- v17.2: Redirect kill switch — посайтовый toggle (дёргает FTP сразу) -->
<section class="card">
    <h2>🔄 Редирект на сайте</h2>
    <?php
    $redirectEnabled = (int)($site['redirect_enabled'] ?? 1) === 1;
    $hasToggleState = !empty($site['redirect_toggle_state_json']);
    ?>
    <?php if ($redirectEnabled): ?>
        <p>
            <span style="display:inline-block; width:12px; height:12px; border-radius:50%; background:var(--success); vertical-align:middle;"></span>
            <b>Включён</b> — редирект на сайте работает.
        </p>
        <p class="muted small">
            При нажатии «Выключить» — система зайдёт по FTP, отключит редирект-правила в
            <code>.htaccess</code> / <code>config.php</code> на сайте, сделает резервную копию.
            Также стадия <code>redirect_enable</code> в будущих джобах будет пропускаться.
        </p>
        <form method="post" action="/sites/toggle-redirect-enabled" style="margin-top: 10px;"
              onsubmit="return confirm('Выключить редирект на сайте СЕЙЧАС?\n\nСистема зайдёт по FTP и отключит редирект-правила в .htaccess / config.php. Будет сделан snapshot для возможности отката. Также стадия redirect_enable в будущих джобах будет пропускаться.');">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <button type="submit" class="btn btn-warning">🔴 Выключить редирект сейчас</button>
        </form>
    <?php else: ?>
        <p>
            <span style="display:inline-block; width:12px; height:12px; border-radius:50%; background:var(--danger); vertical-align:middle;"></span>
            <b>Выключен</b> — редирект на сайте отключён.
        </p>
        <?php if ($hasToggleState): ?>
            <?php
            $toggleStateData = json_decode((string)$site['redirect_toggle_state_json'], true) ?: [];
            $disabledAt = (string)($toggleStateData['disabled_at'] ?? '');
            $appliedRules = $toggleStateData['disabled_state']['applied_rules'] ?? [];
            ?>
            <p class="muted small">
                Выключен через UI <?= htmlspecialchars($disabledAt) ?>.
                Применено правил: <?= count($appliedRules) ?>.
                При нажатии «Включить» — система восстановит из резервной копии.
            </p>
        <?php else: ?>
            <p class="muted small">
                <strong>State не сохранён</strong> (выключен до v17.2 или вручную).
                При нажатии «Включить» — флаг встанет в 1, но FTP не дёргается. Если на сайте
                редирект сейчас выключен — поправь руками или запусти джобу.
            </p>
        <?php endif; ?>
        <form method="post" action="/sites/toggle-redirect-enabled" style="margin-top: 10px;"
              onsubmit="return confirm('Включить редирект на сайте обратно?<?= $hasToggleState ? '\\n\\nСистема зайдёт по FTP и восстановит редирект-правила из snapshot.' : '\\n\\n⚠ State не сохранён — будет установлен только флаг в БД, FTP не дёргается.' ?>');">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <button type="submit" class="btn btn-success">✅ Включить редирект обратно</button>
        </form>
    <?php endif; ?>
</section>

<!-- v18.1: Let's Encrypt SSL — опциональный выпуск -->
<section class="card">
    <h2>🔒 Let's Encrypt SSL</h2>
    <?php $sslLeEnabled = (int)($site['ssl_le_enabled'] ?? 0) === 1; ?>

    <details class="technical-details" style="margin-bottom: 12px;">
        <summary style="cursor: pointer; color: var(--text-muted); font-size: 0.9em;">
            ℹ️ Зачем эта галка
        </summary>
        <div style="margin-top: 10px; padding: 10px 14px; background: var(--bg-elevated); border-radius: 4px;">
            <p>В пайплайне refresh/move есть стадия <code>ssl_le_polling</code> которая пытается
            выпустить Let's Encrypt сертификат через FastPanel API после замены домена.
            Это занимает <b>1-3 минуты</b> polling'а и не всегда нужно.</p>
            <p>Для большинства сайтов за <b>DDoS-Guard</b> в качестве origin'а — самоподписной
            сертификат от FastPanel <b>достаточен</b> (DDoS-Guard сам терминирует SSL для посетителей,
            origin сервер ему может отдавать любой self-signed).</p>
            <p><b>Когда включать:</b> если домен ходит без CDN/proxy, сертификат должен быть валидным
            прямо на сервере — браузер должен ему доверять.</p>
            <p><b>Default = выключено.</b> Включай для конкретных сайтов где это нужно.</p>
        </div>
    </details>

    <?php if ($sslLeEnabled): ?>
        <p>
            <span style="display:inline-block; width:12px; height:12px; border-radius:50%; background:var(--success); vertical-align:middle;"></span>
            <b>Включён</b> — после проверки изменений панель автоматически выпустит доверенный сертификат.
        </p>
        <p class="muted small">
            После замены домена панель дойдёт до этапа выпуска сертификата и будет
            poll'ить FastPanel API ~1-3 минуты до выпуска сертификата.
        </p>
        <form method="post" action="/sites/toggle-ssl-le-enabled" style="margin-top: 10px;"
              onsubmit="return confirm('Выключить выпуск Let&apos;s Encrypt для этого сайта?\n\nАвтоматический выпуск доверенного сертификата будет отключён для будущих джоб. Текущий сертификат останется прежним.');">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <button type="submit" class="btn btn-warning">🔓 Выключить LE для этого сайта</button>
        </form>
    <?php else: ?>
        <p>
            <span style="display:inline-block; width:12px; height:12px; border-radius:50%; background:var(--text-muted); vertical-align:middle;"></span>
            <b>Выключен</b> — джоба пропустит этап выпуска сертификата.
        </p>
        <p class="muted small">
            Используется только самоподписной сертификат от FastPanel (создаётся в
            временный самоподписанный сертификат). Этого достаточно для DDoS-Guard origin.
        </p>
        <form method="post" action="/sites/toggle-ssl-le-enabled" style="margin-top: 10px;"
              onsubmit="return confirm('Включить выпуск Let&apos;s Encrypt для этого сайта?\n\nВ следующих джобах после проверки изменений панель автоматически выпустит доверенный сертификат. Это добавит 1-3 минуты.');">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <button type="submit" class="btn btn-success">🔒 Включить LE для этого сайта</button>
        </form>
    <?php endif; ?>
</section>

<!-- v18.1.2: Autopatch robots.php — автоматическая правка некорректного шаблона -->
<section class="card">
    <h2>🤖 Autopatch robots.php</h2>
    <?php
    // v18.1.2: default = 1 (включено по умолчанию для всех сайтов).
    // Если миграция 014 не применена — колонки нет, ?? 1 даст значение по умолчанию.
    $autopatchValue = $site['autopatch_robots_php'] ?? 1;
    $autopatchEnabled = (int)$autopatchValue === 1;
    ?>

    <details class="technical-details" style="margin-bottom: 12px;">
        <summary style="cursor: pointer; color: var(--text-muted); font-size: 0.9em;">
            ℹ️ Что это и зачем
        </summary>
        <div style="margin-top: 10px; padding: 10px 14px; background: var(--bg-elevated); border-radius: 4px;">
            <p>На стадии <code>verify_replacement</code> панель проверяет файл <code>robots.php</code>
            на наличие <b>sameHost-защиты</b>: проверка <code>$_SERVER['HTTP_HOST']</code> против
            <code>$domain</code> из config.php. Если её нет — старые домены (алиасы FastPanel)
            будут продолжать индексироваться поисковиком, что плохо для SEO.</p>

            <p><b>Если файл некорректный:</b></p>
            <ul>
                <li><b>Autopatch включён</b> (default) — система <b>сама</b> через FTP перезаписывает
                <code>robots.php</code> рекомендуемым шаблоном (с проверкой домена) и продолжает переезд
                без вмешательства оператора.</li>
                <li><b>Autopatch выключен</b> — джоба ждёт действия оператора,
                оператор смотрит рекомендуемый шаблон в карточке джобы и копирует его руками.</li>
            </ul>

            <p><b>Когда выключать:</b> если у тебя в robots.php кастомная логика
            (например блокировка отдельных user-agent'ов, специальные allow/disallow для разделов сайта)
            которую autopatch затрёт. В этом случае правь файл руками.</p>

            <p><b>Default = включено</b> для всех сайтов. Большинство шаблонов простые
            (1win-стиль) — autopatch экономит время оператора.</p>
        </div>
    </details>

    <?php if ($autopatchEnabled): ?>
        <p>
            <span style="display:inline-block; width:12px; height:12px; border-radius:50%; background:var(--success); vertical-align:middle;"></span>
            <b>Включён</b> (default) — система автоматически перепишет <code>robots.php</code> если он некорректный.
        </p>
        <p class="muted small">
            При проверке внесённых изменений, если файл robots.php некорректен, он будет перезаписан рекомендуемым шаблоном через FTP, без вмешательства оператора.
            Факт перезаписи будет в логе джобы.
        </p>
        <form method="post" action="/sites/toggle-autopatch-robots" style="margin-top: 10px;"
              onsubmit="return confirm('Выключить autopatch robots.php для этого сайта?\n\nЭто нужно если у тебя в robots.php кастомная логика которую нельзя терять. После выключения, если автоматическая проверка robots.php не пройдёт, панель остановится и попросит решение.');">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <button type="submit" class="btn btn-warning">🔓 Выключить autopatch для этого сайта</button>
        </form>
    <?php else: ?>
        <p>
            <span style="display:inline-block; width:12px; height:12px; border-radius:50%; background:var(--text-muted); vertical-align:middle;"></span>
            <b>Выключен</b> — при некорректном <code>robots.php</code> джоба будет ждать действия оператора.
        </p>
        <p class="muted small">
            Оператор увидит подробную диагностику и рекомендуемый код в карточке джобы,
            и сам решит править файл или скипнуть проверку. Подходит для сайтов с
            кастомной логикой в robots.php которую нельзя терять.
        </p>
        <form method="post" action="/sites/toggle-autopatch-robots" style="margin-top: 10px;"
              onsubmit="return confirm('Включить autopatch robots.php обратно (default)?\n\nЕсли автоматическая проверка robots.php не пройдёт, панель сама перезапишет файл рекомендуемым шаблоном. Пользовательская логика в файле будет потеряна.');">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <button type="submit" class="btn btn-success">🤖 Включить autopatch обратно</button>
        </form>
    <?php endif; ?>
</section>

<!-- v17.10 + ТЗ 039 §10: Рандомизация классов — статус применимости, режим, кастомный path -->
<section class="card">
    <h2 id="uc-randomization">🎲 Рандомизация классов</h2>
    <?php
    $updateClassesUrl = trim((string)($site['update_classes_url'] ?? ''));
    // ТЗ 039 §10: человекочитаемый статус применимости.
    $ucMode = (string)($site['uc_mode'] ?? 'auto');
    $ucCap = (string)($site['uc_capability'] ?? 'unknown');
    $ucDetectedAt = trim((string)($site['uc_detected_at'] ?? ''));
    $ucDetJson = (string)($site['uc_detection_json'] ?? '');
    if ($ucMode === 'disabled') {
        $ucStatusText = 'не используется (отключена оператором)'; $ucStatusClass = 'muted';
    } elseif ($ucMode === 'custom') {
        $ucStatusText = 'используется (кастомный адрес)'; $ucStatusClass = '';
    } elseif (in_array($ucCap, ['variant_refresh', 'update_classes'], true)) {
        $ucStatusText = 'используется'; $ucStatusClass = '';
    } elseif ($ucCap === 'confirmed_absent') {
        $ucStatusText = 'не используется'; $ucStatusClass = 'muted';
    } elseif ($ucCap === 'unknown') {
        $ucStatusText = 'ещё не проверялась'; $ucStatusClass = 'muted';
    } else {
        $ucStatusText = 'требует проверки'; $ucStatusClass = '';
    }
    $ucMech = class_exists('SiteRandomizationInspector')
        ? SiteRandomizationInspector::mechanismLabel($ucMode === 'custom' ? 'custom' : $ucCap)
        : $ucCap;
    ?>
    <table class="kv-table" style="width:100%; margin-bottom: 10px;">
        <tr><td style="width:220px;">Рандомизация классов</td>
            <td class="<?= $ucStatusClass ?>"><b><?= htmlspecialchars($ucStatusText) ?></b></td></tr>
        <tr><td>Последняя проверка</td>
            <td><?= $ucDetectedAt !== '' ? htmlspecialchars(Time::msk($ucDetectedAt, 'd.m.Y H:i')) : 'ещё не выполнялась' ?></td></tr>
        <tr><td>Найденный механизм</td>
            <td><?= htmlspecialchars($ucMech) ?></td></tr>
    </table>
    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center; margin-bottom: 12px;">
        <form method="post" action="/sites/check-randomization" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <button type="submit" class="btn btn-primary">🔎 Проверить рандомизацию</button>
        </form>
        <?php if ($ucMode === 'disabled'): ?>
        <form method="post" action="/sites/set-uc-mode" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <input type="hidden" name="uc_mode" value="auto">
            <button type="submit" class="btn btn-secondary">▶️ Включить обратно (авто)</button>
        </form>
        <?php else: ?>
        <form method="post" action="/sites/set-uc-mode" style="display:inline;"
              onsubmit="var c=(this.comment.value||'').trim(); if(!c){alert('Причина обязательна.');this.comment.focus();return false;} return confirm('Отключить рандомизацию для этого сайта? Все следующие джобы будут пропускать этап.');">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <input type="hidden" name="uc_mode" value="disabled">
            <input type="text" name="comment" placeholder="причина отключения (обязательно)" style="padding:6px 8px; min-width:220px;">
            <button type="submit" class="btn btn-secondary">🚫 Отключить для сайта</button>
        </form>
        <?php endif; ?>
    </div>
    <?php
        // §9 (v5): понятный баннер, когда скрипт найден, но семейство не
        // определено или конфликтует. Raw-коды (needs_review, family_unresolved)
        // НЕ показываем — только человеко-текст и конкретные действия.
        $ucReason = '';
        if ($ucDetJson !== '') { $d = json_decode($ucDetJson, true); if (is_array($d)) $ucReason = (string)($d['reason'] ?? ''); }
        $isUnresolved = ($ucCap === 'needs_review' && strpos($ucReason, 'family_unresolved') !== false);
        $isConflict   = ($ucCap === 'conflict');
    ?>
    <?php if ($isUnresolved): ?>
    <div class="notice notice-warn" style="margin-bottom:12px; padding:12px; border-left:4px solid var(--warn,#e0a800); background:rgba(224,168,0,0.08);">
        <b>Скрипт смены классов найден, но его формат не удалось определить.</b><br>
        Панель не будет запускать его автоматически, чтобы не выполнить смену классов неверно.
        Выберите способ подтверждения результата ниже или отключите рандомизацию для этого сайта.
    </div>
    <?php elseif ($isConflict): ?>
    <div class="notice notice-warn" style="margin-bottom:12px; padding:12px; border-left:4px solid var(--warn,#e0a800); background:rgba(224,168,0,0.08);">
        <b>Панель обнаружила противоречивый формат скрипта.</b><br>
        В каталоге найдены признаки сразу нескольких форматов. Автоматический запуск остановлен —
        уточните настройку или отключите рандомизацию для этого сайта.
    </div>
    <?php endif; ?>
    <?php if ($ucDetJson !== '' || $ucCap !== 'unknown'): ?>
    <details class="technical-details" style="margin-bottom: 12px;">
        <summary class="muted small">Технические детали проверки</summary>
        <table class="kv-table" style="width:100%; margin-top:6px;">
            <tr><td style="width:220px;">Режим (uc_mode)</td><td><code><?= htmlspecialchars($ucMode) ?></code></td></tr>
            <tr><td>Применимость (uc_capability)</td><td><code><?= htmlspecialchars($ucCap) ?></code></td></tr>
            <?php if ($ucDetJson !== ''): ?>
            <tr><td>Детали детекции</td><td><pre style="white-space:pre-wrap; margin:0; font-size:11px;"><?= htmlspecialchars($ucDetJson) ?></pre></td></tr>
            <?php endif; ?>
        </table>
    </details>
    <?php endif; ?>

    <details class="technical-details" style="margin-bottom: 12px;">
        <summary style="cursor: pointer; color: var(--text-muted); font-size: 0.9em;">
            ℹ️ Что делает эта стадия и как работает автодетект
        </summary>
        <div style="margin-top: 10px; padding: 10px 14px; background: var(--bg-elevated); border-radius: 4px;">
            <p class="muted small" style="margin: 0 0 8px 0;">
                Перед добавлением сайта в Яндекс.Вебмастер панель вызывает скрипт рандомизации
                на новом домене (этап «Смена классов сайта»).
                Это нужно чтобы боты Яндекса видели свежие, не повторяющиеся CSS-классы и не
                склеивали сайт с другими шаблонами этой же сетки.
            </p>
            <p class="muted small" style="margin: 0 0 4px 0;">
                Поддерживаются <b>два формата</b> скрипта (определяются автоматически по корню сайта через FTP):
            </p>
            <ul class="muted small" style="margin: 0 0 12px 0; padding-left: 20px;">
                <li><b>Старый:</b> <code>/update_classes.php</code> — без секрета</li>
                <li><b>Новый (enomo v3):</b> <code>/variant-refresh.php?k=SECRET</code> — секрет извлекается из <code>config.php</code> (<code>$variant_settings['manual_secret']</code>) regex-ом</li>
            </ul>

            <p style="margin: 0 0 6px 0;"><b>Логика стадии (приоритет сверху вниз):</b></p>
            <ol class="muted small" style="margin: 0 0 8px 0; padding-left: 20px;">
                <li><b>Кастомный path указан</b> → дёргается <code>https://NEW_DOMAIN&lt;path&gt;</code></li>
                <li>
                    <b>Path пуст → автодетект через FTP:</b>
                    <ul style="margin-top: 2px;">
                        <li>Найден <code>variant-refresh.php</code> → <code>https://NEW_DOMAIN/variant-refresh.php?k=&lt;secret&gt;</code></li>
                        <li>Найден <code>update_classes.php</code> → <code>https://NEW_DOMAIN/update_classes.php</code></li>
                        <li>Если оба — приоритет у <code>variant-refresh.php</code></li>
                    </ul>
                </li>
                <li><b>Ничего не найдено</b> → этап пропускается (переезд продолжается)</li>
            </ol>
            <p class="muted small" style="margin: 0;">
                <b>Когда задавать path вручную:</b> если автодетект не подходит — секрет невозможно
                извлечь, нестандартное имя файла, или скрипт не в корне.
            </p>
        </div>
    </details>

    <?php
        $ucContract = trim((string)($site['uc_verification_contract'] ?? ''));
        $ucMarker   = trim((string)($site['uc_verification_marker'] ?? ''));
    ?>
    <form method="post" action="/sites/save-update-classes-url" id="uc-contract-form">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
        <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
        <label for="update_classes_url">Адрес скрипта <span class="muted small">(опционально, если автодетект не подходит)</span>
            <input type="text" id="update_classes_url" name="update_classes_url"
                   value="<?= htmlspecialchars($updateClassesUrl) ?>"
                   placeholder="/variant-refresh.php?k=..."
                   style="font-family: monospace;">
        </label>
        <p class="muted small" style="margin: 6px 0 12px 0;">
            Адрес начинается со слеша. Домен подставляется автоматически.
            Полный URL будет обрезан до пути. Пустое поле — автоопределение.
        </p>

        <label for="uc_verification_contract">Как подтвердить результат
            <select id="uc_verification_contract" name="uc_verification_contract" required>
                <option value="" <?= $ucContract === '' ? 'selected' : '' ?>>Выберите способ</option>
                <option value="json_ok_true" <?= $ucContract === 'json_ok_true' ? 'selected' : '' ?>>
                    Скрипт возвращает JSON с {"ok":true}
                </option>
                <option value="exact_marker" <?= $ucContract === 'exact_marker' ? 'selected' : '' ?>>
                    Скрипт возвращает точную контрольную строку
                </option>
                <option value="ftp_profile" <?= $ucContract === 'ftp_profile' ? 'selected' : '' ?>>
                    Проверить изменение файлов по FTP
                </option>
            </select>
        </label>
        <div class="muted small" style="margin: 6px 0 12px 0; line-height: 1.5;">
            <p style="margin:0 0 4px 0;"><b>JSON {"ok":true}</b> — выберите, если скрипт возвращает
                ответ вида <code>{"ok":true}</code>. Значения <code>1</code>, <code>"true"</code>
                и <code>status:"ok"</code> подтверждением не считаются.</p>
            <p style="margin:0 0 4px 0;"><b>Точная строка</b> — панель признаёт успех только при наличии
                указанной точной строки в ответе. Регулярные выражения и общий список строк не используются.</p>
            <p style="margin:0;"><b>По файлам (FTP)</b> — до запуска панель сохранит состояние
                проверяемых файлов, после запуска перечитает их и подтвердит изменение. Если проверку
                построить нельзя, скрипт не будет вызван.</p>
        </div>

        <div data-contract-panel="exact_marker" <?= $ucContract === 'exact_marker' ? '' : 'hidden' ?>>
            <label for="uc_verification_marker">Контрольная строка
                <input type="text" id="uc_verification_marker" name="uc_verification_marker"
                       maxlength="255" value="<?= htmlspecialchars($ucMarker) ?>"
                       placeholder="Например: ROTATED_OK" style="font-family: monospace;"
                       <?= $ucContract === 'exact_marker' ? 'required' : '' ?>>
            </label>
        </div>

        <div style="margin-top:12px;">
            <button type="submit" class="btn btn-primary">💾 Сохранить</button>
        </div>
    </form>
    <?php if ($updateClassesUrl !== ''): ?>
        <form method="post" action="/sites/save-update-classes-url" style="margin-top:8px;">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
            <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
            <input type="hidden" name="update_classes_url" value="">
            <input type="hidden" name="uc_verification_contract" value="json_ok_true">
            <button type="submit" class="btn btn-secondary"
                    onclick="return confirm('Очистить адрес скрипта? При следующей джобе будет автоопределение через FTP.');">
                🗑 Очистить
            </button>
        </form>
    <?php endif; ?>
    <script>
    (function(){
        var form = document.getElementById('uc-contract-form');
        if (!form) return;
        var sel = form.querySelector('#uc_verification_contract');
        var panel = form.querySelector('[data-contract-panel="exact_marker"]');
        var marker = form.querySelector('#uc_verification_marker');
        function sync(){
            var isExact = sel.value === 'exact_marker';
            if (isExact) { panel.removeAttribute('hidden'); marker.setAttribute('required','required'); }
            else { panel.setAttribute('hidden','hidden'); marker.removeAttribute('required'); marker.value=''; }
        }
        sel.addEventListener('change', sync);
        form.addEventListener('submit', function(e){
            // §7.3: пустой контракт блокирует отправку (серверная проверка всё равно обязательна)
            if (!sel.value) { e.preventDefault(); alert('Выберите способ подтверждения результата.'); }
        });
        sync();
    })();
    </script>

    <?php if ($updateClassesUrl !== ''): ?>
        <p class="muted small" style="margin-top: 10px;">
            <b>Превью при следующей джобе</b> (когда new_domain будет известен): <br>
            <code>https://&lt;NEW_DOMAIN&gt;<?= htmlspecialchars($updateClassesUrl) ?></code>
        </p>
    <?php endif; ?>
</section>

<!-- §7.3.1 (v4): Мультисайт — человекочитаемый блок -->
<section class="card" style="margin-top: 20px;">
    <h2>🌐 Мультисайт</h2>
    <?php
        $ucSubroot = trim((string)($site['uc_site_subroot'] ?? ''));
        $autoSub = null;
        try { $autoSub = (new \SitesController())->detectMultisiteSubroot((int)$site['id']); } catch (\Throwable $e) {}
    ?>
    <p class="muted small">
        Укажите внутренний каталог только тогда, когда несколько сайтов используют
        общий корень. Например: <code>sites/_main</code>. Если панель не сможет точно
        определить каталог, она не будет запускать смену классов и попросит решение.
    </p>
    <?php if ($autoSub !== null): ?>
        <p class="small" style="margin:8px 0;">
            🔎 Панель предлагает каталог <b><code><?= htmlspecialchars((string)$autoSub['base']) ?></code></b>
            (определён по домену). Подтвердите или исправьте ниже.
        </p>
    <?php else: ?>
        <p class="small muted" style="margin:8px 0;">Автоматически определить каталог не удалось — при необходимости укажите его вручную.</p>
    <?php endif; ?>
    <form method="post" action="/sites/save-multisite-subroot">
        <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
        <label for="uc_site_subroot"><b>Каталог проекта внутри мультисайта</b></label><br>
        <input type="text" id="uc_site_subroot" name="uc_site_subroot" style="width: 320px;"
               value="<?= htmlspecialchars($ucSubroot ?: (string)($autoSub['base'] ?? '')) ?>"
               placeholder="Например: sites/_main">
        <p class="help muted small">Оставьте пустым для обычного сайта.</p>
        <button type="submit" class="btn btn-primary">💾 Сохранить</button>
        <button type="submit" name="uc_site_subroot" value="" class="btn btn-secondary"
                onclick="return confirm('Очистить каталог? Панель попробует определить его автоматически.');">
            🗑 Очистить
        </button>
    </form>
    <?php if ($ucSubroot !== ''): ?>
        <p class="small" style="margin-top:8px;">Текущий каталог: <code><?= htmlspecialchars($ucSubroot) ?></code></p>
    <?php endif; ?>
    <details class="technical-details" style="margin-top:10px;">
        <summary>Технические детали</summary>
        <div class="muted small">
            Поле БД: <code>uc_site_subroot</code><br>
            <?php if ($autoSub !== null): ?>
                Источник определения: <code>sites/_hostmap.php</code> по домену <code><?= htmlspecialchars((string)$autoSub['host']) ?></code><br>
                Physical root: <code><?= htmlspecialchars((string)($autoSub['base'] ?? '')) ?></code><br>
            <?php endif; ?>
            При неоднозначном или неподтверждённом каталоге запуск скрипта блокируется
            (fail-closed): смена классов не выполняется, джоба ждёт решения оператора.
        </div>
    </details>
</section>

<section class="card">
    <h2>📜 История джоб перевыставления</h2>
    <?php if (empty($jobs)): ?>
        <p class="muted">Пока нет.</p>
    <?php else: ?>
        <table class="hub-table">
            <thead><tr><th>#</th><th>Старый</th><th>Новый</th><th>Стадия</th><th>Статус</th><th>Создана</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($jobs as $j): ?>
                <tr>
                    <td>#<?= (int)$j['id'] ?></td>
                    <td><?= htmlspecialchars($j['old_domain']) ?></td>
                    <td><?= htmlspecialchars($j['new_domain']) ?></td>
                    <td><?= htmlspecialchars(JobEventPresenter::stageLabel((string)$j['stage'])) ?></td>
                    <td><span class="pill pill-<?= htmlspecialchars($j['stage_status']) ?>"><?= htmlspecialchars(JobEventPresenter::statusLabel((string)$j['stage_status'])) ?></span></td>
                    <td class="muted small"><?= htmlspecialchars(Time::msk((string)$j['created_at'])) ?></td>
                    <td><a href="/jobs/show?id=<?= (int)$j['id'] ?>" class="btn btn-secondary">Открыть</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>

<section class="card">
    <h2>⚙️ Опасная зона</h2>
    <form method="post" action="/sites/delete" onsubmit="return confirm('Удалить сайт из панели? Сам сайт на VPS не пострадает.');">
        <input type="hidden" name="id" value="<?= (int)$site['id'] ?>">
        <button type="submit" class="btn btn-danger">Удалить из панели</button>
    </form>
</section>
