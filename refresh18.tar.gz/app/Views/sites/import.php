<h1 class="page-title">Поиск и добавление сайта с FastPanel</h1>

<?php if (empty($servers)): ?>
    <div class="hub-flash hub-flash--warning">
        Сначала добавьте сервер FastPanel: <a href="/servers/create">Добавить сервер</a>
    </div>
<?php else: ?>

<form method="get" action="/sites/import" class="form-card form-card--inline">
    <div class="form-row" style="gap:12px; flex-wrap:wrap; align-items:flex-end;">
        <label style="flex:0 0 240px; margin:0;">Сервер
            <select name="server_id" onchange="this.form.submit()">
                <?php foreach ($servers as $s): ?>
                    <option value="<?= (int)$s['id'] ?>" <?= (int)$s['id'] === $serverId ? 'selected' : '' ?>>
                        <?php $bc040 = trim((string)($s['ui_badge_code'] ?? '')); ?><?= $bc040 !== '' ? htmlspecialchars($bc040) . ' · ' : '' ?><?= htmlspecialchars($s['title']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <label style="flex:1; margin:0; min-width:240px;">Поиск по домену или владельцу
            <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="например: 7k-200 или irwincasino" autofocus>
        </label>
        <button type="submit" class="btn btn-primary">Найти</button>
    </div>
</form>

<?php if ($error): ?>
    <div class="hub-flash hub-flash--error">
        Ошибка обращения к FastPanel: <code><?= htmlspecialchars($error) ?></code>
    </div>
<?php endif; ?>

<?php if ($cacheInfo && $cacheInfo['count'] > 0): ?>
    <div class="cache-info">
        <span class="muted small">
            В кеше сервера: <b><?= (int)$cacheInfo['count'] ?></b> сайтов.
            Обновлено: <?= htmlspecialchars(Time::msk((string)$cacheInfo['last_at'], 'Y-m-d H:i:s')) ?>.
        </span>
        <form method="post" action="/sites/import/refresh-cache" style="display:inline">
            <input type="hidden" name="server_id" value="<?= $serverId ?>">
            <button type="submit" class="btn btn-sm btn-secondary">Обновить кеш</button>
        </form>
    </div>
<?php endif; ?>

<?php if (!empty($results)): ?>
    <table class="hub-table search-results">
        <thead>
            <tr>
                <th>FP ID</th>
                <th>Основной домен</th>
                <th>Владелец</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($results as $r): ?>
                <tr data-row-fpid="<?= (int)$r['fp_site_id'] ?>">
                    <td><?= (int)$r['fp_site_id'] ?></td>
                    <td>
                        <code><?= htmlspecialchars($r['server_name']) ?></code>
                        <?php /* v18.1.28: отметка что найдено по алиасу */ ?>
                        <?php if (!empty($r['matched_alias'])): ?>
                            <div class="muted small" style="margin-top:4px;">
                                ↳ найдено по алиасу: <code><?= htmlspecialchars($r['matched_alias']) ?></code>
                            </div>
                        <?php endif; ?>
                        <?php /* v18.1.28: все алиасы (компактно, под именем) */ ?>
                        <?php if (!empty($r['aliases'])): ?>
                            <div class="muted small" style="margin-top:2px;">
                                <?php $aliasesShown = array_slice($r['aliases'], 0, 4); ?>
                                алиасы:
                                <?php foreach ($aliasesShown as $i => $a): ?>
                                    <code><?= htmlspecialchars($a) ?></code><?= $i < count($aliasesShown) - 1 ? ',' : '' ?>
                                <?php endforeach; ?>
                                <?php if (count($r['aliases']) > 4): ?>
                                    <span>+<?= count($r['aliases']) - 4 ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <span class="last-alias-line muted small" id="alias-<?= (int)$r['fp_site_id'] ?>"></span>
                    </td>
                    <td class="muted small"><?= htmlspecialchars($r['owner']) ?></td>
                    <td style="text-align:right; white-space:nowrap;">
                        <?php if ($r['already_added']): ?>
                            <a href="/sites/show?id=<?= (int)$r['managed_id'] ?>" class="btn btn-sm btn-secondary">Уже добавлен →</a>
                        <?php else: ?>
                            <button type="button"
                                    class="btn btn-sm btn-secondary"
                                    data-preview-btn="<?= (int)$r['fp_site_id'] ?>">
                                Подробнее
                            </button>
                            <button type="button"
                                    class="btn btn-sm btn-primary"
                                    data-add-btn="<?= (int)$r['fp_site_id'] ?>">
                                Добавить
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php elseif ($serverId > 0 && !$error): ?>
    <div class="empty-state">
        <?php if ($q !== ''): ?>
            <p>Ничего не найдено по запросу <code><?= htmlspecialchars($q) ?></code>.</p>
        <?php else: ?>
            <p>Введите часть домена в поле поиска.</p>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php endif; ?>

<!-- Модалка превью -->
<div id="preview-modal" class="modal-overlay" style="display:none;">
    <div class="modal-card">
        <button type="button" class="modal-close" data-modal-close>&times;</button>
        <h2>Предпросмотр сайта</h2>
        <div id="preview-content">
            <div class="muted">Загрузка...</div>
        </div>
        <div class="modal-actions">
            <button type="button" class="btn btn-secondary" data-modal-close>Отмена</button>
            <form method="post" action="/sites/import/do" id="preview-add-form">
                <input type="hidden" name="server_id" value="<?= $serverId ?>">
                <input type="hidden" name="fp_site_id" id="preview-fp-id" value="">
                <button type="submit" class="btn btn-primary">Добавить</button>
            </form>
        </div>
    </div>
</div>

<form method="post" action="/sites/import/do" id="direct-add-form" style="display:none;">
    <input type="hidden" name="server_id" value="<?= $serverId ?>">
    <input type="hidden" name="fp_site_id" id="direct-fp-id" value="">
</form>

<script>
(function () {
    var serverId = <?= (int)$serverId ?>;
    var aliasCache = {};

    function loadPreview(fpId, callback) {
        if (aliasCache[fpId]) { callback(aliasCache[fpId]); return; }
        fetch('/sites/import/preview?server_id=' + serverId + '&fp_site_id=' + fpId, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (j && j.ok) { aliasCache[fpId] = j.site; callback(j.site); }
                else { callback({ error: (j && j.error) || 'unknown' }); }
            })
            .catch(function (e) { callback({ error: e.message }); });
    }

    function escapeHtml(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) {
            return ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[m];
        });
    }

    function renderPreview(site) {
        if (site.error) {
            return '<div class="hub-flash hub-flash--error">Ошибка: ' + escapeHtml(site.error) + '</div>';
        }
        var aliasesList = (site.aliases || []).map(function (a, i, arr) {
            var isLast = i === arr.length - 1;
            return '<li><code>' + escapeHtml(a) + '</code>' + (isLast ? ' <span class="pill pill-ok">last</span>' : '') + '</li>';
        }).join('');
        if (!aliasesList) aliasesList = '<li class="muted">нет алиасов</li>';
        return '' +
            '<dl class="kv">' +
                '<dt>FP Site ID</dt><dd>' + site.fp_site_id + '</dd>' +
                '<dt>server_name</dt><dd><code>' + escapeHtml(site.server_name) + '</code></dd>' +
                '<dt>Последний алиас</dt><dd>' + (site.last_alias ? '<b>' + escapeHtml(site.last_alias) + '</b>' : '<span class="muted">—</span>') + '</dd>' +
                '<dt>Владелец</dt><dd>' + escapeHtml(site.owner || '—') + '</dd>' +
                '<dt>VPS IP</dt><dd>' + escapeHtml(site.vps_ip || '—') + '</dd>' +
                '<dt>Index dir</dt><dd><code>' + escapeHtml(site.index_dir || '—') + '</code></dd>' +
            '</dl>' +
            '<h3 style="margin-top:16px;">Все алиасы (' + (site.aliases || []).length + ')</h3>' +
            '<ul class="alias-list">' + aliasesList + '</ul>';
    }

    document.querySelectorAll('[data-row-fpid]').forEach(function (row) {
        var fpId = row.getAttribute('data-row-fpid');
        var triggered = false;
        row.addEventListener('mouseenter', function () {
            if (triggered) return;
            triggered = true;
            loadPreview(fpId, function (site) {
                if (site.error) return;
                var span = document.getElementById('alias-' + fpId);
                if (span && site.last_alias) {
                    span.innerHTML = ' → <b>' + escapeHtml(site.last_alias) + '</b>';
                }
            });
        });
    });

    document.querySelectorAll('[data-preview-btn]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var fpId = btn.getAttribute('data-preview-btn');
            var modal = document.getElementById('preview-modal');
            var content = document.getElementById('preview-content');
            document.getElementById('preview-fp-id').value = fpId;
            content.innerHTML = '<div class="muted">Загрузка...</div>';
            modal.style.display = 'flex';
            loadPreview(fpId, function (site) {
                content.innerHTML = renderPreview(site);
            });
        });
    });

    document.querySelectorAll('[data-add-btn]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var fpId = btn.getAttribute('data-add-btn');
            btn.disabled = true;
            btn.textContent = 'Загрузка...';
            loadPreview(fpId, function (site) {
                btn.disabled = false;
                btn.textContent = 'Добавить';
                if (site.error) { alert('Не удалось получить детали: ' + site.error); return; }
                var dom = site.last_alias || site.server_name;
                var msg = 'Добавить сайт ' + dom + '?\n\n' +
                          'server_name: ' + site.server_name + '\n' +
                          (site.last_alias ? 'last alias: ' + site.last_alias + '\n' : '') +
                          'owner: ' + (site.owner || '?') + '\n' +
                          'aliases: ' + (site.aliases || []).length + ' шт.\n\n' +
                          'Будет создан FTP-аккаунт через API FastPanel.';
                if (!confirm(msg)) return;
                document.getElementById('direct-fp-id').value = fpId;
                document.getElementById('direct-add-form').submit();
            });
        });
    });

    document.querySelectorAll('[data-modal-close]').forEach(function (el) {
        el.addEventListener('click', function () {
            document.getElementById('preview-modal').style.display = 'none';
        });
    });
    var modal = document.getElementById('preview-modal');
    if (modal) {
        modal.addEventListener('click', function (ev) {
            if (ev.target === this) this.style.display = 'none';
        });
    }
})();
</script>
