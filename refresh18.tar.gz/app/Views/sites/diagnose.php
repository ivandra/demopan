<h1 class="page-title">
    <a href="/sites/show?id=<?= (int)$site['id'] ?>" class="back-link">← <?= htmlspecialchars($site['current_domain']) ?></a>
    Диагностика
</h1>

<section class="card">
    <h2>📋 Сырая запись из БД</h2>
    <table class="hub-table hub-table--kv">
        <?php foreach (['id','fastpanel_server_id','fp_site_id','fp_site_owner','fp_index_dir','current_domain','vps_ip','ftp_user','ftp_host','config_remote_path','config_template_kind','config_last_synced_at','status','created_at','updated_at'] as $k): ?>
            <tr>
                <th><?= htmlspecialchars($k) ?></th>
                <td>
                    <?php $v = $site[$k] ?? null; ?>
                    <?php if ($v === null || $v === ''): ?>
                        <span class="muted">(пусто)</span>
                    <?php else: ?>
                        <code><?= htmlspecialchars((string)$v) ?></code>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <th>ftp_pass_enc</th>
            <td><?= !empty($site['ftp_pass_enc']) ? '<span class="pill pill-ok">есть (' . strlen($site['ftp_pass_enc']) . ' байт)</span>' : '<span class="muted">(пусто)</span>' ?></td>
        </tr>
    </table>
</section>

<section class="card">
    <h2>📜 Лог импорта</h2>
    <?php if (empty($importLog)): ?>
        <p class="muted">Лог пуст или старый сайт без логирования.</p>
    <?php else: ?>
        <ul class="import-log">
            <?php foreach ($importLog as $entry): ?>
                <li class="import-log-entry import-log-entry--<?= htmlspecialchars($entry['level'] ?? 'info') ?>">
                    <span class="muted small"><?= htmlspecialchars($entry['ts'] ?? '') ?></span>
                    <span class="pill pill-<?= htmlspecialchars($entry['level'] ?? 'info') === 'error' ? 'failed' : (htmlspecialchars($entry['level'] ?? 'info') === 'ok' ? 'ok' : 'info') ?>">
                        <?= htmlspecialchars($entry['level'] ?? 'info') ?>
                    </span>
                    <?= htmlspecialchars($entry['msg'] ?? '') ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>

<section class="card">
    <h2>🔌 Сырой JSON от FastPanel API</h2>
    <?php if (empty($rawJson)): ?>
        <p class="muted">JSON ещё не сохранён. Импортируйте сайт заново.</p>
    <?php else: ?>
        <p class="muted small">Это полный ответ <code>GET /api/sites/<?= (int)$site['fp_site_id'] ?></code> от FastPanel. Используется для диагностики того, какие поля доступны.</p>
        <pre class="raw-json"><?= htmlspecialchars(json_encode($rawJson, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?></pre>
    <?php endif; ?>
</section>
