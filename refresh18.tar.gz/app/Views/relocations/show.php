<?php
/**
 * Карточка переезда: даты, статусы, действия, история XMLStock-проверок
 * и журнал действий оператора.
 */
list($idxLabel, $idxColor) = RelocationService::indexStatusLabel((string)$r['index_status']);
$status = (string)$r['status'];
$jobExists = !empty($r['job_exists']);

// Человекочитаемый русский формат; хранение в БД остаётся UTC.
$fmtMskFullRu = static function (?string $value): string {
    return Time::msk($value, 'd.m.Y H:i:s', true);
};
$fmtMskShortRu = static function (?string $value): string {
    return Time::msk($value, 'd.m.Y H:i', false);
};
?>
<p><a href="/relocations">← Переезды</a></p>

<h1>
    <?php // ТЗ 040 §9.4/§9.6: бейдж из контроллера ($serverBadge).
    if (!empty($serverBadge)) { $badge = $serverBadge; $badgeMode='compact'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; } ?>
    Переезд #<?= (int)$r['id'] ?>
    <span class="muted small"><?= htmlspecialchars((string)$r['mode']) ?></span>
</h1>

<?php if (!$jobExists): ?>
    <div class="notice warn">
        Джоба удалена. Данные переезда взяты из сохранённого snapshot; ссылка на карточку джобы недоступна.
    </div>
<?php endif; ?>

<section class="card">
    <h2>Основное</h2>
    <dl class="kv">
        <dt>Откуда</dt>
        <dd><a href="https://<?= htmlspecialchars((string)$r['old_domain']) ?>" target="_blank" rel="noopener">
            <?= htmlspecialchars((string)$r['old_domain']) ?></a></dd>

        <dt>Куда</dt>
        <dd><a href="https://<?= htmlspecialchars((string)$r['new_domain']) ?>" target="_blank" rel="noopener">
            <?= htmlspecialchars((string)$r['new_domain']) ?></a></dd>

        <dt>Дата старта</dt>
        <dd><?= $r['started_at'] ? htmlspecialchars($fmtMskFullRu((string)$r['started_at'])) : '—' ?>
            <span class="muted small">— момент создания джобы, не меняется</span></dd>

        <dt>Плановая дата</dt>
        <dd><?= htmlspecialchars($fmtMskFullRu((string)$r['planned_at'])) ?></dd>

        <dt>Статус переезда</dt>
        <dd><b><?= htmlspecialchars(RelocationService::statusLabel($status)) ?></b></dd>

        <dt>Задержка</dt>
        <dd><?= htmlspecialchars((string)$r['delay']['text']) ?></dd>

        <?php if (!empty($r['duration'])): ?>
            <dt>Длительность переезда</dt>
            <dd><?= htmlspecialchars((string)$r['duration']) ?>
                <span class="muted small">— от старта до подтверждения зеркала</span></dd>
        <?php endif; ?>

        <dt>Статус индекса</dt>
        <dd><span style="color:<?= $idxColor ?>">●</span> <?= htmlspecialchars($idxLabel) ?>
            <span class="muted small">— источник: XMLStock</span></dd>

        <dt>Замечен в индексе</dt>
        <dd><?= $r['first_indexed_at']
                ? htmlspecialchars($fmtMskFullRu((string)$r['first_indexed_at']))
                : '<span class="muted">—</span>' ?></dd>

        <dt>Фактический переезд</dt>
        <dd><?= $r['move_completed_at']
                ? htmlspecialchars($fmtMskFullRu((string)$r['move_completed_at'])) . ' <span class="muted small">— Яндекс подтвердил смену главного зеркала</span>'
                : '<span class="muted">не подтверждён</span>' ?></dd>

        <dt>Последняя проверка XMLStock</dt>
        <dd><?= $r['index_checked_at'] ? htmlspecialchars($fmtMskFullRu((string)$r['index_checked_at'])) : '<span class="muted">не выполнялась</span>' ?>
            <?php if (!empty($r['index_error'])): ?>
                <br><span class="muted small" style="color:#f0a020"><?= htmlspecialchars((string)$r['index_error']) ?></span>
            <?php endif; ?></dd>

        <?php if ($jobExists): ?>
            <dt>Джоба</dt>
            <dd><a href="/jobs/show?id=<?= (int)$r['job_id'] ?>">#<?= (int)$r['job_id'] ?></a>
                <span class="muted small">стадия <code><?= htmlspecialchars((string)$r['stage']) ?></code>
                / <?= htmlspecialchars((string)$r['stage_status']) ?></span></dd>
            <?php if (!empty($r['site_id'])): ?>
                <dt>Сайт</dt>
                <dd><a href="/sites/show?id=<?= (int)$r['site_id'] ?>">#<?= (int)$r['site_id'] ?></a></dd>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (!empty($r['is_backfilled'])): ?>
            <dt>Историческая запись</dt>
            <dd>восстановлена через backfill
                <?php if (!empty($r['backfill_notes'])): ?>
                    <br><span class="muted small"><?= htmlspecialchars((string)$r['backfill_notes']) ?></span>
                <?php endif; ?></dd>
        <?php endif; ?>

        <?php if (!empty($r['cancelled_at'])): ?>
            <dt>Отменён</dt>
            <dd><?= htmlspecialchars($fmtMskFullRu((string)$r['cancelled_at'])) ?>
                <?php if (!empty($r['cancelled_by'])): ?>
                    <span class="muted small">— <?= htmlspecialchars((string)$r['cancelled_by']) ?></span>
                <?php endif; ?>
                <?php if (!empty($r['comment'])): ?>
                    <br><span class="muted small"><?= htmlspecialchars((string)$r['comment']) ?></span>
                <?php endif; ?></dd>
        <?php endif; ?>
    </dl>
</section>

<section class="card">
    <h2>Действия</h2>

    <form method="post" action="/relocations/planned-at" class="row" style="gap:10px; align-items:flex-end; margin-bottom:14px">
        <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
        <label style="display:flex; flex-direction:column; gap:4px">
            <span class="muted small">Плановая дата и время</span>
            <input type="datetime-local" name="planned_at"
                   value="<?= htmlspecialchars(RelocationService::toMskInput((string)$r['planned_at'])) ?>"
                   required style="padding:6px">
            <span class="muted small">время московское</span>
        </label>
        <button type="submit" class="btn btn-primary">Сохранить срок</button>
        <span class="muted small">дата старта при этом не меняется</span>
    </form>

    <?php
    // H7: кнопка недоступна там, где запрос был бы бессмысленным или вредным.
    $checkBlock = null;
    if (trim((string)$r['new_domain']) === '')      $checkBlock = 'новый домен ещё не зафиксирован';
    elseif (!empty($r['cancelled_at']))             $checkBlock = 'переезд отменён';
    elseif (!empty($r['first_indexed_at']))         $checkBlock = 'домен уже зафиксирован в индексе';
    elseif (!empty($r['stage']) && (string)$r['stage'] === 'final_monitoring'
            && in_array((string)$r['stage_status'], ['pending','ok','running'], true))
                                                    $checkBlock = 'сейчас работает встроенная проверка джобы';
    ?>
    <?php if ($checkBlock === null): ?>
        <form method="post" action="/relocations/check-now" style="margin-bottom:14px">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button type="submit" class="btn">🔍 Проверить индекс сейчас (XMLStock)</button>
            <span class="muted small">
                если проверка уже выполняется для этого домена — второй запрос не отправляется
            </span>
        </form>
    <?php else: ?>
        <p class="muted small" style="margin-bottom:14px">
            🔍 Ручная проверка недоступна: <?= htmlspecialchars($checkBlock) ?>.
        </p>
    <?php endif; ?>

    <?php if (empty($r['cancelled_at']) && empty($r['move_completed_at'])): ?>
        <?php /* v24.2 (B5): cancelled/superseded — тоже терминальные, отмена учёта доступна. */ ?>
        <?php $jobActive = $jobExists
            && !in_array((string)$r['stage'], ['done','failed','cancelled','superseded'], true); ?>
        <details>
            <summary class="muted small" style="cursor:pointer">Отменить учёт переезда</summary>
            <?php if ($jobActive): ?>
                <div class="notice warn" style="margin-top:8px">
                    Джоба #<?= (int)$r['job_id'] ?> ещё активна (стадия <code><?= htmlspecialchars((string)$r['stage']) ?></code>).
                    Отмена учёта недоступна: сначала остановите джобу штатным действием в разделе «Джобы».
                    Отмена записи здесь не останавливает выполнение джобы.
                </div>
            <?php else: ?>
                <form method="post" action="/relocations/cancel" style="margin-top:8px">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <label style="display:block; margin-bottom:8px">
                        <span class="muted small">Причина отмены (обязательно)</span><br>
                        <input type="text" name="comment" required style="width:100%; max-width:520px; padding:6px">
                    </label>
                    <button type="submit" class="btn">Отменить переезд</button>
                    <span class="muted small">джоба при этом не изменяется</span>
                </form>
            <?php endif; ?>
        </details>
    <?php endif; ?>
</section>

<section class="card">
    <h2>История проверок XMLStock</h2>
    <?php if (!$checks): ?>
        <p class="muted small">Проверок ещё не было.</p>
    <?php else: ?>
        <table class="table small" style="width:100%">
            <thead>
                <tr><th>Когда</th><th>Триггер</th><th>Результат</th><th>Страниц</th><th>Ошибка</th><th>Кто</th></tr>
            </thead>
            <tbody>
            <?php foreach ($checks as $c): ?>
                <tr>
                    <td><?= htmlspecialchars($fmtMskShortRu((string)$c['checked_at'])) ?></td>
                    <td><code><?= htmlspecialchars((string)$c['trigger_type']) ?></code></td>
                    <td>
                        <?php if (!empty($c['ok'])): ?>
                            <?= !empty($c['indexed'])
                                ? '<span style="color:#3fb950">в индексе</span>'
                                : '<span style="color:#ef4444">без индекса</span>' ?>
                        <?php else: ?>
                            <span style="color:#f0a020">запрос не удался</span>
                        <?php endif; ?>
                    </td>
                    <td><?= (int)$c['pages_indexed'] ?></td>
                    <td class="muted small">
                        <?php if (!empty($c['error_code'])): ?>
                            <code><?= htmlspecialchars((string)$c['error_code']) ?></code>
                            <?= htmlspecialchars((string)($c['error_message'] ?? '')) ?>
                        <?php endif; ?>
                    </td>
                    <td class="muted small"><?= htmlspecialchars((string)($c['created_by'] ?? '')) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>

<section class="card">
    <h2>Журнал действий</h2>
    <?php $actions = RelocationService::actionHistory((int)$r['id'], 50); ?>
    <?php if (!$actions && !$events): ?>
        <p class="muted small">Действий оператора не было.</p>
    <?php else: ?>
        <ul class="small" style="line-height:1.7">
            <?php foreach ($actions as $a): ?>
                <li>
                    <span class="muted"><?= htmlspecialchars($fmtMskShortRu((string)$a['created_at'])) ?></span>
                    — <?= htmlspecialchars((string)$a['action']) ?>
                    <?php if (!empty($a['old_value']) || !empty($a['new_value'])): ?>
                        : <code><?= htmlspecialchars((string)$a['old_value']) ?></code>
                        → <code><?= htmlspecialchars((string)$a['new_value']) ?></code>
                    <?php endif; ?>
                    <?php if (!empty($a['comment'])): ?>
                        <br><span class="muted"><?= htmlspecialchars((string)$a['comment']) ?></span>
                    <?php endif; ?>
                    <?php if (!empty($a['actor'])): ?>
                        <span class="muted">· <?= htmlspecialchars((string)$a['actor']) ?></span>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>
