<?php
/**
 * Список переездов. Только move_indexed / move_simple.
 * Все вычисляемые поля (статус, задержка) приходят из RelocationService::enrich().
 */
// Русский формат дат только для раздела «Переезды».
// В БД всё остаётся в UTC; Time::msk() конвертирует отображение в МСК.
$fmtDate = static function (?string $value): string {
    return Time::msk($value, 'd.m.Y', false);
};
$fmtTime = static function (?string $value): string {
    return Time::msk($value, 'H:i', false);
};
?>
<h1>🚚 Переезды</h1>
<p class="muted small">
    Учёт переездов сайтов со старого домена на новый. В раздел попадают только режимы
    <code>move_indexed</code> и <code>move_simple</code> — режим <code>refresh</code>
    это перевыставление, а не переезд.
    Статус индекса определяется <b>строго по XMLStock</b>; фактический переезд —
    по подтверждению Яндекс.Вебмастера (смена главного зеркала).
</p>

<section class="card">
    <div class="row" style="gap:6px; flex-wrap:wrap; margin-bottom:12px">
        <?php
        // §3.6: вкладки сохраняют server_id/q/mode/index_status/sort; page → 1.
        $tabKeep = [];
        foreach (['q','mode','index_status','sort','server_id'] as $kk) {
            $vv = $_GET[$kk] ?? '';
            if ($vv !== '' && !is_array($vv)) $tabKeep[$kk] = (string)$vv;
        }
        foreach ($tabs as $key => $label):
            $qs = array_merge(['tab' => $key], $tabKeep);
        ?>
            <a class="btn <?= $tab === $key ? 'btn-primary' : '' ?>"
               href="/relocations?<?= htmlspecialchars(http_build_query($qs), ENT_QUOTES) ?>">
                <?= htmlspecialchars($label) ?>
                <span class="muted small">(<?= (int)($counts[$key] ?? 0) ?>)</span>
            </a>
        <?php endforeach; ?>
    </div>

    <form method="get" action="/relocations" class="row" style="gap:10px; flex-wrap:wrap; align-items:flex-end">
        <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">

        <label style="display:flex; flex-direction:column; gap:4px">
            <span class="muted small">Поиск по домену</span>
            <input type="text" name="q" value="<?= htmlspecialchars($q) ?>"
                   placeholder="старый или новый домен" style="padding:6px; min-width:220px">
        </label>

        <label style="display:flex; flex-direction:column; gap:4px">
            <span class="muted small">Режим</span>
            <select name="mode" style="padding:6px">
                <option value="">все</option>
                <option value="move_indexed" <?= $mode === 'move_indexed' ? 'selected' : '' ?>>move_indexed</option>
                <option value="move_simple"  <?= $mode === 'move_simple'  ? 'selected' : '' ?>>move_simple</option>
            </select>
        </label>

        <label style="display:flex; flex-direction:column; gap:4px">
            <span class="muted small">Сервер</span>
            <select name="server_id" style="padding:6px">
                <option value="0">все</option>
                <?php foreach (($servers ?? []) as $srv): $lbl = trim((string)($srv['title'] ?? ('#'.$srv['id']))); $code = trim((string)($srv['ui_badge_code'] ?? '')); if ($code!=='') $lbl = $code.' · '.$lbl; ?>
                    <option value="<?= (int)$srv['id'] ?>" <?= (int)($serverFilter ?? 0) === (int)$srv['id'] ? 'selected' : '' ?>><?= htmlspecialchars($lbl) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label style="display:flex; flex-direction:column; gap:4px">
            <span class="muted small">Статус индекса</span>
            <select name="index_status" style="padding:6px">
                <option value="">любой</option>
                <?php foreach (['unchecked','not_indexed','indexed','check_error'] as $s):
                    list($lbl,) = RelocationService::indexStatusLabel($s); ?>
                    <option value="<?= $s ?>" <?= $idxStatus === $s ? 'selected' : '' ?>><?= htmlspecialchars($lbl) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label style="display:flex; flex-direction:column; gap:4px">
            <span class="muted small">Сортировка</span>
            <select name="sort" style="padding:6px">
                <option value="started_desc"   <?= $sort==='started_desc'?'selected':'' ?>>дата старта ↓</option>
                <option value="started_asc"    <?= $sort==='started_asc'?'selected':'' ?>>дата старта ↑</option>
                <option value="planned_asc"    <?= $sort==='planned_asc'?'selected':'' ?>>плановая дата ↑</option>
                <option value="planned_desc"   <?= $sort==='planned_desc'?'selected':'' ?>>плановая дата ↓</option>
                <option value="completed_desc" <?= $sort==='completed_desc'?'selected':'' ?>>дата переезда ↓</option>
                <option value="indexed_desc"   <?= $sort==='indexed_desc'?'selected':'' ?>>замечен в индексе ↓</option>
            </select>
        </label>

        <button type="submit" class="btn">Применить</button>
        <a class="btn" href="/relocations">Сбросить</a>
    </form>
</section>

<section class="card">
    <?php if (!$rows): ?>
        <p class="muted">Записей нет.</p>
    <?php else: ?>
        <table class="table small" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Режим</th>
                    <th>Откуда → Куда</th>
                    <th>Старт</th>
                    <th>План</th>
                    <th>Индекс</th>
                    <th>Замечен</th>
                    <th>Переезд</th>
                    <th>Задержка</th>
                    <th>Стадия</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r):
                list($idxLabel, $idxColor) = RelocationService::indexStatusLabel((string)$r['index_status']);
                $status = (string)$r['status'];
                $statusColor = [
                    'completed'   => '#3fb950',
                    'overdue'     => '#f0a020',
                    'cancelled'   => '#8b949e',
                    'error'       => '#ef4444',
                    'in_progress' => '#58a6ff',
                ][$status] ?? '#8b949e';
            ?>
                <tr>
                    <td>#<?= (int)$r['id'] ?></td>
                    <td><span class="muted small"><?= htmlspecialchars((string)$r['mode']) ?></span></td>
                    <td>
                        <?php $badge = (new ServerBadgePresenter())->fromRow($r); $badgeMode = 'compact'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; ?>
                        <code><?= htmlspecialchars((string)$r['old_domain']) ?></code>
                        <span class="muted">→</span>
                        <code><?= htmlspecialchars((string)$r['new_domain']) ?></code>
                        <?php if (empty($r['job_exists'])): ?>
                            <span class="muted small" title="Джоба удалена, данные взяты из snapshot">· джоба удалена</span>
                        <?php endif; ?>
                    </td>
                    <td class="small" title="Московское время">
                        <?php if ($r['started_at']): ?>
                            <span style="white-space:nowrap"><?= htmlspecialchars($fmtDate((string)$r['started_at'])) ?></span><br>
                            <span class="muted" style="white-space:nowrap"><?= htmlspecialchars($fmtTime((string)$r['started_at'])) ?></span>
                        <?php else: ?>—<?php endif; ?>
                    </td>
                    <td class="small" title="Московское время">
                        <span style="white-space:nowrap"><?= htmlspecialchars($fmtDate((string)$r['planned_at'])) ?></span><br>
                        <span class="muted" style="white-space:nowrap"><?= htmlspecialchars($fmtTime((string)$r['planned_at'])) ?></span>
                    </td>
                    <td><span style="color:<?= $idxColor ?>">●</span> <span class="small"><?= htmlspecialchars($idxLabel) ?></span></td>
                    <td class="small" title="Московское время">
                        <?php if ($r['first_indexed_at']): ?>
                            <span style="white-space:nowrap"><?= htmlspecialchars($fmtDate((string)$r['first_indexed_at'])) ?></span><br>
                            <span class="muted" style="white-space:nowrap"><?= htmlspecialchars($fmtTime((string)$r['first_indexed_at'])) ?></span>
                        <?php else: ?>—<?php endif; ?>
                    </td>
                    <td class="small">
                        <span style="color:<?= $statusColor ?>"><?= htmlspecialchars(RelocationService::statusLabel($status)) ?></span>
                        <?php if (!empty($r['move_completed_at'])): ?>
                            <br><span class="muted" style="white-space:nowrap" title="Московское время">
                                <?= htmlspecialchars($fmtDate((string)$r['move_completed_at'])) ?>
                                <?= htmlspecialchars($fmtTime((string)$r['move_completed_at'])) ?>
                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="small"><?= htmlspecialchars((string)$r['delay']['text']) ?></td>
                    <td class="small">
                        <?php if (!empty($r['stage'])): ?>
                            <code><?= htmlspecialchars((string)$r['stage']) ?></code>
                            <span class="muted"><?= htmlspecialchars((string)$r['stage_status']) ?></span>
                        <?php else: ?>
                            <span class="muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td><a class="btn" href="/relocations/show?id=<?= (int)$r['id'] ?>">Открыть</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
