<?php
/**
 * Страница проверки и сохранения OAuth-токенов Yandex.Webmaster.
 * PATCH 047.1 — UI-only polish (вёрстка/CSS/HTML). Routing/endpoint/CSRF/DB/JS-логика PATCH 047
 * НЕ изменены: все id, классы, data-атрибуты, action и имена полей сохранены.
 * @var array $rows  список аккаунтов из БД
 * @var array $ips   пул исходящих IP
 */
?>
<style>
/* ═══ PATCH 047.1: page-local UI polish (только эта страница) ═══ */
body:has(.webmaster-page) .hub-main { max-width: 1440px; }

.webmaster-page h2 { font-size: 1.15em; margin: 0 0 14px 0; }
.webmaster-page .wm-card { background: var(--bg-card); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 20px; margin-bottom: 20px; }
.webmaster-page .wm-card__head { display: flex; align-items: center; justify-content: space-between;
    flex-wrap: wrap; gap: 10px; margin-bottom: 14px; }
.webmaster-page .wm-card__head h2, .webmaster-page .wm-card__head h3 { margin: 0; }
.webmaster-page .wm-card__actions { display: flex; gap: 8px; flex-wrap: wrap; }

/* Единые badge'и */
.webmaster-page .wm-badge { display: inline-block; padding: 2px 8px; border-radius: 6px;
    font-size: 0.72em; font-weight: 700; letter-spacing: 0.4px; text-transform: uppercase;
    line-height: 1.5; white-space: nowrap; }
.webmaster-page .wm-badge--default  { background: rgba(79,139,255,0.16); color: var(--primary); }
.webmaster-page .wm-badge--assigned { background: rgba(79,182,230,0.16); color: var(--info); }
.webmaster-page .wm-badge--ok       { background: rgba(45,187,110,0.16); color: var(--success); }
.webmaster-page .wm-badge--error    { background: rgba(233,76,76,0.16);  color: var(--danger); }
.webmaster-page .wm-badge--disabled { background: rgba(124,133,151,0.18); color: var(--text-muted); }
.webmaster-page .wm-badge--warn     { background: rgba(230,162,60,0.16);  color: var(--warning); }

/* Кнопки страницы — три типа + icon. Никаких крошечных белых кнопок. */
.webmaster-page .btn { min-height: 34px; }
.webmaster-page .wm-actions { display: flex; gap: 6px; flex-wrap: nowrap; align-items: center; }
.webmaster-page .wm-iconbtn { width: 32px; height: 32px; min-height: 32px; padding: 0;
    display: inline-flex; align-items: center; justify-content: center; font-size: 1em; line-height: 1; }

/* Таблица IP */
.webmaster-page .wm-ip-table td, .webmaster-page .wm-ip-table th { vertical-align: middle; }
.webmaster-page .wm-ip-table code { font-size: 0.95em; }

/* Форма добавления IP — одна строка на desktop */
.webmaster-page .wm-addip { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin-top: 12px; }
.webmaster-page .wm-addip input[type=text] { padding: 8px 10px; background: var(--bg-elevated);
    border: 1px solid var(--border); border-radius: 6px; color: var(--text); }
.webmaster-page .wm-addip input[name=ip_address] { flex: 1 1 240px; }
.webmaster-page .wm-addip input[name=label] { flex: 1 1 200px; }

/* Форма аккаунта */
.webmaster-page .wm-field { margin-bottom: 14px; }
.webmaster-page .wm-field > label { display: block; margin-bottom: 6px; font-weight: 600; }
.webmaster-page textarea#access_token { width: 100%; font-family: monospace; font-size: 0.9em;
    padding: 10px; box-sizing: border-box; background: var(--bg-elevated);
    border: 1px solid var(--border); border-radius: 8px; color: var(--text); }
.webmaster-page select#outbound_ip_id, .webmaster-page .acc-ip-select { padding: 8px 10px;
    background: var(--bg-elevated); border: 1px solid var(--border); border-radius: 6px;
    color: var(--text); max-width: 100%; }
.webmaster-page select#outbound_ip_id { min-width: 360px; }

/* Таблица аккаунтов */
.webmaster-page .wm-acc-table th, .webmaster-page .wm-acc-table td { vertical-align: top; }
.webmaster-page .wm-acc-ipcell { min-width: 260px; }
.webmaster-page .wm-acc-ipcell .wm-ip-head { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.webmaster-page .wm-acc-ipcell .wm-ip-controls { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.webmaster-page .wm-acc-ipcell .acc-ip-select { flex: 1 1 180px; font-size: 0.9em; }
.webmaster-page .acc-ip-status { display: block; margin-top: 6px; font-size: 0.82em; }
.webmaster-page .wm-tokendays { font-weight: 600; }
.webmaster-page .wm-acc-status { line-height: 1.5; }

/* Responsive: планшет — «Заметка» уезжает под аккаунт */
@media (max-width: 1199px) {
    .webmaster-page .wm-col-note { display: none; }
    .webmaster-page .wm-acc-note-inline { display: block; margin-top: 4px; }
}
@media (min-width: 1200px) { .webmaster-page .wm-acc-note-inline { display: none; } }

/* Responsive: мобильный — таблица аккаунтов становится карточками (без горизонтального скролла) */
@media (max-width: 767px) {
    .webmaster-page .wm-acc-table, .webmaster-page .wm-acc-table tbody,
    .webmaster-page .wm-acc-table tr, .webmaster-page .wm-acc-table td { display: block; width: 100%; }
    .webmaster-page .wm-acc-table thead { display: none; }
    .webmaster-page .wm-acc-table tr { border: 1px solid var(--border); border-radius: 8px;
        margin-bottom: 12px; padding: 8px 12px; background: var(--bg-card); }
    .webmaster-page .wm-acc-table td { border: none; padding: 6px 0; }
    .webmaster-page .wm-acc-table td::before { content: attr(data-label); display: block;
        font-size: 0.72em; text-transform: uppercase; letter-spacing: 0.4px; color: var(--text-muted); margin-bottom: 2px; }
    .webmaster-page .wm-acc-ipcell { min-width: 0; }
    .webmaster-page .wm-ip-table { display: block; overflow-x: auto; }
}
</style>

<div class="webmaster-page">

<h1 class="page-title">Yandex.Webmaster — токены аккаунтов</h1>

<div class="wm-card">
    <h3>📚 Как получить токен</h3>
    <ol style="line-height:1.7;">
        <li>Создай приложение на <a href="https://oauth.yandex.ru/" target="_blank" rel="noopener">oauth.yandex.ru</a> с правами <code>webmaster:hostinfo</code> + <code>webmaster:verify</code></li>
        <li>Redirect URI: <code>https://oauth.yandex.ru/verification_code</code></li>
        <li>Войди в нужный Яндекс-аккаунт в браузере (используй приватный режим для разных аккаунтов)</li>
        <li>Открой URL: <code>https://oauth.yandex.ru/authorize?response_type=token&amp;client_id=ТВОЙ_CLIENT_ID</code></li>
        <li>Нажми «Разрешить» → скопируй зелёную строку токена</li>
        <li>Вставь его в форму ниже и нажми «Проверить»</li>
    </ol>
</div>

<!-- ═══ Карточка 1: Исходящие IP Yandex.Webmaster ═══ -->
<div class="wm-card">
    <div class="wm-card__head">
        <h2>🌐 Исходящие IP Yandex.Webmaster</h2>
        <div class="wm-card__actions">
            <button type="button" id="btn-probe-all" class="btn btn-secondary btn-sm">Проверить все IP</button>
            <button type="button" id="btn-routing-check" class="btn btn-primary btn-sm">🔎 Проверить маршрутизацию</button>
        </div>
    </div>

    <table class="hub-table wm-ip-table">
        <thead><tr>
            <th>Метка</th><th>IP</th><th>Тип</th><th>Аккаунтов</th>
            <th>Последняя проверка</th><th>Local / Public</th><th>Статус</th><th>Действия</th>
        </tr></thead>
        <tbody>
        <?php foreach (($ips ?? []) as $ip):
            $cid = (int)$ip['id'];
            $cnt = (int)(($ip_counts[$cid] ?? 0));
            if ((int)$ip['is_default'] === 1) $cnt += (int)(($ip_counts['null'] ?? 0)); // NULL-аккаунты ходят через default
            $ipEnabled = ((int)$ip['is_enabled'] === 1);
            $probeOk = $ip['last_probe_ok'] ?? null;
        ?>
            <tr>
                <td><?= htmlspecialchars($ip['label']) ?></td>
                <td><code><?= htmlspecialchars($ip['ip_address']) ?></code></td>
                <td>
                    <?php if ((int)$ip['is_default'] === 1): ?><span class="wm-badge wm-badge--default">DEFAULT</span>
                    <?php elseif (!$ipEnabled): ?><span class="wm-badge wm-badge--disabled">DISABLED</span>
                    <?php else: ?><span class="muted">—</span><?php endif; ?>
                </td>
                <td><?= $cnt ?></td>
                <td><small class="muted"><?= $ip['last_probe_at'] ? htmlspecialchars(Time::msk((string)$ip['last_probe_at'])) : '—' ?></small></td>
                <td><small class="muted"><?= htmlspecialchars((string)($ip['last_probe_local_ip'] ?? '—')) ?> / <?= htmlspecialchars((string)($ip['last_probe_public_ip'] ?? '—')) ?></small></td>
                <td>
                    <?php if (!$ipEnabled): ?><span class="wm-badge wm-badge--disabled">Выключен</span>
                    <?php elseif ($probeOk === null): ?><span class="muted">не проверен</span>
                    <?php elseif ((int)$probeOk === 1): ?><span class="wm-badge wm-badge--ok">✓ Работает</span>
                    <?php else: ?><span class="wm-badge wm-badge--error">✕ Ошибка</span><?php endif; ?>
                </td>
                <td>
                    <div class="wm-actions">
                        <button type="button" class="btn btn-secondary btn-sm btn-probe-ip" data-id="<?= $cid ?>">Проверить</button>
                        <?php if ((int)$ip['is_default'] !== 1): ?>
                        <form method="post" action="/system/webmaster-tokens/ip-set-default" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf ?? '') ?>">
                            <input type="hidden" name="id" value="<?= $cid ?>">
                            <button type="submit" class="btn btn-secondary btn-sm wm-iconbtn" title="Сделать default">★</button>
                        </form>
                        <form method="post" action="/system/webmaster-tokens/ip-toggle" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf ?? '') ?>">
                            <input type="hidden" name="id" value="<?= $cid ?>">
                            <input type="hidden" name="enable" value="<?= $ipEnabled ? '0' : '1' ?>">
                            <button type="submit" class="btn btn-secondary btn-sm"><?= $ipEnabled ? 'Выключить' : 'Включить' ?></button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <form method="post" action="/system/webmaster-tokens/ip-add" class="wm-addip">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf ?? '') ?>">
        <input type="text" name="ip_address" placeholder="IPv4, напр. 203.0.113.7">
        <input type="text" name="label" placeholder="Метка">
        <button type="submit" class="btn btn-secondary btn-sm">Добавить IP</button>
    </form>
    <div id="routing-result" style="margin-top:12px;"></div>
</div>

<!-- ═══ Карточка 2: Добавить аккаунт Yandex.Webmaster ═══ -->
<div class="wm-card">
    <h2>+ Добавить аккаунт Yandex.Webmaster</h2>

    <div id="check-form">
        <div class="wm-field">
            <label>Access Token (строка <code>y0_AgAAAAA...</code>)</label>
            <textarea id="access_token" rows="3" placeholder="y0_AgAAAAA0XXXX..."></textarea>
        </div>
        <div class="wm-field">
            <label>Исходящий IP Webmaster (жёсткая привязка)</label>
            <select id="outbound_ip_id">
                <?php foreach (($ips ?? []) as $ip): if ((int)$ip['is_enabled'] !== 1) continue; ?>
                    <option value="<?= (int)$ip['id'] ?>" <?= (int)$ip['is_default'] === 1 ? 'selected' : '' ?>>
                        <?= htmlspecialchars($ip['label']) ?> — <?= htmlspecialchars($ip['ip_address']) ?><?= (int)$ip['is_default'] === 1 ? ' (DEFAULT)' : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="button" id="btn-check" class="btn btn-primary">🔍 Проверить токен и IP</button>
        <span id="check-status" style="margin-left:12px; font-style:italic;"></span>
    </div>

    <!-- Результат проверки и форма сохранения (показывается после успешной проверки) -->
    <div id="save-form" style="display:none; margin-top:20px; padding-top:20px; border-top:1px solid var(--border);">
        <div id="check-result" style="margin-bottom:16px;"></div>

        <form method="post" action="/system/webmaster-tokens/save">
            <input type="hidden" name="access_token" id="hidden-token">
            <input type="hidden" name="outbound_ip_id" id="hidden-outbound-ip">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf ?? '') ?>">
            <input type="hidden" name="expires_in" value="31536000">

            <table class="kv-table" style="width:100%; max-width:600px;">
                <tr>
                    <td style="width:160px; padding:8px 0;">Email аккаунта *</td>
                    <td><input type="email" name="email" required style="width:100%; padding:6px;" placeholder="seotop.luxe@yandex.ru"></td>
                </tr>
                <tr>
                    <td style="padding:8px 0;">Метка (label)</td>
                    <td><input type="text" name="label" style="width:100%; padding:6px;" placeholder="оставь пустым = email"></td>
                </tr>
                <tr>
                    <td style="padding:8px 0;">Заметка</td>
                    <td><input type="text" name="note" style="width:100%; padding:6px;" placeholder="например: основной для casino-сайтов"></td>
                </tr>
                <tr>
                    <td style="padding:8px 0;">По умолчанию?</td>
                    <td>
                        <label><input type="checkbox" name="is_default" value="1">
                        использовать для новых сайтов автоматически</label>
                    </td>
                </tr>
            </table>
            <button type="submit" class="btn btn-success" style="margin-top:12px;">💾 Сохранить</button>
        </form>
    </div>
</div>

<!-- ═══ Карточка 3: Добавленные аккаунты ═══ -->
<div class="wm-card">
    <div class="wm-card__head">
        <h2>Добавленные аккаунты (<?= count($rows) ?>)</h2>
        <div class="wm-card__actions">
            <select id="wm-filter-ip" class="btn btn-secondary btn-sm" style="padding:6px 10px;">
                <option value="">Фильтр по IP — все</option>
                <option value="__default__">DEFAULT (155.212.141.141)</option>
                <?php foreach (($ips ?? []) as $ip): if ((int)$ip['is_default'] === 1) continue; ?>
                    <option value="<?= (int)$ip['id'] ?>"><?= htmlspecialchars($ip['ip_address']) ?></option>
                <?php endforeach; ?>
            </select>
            <label class="btn btn-secondary btn-sm" style="display:inline-flex; align-items:center; gap:6px; cursor:pointer;">
                <input type="checkbox" id="wm-filter-problems"> Только проблемные
            </label>
            <button type="button" id="btn-check-all-acc" class="btn btn-secondary btn-sm">Проверить все аккаунты</button>
        </div>
    </div>

<?php if (empty($rows)): ?>
    <div class="empty-state"><p>Аккаунтов пока нет. Добавь первый через форму выше.</p></div>
<?php else: ?>
    <table class="hub-table wm-acc-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Аккаунт</th>
                <th>Webmaster</th>
                <th>Сайтов</th>
                <th>Токен</th>
                <th>Исходящий IP</th>
                <th>Статус</th>
                <th class="wm-col-note">Заметка</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $r): ?>
                <?php
                $expiresAt = $r['token_expires_at'] ?: '';
                $daysLeft = null;
                if ($expiresAt) {
                    $diff = strtotime($expiresAt) - time();
                    $daysLeft = (int)floor($diff / 86400);
                }
                $expired = $daysLeft !== null && $daysLeft < 0;
                // цвет токена: >60 green/neutral, 15–60 amber, <15 red, expired red badge
                $tokenClass = 'muted';
                if ($daysLeft !== null) {
                    if ($daysLeft < 0) $tokenClass = 'wm-badge wm-badge--error';
                    elseif ($daysLeft < 15) $tokenClass = 'wm-tokendays';
                }
                $accIp = $r['outbound_ip_address'] ?? null;
                $accIpDisabled = ($r['outbound_ip_id'] !== null && (int)($r['outbound_ip_enabled'] ?? 1) === 0);
                $lastOk = $r['last_outbound_ok'];
                $validationOk = !empty($r['last_validation_ok']);
                $isProblem = (!$validationOk) || $accIpDisabled || ($lastOk !== null && (int)$lastOk !== 1) || $expired ? '1' : '0';
                ?>
                <tr class="wm-acc-row" data-ip-id="<?= (int)($r['outbound_ip_id'] ?? 0) ?>" data-problem="<?= $isProblem ?>">
                    <td data-label="#"><?= (int)$r['id'] ?></td>
                    <td data-label="Аккаунт">
                        <strong><?= htmlspecialchars($r['email']) ?></strong>
                        <?php if (!empty($r['label']) && $r['label'] !== $r['email']): ?>
                            <br><small class="muted"><?= htmlspecialchars($r['label']) ?></small>
                        <?php endif; ?>
                        <span class="wm-acc-note-inline"><small class="muted"><?= htmlspecialchars((string)($r['note'] ?? '')) ?></small></span>
                    </td>
                    <td data-label="Webmaster">
                        <code>ID <?= (int)$r['yandex_user_id'] ?></code>
                        <?php if (!empty($r['is_default'])): ?><br><span class="wm-badge wm-badge--default">DEFAULT ACCOUNT</span><?php endif; ?>
                    </td>
                    <td data-label="Сайтов"><?= (int)$r['host_count'] ?></td>
                    <td data-label="Токен">
                        <?php if ($expired): ?>
                            <span class="wm-badge wm-badge--error">истёк</span>
                        <?php elseif ($daysLeft !== null): ?>
                            <span class="<?= $tokenClass ?>" style="<?= $daysLeft < 15 ? 'color:var(--danger);' : ($daysLeft < 60 ? 'color:var(--warning);' : '') ?>"><?= $daysLeft ?> дн.</span>
                        <?php else: ?>
                            <span class="muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td data-label="Исходящий IP" class="wm-acc-ipcell">
                        <div class="wm-ip-head">
                            <?php if ($accIp === null): ?>
                                🌐 <code><?= htmlspecialchars((string)($default_ip ?? '')) ?></code>
                                <span class="wm-badge wm-badge--default">DEFAULT</span>
                            <?php else: ?>
                                🌐 <code><?= htmlspecialchars($accIp) ?></code>
                                <span class="wm-badge wm-badge--assigned">ASSIGNED</span>
                                <?php if ($accIpDisabled): ?><span class="wm-badge wm-badge--error">IP выключен</span><?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="wm-ip-controls">
                            <select class="acc-ip-select" data-account="<?= (int)$r['id'] ?>">
                                <option value="">— выбрать IP —</option>
                                <?php foreach (($ips ?? []) as $ip): if ((int)$ip['is_enabled'] !== 1) continue; ?>
                                    <option value="<?= (int)$ip['id'] ?>" <?= ((int)($r['outbound_ip_id'] ?? 0) === (int)$ip['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($ip['ip_address']) ?><?= (int)$ip['is_default'] === 1 ? ' (DEFAULT)' : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="button" class="btn btn-primary btn-sm btn-assign-ip" data-account="<?= (int)$r['id'] ?>" title="Проверить и назначить IP">Применить</button>
                        </div>
                        <span class="acc-ip-status muted" data-account="<?= (int)$r['id'] ?>"></span>
                    </td>
                    <td data-label="Статус" class="wm-acc-status">
                        <?php if ($validationOk): ?>
                            <span class="wm-badge wm-badge--ok">✓ OK</span>
                            <?php if ($r['last_validated_at']): ?>
                                <br><small class="muted">проверен <?= htmlspecialchars(Time::msk((string)$r['last_validated_at'])) ?></small>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="wm-badge wm-badge--error">✕ FAIL</span>
                            <?php if (!empty($r['last_validation_error'])): ?>
                                <br><small style="color:var(--danger);"><?= htmlspecialchars(mb_substr((string)$r['last_validation_error'], 0, 80)) ?></small>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if ($lastOk !== null): ?>
                            <br><small style="color:<?= (int)$lastOk === 1 ? 'var(--success)' : 'var(--danger)' ?>;">
                                <?= (int)$lastOk === 1 ? '✓ IP подтверждён' : '✗ IP mismatch' ?>
                            </small>
                        <?php endif; ?>
                    </td>
                    <td data-label="Заметка" class="wm-col-note"><small><?= htmlspecialchars((string)($r['note'] ?? '')) ?></small></td>
                    <td data-label="Действия">
                        <div class="wm-actions">
                            <button type="button" class="btn btn-secondary btn-sm wm-iconbtn btn-check-acc" data-account="<?= (int)$r['id'] ?>" title="Проверить API / IP">🔎</button>
                            <form method="post" action="/system/webmaster-tokens/recheck" style="display:inline;">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf ?? '') ?>">
                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                <button type="submit" class="btn btn-secondary btn-sm wm-iconbtn" title="Перепроверить">↻</button>
                            </form>
                            <form method="post" action="/system/webmaster-tokens/delete"
                                  onsubmit="return confirm('Удалить аккаунт <?= htmlspecialchars($r['email']) ?>?');" style="display:inline;">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf ?? '') ?>">
                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm wm-iconbtn" title="Удалить">×</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
</div>

<script>
(function() {
    const btnCheck = document.getElementById('btn-check');
    const tokenInput = document.getElementById('access_token');
    const status = document.getElementById('check-status');
    const result = document.getElementById('check-result');
    const saveForm = document.getElementById('save-form');
    const hiddenToken = document.getElementById('hidden-token');

    btnCheck.addEventListener('click', async function() {
        const token = tokenInput.value.trim();
        if (!token) {
            status.style.color = 'var(--danger)';
            status.textContent = 'Вставь токен в поле выше';
            return;
        }

        // Очищаем
        saveForm.style.display = 'none';
        status.style.color = 'var(--text-muted)';
        status.textContent = '⏳ Проверяю через API Webmaster...';
        btnCheck.disabled = true;

        try {
            const formData = new FormData();
            formData.append('access_token', token);
            const outSel = document.getElementById('outbound_ip_id');
            const outId = outSel ? outSel.value : '';
            if (outId) formData.append('outbound_ip_id', outId);

            const resp = await fetch('/system/webmaster-tokens/check', {
                method: 'POST',
                body: formData,
            });
            const data = await resp.json();

            if (!resp.ok || !data.ok) {
                status.style.color = 'var(--danger)';
                status.textContent = '✗ ' + (data.error || data.message || ('HTTP ' + resp.status));
                return;
            }

            // Успех
            const r = data.data || data;
            status.style.color = 'var(--success)';
            status.textContent = '✓ Токен валиден';

            // Формируем превью
            let html = '<div style="background:var(--bg-elevated); padding:12px; border-radius:4px;">';
            html += '<strong>user_id:</strong> <code>' + escapeHtml(String(r.user_id)) + '</code><br>';
            html += '<strong>Сайтов в Webmaster:</strong> ' + r.host_count;
            html += '<br><strong>Исходящий IP (ожидался):</strong> <code>' + escapeHtml(String(r.outbound_ip_expected||'')) + '</code>';
            html += '<br><strong>Фактически использован:</strong> <code>' + escapeHtml(String(r.outbound_ip_actual||'')) + '</code>';
            html += '<br><strong>Source IP подтверждён:</strong> ' + (r.source_ip_verified ? '✓ да' : '✗ нет');
            if (r.source_ip_verified) { status.textContent = '✓ Токен проверен через ' + (r.outbound_ip_expected||''); }
            var hio = document.getElementById('hidden-outbound-ip');
            if (hio) hio.value = (r.outbound_ip_id || outId || '');
            if (r.host_count > 0 && r.hosts && r.hosts.length) {
                html += '<details style="margin-top:8px;"><summary style="cursor:pointer;">Список сайтов (первые ' + r.hosts.length + (r.has_more ? ', есть ещё' : '') + ')</summary>';
                html += '<ul style="margin:8px 0 0 16px; font-size:0.9em;">';
                for (const h of r.hosts) {
                    const url = h.unicode_host_url || h.ascii_host_url || h.host_id;
                    const verified = h.verified ? '✓' : '✗';
                    html += '<li>' + verified + ' ' + escapeHtml(url) + '</li>';
                }
                html += '</ul></details>';
            }
            html += '</div>';
            result.innerHTML = html;

            hiddenToken.value = token;
            saveForm.style.display = 'block';

            // Прокрутим к форме сохранения
            saveForm.scrollIntoView({behavior: 'smooth', block: 'start'});
        } catch (e) {
            status.style.color = 'var(--danger)';
            status.textContent = '✗ Ошибка: ' + e.message;
        } finally {
            btnCheck.disabled = false;
        }
    });

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    // ═══ PATCH 047: probe / routing / assign / account-check ═══
    const CSRF = <?= json_encode($csrf ?? '') ?>;
    function post(url, params) {
        const fd = new FormData();
        fd.append('csrf_token', CSRF);
        for (const k in params) {
            if (Array.isArray(params[k])) { for (const v of params[k]) fd.append(k + '[]', v); }
            else fd.append(k, params[k]);
        }
        return fetch(url, { method: 'POST', body: fd }).then(r => r.json());
    }

    const routingResult = document.getElementById('routing-result');
    const btnRouting = document.getElementById('btn-routing-check');
    if (btnRouting) btnRouting.addEventListener('click', async () => {
        routingResult.innerHTML = '⏳ Проверяю маршрутизацию…';
        try {
            const d = await post('/system/webmaster-tokens/routing-check', {});
            const s = (d.data && d.data.summary) || d.summary || {};
            let html = '<div style="padding:8px; border-radius:4px; background:var(--bg-elevated);">';
            html += '<strong>WEBMASTER ROUTING: ' + (s.overall_pass ? '✅ PASS' : '❌ FAIL') + '</strong><br>';
            html += 'Default: ' + escapeHtml(String(s.default_ip||'—')) + ' (ok=' + s.default_ok + ')<br>';
            html += 'Accounts: ' + s.accounts_pass + ' PASS / ' + s.accounts_fail + ' FAIL<br>';
            html += 'IP пул: ' + (s.pool_pass||0) + ' PASS / ' + (s.pool_fail||0) + ' FAIL<br>';
            html += 'Source mismatches: ' + s.source_mismatches + ' · disabled: ' + s.disabled_assignments + ' · missing: ' + s.missing_assignments;
            html += '</div>';
            routingResult.innerHTML = html;
        } catch (e) { routingResult.innerHTML = '✗ ' + e.message; }
    });

    document.querySelectorAll('.btn-probe-ip').forEach(b => b.addEventListener('click', async () => {
        const id = b.getAttribute('data-id'); b.disabled = true; b.textContent = '⏳';
        try { const d = await post('/system/webmaster-tokens/ip-probe', { id }); const res = (d.data && d.data.results) || d.results || [];
              const r0 = res[0] || {}; b.textContent = r0.ok ? '✓' : '✗'; }
        catch (e) { b.textContent = '✗'; } finally { setTimeout(() => { b.disabled = false; b.textContent = 'Проверить'; }, 2500); }
    }));
    const btnProbeAll = document.getElementById('btn-probe-all');
    if (btnProbeAll) btnProbeAll.addEventListener('click', async () => {
        btnProbeAll.disabled = true; try { await post('/system/webmaster-tokens/ip-probe', {}); location.reload(); }
        catch (e) { btnProbeAll.disabled = false; }
    });

    document.querySelectorAll('.btn-check-acc').forEach(b => b.addEventListener('click', async () => {
        const id = b.getAttribute('data-account');
        const st = document.querySelector('.acc-ip-status[data-account="' + id + '"]');
        if (st) st.textContent = '⏳';
        try { const d = await post('/system/webmaster-tokens/account-check', { id }); const r = d.data || d;
              if (st) { st.style.color = r.ok ? 'var(--success)' : 'var(--danger)';
                        st.textContent = (r.ok ? '✓ ' : '✗ ') + (r.actual || '') + (r.error ? (' — ' + r.error) : ''); } }
        catch (e) { if (st) st.textContent = '✗ ' + e.message; }
    }));

    document.querySelectorAll('.btn-assign-ip').forEach(b => b.addEventListener('click', async () => {
        const id = b.getAttribute('data-account');
        const sel = document.querySelector('.acc-ip-select[data-account="' + id + '"]');
        const ipId = sel ? sel.value : '';
        const st = document.querySelector('.acc-ip-status[data-account="' + id + '"]');
        if (!ipId) { if (st) st.textContent = 'выберите IP'; return; }
        if (st) st.textContent = '⏳ проверяю через выбранный IP…';
        try { const d = await post('/system/webmaster-tokens/assign-ip', { account_id: id, ip_id: ipId });
              if (d.ok || (d.data && d.data.ok)) { location.reload(); }
              else if (st) { st.style.color = 'var(--danger)'; st.textContent = '✗ ' + (d.error || 'fail'); } }
        catch (e) { if (st) st.textContent = '✗ ' + e.message; }
    }));

    const btnCheckAll = document.getElementById('btn-check-all-acc');
    if (btnCheckAll) btnCheckAll.addEventListener('click', async () => {
        btnCheckAll.disabled = true; btnCheckAll.textContent = '⏳…';
        try { const d = await post('/system/webmaster-tokens/check-all', {}); const accs = (d.data && d.data.accounts) || d.accounts || [];
              let pass = accs.filter(a => a.ok).length;
              routingResult.innerHTML = '<div style="padding:8px;background:var(--bg-elevated);border-radius:4px;">Аккаунты: ' + pass + '/' + accs.length + ' PASS</div>'; }
        catch (e) { routingResult.innerHTML = '✗ ' + e.message; }
        finally { btnCheckAll.disabled = false; btnCheckAll.textContent = 'Проверить все аккаунты'; }
    });

    // ═══ PATCH 047.1: клиентский фильтр аккаунтов (UI-only, без запросов) ═══
    const fIp = document.getElementById('wm-filter-ip');
    const fProb = document.getElementById('wm-filter-problems');
    function applyFilter() {
        const ipv = fIp ? fIp.value : '';
        const onlyProb = fProb ? fProb.checked : false;
        document.querySelectorAll('.wm-acc-row').forEach(row => {
            let show = true;
            if (ipv === '__default__') { show = (row.getAttribute('data-ip-id') === '0'); }
            else if (ipv) { show = (row.getAttribute('data-ip-id') === ipv); }
            if (show && onlyProb) { show = (row.getAttribute('data-problem') === '1'); }
            row.style.display = show ? '' : 'none';
        });
    }
    if (fIp) fIp.addEventListener('change', applyFilter);
    if (fProb) fProb.addEventListener('change', applyFilter);
})();
</script>

<!-- ═══ Карточка 4: журнал запросов Webmaster API ═══ -->
<div class="wm-card">
    <details>
        <summary style="cursor:pointer; font-weight:600;">📋 Последние запросы Webmaster API (аудит исходящего IP)</summary>
        <div style="margin-top:8px;">
            <label><input type="checkbox" id="audit-errors-only"> только ошибки</label>
            <button type="button" id="btn-load-audit" class="btn btn-secondary btn-sm">Загрузить</button>
            <div id="audit-body" style="margin-top:8px; overflow-x:auto;"></div>
        </div>
    </details>
</div>

</div><!-- /.webmaster-page -->

<script>
(function() {
    const btn = document.getElementById('btn-load-audit');
    const body = document.getElementById('audit-body');
    if (!btn) return;
    btn.addEventListener('click', async () => {
        const only = document.getElementById('audit-errors-only').checked ? '1' : '';
        body.innerHTML = '⏳…';
        try {
            const resp = await fetch('/system/webmaster-tokens/audit' + (only ? '?only_errors=1' : ''));
            const d = await resp.json();
            const rows = (d.data && d.data.rows) || d.rows || [];
            let html = '<table class="hub-table" style="width:100%; font-size:0.85em;"><thead><tr>' +
                '<th>Время</th><th>Acc</th><th>Job</th><th>Этап</th><th>Метод/endpoint</th>' +
                '<th>Ожидался</th><th>Факт.</th><th>HTTP</th><th>Результат</th></tr></thead><tbody>';
            for (const r of rows) {
                const okc = r.result === 'success' ? 'var(--success)' : 'var(--danger)';
                html += '<tr><td>' + esc(r.created_at) + '</td><td>' + esc(r.webmaster_account_id) + '</td>' +
                    '<td>' + esc(r.refresh_job_id || '') + '</td><td>' + esc(r.stage || '') + '</td>' +
                    '<td>' + esc(r.endpoint) + '</td><td><code>' + esc(r.expected_outbound_ip) + '</code></td>' +
                    '<td><code>' + esc(r.actual_local_ip || '') + '</code></td><td>' + esc(r.http_code || '') + '</td>' +
                    '<td style="color:' + okc + ';">' + esc(r.result) + '</td></tr>';
            }
            html += '</tbody></table>';
            body.innerHTML = rows.length ? html : '<em>нет записей</em>';
        } catch (e) { body.innerHTML = '✗ ' + e.message; }
    });
    function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
})();
</script>
