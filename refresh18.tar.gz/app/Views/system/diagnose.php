<h1 class="page-title">🩺 Системная диагностика</h1>

<section class="card">
    <h2>PHP окружение</h2>
    <dl class="kv">
        <dt>Версия PHP</dt><dd><code><?= htmlspecialchars($phpVersion) ?></code></dd>
        <dt>app_key</dt><dd>
            <?php if ($hasAppKey): ?>
                <span class="pill pill-ok">установлен</span>
            <?php else: ?>
                <span class="pill pill-warn">не установлен (используется дефолт!)</span>
            <?php endif; ?>
        </dd>
        <dt>Storage writable</dt><dd>
            <?php if ($storageWritable): ?>
                <span class="pill pill-ok">да</span>
            <?php else: ?>
                <span class="pill pill-failed">нет</span>
            <?php endif; ?>
        </dd>
        <dt>Sessions dir</dt><dd>
            <code><?= htmlspecialchars($sessionsDir) ?></code>
            <?php if ($sessionsWritable): ?>
                <span class="pill pill-ok">writable</span>
            <?php else: ?>
                <span class="pill pill-failed">не writable</span>
            <?php endif; ?>
        </dd>
    </dl>

    <h3>Расширения</h3>
    <dl class="kv">
        <?php foreach ($extStatus as $name => $ok): ?>
            <dt><?= htmlspecialchars($name) ?></dt>
            <dd>
                <?php if ($ok): ?>
                    <span class="pill pill-ok">установлен</span>
                <?php else: ?>
                    <span class="pill pill-failed">отсутствует!</span>
                <?php endif; ?>
            </dd>
        <?php endforeach; ?>
    </dl>
</section>

<!-- v18.1.20: блок состояния cron — самая важная диагностика когда джобы не двигаются -->
<section class="card">
    <h2>⏰ Состояние крона</h2>

    <?php
    // v18.1.29: показываем настройку max_jobs_per_tick.
    // Источник: БД (app_settings) → config/app.php fallback → default 5.
    $maxJobsConfigDefault = (int)config('cron.max_jobs_per_tick', 5);
    $maxJobsPerTick = AppSettings::getInt('cron.max_jobs_per_tick', $maxJobsConfigDefault);
    ?>
    <p class="muted small" style="margin-bottom: 12px;">
        Cron обрабатывает до <strong><?= $maxJobsPerTick ?></strong> джоб за один tick (параллельно через per-job lock).
        Изменить можно в <a href="/settings">Настройках</a> → «⚙️ Параллельная обработка джоб».
        Каждая джоба защищена индивидуальным lock'ом — повторный запуск (cron + manual) не вызовет race.
    </p>

    <?php if (empty($cronStates)): ?>
        <div class="hub-flash hub-flash--warn">
            <b>⚠ Cron ни разу не запускался</b><br>
            Таблица <code>cron_state</code> пуста. Проверь что на хостинге настроен cron-job
            на URL <code>https://refresh-panel.seotop-one.ru/cron?token=...</code> и что
            он реально дёргается.
        </div>
    <?php else: ?>
        <table class="hub-table" style="margin-bottom: 12px;">
            <thead>
                <tr>
                    <th>Cron</th>
                    <th>Последний запуск</th>
                    <th>Когда</th>
                    <th>Статус</th>
                    <th>Что делал</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cronStates as $cs): ?>
                    <?php
                    $secAgo = (int)($cs['seconds_ago'] ?? 0);
                    $minAgo = (int)($secAgo / 60);
                    $isStale = $secAgo > 180; // 3 минуты — уже подозрительно
                    $isVeryStale = $secAgo > 600; // 10 минут — точно сломано
                    $stats = !empty($cs['stats_json']) ? (json_decode((string)$cs['stats_json'], true) ?: []) : [];
                    $whatDid = '';
                    // v18.1.29: multi-job stats (новый формат)
                    if (isset($stats['job_results']) && is_array($stats['job_results'])) {
                        $jobsCount = count($stats['job_results']);
                        $processed = (int)($stats['jobs_processed'] ?? 0);
                        $skipped = (int)($stats['jobs_skipped_lock'] ?? 0);
                        if ($jobsCount === 0 && $skipped === 0) {
                            $whatDid = '(нет джоб в очереди)';
                        } else {
                            $parts = [];
                            if ($processed > 0) $parts[] = "обработал {$processed}";
                            if ($skipped > 0) $parts[] = "пропустил {$skipped} (lock)";
                            $whatDid = implode(', ', $parts);
                            // Подсказка first job
                            $firstJob = $stats['job_results'][0] ?? null;
                            if ($firstJob && isset($firstJob['job_id'])) {
                                $whatDid .= ' · первая: #' . (int)$firstJob['job_id']
                                         . ' ' . htmlspecialchars((string)($firstJob['from_stage'] ?? '?'))
                                         . ' → ' . htmlspecialchars((string)($firstJob['to_stage'] ?? '?'));
                            }
                        }
                    }
                    // Legacy (single-job) stats — для cron_state от старой версии
                    elseif (!empty($stats['picked_job_id'])) {
                        $whatDid = 'job #' . (int)$stats['picked_job_id']
                                 . ' (' . htmlspecialchars((string)($stats['picked_stage'] ?? '?'))
                                 . '/' . htmlspecialchars((string)($stats['picked_status'] ?? '?')) . ')';
                        if (!empty($stats['result_stage'])) {
                            $whatDid .= ' → ' . htmlspecialchars((string)$stats['result_stage'])
                                     . '/' . htmlspecialchars((string)($stats['result_status'] ?? '?'));
                        }
                    } elseif (isset($stats['jobs_picked']) && (int)$stats['jobs_picked'] === 0) {
                        $whatDid = '(нет джоб в очереди)';
                    }
                    ?>
                    <tr>
                        <td><code><?= htmlspecialchars((string)$cs['cron_name']) ?></code></td>
                        <td><code><?= htmlspecialchars(Time::msk((string)$cs['last_run_at'], 'Y-m-d H:i:s')) ?></code></td>
                        <td>
                            <?php if ($isVeryStale): ?>
                                <span class="pill pill-failed">⚠ <?= $minAgo ?> мин назад</span>
                            <?php elseif ($isStale): ?>
                                <span class="pill pill-warn"><?= $minAgo ?> мин назад</span>
                            <?php else: ?>
                                <span class="pill pill-ok"><?= $secAgo ?> сек назад</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ((int)$cs['last_ok'] === 1): ?>
                                <span class="pill pill-ok">✓ ok</span>
                            <?php else: ?>
                                <span class="pill pill-failed">✗ error</span>
                                <?php if (!empty($cs['last_error'])): ?>
                                    <br><code class="small" style="color: var(--danger);"><?= htmlspecialchars((string)$cs['last_error']) ?></code>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="muted small"><?= $whatDid ?: '—' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <?php if (!empty($pendingJobs)): ?>
        <h3 style="margin-top: 16px;">Джобы которые ждут крон (<?= count($pendingJobs) ?>)</h3>
        <table class="hub-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Домены</th>
                    <th>Стадия</th>
                    <th>Статус</th>
                    <th>Следующий запуск</th>
                    <th>Ждёт</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pendingJobs as $j): ?>
                    <?php $waitMin = (int)((int)($j['waiting_sec'] ?? 0) / 60); ?>
                    <tr>
                        <td><a href="/jobs/show?id=<?= (int)$j['id'] ?>">#<?= (int)$j['id'] ?></a></td>
                        <td class="small">
                            <code><?= htmlspecialchars((string)$j['old_domain']) ?></code>
                            → <code><?= htmlspecialchars((string)$j['new_domain']) ?></code>
                        </td>
                        <td><code><?= htmlspecialchars(JobEventLogger::stageLabel((string)$j['stage'])) ?></code></td>
                        <td><code><?= htmlspecialchars(JobEventLogger::statusLabel((string)$j['stage_status'])) ?></code></td>
                        <td class="small"><?= htmlspecialchars(!empty($j['next_run_at']) ? Time::msk((string)$j['next_run_at']) : '— (сразу)') ?></td>
                        <td><?= $waitMin > 0 ? $waitMin . ' мин' : 'только что' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p class="muted small" style="margin-top: 8px;">
            Если эти джобы тут давно — значит cron не подхватывает.
            Жми кнопку «Запустить cron сейчас» — она вызовет cron-эндпоинт руками
            и покажет ответ. Если ответ нормальный («picked job_id=...») — значит код
            работает и проблема в хостинг-cron'е (он не дёргает URL).
        </p>
    <?php else: ?>
        <p class="muted">✓ Все джобы либо завершены, либо ждут оператора. Очередь пустая.</p>
    <?php endif; ?>

    <form method="post" action="/system/run-cron" style="margin-top: 12px;"
          onsubmit="return confirm('Вызвать /cron?token=... руками? Будет показан ответ сервера.\n\nИспользуй для проверки что cron-эндпоинт работает (если хостинг-cron не дёргает его).');">
        <button type="submit" class="btn btn-primary">⚡ Запустить cron сейчас</button>
        <span class="muted small" style="margin-left: 8px;">
            Делает HTTP-вызов <code>/cron?token=...</code> своему же сайту, показывает ответ.
        </span>
    </form>
</section>

<?php /* ТЗ047 §50 — Yandex.Webmaster: исходящая маршрутизация */ ?>
<?php if (!empty($webmasterRouting['available'])): ?>
<section class="card">
    <h2>🌐 Yandex.Webmaster — исходящая маршрутизация</h2>
    <table class="hub-table" style="width:100%; max-width:640px;">
        <tbody>
        <?php foreach (($webmasterRouting['checks'] ?? []) as $c): ?>
            <tr>
                <td><?= htmlspecialchars($c['label']) ?></td>
                <td style="color:<?= !empty($c['ok']) ? 'var(--success)' : 'var(--danger)' ?>; white-space:nowrap;">
                    <?= !empty($c['ok']) ? '✓ PASS' : '✗ FAIL' ?>
                </td>
                <td><small class="muted"><?= htmlspecialchars((string)($c['detail'] ?? '')) ?></small></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php if (!empty($webmasterRouting['pool'])): ?>
        <h3 style="margin-top:12px;">Пул исходящих IP</h3>
        <ul style="margin:0 0 0 16px;">
            <?php foreach ($webmasterRouting['pool'] as $p): ?>
                <li><code><?= htmlspecialchars($p['ip']) ?></code> — <?= htmlspecialchars($p['label']) ?>
                    <?= !empty($p['enabled']) ? '' : '<span style="color:var(--danger);">(выключен)</span>' ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <p class="muted small" style="margin-top:8px;">
        Живые probe IP (bind/TLS + public egress) и проверка аккаунтов — на странице
        <a href="/system/webmaster-tokens">Webmaster-токены</a> (кнопка «🔎 Проверить маршрутизацию Webmaster»).
    </p>
</section>
<?php endif; ?>

<?php if (!empty($syntaxIssues)): ?>
    <section class="card" style="border-color: var(--danger);">
        <h2>❌ Файлы с синтаксической ошибкой (<?= count($syntaxIssues) ?>)</h2>
        <p class="muted">
            Это означает что файл сломан или залит не полностью. Залейте его заново
            через FTP. Часто помогает выкачать архив v6/v8 заново и переписать всё поверх.
        </p>
        <?php foreach ($syntaxIssues as $i): ?>
            <div class="hub-flash hub-flash--error" style="margin-bottom: 12px;">
                <div><b><?= htmlspecialchars($i['file']) ?></b>
                    <span class="muted small">(<?= (int)$i['lines'] ?> строк, <?= number_format((float)$i['size'], 0, '.', ' ') ?> байт)</span>
                </div>
                <pre style="background: rgba(0,0,0,0.3); padding: 8px; border-radius: 4px; margin-top: 8px; font-size: 0.85em; white-space: pre-wrap; word-break: break-all;"><?= htmlspecialchars((string)$i['error']) ?></pre>
            </div>
        <?php endforeach; ?>
    </section>
<?php else: ?>
    <section class="card">
        <h2>✅ Все PHP-файлы валидны</h2>
        <p class="muted">Проверено: <?= count($syntaxOk) ?> файлов.</p>
    </section>
<?php endif; ?>

<section class="card">
    <h2>📋 Все проверенные файлы</h2>
    <table class="hub-table">
        <thead><tr><th>Файл</th><th>Строк</th><th>Размер</th><th>Статус</th></tr></thead>
        <tbody>
            <?php foreach ($syntaxOk as $f): ?>
                <tr>
                    <td><code><?= htmlspecialchars($f['file']) ?></code></td>
                    <td><?= (int)$f['lines'] ?></td>
                    <td><?= number_format((float)$f['size'], 0, '.', ' ') ?></td>
                    <td><span class="pill pill-ok">ok</span></td>
                </tr>
            <?php endforeach; ?>
            <?php foreach ($syntaxIssues as $f): ?>
                <tr>
                    <td><code><?= htmlspecialchars($f['file']) ?></code></td>
                    <td><?= (int)$f['lines'] ?></td>
                    <td><?= number_format((float)$f['size'], 0, '.', ' ') ?></td>
                    <td><span class="pill pill-failed">SYNTAX ERROR</span></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>
