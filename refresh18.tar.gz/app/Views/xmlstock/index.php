<?php
/**
 * §6 — Полный UI /xmlstock: KPI, вкладки, обзор, мониторы, история, настройки.
 * Дизайн-система панели (тёмная тема), классы .xmlstock-* из admin.css, без inline-
 * раскладки, все enum — через XmlStockLabels, все даты — МСК через Time::msk.
 *
 * @var string $tab  overview|monitors|history|settings
 */
$csrf = htmlspecialchars((string)($csrfToken ?? ''));
$e = static fn($v) => htmlspecialchars((string)$v);
// §5.2.2 (v4): нормализация необязательных данных, чтобы страница никогда не
// показывала PHP Warning/Notice при неполном контракте контроллера.
$balance  = is_array($balance ?? null) ? $balance : [];
$pollers  = is_array($pollers ?? null) ? $pollers : [];
$forecast = is_array($forecast ?? null) ? $forecast : [];
$forecastNext24h = (int)($forecast['next24h'] ?? 0);
$forecastSteady  = (int)($forecast['steady'] ?? 0);
$forecastNearest = $forecast['nearest_at'] ?? null;
$msk = static function ($dt, string $fmt = 'd.m.Y H:i') {
    $s = (string)($dt ?? '');
    if ($s === '') return '—';
    // Time::msk сам добавляет метку «МСК» (третий аргумент appendLabel по умолчанию true)
    return class_exists('Time') ? Time::msk($s, $fmt) : $s;
};
$tabs = ['overview' => 'Обзор', 'monitors' => 'Активные проверки', 'history' => 'История расхода', 'settings' => 'Настройки'];
$xsOn = (int)($xs['enabled'] ?? 0) === 1;
$sumOk = !empty($summary['ok']);
$today = $sumOk ? ($summary['today'] ?? []) : [];
$quota = (int)($xs['daily_quota_limit'] ?? 0);
$charged = (int)($today['charged'] ?? 0);
$pct = $quota > 0 ? min(100, (int)round($charged / $quota * 100)) : 0;
$pctClass = $pct >= 90 ? 'xmlstock-progress__bar--danger' : ($pct >= 70 ? 'xmlstock-progress__bar--warn' : '');
$balStr = '—'; $balLow = false; $balChecked = '';
if (is_array($balance) && isset($balance['balance'])) {
    $cur = (string)($balance['currency'] ?? 'RUB');
    $balStr = number_format((float)$balance['balance'], 0, '.', ' ') . ' ' . ($cur === 'RUB' ? '₽' : $cur);
    $balChecked = (string)($balance['last_checked_at'] ?? '');
    $balLow = ((string)($balance['status'] ?? '') === 'low') || ((float)$balance['balance'] < 100);
}
$fcOk = !empty($forecast['ok']);
$actOk = !empty($activation['ok']);
$activePollers = 0;
foreach ($pollers as $p) if (empty($p['paused']) && empty($p['stopped'])) $activePollers++;
$activeMonitors = $fcOk ? (int)$forecast['active_monitors'] : (int)($activation['monitors_active'] ?? 0);

/** Прогресс negative-серии: streak/total + цветовая зона (§6.2.G). */
$seriesCell = static function (array $m) use ($e): string {
    $pol = json_decode((string)($m['policy_snapshot_json'] ?? ''), true) ?: [];
    $probable = max(1, (int)($pol['probable_negative_count'] ?? 3));
    $total = $probable + max(0, (int)($pol['insurance_negative_count'] ?? 3));
    $streak = max(0, (int)($m['negative_streak'] ?? 0));
    $stateS = (string)$m['state'];
    $zone = 'xmlstock-series--0';
    if ($stateS === 'banned') $zone = 'xmlstock-series--confirmed';
    elseif ($streak >= $probable || $stateS === 'insurance') $zone = 'xmlstock-series--probable';
    elseif ($streak >= 1) $zone = 'xmlstock-series--low';
    $w = $total > 0 ? min(100, (int)round($streak / $total * 100)) : 0;
    return '<span class="xmlstock-series-progress ' . $zone . '" title="Отрицательных подряд: ' . $streak . ' из ' . $total . ' (порог подозрения ' . $probable . ')">'
        . '<span class="xmlstock-series-progress__track"><span class="xmlstock-series-progress__fill" style="width:' . $w . '%"></span></span>'
        . '<b>' . $streak . ' / ' . $total . '</b></span>';
};
$stateBadge = static function (array $m) use ($e): string {
    $s = (string)$m['state'];
    $label = XmlStockLabels::monitorState($s);
    $tone = XmlStockLabels::monitorTone($s);
    $blk = (string)($m['blocked_reason'] ?? '');
    $out = '<span class="xmlstock-monitor-state xmlstock-monitor-state--' . $tone . '" title="' . $e($s) . '">' . $e($label) . '</span>';
    if ($blk !== '' && in_array($s, ['waiting_initial_delay', 'monitoring', 'confirming', 'insurance'], true)) {
        $out .= '<br><span class="xmlstock-monitor-state xmlstock-monitor-state--warn" title="blocked_reason: ' . $e($blk) . '">Заблокирован: ' . $e(XmlStockLabels::blockedReason($blk)) . '</span>';
    }
    return $out;
};
$tabUrl = static fn(string $t) => '/xmlstock?tab=' . $t;
?>
<div class="xmlstock-page">

<h1 class="page-title">XMLStock</h1>
<p class="muted">Контроль платных запросов, ожидания индексации и мониторинга выпадения из индекса.
Платные запросы делаются в стадиях ожидания индексации, финального мониторинга переезда,
мониторинга бана и при ручных проверках — каждый учитывается в журнале ниже.</p>

<?php if (!empty($alerts)): ?>
<div class="xmlstock-alerts">
    <?php foreach ($alerts as $al): ?>
    <div class="xmlstock-alert <?= ($al['level'] ?? '') === 'error' ? 'xmlstock-alert--error' : '' ?>">⚠ <?= $e($al['text']) ?></div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ===================== KPI (§6.2.B) ===================== -->
<div class="xmlstock-kpi-grid">
    <div class="xmlstock-kpi <?= $xsOn ? '' : 'xmlstock-kpi--alert' ?>">
        <div class="xmlstock-kpi__label">Сервис
            <span class="pill <?= $xsOn ? 'pill-ok' : 'pill-warn' ?>"><?= $xsOn ? 'Включён' : 'Выключен' ?></span>
        </div>
        <div class="xmlstock-kpi__value"><?= $xsOn ? 'Работает' : 'Остановлен' ?></div>
        <div class="xmlstock-kpi__sub"><?= $xsOn ? 'Платные запросы разрешены' : 'Fallback для индексации, мониторы бана заблокированы' ?></div>
        <div class="xmlstock-kpi__action">
            <form method="post" action="/xmlstock/toggle-enabled" onsubmit="return confirm('<?= $xsOn ? 'Выключить XMLStock? Мониторы бана перестанут проверяться (без роста серии), индексация уйдёт на бесплатный fallback.' : 'Включить XMLStock? Платные запросы возобновятся.' ?>');">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <input type="hidden" name="tab" value="<?= $e($tab) ?>">
                <input type="hidden" name="enable" value="<?= $xsOn ? 0 : 1 ?>">
                <input type="text" name="comment" placeholder="причина (обязательно)" required>
                <button type="submit" class="btn btn-sm <?= $xsOn ? 'btn-danger' : 'btn-primary' ?>" style="margin-top:6px;"><?= $xsOn ? 'Выключить (стоп-кран)' : 'Включить' ?></button>
            </form>
        </div>
    </div>

    <div class="xmlstock-kpi <?= $balLow ? 'xmlstock-kpi--alert' : '' ?>">
        <div class="xmlstock-kpi__label">Баланс
            <?php if ($balLow): ?><span class="pill pill-warn">Низкий</span><?php endif; ?>
        </div>
        <div class="xmlstock-kpi__value"><?= $e($balStr) ?></div>
        <div class="xmlstock-kpi__sub">Проверен: <?= $e($msk($balChecked)) ?></div>
    </div>

    <div class="xmlstock-kpi">
        <div class="xmlstock-kpi__label">Расход сегодня</div>
        <?php if ($sumOk): ?>
        <div class="xmlstock-kpi__value"><?= $charged ?><?= $quota > 0 ? ' <span class="muted small">/ ' . $quota . '</span>' : '' ?></div>
        <div class="xmlstock-kpi__sub">Выполнено <?= (int)($today['completed'] ?? 0) ?><?php if ((int)($today['ambiguous'] ?? 0) > 0): ?> · <span class="pill pill-warn">неопределённых <?= (int)$today['ambiguous'] ?></span><?php endif; ?></div>
        <?php if ($quota > 0): ?><div class="xmlstock-progress"><div class="xmlstock-progress__bar <?= $pctClass ?>" style="width:<?= $pct ?>%"></div></div><?php endif; ?>
        <?php else: ?>
        <div class="xmlstock-kpi__value">—</div>
        <div class="xmlstock-kpi__sub">⚠ Не удалось получить показатель</div>
        <?php endif; ?>
    </div>

    <div class="xmlstock-kpi">
        <div class="xmlstock-kpi__label">Прогноз 24 часа</div>
        <?php if ($fcOk): ?>
        <div class="xmlstock-kpi__value">≈ <?= $forecastNext24h ?></div>
        <div class="xmlstock-kpi__sub">Штатно (после начальной задержки): ≈ <?= $forecastSteady ?>/сутки</div>
        <?php else: ?>
        <div class="xmlstock-kpi__value">—</div>
        <div class="xmlstock-kpi__sub">⚠ Не удалось получить показатель</div>
        <?php endif; ?>
    </div>

    <div class="xmlstock-kpi">
        <div class="xmlstock-kpi__label">Активный контроль</div>
        <div class="xmlstock-kpi__value"><?= (int)$activePollers ?> + <?= (int)$activeMonitors ?></div>
        <div class="xmlstock-kpi__sub">Джобы в опросе + мониторы бана<br>Ближайшая проверка: <?= $e($fcOk && $forecastNearest ? $msk($forecastNearest, 'd.m H:i') : '—') ?></div>
    </div>
</div>

<!-- ===================== Вкладки (§6.2.C) ===================== -->
<nav class="xmlstock-tabs">
    <?php foreach ($tabs as $tKey => $tLabel): ?>
    <a href="<?= $tabUrl($tKey) ?>" class="<?= $tab === $tKey ? 'is-active' : '' ?>"><?= $e($tLabel) ?></a>
    <?php endforeach; ?>
</nav>

<?php if ($tab === 'overview'): ?>
<!-- ===================== ОБЗОР (§6.2.D) ===================== -->
<div class="card">
    <h2>Расход сегодня по назначениям</h2>
    <?php if (!empty($consumers['ok'])): ?>
    <div class="xmlstock-summary-grid">
        <?php foreach ($consumers['by_purpose'] as $pKey => $c): ?>
        <div class="xmlstock-consumer">
            <div class="xmlstock-consumer__name"><?= $e(XmlStockLabels::purpose($pKey)) ?></div>
            <div class="xmlstock-consumer__num"><?= (int)$c['charged'] ?></div>
            <div class="muted small">выполнено <?= (int)$c['completed'] ?><?= (int)$c['ambiguous'] > 0 ? ' · неопределённых ' . (int)$c['ambiguous'] : '' ?><?= (int)$c['failed_before_http'] > 0 ? ' · сбоев до запроса ' . (int)$c['failed_before_http'] : '' ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="xmlstock-alert xmlstock-alert--error">⚠ Не удалось получить показатель расхода по назначениям.</div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Ближайшие платные запросы</h2>
    <?php if (!empty($nextScheduled['ok']) && $nextScheduled['rows']): ?>
    <div class="xmlstock-table-wrap"><table class="kv-table" style="min-width:0;">
        <?php foreach ($nextScheduled['rows'] as $n): ?>
        <tr><th><?= $e($msk($n['at'], 'd.m.Y H:i')) ?></th><td><?= $e($n['who']) ?> — <?= $e($n['what']) ?></td></tr>
        <?php endforeach; ?>
    </table></div>
    <?php elseif (!empty($nextScheduled['ok'])): ?>
    <div class="xmlstock-empty">Запланированных платных запросов нет.</div>
    <?php else: ?>
    <div class="xmlstock-alert xmlstock-alert--error">⚠ Не удалось получить расписание.</div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Мониторинг бана — статус</h2>
    <?php if ($actOk): $as = $activation['settings']; $enr = (int)($as['enrollment_enabled'] ?? 0) === 1; ?>
    <div class="xmlstock-status-card">
        <div class="xmlstock-status-card__row"><span class="xmlstock-status-card__k">Мониторинг новых джоб:</span>
            <span class="pill <?= $enr ? 'pill-ok' : 'pill-warn' ?>"><?= $enr ? 'включён' : 'выключен' ?></span></div>
        <?php if ($enr): ?>
        <div class="xmlstock-status-card__row"><span class="xmlstock-status-card__k">Автоматическое подключение новых джоб:</span>
            <span>джоба #<?= (int)($as['activation_min_job_id'] ?? 0) ?> и новее (активирован <?= $e($msk($as['activation_started_at'] ?? '')) ?>)</span></div>
        <?php endif; ?>
        <div class="xmlstock-status-card__row"><span class="xmlstock-status-card__k">Выполнение проверок:</span>
            <span class="pill <?= (int)($as['processing_enabled'] ?? 0) === 1 ? 'pill-ok' : 'pill-warn' ?>"><?= (int)($as['processing_enabled'] ?? 0) === 1 ? 'работают' : 'приостановлены' ?></span></div>
        <div class="xmlstock-status-card__row"><span class="xmlstock-status-card__k">Счётчики:</span>
            <span>джоб под автоматическим подключением: <b><?= (int)$activation['auto_eligible_jobs'] ?></b> ·
                  мониторов автоматических: <b><?= (int)$activation['monitors_automatic'] ?></b> ·
                  подключённых вручную: <b><?= (int)$activation['monitors_manual'] ?></b> ·
                  активных: <b><?= (int)$activation['monitors_active'] ?></b> ·
                  завершённых: <b><?= (int)$activation['monitors_finished'] ?></b></span></div>
    </div>
    <p class="muted small">Управление активацией, схемой проверок и ручным подключением — во вкладке «Настройки».</p>
    <?php else: ?>
    <div class="xmlstock-alert xmlstock-alert--error">⚠ Не удалось получить статус активации.</div>
    <?php endif; ?>
</div>

<?php elseif ($tab === 'monitors'): ?>
<!-- ===================== АКТИВНЫЕ ПРОВЕРКИ (§6.2.G) ===================== -->
<div class="card">
    <h2>Мониторы бана — активные (<?= count($monitorsActive['rows'] ?? []) ?>)</h2>
    <?php if (empty($monitorsActive['ok'])): ?>
    <div class="xmlstock-alert xmlstock-alert--error">⚠ Не удалось получить список мониторов.</div>
    <?php elseif (!$monitorsActive['rows']): ?>
    <div class="xmlstock-empty">Активных мониторов нет. Новые появятся автоматически после первой подтверждённой индексации новой джобы (либо через ручное подключение в «Настройках»).</div>
    <?php else: ?>
    <div class="xmlstock-table-wrap">
    <table class="xmlstock-monitor-table">
        <thead><tr>
            <th>Домен</th><th>Джоба</th><th>Статус</th><th>Последний раз в индексе</th>
            <th>Следующая проверка</th><th>Серия</th><th>Запросы сегодня</th><th>Действия</th>
        </tr></thead>
        <tbody>
        <?php foreach ($monitorsActive['rows'] as $m): $mid = (int)$m['id'];
            $cnt = $monitorsActive['counts'][$mid] ?? ['today' => 0, 'total' => 0];
            $hl = !empty($highlightMonitorId) && $highlightMonitorId === $mid; ?>
        <tr id="monitor-<?= $mid ?>" class="<?= $hl ? 'is-highlighted' : '' ?>">
            <td class="xmlstock-domain"><?= $e($m['domain']) ?></td>
            <td><a href="/jobs/show?id=<?= (int)$m['source_job_id'] ?>">#<?= (int)$m['source_job_id'] ?></a></td>
            <td><?= $stateBadge($m) ?></td>
            <td><?= $e($msk($m['last_positive_at'] ?? '', 'd.m.Y H:i')) ?><?php if (!empty($m['last_positive_pages'])): ?><br><span class="muted small"><?= (int)$m['last_positive_pages'] ?> стр.</span><?php endif; ?></td>
            <td><?= $e($msk($m['next_check_at'] ?? '', 'd.m.Y H:i')) ?></td>
            <td><?= $seriesCell($m) ?></td>
            <td><?= (int)$cnt['today'] ?> <span class="muted small">/ всего <?= (int)$cnt['total'] ?></span></td>
            <td>
                <div class="xmlstock-monitor-actions">
                    <form method="post" action="/xmlstock/monitor/check-now">
                        <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                        <input type="hidden" name="tab" value="monitors">
                        <input type="hidden" name="monitor_id" value="<?= $mid ?>">
                        <button type="submit" class="btn btn-sm btn-primary">Проверить сейчас</button>
                    </form>
                    <details>
                        <summary class="btn btn-sm btn-secondary">Ещё…</summary>
                        <div class="xmlstock-row-details">
                            <div class="xmlstock-monitor-actions">
                            <?php if ((string)$m['state'] === 'paused'): ?>
                                <form method="post" action="/xmlstock/monitor/resume">
                                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                                    <input type="hidden" name="tab" value="monitors">
                                    <input type="hidden" name="monitor_id" value="<?= $mid ?>">
                                    <button type="submit" name="resume_mode" value="continue" class="btn btn-sm btn-secondary">Возобновить (продолжить серию)</button>
                                    <button type="submit" name="resume_mode" value="reset" class="btn btn-sm btn-secondary">Возобновить со сбросом серии</button>
                                </form>
                            <?php else: ?>
                                <form method="post" action="/xmlstock/monitor/pause">
                                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                                    <input type="hidden" name="tab" value="monitors">
                                    <input type="hidden" name="monitor_id" value="<?= $mid ?>">
                                    <button type="submit" class="btn btn-sm btn-secondary">Пауза</button>
                                </form>
                            <?php endif; ?>
                                <button type="button" class="btn btn-sm btn-danger" onclick="xmlstockOpenStop(<?= $mid ?>, '<?= $e($m['domain']) ?>')">Остановить…</button>
                                <a class="btn btn-sm btn-secondary" href="/xmlstock?tab=history&monitor_id=<?= $mid ?>">История</a>
                            </div>
                        </div>
                    </details>
                    <details>
                        <summary class="btn btn-sm btn-secondary">Подробнее</summary>
                        <div class="xmlstock-row-details">
                            <table class="kv-table">
                                <tr><th>Monitor ID</th><td>#<?= $mid ?></td></tr>
                                <tr><th>Подключение</th><td><?= $e(XmlStockLabels::enrollmentSource($m['enrollment_source'] ?? 'automatic')) ?></td></tr>
                                <tr><th>Версия правил</th><td>v<?= (int)$m['policy_version'] ?></td></tr>
                                <tr><th>Впервые в индексе</th><td><?= $e($msk($m['indexed_at'] ?? '')) ?></td></tr>
                                <tr><th>Первая пропажа</th><td><?= $e($msk($m['first_negative_at'] ?? '')) ?></td></tr>
                                <tr><th>Серия №</th><td><?= (int)($m['series_no'] ?? 0) ?></td></tr>
                                <tr><th>Запросов всего</th><td><?= (int)$cnt['total'] ?></td></tr>
                                <?php if (!empty($m['last_error'])): ?><tr><th>Последняя тех. ошибка</th><td class="muted"><?= $e($m['last_error']) ?></td></tr><?php endif; ?>
                            </table>
                            <?php $checks = $monitorChecks[$mid] ?? []; if ($checks): ?>
                            <p class="small" style="margin:10px 0 4px;"><b>Последние проверки</b></p>
                            <table class="kv-table">
                                <?php foreach ($checks as $ch): ?>
                                <tr><th><?= $e($msk($ch['checked_at'] ?? '', 'd.m H:i')) ?></th>
                                    <td><?= $e(XmlStockLabels::phase($ch['phase'] ?? '')) ?> — <?= $e(XmlStockLabels::result($ch['result'] ?? '')) ?><?php if (isset($ch['pages_indexed']) && $ch['pages_indexed'] !== null): ?> (<?= (int)$ch['pages_indexed'] ?> стр.)<?php endif; ?></td></tr>
                                <?php endforeach; ?>
                            </table>
                            <?php endif; ?>
                        </div>
                    </details>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>История мониторов — завершённые (<?= count($monitorsTerminal['rows'] ?? []) ?>)</h2>
    <?php if (!empty($monitorsTerminal['rows'])): ?>
    <div class="xmlstock-table-wrap">
    <table class="xmlstock-monitor-table">
        <thead><tr><th>Домен</th><th>Джоба</th><th>Статус</th><th>Последний раз в индексе</th><th>Серия</th><th>Подключение</th></tr></thead>
        <tbody>
        <?php foreach ($monitorsTerminal['rows'] as $m): ?>
        <tr>
            <td class="xmlstock-domain"><?= $e($m['domain']) ?></td>
            <td><a href="/jobs/show?id=<?= (int)$m['source_job_id'] ?>">#<?= (int)$m['source_job_id'] ?></a></td>
            <td><?= $stateBadge($m) ?></td>
            <td><?= $e($msk($m['last_positive_at'] ?? '', 'd.m.Y H:i')) ?></td>
            <td><?= $seriesCell($m) ?></td>
            <td class="muted small"><?= $e(XmlStockLabels::enrollmentSource($m['enrollment_source'] ?? 'automatic')) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php else: ?>
    <div class="xmlstock-empty">Завершённых мониторов пока нет.</div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Джобы в опросе индексации (<?= count($pollers) ?>)</h2>
    <?php if ($pollers): ?>
    <div class="xmlstock-table-wrap">
    <table class="xmlstock-monitor-table">
        <thead><tr><th>Джоба</th><th>Домен</th><th>Стадия</th><th>Состояние</th><th>Следующий запрос</th><th>≈/сутки</th><th>Действия</th></tr></thead>
        <tbody>
        <?php foreach ($pollers as $p): ?>
        <tr>
            <td><a href="/jobs/show?id=<?= (int)$p['id'] ?>">#<?= (int)$p['id'] ?></a></td>
            <td class="xmlstock-domain"><?= $e($p['new_domain']) ?></td>
            <td><?= $e(XmlStockLabels::purpose((string)$p['stage'] === 'final_monitoring' ? 'final_monitoring' : 'index_watching')) ?></td>
            <td><?php if (!empty($p['stopped'])): ?><span class="pill pill-error">остановлена</span>
                <?php elseif (!empty($p['paused'])): ?><span class="pill pill-warn">на паузе</span>
                <?php else: ?><span class="pill pill-ok">опрашивается</span><?php endif; ?></td>
            <td><?= $e(!empty($p['paused']) ? '—' : $msk($p['next_run_at'] ?? '', 'd.m H:i')) ?></td>
            <td><?= (int)($p['est_per_day'] ?? 0) ?></td>
            <td>
                <div class="xmlstock-monitor-actions">
                <?php if (!empty($p['paused'])): ?>
                    <form method="post" action="/xmlstock/resume-job">
                        <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                        <input type="hidden" name="tab" value="monitors">
                        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-secondary">Возобновить</button>
                    </form>
                <?php elseif (empty($p['stopped'])): ?>
                    <form method="post" action="/xmlstock/pause-job">
                        <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                        <input type="hidden" name="tab" value="monitors">
                        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-secondary">Пауза</button>
                    </form>
                <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <div class="xmlstock-actions" style="margin-top:10px;">
        <form method="post" action="/xmlstock/pause-all" onsubmit="return confirm('Поставить на паузу опрос всех джоб?');">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="tab" value="monitors">
            <button type="submit" class="btn btn-sm btn-secondary">Пауза всех</button>
        </form>
        <form method="post" action="/xmlstock/resume-all">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="tab" value="monitors">
            <button type="submit" class="btn btn-sm btn-secondary">Возобновить все</button>
        </form>
    </div>
    <?php else: ?>
    <div class="xmlstock-empty">Джоб в polling-стадиях нет.</div>
    <?php endif; ?>
</div>

<!-- Модал остановки монитора (§6.2.G): обязательная причина -->
<div class="xmlstock-modal" id="xmlstock-stop-modal">
    <div class="xmlstock-modal__box">
        <h3>Остановить монитор</h3>
        <p class="muted small">Мониторинг домена <b id="xmlstock-stop-domain"></b> будет остановлен навсегда (state → «Остановлен»). Возобновить нельзя — только подключить заново вручную.</p>
        <form method="post" action="/xmlstock/monitor/stop">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="tab" value="monitors">
            <input type="hidden" name="monitor_id" id="xmlstock-stop-id" value="">
            <label class="small">Причина (обязательно):
                <textarea name="comment" required placeholder="почему останавливаем"></textarea>
            </label>
            <div class="xmlstock-actions">
                <button type="submit" class="btn btn-sm btn-danger">Остановить монитор</button>
                <button type="button" class="btn btn-sm btn-secondary" onclick="xmlstockCloseStop()">Отмена</button>
            </div>
        </form>
    </div>
</div>
<script>
function xmlstockOpenStop(id, domain){
    document.getElementById('xmlstock-stop-id').value = id;
    document.getElementById('xmlstock-stop-domain').textContent = domain;
    document.getElementById('xmlstock-stop-modal').classList.add('is-open');
}
function xmlstockCloseStop(){
    document.getElementById('xmlstock-stop-modal').classList.remove('is-open');
}
document.getElementById('xmlstock-stop-modal').addEventListener('click', function(e){ if (e.target === this) xmlstockCloseStop(); });
</script>

<?php elseif ($tab === 'history'): ?>
<!-- ===================== ИСТОРИЯ (§6.2.H) ===================== -->
<div class="card">
    <h2>История XMLStock-запросов</h2>
    <form method="get" action="/xmlstock">
        <input type="hidden" name="tab" value="history">
        <div class="xmlstock-filter-grid">
            <label>Период
                <select name="period">
                    <?php foreach (['today' => 'Сегодня', '24h' => '24 часа', '7d' => '7 дней', 'all' => 'Всё время'] as $pv => $pl): ?>
                    <option value="<?= $pv ?>" <?= ($histFilters['period'] ?? 'today') === $pv ? 'selected' : '' ?>><?= $pl ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Назначение
                <select name="purpose">
                    <option value="">— любое —</option>
                    <?php foreach (XmlStockLabels::PURPOSE as $pv => $pl): ?>
                    <option value="<?= $pv ?>" <?= ($histFilters['purpose'] ?? '') === $pv ? 'selected' : '' ?>><?= $e($pl) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Домен
                <input type="text" name="domain" value="<?= $e($histFilters['domain'] ?? '') ?>" placeholder="часть домена">
            </label>
            <label>Джоба (ID)
                <input type="text" name="job_id" value="<?= $e($histFilters['job_id'] ?? '') ?>" placeholder="#">
            </label>
            <label>Monitor (ID)
                <input type="text" name="monitor_id" value="<?= $e($histFilters['monitor_id'] ?? '') ?>" placeholder="#">
            </label>
            <label>Результат
                <select name="result">
                    <option value="">— любой —</option>
                    <?php foreach (XmlStockLabels::RESULT as $rv => $rl): ?>
                    <option value="<?= $rv ?>" <?= ($histFilters['result'] ?? '') === $rv ? 'selected' : '' ?>><?= $e($rl) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Состояние выполнения
                <select name="execution_state">
                    <option value="">— любое —</option>
                    <?php foreach (XmlStockLabels::EXECUTION_STATE as $ev => $el): ?>
                    <option value="<?= $ev ?>" <?= ($histFilters['execution_state'] ?? '') === $ev ? 'selected' : '' ?>><?= $e($el) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Инициатор
                <select name="initiated_by">
                    <option value="">— любой —</option>
                    <?php foreach (XmlStockLabels::INITIATED_BY as $iv => $il): ?>
                    <option value="<?= $iv ?>" <?= ($histFilters['initiated_by'] ?? '') === $iv ? 'selected' : '' ?>><?= $e($il) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <div class="xmlstock-filter-actions">
                <button type="submit" class="btn btn-sm btn-primary">Применить</button>
                <a class="btn btn-sm btn-secondary" href="/xmlstock?tab=history">Сбросить</a>
            </div>
        </div>
    </form>

    <?php if (empty($history['ok'])): ?>
    <div class="xmlstock-alert xmlstock-alert--error">⚠ Не удалось получить историю запросов.</div>
    <?php else: ?>
    <p class="muted small">Найдено <?= (int)$history['total'] ?> записей<?= (int)$history['pages'] > 1 ? ' · страница ' . (int)$history['page'] . ' из ' . (int)$history['pages'] : '' ?>.</p>
    <?php if (!$history['rows']): ?>
    <div class="xmlstock-empty">По выбранным фильтрам записей нет.</div>
    <?php else: ?>
    <div class="xmlstock-table-wrap">
    <table class="xmlstock-history-table">
        <thead><tr>
            <th>Время</th><th>Назначение</th><th>Домен</th><th>Джоба</th><th>Monitor</th>
            <th>Результат</th><th>Состояние</th><th>Инициатор</th><th>Стр.</th>
        </tr></thead>
        <tbody>
        <?php foreach ($history['rows'] as $h):
            $es = (string)($h['execution_state'] ?? '');
            $cls = $es === 'ambiguous' ? 'is-ambiguous' : ($es === 'failed_before_http' ? 'is-failed' : ($es === 'completed' ? 'is-completed' : '')); ?>
        <tr class="<?= $cls ?>">
            <td><?= $e($msk($h['requested_at'] ?? '', 'd.m.Y H:i:s')) ?></td>
            <td title="<?= $e($h['purpose'] ?? '') ?>"><?= $e(XmlStockLabels::purpose($h['purpose'] ?? '')) ?><?php if (!empty($h['phase'])): ?><br><span class="muted small"><?= $e(XmlStockLabels::phase($h['phase'])) ?></span><?php endif; ?></td>
            <td class="xmlstock-domain"><?= $e($h['domain'] ?? '') ?></td>
            <td><?php if (!empty($h['source_job_id'])): ?><a href="/jobs/show?id=<?= (int)$h['source_job_id'] ?>">#<?= (int)$h['source_job_id'] ?></a><?php else: ?>—<?php endif; ?></td>
            <td><?php if (!empty($h['monitor_id'])): ?><a href="/xmlstock?tab=monitors&monitor_id=<?= (int)$h['monitor_id'] ?>#monitor-<?= (int)$h['monitor_id'] ?>">#<?= (int)$h['monitor_id'] ?></a><?php else: ?>—<?php endif; ?></td>
            <td title="<?= $e($h['result'] ?? '') ?>"><?= $e(XmlStockLabels::result($h['result'] ?? null)) ?></td>
            <td class="xmlstock-exec" title="<?= $e($es) ?>"><?= $e(XmlStockLabels::executionState($es)) ?></td>
            <td title="<?= $e($h['initiated_by'] ?? '') ?>"><?= $e(XmlStockLabels::initiatedBy($h['initiated_by'] ?? null)) ?></td>
            <td><?= $h['pages_indexed'] !== null ? (int)$h['pages_indexed'] : '—' ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php if ((int)$history['pages'] > 1):
        $qs = $_GET; unset($qs['page']);
        $mkUrl = static fn(int $pg) => '/xmlstock?' . http_build_query(array_merge($qs, ['page' => $pg]));
        $cur = (int)$history['page']; $pages = (int)$history['pages'];
    ?>
    <div class="xmlstock-pagination">
        <?php if ($cur > 1): ?><a href="<?= $e($mkUrl($cur - 1)) ?>">← Назад</a><?php endif; ?>
        <?php
        $shown = [];
        foreach ([1, 2, $cur - 1, $cur, $cur + 1, $pages - 1, $pages] as $pg) {
            if ($pg < 1 || $pg > $pages || isset($shown[$pg])) continue;
            $shown[$pg] = true;
        }
        $prev = 0;
        foreach (array_keys($shown) as $pg): if ($pg - $prev > 1): ?><span class="muted">…</span><?php endif; $prev = $pg; ?>
            <?php if ($pg === $cur): ?><span class="cur"><?= $pg ?></span><?php else: ?><a href="<?= $e($mkUrl($pg)) ?>"><?= $pg ?></a><?php endif; ?>
        <?php endforeach; ?>
        <?php if ($cur < $pages): ?><a href="<?= $e($mkUrl($cur + 1)) ?>">Вперёд →</a><?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
</div>

<?php else: /* settings */ ?>
<!-- ===================== НАСТРОЙКИ (§6.2.E/F) ===================== -->
<?php $bs = $banSettings ?? []; $bp = $banPolicy ?? null; $enr = (int)($bs['enrollment_enabled'] ?? 0) === 1;
      $proc = (int)($bs['processing_enabled'] ?? 0) === 1; ?>
<div class="card">
    <h2>Активация мониторинга бана</h2>
    <div class="xmlstock-status-card">
        <div class="xmlstock-status-card__row"><span class="xmlstock-status-card__k">Мониторинг новых джоб:</span>
            <span class="pill <?= $enr ? 'pill-ok' : 'pill-warn' ?>"><?= $enr ? 'включён' : 'выключен' ?></span></div>
        <?php if ($enr): ?>
        <div class="xmlstock-status-card__row"><span class="xmlstock-status-card__k">Активирован:</span>
            <span><?= $e($msk($bs['activation_started_at'] ?? '')) ?></span></div>
        <div class="xmlstock-status-card__row"><span class="xmlstock-status-card__k">Автоматическое подключение новых джоб:</span>
            <span>джоба #<?= (int)($bs['activation_min_job_id'] ?? 0) ?> и новее</span></div>
        <?php endif; ?>
        <div class="xmlstock-status-card__row"><span class="xmlstock-status-card__k">Выполнение проверок:</span>
            <span class="pill <?= $proc ? 'pill-ok' : 'pill-warn' ?>"><?= $proc ? 'работают' : 'приостановлены' ?></span></div>
    </div>

    <div class="xmlstock-actions">
        <?php if ($enr): ?>
        <form method="post" action="/xmlstock/ban-monitoring/deactivate-new-jobs" onsubmit="return confirm('Отключить мониторинг для новых джоб? Существующие мониторы продолжат работу.');">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="tab" value="settings">
            <button type="submit" class="btn btn-sm btn-secondary">Отключить для новых джоб</button>
        </form>
        <?php else: ?>
        <form method="post" action="/xmlstock/ban-monitoring/activate-new-jobs" onsubmit="return confirm('Включить мониторинг ТОЛЬКО для новых джоб (будет создана новая версия правил мониторинга)?');">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="tab" value="settings">
            <button type="submit" class="btn btn-sm btn-primary">Включить только для новых джоб</button>
        </form>
        <?php endif; ?>
        <form method="post" action="/xmlstock/ban-monitoring/toggle-processing">
            <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
            <input type="hidden" name="tab" value="settings">
            <input type="hidden" name="processing" value="<?= $proc ? 0 : 1 ?>">
            <input type="text" name="comment" placeholder="комментарий (для паузы)" <?= $proc ? 'required' : '' ?>>
            <button type="submit" class="btn btn-sm <?= $proc ? 'btn-danger' : 'btn-primary' ?>"><?= $proc ? 'Приостановить проверки' : 'Возобновить проверки' ?></button>
        </form>
    </div>

    <details style="margin-top:12px;">
        <summary class="btn btn-sm btn-secondary">Подключить существующую джобу (по job id)</summary>
        <div class="xmlstock-row-details">
            <p class="muted small">Осознанное исключение из «только новые джобы»: монитор ставится существующей refresh-джобе строго по указанному id. Выполняется 1 XMLStock-запрос; монитор ставится только если новый домен сейчас в индексе (один negative — не бан).</p>
            <form method="post" action="/xmlstock/ban-monitoring/bootstrap-jobs" onsubmit="return confirm('Подключить мониторинг к указанным джобам? Будет выполнен реальный XMLStock-запрос по каждой.');">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <input type="hidden" name="tab" value="settings">
                <div class="xmlstock-form-grid">
                    <label>Job id (через запятую)
                        <input type="text" name="job_ids" placeholder="например 189,190"></label>
                    <label>Комментарий (обязателен для боевого)
                        <input type="text" name="comment" placeholder="причина подключения"></label>
                    <label class="small"><input type="checkbox" name="dry_run" value="1"> сухой прогон (без записи и без XMLStock)</label>
                </div>
                <button type="submit" class="btn btn-sm btn-secondary">Подключить</button>
            </form>
        </div>
    </details>

    <details class="technical-details" style="margin-top:8px;">
        <summary class="btn btn-sm btn-secondary">Подробности (технические)</summary>
        <div class="xmlstock-row-details">
            <table class="kv-table">
                <tr><th>activation_generation</th><td><?= (int)($bs['activation_generation'] ?? 0) ?></td></tr>
                <tr><th>activation_min_job_id</th><td><?= $bs['activation_min_job_id'] !== null ? (int)$bs['activation_min_job_id'] : '—' ?></td></tr>
                <tr><th>activation_started_at (UTC)</th><td><?= $e($bs['activation_started_at'] ?? '—') ?></td></tr>
                <tr><th>policy_version</th><td><?= (int)($bs['policy_version'] ?? 0) ?></td></tr>
                <tr><th>cron_batch_limit</th><td><?= (int)($bs['cron_batch_limit'] ?? 0) ?></td></tr>
            </table>
        </div>
    </details>
</div>

<div class="card">
    <h2>Схема проверок</h2>
    <?php if ($bp): ?>
    <div class="xmlstock-policy-summary">
        Первая проверка через <b><?= (int)$bp->initialDelayMinutes() ?> мин</b> (≈<?= round($bp->initialDelayMinutes() / 60, 1) ?> ч) после подтверждённой индексации<br>
        Штатно каждые <b><?= (int)$bp->regularIntervalMinutes() ?> мин</b><br>
        Предупреждение после <b><?= (int)$bp->probableNegativeCount() ?></b> отрицательных ответов подряд<br>
        Затем <b><?= (int)$bp->insuranceNegativeCount() ?></b> страховочных проверок каждые <b><?= (int)$bp->insuranceIntervalMinutes() ?> мин</b>
    </div>
    <div class="xmlstock-calc">
        Итого: подтверждённый бан после <b><?= (int)$bp->probableNegativeCount() + (int)$bp->insuranceNegativeCount() ?></b> отрицательных подряд ·
        минимальное время подтверждения ≈ <b><?= (int)$bp->insuranceNegativeCount() * (int)$bp->insuranceIntervalMinutes() ?> мин</b> после подозрения ·
        максимум запросов в одной серии: <b><?= (int)$bp->probableNegativeCount() + (int)$bp->insuranceNegativeCount() ?></b>
    </div>
    <?php endif; ?>
    <details>
        <summary class="btn btn-sm btn-secondary">Изменить схему…</summary>
        <div class="xmlstock-row-details">
            <p class="muted small"><b>Изменения применяются только к новым monitor.</b> Существующие продолжают работать по своему снимку схемы.</p>
            <form method="post" action="/xmlstock/ban-monitoring/save-policy">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                <input type="hidden" name="tab" value="settings">
                <p class="small" style="margin:8px 0 2px;"><b>Старт и штатный контроль</b></p>
                <div class="xmlstock-form-grid">
                    <label>Первая проверка через, мин
                        <input type="number" name="initial_delay_minutes" min="1" value="<?= (int)($bs['initial_delay_minutes'] ?? 720) ?>"></label>
                    <label>Штатный интервал, мин
                        <input type="number" name="regular_interval_minutes" min="1" value="<?= (int)($bs['regular_interval_minutes'] ?? 30) ?>"></label>
                </div>
                <p class="small" style="margin:8px 0 2px;"><b>Подозрение и подтверждение бана</b></p>
                <div class="xmlstock-form-grid">
                    <label>Отрицательных до подозрения
                        <input type="number" name="probable_negative_count" min="1" value="<?= (int)($bs['probable_negative_count'] ?? 3) ?>"></label>
                    <label>Интервал подтверждения, мин
                        <input type="number" name="confirm_interval_minutes" min="1" value="<?= (int)($bs['confirm_interval_minutes'] ?? 10) ?>"></label>
                    <label>Страховочных проверок
                        <input type="number" name="insurance_negative_count" min="0" value="<?= (int)($bs['insurance_negative_count'] ?? 3) ?>"></label>
                    <label>Интервал страховочных, мин
                        <input type="number" name="insurance_interval_minutes" min="1" value="<?= (int)($bs['insurance_interval_minutes'] ?? 10) ?>"></label>
                </div>
                <p class="small" style="margin:8px 0 2px;"><b>Технические</b></p>
                <div class="xmlstock-form-grid">
                    <label>Повтор после тех. ошибки, мин
                        <input type="number" name="technical_error_retry_minutes" min="1" value="<?= (int)($bs['technical_error_retry_minutes'] ?? 30) ?>"></label>
                    <label>Размер пакета проверок
                        <input type="number" name="cron_batch_limit" min="1" value="<?= (int)($bs['cron_batch_limit'] ?? 20) ?>"></label>
                    <label>Повтор Telegram, мин
                        <input type="number" name="telegram_retry_minutes" min="1" value="<?= (int)($bs['telegram_retry_minutes'] ?? 10) ?>"></label>
                    <label>Макс. попыток Telegram
                        <input type="number" name="telegram_max_attempts" min="1" value="<?= (int)($bs['telegram_max_attempts'] ?? 20) ?>"></label>
                </div>
                <label class="small">Комментарий к изменению
                    <input type="text" name="comment" placeholder="зачем меняем схему"></label>
                <div class="xmlstock-actions" style="margin-top:8px;">
                    <button type="submit" class="btn btn-sm btn-primary">Сохранить схему</button>
                </div>
            </form>
        </div>
    </details>
</div>
<?php endif; ?>

</div><!-- /.xmlstock-page -->
