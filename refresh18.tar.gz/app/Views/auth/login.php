<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Refresh Panel - Вход</title>
<link rel="stylesheet" href="/assets/admin.css">
</head>
<body class="login-body">
<div class="login-card">
    <h1>🔄 Refresh Panel</h1>
    <?php if (!empty($error)): ?>
        <div class="hub-flash hub-flash--error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" action="/login">
        <label>Логин<input type="text" name="username" autofocus required></label>
        <label>Пароль<input type="password" name="password" required></label>
        <button type="submit" class="btn btn-primary">Войти</button>
    </form>
</div>
</body>
</html>
