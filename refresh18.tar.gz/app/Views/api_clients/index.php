<?php
/**
 * /api-clients — UI управления API-ключами.
 * @var array $rows
 * @var ?string $newSecret
 * @var array $scopeList key=>description
 */
?>
<div class="page-header">
    <h1>🔑 API-ключи</h1>
    <p class="muted">Внешние потребители refresh-panel'и (Casino Panel и т.п.) используют эти ключи для доступа к <code>/api/v1/*</code> endpoint'ам.</p>
</div>

<?php if (!empty($newSecret)): ?>
<div class="card" style="border:2px solid #f59e0b;background:rgba(245,158,11,.08);margin-bottom:18px">
    <h2 style="margin-top:0;color:#f59e0b">⚠️ Скопируй этот ключ сейчас — повторно он показан не будет</h2>
    <input type="text" value="<?= htmlspecialchars($newSecret, ENT_QUOTES) ?>"
           readonly onclick="this.select()"
           style="width:100%;font-family:monospace;font-size:14px;padding:10px;background:#0b1220;color:#fbbf24;border:1px solid #f59e0b;border-radius:6px">
    <p class="muted" style="margin-top:8px;font-size:13px">Передай его как <code>Authorization: Bearer &lt;ключ&gt;</code> в запросах от потребителя. После закрытия страницы он больше не будет доступен — придётся создать новый.</p>
</div>
<?php endif; ?>

<div class="card">
    <h2>Создать новый ключ</h2>
    <form method="post" action="/api-clients/create">
        <div class="form-row">
            <label>Имя клиента (для UI)</label>
            <input type="text" name="label" placeholder="casino-panel-vps-95.129.234.20" required style="font-family:monospace">
        </div>
        <div class="form-row">
            <label>Scopes</label>
            <div style="background:#0c1c2c;padding:10px;border-radius:6px">
                <label style="display:block;margin-bottom:8px;font-weight:600">
                    <input type="checkbox" name="scopes[]" value="*"> <code>*</code> — все scopes (для админ-клиентов)
                </label>
                <hr style="border-color:#1e293b;margin:8px 0">
                <?php foreach ($scopeList as $key => $desc): ?>
                    <label style="display:block;margin-bottom:6px">
                        <input type="checkbox" name="scopes[]" value="<?= htmlspecialchars($key) ?>">
                        <code><?= htmlspecialchars($key) ?></code> — <?= htmlspecialchars($desc) ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="form-row">
            <label>Заметка (опционально)</label>
            <input type="text" name="note" placeholder="например: вид VPS, дата выдачи, ответственный">
        </div>
        <button class="btn btn-primary" type="submit">Создать ключ</button>
    </form>
</div>

<div class="card" style="margin-top:18px">
    <div style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Существующие ключи (<?= count($rows) ?>)</h2>
        <a href="/api-clients/test" class="btn">🧪 Открыть тест-страницу</a>
    </div>

    <?php if (empty($rows)): ?>
        <p class="muted">Пока нет ни одного ключа.</p>
    <?php else: ?>
        <table style="width:100%;border-collapse:collapse;margin-top:14px;font-size:13px">
            <thead>
            <tr style="border-bottom:2px solid #334155">
                <th align="left" style="padding:8px">ID</th>
                <th align="left" style="padding:8px">Имя</th>
                <th align="left" style="padding:8px">Prefix</th>
                <th align="left" style="padding:8px">Scopes</th>
                <th align="left" style="padding:8px">Last used</th>
                <th align="left" style="padding:8px">Статус</th>
                <th align="left" style="padding:8px">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r):
                $isRevoked = !empty($r['revoked_at']);
            ?>
                <tr style="border-bottom:1px solid #1e293b;<?= $isRevoked ? 'opacity:.5' : '' ?>">
                    <td style="padding:8px"><?= (int)$r['id'] ?></td>
                    <td style="padding:8px;font-family:monospace"><?= htmlspecialchars($r['label']) ?>
                        <?php if (!empty($r['note'])): ?>
                            <br><small class="muted"><?= htmlspecialchars(mb_substr($r['note'], 0, 80)) ?></small>
                        <?php endif; ?>
                    </td>
                    <td style="padding:8px;font-family:monospace;color:#3b82f6"><?= htmlspecialchars($r['key_prefix']) ?>…</td>
                    <td style="padding:8px;font-family:monospace;font-size:11px">
                        <?php foreach (preg_split('~[,\s]+~', trim($r['scopes'])) ?: [] as $s):
                            if ($s === '') continue; ?>
                            <span style="background:#1e293b;padding:2px 6px;border-radius:3px;display:inline-block;margin:1px"><?= htmlspecialchars($s) ?></span>
                        <?php endforeach; ?>
                    </td>
                    <td style="padding:8px;font-size:11px">
                        <?php if ($r['last_used_at']): ?>
                            <?= htmlspecialchars($r['last_used_at']) ?>
                            <?php if ($r['last_used_ip']): ?>
                                <br><span class="muted">из <?= htmlspecialchars($r['last_used_ip']) ?></span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="muted">никогда</span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:8px">
                        <?php if ($isRevoked): ?>
                            <span style="color:#ef4444">⊘ revoked<br><small><?= htmlspecialchars($r['revoked_at']) ?></small></span>
                        <?php else: ?>
                            <span style="color:#3fb950">✓ активен</span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:8px">
                        <?php if ($isRevoked): ?>
                            <form method="post" action="/api-clients/unrevoke" style="display:inline">
                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                <button class="btn small-btn" type="submit">Восстановить</button>
                            </form>
                        <?php else: ?>
                            <form method="post" action="/api-clients/revoke" style="display:inline"
                                  onsubmit="return confirm('Заблокировать ключ?')">
                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                <button class="btn small-btn" type="submit">⊘ Revoke</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
