<?php
/**
 * /api-clients/test — встроенная страница для теста API.
 * Открываешь, вводишь api_key, тыкаешь кнопки, видишь ответы JSON.
 */
?>
<style>
    .api-test-card{background:#0f172a;border:1px solid #334155;border-radius:10px;padding:14px;margin-bottom:14px}
    .api-test-card h3{margin:0 0 8px 0;font-size:15px}
    .api-test-card code{background:#1e293b;padding:2px 6px;border-radius:3px;font-size:12px;color:#3b82f6}
    .api-test-row{display:flex;gap:8px;align-items:center;margin-bottom:6px;flex-wrap:wrap}
    .api-test-row input{padding:6px 10px;border:1px solid #334155;background:#0b1220;color:#e6edf3;border-radius:4px;font-family:monospace;font-size:13px}
    .api-test-row label{font-size:12px;color:#9aa6b2}
    .api-test-resp{background:#0b1220;border:1px solid #1e293b;border-radius:6px;padding:10px;margin-top:8px;font-family:monospace;font-size:12px;overflow-x:auto;white-space:pre-wrap;max-height:400px;overflow-y:auto}
    .api-test-resp-ok{border-color:#3fb950;color:#86efac}
    .api-test-resp-err{border-color:#ef4444;color:#fca5a5}
    .api-test-status{padding:2px 8px;border-radius:3px;font-size:11px;font-weight:bold;margin-left:8px}
    .api-test-status.s2xx{background:#3fb950;color:#0a1c0e}
    .api-test-status.s4xx{background:#ef4444;color:#fff}
    .api-test-status.s5xx{background:#a855f7;color:#fff}
    .api-test-elapsed{color:#9aa6b2;font-size:11px;margin-left:6px}
</style>

<div class="page-header">
    <h1>🧪 Тест API</h1>
    <p class="muted">Открой в браузере. Вставь свой API-ключ из <a href="/api-clients">списка</a>. Тыкай кнопки. Видишь ответы.</p>
</div>

<div class="card">
    <h2>Настройки</h2>
    <div class="api-test-row">
        <label style="min-width:80px">API-ключ:</label>
        <input id="api-key" type="text" placeholder="<prefix>.<тело>" style="flex:1;min-width:300px" value="">
        <button class="btn" onclick="localStorage.setItem('api_test_key', document.getElementById('api-key').value)">💾 Запомнить</button>
        <button class="btn" onclick="document.getElementById('api-key').value=''">✗ Стереть</button>
    </div>
    <div class="api-test-row">
        <label style="min-width:80px">Base URL:</label>
        <input id="api-base" type="text" value="" style="flex:1;min-width:300px">
    </div>
    <p class="muted small">Ключ хранится в localStorage этого браузера (не отправляется никуда кроме самой API).</p>
</div>

<!-- ============= Endpoints ============= -->

<div class="api-test-card">
    <h3>0. <code>GET /api/v1/me</code> — проверка ключа</h3>
    <p class="muted small">Самый базовый. Если работает — ключ валиден и таблица мигрирована.</p>
    <button class="btn btn-primary" onclick="apiTest('me', 'GET', '/api/v1/me')">▶ Test</button>
    <div id="resp-me"></div>
</div>

<div class="api-test-card">
    <h3>1. <code>GET /api/v1/webmaster/accounts</code> — список Yandex-аккаунтов</h3>
    <p class="muted small">Требует scope <code>webmaster.read</code>. Токены НЕ должны быть в ответе.</p>
    <button class="btn btn-primary" onclick="apiTest('wm-list', 'GET', '/api/v1/webmaster/accounts')">▶ Test</button>
    <div id="resp-wm-list"></div>
</div>

<div class="api-test-card">
    <h3>2. <code>GET /api/v1/webmaster/credentials?id=X</code> — выдача access_token</h3>
    <p class="muted small">Требует <code>webmaster.credentials</code>. Полезно сразу проверить токен на api.webmaster.yandex.net (см. ниже кнопку «Проверить токен в Yandex»).</p>
    <div class="api-test-row">
        <label>ID аккаунта:</label>
        <input id="wm-id" type="number" value="1" style="width:80px">
        <button class="btn btn-primary" onclick="apiTest('wm-cred', 'GET', '/api/v1/webmaster/credentials?id=' + document.getElementById('wm-id').value)">▶ Test</button>
        <button class="btn" onclick="testYandexToken()">🔗 Проверить полученный токен в Yandex</button>
    </div>
    <div id="resp-wm-cred"></div>
    <div id="resp-yandex"></div>
</div>

<div class="api-test-card">
    <h3>3. <code>GET /api/v1/registrar/accounts</code></h3>
    <p class="muted small">Требует <code>registrar.read</code>.</p>
    <button class="btn btn-primary" onclick="apiTest('reg-list', 'GET', '/api/v1/registrar/accounts')">▶ Test</button>
    <div id="resp-reg-list"></div>
</div>

<div class="api-test-card">
    <h3>4. <code>GET /api/v1/registrar/credentials?id=X</code></h3>
    <p class="muted small">Требует <code>registrar.credentials</code>.</p>
    <div class="api-test-row">
        <label>ID:</label>
        <input id="reg-id" type="number" value="2" style="width:80px">
        <button class="btn btn-primary" onclick="apiTest('reg-cred', 'GET', '/api/v1/registrar/credentials?id=' + document.getElementById('reg-id').value)">▶ Test</button>
    </div>
    <div id="resp-reg-cred"></div>
</div>

<div class="api-test-card">
    <h3>5. <code>GET /api/v1/registrar/contacts</code></h3>
    <button class="btn btn-primary" onclick="apiTest('reg-contacts', 'GET', '/api/v1/registrar/contacts')">▶ Test</button>
    <div id="resp-reg-contacts"></div>
</div>

<div class="api-test-card">
    <h3>6. <code>GET /api/v1/fastpanel/servers</code></h3>
    <button class="btn btn-primary" onclick="apiTest('fp-list', 'GET', '/api/v1/fastpanel/servers')">▶ Test</button>
    <div id="resp-fp-list"></div>
</div>

<div class="api-test-card">
    <h3>7. <code>POST /api/v1/fastpanel/jwt?id=X</code> — свежий JWT FastPanel</h3>
    <p class="muted small">refresh-panel залогинится в FP через свои creds и вернёт свежий Bearer JWT.</p>
    <div class="api-test-row">
        <label>FP server ID:</label>
        <input id="fp-id" type="number" value="1" style="width:80px">
        <button class="btn btn-primary" onclick="apiTest('fp-jwt', 'POST', '/api/v1/fastpanel/jwt?id=' + document.getElementById('fp-id').value)">▶ Test</button>
    </div>
    <div id="resp-fp-jwt"></div>
</div>

<div class="api-test-card">
    <h3>8. <code>GET /api/v1/server/site-ip?fp_server=X&fp_site=Y</code></h3>
    <p class="muted small">Резолвит IP сайта (для DNS A-записи нового домена).</p>
    <div class="api-test-row">
        <label>fp_server:</label>
        <input id="ip-srv" type="number" value="1" style="width:80px">
        <label>fp_site:</label>
        <input id="ip-site" type="number" value="1071" style="width:100px">
        <button class="btn btn-primary" onclick="apiTest('site-ip', 'GET', '/api/v1/server/site-ip?fp_server=' + document.getElementById('ip-srv').value + '&fp_site=' + document.getElementById('ip-site').value)">▶ Test</button>
    </div>
    <div id="resp-site-ip"></div>
</div>

<div class="api-test-card">
    <h3>9. <code>GET /api/v1/app-settings/domain</code></h3>
    <button class="btn btn-primary" onclick="apiTest('settings-dom', 'GET', '/api/v1/app-settings/domain')">▶ Test</button>
    <div id="resp-settings-dom"></div>
</div>

<div class="api-test-card" style="border:1px dashed #475569">
    <h3>🔍 Negative-тесты</h3>
    <p class="muted small">Эти запросы ДОЛЖНЫ упасть. Проверим что ошибки структурированы.</p>
    <button class="btn" onclick="apiTestRaw('neg-noauth', 'GET', '/api/v1/me', '')">no-auth → 401</button>
    <button class="btn" onclick="apiTestRaw('neg-badkey', 'GET', '/api/v1/me', 'invalid')">bad-key → 401</button>
    <button class="btn" onclick="apiTest('neg-404', 'GET', '/api/v1/webmaster/credentials?id=9999')">id=9999 → 404</button>
    <div id="resp-neg-noauth"></div>
    <div id="resp-neg-badkey"></div>
    <div id="resp-neg-404"></div>
</div>

<script>
// Восстанавливаем ключ из localStorage
(function() {
    const savedKey = localStorage.getItem('api_test_key');
    if (savedKey) document.getElementById('api-key').value = savedKey;
    document.getElementById('api-base').value = location.protocol + '//' + location.host;
})();

let lastYandexToken = '';

async function apiTest(slot, method, path) {
    const key = document.getElementById('api-key').value.trim();
    return apiTestRaw(slot, method, path, key);
}

async function apiTestRaw(slot, method, path, key) {
    const respEl = document.getElementById('resp-' + slot);
    if (!respEl) return;
    respEl.innerHTML = '<div class="api-test-resp">⏳ Выполняется…</div>';

    const baseUrl = document.getElementById('api-base').value.trim();
    const url = baseUrl + path;
    const t0 = performance.now();
    const opts = { method, headers: {} };
    if (key) opts.headers['Authorization'] = 'Bearer ' + key;

    let status = 0, text = '', isJson = false, body = null, err = null;
    try {
        const resp = await fetch(url, opts);
        status = resp.status;
        text = await resp.text();
        try { body = JSON.parse(text); isJson = true; } catch (e) { /* not JSON */ }
    } catch (e) {
        err = String(e);
    }
    const elapsed = Math.round(performance.now() - t0);

    // Достаём access_token если есть — для последующего теста против Yandex
    if (isJson && body && body.access_token) lastYandexToken = body.access_token;

    let statusClass = 's2xx';
    if (status >= 400 && status < 500) statusClass = 's4xx';
    else if (status >= 500) statusClass = 's5xx';
    else if (status === 0) statusClass = 's5xx';

    const headline = `<div style="font-family:monospace;font-size:12px">
        <span class="api-test-status ${statusClass}">HTTP ${status || 'ERR'}</span>
        <span style="color:#9aa6b2">${method} ${path}</span>
        <span class="api-test-elapsed">${elapsed}ms</span>
    </div>`;

    let bodyHtml;
    if (err) {
        bodyHtml = '<div class="api-test-resp api-test-resp-err">⚠️ Network error: ' + err + '</div>';
    } else if (isJson) {
        const ok = (body && body.ok === true);
        const cls = ok ? 'api-test-resp-ok' : 'api-test-resp-err';
        bodyHtml = '<div class="api-test-resp ' + cls + '">' +
            JSON.stringify(body, null, 2).replace(/</g, '&lt;') + '</div>';
    } else {
        bodyHtml = '<div class="api-test-resp api-test-resp-err">' +
            (text || '(пусто)').slice(0, 5000).replace(/</g, '&lt;') + '</div>';
    }

    respEl.innerHTML = headline + bodyHtml;
}

async function testYandexToken() {
    const respEl = document.getElementById('resp-yandex');
    const wmId = document.getElementById('wm-id').value;
    const key = document.getElementById('api-key').value.trim();
    const baseUrl = document.getElementById('api-base').value.trim();
    if (!key) {
        respEl.innerHTML = '<div class="api-test-resp api-test-resp-err">Сначала вставь API-ключ выше.</div>';
        return;
    }
    respEl.innerHTML = '<div class="api-test-resp">⏳ Server-side proxy → api.webmaster.yandex.net/v4/user…</div>';

    // Используем server-side proxy чтобы обойти CORS
    const url = baseUrl + '/api/v1/webmaster/test-token?id=' + encodeURIComponent(wmId);
    const t0 = performance.now();
    try {
        const resp = await fetch(url, {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + key }
        });
        const text = await resp.text();
        let body = null;
        try { body = JSON.parse(text); } catch (e) {}
        const elapsed = Math.round(performance.now() - t0);

        const isValid = body && body.token_valid === true;
        const headline = `<div style="font-family:monospace;font-size:12px">
            <span class="api-test-status ${isValid ? 's2xx' : 's4xx'}">${isValid ? 'TOKEN VALID' : 'TOKEN FAILED'}</span>
            <span style="color:#9aa6b2">via /api/v1/webmaster/test-token (server-side proxy)</span>
            <span class="api-test-elapsed">${elapsed}ms</span>
        </div>`;

        respEl.innerHTML = headline +
            '<div class="api-test-resp ' + (isValid ? 'api-test-resp-ok' : 'api-test-resp-err') + '">' +
            (body ? JSON.stringify(body, null, 2) : text).replace(/</g, '&lt;') +
            '</div>';
    } catch (e) {
        respEl.innerHTML = '<div class="api-test-resp api-test-resp-err">⚠️ ' + String(e) + '</div>';
    }
}
</script>
