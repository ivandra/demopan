<?php
/**
 * @var array $project
 * @var array $sites
 * @var array $runs
 * @var array $accountNames
 */
$projectId = (int)$project['id'];
?>
<div class="page-header">
    <a href="/casino" style="color:#9aa6b2;text-decoration:none">← Проекты</a>
    <h1>🎰 <?= htmlspecialchars($project['main_host']) ?> <small style="color:#9aa6b2">#<?= $projectId ?></small></h1>
</div>

<div class="card">
    <table class="kv-table" style="width:100%;font-size:13px">
        <tr><td style="width:200px">External ID</td><td><code><?= htmlspecialchars($project['external_id']) ?></code></td></tr>
        <tr><td>Label</td><td><?= htmlspecialchars($project['label']) ?></td></tr>
        <tr><td>Docroot</td><td><code><?= htmlspecialchars($project['docroot']) ?></code></td></tr>
        <tr><td>VPS IP</td><td><code><?= htmlspecialchars($project['vps_ip'] ?? '—') ?></code></td></tr>
        <tr><td>Root domain</td><td>
            <?php if (!empty($project['root_domain'])): ?>
                <code style="color:#3fb950"><?= htmlspecialchars($project['root_domain']) ?></code>
            <?php else: ?>
                <span class="muted">не куплен</span>
            <?php endif; ?>
        </td></tr>
        <tr><td>Webmaster аккаунт</td><td><?= htmlspecialchars($accountNames['webmaster'] ?? '—') ?></td></tr>
        <tr><td>Namecheap аккаунт</td><td><?= htmlspecialchars($accountNames['registrar'] ?? '—') ?></td></tr>
        <tr><td>WHOIS контакт</td><td><?= htmlspecialchars($accountNames['contact'] ?? '—') ?></td></tr>
        <tr><td>FastPanel сервер</td><td>
            <?= htmlspecialchars($accountNames['fastpanel'] ?? '—') ?>
            <?php if (!empty($project['fp_site_id'])): ?> · site #<?= (int)$project['fp_site_id'] ?><?php endif; ?>
        </td></tr>
        <tr><td>Status</td><td><b><?= htmlspecialchars($project['status']) ?></b></td></tr>
        <tr><td>Created / Updated</td><td><?= htmlspecialchars($project['created_at']) ?> / <?= htmlspecialchars($project['updated_at']) ?></td></tr>
    </table>
</div>

<div class="card" style="margin-top:18px">
    <div style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Сайты в проекте (<?= count($sites) ?>)</h2>
        <span class="muted small">main первым</span>
    </div>
    <table style="width:100%;border-collapse:collapse;margin-top:10px;font-size:12px">
        <thead><tr style="border-bottom:1px solid #334155">
            <th align="left" style="padding:6px">Slug</th>
            <th align="left" style="padding:6px">Brand</th>
            <th align="left" style="padding:6px">Host</th>
            <th align="left" style="padding:6px">Path</th>
            <th align="left" style="padding:6px">DNS</th>
            <th align="left" style="padding:6px">FP alias</th>
            <th align="left" style="padding:6px">SSL</th>
            <th align="left" style="padding:6px">Webmaster</th>
        </tr></thead>
        <tbody>
        <?php $statusEmoji = function($s) {
            return [
                'pending' => '⏳', 'added' => '✓', 'done' => '✓',
                'failed' => '✗', 'verified' => '✓',
            ][$s] ?? $s;
        }; ?>
        <?php foreach ($sites as $s): ?>
            <tr style="border-bottom:1px solid #1e293b<?= $s['is_main'] ? ';background:rgba(63,185,80,.05)' : '' ?>">
                <td style="padding:6px;font-family:monospace">
                    <?php if ($s['is_main']): ?>⭐ <?php endif; ?>
                    <?= htmlspecialchars($s['site_slug']) ?>
                </td>
                <td style="padding:6px"><?= htmlspecialchars($s['brand']) ?></td>
                <td style="padding:6px;font-family:monospace"><?= htmlspecialchars($s['host']) ?></td>
                <td style="padding:6px;font-family:monospace">/<?= htmlspecialchars($s['path_prefix']) ?>/×<?= (int)$s['path_repeats'] ?>/</td>
                <td style="padding:6px"><?= $statusEmoji($s['dns_status']) ?> <small><?= htmlspecialchars($s['dns_status']) ?></small></td>
                <td style="padding:6px"><?= $statusEmoji($s['fp_alias_status']) ?> <small><?= htmlspecialchars($s['fp_alias_status']) ?></small></td>
                <td style="padding:6px"><?= $statusEmoji($s['ssl_status']) ?> <small><?= htmlspecialchars($s['ssl_status']) ?></small></td>
                <td style="padding:6px"><?= (int)$s['wm_verified'] ? '✓' : '⏳' ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="card" style="margin-top:18px">
    <h2>Операции (runs)</h2>
    <?php if (empty($runs)): ?>
        <p class="muted small">Пока ни одной операции не запускалось. Кнопки появятся в следующих этапах (B2+).</p>
    <?php else: ?>
        <table style="width:100%;border-collapse:collapse;font-size:12px">
            <thead><tr style="border-bottom:1px solid #334155">
                <th align="left" style="padding:6px">Run ID</th>
                <th align="left" style="padding:6px">Kind</th>
                <th align="left" style="padding:6px">State</th>
                <th align="left" style="padding:6px">Progress</th>
                <th align="left" style="padding:6px">Last message</th>
                <th align="left" style="padding:6px">Started</th>
                <th align="left" style="padding:6px">Finished</th>
            </tr></thead>
            <tbody>
            <?php foreach ($runs as $r):
                $color = ['queued'=>'#9aa6b2','running'=>'#f59e0b','done'=>'#3fb950','failed'=>'#ef4444','cancelled'=>'#a855f7'][$r['state']] ?? '#9aa6b2';
            ?>
                <tr style="border-bottom:1px solid #1e293b">
                    <td style="padding:6px;font-family:monospace"><?= htmlspecialchars($r['run_id']) ?></td>
                    <td style="padding:6px"><?= htmlspecialchars($r['kind']) ?></td>
                    <td style="padding:6px;color:<?= $color ?>">● <?= htmlspecialchars($r['state']) ?></td>
                    <td style="padding:6px"><?= (int)$r['progress'] ?>%</td>
                    <td style="padding:6px"><small><?= htmlspecialchars(mb_substr($r['last_message'] ?? '', 0, 80)) ?></small></td>
                    <td style="padding:6px"><?= htmlspecialchars($r['started_at'] ?? '—') ?></td>
                    <td style="padding:6px"><?= htmlspecialchars($r['finished_at'] ?? '—') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="card" style="margin-top:18px;border:1px solid #ef4444">
    <h3 style="color:#ef4444;margin:0">Опасная зона</h3>
    <form method="post" action="/casino/delete" onsubmit="return confirm('Удалить проект #<?= $projectId ?> со всеми его sites и runs? Это не трогает реальные купленные домены и FP-сайты — только удалит запись из refresh-panel.')" style="margin-top:10px">
        <input type="hidden" name="id" value="<?= $projectId ?>">
        <button type="submit" class="btn" style="background:#7f1d1d;color:#fff;border-color:#ef4444">🗑 Удалить проект из refresh-panel</button>
    </form>
</div>
