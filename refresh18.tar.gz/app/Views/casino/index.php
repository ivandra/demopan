<?php
/** @var array $rows */
/** @var array $apiClients */
?>
<div class="page-header">
    <h1>🎰 Casino — проекты</h1>
    <p class="muted">Проекты переданные из casino-panel'и для деплоя.</p>
</div>

<div class="card">
    <?php if (empty($rows)): ?>
        <p class="muted">Пока ни одного проекта не зарегистрировано.</p>
        <p class="muted small">Чтобы зарегистрировать — в casino-panel настрой API-ключ (Шаг 1) и нажми «Передать в refresh-panel» (Шаг 6).</p>
    <?php else: ?>
        <table style="width:100%;border-collapse:collapse">
            <thead>
            <tr style="border-bottom:2px solid #334155">
                <th align="left" style="padding:8px">#</th>
                <th align="left" style="padding:8px">Main host</th>
                <th align="left" style="padding:8px">Root domain</th>
                <th align="left" style="padding:8px">Docroot</th>
                <th align="left" style="padding:8px">Client</th>
                <th align="left" style="padding:8px">Status</th>
                <th align="left" style="padding:8px">Updated</th>
                <th align="left" style="padding:8px"></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r):
                $client = $apiClients[(int)$r['api_client_id']] ?? null;
                $statusColor = [
                    'registered'      => '#9aa6b2',
                    'domain_bought'   => '#3b82f6',
                    'subs_ready'      => '#06b6d4',
                    'wm_added'        => '#a855f7',
                    'done'            => '#3fb950',
                    'failed'          => '#ef4444',
                ][(string)$r['status']] ?? '#9aa6b2';
            ?>
                <tr style="border-bottom:1px solid #1e293b">
                    <td style="padding:8px;font-family:monospace"><?= (int)$r['id'] ?></td>
                    <td style="padding:8px"><code><?= htmlspecialchars($r['main_host']) ?></code>
                        <?php if (!empty($r['label'])): ?><br><small class="muted"><?= htmlspecialchars($r['label']) ?></small><?php endif; ?>
                    </td>
                    <td style="padding:8px">
                        <?php if (!empty($r['root_domain'])): ?>
                            <code style="color:#3fb950"><?= htmlspecialchars($r['root_domain']) ?></code>
                        <?php else: ?>
                            <span class="muted small">не куплен</span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:8px;font-family:monospace;font-size:12px"><?= htmlspecialchars($r['docroot']) ?></td>
                    <td style="padding:8px;font-size:12px">
                        <?php if ($client): ?>
                            <?= htmlspecialchars($client['label']) ?>
                            <br><span class="muted"><?= htmlspecialchars($client['key_prefix']) ?>…</span>
                        <?php else: ?>
                            <span class="muted">#<?= (int)$r['api_client_id'] ?></span>
                        <?php endif; ?>
                    </td>
                    <td style="padding:8px"><span style="color:<?= $statusColor ?>">● <?= htmlspecialchars($r['status']) ?></span></td>
                    <td style="padding:8px;font-size:12px"><?= htmlspecialchars($r['updated_at']) ?></td>
                    <td style="padding:8px">
                        <a href="/casino/show?id=<?= (int)$r['id'] ?>" class="btn small-btn">→ Открыть</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
