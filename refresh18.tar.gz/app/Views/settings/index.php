<h1 class="page-title">Настройки</h1>

<section class="card">
    <h2>📦 Миграции БД</h2>
    <table class="hub-table">
        <thead><tr><th>Миграция</th><th>Статус</th></tr></thead>
        <tbody>
            <?php foreach ($migrations as $m): ?>
                <?php $isApplied = isset($applied[$m['name']]); ?>
                <tr>
                    <td><code><?= htmlspecialchars($m['name']) ?></code></td>
                    <td>
                        <?php if ($isApplied): ?>
                            <span class="pill pill-ok">applied</span>
                        <?php else: ?>
                            <span class="pill pill-warn">pending</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <form method="post" action="/settings/migrate">
        <button type="submit" class="btn btn-primary">Применить непримененные миграции</button>
    </form>
</section>

<section class="card">
    <h2>🤖 Telegram уведомления</h2>
    <form method="post" action="/settings/telegram" class="form-card form-card--inline">
        <label class="checkbox">
            <input type="checkbox" name="enabled" value="1" <?= !empty($tg['enabled']) ? 'checked' : '' ?>>
            Включить уведомления
        </label>
        <label>Bot token
            <input type="text" name="bot_token" placeholder="<?= !empty($tg['bot_token']) ? '(скрыт — оставьте пустым чтобы не менять)' : '123456:ABC...' ?>">
        </label>
        <label>Chat ID
            <input type="text" name="chat_id" value="<?= htmlspecialchars((string)$tg['chat_id']) ?>" placeholder="-1001234567890">
        </label>
        <fieldset>
            <legend>Когда уведомлять</legend>
            <label class="checkbox">
                <input type="checkbox" name="notify_on_stage_ok" value="1" <?= !empty($tg['notify_on_stage_ok']) ? 'checked' : '' ?>>
                После успешного завершения каждого этапа
            </label>
            <label class="checkbox">
                <input type="checkbox" name="notify_on_stage_fail" value="1" <?= !empty($tg['notify_on_stage_fail']) ? 'checked' : '' ?>>
                При ошибке этапа
            </label>
            <label class="checkbox">
                <input type="checkbox" name="notify_on_done" value="1" <?= !empty($tg['notify_on_done']) ? 'checked' : '' ?>>
                По завершении всей джобы
            </label>
        </fieldset>

        <!-- v14h: фильтр для масштаба -->
        <fieldset style="margin-top: 16px;">
            <legend>📉 Фильтр для масштаба (анти-спам)</legend>
            <p class="muted small" style="margin-top: 0;">
                При параллельном перевыставлении 20-30 сайтов в Telegram может прилететь
                сотни сообщений. Эти настройки фильтруют что отправлять.
            </p>

            <label>Уровень фильтра
                <select name="min_level" style="width: 100%; padding: 6px;">
                    <?php $ml = (string)($tg['min_level'] ?? 'milestones'); ?>
                    <option value="all" <?= $ml === 'all' ? 'selected' : '' ?>>
                        Всё (как раньше — шумно)
                    </option>
                    <option value="milestones" <?= $ml === 'milestones' ? 'selected' : '' ?>>
                        Только важные вехи (рекомендуется)
                    </option>
                    <option value="errors_only" <?= $ml === 'errors_only' ? 'selected' : '' ?>>
                        Только ошибки
                    </option>
                    <option value="off" <?= $ml === 'off' ? 'selected' : '' ?>>
                        Выключить (ничего не слать)
                    </option>
                </select>
            </label>

            <p class="muted small" style="margin-top: 8px; margin-bottom: 8px;">
                <strong>Только важные вехи</strong> = алиасы добавлены, verify прошёл,
                LE выпустился, redirect восстановлен, джоба завершена. Внутренние шаги
                стадии не отправляются.
            </p>

            <label>Лимит ok-сообщений на стадию (per job)
                <input type="number" name="ok_per_stage_limit"
                       value="<?= (int)($tg['ok_per_stage_limit'] ?? 1) ?>"
                       min="0" max="10" style="width: 80px;">
                <span class="muted small">— 0 = вообще не слать ok, 1 = только первое (рекомендуется), N = первые N</span>
            </label>

            <label class="checkbox" style="margin-top: 8px;">
                <input type="checkbox" name="job_summary_enabled" value="1" <?= !empty($tg['job_summary_enabled']) ? 'checked' : '' ?>>
                <strong>Сводка джобы</strong> — одно итоговое сообщение со списком стадий
                вместо россыпи отдельных «✓ ok»
            </label>
            <p class="muted small" style="margin: 4px 0 0 24px;">
                Например: «🎉 refresh #42 готово. zooma-21 → zooma-22. ✅ aliases ✅ ssl ✅ verify ✅ redirect ✅ LE»
            </p>

            <!-- v18.1.28: @упоминания участников для balance-low алертов -->
            <label style="margin-top: 12px;">
                <strong>Упоминания для критических алертов</strong>
                <input type="text" name="mention_usernames"
                       value="<?= htmlspecialchars((string)($tg['mention_usernames'] ?? '')) ?>"
                       placeholder="alice, @bob @charlie"
                       style="width: 100%; padding: 6px;">
            </label>
            <p class="muted small" style="margin: 4px 0 0 24px;">
                Список @usernames через запятую или пробел. Используется в алертах
                <strong>о низком балансе Namecheap и XMLStock</strong> чтобы участники получили push.
                Знак <code>@</code> опционален — добавится автоматически.
            </p>
        </fieldset>
        <div class="form-row">
            <button type="submit" class="btn btn-primary">Сохранить</button>
            <a href="/settings/telegram-test" class="btn btn-secondary">Отправить тестовое сообщение</a>
        </div>
    </form>
</section>

<!-- v18.1.28: пороги балансов для алертов -->
<section class="card">
    <h2>💰 Пороги балансов</h2>
    <p class="muted small">
        Когда баланс одного из сервисов опускается ниже порога, в Telegram приходит алерт
        с упоминанием участников. Проверяются автоматически: <strong>раз в час</strong> через cron +
        <strong>после покупки домена</strong> (Namecheap) + <strong>на старте index_watching</strong> (XMLStock).
        Anti-spam: повторный алерт того же сервиса — не чаще раз в 6 часов.
    </p>

    <?php
    $balRows = [];
    try {
        $balRows = DB::pdo()->query("SELECT * FROM balance_current
            WHERE service IN ('namecheap','xmlstock') AND account_label='default'
            ORDER BY service")->fetchAll() ?: [];
    } catch (\Throwable $e) {}

    $ncRow = null; $xsRow = null;
    foreach ($balRows as $r) {
        if ($r['service'] === 'namecheap') $ncRow = $r;
        if ($r['service'] === 'xmlstock')  $xsRow = $r;
    }
    $ncThreshold = $ncRow ? (float)$ncRow['threshold'] : 100;
    $xsThreshold = $xsRow ? (float)$xsRow['threshold'] : 100;
    ?>

    <form method="post" action="/settings/balance-thresholds" class="form-card form-card--inline">
        <fieldset style="border:1px solid var(--border, #ccc); padding: 12px; border-radius: 6px;">
            <legend><strong>Порог уведомления</strong></legend>

            <div class="form-row" style="display:flex; gap: 24px; flex-wrap: wrap;">
                <label style="flex: 0 0 240px;">
                    Namecheap (USD)
                    <input type="number" name="namecheap_threshold"
                           value="<?= number_format($ncThreshold, 2, '.', '') ?>"
                           min="0" step="0.01" style="width: 100%; padding: 6px;">
                    <?php if ($ncRow): ?>
                        <span class="muted small">
                            Текущий баланс: <?= htmlspecialchars(number_format((float)$ncRow['balance'], 2)) ?> USD
                            <?php if (!empty($ncRow['last_checked_at'])): ?>
                                (проверен <?= htmlspecialchars(Time::msk((string)$ncRow['last_checked_at'])) ?>)
                            <?php endif; ?>
                        </span>
                    <?php endif; ?>
                </label>

                <label style="flex: 0 0 240px;">
                    XMLStock (RUB)
                    <input type="number" name="xmlstock_threshold"
                           value="<?= number_format($xsThreshold, 0, '.', '') ?>"
                           min="0" step="1" style="width: 100%; padding: 6px;">
                    <?php if ($xsRow): ?>
                        <span class="muted small">
                            Текущий баланс: <?= htmlspecialchars(number_format((float)$xsRow['balance'], 2)) ?> ₽
                            <?php if (!empty($xsRow['last_checked_at'])): ?>
                                (проверен <?= htmlspecialchars(Time::msk((string)$xsRow['last_checked_at'])) ?>)
                            <?php endif; ?>
                        </span>
                    <?php endif; ?>
                </label>
            </div>
        </fieldset>
        <div class="form-row" style="margin-top: 12px;">
            <button type="submit" class="btn btn-primary">Сохранить пороги</button>
        </div>
    </form>

    <!-- Отдельная форма (HTML не разрешает nested forms) для ручного обновления -->
    <form method="post" action="/system/balance/refresh" style="margin-top: 8px;">
        <button type="submit" class="btn btn-secondary">🔄 Обновить балансы сейчас</button>
    </form>
</section>

<!-- v18.1.29: настройки cron и параллельной обработки джоб -->
<section class="card">
    <h2>⚙️ Параллельная обработка джоб</h2>
    <p class="muted small">
        Сколько джоб панель обрабатывает <strong>за один cron-tick</strong> (одну минуту).
        Раньше — одна джоба за tick (10 джоб = 10 минут очереди).
        Теперь — несколько параллельно через per-job lock.
        Каждая защищена индивидуальным lock'ом, повторный запуск (cron + manual)
        не вызовет race condition.
    </p>

    <?php
    $cronMaxJobs = AppSettings::getInt('cron.max_jobs_per_tick',
        (int)config('cron.max_jobs_per_tick', 5));
    ?>

    <form method="post" action="/settings/cron" class="form-card form-card--inline">
        <label style="display:block; max-width: 360px;">
            <strong>Джоб за один cron-tick</strong>
            <input type="number" name="max_jobs_per_tick"
                   value="<?= $cronMaxJobs ?>"
                   min="1" max="50" step="1"
                   style="width: 100%; padding: 6px;">
            <span class="muted small">
                Допустимо 1–50. Рекомендуется 5 (быстро для типичной нагрузки).
                Увеличивай до 15-20 если у тебя много джоб одновременно
                (например, массовое перевыставление 30 сайтов).
                Каждая джоба внутри tick занимает ~1-3 секунды.
            </span>
        </label>

        <div class="form-row" style="margin-top: 12px;">
            <button type="submit" class="btn btn-primary">Сохранить</button>
        </div>
    </form>

    <details style="margin-top: 12px;">
        <summary class="muted small" style="cursor: pointer;">ℹ️ Как это работает</summary>
        <div class="muted small" style="margin-top: 6px; padding: 8px; background: rgba(255,255,255,0.03); border-radius: 6px; line-height: 1.5;">
            <ol>
                <li>Cron вызывается раз в минуту (через хостинг-cron).</li>
                <li>Берёт короткий picking-lock (~10ms), SELECT'ит до N джоб из очереди.</li>
                <li>Отпускает picking-lock сразу — параллельный cron может взять следующие N.</li>
                <li>Для каждой джобы — non-blocking per-job lock (<code>rfp_job_&lt;id&gt;</code>).
                    Если занят (например, ты только что нажал «⚡ Шаг сейчас») — пропускаем.</li>
                <li>Обрабатывает step через RefreshOrchestrator. Ошибка отдельной джобы
                    не блокирует остальные.</li>
                <li>Освобождает per-job lock.</li>
            </ol>
            <p>
                <strong>Защита от race condition</strong>: оператор нажимает «⚡ Шаг сейчас»
                в момент когда cron обрабатывает ту же джобу — UI выдаст warning,
                step не дублируется.
            </p>
            <p>
                <strong>Stale recovery</strong>: если PHP-воркер падает с fatal —
                lock автоматически освобождается (MySQL native behavior). Дополнительно
                если <code>stage_status='running'</code> дольше 5 минут — pickJobs сбросит в pending.
            </p>
        </div>
    </details>
</section>

<!-- v25.1-b: SSL-мониторинг и доступность -->
<section class="card">
    <h2>🔒 SSL-мониторинг и доступность</h2>
    <p class="muted small">
        Частоты автоматических SSL-проверок и порог предупреждения о зависшей
        верификации Вебмастера. Проверки выполняет отдельный cron
        <code>/cron/ssl</code>.
    </p>
    <?php
    $sslMon = AppSettings::getBool('ssl.monitor_enabled', true);
    $sslMax = AppSettings::getInt('ssl.max_checks_per_tick', 10);
    $sslPend = AppSettings::getInt('ssl.pending_interval_seconds', 60);
    $sslSelf = AppSettings::getInt('ssl.self_signed_interval_seconds', 90);
    $sslTrust = AppSettings::getInt('ssl.trusted_interval_minutes', 720);
    $sslWarn = AppSettings::getInt('ssl.expiring_days_warning', 30);
    $sslCrit = AppSettings::getInt('ssl.expiring_days_critical', 7);
    $sslRet = AppSettings::getInt('ssl.history_retention_days', 90);
    $wmWarn = AppSettings::getInt('wm.verification_warning_minutes', 60);
    ?>
    <form method="post" action="/settings/ssl" class="form-card form-card--inline">
        <div class="form-row" style="display:flex; gap:20px; flex-wrap:wrap;">
            <label><input type="checkbox" name="ssl_monitor_enabled" value="1" <?= $sslMon ? 'checked' : '' ?>> Мониторинг включён</label>
            <label>Проверок за tick <input type="number" name="ssl_max_checks_per_tick" value="<?= (int)$sslMax ?>" min="1" max="200" style="width:80px;"></label>
        </div>
        <div class="form-row" style="display:flex; gap:20px; flex-wrap:wrap; margin-top:10px;">
            <label>pending (сек) <input type="number" name="ssl_pending_interval_seconds" value="<?= (int)$sslPend ?>" min="15" style="width:90px;"></label>
            <label>self-signed (сек) <input type="number" name="ssl_self_signed_interval_seconds" value="<?= (int)$sslSelf ?>" min="15" style="width:90px;"></label>
            <label>trusted (мин) <input type="number" name="ssl_trusted_interval_minutes" value="<?= (int)$sslTrust ?>" min="10" style="width:90px;"></label>
        </div>
        <div class="form-row" style="display:flex; gap:20px; flex-wrap:wrap; margin-top:10px;">
            <label>предупреждение ≤ дней <input type="number" name="ssl_expiring_days_warning" value="<?= (int)$sslWarn ?>" min="1" style="width:80px;"></label>
            <label>критично ≤ дней <input type="number" name="ssl_expiring_days_critical" value="<?= (int)$sslCrit ?>" min="1" style="width:80px;"></label>
            <label>история (дней) <input type="number" name="ssl_history_retention_days" value="<?= (int)$sslRet ?>" min="1" style="width:80px;"></label>
        </div>
        <div class="form-row" style="display:flex; gap:20px; flex-wrap:wrap; margin-top:10px;">
            <label>Вебмастер warning (мин) <input type="number" name="wm_verification_warning_minutes" value="<?= (int)$wmWarn ?>" min="1" style="width:90px;"></label>
        </div>
        <div class="form-row" style="margin-top:12px;">
            <button type="submit" class="btn btn-primary">Сохранить</button>
        </div>
    </form>
</section>

<!-- v25.2-a1.6.4: авто-закрытие неактивных джоб -->
<section class="card">
    <h2>🤖 Автозакрытие джоб, ожидающих оператора</h2>
    <p class="muted small">
        Джоба, которая непрерывно ждёт действия оператора (<code>awaiting_user</code>) дольше
        заданного срока, закрывается автоматически: финальная стадия
        <code>old_delurl_notify</code> — как <strong>done</strong>, остальные — как
        <strong>cancelled</strong>. Отсчёт идёт с момента остановки, а не с даты создания
        (фоновые SSL-проверки не считаются активностью). После закрытия SSL-домен уходит в Архив.
    </p>
    <form method="post" action="/settings/jobs" class="form-card form-card--inline">
        <div class="form-row">
            <label>
                <input type="checkbox" name="jobs_auto_close_enabled" value="1"
                    <?= AppSettings::getBool('jobs.auto_close_enabled', true) ? 'checked' : '' ?>>
                Автозакрытие включено
            </label>
        </div>
        <div class="form-row">
            <label>Срок ожидания (дней)
                <input type="number" name="jobs_auto_close_days" min="1" max="365"
                    value="<?= (int)AppSettings::getInt('jobs.auto_close_days', 30) ?>">
            </label>
            <label>Размер пачки
                <input type="number" name="jobs_auto_close_batch" min="1" max="200"
                    value="<?= (int)AppSettings::getInt('jobs.auto_close_batch', 50) ?>">
            </label>
            <label>Интервал запуска (мин)
                <input type="number" name="jobs_auto_close_interval_minutes" min="15" max="1440"
                    value="<?= (int)AppSettings::getInt('jobs.auto_close_interval_minutes', 60) ?>">
            </label>
        </div>
        <div class="form-row" style="margin-top:12px;">
            <button type="submit" class="btn btn-primary">Сохранить</button>
        </div>
    </form>
</section>
<section class="card">
    <h2>🎯 Маска генерации: домен и sub_id</h2>
    <p class="muted small">
        Единый движок для <strong>нового домена</strong> и <strong>нового sub_id</strong> — раньше это были
        две разные реализации, и они расходились: домен <code>vodka104x.casino</code> превращался
        в <code>vodka104x2.casino</code> (цифра лепилась в конец), хотя sub_id считался верно —
        <code>vodka104x → vodka105x</code>. Теперь правило одно.
    </p>

    <?php
    $mo = isset($maskOpts) && is_array($maskOpts) ? $maskOpts : DomainMaskService::DEFAULTS;
    $maskDemo = new DomainMaskService();
    $demoTokens = ['vodka104x', 'vavada132x', '7k5265', 'Dstake204', 'vodka007', 'pinko'];
    ?>

    <form method="post" action="/settings/mask" class="form-card">
        <label style="display:block; max-width: 360px; margin-bottom: 16px;">
            <strong>Стратегия</strong>
            <select name="mask_strategy" style="width: 100%; padding: 6px;">
                <option value="number" <?= ($mo['strategy'] === 'number' ? 'selected' : '') ?>>
                    number — инкремент числа (vodka104x → vodka105x)
                </option>
                <option value="letter" <?= ($mo['strategy'] === 'letter' ? 'selected' : '') ?>>
                    letter — сдвиг хвостовой буквы (vodka104x → vodka104y)
                </option>
            </select>
            <span class="muted small">
                <code>number</code> — рабочий режим по умолчанию: берётся ПОСЛЕДНЯЯ группа цифр,
                хвостовые буквы сохраняются.
                <code>letter</code> — сдвигает последнюю букву; если букв нет, автоматически
                откатывается на инкремент числа.
            </span>
        </label>

        <label style="display:block; max-width: 360px; margin-bottom: 16px;">
            <strong>Шаг инкремента</strong>
            <input type="number" name="mask_step" value="<?= (int)$mo['step'] ?>"
                   min="1" max="1000" step="1" style="width: 100%; padding: 6px;">
            <span class="muted small">
                1–1000. По умолчанию 1: <code>7k5265 → 7k5266</code>.
                Шаг 5 даст <code>7k5265 → 7k5270</code>.
            </span>
        </label>

        <label style="display:block; max-width: 360px; margin-bottom: 16px;">
            <strong>Если цифр в имени нет вообще</strong>
            <input type="number" name="mask_no_digit_start" value="<?= (int)$mo['no_digit_start'] ?>"
                   min="0" max="999999" step="1" style="width: 100%; padding: 6px;">
            <span class="muted small">
                Какое число дописать в конец: <code>pinko → pinko<?= (int)$mo['no_digit_start'] ?></code>.
                По умолчанию 2.
            </span>
        </label>

        <label style="display:block; margin-bottom: 12px;">
            <input type="checkbox" name="mask_pad_zeros" value="1" <?= (!empty($mo['pad_zeros']) ? 'checked' : '') ?>>
            <strong>Сохранять ведущие нули</strong>
            <span class="muted small">
                &nbsp;— <code>vodka007 → vodka008</code>. Без галочки: <code>vodka007 → vodka8</code>.
            </span>
        </label>

        <label style="display:block; max-width: 360px; margin-bottom: 12px;">
            <strong>Алфавит для сдвига букв</strong>
            <input type="text" name="mask_letter_alphabet"
                   value="<?= htmlspecialchars((string)$mo['letter_alphabet']) ?>"
                   style="width: 100%; padding: 6px;">
            <span class="muted small">
                Используется только стратегией <code>letter</code>. Порядок задаёт последовательность
                сдвига (x → y → z → …).
            </span>
        </label>

        <label style="display:block; margin-bottom: 12px;">
            <input type="checkbox" name="mask_sync_with_domain" value="1" <?= (!empty($mo['sync_with_domain']) ? 'checked' : '') ?>>
            <strong>Синхронизировать число sub_id с доменом</strong>
            <span class="muted small">
                &nbsp;— sub_id получает число НОВОГО домена вместо независимого +1.
                Именно из-за независимого инкремента sub_id на проде отставал от домена
                (в базе встречался разрыв до 52). Рекомендуется держать включённым.
            </span>
        </label>

        <label style="display:block; margin-bottom: 12px;">
            <input type="checkbox" name="mask_prefix_enabled" value="1" <?= (!empty($mo['prefix_enabled']) ? 'checked' : '') ?>>
            <strong>Префикс сотрудника</strong>
            <input type="text" name="mask_prefix" value="<?= htmlspecialchars((string)$mo['prefix']) ?>"
                   placeholder="A_" maxlength="16" style="width:90px; padding:4px; margin-left:6px;">
            <span class="muted small">
                &nbsp;— редкая опция: добавляет префикс в начало sub_id, если его там нет.
                Обычно задаётся персонально на сайт, а не глобально.
            </span>
        </label>

        <label style="display:block; margin-bottom: 16px;">
            <input type="checkbox" name="mask_letter_wrap" value="1" <?= (!empty($mo['letter_wrap']) ? 'checked' : '') ?>>
            <strong>Перенос на конце алфавита</strong>
            <span class="muted small">
                &nbsp;— на конце алфавита группа расширяется: <code>dz → ea</code>,
                <code>z → aa</code>. Число при этом <b>не меняется</b> — оно может быть
                частью бренда. Без галочки достижение конца алфавита считается ошибкой
                и джоба остановится с понятным сообщением.
            </span>
        </label>

        <button type="submit" class="btn btn-primary">Сохранить</button>
    </form>

    <div style="margin-top: 14px;">
        <strong class="small">Превью на текущих параметрах</strong>
        <div class="muted small" style="margin:4px 0 6px;">
            Синхронизация sub_id с доменом:
            <code>7k5212</code> + домен <code>7k5265.casino</code> →
            <code><?= htmlspecialchars($maskDemo->subIdForDomain('7k5212', '7k5265.casino')) ?></code>
            &nbsp;|&nbsp; буквенный счётчик:
            <code><?= htmlspecialchars((new DomainMaskService(['strategy' => 'letter']))->nextSubId('A_azino_777df_casino')) ?></code>
        </div>
        <table class="table small" style="margin-top: 6px; max-width: 560px;">
            <thead>
                <tr><th>Было</th><th>Новый домен</th><th>Новый sub_id</th></tr>
            </thead>
            <tbody>
            <?php foreach ($demoTokens as $tk): ?>
                <tr>
                    <td><code><?= htmlspecialchars($tk) ?></code></td>
                    <td><code><?= htmlspecialchars($maskDemo->nextDomain($tk . '.casino')) ?></code></td>
                    <td><code><?= htmlspecialchars($maskDemo->nextSubId($tk)) ?></code></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <span class="muted small">
            Домен всегда приводится к нижнему регистру (DNS регистронезависим), sub_id регистр сохраняет —
            это ожидаемо и не является расхождением.
        </span>
    </div>

    <details style="margin-top: 12px;">
        <summary class="muted small" style="cursor: pointer;">ℹ️ Правила генерации</summary>
        <div class="muted small" style="margin-top: 6px; padding: 8px; background: rgba(255,255,255,0.03); border-radius: 6px; line-height: 1.6;">
            <p><strong>1. Инкрементируется последняя группа цифр, хвостовые буквы сохраняются.</strong><br>
            <code>vodka104x → vodka105x</code>, <code>vavada132x → vavada133x</code>,
            <code>7k-200 → 7k-201</code>.</p>
            <p><strong>2. Если цифр нет вообще — число дописывается в конец.</strong><br>
            <code>pinko → pinko2</code>.</p>
            <p><strong>3. Ведущие нули сохраняются.</strong><br>
            <code>vodka007 → vodka008</code>.</p>
            <p><strong>4. Опционально — сдвиг буквы.</strong><br>
            Стратегия <code>letter</code>: <code>vodka104x → vodka104y</code>.</p>
            <p><b>Домен</b> всегда считается по числовой стратегии — буквенный счётчик
            это соглашение для <code>sub_id</code>, к покупке доменов оно не применяется.
            Число <code>sub_id</code> берётся из нового домена, поэтому они не разъезжаются.</p>
        </div>
    </details>
</section>

<!-- v18.1.31: настройки поиска доменов при покупке -->
<section class="card">
    <h2>🔎 Поиск доменов при покупке</h2>
    <p class="muted small">
        Сколько кандидатов по маске <code>домен+N</code> проверяет панель за <strong>один cron-tick</strong>.
        Раньше было жёстко 5 — если подряд 5 заняты, джоба падала с <code>all_candidates_failed</code>.
        Теперь по умолчанию 30 за tick и до 200 в сумме (продолжает в следующих tick'ах).
    </p>

    <?php
    $candPerTick = AppSettings::getInt('domain.candidates_per_tick', 30);
    $candMaxTotal = AppSettings::getInt('domain.candidates_max_total', 200);
    ?>

    <form method="post" action="/settings/domain-search" class="form-card">
        <label style="display:block; max-width: 360px; margin-bottom: 16px;">
            <strong>Кандидатов за один cron-tick</strong>
            <input type="number" name="candidates_per_tick"
                   value="<?= $candPerTick ?>"
                   min="1" max="200" step="1"
                   style="width: 100%; padding: 6px;">
            <span class="muted small">
                1–200. По умолчанию 30. Каждая проверка ~500мс через Namecheap API,
                так что 30 кандидатов ≈ 15-30 сек в одном tick'е.
                Если попадаешь в полосу 50+ занятых подряд (типично для популярных масок)
                — увеличь до 50-60.
            </span>
        </label>

        <label style="display:block; max-width: 360px; margin-bottom: 12px;">
            <strong>Жёсткий потолок всего поиска</strong>
            <input type="number" name="candidates_max_total"
                   value="<?= $candMaxTotal ?>"
                   min="1" max="10000" step="1"
                   style="width: 100%; padding: 6px;">
            <span class="muted small">
                Защита от runaway. Если за все попытки проверено столько доменов
                и все заняты — джоба останавливается со статусом
                <code>max_total_exhausted</code>. По умолчанию 200.
                Это означает: <em>"всё, что разумно, уже проверили — нужно вмешательство"</em>.
            </span>
        </label>

        <button type="submit" class="btn btn-primary">Сохранить</button>
    </form>

    <details style="margin-top: 12px;">
        <summary class="muted small" style="cursor: pointer;">ℹ️ Как это работает</summary>
        <div class="muted small" style="margin-top: 6px; padding: 8px; background: rgba(255,255,255,0.03); border-radius: 6px; line-height: 1.5;">
            <ol>
                <li>Первый tick: маска даёт N кандидатов начиная от <code>oldDomain+1</code>.</li>
                <li>Каждый проверяется через Namecheap API <code>checkDomain</code>.</li>
                <li>Если кандидат свободен — покупаем, стадия завершена ✓.</li>
                <li>Если все N в этом батче заняты — сохраняем последний проверенный
                    в <code>artifacts.domain_purchasing_stage.last_checked_domain</code>,
                    следующий tick (через 30 сек) продолжает от него.</li>
                <li>Так продолжается пока не найдём свободный или не упрёмся в общий потолок.</li>
            </ol>
            <p>
                <strong>Прогресс</strong> виден в логе джобы: каждый tick пишет
                <em>"Кандидаты по маске: ... (продолжаем с #N, уже проверено M)"</em>.
            </p>
        </div>
    </details>
</section>

<!-- v17.1: xmlstock.com — основной метод проверки индексации -->
<section class="card">
    <h2>🔍 XML Search API (xmlstock.com)</h2>
    <p class="muted small">
        Платный сервис XML Search API Яндекса. Если включён, используется как
        <strong>основной метод</strong> проверки индексации в стадии <code>index_watching</code>.
        Намного быстрее чем Webmaster API (который кешируется на стороне Яндекса).
        Если отключён — fallback на 4 метода Webmaster API.
    </p>

    <?php
    $xs = [];
    try {
        $stXs = DB::pdo()->query("SELECT * FROM xmlstock_settings WHERE id = 1");
        $xs = $stXs->fetch() ?: [];
    } catch (\Throwable $e) {}
    ?>

    <form method="post" action="/settings/xmlstock" class="form-card form-card--inline">
        <label class="checkbox">
            <input type="checkbox" name="enabled" value="1" <?= !empty($xs['enabled']) ? 'checked' : '' ?>>
            <strong>Включён</strong> — использовать xmlstock как основной метод проверки
        </label>

        <label>Endpoint XML
            <input type="text" name="endpoint_xml"
                   value="<?= htmlspecialchars((string)($xs['endpoint_xml'] ?? 'https://xmlstock.com/yandexlive/xml/')) ?>"
                   placeholder="https://xmlstock.com/yandexlive/xml/">
            <span class="muted small">URL endpoint'а xmlstock. Default: <code>https://xmlstock.com/yandexlive/xml/</code></span>
        </label>

        <label>User (login)
            <input type="text" name="user_id"
                   value="<?= htmlspecialchars((string)($xs['user_id'] ?? '')) ?>"
                   placeholder="ваш user из xmlstock.com">
        </label>

        <label>Key (API key)
            <input type="text" name="api_key"
                   value="<?= htmlspecialchars((string)($xs['api_key'] ?? '')) ?>"
                   placeholder="ваш API key">
            <span class="muted small">Найти можно на странице xmlstock.com → Личный кабинет → API.</span>
        </label>

        <label>Дневной лимит (информационно)
            <input type="number" name="daily_quota_limit" min="0"
                   value="<?= (int)($xs['daily_quota_limit'] ?? 1000) ?>">
            <span class="muted small">
                Не используется в логике, только для отображения в UI.
                За сегодня сделано: <strong><?= (int)($xs['queries_today'] ?? 0) ?></strong> запросов
                (за <?= htmlspecialchars((string)($xs['queries_today_date'] ?: '—')) ?>).
            </span>
        </label>

        <!-- v18.1.28: URL balance API XMLStock — для статус-бара -->
        <label>URL Balance API <span class="muted small">(опционально)</span>
            <input type="text" name="balance_endpoint"
                   value="<?= htmlspecialchars((string)($xs['balance_endpoint'] ?? '')) ?>"
                   placeholder="https://xmlstock.com/api/balance/">
            <span class="muted small">
                Если задан — сервис будет использовать этот URL для получения баланса.
                Если пуст — сервис автоматически перебирает кандидаты и кеширует рабочий.
                Точный URL смотри в xmlstock.com → Личный кабинет → API → Получение информации о балансе.
            </span>
        </label>

        <?php if (!empty($xs['last_validated_at'])): ?>
        <fieldset>
            <legend>Последняя проверка</legend>
            <p class="muted small">
                <?= htmlspecialchars(Time::msk((string)$xs['last_validated_at'], 'Y-m-d H:i:s')) ?>:
                <?php if (!empty($xs['last_validation_ok'])): ?>
                    <span style="color: var(--success);">✅ OK</span>
                <?php else: ?>
                    <span style="color: var(--danger);">⚠ Ошибка</span>
                <?php endif; ?>
                — <?= htmlspecialchars((string)($xs['last_validation_error'] ?? '')) ?>
            </p>
        </fieldset>
        <?php endif; ?>

        <div class="form-row">
            <button type="submit" class="btn btn-primary">Сохранить</button>
        </div>
    </form>

    <form method="post" action="/settings/xmlstock-test" style="margin-top: 12px;">
        <fieldset>
            <legend>Тест запроса</legend>
            <label>Тестовый домен (для запроса site:HOST)
                <input type="text" name="test_host" value="yandex.ru" placeholder="yandex.ru">
            </label>
            <button type="submit" class="btn btn-secondary">Отправить тестовый запрос</button>
            <p class="muted small">
                Сделает 1 запрос с текущими настройками. <strong>Расходует 1 единицу лимита.</strong>
            </p>
        </fieldset>
    </form>
</section>
