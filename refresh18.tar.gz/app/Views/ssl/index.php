<?php
/** @var array $rows @var int $total @var int $page @var int $perPage
 *  @var array $filters @var array $summary @var array|null $batch */
function ssl_badge(?array $s): string {
    $status = $s['status'] ?? 'not_checked';
    if (empty($s) || empty($s['checked_at'])) $status = 'not_checked';
    $map = [
        'trusted'           => ['green',  '🟢', 'Trusted'],
        'self_signed'       => ['yellow', '🟡', 'Self-signed'],
        'ssl_issuing'       => ['yellow', '🟡', 'Выпуск SSL'],
        'verify_pending'    => ['orange', '🟠', 'Verification'],
        'hostname_mismatch' => ['red',    '⚠',  'Mismatch'],
        'expired'           => ['red',    '⛔', 'Expired'],
        'not_yet_valid'     => ['red',    '⛔', 'Ещё не действует'],
        'site_error'        => ['red',    '⛔', 'Сайт не отвечает'],
        'unreachable'       => ['red',    '⛔', 'Недоступен'],
        'not_checked'       => ['gray',   '⚪', 'Не проверялся'],
    ];
    [$cls, $icon, $label] = $map[$status] ?? ['gray', '⚪', htmlspecialchars($status)];
    // критические различимы не только цветом — иконка + текст
    return '<span class="ssl-badge ssl-badge--' . $cls . '" title="' . htmlspecialchars($label) . '">' . $icon . ' ' . $label . '</span>';
}
$scope = $filters['scope'];
$totalPages = max(1, (int)ceil($total / $perPage));
function ssl_qs(array $over): string {
    $base = $_GET; foreach ($over as $k=>$v){ if($v===null) unset($base[$k]); else $base[$k]=$v; }
    return '/ssl?' . http_build_query($base);
}
// карточка-фильтр: клик ведёт на фильтр по статусу/доступности
function ssl_card(string $label, $num, string $filterKey, string $filterVal, array $filters): string {
    $active = isset($filters[$filterKey]) && $filters[$filterKey] === $filterVal && $filterVal !== '';
    $href = ssl_qs([$filterKey => ($filterVal !== '' ? $filterVal : null), 'page'=>null]);
    return '<a class="ssl-card' . ($active ? ' ssl-card--active' : '') . '" href="' . htmlspecialchars($href) . '">'
        . '<span class="ssl-card__num">' . (int)$num . '</span><span class="ssl-card__label">' . htmlspecialchars($label) . '</span></a>';
}
?>
<h1 class="page-title">SSL и доступность доменов</h1>

<?php
// v25.2-b: компактный heartbeat двух cron (основной + SSL). Два блока, без раздувания.
$hb = $cronHeartbeat ?? [];
$hbColor = ['green'=>'#28a745','yellow'=>'#ffc107','red'=>'#dc3545','gray'=>'#adb5bd'];
if (!function_exists('hb_block')) {
    function hb_block(array $c, array $colors): string {
        $dot = $colors[$c['color']] ?? '#adb5bd';
        $ago = $c['ago_sec'] === null ? '—' : ($c['ago_sec'] . ' сек назад');
        $last = $c['last_run_at'] ? htmlspecialchars((string)$c['last_run_at']) : '—';
        $proc = $c['processed'] === null ? '' : (' · обработано: ' . (int)$c['processed']);
        $dur = ($c['duration'] === null) ? '' : (' · ' . htmlspecialchars((string)$c['duration']) . 'с');
        $err = !empty($c['last_error']) ? '<div class="hb-err" style="color:#dc3545;font-size:.85em;margin-top:2px;">⚠ ' . htmlspecialchars(mb_substr((string)$c['last_error'],0,120)) . '</div>' : '';
        return '<div class="hb-card" style="flex:1;min-width:240px;border:1px solid #e3e6ea;border-radius:8px;padding:10px 14px;">'
            . '<div style="display:flex;align-items:center;gap:8px;">'
            . '<span style="width:10px;height:10px;border-radius:50%;background:' . $dot . ';display:inline-block;"></span>'
            . '<b>' . htmlspecialchars($c['label']) . '</b>'
            . '<span style="color:#6c757d;font-size:.85em;">' . htmlspecialchars($c['status_text']) . '</span>'
            . '</div>'
            . '<div style="color:#6c757d;font-size:.85em;margin-top:4px;">Последний запуск: ' . $last . ' (' . htmlspecialchars($ago) . ')' . $proc . $dur . '</div>'
            . $err
            . '</div>';
    }
}
if (!empty($hb)): ?>
<div class="hb-row" style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px;">
    <?php if (isset($hb['main'])) echo hb_block($hb['main'], $hbColor); ?>
    <?php if (isset($hb['ssl'])) echo hb_block($hb['ssl'], $hbColor); ?>
</div>
<?php
// Предупреждение: если SSL-cron красный, а в очереди есть домены.
$sslRed = ($hb['ssl']['color'] ?? '') === 'red';
$queuedN = (int)($summary['queued'] ?? 0);
if ($sslRed && $queuedN > 0): ?>
<div class="hb-warn" style="background:#fff3cd;border:1px solid #ffeeba;border-radius:8px;padding:10px 14px;margin-bottom:16px;color:#856404;">
    ⚠ SSL-cron не запускался вовремя, а в очереди <?= $queuedN ?> домен(ов). Проверка поставлена в очередь, но может задерживаться. Критический выпуск trusted SSL для активных джоб при этом продолжает работать через основной cron.
</div>
<?php endif; endif; ?>

<div class="ssl-cards">
    <?= ssl_card('Всего активных', $summary['total'], 'status', '', $filters) ?>
    <?= ssl_card('В очереди', $summary['queued'] ?? 0, 'batch', 'queued', $filters) ?>
    <?= ssl_card('Проверяются', $summary['checking'], 'batch', 'checking', $filters) ?>
    <?= ssl_card('Trusted', $summary['trusted'], 'status', 'trusted', $filters) ?>
    <?= ssl_card('Self-signed', $summary['self_signed'], 'status', 'self_signed', $filters) ?>
    <?= ssl_card('Истекают', $summary['expiring'], 'status', '', $filters) ?>
    <?= ssl_card('Ошибки', $summary['hostname_errors'] + $summary['unreachable'], 'status', 'errors', $filters) ?>
    <?= ssl_card('Не проверялись', $summary['not_checked'], 'status', 'not_checked', $filters) ?>
</div>

<form method="get" action="/ssl" class="ssl-toolbar">
    <input type="hidden" name="scope" value="<?= htmlspecialchars($scope) ?>">
    <input type="text" name="q" value="<?= htmlspecialchars($filters['q']) ?>" placeholder="Поиск по домену…" class="ssl-toolbar__search">
    <select name="status" class="ssl-toolbar__sel">
        <option value="">SSL: все</option>
        <?php foreach (['errors'=>'⛔ Ошибки (все)','trusted'=>'Trusted','self_signed'=>'Self-signed','ssl_issuing'=>'Выпуск SSL','verify_pending'=>'Verification','hostname_mismatch'=>'Mismatch','expired'=>'Expired','not_yet_valid'=>'Ещё не действует','site_error'=>'Сайт не отвечает','unreachable'=>'Недоступен','not_checked'=>'Не проверялся'] as $k=>$v): ?>
            <option value="<?= $k ?>" <?= $filters['status']===$k?'selected':'' ?>><?= $v ?></option>
        <?php endforeach; ?>
    </select>
    <select name="availability" class="ssl-toolbar__sel">
        <option value="">Доступность: все</option>
        <option value="available" <?= $filters['availability']==='available'?'selected':'' ?>>Доступен</option>
        <option value="unreachable" <?= $filters['availability']==='unreachable'?'selected':'' ?>>Недоступен</option>
    </select>
    <select name="source" class="ssl-toolbar__sel">
        <option value="">Источник: все</option>
        <?php foreach (['job'=>'Джоба','purchase'=>'Покупка','alias'=>'Alias','readiness'=>'Readiness','manual'=>'Вручную'] as $k=>$v): ?>
            <option value="<?= $k ?>" <?= $filters['source']===$k?'selected':'' ?>><?= $v ?></option>
        <?php endforeach; ?>
    </select>
    <select name="server_id" class="ssl-toolbar__sel">
        <option value="0">Сервер: все</option>
        <?php foreach (($servers ?? []) as $srv): $lbl = trim((string)($srv['title'] ?? ('#'.$srv['id']))); $code = trim((string)($srv['ui_badge_code'] ?? '')); if ($code!=='') $lbl = $code.' · '.$lbl; ?>
            <option value="<?= (int)$srv['id'] ?>" <?= (int)($serverFilter ?? 0) === (int)$srv['id'] ? 'selected' : '' ?>><?= htmlspecialchars($lbl) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="per" class="ssl-toolbar__sel">
        <?php foreach ([25,50,100] as $pp): ?>
            <option value="<?= $pp ?>" <?= $perPage===$pp?'selected':'' ?>><?= $pp ?> строк</option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-secondary btn-sm">Применить</button>
    <a href="/ssl" class="btn btn-secondary btn-sm">Сброс</a>
</form>

<div class="ssl-toolbar ssl-toolbar--actions">
    <div class="ssl-scope-switch">
        <a class="btn btn-sm <?= $scope==='active'?'btn-primary':'btn-secondary' ?>" href="<?= htmlspecialchars(ssl_qs(['scope'=>'active','page'=>null])) ?>">Активные</a>
        <a class="btn btn-sm <?= $scope==='archived'?'btn-primary':'btn-secondary' ?>" href="<?= htmlspecialchars(ssl_qs(['scope'=>'archived','page'=>null])) ?>">Архив</a>
        <a class="btn btn-sm <?= $scope==='all'?'btn-primary':'btn-secondary' ?>" href="<?= htmlspecialchars(ssl_qs(['scope'=>'all','page'=>null])) ?>">Все</a>
    </div>
    <div class="page-actions">
        <button id="ssl-check-all" class="btn btn-primary btn-sm">Проверить все</button>
        <button id="ssl-stop-batch" class="btn btn-danger btn-sm" style="display:none;">Остановить batch</button>
        <a href="/ssl" class="btn btn-secondary btn-sm">Обновить</a>
        <button id="ssl-add-domain-btn" class="btn btn-secondary btn-sm">+ Добавить домен</button>
    </div>
</div>

<form id="ssl-add-domain-form" method="post" action="/ssl/add-domain" style="display:none; margin:8px 0;">
    <input type="text" name="domain" placeholder="example.casino" class="ssl-toolbar__search">
    <button type="submit" class="btn btn-primary btn-sm">Добавить в мониторинг</button>
</form>

<div id="ssl-batch-progress" class="ssl-progress" style="<?= $batch ? '' : 'display:none;' ?>"
     data-batch-id="<?= $batch ? (int)$batch['id'] : '' ?>">
    <div class="ssl-progress__bar"><div class="ssl-progress__fill" id="ssl-progress-fill"></div></div>
    <div class="ssl-progress__stats" id="ssl-progress-stats">
        <?php if ($batch): ?>
            Всего <?= (int)$batch['total'] ?> · В очереди <?= (int)$batch['queued'] ?> ·
            Проверяется <?= (int)$batch['checking'] ?> · Проверено <?= (int)$batch['done'] ?> ·
            Успешно <?= (int)$batch['ok_count'] ?> · Предупреждение <?= (int)$batch['warn_count'] ?> ·
            Ошибок <?= (int)$batch['error_count'] ?>
        <?php endif; ?>
    </div>
</div>

<?php if (empty($rows)): ?>
    <div class="empty-state">
        <?php if ($scope === 'archived'): ?>Архив пуст.
        <?php else: ?>Нет доменов в мониторинге. Домены добавляются автоматически при появлении активной джобы с новым доменом, либо вручную кнопкой «+ Добавить домен».<?php endif; ?>
    </div>
<?php else: ?>
<div class="ssl-table-scroll">
<table class="hub-table ssl-table">
    <thead><tr>
        <th>Домен</th><th>Сайт / job</th><th>Доступность</th><th>HTTP → Redirect</th>
        <th>SSL</th><th>Действует до</th><th>Последняя</th><th>Следующая</th><th>Действия</th>
    </tr></thead>
    <tbody>
    <?php foreach ($rows as $row): $s = $row['status_row']; $d = $row['domain']; ?>
        <tr data-domain="<?= htmlspecialchars($d) ?>">
            <td class="ssl-col-domain"><?php $badge = (new ServerBadgePresenter())->fromRow($row); $badgeMode = 'compact'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; ?><a href="https://<?= htmlspecialchars($d) ?>" target="_blank" rel="noopener" title="<?= htmlspecialchars($d) ?>"><?= htmlspecialchars($d) ?></a></td>
            <td>
                <?php if ($row['site_id']): ?><a href="/sites/show?id=<?= (int)$row['site_id'] ?>">#<?= (int)$row['site_id'] ?></a><?php endif; ?>
                <?php if ($row['job_id']): ?> <a href="/jobs/show?id=<?= (int)$row['job_id'] ?>">job#<?= (int)$row['job_id'] ?></a><?php endif; ?>
            </td>
            <td><?php if ($s === null || empty($s['checked_at'])) { echo '<span class="muted">—</span>'; } elseif ((int)$s['technical_ready']===1) { echo '✅ Да'; } else { echo '❌ Нет'; } ?></td>
            <td class="ssl-col-redirect" title="<?= htmlspecialchars((string)($s['http_location'] ?? '')) ?>">
                <?= $s ? (int)$s['http_code'] : '—' ?><?php if ($s && $s['http_location']): ?> → <?= htmlspecialchars(mb_substr((string)$s['http_location'],0,28)) ?><?php endif; ?>
            </td>
            <td><?= ssl_badge($s) ?></td>
            <td><?= $s && $s['valid_to'] ? htmlspecialchars(mb_substr((string)$s['valid_to'],0,10)) : '—' ?>
                <?php if ($s && $s['days_remaining'] !== null): ?><span class="muted small">(<?= (int)$s['days_remaining'] ?>д)</span><?php endif; ?></td>
            <td class="ssl-col-time"><?= $s && $s['checked_at'] ? htmlspecialchars(mb_substr((string)$s['checked_at'],0,16)) : '—' ?></td>
            <td class="ssl-col-time"><?= $s && $s['next_check_at'] ? htmlspecialchars(mb_substr((string)$s['next_check_at'],0,16)) : '—' ?></td>
            <td class="ssl-actions">
                <button class="btn btn-sm btn-secondary ssl-check-one" data-domain="<?= htmlspecialchars($d) ?>">Проверить</button>
                <a class="btn btn-sm btn-secondary" href="/ssl/show?domain=<?= urlencode($d) ?>">Подробнее</a>
                <?php if ($scope === 'active'): ?>
                    <button class="btn btn-sm btn-secondary ssl-archive" data-domain="<?= htmlspecialchars($d) ?>">В архив</button>
                <?php else: ?>
                    <button class="btn btn-sm btn-primary ssl-unarchive" data-domain="<?= htmlspecialchars($d) ?>">Вернуть</button>
                <?php endif; ?>
                <button class="btn btn-sm btn-danger ssl-remove" data-domain="<?= htmlspecialchars($d) ?>">Удалить</button>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>

<div class="ssl-pagination">
    <span class="muted small">Всего: <?= (int)$total ?> · Стр. <?= (int)$page ?>/<?= (int)$totalPages ?></span>
    <?php if ($page > 1): ?><a class="btn btn-sm btn-secondary" href="<?= htmlspecialchars(ssl_qs(['page'=>$page-1])) ?>">← Назад</a><?php endif; ?>
    <?php if ($page < $totalPages): ?><a class="btn btn-sm btn-secondary" href="<?= htmlspecialchars(ssl_qs(['page'=>$page+1])) ?>">Вперёд →</a><?php endif; ?>
</div>
<?php endif; ?>
