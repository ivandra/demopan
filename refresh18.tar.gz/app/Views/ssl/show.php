<?php
/** @var string $domain @var array|null $sslRow @var array $history @var bool $not_found */
$not_found = $not_found ?? false;
if (!function_exists('ssl_row')) {
function ssl_row(string $label, $value): string {
    $v = ($value === null || $value === '') ? '—' : htmlspecialchars((string)$value);
    return '<tr><th>' . htmlspecialchars($label) . '</th><td>' . $v . '</td></tr>';
}
}
$s = isset($sslRow) && is_array($sslRow) ? $sslRow : null;
$ips = (is_array($s) && !empty($s['resolved_ips_json'])) ? implode(', ', (array)json_decode((string)$s['resolved_ips_json'], true)) : '';
?>
<h1 class="page-title">SSL: <?php // ТЗ 040 §9.4/§9.6: бейдж из контроллера ($serverBadge).
    if (!empty($serverBadge)) { $badge = $serverBadge; $badgeMode='compact'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; }
    ?><?= htmlspecialchars($domain) ?></h1>

<?php if ($not_found): ?>
    <div class="empty-state">
        Домен <b><?= htmlspecialchars($domain) ?></b> не найден в SSL-мониторинге (404).
        <div style="margin-top:12px;">
            <a href="/ssl" class="btn btn-secondary">← К списку</a>
            <form method="post" action="/ssl/add-domain" style="display:inline;">
                <input type="hidden" name="domain" value="<?= htmlspecialchars($domain) ?>">
                <button type="submit" class="btn btn-primary">Добавить в мониторинг</button>
            </form>
        </div>
    </div>
<?php else: ?>
<div class="page-toolbar">
    <div class="page-actions">
        <a href="/ssl" class="btn btn-secondary">← К списку</a>
        <a href="https://<?= htmlspecialchars($domain) ?>" target="_blank" rel="noopener" class="btn btn-secondary">Открыть сайт</a>
        <button class="btn btn-primary ssl-check-one" data-domain="<?= htmlspecialchars($domain) ?>" data-reload="1">Проверить сейчас</button>
        <?php $mon = $s ? (int)($s['monitoring_enabled'] ?? 1) : 1; ?>
        <?php if ($s === null): ?>
            <form method="post" action="/ssl/add-domain" style="display:inline;">
                <input type="hidden" name="domain" value="<?= htmlspecialchars($domain) ?>">
                <button type="submit" class="btn btn-secondary">Добавить в мониторинг</button>
            </form>
        <?php elseif ($mon === 1): ?>
            <form method="post" action="/ssl/archive" style="display:inline;">
                <input type="hidden" name="domain" value="<?= htmlspecialchars($domain) ?>">

                <button type="submit" class="btn btn-secondary">Отключить мониторинг</button>
            </form>
        <?php else: ?>
            <form method="post" action="/ssl/unarchive" style="display:inline;">
                <input type="hidden" name="domain" value="<?= htmlspecialchars($domain) ?>">
                <button type="submit" class="btn btn-primary">Вернуть в мониторинг</button>
            </form>
        <?php endif; ?>
        <?php if ($s !== null): ?>
            <form method="post" action="/ssl/remove" style="display:inline;"
                  onsubmit="return confirm('Удалить <?= htmlspecialchars($domain) ?> из списка? История сохранится.');">
                <input type="hidden" name="domain" value="<?= htmlspecialchars($domain) ?>">
                <button type="submit" class="btn btn-danger">Удалить из списка</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php if ($s === null): ?>
    <div class="empty-state">Домен ещё не проверялся. Нажмите «Проверить сейчас».</div>
<?php else: ?>
<div class="ssl-detail">
<table class="hub-table ssl-detail-table">
<tbody>
    <?= ssl_row('Статус', $s['status']) ?>
    <?= ssl_row('Причина', $s['reason']) ?>
    <?= ssl_row('Техническая доступность', (int)$s['technical_ready']===1 ? 'Да' : 'Нет') ?>
    <?= ssl_row('DNS A/AAAA (IP)', $ips) ?>
    <?= ssl_row('HTTP (обычный UA) — код', $s['http_code']) ?>
    <?= ssl_row('HTTP — Location', $s['http_location']) ?>
    <?= ssl_row('YandexBot — код', $s['yandexbot_http_code']) ?>
    <?= ssl_row('YandexBot — Location', $s['yandexbot_location']) ?>
    <?= ssl_row('HTTPS initial', $s['https_initial_code']) ?>
    <?= ssl_row('HTTPS final', $s['https_final_code']) ?>
    <?= ssl_row('HTTPS final URL', $s['https_final_url']) ?>
    <?= ssl_row('Сайт / vhost', (int)$s['site_reachable']===1 ? 'Правильный' : ((int)$s['technical_ready']===1 ? 'Проверяется' : 'Не проверен')) ?>
    <?= ssl_row('probe HTTP-код', $s['probe_http_code']) ?>
    <?= ssl_row('probe token match', $s['probe_ok'] === null ? '—' : ((int)$s['probe_ok']===1 ? 'Да' : 'Нет')) ?>
    <?= ssl_row('TLS присутствует', (int)$s['tls_present']===1 ? 'Да' : 'Нет') ?>
    <?= ssl_row('TLS доверенный', (int)$s['tls_trusted']===1 ? 'Да' : 'Нет') ?>
    <?= ssl_row('self-signed', (int)$s['is_self_signed']===1 ? 'Да' : 'Нет') ?>
    <?= ssl_row('hostname совпадает', (int)$s['hostname_valid']===1 ? 'Да' : 'Нет') ?>
    <?= ssl_row('Issuer', $s['issuer']) ?>
    <?= ssl_row('Subject', $s['subject']) ?>
    <?= ssl_row('Serial', $s['serial_number']) ?>
    <?= ssl_row('Действует с', $s['valid_from']) ?>
    <?= ssl_row('Действует до', $s['valid_to']) ?>
    <?= ssl_row('Осталось дней', $s['days_remaining']) ?>
    <?= ssl_row('Ошибка cURL/OpenSSL', $s['error_message']) ?>
    <?= ssl_row('Источник проверки', $s['check_source']) ?>
    <?= ssl_row('Enrolment (источник)', $s['enrolled_source'] ?? null) ?>
    <?= ssl_row('Добавлен вручную', isset($s['manual_added']) ? ((int)$s['manual_added']===1 ? 'Да' : 'Нет') : '—') ?>
    <?= ssl_row('Мониторинг', isset($s['monitoring_enabled']) ? ((int)$s['monitoring_enabled']===1 ? 'Активен' : 'В архиве') : '—') ?>
    <?= ssl_row('Проверено', $s['checked_at']) ?>
    <?= ssl_row('Следующая проверка', $s['next_check_at']) ?>
</tbody>
</table>
</div>

<h2 class="page-subtitle">История проверок</h2>
<?php if (empty($history)): ?>
    <div class="empty-state">История пуста.</div>
<?php else: ?>
<div class="table-wrap">
<table class="hub-table">
    <thead><tr><th>Когда</th><th>Статус</th><th>Тех.</th><th>HTTP</th><th>HTTPS</th><th>Trusted</th><th>Self-signed</th><th>Причина</th><th>Источник</th></tr></thead>
    <tbody>
    <?php foreach ($history as $h): ?>
        <tr>
            <td><?= htmlspecialchars((string)$h['created_at']) ?></td>
            <td><?= htmlspecialchars((string)$h['status']) ?></td>
            <td><?= (int)$h['technical_ready']===1 ? 'Да' : 'Нет' ?></td>
            <td><?= $h['http_code'] !== null ? (int)$h['http_code'] : '—' ?></td>
            <td><?= $h['https_final_code'] !== null ? (int)$h['https_final_code'] : '—' ?></td>
            <td><?= (int)$h['tls_trusted']===1 ? 'Да' : 'Нет' ?></td>
            <td><?= (int)$h['is_self_signed']===1 ? 'Да' : 'Нет' ?></td>
            <td><?= htmlspecialchars((string)($h['reason'] ?? '')) ?></td>
            <td><?= htmlspecialchars((string)($h['check_source'] ?? '')) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>
<?php endif; ?>
<?php endif; ?>
<?php endif; /* not_found */ ?>
