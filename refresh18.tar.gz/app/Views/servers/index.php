<h1 class="page-title">Серверы FastPanel</h1>

<div class="page-toolbar">
    <div></div>
    <div class="page-actions">
        <a href="/servers/create" class="btn btn-primary">Добавить сервер</a>
    </div>
</div>

<?php if (empty($rows)): ?>
    <div class="empty-state">
        <p>Серверов пока нет.</p>
        <p>Без сервера FastPanel панель не сможет управлять сайтами. <a href="/servers/create">Добавить</a>.</p>
    </div>
<?php else: ?>
    <table class="hub-table">
        <thead><tr><th>#</th><th>Сервер</th><th>Хост</th><th>Логин</th><th>TLS</th><th>Посл. тест</th><th></th></tr></thead>
        <tbody>
            <?php foreach ($rows as $r): ?>
                <?php $sid = (int)$r['id']; $cnt = (int)($siteCounts[$sid] ?? 0); ?>
                <tr>
                    <td><?= $sid ?></td>
                    <td>
                        <?php $badgeRow = $r; $badgeMode = 'compact'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; ?>
                        <?= htmlspecialchars($r['title']) ?>
                        <?php if ($cnt > 0): ?><span class="muted small">· <?= $cnt ?> сайт(ов)</span><?php endif; ?>
                    </td>
                    <td><code><?= htmlspecialchars($r['host']) ?></code></td>
                    <td><?= htmlspecialchars($r['username']) ?></td>
                    <td><?= $r['verify_tls'] ? '✓' : '—' ?></td>
                    <td class="small">
                        <?php if (!empty($r['last_tested_at'])): ?>
                            <?php if ((int)($r['last_test_ok'] ?? 0) === 1): ?>
                                <span class="badge badge-ok" title="<?= htmlspecialchars((string)$r['last_tested_at']) ?>">OK</span>
                            <?php else: ?>
                                <span class="badge badge-danger" title="<?= htmlspecialchars((string)($r['last_test_error'] ?? '')) ?>">FAIL</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="row-actions">
                        <a href="/servers/edit?id=<?= $sid ?>" class="btn btn-sm">Изменить</a>
                        <button type="button" class="btn btn-sm btn-secondary" data-test-server="<?= $sid ?>"
                                data-csrf="<?= htmlspecialchars($csrfToken) ?>">Тест</button>
                        <span class="test-result" data-test-result="<?= $sid ?>"></span>
                        <form method="post" action="/servers/delete" style="display:inline"
                              onsubmit="return confirm('Удалить сервер? Разрешено только если на нём нет сайтов, кеша и активных джоб.');">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                            <input type="hidden" name="id" value="<?= $sid ?>">
                            <button type="submit" class="btn btn-sm btn-danger">×</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
