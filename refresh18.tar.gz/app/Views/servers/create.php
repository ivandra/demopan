<h1 class="page-title"><a href="/servers" class="back-link">← Серверы</a> Добавить сервер</h1>

<form method="post" action="/servers/create" class="form-card" id="server-form">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">

    <fieldset class="form-block">
        <legend>Подключение FastPanel</legend>
        <label>Название
            <input type="text" name="title" placeholder="VPS RU Fake" required>
        </label>
        <label>Host (без схемы)
            <input type="text" name="host" placeholder="37.252.0.32:8888" required>
            <span class="hint">https:// и порт по умолчанию 8888 подставятся автоматически</span>
        </label>
        <label>Логин FastPanel
            <input type="text" name="username" placeholder="fastuser" required>
            <span class="hint">Используется учётная запись FastPanel, например fastuser. Это не SSH-пользователь root.</span>
        </label>
        <label>Пароль FastPanel
            <input type="password" name="password" required>
        </label>
        <label class="checkbox">
            <input type="checkbox" name="verify_tls" value="1"> Проверять TLS-сертификат FastPanel API
        </label>
        <button type="button" class="btn btn-secondary" disabled
                title="Сначала сохраните сервер">Проверить подключение (после сохранения)</button>
    </fieldset>

    <fieldset class="form-block">
        <legend>IP сервера</legend>
        <label>Дополнительные IP
            <input type="text" name="extra_ips" id="extra_ips" placeholder="5.45.80.78">
            <span class="hint">разделители: запятая, точка с запятой, пробел, перенос строки</span>
        </label>
        <div class="allowlist-preview" data-allowlist-preview></div>
    </fieldset>

    <fieldset class="form-block">
        <legend>Маркировка</legend>
        <label>Код <input type="text" name="ui_badge_code" id="ui_badge_code" maxlength="8" placeholder="F"></label>
        <label>Подпись <input type="text" name="ui_badge_label" id="ui_badge_label" maxlength="64" placeholder="Fake"></label>
        <label>Цвет
            <input type="color" name="ui_badge_color" id="ui_badge_color" value="#A855F7">
        </label>
        <?php // ТЗ 042 §7.2/§7.3: пустой код — «не задан», не ложное «F». ?>
        <div>Предпросмотр: <span class="server-badge server-badge--empty" data-badge-preview>не задан</span></div>
    </fieldset>

    <button type="submit" class="btn btn-primary">Сохранить</button>
    <a href="/servers" class="btn btn-secondary">Отмена</a>
</form>
