<h1 class="page-title"><a href="/servers" class="back-link">← Серверы</a> Изменить сервер</h1>

<?php // ТЗ 042 §3.2: форма работает с $server (не $row). §3.5: autocomplete=off. ?>
<form method="post" action="/servers/edit" class="form-card" id="server-form" autocomplete="off">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
    <input type="hidden" name="id" value="<?= (int)($server['id'] ?? 0) ?>">

    <fieldset class="form-block">
        <legend>Подключение FastPanel</legend>
        <label>Название
            <input type="text" name="title" value="<?= htmlspecialchars((string)($server['title'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required>
        </label>
        <label>Host (без схемы)
            <input type="text" name="host" value="<?= htmlspecialchars((string)($server['host'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required>
        </label>
        <label>Логин FastPanel
            <input type="text" name="username" autocomplete="off" value="<?= htmlspecialchars((string)($server['username'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required>
            <span class="hint">Используется учётная запись FastPanel, например fastuser. Это не SSH-пользователь root.</span>
        </label>
        <label>Пароль FastPanel (пусто — не менять)
            <?php // §3.4: пароль не выводится; пустое поле = не менять password_enc. ?>
            <input type="password" name="password" autocomplete="new-password">
        </label>
        <label class="checkbox">
            <input type="checkbox" name="verify_tls" value="1" <?= !empty($server['verify_tls']) ? 'checked' : '' ?>> Проверять TLS API
        </label>
        <button type="button" class="btn btn-secondary" data-test-server="<?= (int)($server['id'] ?? 0) ?>"
                data-csrf="<?= htmlspecialchars($csrfToken) ?>">Проверить сохранённое подключение</button>
        <span class="test-result" data-test-result="<?= (int)($server['id'] ?? 0) ?>"></span>
        <?php if (!empty($server['last_tested_at'])): ?>
            <p class="muted small">Последний тест: <?= htmlspecialchars((string)$server['last_tested_at']) ?> —
                <?= (int)($server['last_test_ok'] ?? 0) === 1 ? 'OK' : 'FAIL' ?>
                <?php if ((int)($server['last_test_ok'] ?? 0) !== 1 && !empty($server['last_test_error'])): ?>
                    (<?= htmlspecialchars((string)$server['last_test_error']) ?>)
                <?php endif; ?>
            </p>
        <?php endif; ?>
    </fieldset>

    <fieldset class="form-block">
        <legend>IP сервера</legend>
        <label>Дополнительные IP
            <input type="text" name="extra_ips" id="extra_ips" value="<?= htmlspecialchars((string)($server['extra_ips'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
            <span class="hint">разделители: запятая, точка с запятой, пробел, перенос строки</span>
        </label>
        <div class="allowlist-preview" data-allowlist-preview></div>
    </fieldset>

    <fieldset class="form-block">
        <legend>Маркировка</legend>
        <label>Код <input type="text" name="ui_badge_code" id="ui_badge_code" maxlength="8" value="<?= htmlspecialchars((string)($server['ui_badge_code'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="F"></label>
        <label>Подпись <input type="text" name="ui_badge_label" id="ui_badge_label" maxlength="64" value="<?= htmlspecialchars((string)($server['ui_badge_label'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="Fake"></label>
        <label>Цвет
            <input type="color" name="ui_badge_color" id="ui_badge_color" value="<?= htmlspecialchars((string)(($server['ui_badge_color'] ?? '') ?: '#A855F7'), ENT_QUOTES, 'UTF-8') ?>">
        </label>
        <?php
            // ТЗ 042 §7.2: server-side preview. present() возвращает null при пустом
            // коде — тогда показываем «не задан», НЕ ложное «F».
            $prev = (new ServerBadgePresenter())->present(
                $server['ui_badge_code'] ?? null,
                $server['ui_badge_label'] ?? null,
                $server['ui_badge_color'] ?? null,
                $server['title'] ?? null
            );
        ?>
        <?php if ($prev === null): ?>
        <div>Предпросмотр: <span class="server-badge server-badge--empty" data-badge-preview>не задан</span></div>
        <?php else: ?>
        <div>Предпросмотр: <span class="server-badge" data-badge-preview style="background:<?= htmlspecialchars((string)$prev['color']) ?>;color:<?= htmlspecialchars((string)$prev['text_color']) ?>"><?= htmlspecialchars((string)$prev['code']) ?></span></div>
        <?php endif; ?>
    </fieldset>

    <button type="submit" class="btn btn-primary">Сохранить</button>
    <a href="/servers" class="btn btn-secondary">Отмена</a>
</form>
