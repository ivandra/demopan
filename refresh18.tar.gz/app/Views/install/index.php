<?php
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
$flash = $_SESSION['flash'] ?? [];
unset($_SESSION['flash']);
?><!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Refresh Panel — Установка</title>
<link rel="stylesheet" href="/assets/admin.css">
</head>
<body class="login-body">
<div class="install-card">
    <h1>🛠️ Установка Refresh Panel</h1>

    <?php foreach (['success' => 'success', 'error' => 'error', 'warning' => 'warning'] as $type => $cls): ?>
        <?php if (!empty($flash[$type])): ?>
            <?php foreach ((array)$flash[$type] as $msg): ?>
                <div class="hub-flash hub-flash--<?= $cls ?>"><?= htmlspecialchars((string)$msg) ?></div>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php endforeach; ?>

    <h2>1. Подключение к БД</h2>
    <?php if ($dbOk): ?>
        <div class="hub-flash hub-flash--success">✅ Подключение к БД работает</div>
    <?php else: ?>
        <div class="hub-flash hub-flash--error">
            ❌ Не удалось подключиться к БД:<br>
            <code><?= htmlspecialchars($dbError) ?></code><br><br>
            Проверьте <code>config/db.php</code>: реквизиты, имя БД, доступ пользователя.
        </div>
    <?php endif; ?>

    <h2>2. Миграции</h2>
    <table class="hub-table">
        <thead><tr><th>Миграция</th><th>Статус</th></tr></thead>
        <tbody>
            <?php foreach ($migrations as $m): ?>
                <?php $isApplied = isset($applied[$m['name']]); ?>
                <tr>
                    <td><code><?= htmlspecialchars($m['name']) ?></code></td>
                    <td>
                        <?php if ($isApplied): ?>
                            <span class="pill pill-ok">applied</span>
                        <?php else: ?>
                            <span class="pill pill-warn">pending</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if ($dbOk): ?>
        <form method="post" action="/install/run" class="install-actions">
            <button type="submit" class="btn btn-primary">Применить миграции и завершить установку</button>
        </form>
    <?php endif; ?>

    <p class="muted small">
        После завершения установки вы будете перенаправлены на страницу входа.
        Логин и пароль настраиваются в <code>config/app.php</code>.
    </p>
</div>
</body>
</html>
