<?php
/**
 * @var array $jobs
 * @var string $filter
 * @var array $scheduledJobs
 */

// v18-fix: helper для отображения серверного DATETIME в МСК.
// v18.1.28: делегирует на Time::msk() — единый helper для всего приложения.
$fmtMsk = function (?string $serverDatetime): string {
    return Time::msk($serverDatetime);
};

// v18-fix: helper для "через X" формата
$fmtRelative = function (int $secondsUntil): string {
    if ($secondsUntil < 60)        return "через {$secondsUntil} сек";
    if ($secondsUntil < 3600)      return "через " . (int)round($secondsUntil / 60) . " мин";
    if ($secondsUntil < 86400)     return "через " . round($secondsUntil / 3600, 1) . " ч";
    return "через " . round($secondsUntil / 86400, 1) . " дн";
};

$scheduledJobs = $scheduledJobs ?? [];
?>

<h1 class="page-title">Джобы перевыставления</h1>

<div class="page-toolbar">
    <div class="hub-statusline">
        <div class="hub-statusline__left">
            <a href="/jobs?filter=all<?= $serverFilter ? '&server_id='.(int)$serverFilter : '' ?>"       class="btn <?= $filter === 'all'       ? 'btn-primary' : 'btn-secondary' ?>">Все</a>
            <a href="/jobs?filter=active<?= $serverFilter ? '&server_id='.(int)$serverFilter : '' ?>"    class="btn <?= $filter === 'active'    ? 'btn-primary' : 'btn-secondary' ?>">Активные</a>
            <a href="/jobs?filter=scheduled<?= $serverFilter ? '&server_id='.(int)$serverFilter : '' ?>" class="btn <?= $filter === 'scheduled' ? 'btn-primary' : 'btn-secondary' ?>"
               <?php if (!empty($scheduledJobs) && $filter !== 'scheduled'): ?>style="border-color:#3a7bd5;"<?php endif; ?>>
                ⏰ Запланированы
                <?php if (!empty($scheduledJobs)): ?>
                    <span style="display:inline-block; margin-left:4px; padding:1px 6px; background:rgba(58, 123, 213, 0.3); border-radius: 8px; font-size:0.8em;"><?= count($scheduledJobs) ?></span>
                <?php endif; ?>
            </a>
            <a href="/jobs?filter=awaiting<?= $serverFilter ? '&server_id='.(int)$serverFilter : '' ?>"  class="btn <?= $filter === 'awaiting'  ? 'btn-primary' : 'btn-secondary' ?>">
                ⏳ Ожидают действия<?php if (!empty($awaitingCount)): ?> <b><?= (int)$awaitingCount ?></b><?php endif; ?>
            </a>
            <a href="/jobs?filter=done<?= $serverFilter ? '&server_id='.(int)$serverFilter : '' ?>"      class="btn <?= $filter === 'done'      ? 'btn-primary' : 'btn-secondary' ?>">Завершённые</a>
            <a href="/jobs?filter=failed<?= $serverFilter ? '&server_id='.(int)$serverFilter : '' ?>"    class="btn <?= $filter === 'failed'    ? 'btn-primary' : 'btn-secondary' ?>">Упавшие</a>
        </div>
        <div class="hub-statusline__right">
            <?php include Paths::appRoot() . '/app/Views/partials/server_filter.php'; ?>
        </div>
    </div>
</div>

<?php /* v18-fix: блок запланированных джоб (всегда показывается если есть, кроме фильтра scheduled — там и так список) */ ?>
<?php if (!empty($scheduledJobs) && $filter !== 'scheduled'): ?>
    <div class="card" style="border:2px solid #3a7bd5; background:rgba(58, 123, 213, 0.05); margin-bottom: 16px;">
        <h3 style="margin-top:0;">⏰ Запланированные джобы (<?= count($scheduledJobs) ?>)</h3>
        <p class="muted small" style="margin-bottom: 12px;">
            Эти джобы созданы с отложенным стартом и cron подхватит их когда наступит указанное время.
            <?php
            $nowMskStr = (new \DateTime('now', new \DateTimeZone('Europe/Moscow')))->format('Y-m-d H:i');
            ?>
            Сейчас в Москве: <code><?= htmlspecialchars($nowMskStr) ?></code>.
        </p>
        <table style="width:100%; border-collapse:collapse; font-size:0.9em;">
            <thead>
                <tr style="background: rgba(58, 123, 213, 0.08);">
                    <th style="padding:8px; text-align:left;">#</th>
                    <th style="padding:8px; text-align:left;">Сайт</th>
                    <th style="padding:8px; text-align:left;">Режим</th>
                    <th style="padding:8px; text-align:left;">Старт</th>
                    <th style="padding:8px;"></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($scheduledJobs as $sj): ?>
                <?php
                $secondsUntil = strtotime((string)$sj['next_run_at']) - time();
                $modeLabels = [
                    'refresh'      => '🔄 Перевыставление',
                    'move_indexed' => '🚚 Переезд (с инд.)',
                    'move_simple'  => '🚚 Переезд (без инд.)',
                ];
                $modeLabel = $modeLabels[$sj['mode'] ?? 'refresh'] ?? ($sj['mode'] ?? 'refresh');
                ?>
                <tr style="border-top: 1px solid var(--border);">
                    <td style="padding:8px;">#<?= (int)$sj['id'] ?></td>
                    <td style="padding:8px;">
                        <?php $badgeRow = $sj; $badgeMode = 'compact'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; ?>
                        <code><?= htmlspecialchars((string)($sj['current_domain'] ?? $sj['old_domain'])) ?></code>
                    </td>
                    <td style="padding:8px;"><?= htmlspecialchars($modeLabel) ?></td>
                    <td style="padding:8px;">
                        <code><?= htmlspecialchars($fmtMsk((string)$sj['next_run_at'])) ?></code>
                        <small class="muted" style="margin-left:6px;">(<?= htmlspecialchars($fmtRelative($secondsUntil)) ?>)</small>
                    </td>
                    <td style="padding:8px;">
                        <a href="/jobs/show?id=<?= (int)$sj['id'] ?>" class="btn btn-secondary" style="padding: 4px 12px; font-size:0.85em;">Открыть</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php if (empty($jobs)): ?>
    <div class="card">
        <p style="color: var(--text-muted); text-align:center; padding: 40px;">
            Пока нет джоб. Откройте карточку сайта и нажмите «Перевыставить».
        </p>
    </div>
<?php else: ?>
    <div class="card" style="padding: 0;">
        <table style="width:100%; border-collapse: collapse;">
            <thead>
                <tr style="background: var(--bg-elevated);">
                    <th style="padding: 12px; text-align: left;">#</th>
                    <th style="padding: 12px; text-align: left;">Сайт / старый домен</th>
                    <th style="padding: 12px; text-align: left;">Новый домен</th>
                    <th style="padding: 12px; text-align: left;">Стадия</th>
                    <th style="padding: 12px; text-align: left;">Статус</th>
                    <th style="padding: 12px; text-align: left;">Создана</th>
                    <th style="padding: 12px; text-align: left;"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($jobs as $j): ?>
                    <?php
                    $statusCls = [
                        'pending' => '',
                        'running' => 'is-warn',
                        'ok'      => 'is-ok',
                        'failed'  => 'is-bad',
                    ][$j['stage_status']] ?? '';
                    $stageCls = $j['stage'] === 'done' ? 'is-ok'
                              : ($j['stage'] === 'failed' ? 'is-bad' : 'is-info');
                    ?>
                    <tr style="border-top: 1px solid var(--border);">
                        <td style="padding: 12px;">#<?= (int)$j['id'] ?></td>
                        <td style="padding: 12px;">
                            <?php $badgeRow = $j; $badgeMode = 'compact'; include Paths::appRoot() . '/app/Views/partials/server_badge.php'; ?>
                            <code><?= htmlspecialchars($j['old_domain']) ?></code>
                        </td>
                        <td style="padding: 12px;">
                            <?php if ($j['new_domain']): ?>
                                <code style="color: var(--success);"><?= htmlspecialchars($j['new_domain']) ?></code>
                            <?php else: ?>
                                <span style="color: var(--text-muted);">—</span>
                            <?php endif; ?>
                        </td>
                        <td style="padding: 12px;">
                            <span class="hub-mini-pill <?= $stageCls ?>">
                                <span class="hub-mini-pill__dot"></span>
                                <?= htmlspecialchars(JobEventLogger::stageLabel((string)$j['stage'])) ?>
                            </span>
                            <?php /* v18-fix: индикатор отложенного старта */ ?>
                            <?php
                            $isScheduled = ($j['stage'] === 'queued'
                                && $j['stage_status'] === 'pending'
                                && !empty($j['next_run_at'])
                                && strtotime((string)$j['next_run_at']) > time());
                            ?>
                            <?php if ($isScheduled): ?>
                                <?php
                                $secondsUntil = strtotime((string)$j['next_run_at']) - time();
                                if ($secondsUntil < 60)        $eta = "через {$secondsUntil} сек";
                                elseif ($secondsUntil < 3600)  $eta = "через " . (int)round($secondsUntil / 60) . " мин";
                                elseif ($secondsUntil < 86400) $eta = "через " . round($secondsUntil / 3600, 1) . " ч";
                                else                           $eta = "через " . round($secondsUntil / 86400, 1) . " дн";
                                ?>
                                <span style="display:inline-block; margin-left:6px; padding:2px 8px;
                                       background: rgba(58, 123, 213, 0.2); color:#3a7bd5;
                                       border-radius: 10px; font-size: 0.8em;"
                                      title="Отложенный старт: <?= htmlspecialchars($fmtMsk((string)$j['next_run_at'])) ?>">
                                    ⏰ <?= htmlspecialchars($eta) ?>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td style="padding: 12px;">
                            <span class="hub-mini-pill <?= $statusCls ?>">
                                <span class="hub-mini-pill__dot"></span>
                                <?= htmlspecialchars(JobEventLogger::statusLabel((string)$j['stage_status'])) ?>
                            </span>
                        </td>
                        <td style="padding: 12px; font-size: 0.85em; color: var(--text-muted);">
                            <?= htmlspecialchars($fmtMsk((string)$j['created_at'])) ?>
                        </td>
                        <td style="padding: 12px;">
                            <a href="/jobs/show?id=<?= (int)$j['id'] ?>" class="btn btn-secondary">Открыть</a>
                        </td>
                    </tr>
                    <?php
                    // v23: строка-пояснение для джоб, ожидающих действия оператора.
                    // Пока джоба в этом статусе, для её сайта нельзя создать новую.
                    $aw = $awaitingInfo[(int)$j['id']] ?? null;
                    ?>
                    <?php if ($aw): ?>
                        <tr style="background: rgba(240,160,32,0.07);">
                            <td colspan="7" style="padding: 6px 12px 12px 12px; font-size: 0.85em;">
                                <span style="color:#f0a020">⏳ Ожидает действия <?= htmlspecialchars((string)$aw['waiting']) ?>:</span>
                                <b><?= htmlspecialchars((string)$aw['action']) ?></b>
                                <div style="color: var(--text-muted); margin-top: 3px;">
                                    <?= htmlspecialchars((string)$aw['hint']) ?>
                                </div>
                                <div style="color: var(--text-muted); margin-top: 3px;">
                                    Сайт заблокирован для новых джоб, пока эта не завершена.
                                    <a href="/jobs/show?id=<?= (int)$j['id'] ?>">Открыть карточку</a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
