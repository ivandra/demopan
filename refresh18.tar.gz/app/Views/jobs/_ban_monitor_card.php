<?php
/**
 * §7 — карточка «Фоновый мониторинг бана» в джобе. Read-only; тёмная тема, без
 * светлых подложек и сырого JSON на основном экране. Ожидает: $banMonitor (row|null),
 * $banChecks (<=10), $banCounts (['today','total']), $banEligible, $job.
 * Ручные действия — на /xmlstock (§7.3: ссылка ведёт на строку монитора).
 */
$bm = $banMonitor ?? null;
$bc = $banChecks ?? [];
$bcnt = $banCounts ?? ['today' => 0, 'total' => 0];
$el = $banEligible ?? ['eligible' => false, 'generation' => null, 'eligible_since' => null, 'enrollment_on' => false];
$e = static fn($v) => htmlspecialchars((string)$v);
$msk = static function ($u, string $fmt = 'd.m.Y H:i'): string {
    $s = (string)($u ?? '');
    // Time::msk сам добавляет метку «МСК»
    return $s === '' ? '—' : (class_exists('Time') ? Time::msk($s, $fmt) : $s);
};
?>
<div class="card">
    <h3 style="margin-top:0;">🛡️ Фоновый мониторинг бана (XMLStock)</h3>
<?php if (!$bm): ?>
    <?php if (!empty($el['eligible'])): ?>
    <p class="muted" style="margin-bottom:6px;">
        <b>Будет подключён после первой подтверждённой индексации</b> нового домена.
        Первая проверка бана начнётся с задержкой по действующей схеме.
    </p>
    <?php else:
        // §7.2: три понятных состояния. «До активации» — job старше cutoff;
        // иначе enrollment был выключен при создании.
        $minId = $el['activation_min_job_id'] ?? null;
        $started = (string)($el['activation_started_at'] ?? '');
        $created = (string)($el['job_created_at'] ?? '');
        $beforeActivation = !empty($el['enrollment_on']) && (
            ($minId !== null && (int)($job['id'] ?? 0) < (int)$minId)
            || ($started !== '' && $created !== '' && strtotime($created) < strtotime($started))
        );
    ?>
    <p class="muted" style="margin-bottom:6px;">
        <b>Не подключён: <?= $beforeActivation ? 'джоба создана до активации мониторинга' : 'подключение новых джоб было выключено' ?>.</b><br>
        <span class="small">Автоматического подключения исторических джоб нет. При необходимости монитор можно
        поставить вручную по job id: <a href="/xmlstock?tab=settings">/xmlstock → Настройки → «Подключить существующую джобу»</a>.</span>
    </p>
    <?php endif; ?>
    <details class="technical-details">
        <summary class="muted small" style="cursor:pointer;">Технические детали</summary>
        <table class="kv-table" style="margin-top:6px;">
            <tr><th>eligible</th><td><?= !empty($el['eligible']) ? 'да' : 'нет' ?></td></tr>
            <tr><th>generation</th><td><?= $el['generation'] !== null ? (int)$el['generation'] : 'NULL' ?></td></tr>
            <tr><th>eligible_since</th><td><?= $e($msk($el['eligible_since'] ?? null)) ?></td></tr>
            <tr><th>enrollment сейчас</th><td><?= !empty($el['enrollment_on']) ? 'включён' : 'выключен' ?></td></tr>
        </table>
    </details>
<?php else:
    $st = (string)$bm['state'];
    $tone = XmlStockLabels::monitorTone($st);
    $pol = BanMonitoringPolicy::fromJson($bm['policy_snapshot_json'] ?? null);
    $probable = $pol->probableNegativeCount();
    $total = $pol->requiredNegativeTotal();
    $streak = (int)$bm['negative_streak'];
    $lastCheck = $bc[0] ?? null;
    $techLast = $lastCheck && (string)($lastCheck['result'] ?? '') === 'technical_error';
    $blk = (string)($bm['blocked_reason'] ?? '');
?>
    <!-- §7.3: компактная верхняя строка -->
    <p style="margin:0 0 4px;">
        <span class="xmlstock-monitor-state xmlstock-monitor-state--<?= $e($tone) ?>" title="<?= $e($st) ?>"><?= $e(XmlStockLabels::monitorState($st)) ?></span>
        <?php if ($blk !== ''): ?><span class="xmlstock-monitor-state xmlstock-monitor-state--warn">Заблокирован: <?= $e(XmlStockLabels::blockedReason($blk)) ?></span><?php endif; ?>
        <?php if ($techLast): ?><span class="small" style="color:var(--warning);">⚠ последняя проверка — техническая ошибка (не считается отрицательной)</span><?php endif; ?>
    </p>
    <?php if (in_array($st, ['confirming', 'insurance'], true) || ($streak > 0 && $st !== 'banned')): ?>
    <p style="margin:2px 0;"><b style="color:var(--warning);">Подозрение на бан · <?= $streak ?> из <?= $total ?> отрицательных проверок</b><br>
        <span class="muted small">Первая пропажа: <?= $e($msk($bm['first_negative_at'] ?? null)) ?> · следующая проверка: <?= $e($msk($bm['next_check_at'] ?? null)) ?></span></p>
    <?php elseif ($st === 'banned'): ?>
    <p style="margin:2px 0;"><b style="color:var(--danger);">Бан подтверждён: <?= $e($msk($bm['banned_confirmed_at'] ?? $bm['last_check_at'] ?? null)) ?></b><br>
        <span class="muted small">Мониторинг остановлен; следующих проверок нет.</span></p>
    <?php else: ?>
    <p style="margin:2px 0;" class="small">Последний раз найден: <b><?= $e($msk($bm['last_positive_at'] ?? null)) ?></b> · <?= (int)($bm['last_positive_pages'] ?? 0) ?> стр.<br>
        Следующая проверка: <b><?= $e($msk($bm['next_check_at'] ?? null)) ?></b></p>
    <?php endif; ?>

    <!-- 4–6 ключевых полей -->
    <table class="kv-table" style="margin:8px 0;">
        <tr><th>Прогресс серии</th><td><?= $streak ?> / <?= $total ?> (порог подозрения <?= $probable ?>)</td></tr>
        <tr><th>Запросов XMLStock</th><td>сегодня <?= (int)$bcnt['today'] ?> · всего <?= (int)$bcnt['total'] ?></td></tr>
        <tr><th>Впервые в индексе</th><td><?= $e($msk($bm['indexed_at'] ?? null)) ?></td></tr>
        <tr><th>Подключение</th><td><?= $e(XmlStockLabels::enrollmentSource($bm['enrollment_source'] ?? 'automatic')) ?></td></tr>
    </table>

    <p style="margin:6px 0;">
        <a class="btn btn-sm btn-secondary" href="/xmlstock?tab=monitors&monitor_id=<?= (int)$bm['id'] ?>#monitor-<?= (int)$bm['id'] ?>">Открыть монитор и расход XMLStock</a>
    </p>

    <details class="technical-details">
        <summary class="muted small" style="cursor:pointer;">Подробности</summary>
        <table class="kv-table" style="margin-top:6px;">
            <tr><th>Monitor ID</th><td>#<?= (int)$bm['id'] ?></td></tr>
            <tr><th>Generation / policy</th><td>gen <?= (int)($bm['activation_generation'] ?? 0) ?> · policy v<?= (int)($bm['policy_version'] ?? 1) ?></td></tr>
            <tr><th>Серия №</th><td><?= (int)($bm['series_no'] ?? 0) ?></td></tr>
            <tr><th>Первая пропажа</th><td><?= $e($msk($bm['first_negative_at'] ?? null)) ?></td></tr>
            <tr><th>Схема проверок</th><td class="small">первая через <?= (int)$pol->initialDelayMinutes() ?> мин · штатно каждые <?= (int)$pol->regularIntervalMinutes() ?> мин ·
                подозрение после <?= $probable ?> · затем <?= (int)$pol->insuranceNegativeCount() ?> × <?= (int)$pol->insuranceIntervalMinutes() ?> мин</td></tr>
            <?php if (!empty($bm['last_error'])): ?><tr><th>Последняя тех. ошибка</th><td class="muted small"><?= $e($bm['last_error']) ?></td></tr><?php endif; ?>
        </table>
        <?php if ($bc): ?>
        <p class="small" style="margin:10px 0 4px;"><b>Последние проверки</b></p>
        <table class="kv-table">
            <?php foreach (array_slice($bc, 0, 8) as $ch): ?>
            <tr><th><?= $e($msk($ch['checked_at'] ?? null, 'd.m H:i')) ?></th>
                <td><?= $e(XmlStockLabels::phase($ch['phase'] ?? null)) ?> — <?= $e(XmlStockLabels::result($ch['result'] ?? null)) ?><?php if (isset($ch['pages_indexed']) && $ch['pages_indexed'] !== null): ?> (<?= (int)$ch['pages_indexed'] ?> стр.)<?php endif; ?></td></tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
        <details class="technical-details" style="margin-top:8px;">
            <summary class="muted small" style="cursor:pointer;">Raw policy snapshot (JSON)</summary>
            <pre class="small" style="white-space:pre-wrap; background:var(--bg-elevated); border:1px solid var(--border); padding:8px; border-radius:6px;"><?= $e(json_encode($pol->toArray(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></pre>
        </details>
    </details>
<?php endif; ?>
</div>
