<?php
/**
 * v24: экран конфликта — у сайта уже есть незавершённая джоба.
 *
 * Вместо общего отказа показываем саму джобу и доступные действия.
 * Замена и отмена доступны ТОЛЬКО для stage_status='awaiting_user':
 * работающую джобу закрывать нельзя, она может быть в середине записи
 * по FTP, покупки домена или обращения к Вебмастеру.
 */
$stage       = (string)$job['stage'];
$stageStatus = (string)$job['stage_status'];
$siteDomain  = (string)($job['current_domain'] ?: $job['old_domain']);
?>
<p><a href="/sites/show?id=<?= (int)$siteId ?>">← Сайт</a></p>

<h1>Сайт уже имеет незавершённую джобу</h1>

<section class="card">
    <dl class="kv">
        <dt>Сайт</dt><dd><b><?= htmlspecialchars($siteDomain) ?></b></dd>
        <dt>Джоба</dt>
        <dd>
            <a href="/jobs/show?id=<?= (int)$job['id'] ?>">#<?= (int)$job['id'] ?></a>
            <span class="muted small">режим <code><?= htmlspecialchars((string)$job['mode']) ?></code></span>
        </dd>
        <dt>Стадия</dt><dd><code><?= htmlspecialchars($stage) ?></code></dd>
        <dt>Статус</dt>
        <dd>
            <?= $stageStatus === 'awaiting_user'
                ? '<span style="color:#f0a020">ожидает действия оператора</span>'
                : '<span style="color:#58a6ff">выполняется</span>' ?>
            <span class="muted small">(<?= htmlspecialchars($stageStatus) ?>)</span>
        </dd>
        <?php if ($await): ?>
            <dt>Ожидает с</dt>
            <dd><?= htmlspecialchars(Time::msk((string)$job['updated_at'], 'd.m.Y H:i', true)) ?>
                <span class="muted small">— <?= htmlspecialchars((string)$await['waiting']) ?></span></dd>
            <dt>Требуется</dt>
            <dd><b><?= htmlspecialchars((string)$await['action']) ?></b>
                <div class="muted small" style="margin-top:3px"><?= htmlspecialchars((string)$await['hint']) ?></div></dd>
        <?php endif; ?>
    </dl>
</section>

<?php if (!$closable): ?>
    <section class="card">
        <h2>Действия недоступны</h2>
        <div class="notice warn">
            Джоба <b>ещё выполняется</b>. Закрыть её с заменой или отменить нельзя:
            в этот момент могут идти запись по FTP, изменение файлов сайта, покупка домена
            или обращение к Яндекс.Вебмастеру. Прерывание оставит сайт в промежуточном состоянии.
        </div>
        <p class="muted small">
            Дождитесь завершения стадии либо перехода джобы в статус «ожидает действия оператора».
        </p>
        <p><a class="btn" href="/jobs/show?id=<?= (int)$job['id'] ?>">Открыть джобу</a></p>
    </section>
<?php else: ?>
    <section class="card">
        <h2>Что можно сделать</h2>

        <p class="row" style="gap:10px; flex-wrap:wrap">
            <a class="btn" href="/jobs/show?id=<?= (int)$job['id'] ?>">Открыть старую джобу</a>
        </p>

        <details style="margin-top:14px">
            <summary style="cursor:pointer"><b>Закрыть старую и создать новую</b></summary>
            <div style="margin-top:10px; padding:12px; background:rgba(255,255,255,.03); border-radius:6px">
                <p class="muted small">
                    Старая джоба #<?= (int)$job['id'] ?> будет переведена в состояние
                    <code>superseded</code> с указанием, какой джобой заменена.
                    Возобновить её после этого будет нельзя.
                    Обе операции выполняются одной транзакцией: если создать новую джобу
                    не удастся, старая останется без изменений.
                </p>

                <?php if (!empty($scheduleWarning)): ?>
                    <div class="notice warn" style="margin-bottom:10px">
                        <?= htmlspecialchars((string)$scheduleWarning) ?>
                    </div>
                <?php endif; ?>

                <?php /* v24.2 (H1): параметры исходного запуска — оператор видит
                        и подтверждает именно то, что выбирал на карточке сайта. */ ?>
                <?php if (!empty($wmOverride) || !empty($scheduleDisplay)): ?>
                    <div class="notice" style="margin-bottom:10px">
                        Параметры новой джобы из исходного запуска:
                        <?php if (!empty($wmOverride)): ?>
                            <div>• Webmaster override:
                                <b>#<?= (int)$wmOverride ?><?= $wmLabel !== ''
                                    ? ' — ' . htmlspecialchars((string)$wmLabel) : '' ?></b></div>
                        <?php endif; ?>
                        <?php if (!empty($scheduleDisplay)): ?>
                            <div>• ⏰ Отложенный старт:
                                <b><?= htmlspecialchars((string)$scheduleDisplay) ?></b></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="/jobs/supersede">
                    <input type="hidden" name="old_job_id" value="<?= (int)$job['id'] ?>">
                    <input type="hidden" name="site_id" value="<?= (int)$siteId ?>">
                    <?php if (!empty($wmOverride)): ?>
                        <input type="hidden" name="webmaster_account_override_id"
                               value="<?= (int)$wmOverride ?>">
                    <?php endif; ?>
                    <?php if (!empty($scheduleAtRaw)): ?>
                        <input type="hidden" name="schedule_at"
                               value="<?= htmlspecialchars((string)$scheduleAtRaw) ?>">
                    <?php endif; ?>

                    <label style="display:block; max-width:340px; margin-bottom:10px">
                        <span class="muted small">Режим новой джобы</span>
                        <select name="mode" style="width:100%; padding:6px">
                            <option value="refresh"      <?= $mode === 'refresh'      ? 'selected' : '' ?>>refresh — перевыставление</option>
                            <option value="move_indexed" <?= $mode === 'move_indexed' ? 'selected' : '' ?>>move_indexed — переезд с индексацией</option>
                            <option value="move_simple"  <?= $mode === 'move_simple'  ? 'selected' : '' ?>>move_simple — простой переезд</option>
                        </select>
                    </label>

                    <label style="display:block; max-width:520px; margin-bottom:10px">
                        <span class="muted small">Комментарий (необязательно)</span>
                        <input type="text" name="comment" style="width:100%; padding:6px"
                               placeholder="почему старая джоба заменяется">
                    </label>

                    <button type="submit" class="btn btn-primary"
                            onclick="return confirm('Закрыть джобу #<?= (int)$job['id'] ?> и создать новую? Старую джобу возобновить будет нельзя.');">
                        Закрыть старую и создать новую
                    </button>
                </form>
            </div>
        </details>

        <details style="margin-top:10px">
            <summary style="cursor:pointer">Отменить старую джобу (без создания новой)</summary>
            <div style="margin-top:10px; padding:12px; background:rgba(255,255,255,.03); border-radius:6px">
                <p class="muted small">
                    Джоба перейдёт в состояние <code>cancelled</code>, сайт освободится
                    для новых джоб. Возобновить отменённую джобу нельзя.
                </p>
                <form method="post" action="/jobs/close">
                    <input type="hidden" name="job_id" value="<?= (int)$job['id'] ?>">
                    <label style="display:block; max-width:520px; margin-bottom:10px">
                        <span class="muted small">Причина отмены (обязательно)</span>
                        <input type="text" name="comment" required style="width:100%; padding:6px">
                    </label>
                    <button type="submit" class="btn"
                            onclick="return confirm('Отменить джобу #<?= (int)$job['id'] ?>?');">
                        Отменить джобу
                    </button>
                </form>
            </div>
        </details>
    </section>
<?php endif; ?>
