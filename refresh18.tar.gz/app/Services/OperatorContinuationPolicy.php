<?php

/**
 * ТЗ044 §6.3 — allowlist-политика кнопки «Я поправил, продолжить».
 * Generic stage_status=ok разрешён ТОЛЬКО для стадий, где семантика стадии — реальное
 * ручное подтверждение оператора. Для остальных awaiting_user — retry той же стадии
 * (pending), выделенное действие или блок.
 */
final class OperatorContinuationPolicy
{
    const RETRY_SAME_STAGE          = 'RETRY_SAME_STAGE';
    const ADVANCE_CONFIRMED         = 'ADVANCE_CONFIRMED';
    const DEDICATED_ACTION_REQUIRED = 'DEDICATED_ACTION_REQUIRED';
    const BLOCK_INVALID_STATE       = 'BLOCK_INVALID_STATE';

    /** Стадии, где generic «продолжить» действительно означает ручное подтверждение. */
    private const ADVANCE_ALLOWLIST = [
        'move_submit_request',  // оператор подал заявку на переезд руками
        'old_delurl_notify',    // оператор подтвердил финальное уведомление/удаление URL
        'index_watching',       // оператор осознанно прекращает ожидание индексации
    ];

    /** Стадии с выделенными действиями — generic continue запрещён. */
    private const DEDICATED_ONLY = [
        'update_classes_call',  // «Проверить рандом» / «Пропустить» (v25.2 §8)
    ];

    public static function actionFor(string $stage, array $job, array $artifacts): string
    {
        if (in_array($stage, self::DEDICATED_ONLY, true)) return self::DEDICATED_ACTION_REQUIRED;
        if (in_array($stage, self::ADVANCE_ALLOWLIST, true)) return self::ADVANCE_CONFIRMED;

        // analyze_site: awaiting почти всегда из-за prepare/scan блока — переисполнить анализ.
        if ($stage === 'analyze_site') return self::RETRY_SAME_STAGE;

        // config_replaced: если plan отсутствует/битый — нельзя ни ok, ни слепой retry записи.
        if ($stage === 'config_replaced') {
            $inv = StageInvariantGuard::checkAnalyzePlan($artifacts);
            return $inv['ok'] ? self::RETRY_SAME_STAGE : self::BLOCK_INVALID_STATE;
        }

        // redirect_enable: спец-кейс smoke-retry обрабатывается в контроллере ДО policy;
        // остальные причины awaiting — повторить стадию.
        if ($stage === 'redirect_enable') return self::RETRY_SAME_STAGE;

        // По умолчанию — безопасный retry той же стадии (НЕ ok).
        return self::RETRY_SAME_STAGE;
    }
}
