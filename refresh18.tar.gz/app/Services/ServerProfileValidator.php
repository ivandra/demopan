<?php

/**
 * ТЗ 040 §3.3/§4.2: чистая валидация серверного профиля FastPanel.
 *
 * Только разбор и проверка строк — ни БД, ни HTTP. Используется контроллером
 * серверов при create/update и тестами SRV-*. Нормализация host и правила
 * значений собраны здесь, чтобы не дублировать в контроллере и во View.
 */
final class ServerProfileValidator
{

    /**
     * Нормализовать host к виду "IP_или_хост:порт" (§4.2).
     *   https://37.252.0.32:8888/  -> 37.252.0.32:8888
     *   37.252.0.32                -> 37.252.0.32:8888  (порт по умолчанию 8888)
     * Запрещены path/query/fragment/userinfo, управляющие символы; порт 1-65535;
     * host — валидный IPv4 или hostname.
     *
     * @return array{ok:bool,host:string,error:?string}
     */
    public static function normalizeHost(string $raw): array
    {
        // ТЗ 040 FINAL-3 §3.10: единый нормализатор — один источник истины,
        // тот же, что использует миграция 040 и контроллер.
        return FastpanelHostNormalizer::normalize($raw);
    }

    public static function isValidIpv4(string $ip): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
    }

    public static function isValidHostname(string $host): bool
    {
        if (strlen($host) > 253) return false;
        return (bool)preg_match('~^(?=.{1,253}$)([A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$~', $host);
    }

    /** §3.3: код бейджа 1-8 символов, только буквы/цифры/`_-`. */
    public static function validBadgeCode(string $code): bool
    {
        return (bool)preg_match('~^[A-Za-z0-9_-]{1,8}$~', $code);
    }

    /** §3.3/§8.2: цвет строго #RRGGBB. */
    public static function validColor(string $color): bool
    {
        return (bool)preg_match('~^#[0-9A-Fa-f]{6}$~', $color);
    }

}
