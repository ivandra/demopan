<?php

/**
 * AppSettings — typed key-value helper для настроек приложения (v18.1.29).
 *
 * В отличие от config('xxx') (читает PHP-файлы config/app.php), AppSettings
 * читает БД (таблица app_settings). Оператор может менять через /settings UI.
 *
 * Использование:
 *   $max = AppSettings::getInt('cron.max_jobs_per_tick', 5);
 *   AppSettings::setInt('cron.max_jobs_per_tick', 10);
 *
 *   $list = AppSettings::all();  // для UI рендера
 *
 * Если таблица app_settings отсутствует (миграция 018 не применена) — все
 * методы возвращают $default. Это позволяет код использовать AppSettings до
 * применения миграции, не падая.
 *
 * Также есть КЕШ в памяти: повторные get() в рамках одного запроса не дёргают БД.
 */
class AppSettings
{
    /** @var array<string, string|null>|null In-memory кеш одного запроса. */
    private static ?array $cache = null;

    /**
     * Прочитать все настройки из БД в кеш.
     */
    private static function loadCache(): array
    {
        if (self::$cache !== null) return self::$cache;
        try {
            $rows = DB::pdo()->query(
                "SELECT setting_key, setting_value FROM app_settings"
            )->fetchAll();
            self::$cache = [];
            foreach ($rows as $r) {
                self::$cache[(string)$r['setting_key']] = $r['setting_value']; // может быть null
            }
        } catch (\Throwable $e) {
            // Таблица отсутствует (миграция не применена) — кешируем пустой массив
            self::$cache = [];
        }
        return self::$cache;
    }

    /**
     * Сбросить кеш — после set() или для тестов.
     */
    public static function clearCache(): void
    {
        self::$cache = null;
    }

    /**
     * Прочитать сырое строковое значение.
     */
    public static function getRaw(string $key, ?string $default = null): ?string
    {
        $cache = self::loadCache();
        if (!array_key_exists($key, $cache)) return $default;
        return $cache[$key] ?? $default;
    }

    /**
     * Прочитать как int.
     */
    public static function getInt(string $key, int $default = 0): int
    {
        $raw = self::getRaw($key);
        if ($raw === null || $raw === '') return $default;
        if (!is_numeric($raw)) return $default;
        return (int)$raw;
    }

    /**
     * Прочитать как float.
     */
    public static function getFloat(string $key, float $default = 0.0): float
    {
        $raw = self::getRaw($key);
        if ($raw === null || $raw === '') return $default;
        if (!is_numeric($raw)) return $default;
        return (float)$raw;
    }

    /**
     * Прочитать как bool.
     * Truthy values: '1', 'true', 'yes', 'on'
     */
    public static function getBool(string $key, bool $default = false): bool
    {
        $raw = self::getRaw($key);
        if ($raw === null || $raw === '') return $default;
        $low = strtolower(trim($raw));
        return in_array($low, ['1', 'true', 'yes', 'on'], true);
    }

    /**
     * Прочитать как JSON-массив.
     */
    public static function getJson(string $key, array $default = []): array
    {
        $raw = self::getRaw($key);
        if ($raw === null || $raw === '') return $default;
        $d = json_decode($raw, true);
        return is_array($d) ? $d : $default;
    }

    /**
     * Записать значение. Возвращает true если успешно.
     * После записи кеш сбрасывается.
     */
    public static function setRaw(string $key, ?string $value): bool
    {
        try {
            $st = DB::pdo()->prepare(
                "INSERT INTO app_settings (setting_key, setting_value)
                 VALUES (?, ?)
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
            );
            $st->execute([$key, $value]);
            self::clearCache();
            return true;
        } catch (\Throwable $e) {
            error_log("AppSettings::setRaw({$key}) failed: " . $e->getMessage());
            return false;
        }
    }

    public static function setInt(string $key, int $value): bool
    {
        return self::setRaw($key, (string)$value);
    }

    public static function setFloat(string $key, float $value): bool
    {
        return self::setRaw($key, (string)$value);
    }

    public static function setBool(string $key, bool $value): bool
    {
        return self::setRaw($key, $value ? '1' : '0');
    }

    public static function setJson(string $key, array $value): bool
    {
        return self::setRaw($key, json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    /**
     * Получить все настройки с метаданными (для UI).
     *
     * @return array<int, array{key, value, type, description}>
     */
    public static function all(): array
    {
        try {
            $rows = DB::pdo()->query(
                "SELECT setting_key, setting_value, value_type, description, updated_at
                 FROM app_settings ORDER BY setting_key"
            )->fetchAll();
            return $rows ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }
}
