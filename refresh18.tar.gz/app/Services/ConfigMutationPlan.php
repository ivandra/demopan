<?php

/**
 * DTO плана мутации config.php. Отдельный файл (autoload в новом PHP-процессе).
 */
final class ConfigMutationPlan
{
    public int $siteId;
    public int $jobId;
    public string $remotePath;
    public string $sourceSha256;
    public string $targetSha256;
    public string $targetStoragePath;
    public string $oldDomain;
    public string $newDomain;
    public ?string $oldSubId;
    public ?string $newSubId;
    public array $expected;

    public static function fromArray(array $v): self
    {
        foreach (['site_id', 'job_id', 'remote_path', 'source_sha256',
                  'target_sha256', 'target_storage_path', 'old_domain',
                  'new_domain', 'expected'] as $key) {
            if (!array_key_exists($key, $v)) {
                throw new InvalidArgumentException("Missing plan key: {$key}");
            }
        }
        $p = new self();
        $p->siteId = (int)$v['site_id'];
        $p->jobId = (int)$v['job_id'];
        $p->remotePath = (string)$v['remote_path'];
        $p->sourceSha256 = (string)$v['source_sha256'];
        $p->targetSha256 = (string)$v['target_sha256'];
        $p->targetStoragePath = (string)$v['target_storage_path'];
        $p->oldDomain = (string)$v['old_domain'];
        $p->newDomain = (string)$v['new_domain'];
        $p->oldSubId = isset($v['old_sub_id']) ? (string)$v['old_sub_id'] : null;
        $p->newSubId = isset($v['new_sub_id']) ? (string)$v['new_sub_id'] : null;
        $p->expected = (array)$v['expected'];
        return $p;
    }

    public function toArray(): array
    {
        return [
            'version' => 1,
            'site_id' => $this->siteId,
            'job_id' => $this->jobId,
            'remote_path' => $this->remotePath,
            'source_sha256' => $this->sourceSha256,
            'target_sha256' => $this->targetSha256,
            'target_storage_path' => $this->targetStoragePath,
            'old_domain' => $this->oldDomain,
            'new_domain' => $this->newDomain,
            'old_sub_id' => $this->oldSubId,
            'new_sub_id' => $this->newSubId,
            'expected' => $this->expected,
        ];
    }
}
