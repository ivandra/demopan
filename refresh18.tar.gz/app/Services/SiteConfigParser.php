<?php

/**
 * Парсер config.php разных шаблонов сайтов.
 * НЕ выполняет PHP-код — только regex-извлечение значений переменных.
 *
 * v11: regex-паттерны собираются конкатенацией из коротких безопасных
 * кусков. Символ '$' хранится как одиночный chr(36), регулярки строятся
 * без двойных кавычек и без экранированных бэкслешей внутри character
 * class — это исключает PHP-парс-ошибки типа "Unclosed { on line N",
 * которые мы наблюдали в v10 на хостинге и локально.
 */
class SiteConfigParser
{
    /** regex-фрагмент для матча литерального символа '$' в исходниках PHP-кода. */
    private $D;

    private $stringFields = [
        'domain',
        'yandex_verification',
        'yandex_metrika',
        'promolink',
        'title',
        'description',
        'keywords',
        'h1',
        'catalog',
        'altANDname',
        'partner_override_url',
        'internal_reg_url',
        'base_new_url',
        'base_second_url',
    ];

    private $intFields = [
        'template',
        'shuffleGames',
        'redirect_enabled',
    ];

    public function __construct()
    {
        // chr(92) === '\', chr(36) === '$'.
        // Хранение через chr() гарантирует, что PHP-парсер
        // никогда не увидит литерал '$' рядом с буквами и не попытается
        // интерпретировать переменную.
        // В regex символ $ — спецсимвол (anchor конца строки),
        // поэтому нужно ЭКРАНИРОВАННОЕ \$ — то есть последовательность
        // backslash + $, два символа.
        $this->D = chr(92) . chr(36);
    }

    public function parse(string $phpSource): array
    {
        $out = [];

        // 1. Старый формат: плоские переменные $domain = '...'; $internal_reg_url = '...';
        foreach ($this->stringFields as $f) {
            $v = $this->extractString($phpSource, $f);
            if ($v !== null) {
                $out[$f] = $v;
            }
        }
        foreach ($this->intFields as $f) {
            $v = $this->extractInt($phpSource, $f);
            if ($v !== null) {
                $out[$f] = $v;
            }
        }

        // 2. v17.13: новый формат массива $site = [...]; $variant_settings = [...];
        // Если поля не нашлись через старый формат — пробуем извлечь из массивов.
        // Объединяем (старый формат имеет приоритет — мы его уже добавили).
        $arrayBased = $this->parseArrayBased($phpSource);
        foreach ($arrayBased as $key => $val) {
            if (!isset($out[$key])) {
                $out[$key] = $val;
            }
        }

        return $out;
    }

    /**
     * v17.13: парсинг нового формата шаблонов (enomo v3).
     *
     * Извлекает ключи из массивов $site = [...] и $variant_settings = [...],
     * и приводит к плоской структуре совместимой со старым форматом.
     *
     * Поддерживаемые источники:
     *   $site['domain']                            → 'domain'
     *   $site['yandex_verification']               → 'yandex_verification'
     *   $site['yandex_metrika']                    → 'yandex_metrika'
     *   $site['promolink']                         → 'promolink'
     *   $site['redirect']['internal_reg_url']      → 'internal_reg_url'
     *   $site['redirect']['base_new_url']          → 'base_new_url'
     *   $site['redirect']['base_second_url']       → 'base_second_url'
     *   $site['redirect']['partner_override_url']  → 'partner_override_url'
     *   $site['redirect']['enabled']               → 'redirect_enabled' (как int)
     *   $variant_settings['manual_secret']         → 'manual_secret'
     *
     * НЕ выполняет PHP-код, использует только regex.
     */
    private function parseArrayBased(string $phpSource): array
    {
        $out = [];

        // Извлекаем тело массива $site = [ ... ];
        // Учитываем что внутри могут быть вложенные массивы — используем рекурсивный подход.
        $siteBody = $this->extractArrayBody($phpSource, 'site');
        if ($siteBody !== null) {
            // Топ-уровень: domain, yandex_verification, yandex_metrika, promolink
            $topKeys = ['domain', 'yandex_verification', 'yandex_metrika', 'promolink'];
            foreach ($topKeys as $key) {
                $v = $this->extractArrayKey($siteBody, $key);
                if ($v !== null) {
                    $out[$key] = $v;
                }
            }

            // Вложенный массив 'redirect' => [...]
            $redirectBody = $this->extractNestedArrayBody($siteBody, 'redirect');
            if ($redirectBody !== null) {
                $redirectKeys = [
                    'internal_reg_url', 'base_new_url', 'base_second_url',
                    'partner_override_url',
                ];
                foreach ($redirectKeys as $key) {
                    $v = $this->extractArrayKey($redirectBody, $key);
                    if ($v !== null) {
                        $out[$key] = $v;
                    }
                }

                // 'enabled' внутри redirect → маппим на старое имя 'redirect_enabled' (int)
                $enabled = $this->extractArrayKeyInt($redirectBody, 'enabled');
                if ($enabled !== null) {
                    $out['redirect_enabled'] = $enabled;
                }
            }
        }

        // $variant_settings = [...]; → manual_secret
        $vsBody = $this->extractArrayBody($phpSource, 'variant_settings');
        if ($vsBody !== null) {
            $secret = $this->extractArrayKey($vsBody, 'manual_secret');
            if ($secret !== null) {
                $out['manual_secret'] = $secret;
            }
        }

        return $out;
    }

    /**
     * v17.13: извлекает тело массива по имени переменной.
     * $varName = [ ... ];  →  возвращает содержимое между [ и соответствующей ]
     *
     * Корректно обрабатывает вложенные [ ] (баланс скобок), строковые литералы
     * и комментарии // /* */ /*. Если массив не найден — возвращает null.
     */
    private function extractArrayBody(string $src, string $varName): ?string
    {
        $D = $this->D; // \\\$
        $name = preg_quote($varName, '~');

        // Ищем "$varName = ["
        if (!preg_match('~' . $D . $name . '\s*=\s*\[~', $src, $m, PREG_OFFSET_CAPTURE)) {
            return null;
        }
        $startBracket = $m[0][1] + strlen($m[0][0]) - 1; // позиция '['

        // Идём по символам, считаем баланс [ и ]
        $depth = 0;
        $len = strlen($src);
        $inSingleQ = false;
        $inDoubleQ = false;
        $inLineComment = false;
        $inBlockComment = false;

        for ($i = $startBracket; $i < $len; $i++) {
            $c = $src[$i];
            $next = $i + 1 < $len ? $src[$i + 1] : '';

            // Обработка комментариев
            if ($inLineComment) {
                if ($c === "\n") $inLineComment = false;
                continue;
            }
            if ($inBlockComment) {
                if ($c === '*' && $next === '/') {
                    $inBlockComment = false;
                    $i++;
                }
                continue;
            }

            // Обработка строк (учитываем escape)
            if ($inSingleQ) {
                if ($c === '\\' && $i + 1 < $len) { $i++; continue; }
                if ($c === "'") $inSingleQ = false;
                continue;
            }
            if ($inDoubleQ) {
                if ($c === '\\' && $i + 1 < $len) { $i++; continue; }
                if ($c === '"') $inDoubleQ = false;
                continue;
            }

            // Начало строк/комментариев (только вне строк)
            if ($c === "'") { $inSingleQ = true; continue; }
            if ($c === '"') { $inDoubleQ = true; continue; }
            if ($c === '/' && $next === '/') { $inLineComment = true; $i++; continue; }
            if ($c === '/' && $next === '*') { $inBlockComment = true; $i++; continue; }

            // Скобки
            if ($c === '[') $depth++;
            elseif ($c === ']') {
                $depth--;
                if ($depth === 0) {
                    // Нашли парную закрывающую скобку
                    return substr($src, $startBracket + 1, $i - $startBracket - 1);
                }
            }
        }

        return null; // несбалансированные скобки или конец файла
    }

    /**
     * v17.13: извлекает тело вложенного массива по ключу.
     * 'key' => [ ... ]
     */
    private function extractNestedArrayBody(string $body, string $key): ?string
    {
        $name = preg_quote($key, '~');

        // Ищем 'key' => [ или "key" => [
        $pattern = "~['\"]" . $name . "['\"]\s*=>\s*\[~";
        if (!preg_match($pattern, $body, $m, PREG_OFFSET_CAPTURE)) {
            return null;
        }
        $startBracket = $m[0][1] + strlen($m[0][0]) - 1;

        // Используем тот же балансировщик
        $depth = 0;
        $len = strlen($body);
        $inSingleQ = false;
        $inDoubleQ = false;
        $inLineComment = false;
        $inBlockComment = false;

        for ($i = $startBracket; $i < $len; $i++) {
            $c = $body[$i];
            $next = $i + 1 < $len ? $body[$i + 1] : '';

            if ($inLineComment) {
                if ($c === "\n") $inLineComment = false;
                continue;
            }
            if ($inBlockComment) {
                if ($c === '*' && $next === '/') {
                    $inBlockComment = false;
                    $i++;
                }
                continue;
            }
            if ($inSingleQ) {
                if ($c === '\\' && $i + 1 < $len) { $i++; continue; }
                if ($c === "'") $inSingleQ = false;
                continue;
            }
            if ($inDoubleQ) {
                if ($c === '\\' && $i + 1 < $len) { $i++; continue; }
                if ($c === '"') $inDoubleQ = false;
                continue;
            }

            if ($c === "'") { $inSingleQ = true; continue; }
            if ($c === '"') { $inDoubleQ = true; continue; }
            if ($c === '/' && $next === '/') { $inLineComment = true; $i++; continue; }
            if ($c === '/' && $next === '*') { $inBlockComment = true; $i++; continue; }

            if ($c === '[') $depth++;
            elseif ($c === ']') {
                $depth--;
                if ($depth === 0) {
                    return substr($body, $startBracket + 1, $i - $startBracket - 1);
                }
            }
        }

        return null;
    }

    /**
     * v17.13: извлекает строковое значение по ключу из тела массива.
     * 'key' => 'value' или "key" => "value"
     */
    private function extractArrayKey(string $body, string $key): ?string
    {
        $name = preg_quote($key, '~');
        $esc = $this->escapedAnything();
        $sq = chr(39);

        // 'key' => 'value' (одинарные)
        $bodyS = '(?:' . $esc . '|' . $this->notQuoteOrBackslash($sq) . ')*';
        $pat = "~['\"]" . $name . "['\"]\s*=>\s*" . $sq . '(' . $bodyS . ')' . $sq . '~s';
        if (preg_match($pat, $body, $m)) {
            return $this->unescapeSingle($m[1]);
        }

        // "key" => "value" (двойные)
        $bodyD = '(?:' . $esc . '|' . $this->notQuoteOrBackslash('"') . ')*';
        $pat = "~['\"]" . $name . "['\"]\s*=>\s*\"(" . $bodyD . ')"~s';
        if (preg_match($pat, $body, $m)) {
            return $this->unescapeDouble($m[1]);
        }

        return null;
    }

    /**
     * v17.13: извлекает int значение по ключу из тела массива.
     * 'key' => 1 или 'key' => 0
     */
    private function extractArrayKeyInt(string $body, string $key): ?int
    {
        $name = preg_quote($key, '~');
        $pat = "~['\"]" . $name . "['\"]\s*=>\s*(-?\d+)~";
        if (preg_match($pat, $body, $m)) {
            return (int)$m[1];
        }

        // Также поддерживаем true/false → 1/0
        $patBool = "~['\"]" . $name . "['\"]\s*=>\s*(true|false)~i";
        if (preg_match($patBool, $body, $m)) {
            return strtolower($m[1]) === 'true' ? 1 : 0;
        }

        return null;
    }

    public function applyChanges(string $phpSource, array $changes): string
    {
        $src = $phpSource;
        foreach ($changes as $field => $value) {
            if (in_array($field, $this->stringFields, true)) {
                $src = $this->replaceString($src, $field, (string)$value);
            } elseif (in_array($field, $this->intFields, true)) {
                $src = $this->replaceInt($src, $field, (int)$value);
            }
        }
        return $src;
    }

    public function replaceAllOccurrences(string $phpSource, string $oldHost, string $newHost): string
    {
        if ($oldHost === '' || $newHost === '' || $oldHost === $newHost) {
            return $phpSource;
        }
        $oldVariants = $this->hostVariants($oldHost);
        $newPlain = $this->plainHost($newHost);

        $patterns = [];
        $replacements = [];
        foreach ($oldVariants as $v) {
            $patterns[] = '~(\bhttps?://)' . preg_quote($v, '~') . '\b~i';
            $replacements[] = '${1}' . $newPlain;
            $patterns[] = '~\b' . preg_quote($v, '~') . '\b~';
            $replacements[] = $newPlain;
        }
        return preg_replace($patterns, $replacements, $phpSource);
    }

    private function hostVariants(string $host): array
    {
        $h = $this->plainHost($host);
        return array_unique([$h, 'www.' . $h]);
    }

    private function plainHost(string $url): string
    {
        $u = trim($url);
        $u = preg_replace('~^https?://~i', '', $u);
        $u = preg_replace('~^www\.~i', '', $u);
        $u = preg_replace('~[/?#].*$~', '', $u);
        $u = preg_replace('~:\d+$~', '', $u);
        return strtolower(trim($u));
    }

    /**
     * Возвращает фрагмент regex для матча character class «всё кроме quote и backslash».
     * Сделано отдельным методом, потому что эта последовательность
     * (\\ и кавычка) — самая «коварная» часть для PHP-парсера в исходниках.
     * Принимает символ кавычки '"' или "'" и ВОЗВРАЩАЕТ строку,
     * полностью построенную через chr() без литералов с обратными слешами.
     *
     *   "  →  [^"\\]
     *   '  →  [^'\\]
     */
    private function notQuoteOrBackslash(string $quoteChar): string
    {
        $bs = chr(92); // '\'
        return '[^' . $quoteChar . $bs . $bs . ']';
    }

    /**
     * Возвращает фрагмент regex для матча «escape-последовательность»: \. (одна backslash + любой символ).
     * Тоже без литералов, чтобы PHP-парсер не плакал.
     */
    private function escapedAnything(): string
    {
        $bs = chr(92);
        // Регекс: \\.    (в PHP-строке это два бэкслеша + точка)
        return $bs . $bs . '.';
    }

    /**
     * Извлекает значение строковой переменной из PHP-кода.
     */
    private function extractString(string $src, string $varName): ?string
    {
        $name = preg_quote($varName, '~');
        $D    = $this->D;
        $esc  = $this->escapedAnything();

        // $varName = "...";
        $body = '(?:' . $esc . '|' . $this->notQuoteOrBackslash('"') . ')*';
        $patternDouble = '~' . $D . $name . '\s*=\s*"(' . $body . ')"\s*;~s';
        if (preg_match($patternDouble, $src, $m)) {
            return $this->unescapeDouble($m[1]);
        }

        // $varName = '...';
        $sq   = chr(39); // одиночная кавычка '
        $body = '(?:' . $esc . '|' . $this->notQuoteOrBackslash($sq) . ')*';
        $patternSingle = '~' . $D . $name . '\s*=\s*' . $sq . '(' . $body . ')' . $sq . '\s*;~s';
        if (preg_match($patternSingle, $src, $m)) {
            return $this->unescapeSingle($m[1]);
        }
        return null;
    }

    private function extractInt(string $src, string $varName): ?int
    {
        $name = preg_quote($varName, '~');
        $D    = $this->D;
        $pattern = '~' . $D . $name . '\s*=\s*(-?\d+)\s*;~';
        if (preg_match($pattern, $src, $m)) {
            return (int)$m[1];
        }
        return null;
    }

    private function unescapeDouble(string $s): string
    {
        return strtr($s, [
            chr(92) . chr(92) => chr(92),
            chr(92) . '"'     => '"',
            chr(92) . 'n'     => "\n",
            chr(92) . 'r'     => "\r",
            chr(92) . 't'     => "\t",
            chr(92) . chr(36) => chr(36),
        ]);
    }

    private function unescapeSingle(string $s): string
    {
        return strtr($s, [
            chr(92) . chr(92) => chr(92),
            chr(92) . "'"     => "'",
        ]);
    }

    private function replaceString(string $src, string $varName, string $newValue): string
    {
        $name = preg_quote($varName, '~');
        $D    = $this->D;
        $esc  = $this->escapedAnything();

        // Двойные кавычки
        $bodyD = '(?:' . $esc . '|' . $this->notQuoteOrBackslash('"') . ')*';
        $patternD = '~(' . $D . $name . '\s*=\s*)"' . $bodyD . '"(\s*;)~s';
        if (preg_match($patternD, $src)) {
            $escaped = $this->escapeForDouble($newValue);
            return preg_replace($patternD, '${1}"' . $escaped . '"${2}', $src, 1);
        }

        // Одинарные кавычки. ВНИМАНИЕ: никаких двойных кавычек с ${...} —
        // PHP интерпретирует это как complex variable interpolation
        // и ломает синтаксис. Используем одинарные кавычки.
        $sq    = chr(39); // одиночная кавычка '
        $bodyS = '(?:' . $esc . '|' . $this->notQuoteOrBackslash($sq) . ')*';
        $patternS = '~(' . $D . $name . '\s*=\s*)' . $sq . $bodyS . $sq . '(\s*;)~s';
        if (preg_match($patternS, $src)) {
            $escaped = $this->escapeForSingle($newValue);
            $replacement = '${1}' . $sq . $escaped . $sq . '${2}';
            return preg_replace($patternS, $replacement, $src, 1);
        }

        // Переменной нет — добавляем перед закрывающим тегом или в конец
        return $this->insertField($src, $varName, "'" . $this->escapeForSingle($newValue) . "'");
    }

    private function replaceInt(string $src, string $varName, int $newValue): string
    {
        $name = preg_quote($varName, '~');
        $D    = $this->D;
        $pattern = '~(' . $D . $name . '\s*=\s*)-?\d+(\s*;)~';
        if (preg_match($pattern, $src)) {
            return preg_replace($pattern, '${1}' . $newValue . '${2}', $src, 1);
        }
        return $this->insertField($src, $varName, (string)$newValue);
    }

    private function insertField(string $src, string $varName, string $valueExpr): string
    {
        $line = chr(36) . $varName . " = " . $valueExpr . ";\n";
        if (preg_match('~\?>\s*$~', $src)) {
            return preg_replace('~(\?>\s*)$~', $line . '${1}', $src);
        }
        return rtrim($src) . "\n" . $line;
    }

    private function escapeForDouble(string $s): string
    {
        return strtr($s, [
            chr(92) => chr(92) . chr(92),
            '"'     => chr(92) . '"',
            chr(36) => chr(92) . chr(36),
        ]);
    }

    private function escapeForSingle(string $s): string
    {
        return strtr($s, [
            chr(92) => chr(92) . chr(92),
            "'"     => chr(92) . "'",
        ]);
    }
}
