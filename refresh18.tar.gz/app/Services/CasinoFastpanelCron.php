<?php
/**
 * CasinoFastpanelCron — создание cron-задачи в FastPanel через его REST API.
 *
 * Структура API подтверждена реальными запросами из браузера FastPanel:
 *   POST https://<host>:8888/login              {username,password} → {token}
 *   GET  https://<host>:8888/api/sites/<vhost>   → site detail (для owner)
 *   POST https://<host>:8888/api/jobs            {command,enabled,owner,minute,hour,
 *                                                 day_of_month,month,day_of_week,vhost}
 *
 * Автономный (не трогает существующий FastpanelClient) — сам логинится и шлёт запрос.
 */
class CasinoFastpanelCron
{
    private string $baseUrl;
    private bool $verifyTls;
    private int $timeout;
    private string $token = '';

    public function __construct(string $host, bool $verifyTls = false, int $timeout = 30)
    {
        // host может быть '95.129.234.20:8888' или 'https://95.129.234.20:8888'
        $host = trim($host);
        if (!preg_match('~^https?://~', $host)) $host = 'https://' . $host;
        $this->baseUrl   = rtrim($host, '/');
        $this->verifyTls = $verifyTls;
        $this->timeout   = $timeout;
    }

    public function login(string $username, string $password): void
    {
        $resp = $this->request('POST', '/login', ['username' => $username, 'password' => $password], false);
        $token = $resp['token'] ?? null;
        if (!is_string($token) || $token === '') {
            throw new RuntimeException('FastPanel cron login: token not found');
        }
        $this->token = $token;
    }

    /**
     * Узнать owner (id пользователя-владельца).
     * 1) Пробуем из site detail (/api/sites/<vhost>) — поля owner/owner_id/user_id/user.
     * 2) Fallback: /api/users — берём пользователя по username (под которым логинились),
     *    либо первого если username не передан.
     * Возвращает 0 если не нашли (вызывающий код покажет диагностику).
     */
    public function detectOwner(int $vhostId, string $loginUsername = ''): int
    {
        // (1) из site detail
        try {
            $site = $this->request('GET', '/api/sites/' . $vhostId);
            foreach (['owner', 'owner_id', 'user_id', 'user'] as $k) {
                if (isset($site[$k])) {
                    if (is_array($site[$k]) && isset($site[$k]['id'])) return (int)$site[$k]['id'];
                    if (is_numeric($site[$k])) return (int)$site[$k];
                }
            }
            // иногда вложено в data
            if (isset($site['data']) && is_array($site['data'])) {
                foreach (['owner', 'owner_id', 'user_id', 'user'] as $k) {
                    if (isset($site['data'][$k])) {
                        if (is_array($site['data'][$k]) && isset($site['data'][$k]['id'])) return (int)$site['data'][$k]['id'];
                        if (is_numeric($site['data'][$k])) return (int)$site['data'][$k];
                    }
                }
            }
        } catch (Throwable $e) { /* перейдём к users */ }

        // (2) из /api/users
        try {
            $resp = $this->request('GET', '/api/users');
            $users = (isset($resp['data']) && is_array($resp['data'])) ? $resp['data'] : (is_array($resp) ? $resp : []);
            $loginUsername = trim($loginUsername);
            // ищем по username
            if ($loginUsername !== '') {
                foreach ($users as $u) {
                    if (!is_array($u)) continue;
                    $name = (string)($u['username'] ?? $u['name'] ?? '');
                    if ($name === $loginUsername && isset($u['id'])) return (int)$u['id'];
                }
            }
            // иначе первый пользователь с id
            foreach ($users as $u) {
                if (is_array($u) && isset($u['id']) && is_numeric($u['id'])) return (int)$u['id'];
            }
        } catch (Throwable $e) { /* вернём 0 */ }

        return 0;
    }

    /**
     * Диагностика: сырой site detail + список users (для отладки no_owner).
     */
    public function debugOwnerInfo(int $vhostId): array
    {
        $out = ['site' => null, 'users' => null];
        try { $out['site'] = $this->request('GET', '/api/sites/' . $vhostId); } catch (Throwable $e) { $out['site'] = ['_error' => $e->getMessage()]; }
        try { $out['users'] = $this->request('GET', '/api/users'); } catch (Throwable $e) { $out['users'] = ['_error' => $e->getMessage()]; }
        return $out;
    }

    /**
     * Создать cron-задачу.
     * $schedule = ['minute'=>'(asterisk-slash-1)','hour'=>'*', ...] — каждую минуту по умолчанию.
     * Возвращает ответ API (с id задачи).
     */
    public function createJob(string $command, int $vhostId, int $owner, array $schedule = [], bool $enabled = true): array
    {
        $payload = [
            'command'      => $command,
            'enabled'      => $enabled,
            'owner'        => $owner,
            'minute'       => (string)($schedule['minute'] ?? '*/1'),
            'hour'         => (string)($schedule['hour'] ?? '*'),
            'day_of_month' => (string)($schedule['day_of_month'] ?? '*'),
            'month'        => (string)($schedule['month'] ?? '*'),
            'day_of_week'  => (string)($schedule['day_of_week'] ?? '*'),
            'vhost'        => $vhostId,
        ];
        return $this->request('POST', '/api/jobs', $payload);
    }

    /**
     * Список существующих cron-задач (для проверки дублей).
     */
    public function listJobs(): array
    {
        $resp = $this->request('GET', '/api/jobs');
        // API может вернуть {data:[...]} или сразу [...]
        if (isset($resp['data']) && is_array($resp['data'])) return $resp['data'];
        return is_array($resp) ? $resp : [];
    }

    private function request(string $method, string $path, ?array $json = null, bool $auth = true): array
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->baseUrl . $path);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $this->verifyTls ? 1 : 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $this->verifyTls ? 2 : 0);

        $headers = ['Accept: application/json'];
        if ($auth) {
            if ($this->token === '') throw new RuntimeException('FastPanel cron: not authenticated');
            $headers[] = 'Authorization: Bearer ' . $this->token;
        }
        if ($json !== null) {
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($json, JSON_UNESCAPED_UNICODE));
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($resp === false) throw new RuntimeException('FastPanel cron curl error: ' . $err);
        $decoded = json_decode((string)$resp, true);
        if ($code >= 400) {
            $msg = is_array($decoded) ? json_encode($decoded, JSON_UNESCAPED_UNICODE) : substr((string)$resp, 0, 500);
            throw new RuntimeException("FastPanel cron HTTP $code: $msg");
        }
        return is_array($decoded) ? $decoded : [];
    }
}
