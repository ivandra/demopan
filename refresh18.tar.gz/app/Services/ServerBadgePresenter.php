<?php

/**
 * ТЗ 040 §8: единый presenter серверного бейджа «F».
 *
 * Считает данные для отрисовки бейджа один раз, чтобы View не дублировали
 * HTML и расчёт контраста. Цвет применяется ТОЛЬКО после строгой HEX-валидации
 * (§8.2) — произвольный CSS невозможен. Если у сервера нет кода бейджа —
 * возвращает null, и UI выглядит как раньше (§8.3/UI-09).
 */
final class ServerBadgePresenter
{
    private const DEFAULT_COLOR = '#6B7280'; // нейтральный серый, если цвет не задан/невалиден

    /**
     * @return array{code:string,label:string,color:string,text_color:string,
     *               title:string,compact:string,full:string}|null
     */
    public function present(?string $code, ?string $label, ?string $color, ?string $serverTitle = null): ?array
    {
        $code = trim((string)$code);
        if ($code === '') return null; // нет бейджа — нет и разметки

        $label = trim((string)$label);
        $title = trim((string)$serverTitle);

        $color = $this->safeColor((string)$color);
        $textColor = $this->textColorFor($color);

        $compact = $code;                                   // в таблицах — только код
        $full = $code . ($label !== '' ? ' · ' . $label : '')
              . ($title !== '' ? ' · ' . $title : '');       // в карточке — полный

        return [
            'code' => $code,
            'label' => $label,
            'color' => $color,
            'text_color' => $textColor,
            'title' => 'Сервер: ' . ($title !== '' ? $title : $code),
            'compact' => $compact,
            'full' => $full,
        ];
    }

    /** Удобная обёртка: presenter прямо из строки fastpanel_servers (с JOIN-полями). */
    public function fromRow(array $row): ?array
    {
        return $this->present(
            $row['ui_badge_code'] ?? null,
            $row['ui_badge_label'] ?? null,
            $row['ui_badge_color'] ?? null,
            $row['server_title'] ?? ($row['title'] ?? null)
        );
    }

    /** Строгая HEX-валидация; иначе безопасный дефолт (никогда не произвольный CSS). */
    public function safeColor(string $color): string
    {
        $color = trim($color);
        return preg_match('~^#[0-9A-Fa-f]{6}$~', $color) ? $color : self::DEFAULT_COLOR;
    }

    /**
     * Карта site_id → готовый бейдж (или null). ОДИН запрос на страницу (§8.5),
     * а не по запросу на строку. Используется списками, где строки несут site_id
     * (SSL, переезды) и где JOIN в основной SQL нежелателен.
     *
     * @return array<int,array|null>
     */
    public function badgeMapBySite(?PDO $pdo = null): array
    {
        $pdo = $pdo ?: DB::pdo();
        $rows = $pdo->query(
            "SELECT s.id AS sid, fps.ui_badge_code, fps.ui_badge_label, fps.ui_badge_color, fps.title AS server_title
               FROM sites_managed s
               LEFT JOIN fastpanel_servers fps ON fps.id = s.fastpanel_server_id"
        )->fetchAll(PDO::FETCH_ASSOC);
        $map = [];
        foreach ($rows as $r) {
            $map[(int)$r['sid']] = $this->fromRow($r);
        }
        return $map;
    }

    /**
     * Серверы для выпадающего фильтра «по серверу» (§8.4): id, заголовок,
     * бейдж-поля. По умолчанию — все; фильтр передаёт server_id, а не текст.
     *
     * @return array<int,array>
     */
    public static function serversForFilter(?PDO $pdo = null): array
    {
        $pdo = $pdo ?: DB::pdo();
        return $pdo->query(
            "SELECT id, title, ui_badge_code, ui_badge_label, ui_badge_color
               FROM fastpanel_servers ORDER BY id ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Чёрный/белый текст по яркости фона (WCAG-подобный порог). */
    public function textColorFor(string $hexColor): string
    {
        $hex = ltrim($this->safeColor($hexColor), '#');
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        // относительная яркость (sRGB, упрощённая)
        $lum = (0.2126 * $r + 0.7152 * $g + 0.0722 * $b) / 255;
        return $lum > 0.6 ? '#000000' : '#ffffff';
    }
}
