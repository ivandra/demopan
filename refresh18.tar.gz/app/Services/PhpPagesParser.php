<?php

/**
 * v18.1: Парсер $pages из config.php (7k шаблон и подобные).
 *
 * Контекст: в 7k шаблоне config.php содержит:
 *
 *   $pages = [
 *       '/' => [...],
 *       '/bonus' => [...],
 *       '/zerkalo' => [...],
 *       '/404' => [...],     <- служебная, в индекс не отправляем
 *       '/vhod' => [...],
 *       ...
 *   ];
 *
 * Этот парсер читает config.php (через FTP или из строки) и достаёт
 * массив ключей $pages. Используется в стадии wm_recrawl чтобы отправлять
 * на переобход не только главную, но и все внутренние страницы.
 *
 * Логика парсера: regex-based (без eval) для безопасности.
 * Ищем блок `$pages = [` ... `];` и потом все ключи `'<path>' => [` или `"<path>" => [`.
 *
 * Если блока нет — возвращаем пустой массив, не падаем.
 */
class PhpPagesParser
{
    /**
     * Парсит ключи $pages из содержимого PHP-файла.
     *
     * @return string[] список path-ключей (например ['/', '/bonus', '/zerkalo'])
     *                  Пустой если $pages не найден или не парсится.
     *                  Уже исключены служебные '/404'.
     */
    public function parsePagesKeys(string $phpContent): array
    {
        if (trim($phpContent) === '') return [];

        // Шаг 1: найти блок $pages = [ ... ];
        // Используем DOTALL чтобы [ ... ] могло занимать несколько строк
        if (!preg_match('/\$pages\s*=\s*\[(.*?)\];/s', $phpContent, $blockMatch)) {
            return [];
        }
        $pagesBlock = $blockMatch[1];

        // Шаг 2: внутри блока найти все ключи вида '/<path>' => [
        // Поддерживаем: одинарные/двойные кавычки, любые пробелы, путь без кавычек запрещён
        //
        // Регексп ищет: <quote><path><quote>\s*=>\s*\[
        // Где <path> — слэш и далее любые символы кроме кавычек
        $pageKeys = [];
        if (preg_match_all('/[\'"](\/[^\'\"]*)[\'"]\s*=>\s*\[/', $pagesBlock, $matches)) {
            foreach ($matches[1] as $path) {
                $path = (string)$path;
                if ($path === '') continue;

                // Нормализация: убрать trailing / для непустых путей (кроме '/')
                if ($path !== '/' && substr($path, -1) === '/') { // v4 (H3): PHP 7.4-совместимо
                    $path = rtrim($path, '/');
                }

                // Служебные страницы пропускаем
                if ($this->isServicePath($path)) continue;

                $pageKeys[] = $path;
            }
        }

        // Дедупликация с сохранением порядка
        return array_values(array_unique($pageKeys));
    }

    /**
     * Получить полные URL страниц для домена.
     *
     * @param string $phpContent содержимое config.php
     * @param string $domain хост (например '7k5213.casino')
     * @param string $scheme 'https' или 'http' (default https)
     * @return string[] список абсолютных URL ['https://7k5213.casino/', '...'] или пустой
     */
    public function getPageUrls(string $phpContent, string $domain, string $scheme = 'https'): array
    {
        $keys = $this->parsePagesKeys($phpContent);
        $domain = trim($domain, '/');
        if ($domain === '') return [];

        $urls = [];
        foreach ($keys as $path) {
            // path начинается с '/' — нужно конкатенировать
            if ($path === '/') {
                $urls[] = "{$scheme}://{$domain}/";
            } else {
                $urls[] = "{$scheme}://{$domain}{$path}";
            }
        }
        return array_values(array_unique($urls));
    }

    /**
     * Служебные страницы которые не нужно отправлять в индекс.
     */
    private function isServicePath(string $path): bool
    {
        $service = ['/404', '/500', '/admin', '/wp-admin', '/api'];
        return in_array($path, $service, true);
    }
}
