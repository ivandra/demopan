<?php

/**
 * MaskSnapshot — единая точка получения параметров маски для джобы.
 *
 * v5 (P1). Задача: гарантировать, что ОДНА джоба на всех стадиях
 * (покупка домена → пересчёт sub_id → построение плана замен) использует
 * ОДИН И ТОТ ЖЕ неизменяемый набор параметров.
 *
 * Почему строго:
 * прежний fromJobSnapshot() при пустом/битом/неполном snapshot молча
 * возвращался к текущим глобальным настройкам (app_settings). Из-за этого
 * джоба, созданная до внедрения snapshot, или джоба с повреждённым JSON
 * незаметно меняла алгоритм генерации — а именно этого механизм и должен
 * был не допускать.
 *
 * Политика для legacy-джоб (snapshot отсутствует):
 *   BACKFILL — параметры считаются один раз из текущих настроек сайта,
 *   записываются в artifacts_json и с этого момента становятся неизменяемыми.
 *   Факт backfill'а пишется в лог джобы как предупреждение, чтобы оператор
 *   видел, что джоба стартовала до обновления.
 *
 * Повреждённый JSON (не legacy, а именно повреждение) — исключение,
 * джоба останавливается, оператор разбирается вручную.
 */
class MaskSnapshot
{
    /**
     * Получить маску для джобы. При необходимости выполняет backfill.
     *
     * @param int                 $jobId
     * @param JobEventLogger|null $log
     * @throws \RuntimeException при повреждённом snapshot
     */
    public static function forJob(int $jobId, $log = null): DomainMaskService
    {
        $row = self::loadJobRow($jobId);
        $artifacts = (string)($row['artifacts_json'] ?? '');

        // 1) Штатный путь — snapshot есть и полон.
        if (trim($artifacts) !== '') {
            $decoded = json_decode($artifacts, true);

            if (!is_array($decoded)) {
                throw new \RuntimeException(
                    "artifacts_json джобы #{$jobId} повреждён (не разбирается как JSON). "
                    . "Параметры маски недоступны — джоба остановлена во избежание "
                    . "генерации по другим настройкам."
                );
            }

            if (isset($decoded['mask_options_snapshot'])) {
                // Строгий разбор: неполный snapshot — тоже ошибка.
                return DomainMaskService::fromJobSnapshotStrict($decoded);
            }
        }

        // 2) Legacy-джоба: snapshot'а нет. Считаем один раз и фиксируем.
        $siteJson = (string)($row['mask_settings_json'] ?? '');
        $mask = DomainMaskService::forSite(['mask_settings_json' => $siteJson]);
        $payload = $mask->snapshotPayload();

        self::persist($jobId, $payload);

        if ($log && method_exists($log, 'warn')) {
            $log->warn('mask',
                "Джоба создана до внедрения snapshot параметров маски. "
                . "Параметры зафиксированы сейчас (стратегия: {$payload['strategy']}, "
                . "шаг: {$payload['step']}) и дальше не изменятся."
            );
        }

        // Возвращаем строго из зафиксированного набора.
        return DomainMaskService::fromJobSnapshotStrict(
            ['mask_options_snapshot' => $payload]
        );
    }

    /**
     * Записать snapshot параметров в джобу (используется при создании джобы).
     */
    public static function persist(int $jobId, array $payload): bool
    {
        try {
            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs
                    SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                  WHERE id = ?"
            );
            return $st->execute([
                json_encode(['mask_options_snapshot' => $payload],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Есть ли у джобы зафиксированный snapshot (для диагностики/проверок перед деплоем).
     */
    public static function hasSnapshot(int $jobId): bool
    {
        try {
            $row = self::loadJobRow($jobId);
            $a = (string)($row['artifacts_json'] ?? '');
            if (trim($a) === '') return false;
            $d = json_decode($a, true);
            return is_array($d) && isset($d['mask_options_snapshot']) && is_array($d['mask_options_snapshot']);
        } catch (\Throwable $e) {
            return false;
        }
    }

    private static function loadJobRow(int $jobId): array
    {
        $st = DB::pdo()->prepare(
            "SELECT j.artifacts_json, j.old_sub_id, s.mask_settings_json
               FROM refresh_jobs j
               LEFT JOIN sites_managed s ON s.id = j.site_id
              WHERE j.id = ?"
        );
        $st->execute([$jobId]);
        $row = $st->fetch();
        return is_array($row) ? $row : [];
    }
}
