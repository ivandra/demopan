<?php

/**
 * RelocationService — учёт переездов (move_indexed / move_simple).
 *
 * Ключевые принципы:
 *
 * 1. Данные не дублируются. Сайт, режим, домены и дата старта живут в
 *    refresh_jobs и берутся JOIN'ом. В site_relocations — только плановый
 *    срок, две write-once даты, состояние проверки индекса и отмена.
 *
 * 2. Статус переезда НЕ хранится, а вычисляется (computeStatus). Исключение —
 *    отмена: её вывести из данных нельзя, поэтому есть cancelled_at.
 *
 * 3. Все временные метки пишутся выражением MySQL NOW(). PHP-времена в записи
 *    не подставляются: PHP работает в UTC (public/index.php:18), сессия MySQL
 *    тоже переводится в UTC (DB.php:75) — значит NOW() является единым
 *    источником времени и рассинхронизация невозможна.
 *
 * 4. first_indexed_at и move_completed_at — write-once. Гарантия обеспечивается
 *    не проверкой в PHP, а условием IS NULL прямо в UPDATE, что исключает гонки.
 *
 * 5. Индексация засчитывается ТОЛЬКО по XMLStock (primary_method='xmlstock').
 *    Fallback Яндекс Вебмастера внутри пайплайна на раздел не влияет.
 *
 * Совместимо с PHP 7.4.
 */
class RelocationService
{
    /** Режимы джоб, попадающие в раздел «Переезды». */
    const MOVE_MODES = ['move_indexed', 'move_simple'];

    /** Плановый срок по умолчанию — дата старта + 14 суток. */
    const DEFAULT_PLAN_DAYS = 14;

    /** Допустимые значения index_status. */
    const INDEX_STATUSES = ['unchecked', 'not_indexed', 'indexed', 'check_error'];

    /** Допустимые значения trigger_type в истории проверок. */
    const TRIGGERS = ['pipeline', 'manual', 'cron'];

    /**
     * Текущий оператор. В панели нет таблицы users и числовых ID —
     * авторизация это один общий флаг сессии, логин лежит в $_SESSION['user'].
     * Поэтому во всех *_by пишется имя логина, а не ID.
     */
    public static function currentUser(): ?string
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $u = $_SESSION['user'] ?? null;
        return is_string($u) && $u !== '' ? mb_substr($u, 0, 64) : null;
    }

    /* ==================== СОЗДАНИЕ ==================== */

    /**
     * Создать запись переезда для джобы. Идемпотентно: повторный вызов
     * для той же джобы не создаёт дубликат (UNIQUE (job_id) + проверка).
     *
     * Вызывается после того, как новый домен зафиксирован в джобе, — тогда
     * snapshot_json сразу полон.
     *
     * @return int|null id записи или null, если создавать не нужно
     */
    public static function createForJob(int $jobId, ?string $user = null): ?int
    {
        $job = self::loadJob($jobId);
        if (!$job) return null;

        // Только move-режимы. refresh — это перевыставление, не переезд.
        if (!in_array((string)$job['mode'], self::MOVE_MODES, true)) {
            return null;
        }

        $existing = self::findByJobId($jobId);
        if ($existing) {
            // Домен мог быть куплен позже создания записи — досохраняем snapshot.
            self::refreshSnapshot((int)$existing['id'], $job);
            return (int)$existing['id'];
        }

        $st = DB::pdo()->prepare(
            "INSERT INTO site_relocations
                (job_id, planned_at, snapshot_json, created_by, created_at, updated_at)
             SELECT ?, DATE_ADD(j.created_at, INTERVAL ? DAY), ?, ?, NOW(), NOW()
               FROM refresh_jobs j
              WHERE j.id = ?"
        );
        $st->execute([
            $jobId,
            self::DEFAULT_PLAN_DAYS,
            self::buildSnapshot($job),
            $user,
            $jobId,
        ]);

        $id = (int)DB::pdo()->lastInsertId();
        return $id > 0 ? $id : null;
    }

    /**
     * Snapshot основных данных джобы — чтобы раздел пережил её удаление.
     * Создаётся/обновляется только когда новый домен уже известен.
     */
    private static function buildSnapshot(array $job): ?string
    {
        $newDomain = trim((string)($job['new_domain'] ?? ''));
        if ($newDomain === '') {
            return null; // домен ещё не зафиксирован — snapshot будет дописан позже
        }
        return json_encode([
            'site_id'        => (int)$job['site_id'],
            'mode'           => (string)$job['mode'],
            'old_domain'     => (string)$job['old_domain'],
            'new_domain'     => $newDomain,
            'job_created_at' => (string)$job['created_at'],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /**
     * Дописать snapshot, если он был пуст (запись создана до покупки домена).
     */
    public static function refreshSnapshot(int $relocationId, ?array $job = null): void
    {
        $rel = self::findById($relocationId);
        if (!$rel) return;
        if (trim((string)($rel['snapshot_json'] ?? '')) !== '') return;

        if ($job === null) $job = self::loadJob((int)$rel['job_id']);
        if (!$job) return;

        $snapshot = self::buildSnapshot($job);
        if ($snapshot === null) return;

        $st = DB::pdo()->prepare(
            "UPDATE site_relocations SET snapshot_json = ?, updated_at = NOW() WHERE id = ?"
        );
        $st->execute([$snapshot, $relocationId]);
    }

    /** Обязательные поля snapshot'а. */
    const SNAPSHOT_FIELDS = ['site_id','mode','old_domain','new_domain','job_created_at'];

    /**
     * Полон ли snapshot записи (все обязательные поля заполнены).
     */
    public static function snapshotComplete(?string $json): bool
    {
        if ($json === null || trim($json) === '') return false;
        $d = json_decode($json, true);
        if (!is_array($d)) return false;
        foreach (self::SNAPSHOT_FIELDS as $f) {
            if (!isset($d[$f]) || $d[$f] === '' || $d[$f] === null) return false;
        }
        return true;
    }

    /**
     * v22.2: гарантировать полный snapshot ДО удаления джобы.
     *
     * Запись переезда создаётся раньше покупки домена, поэтому snapshot сначала
     * пуст и дописывается позже. Если то досохранение упало (ошибка логировалась,
     * но джобу не блокировала), после удаления джобы раздел потерял бы сайт,
     * режим, домены и дату старта. Поэтому перед удалением snapshot
     * пересобирается из ещё существующей джобы и перечитывается.
     *
     * @return array ['ok'=>bool, 'error'=>string]
     */
    public static function ensureSnapshotComplete(int $relocationId): array
    {
        $rel = self::findById($relocationId);
        if (!$rel) return ['ok' => false, 'error' => 'запись переезда не найдена'];

        if (self::snapshotComplete((string)($rel['snapshot_json'] ?? ''))) {
            return ['ok' => true, 'error' => ''];
        }

        // Пересобираем из джобы, пока она ещё существует.
        $job = self::loadJob((int)$rel['job_id']);
        if (!$job) {
            return ['ok' => false, 'error' => 'джоба уже недоступна, snapshot восстановить не из чего'];
        }

        $snapshot = self::buildSnapshot($job);
        if ($snapshot === null) {
            return ['ok' => false, 'error' => 'в джобе не зафиксирован новый домен'];
        }

        $st = DB::pdo()->prepare(
            "UPDATE site_relocations SET snapshot_json = ?, updated_at = NOW() WHERE id = ?"
        );
        $st->execute([$snapshot, $relocationId]);

        // Перечитываем и проверяем результат, а не полагаемся на факт UPDATE.
        $fresh = self::findById($relocationId);
        if (!$fresh || !self::snapshotComplete((string)($fresh['snapshot_json'] ?? ''))) {
            return ['ok' => false, 'error' => 'snapshot не удалось восстановить полностью'];
        }

        return ['ok' => true, 'error' => ''];
    }

    /* ==================== WRITE-ONCE ДАТЫ ==================== */

    /**
     * Зафиксировать первое появление нового домена в индексе.
     *
     * ВАЖНО: вызывать только когда источник результата — XMLStock
     * (primary_method === 'xmlstock'). Проверка источника лежит на вызывающей
     * стороне, потому что она различается: у пайплайна это поле результата
     * IndexCheckOrchestrator, у ручной проверки — прямой вызов XmlStockIndexCheck.
     *
     * @return bool true, если дата была записана именно этим вызовом
     */
    public static function markFirstIndexed(int $relocationId): bool
    {
        $st = DB::pdo()->prepare(
            "UPDATE site_relocations
                SET first_indexed_at = NOW(),
                    index_status     = 'indexed',
                    index_error      = NULL,
                    updated_at       = NOW()
              WHERE id = ? AND first_indexed_at IS NULL"
        );
        $st->execute([$relocationId]);

        if ($st->rowCount() > 0) {
            return true;
        }

        // Дата уже стояла — статус всё равно приводим к indexed (не перезаписывая дату).
        $up = DB::pdo()->prepare(
            "UPDATE site_relocations
                SET index_status = 'indexed', index_error = NULL, updated_at = NOW()
              WHERE id = ? AND index_status <> 'indexed'"
        );
        $up->execute([$relocationId]);
        return false;
    }

    /**
     * Зафиксировать фактический переезд — подтверждение main_mirror.
     * Write-once, гонки исключены условием IS NULL в UPDATE.
     *
     * @return bool true, если дата была записана именно этим вызовом
     */
    public static function markMoveCompleted(int $relocationId): bool
    {
        $st = DB::pdo()->prepare(
            "UPDATE site_relocations
                SET move_completed_at = NOW(), updated_at = NOW()
              WHERE id = ? AND move_completed_at IS NULL"
        );
        $st->execute([$relocationId]);
        return $st->rowCount() > 0;
    }

    /**
     * Обновить состояние проверки индекса.
     *
     * index_checked_at обновляется ТОЛЬКО когда запрос к XMLStock был
     * фактически отправлен ($requestSent = true). Пропуск из-за занятого
     * лока не должен откладывать реальную проверку на сутки.
     */
    public static function updateIndexState(
        int $relocationId,
        string $status,
        ?string $error = null,
        bool $requestSent = true
    ): void {
        if (!in_array($status, self::INDEX_STATUSES, true)) {
            $status = 'check_error';
        }

        $sql = "UPDATE site_relocations
                   SET index_status = ?, index_error = ?"
             . ($requestSent ? ", index_checked_at = NOW()" : "")
             . ", updated_at = NOW()
                 WHERE id = ?";

        $st = DB::pdo()->prepare($sql);
        $st->execute([$status, $error !== null ? mb_substr($error, 0, 255) : null, $relocationId]);
    }

    /* ==================== ДЕЙСТВИЯ ОПЕРАТОРА ==================== */

    /**
     * Изменить плановую дату. Дата старта при этом не меняется никогда.
     */
    public static function changePlannedAt(int $relocationId, string $newPlannedAt, ?string $user): array
    {
        $rel = self::findById($relocationId);
        if (!$rel) return ['ok' => false, 'error' => 'Запись не найдена'];

        // H1: оператор вводит время в МСК (как и schedule_at при создании джобы),
        // а панель хранит UTC. Без явного указания зоны strtotime() разобрал бы
        // ввод как UTC и дата уезжала бы на +3 часа.
        //
        // v22.3: разбор СТРОГИЙ. Мягкий конструктор DateTimeImmutable принимает
        // пустую строку как «сейчас» — очистка поля незаметно переносила плановую
        // дату на текущий момент. Он же нормализует несуществующие даты
        // (например 2026-02-31 → 2026-03-03) вместо отказа.
        $raw = trim(str_replace('T', ' ', $newPlannedAt));
        if ($raw === '') {
            return ['ok' => false, 'error' => 'Плановая дата не может быть пустой'];
        }

        // Допускаем и «Y-m-d H:i», и «Y-m-d H:i:s»
        $tzMsk = new \DateTimeZone('Europe/Moscow');
        $dt = null;
        foreach (['!Y-m-d H:i:s', '!Y-m-d H:i'] as $fmt) {
            $try = \DateTimeImmutable::createFromFormat($fmt, $raw, $tzMsk);
            $err = \DateTimeImmutable::getLastErrors();
            $hasErrors = is_array($err) && ((int)($err['warning_count'] ?? 0) > 0 || (int)($err['error_count'] ?? 0) > 0);
            if ($try instanceof \DateTimeImmutable && !$hasErrors) {
                // Контроль обратного форматирования — отсекает нормализованные даты
                $back = $try->format(substr($fmt, 1));
                if ($back === $raw) { $dt = $try; break; }
            }
        }
        if ($dt === null) {
            return ['ok' => false, 'error' =>
                'Некорректная дата: «' . $newPlannedAt . '». Ожидается формат ГГГГ-ММ-ДД ЧЧ:ММ (московское время).'];
        }

        $formatted = $dt->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s');

        $st = DB::pdo()->prepare(
            "UPDATE site_relocations SET planned_at = ?, updated_by = ?, updated_at = NOW() WHERE id = ?"
        );
        $st->execute([$formatted, $user, $relocationId]);

        self::logAction((int)$rel['job_id'], 'planned_at_changed', [
            'user'      => $user,
            'old_value' => (string)$rel['planned_at'],
            'new_value' => $formatted,
        ]);

        return ['ok' => true, 'planned_at' => $formatted];
    }

    /**
     * Отменить учёт переезда.
     *
     * Отмена НЕ трогает джобу — это две разные операции. Пока связанная джоба
     * активна, отмена запрещена: сначала оператор должен остановить джобу
     * штатным действием.
     */
    public static function cancel(int $relocationId, string $comment, ?string $user): array
    {
        $comment = trim($comment);
        if ($comment === '') {
            return ['ok' => false, 'error' => 'Комментарий обязателен при отмене'];
        }

        $rel = self::findById($relocationId);
        if (!$rel) return ['ok' => false, 'error' => 'Запись не найдена'];
        if (!empty($rel['cancelled_at'])) {
            return ['ok' => false, 'error' => 'Переезд уже отменён'];
        }
        // H4: завершённый переезд отменять нельзя — статус «Отменён» стоит выше
        // «Завершён» в расчёте, и история переезда была бы искажена задним числом.
        if (!empty($rel['move_completed_at'])) {
            return ['ok' => false, 'error' =>
                'Нельзя отменить переезд, который уже подтверждён Яндексом ('
                . $rel['move_completed_at'] . '). Запись завершена.'];
        }

        $job = self::loadJob((int)$rel['job_id']);
        if ($job && self::isJobActive($job)) {
            return ['ok' => false, 'error' =>
                'Нельзя отменить учёт переезда, пока джоба #' . (int)$rel['job_id'] .
                ' активна (стадия ' . $job['stage'] . ', статус ' . $job['stage_status'] . '). ' .
                'Сначала остановите джобу штатным действием в разделе «Джобы».'];
        }

        $st = DB::pdo()->prepare(
            "UPDATE site_relocations
                SET cancelled_at = NOW(), cancelled_by = ?, comment = ?, updated_by = ?, updated_at = NOW()
              WHERE id = ? AND cancelled_at IS NULL"
        );
        $st->execute([$user, $comment, $user, $relocationId]);

        self::logAction((int)$rel['job_id'], 'relocation_cancelled', [
            'user'    => $user,
            'comment' => $comment,
        ]);

        return ['ok' => true];
    }

    /**
     * Джоба считается активной, пока её stage не терминален — то же правило,
     * что у блокировки создания новой джобы.
     * v24.2 (B5): cancelled/superseded тоже терминальны — иначе после
     * закрытия джобы оператор не мог отменить учёт переезда («джоба активна»).
     */
    public static function isJobActive(array $job): bool
    {
        return !JobLifecycleService::isTerminal((string)($job['stage'] ?? ''));
    }

    /* ==================== ИСТОРИЯ ПРОВЕРОК ==================== */

    /**
     * Записать попытку проверки индекса в структурированную историю.
     *
     * @param string $trigger pipeline|manual|cron — валидируется здесь
     */
    public static function recordCheck(int $relocationId, string $trigger, array $result, ?string $user = null): void
    {
        if (!in_array($trigger, self::TRIGGERS, true)) {
            $trigger = 'cron';
        }

        $st = DB::pdo()->prepare(
            "INSERT INTO site_relocation_index_checks
                (relocation_id, checked_at, trigger_type, source, ok, indexed,
                 pages_indexed, error_code, error_message, created_by, created_at)
             VALUES (?, NOW(), ?, 'xmlstock', ?, ?, ?, ?, ?, ?, NOW())"
        );
        $st->execute([
            $relocationId,
            $trigger,
            !empty($result['ok']) ? 1 : 0,
            !empty($result['indexed']) ? 1 : 0,
            (int)($result['pages_indexed'] ?? 0),
            isset($result['error']) && $result['error'] !== '' ? mb_substr((string)$result['error'], 0, 64) : null,
            isset($result['message']) && $result['message'] !== '' ? mb_substr((string)$result['message'], 0, 255) : null,
            $trigger === 'manual' ? $user : null,
        ]);
    }

    /** История проверок по записи (для карточки). */
    public static function checkHistory(int $relocationId, int $limit = 50): array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM site_relocation_index_checks
              WHERE relocation_id = ?
              ORDER BY checked_at DESC, id DESC
              LIMIT " . max(1, min(500, $limit))
        );
        $st->execute([$relocationId]);
        return $st->fetchAll() ?: [];
    }

    /**
     * Действия оператора.
     *
     * H5: пишем в ДВА места. refresh_job_events удобен тем, что действие видно
     * в карточке джобы, но эти события физически удаляются вместе с джобой
     * (RefreshJobController::delete). Поэтому та же запись дублируется в
     * site_relocation_history, которая переживает удаление джобы.
     */
    public static function logAction(int $jobId, string $action, array $payload): void
    {
        $message = self::describeAction($action, $payload);
        $json = json_encode(array_merge(['action' => $action], $payload),
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        // 1) журнал джобы (удобно оператору, но удаляется вместе с джобой)
        try {
            $st = DB::pdo()->prepare(
                "INSERT INTO refresh_job_events (job_id, stage, level, message, payload_json, created_at)
                 VALUES (?, 'relocation', 'info', ?, ?, NOW())"
            );
            $st->execute([$jobId, $message, $json]);
        } catch (\Throwable $e) {
            error_log('RelocationService::logAction (events) failed: ' . $e->getMessage());
        }

        // 2) собственная история раздела — не удаляется вместе с джобой
        try {
            $rel = self::findByJobId($jobId);
            if ($rel) {
                $st = DB::pdo()->prepare(
                    "INSERT INTO site_relocation_history
                        (relocation_id, action, actor, old_value, new_value, comment, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, NOW())"
                );
                $st->execute([
                    (int)$rel['id'],
                    mb_substr($action, 0, 48),
                    isset($payload['user']) ? mb_substr((string)$payload['user'], 0, 64) : null,
                    isset($payload['old_value']) ? mb_substr((string)$payload['old_value'], 0, 255) : null,
                    isset($payload['new_value']) ? mb_substr((string)$payload['new_value'], 0, 255) : null,
                    isset($payload['comment'])   ? mb_substr((string)$payload['comment'], 0, 255) : null,
                ]);
            }
        } catch (\Throwable $e) {
            error_log('RelocationService::logAction (history) failed: ' . $e->getMessage());
        }
    }

    /** История действий оператора по записи (переживает удаление джобы). */
    public static function actionHistory(int $relocationId, int $limit = 50): array
    {
        try {
            $st = DB::pdo()->prepare(
                "SELECT * FROM site_relocation_history
                  WHERE relocation_id = ?
                  ORDER BY created_at DESC, id DESC
                  LIMIT " . max(1, min(500, $limit))
            );
            $st->execute([$relocationId]);
            return $st->fetchAll() ?: [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    private static function describeAction(string $action, array $p): string
    {
        switch ($action) {
            case 'planned_at_changed':
                return 'Плановая дата переезда изменена: '
                     . ($p['old_value'] ?? '?') . ' → ' . ($p['new_value'] ?? '?');
            case 'relocation_cancelled':
                return 'Учёт переезда отменён. Причина: ' . ($p['comment'] ?? '');
            case 'manual_check_requested':
                return 'Запущена ручная проверка индекса (XMLStock)';
            case 'manual_check_skipped_lock_busy':
                return 'Ручная проверка пропущена: домен уже проверяет другой процесс';
            case 'manual_check_skipped_pipeline_active':
                return 'Ручная проверка пропущена: проверка выполняется внутри джобы';
            case 'manual_check_skipped_low_balance':
                return 'Ручная проверка пропущена: недостаточный баланс XMLStock';
            case 'manual_check_skipped_already_indexed':
                return 'Ручная проверка пропущена: домен уже в индексе';
            case 'manual_check_skipped_cancelled':
                return 'Ручная проверка пропущена: учёт переезда отменён';
            case 'manual_check_skipped_empty_domain':
                return 'Ручная проверка пропущена: новый домен не зафиксирован';
            default:
                return $action;
        }
    }

    /* ==================== ВЫБОРКА ==================== */

    public static function findById(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM site_relocations WHERE id = ?");
        $st->execute([$id]);
        $row = $st->fetch();
        return is_array($row) ? $row : null;
    }

    public static function findByJobId(int $jobId): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM site_relocations WHERE job_id = ?");
        $st->execute([$jobId]);
        $row = $st->fetch();
        return is_array($row) ? $row : null;
    }

    private static function loadJob(int $jobId): ?array
    {
        $st = DB::pdo()->prepare(
            "SELECT id, site_id, mode, old_domain, new_domain, stage, stage_status, created_at
               FROM refresh_jobs WHERE id = ?"
        );
        $st->execute([$jobId]);
        $row = $st->fetch();
        return is_array($row) ? $row : null;
    }

    /**
     * Строка переезда, обогащённая данными джобы (или snapshot'ом, если джоба удалена).
     */
    public static function enrich(array $rel): array
    {
        $snapshot = [];
        if (!empty($rel['snapshot_json'])) {
            $decoded = json_decode((string)$rel['snapshot_json'], true);
            if (is_array($decoded)) $snapshot = $decoded;
        }

        $rel['job_exists']     = !empty($rel['job_id_present']);
        $rel['site_id']        = $rel['job_site_id']    ?? ($snapshot['site_id'] ?? null);
        $rel['mode']           = $rel['job_mode']       ?? ($snapshot['mode'] ?? '');
        $rel['old_domain']     = $rel['job_old_domain'] ?? ($snapshot['old_domain'] ?? '');
        $rel['new_domain']     = $rel['job_new_domain'] ?? ($snapshot['new_domain'] ?? '');
        $rel['started_at']     = $rel['job_created_at'] ?? ($snapshot['job_created_at'] ?? null);
        $rel['stage']          = $rel['job_stage']        ?? null;
        $rel['stage_status']   = $rel['job_stage_status'] ?? null;

        $rel['status']         = self::computeStatus($rel);
        $rel['delay']          = self::computeDelay($rel);
        $rel['duration']       = self::computeDuration($rel);

        return $rel;
    }

    /* ==================== ВЫЧИСЛЯЕМЫЕ ПОЛЯ ==================== */

    /**
     * Статус переезда. В БД не хранится — считается сверху вниз,
     * первое совпадение выигрывает.
     *
     * Ошибка XMLStock (index_status=check_error) сама по себе НЕ переводит
     * переезд в статус «Ошибка» — таково требование ТЗ 3.7.
     */
    public static function computeStatus(array $rel): string
    {
        if (!empty($rel['cancelled_at']))      return 'cancelled';
        if (!empty($rel['move_completed_at'])) return 'completed';
        if (($rel['stage'] ?? '') === 'failed') return 'error';

        $planned = strtotime((string)($rel['planned_at'] ?? ''));
        if ($planned !== false && $planned < time()) return 'overdue';

        return 'in_progress';
    }

    public static function statusLabel(string $status): string
    {
        $map = [
            'cancelled'   => 'Отменён',
            'completed'   => 'Завершён',
            'error'       => 'Ошибка',
            'overdue'     => 'Просрочен',
            'in_progress' => 'В процессе',
        ];
        return $map[$status] ?? $status;
    }

    public static function indexStatusLabel(string $s): array
    {
        $map = [
            'unchecked'   => ['Не проверялся',  '#8b949e'],
            'not_indexed' => ['Без индекса',    '#ef4444'],
            'indexed'     => ['В индексе',      '#3fb950'],
            'check_error' => ['Ошибка проверки','#f0a020'],
        ];
        return $map[$s] ?? ['—', '#8b949e'];
    }

    /**
     * Задержка = move_completed_at − planned_at.
     * Пока фактический переезд не подтверждён — срок до плановой даты
     * либо текущая просрочка.
     */
    public static function computeDelay(array $rel): array
    {
        $planned = strtotime((string)($rel['planned_at'] ?? ''));
        if ($planned === false) return ['kind' => 'unknown', 'text' => '—'];

        if (!empty($rel['move_completed_at'])) {
            $done = strtotime((string)$rel['move_completed_at']);
            if ($done === false) return ['kind' => 'unknown', 'text' => '—'];
            $diff = $done - $planned;
            if ($diff === 0)  return ['kind' => 'ontime', 'text' => 'В срок'];
            if ($diff > 0)    return ['kind' => 'late',   'text' => 'Задержка ' . self::humanInterval($diff)];
            return ['kind' => 'early', 'text' => 'На ' . self::humanInterval(-$diff) . ' раньше'];
        }

        if (!empty($rel['cancelled_at'])) return ['kind' => 'none', 'text' => '—'];

        $now = time();
        if ($now <= $planned) {
            return ['kind' => 'pending', 'text' => 'До плановой даты: ' . self::humanInterval($planned - $now)];
        }
        return ['kind' => 'overdue', 'text' => 'Просрочено на ' . self::humanInterval($now - $planned)];
    }

    /** Длительность переезда = move_completed_at − дата старта джобы. */
    public static function computeDuration(array $rel): ?string
    {
        if (empty($rel['move_completed_at']) || empty($rel['started_at'])) return null;
        $a = strtotime((string)$rel['started_at']);
        $b = strtotime((string)$rel['move_completed_at']);
        if ($a === false || $b === false || $b < $a) return null;
        return self::humanInterval($b - $a);
    }

    /**
     * H1: значение для <input type="datetime-local"> — переводим хранимый UTC
     * в МСК, потому что оператор вводит и читает московское время.
     */
    public static function toMskInput(?string $utcDatetime): string
    {
        if (!$utcDatetime) return '';
        try {
            $dt = new \DateTimeImmutable($utcDatetime, new \DateTimeZone('UTC'));
            return $dt->setTimezone(new \DateTimeZone('Europe/Moscow'))->format('Y-m-d\TH:i');
        } catch (\Throwable $e) {
            return '';
        }
    }

    /** «3 дня 6 часов», «1 день 20 часов», «45 минут». */
    public static function humanInterval(int $sec): string
    {
        $sec = max(0, $sec);
        $days  = intdiv($sec, 86400);
        $hours = intdiv($sec % 86400, 3600);
        $mins  = intdiv($sec % 3600, 60);

        $parts = [];
        if ($days > 0)  $parts[] = $days . ' ' . self::plural($days, 'день', 'дня', 'дней');
        if ($hours > 0) $parts[] = $hours . ' ' . self::plural($hours, 'час', 'часа', 'часов');
        if (!$parts && $mins > 0) $parts[] = $mins . ' ' . self::plural($mins, 'минута', 'минуты', 'минут');
        if (!$parts) $parts[] = 'меньше минуты';

        return implode(' ', array_slice($parts, 0, 2));
    }

    private static function plural(int $n, string $one, string $few, string $many): string
    {
        $n = abs($n) % 100;
        if ($n >= 11 && $n <= 14) return $many;
        $n %= 10;
        if ($n === 1) return $one;
        if ($n >= 2 && $n <= 4) return $few;
        return $many;
    }
}
