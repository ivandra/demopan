<?php

/**
 * JobEventPresenter (ТЗ 039 §11–§18) — единый презентер операторских сообщений.
 *
 * Единственный источник человекочитаемого текста для карточки джобы, лога
 * событий, Telegram, /xmlstock, карточки ban-monitor и блоков ручного
 * вмешательства. Не размножаем словари по View.
 *
 * Два уровня (§11):
 *   - обычный режим (humanText): понятные русские фразы, без запрещённых слов §13;
 *   - технические детали (raw stage/status/event_code/JSON/идентификаторы) —
 *     отдаётся отдельно (techDetails), View прячет их в раскрываемый блок.
 *
 * Приоритет источника (§12):
 *   1) payload_json.event_code (стабильный код + параметры) → фраза по коду;
 *   2) fallback-нормализатор старого message (эвристики по подстрокам).
 */
final class JobEventPresenter
{
    /**
     * Запрещённые в обычном режиме слова/коды (§13). Используется тестами и
     * humanize-фолбэком как «красный список»: если фраза его содержит — это
     * технический текст, требующий нормализации.
     */
    public const FORBIDDEN_WORDS = [
        'Eligible', 'eligible', 'generation', 'policy', 'pending', 'resume',
        'Tick', 'tick', 'cert_id', 'execution_state', 'initiated_by',
        'awaiting_user', 'awaiting_trusted_ssl_after_verification', 'no_connection',
        'variant_state', 'identity_verified', 'not_applicable', 'ambiguous',
        'cron', 'operator', 'raw policy snapshot',
        // §5.2 (release gate): расширенный список.
        'Pipeline', 'pipeline', 'Outcome', 'outcome', 'Execution state',
        'mapping/CSS', 'mapping', 'raw JSON', 'audit', 'update_classes_call',
        'ssl_reconciler', 'domain_readiness', 'cutoff', 'enrollment',
        // §9.2 (v2.0): добавленные термины.
        'snapshot', 'initial delay', 'robots_php_logic', 'uc_site_subroot',
        'Stage started', 'Stage finished', 'ssl_le_polling', 'ssl_self_signed_first',
        'verify_replacement', 'php_uniquification_verified_at',
        // ТЗ 045 §10: коды PATCH 044 и типовые технические токены — только в tech.
        'prepared_target_invalid', 'domain_mismatch', 'replacement_plan', 'config_mutation',
        'prepurchase_unsafe', 'read_back', 'target_sha256', 'ambiguous_purchase',
        'snapshot_not_written', 'cas_update_failed', 'getaddrinfo', 'php_network_getaddresses',
        'ssl_reconciler', 'REFRESH-DISABLED', 'not_eligible_status', 'state_changed_concurrently',
        'live_inspection_failed', 'missing_config_mutation_plan', 'sub_id_drift', 'config_domain_drift',
    ];

    /**
     * Человекочитаемые названия стадий (§16.1). Raw-код остаётся в tooltip.
     */
    public const STAGE_LABELS = [
        'queued'                 => 'В очереди',
        'accepted'               => 'Принято в работу',
        'domain_purchasing'      => 'Покупка домена',
        'domain_purchase'        => 'Покупка домена',
        'awaiting_account'       => 'Ожидание аккаунта регистратора',
        'awaiting_host'          => 'Ожидание сервера',
        'pending_quota'          => 'Ожидание свободного лимита',
        'ns_setup'               => 'Настройка DNS',
        'dns_setup'              => 'Настройка DNS',
        'dns_configuring'        => 'Настройка DNS',
        'analyze_site'           => 'Анализ сайта',
        'prepare_target'         => 'Подготовка сайта',
        'aliases_added'          => 'Добавление доменных алиасов',
        'replace_content'        => 'Замена ссылок',
        'config_replaced'        => 'Обновление настроек сайта',
        'verify_replacement'     => 'Проверка внесённых изменений',
        'update_classes_call'    => 'Смена классов сайта',
        'update_called'          => 'Смена классов сайта',
        'domain_readiness'       => 'Проверка доступности домена',
        'redirect_enable'        => 'Включение редиректа',
        'redirect_disable'       => 'Отключение редиректа',
        'move_htaccess_redirect' => 'Настройка переезда',
        'ssl_self_signed_first'  => 'Установка временного сертификата',
        'ssl_issuing'            => 'Выпуск сертификата',
        'ssl_le_polling'         => 'Выпуск сертификата',
        'ssl_reconciler'         => 'Выпуск сертификата',
        'trusted_ssl_gate'       => 'Проверка сертификата',
        'wm_account_resolve'     => 'Поиск аккаунта Webmaster',
        'wm_added'               => 'Добавление в Webmaster',
        'wm_verified'            => 'Подтверждение прав в Яндекс Вебмастере',
        'wm_recrawl'             => 'Запрос переобхода',
        'wm_sitemap'             => 'Отправка карты сайта',
        'wm_robots'              => 'Проверка robots.txt',
        'wm_robots_check'        => 'Проверка robots.txt',
        'wm_old_removed'         => 'Удаление старого адреса из Webmaster',
        'index_watching'         => 'Ожидание появления сайта в поиске',
        'final_monitoring'       => 'Финальная проверка',
        'move_submit_request'    => 'Заявка на переезд',
        'move_poll_status'       => 'Ожидание переезда',
        'old_delurl_notify'      => 'Удаление старого адреса',
        'done'                   => 'Готово',
        'failed'                 => 'Ошибка',
        'cancelled'              => 'Отменена',
        'superseded'             => 'Заменена новой',
    ];

    /** Русское имя стадии (§16.1); неизвестная — сам код (для tooltip). */
    /**
     * ТЗ 039 §6.2: человекочитаемый статус Яндекс Вебмастера по ЧЕТЫРЁМ уровням.
     * Ни strict_https_at, ни submitted_at по отдельности НЕ дают «Права
     * подтверждены» — фактический успех определяется только реальным wm_verified
     * (переход стадии после положительного результата) либо явным флагом.
     *
     * @param array $job строка джобы (поля wm_*, stage)
     * @return array{text:string, tone:string} tone: ok|wait|warn|muted
     */
    public static function webmasterStatus(array $job): array
    {
        $stage = (string)($job['stage'] ?? '');
        $lastState = (string)($job['wm_verification_last_state'] ?? '');
        $verifiedFact = in_array($stage, ['wm_recrawl','wm_sitemap','wm_robots','index_watching',
            'final_monitoring','wm_old_removed','done'], true)
            || !empty($job['wm_verified_at'])
            || $lastState === 'verified' || $lastState === 'success';
        if ($verifiedFact) return ['text' => 'Права подтверждены', 'tone' => 'ok'];
        if ($lastState === 'error' || $lastState === 'failed') {
            return ['text' => 'Не удалось подтвердить права', 'tone' => 'warn'];
        }
        if (!empty($job['wm_verification_submitted_at'])) {
            return ['text' => 'Яндекс проверяет права', 'tone' => 'wait'];
        }
        if (!empty($job['wm_verifier_strict_https_at']) || !empty($job['wm_verifier_uploaded_at'])) {
            return ['text' => 'Файл подтверждения подготовлен', 'tone' => 'wait'];
        }
        if (in_array($stage, ['wm_added','wm_verified','wm_account_resolve'], true)) {
            return ['text' => 'Добавляется', 'tone' => 'wait'];
        }
        return ['text' => 'Ожидает', 'tone' => 'muted'];
    }

    public static function stageLabel(string $stage): string
    {
        // ТЗ 039 §5.5: НИКОГДА не возвращаем сырой код стадии. Неизвестная стадия →
        // «Служебный этап» (raw-код уходит в технические данные отдельно).
        return self::STAGE_LABELS[$stage] ?? 'Служебный этап';
    }

    /**
     * §12: человекочитаемый статус стадии джобы. Сырые коды (pending,
     * awaiting_user, running…) НЕ показываются в обычном UI.
     */
    public static function statusLabel(string $status): string
    {
        $map = [
            'pending'       => 'В очереди',
            'running'       => 'Выполняется',
            'awaiting_user' => 'Требуется действие',
            'ok'            => 'Готово',
            'done'          => 'Завершено',
            'failed'        => 'Ошибка',
            'cancelled'     => 'Отменено',
            'superseded'    => 'Заменено новой джобой',
            'blocked'       => 'Приостановлено',
        ];
        return $map[$status] ?? 'В работе';
    }

    /**
     * Главный вход: событие → человекочитаемый текст + технические детали.
     *
     * @param array{stage?:string,level?:string,message?:string,payload?:array} $event
     * @return array{human:string, stage_label:string, tech:array}
     */
    public static function present(array $event): array
    {
        $stage   = (string)($event['stage'] ?? '');
        $level   = (string)($event['level'] ?? 'info');
        $message = (string)($event['message'] ?? '');
        $payload = is_array($event['payload'] ?? null) ? $event['payload'] : [];

        $eventCode = (string)($payload['event_code'] ?? '');
        // ТЗ 045 ADDENDUM: полная структурная диагностика (severity/source/action/wait/...).
        $diag = self::diagnose($stage, $level, $message, $payload);

        // Технические детали (§11/§13): raw stage/status/event_code/идентификаторы/JSON.
        $tech = [
            'stage'      => $stage,
            'stage_raw'  => $stage,
            'level'      => $level,
            'event_code' => $eventCode,
            'raw_message'=> $message,
            'technical_code' => $diag['technical_code'] ?? '',
        ];
        foreach (['technical_reason', 'cert_id', 'monitor_id', 'execution_id',
                  'next_check_seconds', 'attempt', 'max_attempts', 'generation', 'policy_version',
                  'have', 'want', 'reason', 'block_reason', 'blocking_reasons', 'next_run_at'] as $k) {
            if (array_key_exists($k, $payload)) $tech[$k] = $payload[$k];
        }

        return [
            'human'       => $diag['human'],
            'action'      => $diag['action'],
            'stage_label' => self::stageLabel($stage),
            'diag'        => $diag,
            'tech'        => $tech,
        ];
    }

    /**
     * ТЗ 045 §3.3: человекочитаемое объяснение для standalone-ошибки (stage_error в карточке),
     * когда нет полноценного event. Тот же словарь, что present().
     * @return array{human:string, action:string, stage_label:string, tech:array}
     */
    public static function standaloneError(string $stage, string $message, array $payload = []): array
    {
        return self::present(['stage' => $stage, 'level' => 'error', 'message' => $message, 'payload' => $payload]);
    }

    /**
     * ТЗ 045 ADDENDUM §12: структурный компактный текст для Telegram (тот же источник — diagnose()).
     * INFO не раздуваем; для WARN/ERROR/CRITICAL — блок критичность/источник/проблема/безопасность/
     * автовосстановление/вмешательство/ожидание/эскалация/тех.код.
     */
    public static function telegramText(string $stage, string $level, string $message, array $payload = []): string
    {
        $d = self::diagnose($stage, $level, $message, $payload);
        $sev = (string)($d['severity'] ?? 'info');

        // INFO — компактно: одна фраза + (опц.) когда следующая проверка.
        if ($sev === 'info') {
            $t = $d['reason'];
            if (($d['next_retry_at'] ?? null)) $t .= "\nСледующая проверка: " . $d['next_retry_at'];
            return $t;
        }

        $L = [];
        $L[] = 'Критичность: ' . ($d['severity_label'] ?? '');
        $L[] = 'Источник: ' . ($d['source_label'] ?? '') . ' (уверенность: ' . ($d['confidence_label'] ?? '') . ')';
        $L[] = '';
        $L[] = 'Проблема:';
        $L[] = $d['reason'];
        if (($d['impact'] ?? '') !== '') { $L[] = ''; $L[] = 'Что заблокировано: ' . $d['impact']; }
        if (($d['safety'] ?? '') !== '') { $L[] = 'Безопасность: ' . $d['safety']; }
        if (!empty($d['auto_recovery']) && ($d['auto_recovery_text'] ?? '') !== '') {
            $L[] = ''; $L[] = 'Автовосстановление: ' . $d['auto_recovery_text'];
        }
        $ha = (string)($d['human_action'] ?? 'none');
        $prefix = $ha === 'required' ? 'требуется.' : ($ha === 'maybe' ? 'может понадобиться.' : 'пока не требуется.');
        $haText = (string)($d['human_action_text'] ?? '');
        $L[] = 'Вмешательство: ' . $prefix . ($haText !== '' ? ' ' . $haText : '');
        if (($d['wait_text'] ?? '') !== '') { $L[] = ''; $L[] = $d['wait_text']; }
        $L[] = ''; $L[] = 'Тех. код: ' . ($d['technical_code'] ?? '');
        return implode("\n", $L);
    }

    /**
     * ТЗ 045 ADDENDUM: полная структурная диагностика события (§1) — единый источник
     * для UI, Telegram и stage_error. Делегирует классификацию в DiagnosticCatalog.
     * @return array дескриптор + stage_label + human/action (готовый текст).
     */
    public static function diagnose(string $stage, string $level, string $message, array $payload = []): array
    {
        $diag = DiagnosticCatalog::classify($stage, $level, $message, $payload);
        $specific = !in_array($diag['technical_code'], ['unknown_stage_error', 'unknown_stage_warning', 'stage_event'], true);

        if (!$specific) {
            // неизвестный код — пробуем legacy/event_code гуманизацию (SSL/uc/ban до PATCH 044)
            $code = (string)($payload['event_code'] ?? '');
            $legacy = $code !== '' ? self::fromEventCode($code, $payload, $message) : '';
            if ($legacy === '' || self::looksRaw($legacy) || !empty(self::containsForbidden($legacy))) {
                $legacy = self::humanizeLegacy($stage, $level, $message);
            }
            if ($legacy !== '' && !self::looksRaw($legacy) && empty(self::containsForbidden($legacy))) {
                $diag['reason'] = $legacy; // человекочитаемая legacy-фраза как «что произошло»
            }
        }

        $diag['stage_label'] = self::stageLabel($stage);
        $diag['human']  = (string)$diag['reason'];
        $diag['action'] = self::composeAction($diag);
        return $diag;
    }

    /** Компактная строка «что дальше»: автodействие приоритетнее, иначе действие пользователя. */
    private static function composeAction(array $diag): string
    {
        if (!empty($diag['auto_recovery']) && ($diag['auto_recovery_text'] ?? '') !== '') {
            return (string)$diag['auto_recovery_text'];
        }
        if (($diag['human_action'] ?? 'none') !== 'none' && ($diag['human_action_text'] ?? '') !== '') {
            return (string)$diag['human_action_text'];
        }
        return '';
    }

    /**
     * ТЗ 045: резолвер человекочитаемого текста + действия (обёртка над diagnose()).
     * @return array{human:string, action:string}
     */
    private static function resolveHumanAction(string $stage, string $level, string $message, array $payload): array
    {
        $d = self::diagnose($stage, $level, $message, $payload);
        return ['human' => $d['human'], 'action' => $d['action']];
    }

    /** Текст «сырой», если в нём нет кириллицы (значит не гуманизирован). */
    private static function looksRaw(string $s): bool
    {
        return !preg_match('~[а-яё]~iu', $s);
    }


    /** Только человекочитаемый текст (удобный шорткат). */
    public static function humanText(string $stage, string $level, string $message, array $payload = []): string
    {
        return self::present(['stage' => $stage, 'level' => $level, 'message' => $message, 'payload' => $payload])['human'];
    }

    /**
     * Фразы по стабильному event_code (§12/§14). Неизвестный код → fallback.
     */
    private static function fromEventCode(string $code, array $p, string $message): string
    {
        $sec = (int)($p['next_check_seconds'] ?? 0);
        $inSec = $sec > 0 ? self::humanInterval($sec) : 'через некоторое время';

        switch ($code) {
            // ── SSL / домен (§14.2–§14.5) ──
            case 'domain.awaiting_dns':
                return 'Домен пока недоступен из интернета. Панель автоматически проверит его снова ' . $inSec . '.';
            case 'ssl.issuance_waiting':
                return 'Сертификат выпускается. Следующая автоматическая проверка ' . $inSec . '.';
            case 'ssl.dns_propagated_resume':
                return 'DNS уже обновился. Выпуск сертификата продолжен.';
            case 'ssl.gate_checking':
                return 'Проверяем действующий сертификат на публичном сайте. До успешной проверки сайт не будет добавлен в Webmaster.';
            case 'ssl.gate_confirmed':
                return 'Действующий сертификат подтверждён. Панель переходит к добавлению сайта в Webmaster.';
            case 'ssl.legacy_wait':
                return 'Это старая джоба, начатая до обновления порядка этапов. Права в Webmaster уже подтверждены; панель ждёт завершения выпуска сертификата и не выполняет повторное добавление сайта.';

            // ── Рандомизация (§14.6/§14.7/§10) ──
            case 'uc.confirmed_absent':
            case 'uc.disabled_by_site':
                return 'На этом сайте рандомизация классов не используется. Этап пропущен автоматически.';
            case 'uc.detected_variant_refresh':
            case 'uc.detected_update_classes':
                return 'Найден поддерживаемый механизм рандомизации. Панель запускает обновление классов.';
            case 'uc.needs_review':
            case 'uc.detection_needs_review':
            case 'uc.detection_conflict':
            case 'uc.detection_ftp_error':
                return 'Найден файл рандомизации, но панель не смогла подтвердить, что он подходит этому сайту. Скрипт не запускался.';
            case 'uc.baseline_unavailable':
                return 'Панель не смогла подготовить проверку результата рандомизации, поэтому скрипт не запускался. Нужна ручная проверка.';
            case 'uc.completed_by_marker':
                return 'Рандомизация классов выполнена. Этап завершён.';
            case 'uc.http_ambiguous':
                return 'Скрипт рандомизации был вызван, но панель не смогла достоверно подтвердить изменение файлов. Повторный запуск заблокирован, чтобы не выполнить операцию дважды.';
            case 'uc.site_disabled_by_operator':
                return 'Рандомизация для сайта отключена. Этап пропущен, джоба продолжается.';

            // ── Ban-monitor (§14.1) ──
            case 'ban.enrolled_pending_first_check':
                // ревью P1: задержку берём из snapshot policy, не хардкодим 12ч.
                $delayMin = (int)($p['initial_delay_minutes'] ?? 0);
                $delayHuman = $delayMin > 0 ? self::humanInterval($delayMin * 60) : 'через 12 часов';
                return 'Мониторинг бана подключён для этой джобы. Проверки начнутся '
                    . $delayHuman . ' после того, как XMLStock впервые подтвердит появление нового домена в индексе.';

            // ── Общие (§16.6) ──
            case 'stage.started':
                return 'Этап начат: ' . self::stageLabel((string)($p['stage'] ?? ''));
            case 'stage.finished':
                return 'Этап завершён: ' . self::stageLabel((string)($p['stage'] ?? ''));
        }

        // Неизвестный код — пробуем legacy-нормализацию текста.
        return self::humanizeLegacy((string)($p['stage'] ?? ''), 'info', $message);
    }

    /**
     * Fallback-нормализатор старых строк (§12): без event_code переводим типовые
     * технические сообщения в человекочитаемые по подстрокам. Если ничего не
     * распознали — возвращаем очищенный от «сырых» маркеров текст.
     */
    private static function humanizeLegacy(string $stage, string $level, string $message): string
    {
        $m = $message;
        $low = mb_strtolower($m);

        $has = function (array $needles) use ($low): bool {
            foreach ($needles as $n) if (mb_strpos($low, mb_strtolower($n)) !== false) return true;
            return false;
        };

        // DNS/соединение (§14.2)
        if ($has(['no_connection', 'dns/соединение', 'could not resolve', 'домен пока недоступ'])) {
            return 'Домен пока недоступен из интернета. Панель автоматически проверит его снова через некоторое время.';
        }
        // trusted gate (§14.5) — раньше общей SSL-ветки: у стадии свой контракт.
        if ($stage === 'trusted_ssl_gate' || $has(['trusted_ssl', 'доверенн', 'публичный доверенн'])) {
            $negated = $has(['не подтверждён', 'ещё не подтверждён', 'not confirmed', 'ok=false']);
            if (!$negated && $has(['подтверждён', 'ok=true', 'confirmed', 'валиден'])) {
                return 'Действующий сертификат подтверждён. Панель переходит к добавлению сайта в Webmaster.';
            }
            return 'Проверяем действующий сертификат на публичном сайте. До успешной проверки сайт не будет добавлен в Webmaster.';
        }
        // DNS propagated / resume (§14.4) — раньше issuance: строка содержит 'resume'.
        if ($has(['dns пропагирован', 'resume вызван', 'dns уже обновил', 'resume вызван — le'])) {
            return 'DNS уже обновился. Выпуск сертификата продолжен.';
        }
        // SSL выпуск (§14.3)
        if ($has(['ssl issuance', 'issuance продолжается', 'сертификат выпуск', 'le выпуск', "let's encrypt выпущен", 'le начинает валидац'])) {
            if ($has(['выпущен и применён', 'issued', 'подтверждён'])) {
                return 'Сертификат выпущен и применён.';
            }
            return 'Сертификат выпускается. Панель проверит готовность автоматически.';
        }
        // Рандомизация
        if ($has(['not_applicable', 'рандомизация не использ', 'confirmed_absent', 'поддерживаемого скрипта нет'])) {
            return 'На этом сайте рандомизация классов не используется. Этап пропущен автоматически.';
        }
        if ($has(['ambiguous', 'не смогла достоверно подтвердить', 'без completion marker'])) {
            return 'Скрипт рандомизации был вызван, но панель не смогла достоверно подтвердить изменение файлов. Повторный запуск заблокирован, чтобы не выполнить операцию дважды.';
        }
        if ($has(['needs_review', 'не смогла подтвердить', 'manual_secret'])) {
            return 'Найден файл рандомизации, но панель не смогла подтвердить, что он подходит этому сайту. Скрипт не запускался.';
        }
        // Stage started/finished (§16.6)
        if ($has(['stage started'])) return 'Этап начат: ' . self::stageLabel($stage);
        if ($has(['stage finished'])) return 'Этап завершён: ' . self::stageLabel($stage);

        // Ничего не распознали: вычищаем очевидные «сырые» токены в скобках вида
        // [code] и коды со стрелкой, оставляя основной русский текст.
        $clean = preg_replace('~^\[[a-z0-9_]+\]\s*~i', '', $m);
        $clean = preg_replace('~\b[a-z_]+=[^\s,;]+~', '', $clean);
        $clean = trim(preg_replace('~\s{2,}~', ' ', $clean));
        return $clean !== '' ? $clean : self::stageLabel($stage);
    }

    /** Человеческий интервал: секунды → «через 30 секунд» / «через 5 минут». */
    public static function humanInterval(int $sec): string
    {
        if ($sec <= 0) return 'скоро';
        if ($sec < 60) return 'через ' . $sec . ' ' . self::plural($sec, 'секунду', 'секунды', 'секунд');
        $min = (int)round($sec / 60);
        if ($min < 60) return 'через ' . $min . ' ' . self::plural($min, 'минуту', 'минуты', 'минут');
        $h = (int)round($min / 60);
        return 'через ' . $h . ' ' . self::plural($h, 'час', 'часа', 'часов');
    }

    private static function plural(int $n, string $one, string $few, string $many): string
    {
        $n = abs($n) % 100;
        $n1 = $n % 10;
        if ($n > 10 && $n < 20) return $many;
        if ($n1 > 1 && $n1 < 5) return $few;
        if ($n1 === 1) return $one;
        return $many;
    }

    /**
     * Есть ли в тексте запрещённые слова §13 (для тестов/самопроверки).
     * Сопоставление регистронезависимо и по границам, где это осмысленно.
     */
    public static function containsForbidden(string $text): array
    {
        $hits = [];
        foreach (self::FORBIDDEN_WORDS as $w) {
            if ($w === '') continue;
            if (mb_stripos($text, $w) !== false) $hits[] = $w;
        }
        return array_values(array_unique($hits));
    }
}
