<?php

/**
 * ТЗ044 §12–§14 — безопасный recovery уже испорченных джоб перевыставления.
 * Классификация без повторной покупки; concurrency-guard одного physical site.
 *
 * Классификация чистая (job + sibling-джобы того же site_id). Применение (recover) —
 * DRY RUN по умолчанию; apply только явно. domains.create в recovery ЗАПРЕЩЁН.
 */
final class JobRecoveryService
{
    const CONFIRMED_PURCHASED = 'confirmed_purchased';
    const NO_PURCHASE         = 'no_purchase';
    const AMBIGUOUS_PURCHASE  = 'ambiguous_purchase';
    const SUPERSEDED          = 'superseded';

    private const TERMINAL = ['done', 'failed', 'cancelled', 'superseded'];

    private ?\PDO $pdo;
    public function __construct(?\PDO $pdo = null) { $this->pdo = $pdo; }

    /** ТЗ044 §12.3A (BLOCKER 5) — seam live read-only инспекции. fn(array $job):array */
    public $inspectFn = null;
    /** ТЗ044 §12.3C (BLOCKER 5) — seam read-only Namecheap getInfo резолвера. fn(array $job):array */
    public $ambiguityResolverFn = null;

    /**
     * Live read-only inspection для confirmed #209: текущий config domain/sub, redirect semantic +
     * marker count, наличие alias (FastPanel) + cert (TLS), реальный локальный snapshot config.php.
     * НИКАКИХ записей на VPS/в БД (snapshot пишется ЛОКАЛЬНО в storage).
     */
    private function inspect(array $job): array
    {
        if (is_callable($this->inspectFn)) {
            try { return (array)($this->inspectFn)($job); } catch (\Throwable $e) { return ['ok' => false, 'error' => $e->getMessage()]; }
        }
        try {
            $siteId = (int)$job['site_id'];
            $newDomain = (string)($job['new_domain'] ?? '');
            $sync = new SiteConfigSyncService();
            $fetch = $sync->fetchFromVpsReadOnly($siteId);
            if (empty($fetch['ok'])) return ['ok' => false, 'reason' => 'config_read_failed', 'ftp_writes' => 0];
            $raw = (string)$fetch['raw'];
            $scan = (new StaticSiteConfigScanner())->scan($raw);
            $domain = null; $sub = $scan->isSafe() ? $scan->uniqueSubIdOrNull() : null;
            if ($scan->isSafe()) foreach ($scan->assignments() as $a) if ($a['kind'] === 'domain') $domain = $a['value'];
            [$rv, $mk] = (new RedirectToggler())->redirectVarState($raw);

            // РЕАЛЬНЫЙ локальный snapshot текущего config.php (не FTP-запись — читаем и сохраняем локально)
            $snap = ['written' => false];
            try {
                $dir = Paths::storage('recovery_snapshots');
                Paths::ensureDir($dir);
                $path = $dir . '/job_' . (int)$job['id'] . '_' . gmdate('Ymd_His') . '.php';
                file_put_contents($path, $raw);
                $snap = ['written' => true, 'path' => $path, 'sha256' => hash('sha256', $raw), 'bytes' => strlen($raw)];
            } catch (\Throwable $e) { $snap = ['written' => false, 'error' => $e->getMessage()]; }

            // read-only alias presence (FastPanel) + cert presence/status (TLS) — без записи
            $alias = $this->inspectAlias($siteId, $newDomain);
            $cert = $this->inspectCert($newDomain);

            $facts = [
                'ftp_writes' => 0,
                'config_read_ok' => true,
                'current_config_domain' => $domain, 'current_sub_id' => $sub,
                'redirect_value' => $rv, 'redirect_marker_count' => $mk,
                'redirect_read_ok' => true,
                'alias_present' => $alias['present'], 'alias_detail' => $alias,
                'cert_present' => $cert['present'], 'cert_detail' => $cert,
                'config_snapshot_sha256' => $snap['sha256'] ?? hash('sha256', $raw),
                'config_snapshot_bytes' => $snap['bytes'] ?? strlen($raw),
                'config_snapshot_path' => $snap['path'] ?? null,
                'config_snapshot_written' => (bool)($snap['written'] ?? false),
            ];
            // BLOCKER C (P0-4): fail-closed — ok только если ВСЕ обязательные prerequisites выполнены.
            return array_merge($facts, self::evaluateInspection($facts));
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage(), 'ftp_writes' => 0,
                    'blocking_reasons' => ['inspection_exception']];
        }
    }

    /**
     * Fail-closed оценка live inspection. ok=true только если: config прочитан, snapshot ФИЗИЧЕСКИ
     * записан, redirect прочитан, alias присутствует (===true), cert присутствует (===true).
     * null/false/error любого обязательного пункта → ok=false + список причин.
     */
    public static function evaluateInspection(array $f): array
    {
        $blocking = [];
        if (empty($f['config_read_ok'])) $blocking[] = 'config_read_failed';
        if (empty($f['config_snapshot_written'])) $blocking[] = 'snapshot_not_written';
        if (empty($f['redirect_read_ok'])) $blocking[] = 'redirect_read_failed';
        if (($f['alias_present'] ?? null) !== true) $blocking[] = 'alias_absent_or_unknown';
        if (($f['cert_present'] ?? null) !== true) $blocking[] = 'cert_absent_or_unknown';
        return ['ok' => empty($blocking), 'blocking_reasons' => $blocking];
    }

    /** read-only проверка присутствия домена как сайта/alias в FastPanel. */
    private function inspectAlias(int $siteId, string $newDomain): array
    {
        if ($newDomain === '' || $this->pdo === null) return ['present' => null, 'reason' => 'no_domain_or_db'];
        try {
            $st = $this->pdo->prepare("SELECT fastpanel_server_id FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $srv = (int)($st->fetchColumn() ?: 0);
            if ($srv <= 0) return ['present' => null, 'reason' => 'no_fp_server'];
            $res = (new FastpanelSearchService($srv))->search($newDomain, 5);
            $present = false;
            foreach ((array)$res as $r) {
                $hay = strtolower(json_encode($r));
                if (strpos($hay, strtolower($newDomain)) !== false) { $present = true; break; }
            }
            return ['present' => $present, 'matches' => count((array)$res)];
        } catch (\Throwable $e) {
            return ['present' => null, 'reason' => 'alias_check_error', 'error' => $e->getMessage()];
        }
    }

    /** read-only TLS-проверка сертификата нового домена. */
    private function inspectCert(string $newDomain): array
    {
        if ($newDomain === '') return ['present' => null, 'reason' => 'no_domain'];
        try {
            $r = (new SslLiveCheckService())->checkDomain($newDomain);
            return ['present' => !empty($r['ok']) || !empty($r['has_cert']) || !empty($r['issuer']),
                    'valid' => $r['valid'] ?? null, 'issuer' => $r['issuer'] ?? null, 'raw' => $r];
        } catch (\Throwable $e) {
            return ['present' => null, 'reason' => 'cert_check_error', 'error' => $e->getMessage()];
        }
    }

    /**
     * Production-default read-only разрешение ambiguous purchase через Namecheap domains.getInfo.
     * НИКОГДА не вызывает create. Возвращает ['ok','domain_in_account',...].
     */
    private function resolveAmbiguityDefault(array $job): array
    {
        if ($this->pdo === null) return ['ok' => false, 'reason' => 'no_db'];
        try {
            $art = self::artifacts($job);
            // кандидат: последний tried с purchase_unknown, иначе new_domain
            $candidate = (string)($job['new_domain'] ?? '');
            foreach (array_reverse((array)($art['tried'] ?? [])) as $t) {
                if (($t['result'] ?? '') === 'purchase_unknown' && !empty($t['domain'])) { $candidate = (string)$t['domain']; break; }
            }
            if ($candidate === '') return ['ok' => false, 'reason' => 'no_candidate'];

            $accId = (int)($art['namecheap_account_id'] ?? 0);
            if ($accId > 0) { $st = $this->pdo->prepare("SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'"); $st->execute([$accId]); $acc = $st->fetch(); }
            else { $acc = $this->pdo->query("SELECT * FROM registrar_accounts WHERE provider='namecheap' ORDER BY id LIMIT 1")->fetch(); }
            if (!$acc) return ['ok' => false, 'reason' => 'no_registrar_account'];

            $endpoint = (string)($art['namecheap_endpoint'] ?? ($acc['endpoint'] ?? ''));
            $client = new NamecheapClient($endpoint, (string)$acc['api_user'], Crypto::decrypt((string)$acc['api_key_enc']),
                (string)$acc['username'], (string)$acc['client_ip'], (int)config('namecheap.timeout', 30));
            $info = $client->getDomainInfo($candidate); // read-only
            // P1: используем канонический парсер вместо ad-hoc эвристики верхнего уровня.
            $r = self::classifyAmbiguityInfo($candidate, is_array($info) ? $info : null);
            return array_merge(['ok' => true, 'candidate' => $candidate, 'create_called' => false], $r);
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => 'getinfo_error', 'error' => $e->getMessage(), 'create_called' => false];
        }
    }

    /** P1: контрактный разбор domains.getInfo через NamecheapPurchaseVerifier (учитывает nested DomainGetInfoResult). */
    public static function classifyAmbiguityInfo(string $candidate, ?array $info): array
    {
        $verdict = NamecheapPurchaseVerifier::classifyGetInfo($candidate, $info, null);
        return [
            'domain_in_account' => ($verdict['outcome'] === NamecheapPurchaseVerifier::OUTCOME_SUCCESS),
            'verdict' => $verdict,
            'getinfo' => $info,
        ];
    }

    private static function artifacts(array $job): array
    {
        $raw = $job['artifacts_json'] ?? null;
        if (!is_string($raw) || $raw === '') return [];
        $d = json_decode($raw, true);
        return is_array($d) ? $d : [];
    }

    /**
     * @param array $job целевая джоба
     * @param array $siblings все джобы того же site_id (включая саму), из БД
     * @return array{class:string,reasons:string[],create_domain_allowed:bool,
     *               return_stage:?string,newer_job_id:?int}
     */
    public function classify(array $job, array $siblings): array
    {
        $art = self::artifacts($job);
        $newDomain = trim((string)($job['new_domain'] ?? ''));
        $purchased = trim((string)($art['purchased_domain'] ?? ''));
        $ambiguous = !empty($art['purchase_confirmation']) && empty($art['purchase_confirmation']['resolved']);

        // C. ambiguous — незакрытый unknown create/confirmation
        if ($ambiguous) {
            return self::r(self::AMBIGUOUS_PURCHASE, ['unresolved_purchase_confirmation'], false, null, null);
        }

        // A. confirmed_purchased (#209): куплен и совпадает с new_domain
        if ($newDomain !== '' && $purchased !== '' && $this->bare($purchased) === $this->bare($newDomain)) {
            return self::r(self::CONFIRMED_PURCHASED, ['purchased_domain==new_domain'], false, 'analyze_site', null);
        }

        // B. no_purchase (#208): нет new_domain и нет purchased
        if ($newDomain === '' && $purchased === '') {
            // есть ли более новая authoritative job того же site_id с подтверждённой покупкой?
            $newer = $this->newerAuthoritative($job, $siblings);
            if ($newer !== null) {
                return self::r(self::SUPERSEDED, ['newer_confirmed_job_exists'], false, null, $newer);
            }
            return self::r(self::NO_PURCHASE, ['no_new_domain_no_purchase'], false, 'domain_purchasing', null);
        }

        // new_domain задан, но purchased не совпадает/пуст — неоднозначно, только read-only
        return self::r(self::AMBIGUOUS_PURCHASE, ['new_domain_without_matching_purchase'], false, null, null);
    }

    /** Более новая (id больше) НЕтерминальная-или-успешная джоба того же site с подтверждённой покупкой. */
    private function newerAuthoritative(array $job, array $siblings): ?int
    {
        $jid = (int)$job['id']; $siteId = (int)$job['site_id'];
        $best = null;
        foreach ($siblings as $s) {
            if ((int)$s['site_id'] !== $siteId) continue;
            if ((int)$s['id'] <= $jid) continue;
            $a = self::artifacts($s);
            $nd = trim((string)($s['new_domain'] ?? ''));
            $pd = trim((string)($a['purchased_domain'] ?? ''));
            if ($nd !== '' && $pd !== '' && $this->bare($nd) === $this->bare($pd)) {
                $best = max((int)$best, (int)$s['id']);
            }
        }
        return $best ?: null;
    }

    /**
     * ТЗ044 §14 — вернуть id второй АКТИВНОЙ mutation-джобы того же site (или null).
     * Активная = нетерминальная. Наличие такой при recovery/создании — конфликт.
     */
    public function concurrencyConflict(array $job, array $siblings): ?int
    {
        $jid = (int)$job['id']; $siteId = (int)$job['site_id'];
        foreach ($siblings as $s) {
            if ((int)$s['id'] === $jid) continue;
            if ((int)$s['site_id'] !== $siteId) continue;
            if (!in_array((string)$s['stage'], self::TERMINAL, true)) return (int)$s['id'];
        }
        return null;
    }

    /**
     * Recovery-план (DRY RUN если !$apply). НИКОГДА не вызывает domains.create.
     * @return array сводка действий + признак применения.
     */
    public function recover(array $job, array $siblings, bool $apply = false): array
    {
        $cls = $this->classify($job, $siblings);
        $jobId = (int)$job['id'];
        $out = [
            'job_id' => $jobId, 'site_id' => (int)$job['site_id'],
            'class' => $cls['class'], 'reasons' => $cls['reasons'],
            'create_domain_allowed' => false,          // recovery НИКОГДА не покупает
            'dry_run' => !$apply, 'applied' => false,
            'return_stage' => $cls['return_stage'], 'newer_job_id' => $cls['newer_job_id'],
        ];

        // блокировки
        if ($cls['class'] === self::SUPERSEDED) {
            $out['blocked'] = true; $out['block_reason'] = 'superseded_by_newer_job';
            return $out;
        }
        if ($cls['class'] === self::AMBIGUOUS_PURCHASE) {
            $out['blocked'] = true; $out['block_reason'] = 'ambiguous_purchase_readonly_only';
            // ТЗ §12.3C: read-only getInfo (create запрещён). seam для тестов, иначе production-default.
            try {
                $out['ambiguity_readonly_getinfo'] = is_callable($this->ambiguityResolverFn)
                    ? (array)($this->ambiguityResolverFn)($job)
                    : $this->resolveAmbiguityDefault($job);
            } catch (\Throwable $e) {
                $out['ambiguity_readonly_getinfo'] = ['ok' => false, 'error' => $e->getMessage()];
            }
            return $out;
        }
        $conflict = $this->concurrencyConflict($job, $siblings);
        if ($conflict !== null) {
            $out['blocked'] = true; $out['block_reason'] = 'concurrent_active_job'; $out['conflict_job_id'] = $conflict;
            return $out;
        }

        // confirmed_purchased → live read-only inspection + snapshot, затем возврат на analyze_site
        $out['actions'] = [];
        if ($cls['class'] === self::CONFIRMED_PURCHASED) {
            $out['live_inspection'] = $this->inspect($job); // read-only, ftp_writes=0
            $out['actions'] = ['live_readonly_inspection', 'config_snapshot', 'clear_downstream_stale_artifacts',
                               'return_analyze_site_pending', 'no_domains_create'];
            // BLOCKER C: не можем прочитать/зафиксировать live state → APPLY запрещён (fail-closed).
            if (empty($out['live_inspection']['ok'])) {
                $out['blocked'] = true;
                $out['block_reason'] = 'live_inspection_failed';
                return $out;
            }
        } elseif ($cls['class'] === self::NO_PURCHASE) {
            $out['actions'] = ['restart_domain_purchasing_pending'];
        }

        if ($apply && $this->pdo !== null && $cls['return_stage'] !== null) {
            // P0-3: серверная eligibility — apply только для failed/awaiting_user.
            $curStatus0 = (string)($job['stage_status'] ?? '');
            if (!in_array($curStatus0, ['failed', 'awaiting_user'], true)) {
                $out['blocked'] = true; $out['block_reason'] = 'not_eligible_status';
                $out['current_status'] = $curStatus0;
                return $out;
            }
            // P0-2: транзакция + SELECT ... FOR UPDATE re-read + CAS по исходному stage/stage_status.
            $inTx = false;
            try {
                $this->pdo->beginTransaction(); $inTx = true;
                $sel = $this->pdo->prepare(
                    "SELECT stage, stage_status, artifacts_json FROM refresh_jobs WHERE id = ? FOR UPDATE");
                $sel->execute([$jobId]);
                $cur = $sel->fetch();
                if (!$cur) { $this->pdo->rollBack(); $out['blocked'] = true; $out['block_reason'] = 'job_not_found'; return $out; }
                // состояние не должно было измениться между чтением job и apply
                if ((string)$cur['stage'] !== (string)$job['stage'] || (string)$cur['stage_status'] !== (string)$job['stage_status']) {
                    $this->pdo->rollBack(); $out['blocked'] = true; $out['block_reason'] = 'state_changed_concurrently';
                    $out['observed'] = ['stage' => $cur['stage'], 'stage_status' => $cur['stage_status']];
                    return $out;
                }
                if (!in_array((string)$cur['stage_status'], ['failed', 'awaiting_user'], true)) {
                    $this->pdo->rollBack(); $out['blocked'] = true; $out['block_reason'] = 'not_eligible_status'; return $out;
                }
                $art = json_decode((string)$cur['artifacts_json'], true) ?: [];
                foreach (['replacement_plan', 'config_replaced_stage', 'verify_stage'] as $k) unset($art[$k]);
                $art['recovery'] = ['class' => $cls['class'], 'recovered_at' => gmdate('c'), 'return_stage' => $cls['return_stage']];
                // CAS: обновляем ТОЛЬКО если stage/stage_status всё ещё совпадают.
                $upd = $this->pdo->prepare(
                    "UPDATE refresh_jobs
                        SET stage=?, stage_status='pending', stage_error=NULL, next_run_at=NULL, artifacts_json=?
                      WHERE id=? AND stage=? AND stage_status=?");
                $upd->execute([$cls['return_stage'],
                    json_encode($art, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $jobId, (string)$cur['stage'], (string)$cur['stage_status']]);
                if ($upd->rowCount() !== 1) {
                    $this->pdo->rollBack(); $out['blocked'] = true; $out['block_reason'] = 'cas_update_failed'; return $out;
                }
                $this->pdo->commit(); $inTx = false;
                $out['applied'] = true;
            } catch (\Throwable $e) {
                if ($inTx && $this->pdo->inTransaction()) { try { $this->pdo->rollBack(); } catch (\Throwable $e2) {} }
                $out['blocked'] = true; $out['block_reason'] = 'apply_exception'; $out['error'] = $e->getMessage();
                return $out;
            }
        }
        return $out;
    }

    private function bare(string $d): string
    {
        $d = strtolower(trim($d));
        $d = preg_replace('~^https?://~', '', $d);
        $d = preg_replace('~^www\.~', '', (string)$d);
        return explode('/', (string)$d)[0];
    }

    private static function r(string $class, array $reasons, bool $create, ?string $stage, ?int $newer): array
    {
        return ['class' => $class, 'reasons' => $reasons, 'create_domain_allowed' => $create,
                'return_stage' => $stage, 'newer_job_id' => $newer];
    }
}
