<?php

/**
 * v18-fix: BackupFileCleaner
 *
 * Подчищает старые .bak файлы которые в прошлом создавала панель
 * (до v18-fix когда мы выключили автоматическое создание .bak в applier'ах).
 *
 * Удаляет файлы которые ОДНОВРЕМЕННО:
 *   1. Имеют расширение в одном из паттернов:
 *      - *.bak.refresh-panel_YYYYMMDD_HHMMSS  (от ReplacementApplier)
 *      - *.bak_YYYYMMDD_HHMMSS               (от FtpService::putContent default)
 *      - *.before-disable.txt                 (старый формат)
 *   2. Старше 7 дней (mtime < now - 7d)
 *
 * НЕ трогает:
 *   - Любые другие файлы (.bak без timestamp, .backup, и т.д. — могли создать руками)
 *   - .bak файлы моложе 7 дней (вдруг свежий бэкап нужен оператору)
 *
 * Использование:
 *   $cleaner = new BackupFileCleaner($ftp, $log);
 *   $cleaner->cleanup($basePath, 7);
 */
class BackupFileCleaner
{
    /** Возраст в днях после которого .bak файлы считаются устаревшими */
    private const DEFAULT_MAX_AGE_DAYS = 7;

    /**
     * Регексы имён файлов которые мы создавали в прошлом и теперь хотим подчищать.
     * Все они содержат timestamp в названии — значит точно от автоматики.
     */
    private const CLEANUP_PATTERNS = [
        // Создавал ReplacementApplier::applyPlan() (до v18-fix):
        // "config.php.bak.refresh-panel_20260507_123456"
        '~\.bak\.refresh-panel_\d{8}_\d{6}$~',

        // Создавал FtpService::putContent() с default '.bak' (до v18-fix):
        // ".htaccess.bak_20260508_113900"
        '~\.bak_\d{8}_\d{6}$~',

        // Старый формат от RedirectToggler (до полной переработки):
        // "config.php.before-disable.txt", ".htaccess.before-disable.txt"
        '~\.before-disable\.txt$~',
    ];

    private FtpService $ftp;
    private JobEventLogger $log;

    public function __construct(FtpService $ftp, JobEventLogger $log)
    {
        $this->ftp = $ftp;
        $this->log = $log;
    }

    /**
     * Подчистить старые .bak файлы в указанной директории.
     *
     * @param string $basePath FTP-путь к корню сайта (от текущего FTP cwd).
     *                          Передавайте '' если FTP-юзер чрутнут в сайт.
     * @param int $maxAgeDays Удалять файлы старше N дней (default 7).
     *
     * @return array {
     *     ok: bool,
     *     scanned: int,        // сколько файлов в директории
     *     candidates: int,     // сколько подходит под паттерн .bak
     *     deleted: int,        // сколько реально удалено
     *     deleted_names: string[],
     *     skipped_recent: int, // моложе maxAgeDays — не трогали
     *     skipped_no_mtime: int, // не смогли определить дату — пропустили
     *     errors: string[],
     * }
     */
    public function cleanup(string $basePath = '', int $maxAgeDays = self::DEFAULT_MAX_AGE_DAYS): array
    {
        $result = [
            'ok' => false,
            'scanned' => 0,
            'candidates' => 0,
            'deleted' => 0,
            'deleted_names' => [],
            'skipped_recent' => 0,
            'skipped_no_mtime' => 0,
            'errors' => [],
        ];

        $listPath = $basePath !== '' ? $basePath : '.';
        try {
            $entries = $this->ftp->listDirEntries($listPath);
        } catch (\Throwable $e) {
            $result['errors'][] = 'listDir failed: ' . $e->getMessage();
            $this->log->warn('analyze_site',
                'BackupFileCleaner: не удалось получить список файлов: ' . $e->getMessage());
            return $result;
        }

        $result['scanned'] = count($entries);
        $thresholdTs = time() - ($maxAgeDays * 86400);

        foreach ($entries as $entry) {
            if (($entry['type'] ?? 'file') !== 'file') continue;
            $name = (string)($entry['name'] ?? '');
            if ($name === '') continue;

            // Проверяем что имя матчит хотя бы один из cleanup-паттернов
            $isCandidate = false;
            foreach (self::CLEANUP_PATTERNS as $pattern) {
                if (preg_match($pattern, $name)) {
                    $isCandidate = true;
                    break;
                }
            }
            if (!$isCandidate) continue;

            $result['candidates']++;

            // Проверяем возраст. Если mtime не известен — лучше не трогать
            // (может быть свежий, и мы его удалим, а оператору нужен).
            $mtime = $entry['mtime'] ?? null;
            if ($mtime === null) {
                $result['skipped_no_mtime']++;
                continue;
            }
            if ($mtime > $thresholdTs) {
                $result['skipped_recent']++;
                continue;
            }

            // Удаляем
            $remotePath = $basePath !== ''
                ? rtrim($basePath, '/') . '/' . $name
                : $name;

            $deleted = $this->ftp->deleteFile($remotePath);
            if ($deleted) {
                $result['deleted']++;
                $result['deleted_names'][] = $name;
            } else {
                $result['errors'][] = "Не удалось удалить: {$name}";
            }
        }

        $result['ok'] = empty($result['errors']);

        // Лог сводки
        if ($result['candidates'] === 0) {
            $this->log->info('analyze_site',
                "BackupFileCleaner: старых .bak файлов не найдено (просканировано {$result['scanned']} файлов)");
        } else {
            $deletedSummary = $result['deleted'] > 0
                ? '. Удалено: ' . implode(', ', array_slice($result['deleted_names'], 0, 5))
                  . (count($result['deleted_names']) > 5 ? '... (+' . (count($result['deleted_names']) - 5) . ')' : '')
                : '';
            $this->log->info('analyze_site', sprintf(
                "BackupFileCleaner: найдено .bak-кандидатов %d, удалено %d (старше %d дней), " .
                "оставлено свежих %d, без даты %d%s",
                $result['candidates'], $result['deleted'], $maxAgeDays,
                $result['skipped_recent'], $result['skipped_no_mtime'],
                $deletedSummary
            ));
        }

        return $result;
    }
}
