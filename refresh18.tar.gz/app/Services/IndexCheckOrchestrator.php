<?php

require_once __DIR__ . '/IndexCheck/IndexCheckMethod.php';
require_once __DIR__ . '/IndexCheck/XmlStockIndexCheck.php';
require_once __DIR__ . '/IndexCheck/WebmasterIndexCheckMethods.php';
require_once __DIR__ . '/IndexCheck/XmlStockRequestContext.php';
require_once __DIR__ . '/IndexCheck/XmlStockUsageRepository.php';
require_once __DIR__ . '/IndexCheck/XmlStockRequestService.php';
require_once __DIR__ . '/BanMonitoring/BanMonitoringPolicy.php';
require_once __DIR__ . '/BanMonitoring/BanMonitorDecision.php';

/**
 * Координатор проверки индексации.
 *
 * Запускает методы по приоритету:
 *   1. xmlstock (если включён) — основной, самый быстрый
 *   2. webmaster_summary       — fallback, getHostSummary
 *   3. webmaster_history       — fallback, getInSearchHistory
 *   4. webmaster_samples       — fallback, getInSearchSamples
 *   5. webmaster_events        — fallback, getSearchEventSamples
 *
 * Поведение:
 *   - Если основной метод (xmlstock) включён — используем ТОЛЬКО его
 *     (чтобы не тратить лимиты Webmaster API когда есть платный)
 *   - Если xmlstock недоступен — пробегаем по Webmaster fallback'ам в порядке.
 *     Останавливаемся на первом методе который вернул indexed=true ИЛИ
 *     ok=true (если ни один не нашёл — значит правда не в индексе).
 */
class IndexCheckOrchestrator
{
    /**
     * Главная проверка.
     *
     * @return array {
     *   indexed: bool,
     *   pages_indexed: int,
     *   primary_method: string,    // имя метода которым определили indexed=true
     *   methods_tried: array,      // список всех попыток с результатами
     *   message: string,
     * }
     */
    public function checkIndexed(
        int $accountId,
        string $hostUrl,
        string $userId,
        string $hostId,
        JobEventLogger $log,
        ?int $jobId = null,
        ?int $siteId = null,
        string $purpose = 'index_watching'
    ): array {
        $methodsTried = [];
        $methods = $this->buildMethods($accountId);

        // Проверяем — есть ли xmlstock в активных методах
        $hasXmlstock = false;
        foreach ($methods as $m) {
            if ($m->getName() === 'xmlstock' && $m->isAvailable()) {
                $hasXmlstock = true;
                break;
            }
        }

        foreach ($methods as $method) {
            $name = $method->getName();
            if (!$method->isAvailable()) {
                $methodsTried[] = [
                    'method' => $name,
                    'available' => false,
                    'skipped' => 'not_configured',
                ];
                continue;
            }

            // Если xmlstock включён — используем ТОЛЬКО его, не идём в Webmaster fallback'и
            if ($hasXmlstock && $name !== 'xmlstock') {
                $methodsTried[] = [
                    'method' => $name,
                    'available' => true,
                    'skipped' => 'xmlstock_active',
                ];
                continue;
            }

            $log->info('index_watching', "Проверяю через {$name}...");
            if ($name === 'xmlstock') {
                // §12: XMLStock ТОЛЬКО через central service (reserve-before-HTTP, exactly-once).
                $dom = explode('/', preg_replace('~^https?://~', '', (string)$hostUrl))[0];
                $execPurpose = in_array($purpose, XmlStockRequestContext::PURPOSES, true) ? $purpose : 'index_watching';
                $exec = (new XmlStockRequestService())->execute(
                    new XmlStockRequestContext($execPurpose, $dom, $jobId, $siteId, null, null, null, 'cron'));
                if (!empty($exec['ok']) || !empty($exec['replayed'])) {
                    $result = (array)($exec['result'] ?? []);
                } else {
                    // fail-closed (§12.4): ledger недоступен → технический результат без fabricated indexed.
                    $result = ['ok' => false, 'indexed' => false, 'pages_indexed' => 0, 'method' => 'xmlstock',
                               'error' => (string)($exec['error'] ?? 'usage_unavailable'), 'message' => 'xmlstock ledger unavailable'];
                }
            } else {
                $result = $method->checkIndexed($hostUrl, $userId, $hostId);
            }

            $methodsTried[] = [
                'method' => $name,
                'available' => true,
                'ok' => $result['ok'] ?? false,
                'indexed' => $result['indexed'] ?? false,
                'pages_indexed' => $result['pages_indexed'] ?? 0,
                'message' => $result['message'] ?? '',
                'error' => $result['error'] ?? null,
            ];

            // Метод нашёл indexed=true → СТОП
            if (!empty($result['ok']) && !empty($result['indexed'])) {
                $pages = (int)($result['pages_indexed'] ?? 0);
                $log->ok('index_watching',
                    "✓ {$name}: indexed=true, pages={$pages}. " . ($result['message'] ?? ''));
                return [
                    'indexed' => true,
                    'pages_indexed' => $pages,
                    'primary_method' => $name,
                    'methods_tried' => $methodsTried,
                    'message' => $result['message'] ?? "Indexed via {$name}",
                ];
            }

            // Метод сработал но indexed=false — это ВАЛИДНЫЙ negative answer для основного.
            // Если это xmlstock и он отработал — больше ничего не пробуем (доверяем ему).
            if ($name === 'xmlstock' && !empty($result['ok'])) {
                $log->info('index_watching',
                    "xmlstock: not indexed yet. " . ($result['message'] ?? ''));
                return [
                    'indexed' => false,
                    'pages_indexed' => 0,
                    'primary_method' => $name,
                    'methods_tried' => $methodsTried,
                    'message' => $result['message'] ?? 'Not indexed (xmlstock)',
                ];
            }

            // Метод упал → продолжаем по fallback цепочке
            if (empty($result['ok'])) {
                $log->info('index_watching',
                    "  ✗ {$name}: " . ($result['message'] ?? 'failed'));
                continue;
            }

            // Webmaster метод сработал, indexed=false — продолжаем перебор
            // (потому что разные методы могут показать разное)
            $log->info('index_watching',
                "  · {$name}: not indexed (но метод отработал)");
        }

        // Ни один метод не нашёл индекс
        return [
            'indexed' => false,
            'pages_indexed' => 0,
            'primary_method' => '',
            'methods_tried' => $methodsTried,
            'message' => 'Ни один метод не подтвердил indexed=true',
        ];
    }

    /**
     * Собирает список методов в правильном приоритете.
     * Сюда же добавлять новые методы — они подхватятся автоматически.
     */
    private function buildMethods(int $accountId): array
    {
        return [
            new XmlStockIndexCheck(),                               // priority 1
            new WebmasterSummaryIndexCheck($accountId),             // priority 2
            new WebmasterHistoryIndexCheck($accountId),             // priority 3
            new WebmasterSamplesIndexCheck($accountId),             // priority 4
            new WebmasterEventsIndexCheck($accountId),              // priority 5
        ];
    }
}
