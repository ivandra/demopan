<?php

/**
 * Простой FTP клиент для чтения/записи файлов на VPS.
 * Использует встроенные ftp_* функции PHP.
 */
class FtpService
{
    private $conn = null;
    private string $host;
    private int $port;
    private string $user;
    private string $pass;
    private bool $passive;
    private int $timeout;
    private bool $useFtps;

    public function __construct(string $host, string $user, string $pass, array $opts = [])
    {
        $this->host = $host;
        $this->port = (int)($opts['port'] ?? 21);
        $this->user = $user;
        $this->pass = $pass;
        $this->passive = (bool)($opts['passive'] ?? true);
        $this->timeout = (int)($opts['timeout'] ?? 30);
        $this->useFtps = (bool)($opts['ftps'] ?? false);
    }

    public function connect(): void
    {
        if ($this->conn) return;

        $conn = $this->useFtps
            ? @ftp_ssl_connect($this->host, $this->port, $this->timeout)
            : @ftp_connect($this->host, $this->port, $this->timeout);

        if (!$conn) {
            throw new RuntimeException("FTP connect failed: {$this->host}:{$this->port}");
        }

        if (!@ftp_login($conn, $this->user, $this->pass)) {
            @ftp_close($conn);
            throw new RuntimeException("FTP login failed for user {$this->user}");
        }

        @ftp_pasv($conn, $this->passive);
        $this->conn = $conn;
    }

    public function disconnect(): void
    {
        if ($this->conn) {
            @ftp_close($this->conn);
            $this->conn = null;
        }
    }

    /**
     * Получить содержимое файла по пути на FTP.
     */
    public function getContent(string $remotePath): string
    {
        $this->connect();

        $tmp = tmpfile();
        if (!$tmp) throw new RuntimeException('cannot create tmp file');
        $tmpPath = stream_get_meta_data($tmp)['uri'];

        if (!@ftp_get($this->conn, $tmpPath, $remotePath, FTP_BINARY)) {
            @fclose($tmp);
            throw new RuntimeException("FTP get failed: {$remotePath}");
        }

        $content = file_get_contents($tmpPath);
        @fclose($tmp);
        return $content === false ? '' : $content;
    }

    /**
     * v18-fix: попробовать прочитать файл, вернуть null при ошибке (без исключения).
     *
     * Используется в SiteConfigSyncService для перебора кандидатов-путей —
     * если файла нет по одному пути, пробуем следующий, без exception.
     *
     * Этот метод вызывается из SiteConfigSyncService:
     *   $r = $ftp->tryGetContent($p);
     *   if ($r !== null && $r !== '') {
     *      // нашли
     *   }
     */
    public function tryGetContent(string $remotePath): ?string
    {
        try {
            $this->connect();
        } catch (Throwable $e) {
            return null;
        }

        $tmp = tmpfile();
        if (!$tmp) return null;
        $tmpPath = stream_get_meta_data($tmp)['uri'];

        // suppress warnings — это by design, неудача = вернём null
        $ok = @ftp_get($this->conn, $tmpPath, $remotePath, FTP_BINARY);
        if (!$ok) {
            @fclose($tmp);
            return null;
        }

        $content = file_get_contents($tmpPath);
        @fclose($tmp);
        return $content === false ? null : $content;
    }

    /**
     * v18-fix: получить текущую рабочую директорию FTP-юзера.
     *
     * Обёртка над ftp_pwd(). Используется в SiteConfigSyncService для
     * диагностики — чтобы понять в каком каталоге оказался FTP-юзер
     * после chroot (FastPanel при создании FTP-аккаунта c home_dir
     * делает chroot, и абсолютные пути не работают).
     *
     * Возвращает '/' для chroot'нутых FastPanel-юзеров, или
     * полный путь типа '/var/www/owner/data/www/domain.tld' если
     * chroot не настроен.
     *
     * Этот метод вызывается из SiteConfigSyncService:
     *   $pwd = $ftp->pwd();
     */
    public function pwd(): string
    {
        $this->connect();
        $result = @ftp_pwd($this->conn);
        if ($result === false) {
            throw new RuntimeException('ftp_pwd failed');
        }
        return (string)$result;
    }

    /**
     * Записать содержимое в файл (с резервной копией оригинала, если backupExt задан).
     */
    public function putContent(string $remotePath, string $content, ?string $backupExt = '.bak'): void
    {
        $this->connect();

        // backup
        if ($backupExt !== null && $this->fileExists($remotePath)) {
            $bakPath = $remotePath . $backupExt . '_' . date('Ymd_His');
            try { @ftp_rename($this->conn, $remotePath, $bakPath); } catch (Throwable $e) {
                // try copy by rename + restore — but rename удаляет оригинал.
                // Альтернатива: скачать → загрузить как .bak → перезаписать.
                $orig = $this->getContent($remotePath);
                $this->putRaw($bakPath, $orig);
            }
        }

        $this->putRaw($remotePath, $content);
    }

    private function putRaw(string $remotePath, string $content): void
    {
        $tmp = tmpfile();
        if (!$tmp) throw new RuntimeException('tmp file');
        $tmpPath = stream_get_meta_data($tmp)['uri'];
        file_put_contents($tmpPath, $content);

        if (!@ftp_put($this->conn, $remotePath, $tmpPath, FTP_BINARY)) {
            @fclose($tmp);
            throw new RuntimeException("FTP put failed: {$remotePath}");
        }
        @fclose($tmp);
    }

    public function fileExists(string $remotePath): bool
    {
        $this->connect();
        $size = @ftp_size($this->conn, $remotePath);
        return $size !== -1 && $size !== false;
    }

    public function listDir(string $remotePath): array
    {
        $this->connect();
        $list = @ftp_nlist($this->conn, $remotePath);
        return is_array($list) ? $list : [];
    }

    /**
     * Возвращает сырой ftp_rawlist — массив строк в Unix `ls -l` формате.
     * Например: "-rw-r--r--    1 user  group  1234 Jan 15 10:30 config.php"
     * Это надёжнее ftp_nlist потому что показывает тип (file/dir/link).
     */
    public function listDirRaw(string $remotePath): array
    {
        $this->connect();
        $list = @ftp_rawlist($this->conn, $remotePath);
        return is_array($list) ? $list : [];
    }

    /**
     * Парсит ftp_rawlist в массив ассоциативных entries:
     *   [
     *     ['name' => 'config.php', 'type' => 'file', 'size' => 1234, 'mtime' => 1730000000],
     *     ['name' => 'img',        'type' => 'dir',  'size' => 4096, 'mtime' => null],
     *     ['name' => '.htaccess',  'type' => 'file', 'size' => 567,  'mtime' => 1730000000],
     *     ...
     *   ]
     *
     * v18-fix: добавлено поле mtime (unix timestamp). Может быть null если
     * парсинг даты не удался. Используется для cleanup'а старых .bak файлов.
     *
     * Поддерживает Unix-формат `ls -l`. Windows-формат (rare) не поддерживается.
     * Если парсинг не удался для строки — она пропускается (не падаем).
     */
    public function listDirEntries(string $remotePath): array
    {
        $rawList = $this->listDirRaw($remotePath);
        $out = [];

        foreach ($rawList as $line) {
            if (!is_string($line) || trim($line) === '') continue;
            // Skip "total NNN" header
            if (preg_match('~^total\s+\d+~i', $line)) continue;

            // Unix format: "drwxr-xr-x   2 owner group   4096 Jan 15 10:30 dirname"
            // или         "-rw-r--r--   1 owner group   1234 Jan 15 10:30 file.php"
            // или         "-rw-r--r--   1 owner group   1234 Jan 15  2025 file.php"   (старый файл)
            // или (link)  "lrwxrwxrwx   1 owner group     12 Jan 15 10:30 link -> target"
            //
            // Регексп: первый символ — тип (d/-/l), потом 9 символов прав, потом
            // пробелы, потом дальше всё разбираем по пробелам.

            $mtime = null;

            if (preg_match('~^([d\-l])([rwxsStT\-]{9}\+?)\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+)$~', $line, $m)) {
                $typeChar = $m[1];
                $size = (int)$m[3];
                $month = $m[4];   // Jan / Feb / ...
                $day = $m[5];     // 15
                $yearOrTime = $m[6]; // 10:30 или 2025
                $name = $m[7];
                $mtime = $this->parseUnixLsDate($month, $day, $yearOrTime);
            } elseif (preg_match('~^([d\-l])\S+\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.+)$~', $line, $m)) {
                $typeChar = $m[1];
                $size = (int)$m[2];
                $isoDate = $m[3];      // 2025-01-15
                $isoTime = $m[4];      // 10:30
                $name = $m[5];
                $ts = strtotime("{$isoDate} {$isoTime}");
                $mtime = $ts !== false ? $ts : null;
            } else {
                continue;
            }

            // Если это симлинк — отрезаем " -> target"
            if ($typeChar === 'l' && strpos($name, ' -> ') !== false) {
                $name = substr($name, 0, strpos($name, ' -> '));
            }

            $name = trim($name);
            if ($name === '' || $name === '.' || $name === '..') continue;

            $type = match ($typeChar) {
                'd' => 'dir',
                'l' => 'link',
                default => 'file',
            };

            $out[] = [
                'name' => $name,
                'type' => $type,
                'size' => $size,
                'mtime' => $mtime,
                'raw' => $line,
            ];
        }

        return $out;
    }

    /**
     * ТЗ 039 §4.2: СТРОГИЙ трёхсостояниевый листинг каталога.
     *
     * Возвращает типизированный контракт, позволяющий отличить реально пустой
     * каталог (ok=true, names=[]) от сбоя/неполного разбора (ok=false). Именно
     * на нём инспектор рандомизации принимает решение confirmed_absent —
     * пустой НЕавторитетный массив к этому решению не приводит.
     *
     * @return array{ok:bool, names:array<int,string>, source:string,
     *               raw_count:int, parsed_count:int, errors:array<int,string>}
     */
    public function listDirStrict(string $remotePath): array
    {
        $result = [
            'ok' => false, 'names' => [], 'source' => 'none',
            'raw_count' => 0, 'parsed_count' => 0, 'errors' => [],
        ];
        try {
            $this->connect();
        } catch (\Throwable $e) {
            $result['errors'][] = 'connect_failed: ' . $e->getMessage();
            return $result;
        }

        // 1) rawlist
        $raw = @ftp_rawlist($this->conn, $remotePath);
        $rawNames = null; $rawCount = 0; $parsedCount = 0;
        if ($raw === false) {
            $result['errors'][] = 'rawlist_returned_false';
        } elseif (is_array($raw)) {
            $rawNames = [];
            foreach ($raw as $line) {
                if (!is_string($line) || trim($line) === '') continue;
                // §4.2 п.2: исключить служебные строки "total N".
                if (preg_match('~^total\s+\d+~i', $line)) continue;
                $rawCount++;
                $name = $this->parseListLineName($line);
                if ($name !== null && $name !== '' && $name !== '.' && $name !== '..') {
                    $rawNames[] = $name; $parsedCount++;
                }
            }
            $result['raw_count'] = $rawCount;
            $result['parsed_count'] = $parsedCount;
        } else {
            $result['errors'][] = 'rawlist_unexpected_type';
        }

        // §4.2 п.5: rawlist=false / пусто по неизвестной причине / parsed<raw → nlist.
        $needNlist = ($raw === false)
            || ($rawNames === null)
            || ($parsedCount < $rawCount);
        // Также подстрахуемся nlist при rawlist=[] (может быть и пусто, и сбой).
        if (is_array($rawNames) && $rawCount === 0) $needNlist = true;

        if (!$needNlist && is_array($rawNames)) {
            $result['ok'] = true;
            $result['names'] = array_values(array_unique($rawNames));
            $result['source'] = 'rawlist';
            return $result;
        }

        // 2) nlist как авторитетный источник
        $nlist = @ftp_nlist($this->conn, $remotePath);
        if ($nlist === false) {
            $result['errors'][] = 'nlist_returned_false';
            // rawlist мог быть частично успешен, но неполон → всё равно НЕ авторитетно.
            $result['ok'] = false;
            $result['source'] = is_array($rawNames) ? 'rawlist' : 'none';
            return $result;
        }
        if (!is_array($nlist)) {
            $result['errors'][] = 'nlist_unexpected_type';
            $result['ok'] = false;
            return $result;
        }
        // §4.2 п.6/п.8: nlist успешно выполнен → авторитетный список
        // (в т.ч. авторитетно ПУСТОЙ — это отличимо от false).
        $names = [];
        foreach ($nlist as $p) {
            $b = basename((string)$p);
            if ($b === '' || $b === '.' || $b === '..') continue;
            $names[] = $b;
        }
        $result['ok'] = true;
        $result['names'] = array_values(array_unique($names));
        $result['source'] = is_array($rawNames) && $parsedCount > 0 ? 'rawlist+nlist' : 'nlist';
        return $result;
    }

    /** Извлечь имя файла из одной строки LIST (Unix / Windows / нестандарт). */
    private function parseListLineName(string $line): ?string
    {
        // Unix ls -l: права + ... + имя в конце (недавний файл, есть время)
        if (preg_match('~^([d\-l])[rwxsStT\-]{9}\+?\s+\d+\s+\S+\s+\S+\s+\d+\s+\S+\s+\S+\s+\S+\s+(.+)$~', $line, $m)) {
            $name = $m[2];
            if ($m[1] === 'l' && strpos($name, ' -> ') !== false) $name = substr($name, 0, strpos($name, ' -> '));
            return trim($name);
        }
        // Unix ISO вариант (rare): "... 2025-01-15 10:30 name"
        if (preg_match('~^([d\-l])\S+\s+\d+\s+\S+\s+\S+\s+\d+\s+\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}\s+(.+)$~', $line, $m)) {
            $name = $m[2];
            if ($m[1] === 'l' && strpos($name, ' -> ') !== false) $name = substr($name, 0, strpos($name, ' -> '));
            return trim($name);
        }
        // Windows/IIS: "01-15-25  10:30AM       <DIR>          name"  или "... 1234 name"
        if (preg_match('~^\d{2}-\d{2}-\d{2,4}\s+\d{2}:\d{2}(?:AM|PM)?\s+(?:<DIR>|\d+)\s+(.+)$~i', $line, $m)) {
            return trim($m[1]);
        }
        // Нестандарт: если строка — просто имя без метаданных (некоторые серверы).
        $t = trim($line);
        if ($t !== '' && strpos($t, ' ') === false && strpos($t, '/') === false) {
            return $t;
        }
        return null;
    }

    /**
     * v18-fix: распарсить дату из формата Unix `ls -l`.
     *
     * Возвращает unix timestamp или null если не распарсили.
     */
    private function parseUnixLsDate(string $month, string $day, string $yearOrTime): ?int
    {
        $months = [
            'Jan'=>1, 'Feb'=>2, 'Mar'=>3, 'Apr'=>4, 'May'=>5, 'Jun'=>6,
            'Jul'=>7, 'Aug'=>8, 'Sep'=>9, 'Oct'=>10, 'Nov'=>11, 'Dec'=>12,
        ];
        $monthNum = $months[$month] ?? null;
        if ($monthNum === null) return null;
        $dayInt = (int)$day;
        if ($dayInt < 1 || $dayInt > 31) return null;

        if (preg_match('~^(\d{1,2}):(\d{2})$~', $yearOrTime, $tm)) {
            // recent file: time HH:MM, год = текущий или предыдущий
            $hour = (int)$tm[1];
            $min = (int)$tm[2];
            $currentYear = (int)date('Y');
            $currentMonth = (int)date('n');
            // Если этот месяц еще не наступил в текущем году — файл из прошлого года
            $year = ($monthNum > $currentMonth) ? ($currentYear - 1) : $currentYear;
            $ts = mktime($hour, $min, 0, $monthNum, $dayInt, $year);
            return $ts !== false ? $ts : null;
        }

        if (preg_match('~^\d{4}$~', $yearOrTime)) {
            // old file: year YYYY, время не известно — берём полдень
            $ts = mktime(12, 0, 0, $monthNum, $dayInt, (int)$yearOrTime);
            return $ts !== false ? $ts : null;
        }

        return null;
    }

    /**
     * v18-fix: удалить файл на FTP. Возвращает true при успехе, false при ошибке.
     * Не бросает исключений — для batch-операций (cleanup .bak файлов).
     */
    public function deleteFile(string $remotePath): bool
    {
        try {
            $this->connect();
        } catch (\Throwable $e) {
            return false;
        }
        return @ftp_delete($this->conn, $remotePath);
    }

    public function __destruct()
    {
        $this->disconnect();
    }
}
