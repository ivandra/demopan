<?php

/**
 * BanMonitoringPolicy — immutable снимок схемы мониторинга. Каждый monitor хранит
 * свой snapshot; production-логика (state machine, cron, UI, Telegram, оценки)
 * читает ТОЛЬКО его, а не глобальные константы. Никаких hardcoded 12/30/10/3/6.
 */
final class BanMonitoringPolicy
{
    public const FIELDS = [
        'initial_delay_minutes', 'regular_interval_minutes', 'probable_negative_count',
        'confirm_interval_minutes', 'insurance_negative_count', 'insurance_interval_minutes',
        'technical_error_retry_minutes', 'telegram_retry_minutes', 'telegram_max_attempts',
    ];

    private array $p;

    public function __construct(array $snapshot)
    {
        $d = [
            'initial_delay_minutes' => 720, 'regular_interval_minutes' => 30,
            'probable_negative_count' => 3, 'confirm_interval_minutes' => 10,
            'insurance_negative_count' => 3, 'insurance_interval_minutes' => 10,
            'technical_error_retry_minutes' => 30, 'telegram_retry_minutes' => 10,
            'telegram_max_attempts' => 20,
        ];
        $this->p = [];
        foreach ($d as $k => $dv) $this->p[$k] = (int)($snapshot[$k] ?? $dv);
    }

    public static function fromSettings(array $settings): self { return new self($settings); }

    public function initialDelayMinutes(): int { return $this->p['initial_delay_minutes']; }
    public function regularIntervalMinutes(): int { return $this->p['regular_interval_minutes']; }
    public function probableNegativeCount(): int { return $this->p['probable_negative_count']; }
    public function confirmIntervalMinutes(): int { return $this->p['confirm_interval_minutes']; }
    public function insuranceNegativeCount(): int { return $this->p['insurance_negative_count']; }
    public function insuranceIntervalMinutes(): int { return $this->p['insurance_interval_minutes']; }
    public function technicalErrorRetryMinutes(): int { return $this->p['technical_error_retry_minutes']; }
    public function telegramRetryMinutes(): int { return $this->p['telegram_retry_minutes']; }
    public function telegramMaxAttempts(): int { return $this->p['telegram_max_attempts']; }

    /** Всего последовательных negative до подтверждённого бана (§4.3). */
    public function requiredNegativeTotal(): int
    {
        return $this->p['probable_negative_count'] + $this->p['insurance_negative_count'];
    }

    public function toArray(): array { return $this->p; }
    public function toJson(): string { return json_encode($this->p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }

    public static function fromJson(?string $json): self
    {
        $a = $json ? (json_decode($json, true) ?: []) : [];
        return new self(is_array($a) ? $a : []);
    }

    /** Человекочитаемое резюме для UI подтверждения (§16.2), всё динамическое. */
    public function summary(): array
    {
        $delay = $this->initialDelayMinutes();
        $delayHuman = $delay % 60 === 0 ? ($delay / 60) . ' ч' : $delay . ' мин';
        $minConfirmMin = $this->probableNegativeCount() >= 1
            ? ($this->probableNegativeCount() - 1) * $this->confirmIntervalMinutes()
              + $this->insuranceNegativeCount() * $this->insuranceIntervalMinutes()
            : 0;
        return [
            'first_check' => 'через ' . $delayHuman,
            'regular' => 'каждые ' . $this->regularIntervalMinutes() . ' мин',
            'probable_after' => 'после ' . $this->probableNegativeCount() . ' negative',
            'ban_after' => 'после ' . $this->requiredNegativeTotal() . ' negative',
            'min_confirm_minutes' => $minConfirmMin,
            'max_requests_per_series' => $this->requiredNegativeTotal(),
        ];
    }
}
