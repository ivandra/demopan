<?php

/**
 * BanMonitorNotificationRepository — Telegram outbox (ban_monitor_notifications, §13).
 * Event создаётся атомарно с state transition (unique event_key). Worker забирает
 * pending/retry по next_attempt_at независимо от состояния monitor.
 */
final class BanMonitorNotificationRepository
{
    private PDO $pdo;

    public function __construct(?PDO $pdo = null) { $this->pdo = $pdo ?? DB::pdo(); }

    /**
     * Идемпотентная постановка события в outbox (§13.3/§13.5).
     * @return string 'inserted' | 'duplicate'  (реальная ошибка → исключение → откат transition)
     */
    public function enqueue(array $ev): string
    {
        try {
            $st = $this->pdo->prepare(
                "INSERT INTO ban_monitor_notifications
                   (monitor_id, source_job_id, domain, event_key, kind, payload_json, rendered_text, status, attempts, next_attempt_at)
                 VALUES (?,?,?,?,?,?,?, 'pending', 0, ?)"
            );
            $st->execute([
                (int)$ev['monitor_id'], (int)$ev['source_job_id'], (string)$ev['domain'],
                (string)$ev['event_key'], (string)$ev['kind'],
                (string)($ev['payload_json'] ?? '{}'), (string)$ev['rendered_text'],
                (string)($ev['next_attempt_at'] ?? gmdate('Y-m-d H:i:s')),
            ]);
            return 'inserted';
        } catch (\PDOException $e) {
            if ((int)($e->errorInfo[1] ?? 0) === 1062) return 'duplicate'; // уже поставлено
            throw $e; // реальная ошибка → transition должен откатиться
        }
    }

    /** Забрать due-события (pending/retry, next_attempt_at<=now). */
    public function claimOne(string $nowUtc): ?array
    {
        $s = $this->pdo->prepare(
            "SELECT * FROM ban_monitor_notifications
              WHERE status IN ('pending','retry') AND next_attempt_at <= ?
              ORDER BY next_attempt_at, id LIMIT 1"
        );
        $s->execute([$nowUtc]);
        $row = $s->fetch(PDO::FETCH_ASSOC);
        if (!$row) return null;
        // per-notification claim: только один worker берёт строку
        $u = $this->pdo->prepare("UPDATE ban_monitor_notifications SET status='sending', last_attempt_at=? WHERE id=? AND status IN ('pending','retry')");
        $u->execute([$nowUtc, (int)$row['id']]);
        return $u->rowCount() === 1 ? $row : null;
    }

    public function markSent(int $id, string $nowUtc): void
    {
        $this->pdo->prepare("UPDATE ban_monitor_notifications SET status='sent', sent_at=?, attempts=attempts+1, last_error=NULL WHERE id=?")->execute([$nowUtc, $id]);
    }

    public function markRetryOrFailed(int $id, int $attempts, int $maxAttempts, int $retryMinutes, string $nowUtc, string $err): string
    {
        $attempts += 1;
        if ($attempts >= $maxAttempts) {
            $this->pdo->prepare("UPDATE ban_monitor_notifications SET status='failed', attempts=?, last_error=? WHERE id=?")
                ->execute([$attempts, mb_substr($err, 0, 1000), $id]);
            return 'failed';
        }
        $next = (new DateTimeImmutable($nowUtc, new DateTimeZone('UTC')))->modify('+' . max(1, $retryMinutes) . ' minutes')->format('Y-m-d H:i:s');
        $this->pdo->prepare("UPDATE ban_monitor_notifications SET status='retry', attempts=?, next_attempt_at=?, last_error=? WHERE id=?")
            ->execute([$attempts, $next, mb_substr($err, 0, 1000), $id]);
        return 'retry';
    }

    public function statusForMonitor(int $monitorId): array
    {
        $s = $this->pdo->prepare("SELECT kind, status, attempts, sent_at, last_error FROM ban_monitor_notifications WHERE monitor_id=? ORDER BY id");
        $s->execute([$monitorId]);
        $out = [];
        foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(string)$r['kind']] = $r;
        return $out;
    }

    public function failedCount(): int
    {
        try { return (int)$this->pdo->query("SELECT COUNT(*) FROM ban_monitor_notifications WHERE status='failed'")->fetchColumn(); }
        catch (\Throwable $e) { return 0; }
    }
}
