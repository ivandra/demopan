<?php

/**
 * BanMonitorNotificationService — worker Telegram outbox (§13.4, §15.2). Отправляет
 * сохранённый rendered_text после commit transition; retry по snapshot независимо от
 * состояния monitor (в т.ч. banned/stopped); после telegram_max_attempts → failed + UI alert.
 * Не выполняет XMLStock и не зависит от monitor.next_check_at.
 */
final class BanMonitorNotificationService
{
    private PDO $pdo;
    private BanMonitorNotificationRepository $repo;
    private $telegram; // fn(string): bool
    private $clock;

    public function __construct(?BanMonitorNotificationRepository $repo = null, ?callable $telegram = null, ?callable $clock = null)
    {
        $this->pdo = DB::pdo();
        $this->repo = $repo ?? new BanMonitorNotificationRepository($this->pdo);
        $this->telegram = $telegram ?? static function (string $t): bool {
            try { return (new TelegramService())->send($t); } catch (\Throwable $e) { return false; }
        };
        $this->clock = $clock ?? static fn() => new DateTimeImmutable('now', new DateTimeZone('UTC'));
    }

    public function runDue(int $limit = 10): array
    {
        $out = ['sent' => 0, 'retried' => 0, 'failed' => 0, 'processed' => 0];
        $limit = max(1, min(100, $limit));
        for ($i = 0; $i < $limit; $i++) {
            $now = ($this->clock)();
            $nowS = $now->format('Y-m-d H:i:s');
            $n = $this->repo->claimOne($nowS);
            if (!$n) break;
            $out['processed']++;
            $payload = json_decode((string)($n['payload_json'] ?? '{}'), true) ?: [];
            $retryMin = (int)($payload['telegram_retry_minutes'] ?? 10);
            $maxAtt = (int)($payload['telegram_max_attempts'] ?? 20);
            $sent = false;
            try { $sent = (bool)($this->telegram)((string)$n['rendered_text']); }
            catch (\Throwable $e) { $sent = false; }
            if ($sent) {
                $this->repo->markSent((int)$n['id'], $nowS);
                $out['sent']++;
            } else {
                $r = $this->repo->markRetryOrFailed((int)$n['id'], (int)$n['attempts'], $maxAtt, $retryMin, $nowS, 'telegram send failed');
                if ($r === 'failed') $out['failed']++; else $out['retried']++;
            }
        }
        return $out;
    }
}
