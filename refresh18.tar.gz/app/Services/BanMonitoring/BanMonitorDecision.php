<?php

/**
 * BanMonitorDecision — ЧИСТАЯ ДИНАМИЧЕСКАЯ машина состояний (§9, §10). Все пороги и
 * интервалы берутся из BanMonitoringPolicy (snapshot конкретного monitor), а не из
 * констант. Никаких hardcoded 3/6/10/12. Один переход на один результат XMLStock.
 */
final class BanMonitorDecision
{
    // Справочные DEFAULT (совпадают с policy defaults). Production-логика существующего
    // monitor их НЕ использует — читает snapshot через BanMonitoringPolicy.
    public const WAIT_HOURS  = 12;
    public const NORMAL_MIN  = 30;
    public const CONFIRM_MIN = 10;

    public const ACTIVE_STATES = ['waiting_initial_delay', 'monitoring', 'confirming', 'insurance'];

    /** Классификация результата XMLStock (§10). */
    public static function classify(array $result): string
    {
        $ok = !empty($result['ok']);
        $indexed = !empty($result['indexed']);
        $pages = (int)($result['pages_indexed'] ?? 0);
        if ($ok && $indexed && $pages >= 1) return 'positive';
        if ($ok && !$indexed && $pages === 0) return 'valid_negative';
        return 'technical_error';
    }

    public static function predictPhase(string $state, int $streak, BanMonitoringPolicy $policy): string
    {
        if ($state === 'confirming' || $state === 'insurance') {
            $next = $streak + 1;
            return $next <= $policy->probableNegativeCount() ? 'confirming' : 'insurance';
        }
        return 'monitoring';
    }

    public static function predictSequence(string $state, int $streak): ?int
    {
        if ($state === 'confirming' || $state === 'insurance') return $streak + 1;
        return null;
    }

    /**
     * Один переход. Возвращает: patch, check_result (indexed|not_indexed|technical_error),
     * telegrams (array<probable|confirmed|recovered>), log, phase, sequence_no.
     */
    public static function decide(array $m, string $classification, int $pages, \DateTimeImmutable $now, BanMonitoringPolicy $policy): array
    {
        $fmt = fn(\DateTimeImmutable $d) => $d->format('Y-m-d H:i:s');
        $plus = fn(int $min) => $fmt($now->modify("+{$min} minutes"));
        $nowS = $fmt($now);

        $rawState = (string)($m['state'] ?? 'monitoring');
        $state = $rawState === 'waiting_initial_delay' ? 'monitoring' : $rawState;
        $streak = (int)($m['negative_streak'] ?? 0);
        $seriesNo = (int)($m['series_no'] ?? 0);
        $probableSent = !empty($m['probable_notified_at']);

        $probableThreshold = $policy->probableNegativeCount();
        $totalThreshold = $policy->requiredNegativeTotal();
        $phaseForCheck = self::predictPhase($rawState, $streak, $policy);
        $sequenceForCheck = self::predictSequence($rawState, $streak);

        // ── Техническая ошибка: фаза/серия не продвигаются (§9.7). ──
        if ($classification === 'technical_error') {
            return [
                'patch' => [
                    'technical_error_count' => (int)($m['technical_error_count'] ?? 0) + 1,
                    'next_check_at' => $plus($policy->technicalErrorRetryMinutes()),
                ],
                'check_result' => 'technical_error',
                'telegrams' => [],
                'log' => 'ban_monitor_technical_error',
                'phase' => $phaseForCheck,
                'sequence_no' => $sequenceForCheck,
            ];
        }

        // ── Positive: сброс серии, возврат в monitoring (§9.3). ──
        if ($classification === 'positive') {
            $patch = [
                'state' => 'monitoring',
                'negative_streak' => 0,
                'insurance_checks_done' => 0,
                'first_negative_at' => null,
                'last_positive_at' => $nowS,
                'last_positive_pages' => max(1, $pages),
                'last_pages_indexed' => $pages,
                'next_check_at' => $plus($policy->regularIntervalMinutes()),
                'probable_notified_at' => null,
                'recovered_notified_at' => null,
            ];
            return [
                'patch' => $patch,
                'check_result' => 'indexed',
                'telegrams' => $probableSent ? ['recovered'] : [],
                'log' => $probableSent ? 'ban_monitor_recovered' : 'ban_monitor_indexed',
                'phase' => $phaseForCheck,
                'sequence_no' => null,
                'recovered_prev_streak' => $streak,
            ];
        }

        // ── Valid negative. ──
        $prevStreak = $streak;
        $newStreak = $streak + 1;
        $patch = ['last_negative_at' => $nowS, 'last_pages_indexed' => 0];
        if ($state === 'monitoring') {
            $patch['first_negative_at'] = $nowS;
            $patch['series_no'] = $seriesNo + 1;
            $patch['probable_notified_at'] = null;
            $patch['recovered_notified_at'] = null;
        }
        $patch['negative_streak'] = $newStreak;

        $telegrams = [];
        $crossedProbable = ($prevStreak < $probableThreshold && $newStreak >= $probableThreshold);

        if ($newStreak >= $totalThreshold) {
            $patch['state'] = 'banned';
            $patch['insurance_checks_done'] = $policy->insuranceNegativeCount();
            $patch['next_check_at'] = null;
            $patch['stopped_at'] = $nowS;
            $patch['banned_at'] = $nowS;
            $patch['stop_reason'] = 'confirmed_ban';
            if ($crossedProbable && !$probableSent) $telegrams[] = 'probable';
            $telegrams[] = 'confirmed';
            $log = 'ban_monitor_confirmed:' . $newStreak . '/' . $totalThreshold;
            $phase = 'insurance';
        } elseif ($newStreak >= $probableThreshold) {
            $patch['state'] = 'insurance';
            $patch['insurance_checks_done'] = $newStreak - $probableThreshold;
            $patch['next_check_at'] = $plus($policy->insuranceIntervalMinutes());
            if ($crossedProbable && !$probableSent) $telegrams[] = 'probable';
            $log = ($crossedProbable ? 'ban_monitor_probable:' : 'ban_monitor_insurance:') . $newStreak . '/' . $totalThreshold;
            $phase = $newStreak <= $probableThreshold ? 'confirming' : 'insurance';
        } else {
            $patch['state'] = 'confirming';
            $patch['insurance_checks_done'] = 0;
            $patch['next_check_at'] = $plus($policy->confirmIntervalMinutes());
            $log = 'ban_monitor_negative:' . $newStreak . '/' . $totalThreshold;
            $phase = 'confirming';
        }

        return [
            'patch' => $patch,
            'check_result' => 'not_indexed',
            'telegrams' => $telegrams,
            'log' => $log,
            'phase' => $phase,
            'sequence_no' => $newStreak,
        ];
    }
}
