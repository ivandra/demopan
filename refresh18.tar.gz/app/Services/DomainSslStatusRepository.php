<?php

/**
 * v25.1-b: хранение SSL-статусов, истории и массовых прогонов.
 *
 * - upsert по UNIQUE(domain) — один домен = одна строка (ТЗ §4.2/§7.3);
 * - история пишется в domain_ssl_check_history с ретеншеном (ТЗ §7.4);
 * - источники доменов для вкладки: sites_managed + активные refresh_jobs +
 *   уже сохранённые статусы (ТЗ §4.2);
 * - сводные счётчики (ТЗ §4.3);
 * - управление batch «Проверить все» (ТЗ §5.1).
 *
 * Секреты не хранит и не логирует.
 */
class DomainSslStatusRepository
{
    /** Терминальные стадии джоб — их новые домены не считаем активными. */
    const TERMINAL_STAGES = ['done', 'failed', 'cancelled', 'superseded'];

    /** Стадии ДО SSL-этапа (домен ещё не «боевой» для SSL-мониторинга). */
    const EARLY_STAGES = ['queued', 'domain_purchasing'];

    // ТЗ 041 §5.1: разделение «разовая проверка» и «ручное закрепление».
    const SOURCE_MANUAL_CHECK = 'manual_check'; // разовая проверка, состояние не меняет
    const SOURCE_MANUAL       = 'manual';       // явное добавление/закрепление оператором

    /** @var array<string,bool> кеш проверок наличия колонок */
    private static $colCache = [];

    private function columnExists(string $table, string $col): bool
    {
        $key = $table . '.' . $col;
        if (array_key_exists($key, self::$colCache)) return self::$colCache[$key];
        try {
            $st = DB::pdo()->query("SHOW COLUMNS FROM `{$table}` LIKE " . DB::pdo()->quote($col));
            self::$colCache[$key] = (bool)($st && $st->fetch());
        } catch (\Throwable $e) { self::$colCache[$key] = false; }
        return self::$colCache[$key];
    }

    /**
     * v25.2-a1.6.3.1: ЕДИНОЕ определение «operationally active job» для домена.
     * Используется в ensureActiveJobDomains / autoArchiveStale /
     * maybeSendTransitionAlert / nudge — чтобы логика «активной джобы» не
     * расходилась между методами.
     *
     * Домен операционно-активен, если существует job J с new_domain=домен, которая:
     *   - НЕ терминальная;
     *   - closed_at IS NULL (если колонка есть);
     *   - достигла SSL-этапа (не queued/domain_purchasing);
     *   - является ПОСЛЕДНИМ lifecycle-record сайта — нет НИ ОДНОЙ более новой
     *     job по id (любой стадии). Завершение более новой job НЕ возрождает
     *     старую историческую (#35).
     *
     * @param string $domainExpr SQL-выражение домена: 's.domain' или '?'.
     */
    private function opActiveJobExistsSql(string $domainExpr): string
    {
        $inTerminal = "'" . implode("','", self::TERMINAL_STAGES) . "'";
        $inEarly    = "'" . implode("','", self::EARLY_STAGES) . "'";
        $closedCond = $this->columnExists('refresh_jobs', 'closed_at') ? "AND j.closed_at IS NULL" : "";
        return "EXISTS (
            SELECT 1 FROM refresh_jobs j
             WHERE j.new_domain = {$domainExpr} COLLATE utf8mb4_unicode_ci
               AND j.stage NOT IN ({$inTerminal})
               {$closedCond}
               AND j.stage NOT IN ({$inEarly})
               AND NOT EXISTS (
                   SELECT 1 FROM refresh_jobs newer
                    WHERE newer.site_id = j.site_id AND newer.id > j.id
               )
        )";
    }

    /** Есть ли у домена операционно-активная job (bound-param версия). */
    private function hasOpActiveJob(string $domain): bool
    {
        try {
            $st = DB::pdo()->prepare("SELECT " . $this->opActiveJobExistsSql('?'));
            $st->execute([$domain]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $e) { return false; }
    }

    /** Сохранить результат проверки (upsert) + запись в историю. */
    public function saveResult(array $r): void
    {
        $domain = strtolower(trim((string)$r['domain']));
        if ($domain === '') return;

        // b1.1: прежнее состояние алерта (для anti-spam transition-логики).
        $prevAlertKey = null;
        $prevStatus = null;
        try {
            $st0 = DB::pdo()->prepare("SELECT last_alert_key, status FROM domain_ssl_statuses WHERE domain=?");
            $st0->execute([$domain]);
            $row0 = $st0->fetch(PDO::FETCH_ASSOC);
            if ($row0) { $prevAlertKey = $row0['last_alert_key']; $prevStatus = $row0['status']; }
        } catch (\Throwable $e) { /* колонки может не быть на очень старой базе */ }

        $next = DomainSslCheckService::nextCheckAt((string)$r['status'], $r['days_remaining'] ?? null);
        $r['next_check_at'] = $next;

        $cols = ['domain','site_id','job_id','dns_ok','resolved_ips_json','http_code','http_location',
            'yandexbot_http_code','yandexbot_location','https_initial_code','https_final_code','https_final_url',
            'technical_ready','site_reachable','probe_ok','probe_http_code','tls_present','tls_trusted',
            'is_self_signed','hostname_valid','issuer','subject','serial_number','valid_from','valid_to',
            'days_remaining','status','reason','error_message','checked_at','check_source','next_check_at'];

        $place = implode(',', array_fill(0, count($cols), '?'));
        $updates = [];
        foreach ($cols as $c) { if ($c !== 'domain') $updates[] = "$c=VALUES($c)"; }
        $sql = "INSERT INTO domain_ssl_statuses (" . implode(',', $cols) . ") VALUES ($place)
                ON DUPLICATE KEY UPDATE " . implode(',', $updates);
        $vals = [];
        foreach ($cols as $c) { $vals[] = $r[$c] ?? null; }
        DB::pdo()->prepare($sql)->execute($vals);

        // История (аудит).
        DB::pdo()->prepare(
            "INSERT INTO domain_ssl_check_history
                (domain, site_id, job_id, status, technical_ready, http_code, https_final_code,
                 tls_trusted, is_self_signed, reason, result_json, check_source, checked_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, NOW())"
        )->execute([
            $domain, $r['site_id'] ?? null, $r['job_id'] ?? null, $r['status'],
            (int)($r['technical_ready'] ?? 0), $r['http_code'] ?? null, $r['https_final_code'] ?? null,
            (int)($r['tls_trusted'] ?? 0), (int)($r['is_self_signed'] ?? 0), $r['reason'] ?? null,
            json_encode($this->historyPayload($r), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            $r['check_source'] ?? null, $r['checked_by'] ?? null,
        ]);

        $this->pruneHistory($domain);

        // b1.1 (Блокер 3) + a1.6.3 §6: debounce Telegram-алерта (cooldown,
        // stable-recovery, только для актуальных доменов).
        $this->maybeSendTransitionAlert($domain, (string)$r['status'], (string)($r['reason'] ?? ''), $prevAlertKey, (string)$prevStatus, $r);

        // v25.2-a (§6.1): переход в trusted немедленно будит активную джобу,
        // ожидающую SSL (не ждём очередного минутного retry).
        if ((string)$r['status'] === DomainSslCheckService::S_TRUSTED
            && (string)$prevStatus !== DomainSslCheckService::S_TRUSTED) {
            $this->nudgeJobOnTrusted($domain);
        }
    }

    /**
     * v25.2-a1.1 (§Блокер 3): при появлении trusted SSL разбудить активную джобу
     * этого домена, ожидающую SSL. Работает под НАСТОЯЩИМ per-job lock
     * (rfp_job_<jobId>, тот же, что у оркестратора) — без lock джобу НЕ трогаем.
     * Стадии ожидания SSL: domain_readiness / wm_verified / ssl_le_polling.
     */
    private function nudgeJobOnTrusted(string $domain): void
    {
        $waitStages = ['domain_readiness', 'wm_verified', 'ssl_le_polling'];
        // 1) Находим конкретные активные джобы этого домена на SSL-ожидающих стадиях.
        $jobIds = [];
        try {
            $in = "'" . implode("','", $waitStages) . "'";
            $st = DB::pdo()->prepare(
                "SELECT id FROM refresh_jobs
                  WHERE new_domain = ? COLLATE utf8mb4_unicode_ci
                    AND stage IN ($in)
                    AND stage_status IN ('pending','long_pending')
                    AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $st->execute([$domain]);
            $jobIds = array_map('intval', array_column($st->fetchAll(PDO::FETCH_ASSOC), 'id'));
        } catch (\Throwable $e) { return; }

        foreach ($jobIds as $jobId) {
            // 2) Настоящий per-job lock. Если не получили — джобу НЕ трогаем.
            $guard = CronGuard::forJob($jobId);
            if (!$guard->acquireJobLock()) { continue; }
            try {
                // 3) Перечитываем актуальную запись под локом.
                $st = DB::pdo()->prepare("SELECT stage, stage_status FROM refresh_jobs WHERE id=?");
                $st->execute([$jobId]);
                $row = $st->fetch(PDO::FETCH_ASSOC);
                if (!$row) continue;
                $stage = (string)$row['stage'];
                $status = (string)$row['stage_status'];
                // 4) Условный UPDATE только для актуальной SSL-ожидающей стадии.
                if (!in_array($stage, $waitStages, true)) continue;
                if (!in_array($status, ['pending', 'long_pending'], true)) continue;
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs
                        SET stage_status='pending', next_run_at=NOW(), stage_error=NULL
                      WHERE id=?"
                )->execute([$jobId]);
            } catch (\Throwable $e) {
                // best-effort
            } finally {
                $guard->releaseJobLock();
            }
        }
    }

    /**
     * b1.1: anti-spam алерты. Критические статусы (hostname_mismatch / expired /
     * not_yet_valid / site_error) при ПЕРВОМ переходе → один Telegram, ключ
     * сохраняется. Повтор того же ключа → тишина. Восстановление в trusted →
     * сброс ключа (будущее ухудшение снова уведомит).
     */
    private function maybeSendTransitionAlert(string $domain, string $status, string $reason, $prevAlertKey, string $prevStatus, array $r): void
    {
        $critical = [
            DomainSslCheckService::S_MISMATCH,
            DomainSslCheckService::S_EXPIRED,
            DomainSslCheckService::S_NOT_YET_VALID,
            DomainSslCheckService::S_SITE_ERROR,
        ];
        // Ранг тяжести (для «escalation» в обход cooldown). Больше — тяжелее.
        $rank = [
            DomainSslCheckService::S_SITE_ERROR   => 1,
            DomainSslCheckService::S_NOT_YET_VALID => 2,
            DomainSslCheckService::S_MISMATCH     => 3,
            DomainSslCheckService::S_EXPIRED      => 4,
        ];
        $newKey = in_array($status, $critical, true) ? $status : null;

        try {
            // a1.6.3 §6: алерты ТОЛЬКО для актуальных записей. Архивные,
            // suppressed и legacy (нет активной job и не manual) — не шлём.
            $meta = DB::pdo()->prepare(
                "SELECT monitoring_enabled, monitoring_suppressed, manual_added, enrolled_source, last_alert_sent_at, alert_recovery_since
                   FROM domain_ssl_statuses WHERE domain=?"
            );
            $meta->execute([$domain]);
            $m = $meta->fetch(PDO::FETCH_ASSOC) ?: [];
            $enabled = (int)($m['monitoring_enabled'] ?? 0) === 1;
            $suppressed = (int)($m['monitoring_suppressed'] ?? 0) === 1;
            // ТЗ 041 §9: НАДЁЖНЫЙ признак ручного домена — manual_added=1 И
            // enrolled_source='manual'. Один manual_added=1 недостаточен: историю
            // могло загрязнить старое «Проверить сейчас». Архивный старый домен
            // (monitoring_enabled=0) и ложно помеченный → Telegram 0.
            $explicitManual = (int)($m['manual_added'] ?? 0) === 1
                && (string)($m['enrolled_source'] ?? '') === 'manual';

            // a1.6.3.1 (Блокер 3): тот же ЕДИНЫЙ predicate operationally active job,
            // что в auto-enrolment/auto-archive. Старая нетерминальная job при
            // наличии более новой job сайта НЕ считается активной.
            $hasActiveJob = $this->hasOpActiveJob($domain);

            $actual = $enabled && !$suppressed && ($hasActiveJob || $explicitManual);
            if (!$actual) {
                return; // legacy/archive/suppressed/старая job/ложно-ручной → Telegram не шлём
            }

            $cooldown = max(60, AppSettings::getInt('ssl.alert_cooldown_sec', 21600));
            $recoveryMin = max(1, AppSettings::getInt('ssl.alert_recovery_minutes', 15));
            $lastSentAt = $m['last_alert_sent_at'] ?? null;
            $lastSentTs = $lastSentAt ? strtotime((string)$lastSentAt) : 0;
            $cooldownElapsed = ($lastSentTs <= 0) || ((time() - $lastSentTs) >= $cooldown);

            if ($newKey !== null) {
                // Критический статус сейчас.
                $isEscalation = ($prevAlertKey !== null)
                    && (($rank[$newKey] ?? 0) > ($rank[$prevAlertKey] ?? 0));
                // a1.6.3.1 (Блокер 4): первичность — по ОТСУТСТВИЮ last_alert_sent_at,
                // а не по пустому last_alert_key. Сброс ключа после recovery НЕ
                // обнуляет cooldown.
                $neverSent = ($lastSentTs <= 0);

                $shouldSend = $neverSent || $isEscalation || $cooldownElapsed;

                if ($shouldSend) {
                    $days = $r['days_remaining'] ?? null;
                    $extra = $reason !== '' ? (' — ' . $reason) : '';
                    if ($days !== null && $status === DomainSslCheckService::S_EXPIRED) $extra .= " (дней: {$days})";
                    $msg = "🔴 SSL/домен: {$domain}\nСтатус: {$status}{$extra}";
                    try { (new TelegramService())->send($msg); } catch (\Throwable $e) { /* уведомление не критично */ }
                    // ключ меняем ТОЛЬКО при фактической отправке.
                    DB::pdo()->prepare(
                        "UPDATE domain_ssl_statuses
                            SET last_alert_key=?, last_alert_sent_at=NOW(), alert_recovery_since=NULL WHERE domain=?"
                    )->execute([$newKey, $domain]);
                } else {
                    // a1.6.3.1 (Блокер 5): алерт подавлен cooldown — НЕ понижаем
                    // last_alert_key. Если после recovery ключа нет — фиксируем
                    // новый активный статус (без отправки), чтобы будущая реальная
                    // escalation была распознаваема. Иначе сохраняем прежний
                    // (более высокий) уровень.
                    if ($prevAlertKey === null) {
                        DB::pdo()->prepare(
                            "UPDATE domain_ssl_statuses SET last_alert_key=?, alert_recovery_since=NULL WHERE domain=?"
                        )->execute([$newKey, $domain]);
                    } else {
                        DB::pdo()->prepare(
                            "UPDATE domain_ssl_statuses SET alert_recovery_since=NULL WHERE domain=?"
                        )->execute([$domain]);
                    }
                }
                return;
            }

            // Некритический результат.
            if ($prevAlertKey === null) {
                // Активного алерта нет — чистим возможный recovery-хвост.
                if (!empty($m['alert_recovery_since'])) {
                    DB::pdo()->prepare("UPDATE domain_ssl_statuses SET alert_recovery_since=NULL WHERE domain=?")->execute([$domain]);
                }
                return;
            }

            // Есть активный алерт → это кандидат на выздоровление.
            if ($status === DomainSslCheckService::S_TRUSTED) {
                $recSince = $m['alert_recovery_since'] ?? null;
                $recSinceTs = $recSince ? strtotime((string)$recSince) : 0;
                $twoConsecutive = ($prevStatus === DomainSslCheckService::S_TRUSTED);
                $longEnough = ($recSinceTs > 0) && ((time() - $recSinceTs) >= $recoveryMin * 60);

                if ($twoConsecutive || $longEnough) {
                    // Устойчивое выздоровление → снимаем алерт-ключ (будущее ухудшение снова уведомит).
                    DB::pdo()->prepare(
                        "UPDATE domain_ssl_statuses SET last_alert_key=NULL, alert_recovery_since=NULL WHERE domain=?"
                    )->execute([$domain]);
                } elseif ($recSinceTs <= 0) {
                    // Первый trusted в стрике — запоминаем момент, ключ пока НЕ снимаем.
                    DB::pdo()->prepare(
                        "UPDATE domain_ssl_statuses SET alert_recovery_since=NOW() WHERE domain=?"
                    )->execute([$domain]);
                }
                // иначе стрик идёт, но ещё не устойчив — ждём.
                return;
            }

            // Некритический, но не trusted (unreachable/not_checked) — стрик рвём,
            // ключ НЕ снимаем (одно промежуточное измерение не разрешает новый алерт).
            if (!empty($m['alert_recovery_since'])) {
                DB::pdo()->prepare("UPDATE domain_ssl_statuses SET alert_recovery_since=NULL WHERE domain=?")->execute([$domain]);
            }
        } catch (\Throwable $e) { /* не блокируем проверку из-за алерта */ }
    }

    private function historyPayload(array $r): array
    {
        // Компактный снимок без секретов.
        $keep = ['http_location','yandexbot_http_code','yandexbot_location','https_initial_code',
            'https_final_url','issuer','subject','serial_number','valid_from','valid_to','days_remaining',
            'hostname_valid','probe_ok','error_message','check_duration_ms'];
        $out = [];
        foreach ($keep as $k) if (array_key_exists($k, $r)) $out[$k] = $r[$k];
        return $out;
    }

    private function pruneHistory(string $domain): void
    {
        $days = max(1, AppSettings::getInt('ssl.history_retention_days', 90));
        try {
            DB::pdo()->prepare(
                "DELETE FROM domain_ssl_check_history WHERE domain=? AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)"
            )->execute([$domain, $days]);
            // и не более 100 последних на домен
            DB::pdo()->prepare(
                "DELETE FROM domain_ssl_check_history
                  WHERE domain=? AND id NOT IN (
                    SELECT id FROM (SELECT id FROM domain_ssl_check_history WHERE domain=? ORDER BY id DESC LIMIT 100) t
                  )"
            )->execute([$domain, $domain]);
        } catch (\Throwable $e) { /* ретеншен не критичен */ }
    }

    public function getByDomain(string $domain): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM domain_ssl_statuses WHERE domain=?");
        $st->execute([strtolower(trim($domain))]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function historyForDomain(string $domain, int $limit = 20): array
    {
        $st = DB::pdo()->prepare("SELECT * FROM domain_ssl_check_history WHERE domain=? ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, strtolower(trim($domain)));
        $st->bindValue(2, max(1, $limit), PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    /**
     * v25.1-b1: enrol одного домена в мониторинг ПО ФАКТУ события. Идемпотентно
     * (upsert по UNIQUE domain). Не трогает существующий статус/архив, только
     * гарантирует наличие активной записи и проставляет next_check_at=NOW при
     * первом добавлении.
     *
     * @param string $source job|purchase|alias|readiness|manual
     * @param bool   $manual добавлено вручную оператором
     */
    public function enrollDomain(string $domain, ?int $siteId = null, ?int $jobId = null,
        string $source = 'job', bool $manual = false): void
    {
        $domain = strtolower(trim($domain));
        if ($domain === '') return;
        DB::pdo()->prepare(
            "INSERT INTO domain_ssl_statuses
                (domain, site_id, job_id, status, monitoring_enabled, manual_added,
                 enrolled_source, enrolled_at, next_check_at, created_at)
             VALUES (?,?,?, 'not_checked', 1, ?, ?, NOW(), NOW(), NOW())
             ON DUPLICATE KEY UPDATE
                site_id = COALESCE(VALUES(site_id), site_id),
                -- a1.6.3 §5: job_id перепривязываем ТОЛЬКО на более новую job
                -- (или если раньше был пуст). Старые джобы строку не перехватывают.
                job_id = CASE
                    WHEN VALUES(job_id) IS NULL THEN job_id
                    WHEN job_id IS NULL THEN VALUES(job_id)
                    WHEN VALUES(job_id) >= job_id THEN VALUES(job_id)
                    ELSE job_id END,
                -- a1.6.3 §4: подавленный оператором домен НЕ возвращаем в мониторинг.
                monitoring_enabled = IF(monitoring_suppressed = 1, monitoring_enabled, 1),
                archived_at = IF(monitoring_suppressed = 1, archived_at, NULL),
                archived_reason = IF(monitoring_suppressed = 1, archived_reason, NULL),
                manual_added = GREATEST(manual_added, VALUES(manual_added)),
                -- ТЗ 041 §6: явное ручное закрепление (manual=true) принудительно
                -- ставит enrolled_source='manual'. Это надёжный признак ручного
                -- домена: (manual_added=1 AND enrolled_source='manual'). Автодомен,
                -- ошибочно помеченный старым «Проверить сейчас», такого не получит.
                enrolled_source = CASE
                    WHEN VALUES(manual_added) = 1 THEN 'manual'
                    ELSE COALESCE(enrolled_source, VALUES(enrolled_source))
                END,
                enrolled_at = COALESCE(enrolled_at, VALUES(enrolled_at))"
        )->execute([$domain, $siteId, $jobId, $manual ? 1 : 0, $source]);
    }

    /**
     * v25.1-b1: подтянуть в мониторинг ТОЛЬКО домены активных refresh-джоб
     * (new_domain), которых ещё нет. НЕ импортирует sites_managed.current_domain.
     * Возвращает число вновь добавленных доменов.
     */
    /**
     * v25.1-b1.2 (§2.3): страховочный enrolment. Берёт активные джобы, у которых
     * new_domain не пуст и стадия достигла aliases_added ИЛИ ПОЗЖЕ (не queued/
     * domain_purchasing), и создаёт недостающие SSL-записи с next_check_at=NOW().
     * Историческую sites_managed НЕ импортирует. Возвращает число добавленных.
     *
     * @param array $stagesBeforeAliases стадии ДО aliases_added (домен ещё не готов)
     */
    public function ensureActiveJobDomains(array $stagesBeforeAliases = ['queued', 'domain_purchasing']): int
    {
        // a1.6.3.1 (Блокер 2): выбираем ТОЛЬКО операционно-активные джобы —
        // последний lifecycle-record сайта (нет более новой job по id ЛЮБОЙ
        // стадии), нетерминальный, closed_at IS NULL, достигший SSL-этапа.
        // Завершение более новой job НЕ возрождает старую историческую.
        $inTerminal = "'" . implode("','", self::TERMINAL_STAGES) . "'";
        $inEarly    = "'" . implode("','", self::EARLY_STAGES) . "'";
        $closedCond = $this->columnExists('refresh_jobs', 'closed_at') ? "AND j.closed_at IS NULL" : "";
        $jobs = DB::pdo()->query(
            "SELECT j.id, j.site_id, j.new_domain FROM refresh_jobs j
              WHERE j.new_domain IS NOT NULL AND j.new_domain<>''
                AND j.stage NOT IN ($inTerminal)
                $closedCond
                AND j.stage NOT IN ($inEarly)
                AND NOT EXISTS (
                    SELECT 1 FROM refresh_jobs newer
                     WHERE newer.site_id = j.site_id AND newer.id > j.id
                )"
        )->fetchAll(PDO::FETCH_ASSOC);
        $added = 0;
        foreach ($jobs as $j) {
            $domain = strtolower(trim((string)$j['new_domain']));
            if ($domain === '') continue;
            // a1.6.3 §4: вручную подавленный (operator) домен НЕ возвращаем автоматически.
            $row = DB::pdo()->prepare("SELECT monitoring_suppressed FROM domain_ssl_statuses WHERE domain=?");
            $row->execute([$domain]);
            $rec = $row->fetch(PDO::FETCH_ASSOC);
            if ($rec !== false && (int)($rec['monitoring_suppressed'] ?? 0) === 1) {
                continue; // оператор сам отправил в архив — уважаем
            }
            $existed = ($rec !== false);
            $this->enrollDomain($domain, $j['site_id'] !== null ? (int)$j['site_id'] : null, (int)$j['id'], 'active_job', false);
            if (!$existed) $added++;
        }
        return $added;
    }

    public function ensureTrackedDomains(): int
    {
        $inTerminal = "'" . implode("','", self::TERMINAL_STAGES) . "'";
        $jobs = DB::pdo()->query(
            "SELECT id, site_id, new_domain FROM refresh_jobs
              WHERE new_domain IS NOT NULL AND new_domain<>'' AND stage NOT IN ($inTerminal)"
        )->fetchAll(PDO::FETCH_ASSOC);
        $added = 0;
        foreach ($jobs as $j) {
            $domain = strtolower(trim((string)$j['new_domain']));
            if ($domain === '') continue;
            $exists = DB::pdo()->prepare("SELECT 1 FROM domain_ssl_statuses WHERE domain=?");
            $exists->execute([$domain]);
            if ($exists->fetchColumn()) continue;
            $this->enrollDomain($domain, $j['site_id'] !== null ? (int)$j['site_id'] : null, (int)$j['id'], 'job', false);
            $added++;
        }
        return $added;
    }

    /**
     * v25.2-a1.6.3.1 (§Блокер 1/2): авто-архивирование по ЕДИНОМУ predicate
     * «operationally active job». Любая авто-строка (manual_added=0,
     * monitoring_suppressed=0), у которой НЕТ операционно-активной job, уходит в
     * Архив — даже если есть история и формально нетерминальная старая job.
     * archived_reason='job_stale'. Историю НЕ трогаем. Чистим batch.
     */
    public function autoArchiveStale(): int
    {
        $sql =
            "UPDATE domain_ssl_statuses s
                SET s.monitoring_enabled = 0, s.archived_at = NOW(),
                    s.monitoring_suppressed = 0, s.archived_reason = 'job_stale',
                    s.batch_id = NULL, s.batch_state = NULL, s.batch_claimed_at = NULL
              WHERE s.monitoring_enabled = 1
                AND s.manual_added = 0
                AND s.monitoring_suppressed = 0
                AND NOT " . $this->opActiveJobExistsSql('s.domain');
        $st = DB::pdo()->prepare($sql);
        $st->execute();
        return $st->rowCount();
    }

    /**
     * ТЗ 041 §7: немедленно архивировать СТАРЫЙ домен успешно завершённой джобы.
     * Идемпотентно. Никогда не трогает newDomain (UPDATE только по oldDomain).
     * Архивирует лишь при выполнении ВСЕХ условий §7.2: строка есть, домен не
     * является current_domain управляемого сайта, нет operationally active job
     * (тот же единый predicate), домен не закреплён явно (manual_added=1 AND
     * enrolled_source='manual'). Историю НЕ трогает. true, если строка архивирована.
     */
    public function archiveCompletedOldDomain(string $oldDomain, string $newDomain, ?int $siteId, int $jobId): bool
    {
        $old = strtolower(trim($oldDomain));
        $new = strtolower(trim($newDomain));
        if ($old === '' || $new === '' || $old === $new) return false;

        $chk = DB::pdo()->prepare("SELECT 1 FROM domain_ssl_statuses WHERE domain=?");
        $chk->execute([$old]);
        if (!$chk->fetchColumn()) return false;

        $sql =
            "UPDATE domain_ssl_statuses s
                SET s.monitoring_enabled = 0, s.monitoring_suppressed = 0, s.manual_added = 0,
                    s.archived_at = NOW(), s.archived_reason = 'job_completed', s.next_check_at = NULL,
                    s.batch_id = NULL, s.batch_state = NULL, s.batch_claimed_at = NULL,
                    s.last_alert_key = NULL, s.last_alert_sent_at = NULL, s.alert_recovery_since = NULL
              WHERE s.domain = ?
                AND s.monitoring_enabled = 1
                AND NOT (s.manual_added = 1 AND s.enrolled_source = 'manual')
                AND NOT EXISTS (SELECT 1 FROM sites_managed sm WHERE sm.current_domain = s.domain COLLATE utf8mb4_unicode_ci)
                AND NOT " . $this->opActiveJobExistsSql('s.domain');
        $st = DB::pdo()->prepare($sql);
        $st->execute([$old]);
        return $st->rowCount() > 0;
    }

    /** Отключить мониторинг домена (в архив) — РУЧНОЕ действие оператора. */
    public function archiveDomain(string $domain): void
    {
        // a1.6.3 §4/§7: устойчивое ручное подавление — cron НЕ вернёт домен
        // автоматически (monitoring_suppressed=1). Чистим batch, чтобы старый
        // домен не остался в уже созданном прогоне «Проверить все».
        DB::pdo()->prepare(
            "UPDATE domain_ssl_statuses SET monitoring_enabled=0, archived_at=NOW(),
                monitoring_suppressed=1, archived_reason='operator',
                batch_id=NULL, batch_state=NULL, batch_claimed_at=NULL WHERE domain=?"
        )->execute([strtolower(trim($domain))]);
    }

    /** Вернуть домен в мониторинг: next_check_at=NOW. */
    public function unarchiveDomain(string $domain): void
    {
        // a1.6.1 (Дефект 3) + a1.6.3 §4: фиксируем ручной выбор оператора и
        // снимаем suppression (manual_added=1, enrolled_source='manual',
        // monitoring_suppressed=0), чтобы autoArchiveStale не архивировал обратно.
        DB::pdo()->prepare(
            "UPDATE domain_ssl_statuses SET monitoring_enabled=1, archived_at=NULL,
                monitoring_suppressed=0, archived_reason=NULL,
                manual_added=1, enrolled_source='manual', next_check_at=NOW() WHERE domain=?"
        )->execute([strtolower(trim($domain))]);
    }

    /** Удалить домен из списка. История сохраняется, если $withHistory=false. */
    public function removeDomain(string $domain, bool $withHistory = false): void
    {
        $domain = strtolower(trim($domain));
        DB::pdo()->prepare("DELETE FROM domain_ssl_statuses WHERE domain=?")->execute([$domain]);
        if ($withHistory) {
            DB::pdo()->prepare("DELETE FROM domain_ssl_check_history WHERE domain=?")->execute([$domain]);
        }
    }

    /**
     * v25.1-b1: домены для вкладки читаются ТОЛЬКО из domain_ssl_statuses
     * (enrolment-based), с фильтром активные/архив. НИКАКОГО масс-импорта.
     *
     * @param array $filters ['scope'=>'active'|'archived', 'q'=>str, 'status'=>str,
     *                        'availability'=>'available'|'unreachable', 'source'=>str]
     */
    /** b1.1: единый построитель WHERE для списка/пагинации/подсчёта. */
    /**
     * ТЗ 040 FINAL-3 §3.7: единый FROM/JOIN для SSL-списков. Сервер определяется
     * по effective site = COALESCE(d.site_id, j.site_id), поэтому SSL-запись,
     * связанная только через job_id, тоже получает сервер и бейдж. COUNT и SELECT
     * ОБЯЗАНЫ использовать этот же FROM/JOIN/WHERE.
     */
    private function baseFrom(): string
    {
        return "FROM domain_ssl_statuses d
                LEFT JOIN refresh_jobs j ON j.id = d.job_id
                LEFT JOIN sites_managed s ON s.id = COALESCE(d.site_id, j.site_id)
                LEFT JOIN fastpanel_servers fps ON fps.id = s.fastpanel_server_id";
    }

    private function selectCols(): string
    {
        return "d.*, s.fastpanel_server_id AS server_id, fps.title AS server_title,
                fps.ui_badge_code, fps.ui_badge_label, fps.ui_badge_color";
    }

    private function buildFilterWhere(array $filters): array
    {
        // a1.6 §10: scope 'all' — Активные + Архив (без фильтра monitoring_enabled).
        $rawScope = (string)($filters['scope'] ?? 'active');
        $scope = in_array($rawScope, ['archived', 'all'], true) ? $rawScope : 'active';
        $where = [];
        $args = [];
        if ($scope === 'archived')      $where[] = "d.monitoring_enabled=0";
        elseif ($scope === 'active')    $where[] = "d.monitoring_enabled=1";
        // scope 'all' — без ограничения по monitoring_enabled

        if (!empty($filters['q'])) { $where[] = "d.domain LIKE ?"; $args[] = '%' . strtolower(trim($filters['q'])) . '%'; }
        if (!empty($filters['status'])) {
            if ($filters['status'] === 'errors') {
                $where[] = "d.status IN ('hostname_mismatch','expired','not_yet_valid','site_error','unreachable')";
            } else {
                $where[] = "d.status = ?"; $args[] = $filters['status'];
            }
        }
        if (!empty($filters['source'])) { $where[] = "d.enrolled_source = ?"; $args[] = $filters['source']; }
        if (($filters['batch'] ?? '') === 'queued') { $where[] = "d.batch_state = 'queued'"; }
        elseif (($filters['batch'] ?? '') === 'checking') { $where[] = "d.batch_state = 'checking'"; }
        if (($filters['availability'] ?? '') === 'available') { $where[] = "d.technical_ready = 1"; }
        elseif (($filters['availability'] ?? '') === 'unreachable') { $where[] = "d.technical_ready = 0"; }

        // §3.7: фильтр по серверу через effective site (d.site_id или job.site_id).
        if (!empty($filters['server_id'])) {
            $where[] = "s.fastpanel_server_id = ?";
            $args[] = (int)$filters['server_id'];
        }

        return [$where ? (' WHERE ' . implode(' AND ', $where)) : '', $args];
    }

    private function mapStatusRow(array $s): array
    {
        return [
            'domain' => $s['domain'],
            'site_id' => $s['site_id'] !== null ? (int)$s['site_id'] : null,
            'job_id' => $s['job_id'] !== null ? (int)$s['job_id'] : null,
            // §3.7: серверные поля для бейджа (effective site).
            'server_id' => isset($s['server_id']) && $s['server_id'] !== null ? (int)$s['server_id'] : null,
            'server_title' => $s['server_title'] ?? null,
            'ui_badge_code' => $s['ui_badge_code'] ?? null,
            'ui_badge_label' => $s['ui_badge_label'] ?? null,
            'ui_badge_color' => $s['ui_badge_color'] ?? null,
            'status_row' => $s,
        ];
    }

    public function listDomainsForTab(array $filters = []): array
    {
        [$whereSql, $args] = $this->buildFilterWhere($filters);
        $sql = "SELECT " . $this->selectCols() . " " . $this->baseFrom() . $whereSql . " ORDER BY d.domain ASC";
        $st = DB::pdo()->prepare($sql);
        $st->execute($args);
        $rows = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $s) { $rows[] = $this->mapStatusRow($s); }
        return $rows;
    }

    /** b1.1: настоящая SQL-пагинация (COUNT + LIMIT/OFFSET), не array_slice. */
    public function listDomainsPaged(array $filters, int $page, int $perPage): array
    {
        [$whereSql, $args] = $this->buildFilterWhere($filters);
        $page = max(1, $page);
        $perPage = max(1, $perPage);
        $offset = ($page - 1) * $perPage;

        // §3.7: COUNT и SELECT — один и тот же FROM/JOIN/WHERE builder.
        $cnt = DB::pdo()->prepare("SELECT COUNT(*) " . $this->baseFrom() . $whereSql);
        $cnt->execute($args);
        $total = (int)$cnt->fetchColumn();

        $sql = "SELECT " . $this->selectCols() . " " . $this->baseFrom() . $whereSql . " ORDER BY d.domain ASC LIMIT ? OFFSET ?";
        $st = DB::pdo()->prepare($sql);
        $i = 1;
        foreach ($args as $a) { $st->bindValue($i++, $a); }
        $st->bindValue($i++, $perPage, PDO::PARAM_INT);
        $st->bindValue($i++, $offset, PDO::PARAM_INT);
        $st->execute();
        $rows = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $s) { $rows[] = $this->mapStatusRow($s); }
        return ['rows' => $rows, 'total' => $total];
    }

    /** Сводные счётчики (ТЗ §4.3) — только по активным (monitoring_enabled=1). */
    /**
     * v25.2-b (§Блокер 3): heartbeat основного cron и SSL-cron из таблицы
     * cron_state. Возвращает по каждому: статус-цвет, последний запуск, секунд
     * назад, последнее успешное завершение, длительность, обработано, ошибка.
     * Пороги цвета: основной cron (15с) зелёный ≤45 / жёлтый ≤90 / красный >90;
     * SSL cron (минутный) зелёный ≤90 / жёлтый ≤180 / красный >180; серый — не запускался.
     */
    public function cronHeartbeat(): array
    {
        $out = [];
        $specs = [
            'main' => ['name' => 'refresh_orchestrator', 'label' => 'Основные проверки', 'green' => 45, 'yellow' => 90, 'cadence' => 'каждые 15 сек'],
            'ssl'  => ['name' => 'ssl_monitor',          'label' => 'Проверки сертификата',       'green' => 90, 'yellow' => 180, 'cadence' => 'каждую минуту'],
        ];
        foreach ($specs as $key => $spec) {
            $row = null;
            try {
                $st = DB::pdo()->prepare("SELECT cron_name, last_run_at, last_ok, last_error, stats_json,
                    TIMESTAMPDIFF(SECOND, last_run_at, NOW()) AS ago_sec
                    FROM cron_state WHERE cron_name=?");
                $st->execute([$spec['name']]);
                $row = $st->fetch(PDO::FETCH_ASSOC);
            } catch (\Throwable $e) { $row = null; }

            if (!$row || $row['last_run_at'] === null) {
                $out[$key] = ['label' => $spec['label'], 'color' => 'gray', 'status_text' => 'ни разу не запускался',
                    'last_run_at' => null, 'ago_sec' => null, 'last_ok' => null, 'last_error' => null,
                    'duration' => null, 'processed' => null, 'cadence' => $spec['cadence']];
                continue;
            }
            $ago = (int)$row['ago_sec'];
            $ok = (int)$row['last_ok'] === 1;
            if (!$ok)                     $color = 'red';
            elseif ($ago <= $spec['green'])  $color = 'green';
            elseif ($ago <= $spec['yellow']) $color = 'yellow';
            else                          $color = 'red';

            $stats = json_decode((string)($row['stats_json'] ?? ''), true) ?: [];
            // «обработано» — по типу cron.
            $processed = $stats['jobs_processed'] ?? $stats['checked'] ?? ($stats['ssl_reconciler']['processed'] ?? null);
            $duration = $stats['duration_sec'] ?? null;

            $out[$key] = [
                'label' => $spec['label'],
                'color' => $color,
                'status_text' => $ok ? ($color === 'green' ? 'работает' : ($color === 'yellow' ? 'задерживается' : 'остановлен')) : 'ошибка',
                'last_run_at' => $row['last_run_at'],
                'ago_sec' => $ago,
                'last_ok' => $ok,
                'last_error' => $ok ? null : (string)$row['last_error'],
                'duration' => $duration,
                'processed' => $processed,
                'cadence' => $spec['cadence'],
            ];
        }
        return $out;
    }

    public function summary(array $filters = []): array
    {
        // §4 (аудит ver3): карточки-счётчики учитывают выбранный сервер. Статусный
        // фильтр текущей таблицы к карточкам не применяем, но server_id — обязателен.
        $sumFilters = ['scope' => 'active'];
        if (!empty($filters['server_id'])) $sumFilters['server_id'] = (int)$filters['server_id'];
        $rows = $this->listDomainsForTab($sumFilters);
        $sum = ['total' => 0, 'available' => 0, 'queued' => 0, 'checking' => 0, 'self_signed' => 0, 'trusted' => 0,
            'expiring' => 0, 'hostname_errors' => 0, 'unreachable' => 0, 'not_checked' => 0];
        $warn = max(1, AppSettings::getInt('ssl.expiring_days_warning', 30));
        foreach ($rows as $row) {
            $sum['total']++;
            $s = $row['status_row'];
            $status = (string)($s['status'] ?? 'not_checked');
            $batchState = (string)($s['batch_state'] ?? '');
            // §5: queued и checking — раздельно, взаимоисключающе.
            $isQueued = ($batchState === 'queued');
            $isChecking = ($batchState === 'checking');
            if ($isQueued) $sum['queued']++;
            if ($isChecking) $sum['checking']++;
            // «Не проверялся» — только если НЕ в очереди и НЕ проверяется сейчас.
            if (($status === DomainSslCheckService::S_NOT_CHECKED || empty($s['checked_at']))
                && !$isQueued && !$isChecking) { $sum['not_checked']++; }
            if ((int)($s['technical_ready'] ?? 0) === 1) $sum['available']++;
            if ($status === DomainSslCheckService::S_TRUSTED) $sum['trusted']++;
            if ($status === DomainSslCheckService::S_SELF_SIGNED) $sum['self_signed']++;
            if ($status === DomainSslCheckService::S_MISMATCH) $sum['hostname_errors']++;
            if (in_array($status, [DomainSslCheckService::S_UNREACHABLE, DomainSslCheckService::S_SITE_ERROR,
                DomainSslCheckService::S_EXPIRED, DomainSslCheckService::S_NOT_YET_VALID], true)) $sum['unreachable']++;
            if (isset($s['days_remaining']) && $s['days_remaining'] !== null
                && (int)$s['days_remaining'] <= $warn && (int)$s['days_remaining'] >= 0) $sum['expiring']++;
        }
        return $sum;
    }

    /* ==================== batch «Проверить все» ==================== */

    /** Создать batch из АКТИВНЫХ доменов вкладки (monitoring_enabled=1).
     *  Идемпотентно + СТРОГО под advisory-lock rfp_ssl_batch_start: если лок не
     *  получен — новый batch НЕ создаётся (возвращаем существующий running либо
     *  бросаем ошибку для retry). Два одновременных нажатия → один running batch. */
    public function startBatch(?string $startedBy = null): int
    {
        $lock = 'rfp_ssl_batch_start';
        $locked = false;
        try {
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, ?)");
            $st->execute([$lock, 5]);
            $locked = ((int)$st->fetchColumn() === 1);
        } catch (\Throwable $e) { $locked = false; }

        // b1.1.1: без лока НЕ создаём batch. Если running уже есть — вернём его;
        // иначе — понятная ошибка (пусть вызывающий повторит), но НЕ INSERT.
        if (!$locked) {
            $running = DB::pdo()
                ->query("SELECT id FROM domain_ssl_batches WHERE status='running' ORDER BY id DESC LIMIT 1")
                ->fetchColumn();
            if ($running) return (int)$running;
            throw new \RuntimeException(
                'Не удалось получить блокировку запуска SSL batch (rfp_ssl_batch_start). Повторите попытку.'
            );
        }

        try {
            $running = DB::pdo()->query("SELECT id FROM domain_ssl_batches WHERE status='running' ORDER BY id DESC LIMIT 1")->fetchColumn();
            if ($running) return (int)$running;

            // Только уже enrolled активные домены — НЕ импортируем чужие.
            $domains = $this->listDomainsForTab(['scope' => 'active']);
            $total = count($domains);
            DB::pdo()->prepare(
                "INSERT INTO domain_ssl_batches (status, total, queued, checking, done, started_by, created_at)
                 VALUES ('running', ?, ?, 0, 0, ?, NOW())"
            )->execute([$total, $total, $startedBy]);
            $batchId = (int)DB::pdo()->lastInsertId();

            // Пометим существующие активные записи в очередь batch (без вставки новых).
            $mark = DB::pdo()->prepare(
                "UPDATE domain_ssl_statuses SET batch_id=?, batch_state='queued', batch_claimed_at=NULL, batch_last_error=NULL
                  WHERE domain=? AND monitoring_enabled=1"
            );
            foreach ($domains as $d) {
                $mark->execute([$batchId, $d['domain']]);
            }
            return $batchId;
        } finally {
            try { DB::pdo()->prepare("SELECT RELEASE_LOCK(?)")->execute([$lock]); } catch (\Throwable $e) {}
        }
    }

    /** Остановить batch: отменяем ТОЛЬКО ещё не начатые (queued). */
    public function stopBatch(int $batchId): void
    {
        DB::pdo()->prepare(
            "UPDATE domain_ssl_statuses SET batch_state=NULL, batch_id=NULL
              WHERE batch_id=? AND batch_state='queued'"
        )->execute([$batchId]);
        DB::pdo()->prepare("UPDATE domain_ssl_batches SET status='stopped', queued=0 WHERE id=?")->execute([$batchId]);
    }

    /** Прогресс batch (ТЗ §5.1) — пересчёт из статусов. */
    public function batchProgress(int $batchId): ?array
    {
        $b = DB::pdo()->prepare("SELECT * FROM domain_ssl_batches WHERE id=?");
        $b->execute([$batchId]);
        $batch = $b->fetch(PDO::FETCH_ASSOC);
        if (!$batch) return null;

        $q = DB::pdo()->prepare(
            "SELECT
                SUM(batch_state='queued') queued,
                SUM(batch_state='checking') checking,
                SUM(batch_state='done') done,
                SUM(batch_state='done' AND status IN ('trusted')) ok_count,
                SUM(batch_state='done' AND status IN ('self_signed','ssl_issuing','verify_pending')) warn_count,
                SUM(batch_state='done' AND status IN ('hostname_mismatch','expired','not_yet_valid','site_error','unreachable')) error_count
             FROM domain_ssl_statuses WHERE batch_id=?"
        );
        $q->execute([$batchId]);
        $agg = $q->fetch(PDO::FETCH_ASSOC) ?: [];
        $queued = (int)($agg['queued'] ?? 0);
        $done = (int)($agg['done'] ?? 0);
        $checking = (int)($agg['checking'] ?? 0);

        // Автозавершение batch.
        $status = (string)$batch['status'];
        if ($status === 'running' && $queued === 0 && $checking === 0) {
            DB::pdo()->prepare("UPDATE domain_ssl_batches SET status='done' WHERE id=? AND status='running'")->execute([$batchId]);
            $status = 'done';
        }

        return [
            'id' => $batchId,
            'status' => $status,
            'total' => (int)$batch['total'],
            'queued' => $queued,
            'checking' => $checking,
            'done' => $done,
            'ok_count' => (int)($agg['ok_count'] ?? 0),
            'warn_count' => (int)($agg['warn_count'] ?? 0),
            'error_count' => (int)($agg['error_count'] ?? 0),
        ];
    }

    public function currentRunningBatchId(): ?int
    {
        $id = DB::pdo()->query("SELECT id FROM domain_ssl_batches WHERE status='running' ORDER BY id DESC LIMIT 1")->fetchColumn();
        return $id ? (int)$id : null;
    }

    /** Выбрать пачку доменов batch для проверки на cron-tick, пометив 'checking'
     *  под guard (не берём один домен дважды). Перед выборкой возвращает
     *  «застрявшие» checking (batch_claimed_at старше порога) обратно в queued. */
    public function claimBatchChunk(int $batchId, int $limit): array
    {
        // b1.1: stale-checking recovery — если процесс умер после claim, вернуть в очередь.
        $staleSec = 600; // 10 минут — заведомо больше любой одиночной проверки
        DB::pdo()->prepare(
            "UPDATE domain_ssl_statuses
                SET batch_state='queued', batch_claimed_at=NULL
              WHERE batch_id=? AND batch_state='checking'
                AND (batch_claimed_at IS NULL OR batch_claimed_at < DATE_SUB(NOW(), INTERVAL ? SECOND))"
        )->execute([$batchId, $staleSec]);

        $sel = DB::pdo()->prepare(
            "SELECT domain, site_id, job_id FROM domain_ssl_statuses
              WHERE batch_id=? AND batch_state='queued'
                AND monitoring_enabled=1 AND monitoring_suppressed=0
              ORDER BY id LIMIT ?"
        );
        $sel->bindValue(1, $batchId, PDO::PARAM_INT);
        $sel->bindValue(2, max(1, $limit), PDO::PARAM_INT);
        $sel->execute();
        $rows = $sel->fetchAll(PDO::FETCH_ASSOC) ?: [];

        $claim = DB::pdo()->prepare(
            "UPDATE domain_ssl_statuses SET batch_state='checking', batch_claimed_at=NOW()
              WHERE domain=? AND batch_id=? AND batch_state='queued'"
        );
        $claimed = [];
        foreach ($rows as $row) {
            $claim->execute([$row['domain'], $batchId]);
            if ($claim->rowCount() === 1) $claimed[] = $row; // мы застолбили
        }
        return $claimed;
    }

    /** Домен реально проверен → done. */
    public function markBatchDomainDone(int $batchId, string $domain): void
    {
        DB::pdo()->prepare(
            "UPDATE domain_ssl_statuses SET batch_state='done', batch_claimed_at=NULL, batch_last_error=NULL
              WHERE domain=? AND batch_id=?"
        )->execute([strtolower(trim($domain)), $batchId]);
    }

    /** b1.1: вернуть домен в очередь (lock busy / временная ошибка), НЕ done. */
    public function requeueBatchDomain(int $batchId, string $domain, ?string $error = null): void
    {
        DB::pdo()->prepare(
            "UPDATE domain_ssl_statuses SET batch_state='queued', batch_claimed_at=NULL, batch_last_error=?
              WHERE domain=? AND batch_id=?"
        )->execute([$error !== null ? mb_substr($error, 0, 1024) : null, strtolower(trim($domain)), $batchId]);
    }

    /** b1.1: фатальная ошибка с сохранённым error-result → done + last_error. */
    public function markBatchDomainError(int $batchId, string $domain, string $error): void
    {
        DB::pdo()->prepare(
            "UPDATE domain_ssl_statuses SET batch_state='done', batch_claimed_at=NULL, batch_last_error=?
              WHERE domain=? AND batch_id=?"
        )->execute([mb_substr($error, 0, 1024), strtolower(trim($domain)), $batchId]);
    }

    /** Домены, которым пора на плановую проверку cron (ТЗ §6). */
    public function dueForCron(int $limit): array
    {
        $st = DB::pdo()->prepare(
            "SELECT domain, site_id, job_id FROM domain_ssl_statuses
              WHERE monitoring_enabled = 1
                AND (next_check_at IS NULL OR next_check_at <= NOW())
                AND (batch_state IS NULL OR batch_state='done')
              ORDER BY (next_check_at IS NULL) DESC, next_check_at ASC
              LIMIT ?"
        );
        $st->bindValue(1, max(1, $limit), PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
}
