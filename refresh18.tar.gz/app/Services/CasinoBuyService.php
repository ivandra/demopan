<?php
/**
 * CasinoBuyService — покупка root-домена для casino-проекта.
 *
 * Использует NamecheapClient из B1 (тот же что и refresh-jobs использует).
 * Логи пишутся через CasinoRunStore::log в таблицу casino_run_events.
 *
 * Стратегия:
 *   1. Проверить — уже куплен? (DNS A резолвится на VPS IP → skip)
 *   2. Сгенерировать кандидатов: base_word + (1..50 суффиксы) × TLDs
 *   3. Batch-проверить доступность через NamecheapClient::checkDomain
 *   4. Отфильтровать по max_price_usd
 *   5. Купить первый подходящий через createDomain
 *   6. Поставить DNS A через setHosts → VPS IP
 *   7. Обновить casino_projects.root_domain
 */
class CasinoBuyService
{
    /**
     * P1-5/P1-6: единая точка эмита candidate.rejected. next_candidate вычисляется по ГЛОБАЛЬНОМУ
     * списку кандидатов (следующий за $cand), а не по текущему batch. reason — только из
     * допустимого набора §4 (domain_unavailable/already_exists/registrar_rejected/reserved/
     * validation_failed/price_over_budget/price_fetch_error/unknown); догадки не вводятся.
     */
    private function emitCandidateRejected(string $runId, array $candidates, string $cand, string $reason): void
    {
        $allowed = ['domain_unavailable','already_exists','registrar_rejected','reserved',
                    'validation_failed','price_over_budget','price_fetch_error','unknown'];
        if (!in_array($reason, $allowed, true)) $reason = 'unknown';
        $idx = array_search($cand, $candidates, true);
        $next = ($idx !== false && isset($candidates[$idx + 1])) ? (string)$candidates[$idx + 1] : '';
        CasinoRunStore::log($runId, 'info',
            "Кандидат отклонён: {$cand} (reason={$reason}).",
            ['event_code' => 'candidate.rejected', 'source' => 'registrar',
             'reason' => $reason, 'candidate' => $cand, 'next_candidate' => $next]);
    }

    /**
     * Главный entry-point. Возвращает массив:
     *   ['ok'=>true, 'domain'=>'kazik5.casino', 'price'=>1.99, 'skipped_purchase'=>false]
     *   ['ok'=>false, 'reason'=>'no_candidates_in_budget']
     */
    public static function execute(array $run, array $project): array
    {
        $runId   = (string)$run['run_id'];
        $input   = is_array($run['input_json'] ?? null)
            ? $run['input_json']
            : (json_decode((string)($run['input_json'] ?? ''), true) ?: []);
        $baseWord = strtolower(trim((string)($input['base_word'] ?? '')));
        $tlds     = is_array($input['tlds'] ?? null) ? array_values($input['tlds']) : ['.casino', '.com', '.net'];
        $maxPrice = (float)($input['max_price_usd'] ?? 50);
        $regAccId = (int)($input['registrar_account_id'] ?? 0);
        $contactId = (int)($input['registrar_contact_id'] ?? 0);
        $vpsIp    = (string)($input['vps_ip'] ?? $project['vps_ip'] ?? '');

        if ($baseWord === '' || !preg_match('~^[a-z0-9][a-z0-9-]{1,30}$~', $baseWord)) {
            return ['ok' => false, 'reason' => 'invalid_base_word'];
        }
        if (empty($tlds))   return ['ok' => false, 'reason' => 'no_tlds'];
        if ($maxPrice <= 0) return ['ok' => false, 'reason' => 'invalid_max_price'];
        if (!$regAccId)     return ['ok' => false, 'reason' => 'no_registrar_account'];
        if (!$contactId)    return ['ok' => false, 'reason' => 'no_registrar_contact'];
        if ($vpsIp === '')  return ['ok' => false, 'reason' => 'no_vps_ip'];

        // ВАЖНО: базовое ограничение цены из config (namecheap.max_price_usd, дефолт 12$).
        // Это hard cap — защита от случайной покупки дорогого премиум-домена.
        // Если юзер ввёл больше — снижаем до конфигурационного потолка.
        $hardCap = (float)config('namecheap.max_price_usd', 12.0);
        if ($maxPrice > $hardCap) {
            CasinoRunStore::log($runId, 'warn', "Запрошенный лимит \${$maxPrice} превышает hard cap config'а (\${$hardCap}). Использую \${$hardCap}.");
            $maxPrice = $hardCap;
        }

        CasinoRunStore::log($runId, 'info', "Старт покупки. Base='{$baseWord}', TLDs=" . implode(',', $tlds) . ", maxUSD={$maxPrice}, vps_ip={$vpsIp}");

        // v0.5-fix10: ЦЕЛЕВОЙ домен — это домен панели (target_domain), а не "base+любой TLD".
        // Юзер хочет root_domain = домен где стоит панель (напр. kazik9.casino).
        $targetDomain = strtolower(trim((string)($input['target_domain'] ?? '')));
        $confirmBuy   = !empty($input['confirm_buy']); // явное подтверждение покупки
        $confirmDifferent = !empty($input['confirm_different_tld']); // подтверждение покупки ДРУГОГО домена

        // Параметры для one-click подтверждения в панели (эхо назад во всех needs_confirmation).
        // Покупка асинхронная (run_id), поэтому панель на странице run'а не знает выбор юзера —
        // возвращаем нужное, чтобы кнопка «Купить» собрала повторный запрос с confirm_buy=1.
        $confirmParams = [
            'registrar_account_id' => $regAccId,
            'registrar_contact_id' => $contactId,
            'max_price_usd'        => $maxPrice,
            'vps_ip'               => $vpsIp,
            'base_word'            => $baseWord,
            'tlds'                 => $tlds,
        ];

        // Грузим Namecheap-аккаунт заранее (нужен для проверки владения)
        $stmtAcc = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'");
        $stmtAcc->execute([$regAccId]);
        $accountEarly = $stmtAcc->fetch();
        $ncEarly = null;
        if ($accountEarly) {
            try {
                $apiKeyE = Crypto::decrypt((string)$accountEarly['api_key_enc']);
                $endpointE = !empty($accountEarly['is_sandbox'])
                    ? (string)config('namecheap.endpoint_sandbox', 'https://api.sandbox.namecheap.com/xml.response')
                    : (string)config('namecheap.endpoint', 'https://api.namecheap.com/xml.response');
                $ncEarly = new NamecheapClient($endpointE, (string)$accountEarly['api_user'], $apiKeyE,
                    (string)($accountEarly['username'] ?? ''), (string)$accountEarly['client_ip'],
                    (int)config('namecheap.timeout', 30));
            } catch (Throwable $e) { $ncEarly = null; }
        }

        // Хелпер: владеем ли мы доменом в Namecheap (getDomainInfo НЕ бросает = владеем)
        $weOwn = function (string $dom) use ($ncEarly): bool {
            if ($ncEarly === null || $dom === '') return false;
            try { $ncEarly->getDomainInfo($dom); return true; }
            catch (Throwable $e) { return false; }
        };

        // === ПРИОРИТЕТ 1: целевой домен (домен панели) ===
        // v0.5-fix19: СНАЧАЛА проверяем ДОСТУПНОСТЬ (checkDomain), и только потом владение.
        // Раньше "уже наш" определялось по "getInfo не бросил" — это давало ложный
        // already_owned (домен помечался купленным за $0, хотя был свободен и не куплен).
        // Свободный домен НЕ может быть нашим, поэтому availability первична.
        if ($targetDomain !== '') {
            $tgtAvailable = null; // null = не удалось проверить
            if ($ncEarly !== null) {
                try {
                    $chk = $ncEarly->checkDomain($targetDomain);
                    $tgtAvailable = !empty($chk['available']);
                } catch (Throwable $e) {
                    CasinoRunStore::log($runId, 'warn', "checkDomain({$targetDomain}) ошибка: " . $e->getMessage());
                    $tgtAvailable = null;
                }
            }

            if ($tgtAvailable === true) {
                // Перепроверка: availability иногда ложно помечает НАШ домен «свободным».
                // Если он в нашем аккаунте — берём как есть, не покупаем повторно.
                if ($weOwn($targetDomain)) {
                    CasinoRunStore::log($runId, 'info', "checkDomain считает {$targetDomain} свободным, но он в нашем Namecheap-аккаунте — берём как есть, покупка не нужна.");
                    CasinoRunStore::setProgress($runId, 100, "Уже наш: {$targetDomain}");
                    return ['ok' => true, 'domain' => $targetDomain, 'price' => 0.0, 'skipped_purchase' => true, 'already_owned' => true];
                }
                // СВОБОДЕН и не наш → покупаем (с подтверждением).
                if (!$confirmBuy) {
                    CasinoRunStore::log($runId, 'info', "Домен {$targetDomain} свободен. Нужно подтверждение покупки.");
                    CasinoRunStore::setProgress($runId, 100, "Нужно подтверждение");
                    return ['ok' => true, 'needs_confirmation' => true, 'confirm_kind' => 'buy_target',
                            'domain' => $targetDomain, 'message' => "Домен {$targetDomain} свободен. Купить его?", 'confirm_params' => $confirmParams];
                }
                $baseWord = preg_replace('~\..+$~', '', $targetDomain);
                $tlds = ['.' . preg_replace('~^[^.]+\.~', '', $targetDomain)]; // только TLD целевого
                CasinoRunStore::log($runId, 'info', "Покупаем целевой домен {$targetDomain} (подтверждено, свободен).");
            } elseif ($tgtAvailable === false) {
                // ЗАНЯТ → возможно наш. Проверяем владение и резолв на VPS.
                if ($weOwn($targetDomain)) {
                    CasinoRunStore::log($runId, 'info', "Домен {$targetDomain} занят и в нашем Namecheap-аккаунте — берём, покупка не нужна.");
                    CasinoRunStore::setProgress($runId, 100, "Уже наш: {$targetDomain}");
                    return ['ok' => true, 'domain' => $targetDomain, 'price' => 0.0, 'skipped_purchase' => true, 'already_owned' => true];
                }
                $resolvedIps = @gethostbynamel($targetDomain) ?: [];
                if (in_array($vpsIp, $resolvedIps, true)) {
                    CasinoRunStore::log($runId, 'info', "Домен {$targetDomain} резолвится на наш VPS {$vpsIp} — берём, покупка не нужна.");
                    CasinoRunStore::setProgress($runId, 100, "Резолвится на наш VPS: {$targetDomain}");
                    return ['ok' => true, 'domain' => $targetDomain, 'price' => 0.0, 'skipped_purchase' => true, 'already_owned' => true];
                }
                // занят и НЕ наш → не покупаем молча, спрашиваем про ДРУГОЙ домен
                if (!$confirmDifferent) {
                    CasinoRunStore::log($runId, 'warn', "Домен {$targetDomain} недоступен (занят) и не в нашем аккаунте. Нужно решение пользователя.");
                    CasinoRunStore::setProgress($runId, 100, "Целевой домен недоступен");
                    return ['ok' => true, 'needs_confirmation' => true, 'confirm_kind' => 'target_unavailable',
                            'domain' => $targetDomain,
                            'message' => "Домен {$targetDomain} недоступен (занят или в другом аккаунте). Купить другой похожий домен вместо него? Это будет ДРУГОЙ домен, не совпадающий с сайтом на VPS.", 'confirm_params' => $confirmParams];
                }
                CasinoRunStore::log($runId, 'info', "Пользователь подтвердил покупку другого домена вместо {$targetDomain}.");
                // confirmDifferent → падаем в поиск кандидатов ниже (baseWord/tlds из input)
            } else {
                // ДОСТУПНОСТЬ НЕ ПРОВЕРЕНА (checkDomain недоступен). НЕ считаем владельцем молча.
                if (!$confirmBuy) {
                    CasinoRunStore::log($runId, 'warn', "Не удалось проверить доступность {$targetDomain}. Нужно подтверждение покупки.");
                    CasinoRunStore::setProgress($runId, 100, "Нужно подтверждение");
                    return ['ok' => true, 'needs_confirmation' => true, 'confirm_kind' => 'buy_target',
                            'domain' => $targetDomain, 'message' => "Не удалось проверить доступность {$targetDomain}. Попробовать купить его?", 'confirm_params' => $confirmParams];
                }
                $baseWord = preg_replace('~\..+$~', '', $targetDomain);
                $tlds = ['.' . preg_replace('~^[^.]+\.~', '', $targetDomain)];
                CasinoRunStore::log($runId, 'info', "Покупаем целевой домен {$targetDomain} (подтверждено, доступность не проверена).");
            }
        }

        // ПРИОРИТЕТ 2 (старое поведение): root_domain проекта уже есть и резолвится
        if ($targetDomain === '' && !empty($project['root_domain'])) {
            $existingDomain = (string)$project['root_domain'];
            $resolvedIps = @gethostbynamel($existingDomain) ?: [];
            if (in_array($vpsIp, $resolvedIps, true)) {
                CasinoRunStore::log($runId, 'info', "Домен {$existingDomain} уже принадлежит проекту и резолвится на {$vpsIp} — purchase skipped.");
                CasinoRunStore::setProgress($runId, 100, "Уже куплен: {$existingDomain}");
                return ['ok' => true, 'domain' => $existingDomain, 'price' => 0.0, 'skipped_purchase' => true];
            }
            CasinoRunStore::log($runId, 'warn', "Проект имеет root_domain={$existingDomain}, но DNS A резолвится в [" . implode(',', $resolvedIps) . "] вместо {$vpsIp}. Продолжаю поиск нового домена.");
        }

        // 2. Получаем Namecheap-аккаунт + контакт через прямой SQL (как DomainPurchaseService)
        $stmt = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'");
        $stmt->execute([$regAccId]);
        $account = $stmt->fetch();

        $stmt = DB::pdo()->prepare("SELECT * FROM registrar_contacts WHERE id=?");
        $stmt->execute([$contactId]);
        $contact = $stmt->fetch();

        if (!$account || !$contact) {
            return ['ok' => false, 'reason' => 'account_or_contact_not_found'];
        }
        $modeLabel = !empty($account['is_sandbox']) ? '🟡 SANDBOX' : '🔴 PROD (реальные деньги)';
        CasinoRunStore::log($runId, 'info', "Namecheap: {$modeLabel}, аккаунт {$account['api_user']}, контакт {$contact['label']} ({$contact['email']})");

        $apiKey = Crypto::decrypt((string)$account['api_key_enc']);
        $endpoint = !empty($account['is_sandbox'])
            ? (string)config('namecheap.endpoint_sandbox', 'https://api.sandbox.namecheap.com/xml.response')
            : (string)config('namecheap.endpoint', 'https://api.namecheap.com/xml.response');
        $client = new NamecheapClient(
            $endpoint,
            (string)$account['api_user'],
            $apiKey,
            (string)($account['username'] ?? ''),
            (string)$account['client_ip'],
            (int)config('namecheap.timeout', 30)
        );

        // 3. Генерация списка кандидатов
        $candidates = self::generateCandidates($baseWord, $tlds, 50);
        CasinoRunStore::log($runId, 'info', "Сгенерировано кандидатов: " . count($candidates));
        CasinoRunStore::setProgress($runId, 10, 'Кандидатов: ' . count($candidates));

        // 4. Batch-проверка доступности (Namecheap позволяет до 50 за запрос)
        $available = [];
        $batchSize = 30;
        $batches = array_chunk($candidates, $batchSize);
        foreach ($batches as $bi => $batch) {
            try {
                // ОДИН запрос на весь батч (было — по запросу на каждый кандидат → рейт-лимит).
                $map = $client->checkDomains($batch);
                foreach ($batch as $cand) {
                    if (!empty($map[strtolower($cand)])) { $available[] = $cand; continue; }
                    // §3.2/§4 + P1-6: candidate.rejected с ГЛОБАЛЬНЫМ next_candidate (по всему $candidates,
                    // не по текущему batch). reason машиночитаемый и не выдуман: недоступен → domain_unavailable.
                    $this->emitCandidateRejected($runId, $candidates, $cand, 'domain_unavailable');
                }
                CasinoRunStore::log($runId, 'info', "Batch " . ($bi + 1) . "/" . count($batches) . ": проверено " . count($batch) . ", свободных накопилось " . count($available));
            } catch (Throwable $e) {
                CasinoRunStore::log($runId, 'warn', "Batch " . ($bi + 1) . " checkDomains failed: " . $e->getMessage());
            }
            if (count($available) >= 5) break; // достаточно кандидатов
        }

        if (empty($available)) {
            CasinoRunStore::log($runId, 'error', "Все ". count($candidates) ." кандидатов заняты. Попробуй другое base_word.");
            return ['ok' => false, 'reason' => 'no_available_domains'];
        }

        CasinoRunStore::log($runId, 'info', "Доступны: " . implode(', ', array_slice($available, 0, 10)));
        CasinoRunStore::setProgress($runId, 40, 'Доступных: ' . count($available));

        // 5. Подбираем по цене
        $picked = null;
        $pickedPrice = 0.0;
        $priceByTld = [];      // кэш: цена зависит от TLD, а не от домена → один запрос на TLD
        $rateLimitHit = false; // ловили ли «Too many requests» при проверке цены
        foreach ($available as $cand) {
            try {
                [$sld, $tld] = $client->splitSldTld($cand);
            } catch (Throwable $e) {
                // P1-5: ошибка валидации/split TLD — тоже отклонение кандидата.
                $this->emitCandidateRejected($runId, $available, $cand, 'validation_failed');
                continue;
            }
            try {
                if (!array_key_exists($tld, $priceByTld)) {
                    $priceByTld[$tld] = (float)$client->getPricingRegister1Y($tld);
                }
                $price = $priceByTld[$tld];
                CasinoRunStore::log($runId, 'info', "Цена {$cand}: \${$price}");
                if ($price > 0 && $price <= $maxPrice) {
                    $picked = $cand;
                    $pickedPrice = $price;
                    break;
                } else if ($price > $maxPrice) {
                    CasinoRunStore::log($runId, 'info', "{$cand} = \${$price} превышает бюджет \${$maxPrice}");
                    // P1-5: цена выше бюджета — отклонение кандидата (не выдумываем причину).
                    $this->emitCandidateRejected($runId, $available, $cand, 'price_over_budget');
                } else {
                    // §5.5: цена <= 0 (не определена/нулевая) — кандидат молча не пропускается,
                    // фиксируем достоверную причину price_fetch_error.
                    $this->emitCandidateRejected($runId, $available, $cand, 'price_fetch_error');
                }
            } catch (Throwable $e) {
                $m = $e->getMessage();
                if (stripos($m, 'Too many requests') !== false || strpos($m, '500000') !== false) $rateLimitHit = true;
                CasinoRunStore::log($runId, 'warn', "Цена для {$cand} не определена: " . $m);
                // P1-5: не удалось получить цену — отклонение кандидата, причина не выдумывается.
                $this->emitCandidateRejected($runId, $available, $cand, 'price_fetch_error');
            }
        }

        if (!$picked) {
            if ($rateLimitHit) {
                // ВАЖНО: рейт-лимит ≠ «нет в бюджете». Домен НЕ покупаем, просим повторить.
                CasinoRunStore::log($runId, 'error', "Namecheap перегружен (Too many requests) — цены проверить не удалось. Домен НЕ куплен. Повтори через минуту.");
                return ['ok' => false, 'reason' => 'namecheap_rate_limited'];
            }
            CasinoRunStore::log($runId, 'error', "Нет кандидатов в бюджете \${$maxPrice}. Цены проверены для " . count($available) . " доступных.");
            return ['ok' => false, 'reason' => 'no_candidates_in_budget'];
        }

        // Точное совпадение = base_word + первый TLD (например kazik7.casino)
        $firstTld = ltrim((string)($tlds[0] ?? '.casino'), '.');
        $exactDomain = $baseWord . '.' . $firstTld;
        $isExact = ($picked === $exactDomain);
        CasinoRunStore::log($runId, $isExact ? 'success' : 'warn',
            $isExact
                ? "Выбран ТОЧНЫЙ домен {$picked} (совпадает с желаемым)."
                : "⚠ Точный домен {$exactDomain} недоступен/дорог. Выбран ближайший свободный: {$picked}.");
        CasinoRunStore::log($runId, 'info', "Покупаю {$picked} за \${$pickedPrice}…");
        CasinoRunStore::setProgress($runId, 60, "Покупка {$picked} за \${$pickedPrice}");

        // 6. Покупка
        // ЗАЩИТА ОТ ГЛЮКА/ДВОЙНОЙ ПОКУПКИ: если checkDomain ошибся и домен уже в нашем
        // Namecheap-аккаунте — НЕ покупаем повторно, берём как есть.
        if ($weOwn($picked)) {
            CasinoRunStore::log($runId, 'warn', "{$picked} уже в нашем Namecheap-аккаунте (availability дала ложный «свободен») — покупка пропущена, деньги не списаны.");
            CasinoRunStore::setProgress($runId, 100, "Уже наш: {$picked}");
            try { CasinoProjectStore::setRootDomain((int)$run['project_id'], $picked); } catch (Throwable $e) {}
            return ['ok' => true, 'domain' => $picked, 'price' => 0.0, 'skipped_purchase' => true, 'already_owned' => true];
        }
        try {
            [$sld, $tld] = $client->splitSldTld($picked);
            $created = $client->createDomain($sld, $tld, 1, [
                'first_name'     => (string)($contact['first_name'] ?? ''),
                'last_name'      => (string)($contact['last_name'] ?? ''),
                'organization'   => (string)($contact['organization'] ?? ''),
                'email'          => (string)($contact['email'] ?? ''),
                'phone'          => (string)($contact['phone'] ?? ''),
                'address1'       => (string)($contact['address1'] ?? ''),
                'address2'       => (string)($contact['address2'] ?? ''),
                'city'           => (string)($contact['city'] ?? ''),
                'state_province' => (string)($contact['state_province'] ?? $contact['state'] ?? ''),
                'postal_code'    => (string)($contact['postal_code'] ?? $contact['zip'] ?? ''),
                'country'        => (string)($contact['country'] ?? ''),
            ]);
            CasinoRunStore::log($runId, 'success', "Куплено! domain_id=" . ($created['domain_id'] ?? '?') . ", order_id=" . ($created['order_id'] ?? '?'));
        } catch (Throwable $e) {
            CasinoRunStore::log($runId, 'error', "Покупка {$picked} провалилась: " . $e->getMessage());
            return ['ok' => false, 'reason' => 'purchase_failed: ' . $e->getMessage()];
        }

        // 7. DNS A на VPS IP
        CasinoRunStore::setProgress($runId, 80, 'Устанавливаю DNS A → ' . $vpsIp);
        try {
            [$sld, $tld] = $client->splitSldTld($picked);
            $hosts = [
                ['host' => '@', 'type' => 'A', 'address' => $vpsIp, 'ttl' => 1800],
                ['host' => '*', 'type' => 'A', 'address' => $vpsIp, 'ttl' => 1800],
            ];
            $client->setHosts($sld, $tld, $hosts);
            CasinoRunStore::log($runId, 'success', "DNS A установлены: @ + * → {$vpsIp}");
        } catch (Throwable $e) {
            CasinoRunStore::log($runId, 'warn', "DNS не установлены (домен куплен но не указывает на VPS): " . $e->getMessage());
        }

        // 8. Сохраняем в casino_projects
        try {
            CasinoProjectStore::setRootDomain((int)$run['project_id'], $picked);
        } catch (Throwable $e) {
            CasinoRunStore::log($runId, 'warn', "Не удалось сохранить root_domain в casino_projects: " . $e->getMessage());
        }

        CasinoRunStore::setProgress($runId, 100, "Готово: {$picked}");
        return ['ok' => true, 'domain' => $picked, 'price' => $pickedPrice, 'skipped_purchase' => false];
    }

    /**
     * Генератор кандидатов: base + (без суффикса), base + 1..N, base+cas, base+casino, etc.
     * Возвращает массив доменов вида "kazik.casino", "kazik1.casino", ...
     */
    public static function generateCandidates(string $baseWord, array $tlds, int $maxNumeric = 50): array
    {
        $variants = [$baseWord];
        for ($i = 1; $i <= $maxNumeric; $i++) {
            $variants[] = $baseWord . $i;
        }
        $suffixes = ['cas', 'casino', 'club', 'play', 'spin', 'win', 'bet'];
        foreach ($suffixes as $s) {
            $variants[] = $baseWord . $s;
            $variants[] = $baseWord . '-' . $s;
        }

        $candidates = [];
        foreach ($variants as $v) {
            foreach ($tlds as $tld) {
                $tld = ltrim((string)$tld, '.');
                $candidates[] = $v . '.' . $tld;
            }
        }
        return array_values(array_unique($candidates));
    }
}
