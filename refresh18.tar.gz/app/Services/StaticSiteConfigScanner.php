<?php

/**
 * StaticSiteConfigScanner — распознаёт ТОЛЬКО статические присваивания текущего
 * парка. Fail-closed: любая динамика/неизвестная/дубликат/конфликт → blocked до записи.
 *
 * Token-aware: сначала token_get_all(TOKEN_PARSE). Присваивания реконструируются из
 * токенов (T_VARIABLE [ ['key'] ]* = 'static-string' ;), поэтому текст вида
 * $sub_id = ... ВНУТРИ строкового литерала occurrence'ом не является.
 * Байтовые offset'ы значений — через сумму длин текстов токенов.
 */
final class StaticSiteConfigScanner
{
    private const URL_FIELDS = [
        'redirect_url', 'base_new_url', 'base_second_url',
        'internal_reg_url', 'partner_override_url',
    ];

    public function scan(string $raw): ConfigScanResult
    {
        if (trim($raw) === '') return ConfigScanResult::parseError('empty_config');
        try {
            $tokens = token_get_all($raw, TOKEN_PARSE);
        } catch (\ParseError $e) {
            return ConfigScanResult::parseError('php_parse_error');
        }

        $assignments = [];
        $seenPaths = [];
        $stmt = [];       // значимые токены текущего statement: [id,text,off]
        $off = 0;
        $ignore = [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT, T_OPEN_TAG, T_OPEN_TAG_WITH_ECHO, T_CLOSE_TAG, T_INLINE_HTML];

        $flush = function (array $st) use (&$assignments, &$seenPaths) {
            return $this->processStatement($st, $assignments, $seenPaths);
        };

        foreach ($tokens as $tk) {
            if (is_array($tk)) {
                $text = $tk[1]; $id = $tk[0];
                $sig = !in_array($id, $this->ignoreIds(), true);
                if ($sig) $stmt[] = ['id' => $id, 'text' => $text, 'off' => $off];
            } else {
                $text = $tk;
                $stmt[] = ['id' => null, 'text' => $text, 'off' => $off];
                if ($tk === ';' || $tk === '{' || $tk === '}') {
                    $res = $this->processStatement($stmt, $assignments, $seenPaths);
                    if ($res instanceof ConfigScanResult) return $res; // blocker
                    $stmt = [];
                }
            }
            $off += strlen($text);
        }
        // хвост без ; (маловероятно для config)
        if ($stmt) {
            $res = $this->processStatement($stmt, $assignments, $seenPaths);
            if ($res instanceof ConfigScanResult) return $res;
        }

        // конфликт разных активных значений sub_id
        $active = [];
        foreach ($assignments as $a) {
            if ($a['kind'] === 'bare_sub') $active[] = (string)$a['sub_value'];
            elseif ($a['kind'] === 'url_field' && $a['sub_value'] !== null) $active[] = (string)$a['sub_value'];
        }
        if (count(array_unique($active)) > 1) {
            return ConfigScanResult::blocked('sub_id_conflict', array_values(array_unique($active)));
        }

        return ConfigScanResult::ok($assignments);
    }

    private function ignoreIds(): array
    {
        $ids = [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT, T_OPEN_TAG, T_CLOSE_TAG, T_INLINE_HTML];
        if (defined('T_OPEN_TAG_WITH_ECHO')) $ids[] = T_OPEN_TAG_WITH_ECHO;
        return $ids;
    }

    /**
     * @return ConfigScanResult|null  ConfigScanResult => блокер (stop); null => продолжаем.
     */
    private function processStatement(array $stmt, array &$assignments, array &$seenPaths)
    {
        // отбросить закрывающий ; / { / }
        while ($stmt && in_array(end($stmt)['text'], [';', '{', '}'], true)) array_pop($stmt);
        if (!$stmt) return null;
        if ($stmt[0]['id'] !== T_VARIABLE) return null; // не присваивание переменной

        // индекс верхнеуровневого '=' (не '=>', не '==')
        $eq = -1;
        foreach ($stmt as $i => $t) { if ($t['id'] === null && $t['text'] === '=') { $eq = $i; break; } }
        if ($eq < 1) return null;

        $lhs = array_slice($stmt, 0, $eq);
        $rhs = array_slice($stmt, $eq + 1);

        // LHS: $var (['key'])*
        $var = ltrim($lhs[0]['text'], '$');
        $keys = [];
        $i = 1; $ok = true;
        while ($i < count($lhs)) {
            if ($lhs[$i]['text'] === '[' && isset($lhs[$i + 1], $lhs[$i + 2])
                && $lhs[$i + 1]['id'] === T_CONSTANT_ENCAPSED_STRING && $lhs[$i + 2]['text'] === ']') {
                $keys[] = $this->unquote($lhs[$i + 1]['text']); $i += 3;
            } else { $ok = false; break; }
        }
        $lastKey = $keys ? end($keys) : $var;
        $path = $var . ($keys ? '.' . implode('.', $keys) : '');

        // RHS статичен? (ровно один T_CONSTANT_ENCAPSED_STRING)
        $rhsStatic = (count($rhs) === 1 && $rhs[0]['id'] === T_CONSTANT_ENCAPSED_STRING);
        $rhsTok = $rhsStatic ? $rhs[0] : null;
        $value = $rhsStatic ? $this->unquote($rhsTok['text']) : null;

        $isUrlField = in_array($lastKey, self::URL_FIELDS, true);
        $isBareSub  = (!$keys && in_array($var, ['sub_id', 'subid'], true));
        $isArraySub = ($keys && in_array($lastKey, ['sub_id', 'subid'], true));
        $isDomain   = ($lastKey === 'domain');

        // Вложенный СТАТИЧЕСКИЙ array-литерал: $site = [ 'domain'=>..., 'redirect'=>[...] ];
        // (реальный формат Enomo). Пути: array:site.domain, array:site.redirect.<url_field>.
        if ($ok && !$keys && $this->isArrayOpen($rhs)) {
            return $this->scanArrayLiteral($var, $rhs, $assignments, $seenPaths);
        }

        // Неразобранный сложный LHS: блокируем, если пахнет sub_id
        if (!$ok) {
            if ($isUrlField || $isBareSub || $isArraySub) {
                return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path]);
            }
            return null;
        }

        // Известное URL-поле
        if ($isUrlField) {
            if (!$rhsStatic) return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path]);
            [$param, $sub, $cnt] = $this->extractSub($value);
            if ($cnt > 1) return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path, 'reason' => 'multiple_sub_params']);
            $this->recordDup($path, $seenPaths); if ($this->dupHit) return ConfigScanResult::blocked('duplicate_config_field', ['path' => $path]);
            $assignments[] = ['path' => 'variable:' . $lastKey, 'kind' => 'url_field', 'field' => $lastKey,
                'value' => $value, 'rhs_offset' => $rhsTok['off'], 'rhs_text' => $rhsTok['text'],
                'sub_param' => $param, 'sub_value' => $sub];
            return null;
        }

        // Голый sub_id/subid
        if ($isBareSub) {
            if (!$rhsStatic) return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path]);
            $this->recordDup($path, $seenPaths); if ($this->dupHit) return ConfigScanResult::blocked('duplicate_config_field', ['path' => $path]);
            $assignments[] = ['path' => 'variable:' . $var, 'kind' => 'bare_sub', 'field' => $var,
                'value' => $value, 'rhs_offset' => $rhsTok['off'], 'rhs_text' => $rhsTok['text'],
                'sub_param' => null, 'sub_value' => $value];
            return null;
        }

        // Массивный ключ sub_id/subid — неподдерживаемая форма (fail-closed, S07)
        if ($isArraySub) {
            return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path]);
        }

        // domain (только статический учитываем; динамический $domain игнорируем —
        // домен всё равно меняется строковой трансформацией)
        if ($isDomain && $rhsStatic) {
            $this->recordDup($path, $seenPaths); if ($this->dupHit) return ConfigScanResult::blocked('duplicate_config_field', ['path' => $path]);
            $assignments[] = ['path' => 'variable:domain', 'kind' => 'domain', 'field' => 'domain',
                'value' => $value, 'rhs_offset' => $rhsTok['off'], 'rhs_text' => $rhsTok['text'],
                'sub_param' => null, 'sub_value' => null];
            return null;
        }
        // ТЗ044 §3.4: динамический $domain фиксируется (kind=domain_dynamic) для fail-closed
        // в mutation-контракте. Не влияет на isSafe/activeSubIds/domainRequired.
        if ($isDomain && !$rhsStatic) {
            $assignments[] = ['path' => 'variable:domain', 'kind' => 'domain_dynamic', 'field' => 'domain',
                'value' => null, 'rhs_offset' => null, 'rhs_text' => null,
                'sub_param' => null, 'sub_value' => null];
            return null;
        }

        // Прочее поле: если статическое значение несёт sub_id-параметр в URL — это
        // tracking в неизвестном поле → блок (fail-closed). Иначе не относится к делу.
        if ($rhsStatic) {
            [$param, $sub, $cnt] = $this->extractSub($value);
            if ($cnt >= 1) return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path]);
        }
        return null;
    }

    /** @var bool флаг дубликата (устанавливается recordDup) */
    private bool $dupHit = false;
    private function recordDup(string $path, array &$seen): void
    {
        $this->dupHit = isset($seen[$path]);
        $seen[$path] = true;
    }

    private function isArrayOpen(array $rhs): bool
    {
        if (!$rhs) return false;
        $t = $rhs[0];
        return ($t['id'] === null && $t['text'] === '[') || ($t['id'] === T_ARRAY);
    }

    /**
     * Классификация листьев статического вложенного array-литерала.
     * @return ConfigScanResult|null  блокер | null (продолжаем)
     */
    private function scanArrayLiteral(string $var, array $rhs, array &$assignments, array &$seenPaths)
    {
        $i = 0; $block = null;
        $leaves = $this->parseArray($rhs, $i, $block);
        if ($block instanceof ConfigScanResult) return $block;

        foreach ($leaves as $lf) {
            $keys = $lf['keys'];
            $lastKey = (string)end($keys);
            $path = 'array:' . $var . '.' . implode('.', $keys);
            $isUrl = in_array($lastKey, self::URL_FIELDS, true);
            $isSub = in_array($lastKey, ['sub_id', 'subid'], true);
            $isDom = ($lastKey === 'domain');

            if ($lf['dynamic']) {
                if ($isUrl || $isSub) return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path]);
                if ($isDom) { // ТЗ044 §3.4: динамический domain в массиве → fail-closed marker
                    $assignments[] = ['path' => $path, 'kind' => 'domain_dynamic', 'field' => 'domain',
                        'value' => null, 'rhs_offset' => null, 'rhs_text' => null, 'sub_param' => null, 'sub_value' => null];
                }
                continue;
            }
            $value = $this->unquote($lf['valTok']['text']);

            if ($isUrl) {
                [$param, $sub, $cnt] = $this->extractSub($value);
                if ($cnt > 1) return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path, 'reason' => 'multiple_sub_params']);
                $this->recordDup($path, $seenPaths); if ($this->dupHit) return ConfigScanResult::blocked('duplicate_config_field', ['path' => $path]);
                $assignments[] = ['path' => $path, 'kind' => 'url_field', 'field' => $lastKey,
                    'value' => $value, 'rhs_offset' => $lf['valTok']['off'], 'rhs_text' => $lf['valTok']['text'],
                    'sub_param' => $param, 'sub_value' => $sub];
            } elseif ($isDom) {
                $this->recordDup($path, $seenPaths); if ($this->dupHit) return ConfigScanResult::blocked('duplicate_config_field', ['path' => $path]);
                $assignments[] = ['path' => $path, 'kind' => 'domain', 'field' => 'domain',
                    'value' => $value, 'rhs_offset' => $lf['valTok']['off'], 'rhs_text' => $lf['valTok']['text'],
                    'sub_param' => null, 'sub_value' => null];
            } elseif ($isSub) {
                return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path]);
            } else {
                [$p, $s, $cnt] = $this->extractSub($value);
                if ($cnt >= 1) return ConfigScanResult::blocked('unrecognized_sub_id_field', ['path' => $path]);
            }
        }
        return null;
    }

    /**
     * Рекурсивный парсер статического array-литерала над значимыми токенами (с offset'ами).
     * @return array список листьев ['keys'=>[...],'valTok'=>?,'dynamic'=>bool]
     */
    private function parseArray(array $t, int &$i, &$block): array
    {
        $leaves = [];
        $n = count($t);
        // opener
        if (($t[$i]['id'] ?? null) === T_ARRAY) { $i++; if ($i < $n && ($t[$i]['text'] ?? '') === '(') $i++; $close = ')'; }
        else { $i++; $close = ']'; } // '['

        while ($i < $n && $t[$i]['text'] !== $close) {
            // ключ (только строковый статический ключ)
            $key = null;
            if (($t[$i]['id'] ?? null) === T_CONSTANT_ENCAPSED_STRING
                && isset($t[$i + 1]) && ($t[$i + 1]['id'] ?? null) === T_DOUBLE_ARROW) {
                $key = $this->unquote($t[$i]['text']); $i += 2;
            }
            if ($i >= $n) break;

            // значение
            if (($t[$i]['id'] ?? null) === T_ARRAY || (($t[$i]['id'] ?? null) === null && $t[$i]['text'] === '[')) {
                $sub = $this->parseArray($t, $i, $block);
                if ($block instanceof ConfigScanResult) return $leaves;
                if ($key !== null) {
                    foreach ($sub as $lf) { array_unshift($lf['keys'], $key); $leaves[] = $lf; }
                }
            } elseif (($t[$i]['id'] ?? null) === T_CONSTANT_ENCAPSED_STRING) {
                if ($key !== null) $leaves[] = ['keys' => [$key], 'valTok' => $t[$i], 'dynamic' => false];
                $i++;
            } else {
                // динамическое значение — фиксируем как dynamic и пропускаем до ',' / close на глубине 0
                if ($key !== null) $leaves[] = ['keys' => [$key], 'valTok' => null, 'dynamic' => true];
                $depth = 0;
                while ($i < $n) {
                    $tx = $t[$i]['text'];
                    if ($tx === '[' || $tx === '(' || ($t[$i]['id'] ?? null) === T_ARRAY) { $depth++; }
                    elseif ($tx === ']' || $tx === ')') { if ($depth === 0) break; $depth--; }
                    elseif ($tx === ',' && $depth === 0) { break; }
                    $i++;
                }
            }
            if ($i < $n && $t[$i]['text'] === ',') $i++;
        }
        if ($i < $n && $t[$i]['text'] === $close) $i++; // consume close
        return $leaves;
    }

    /** @return array [param|null, value|null, count] */
    private function extractSub(string $urlValue): array
    {
        if (preg_match_all('~[?&](sub_id|subid|sub)=([^&#]*)~i', $urlValue, $m, PREG_SET_ORDER)) {
            if (count($m) === 1) return [strtolower($m[0][1]), $m[0][2], 1];
            return [null, null, count($m)];
        }
        return [null, null, 0];
    }

    private function unquote(string $tok): string
    {
        if (strlen($tok) >= 2) {
            $q = $tok[0];
            if (($q === '"' || $q === "'") && substr($tok, -1) === $q) {
                $inner = substr($tok, 1, -1);
                // снять экранирование кавычки и слэша (достаточно для config-значений)
                return str_replace(['\\' . $q, '\\\\'], [$q, '\\'], $inner);
            }
        }
        return $tok;
    }
}
