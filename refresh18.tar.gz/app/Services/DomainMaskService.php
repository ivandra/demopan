<?php

/**
 * DomainMaskService — генерация нового домена и нового sub_id.
 *
 * v21 (fix-mask v2). Изменения относительно старой версии:
 *
 * ── 1. Единый движок инкремента ───────────────────────────────────────────
 * Раньше в классе было ДВЕ независимые реализации, и они расходились:
 *   incrementTrailingNumber()  regex ^(.*?)(\d+)$        — требовал цифры В КОНЦЕ
 *   nextSubId()                regex ^(.*?)(\d+)([^\d]*)$ — допускал буквы после числа
 * Из-за этого домен с хвостовыми буквами ломался:
 *   vodka104x.casino → vodka104x2.casino   (цифра лепилась в конец)
 * Теперь правило одно для домена и для sub_id.
 *
 * ── 2. sub_id синхронизируется с ДОМЕНОМ ──────────────────────────────────
 * Главная проблема на проде: sub_id брался из конфига сайта и инкрементился
 * НЕЗАВИСИМО от домена. Если конфиг не обновлялся — панель вечно выдавала одно
 * и то же значение. Пример из БД (сайт 7k5212): домен прошёл 7k5212 → 7k5265
 * за 28 джоб, а sub_id все 28 раз генерился как 7k5212 → 7k5213. Разрыв 52.
 * Теперь число sub_id берётся из НОВОГО ДОМЕНА, а собственный префикс/хвост
 * sub_id сохраняются:
 *   домен volna-205.casino + sub Mvolna202 → Mvolna205
 *   домен pokerdom24.casino + sub Dpokerdom17 → Dpokerdom24
 *
 * ── 3. Стратегия letter — счётчик в буквах ────────────────────────────────
 * Для sub_id, где число является частью БРЕНДА и трогать его нельзя, а
 * счётчиком служат буквы:
 *   A_azino_777df_casino → A_azino_777dg_casino   (777 не меняется, df → dg)
 * Сдвигается последняя буква буквенной группы, идущей сразу после числа.
 * При переполнении группа расширяется (dz → ea, z → aa) — число не трогается.
 *
 * ── 4. Префикс сотрудника ─────────────────────────────────────────────────
 * Опция (по умолчанию ВЫКЛЮЧЕНА): дописать префикс, если его нет.
 *   prefix_enabled=1, prefix='A_'  →  azino_777df → A_azino_777df
 *
 * ── Правила, подтверждённые оператором ────────────────────────────────────
 * 1) Инкремент последней группы цифр, хвостовые буквы сохраняются:
 *      vodka104x → vodka105x,  7k5265 → 7k5266,  7k-200 → 7k-201
 * 2) Цифр нет вообще — число дописывается в конец:  pinko → pinko2
 * 3) Ведущие нули сохраняются:  vodka007 → vodka008
 * 4) Буквенный счётчик — сдвиг последней буквы:  ...777df... → ...777dg...
 *
 * ── Параметры ─────────────────────────────────────────────────────────────
 * Глобальные — в app_settings (ключи mask.*).
 * Персональные на сайт — sites_managed.mask_settings_json (перекрывают глобальные).
 * Фабрика: DomainMaskService::forSite($siteRow).
 *
 * Совместимо с PHP 7.4.
 */
class DomainMaskService
{
    /** Дефолтные параметры генерации. */
    const DEFAULTS = [
        'strategy'         => 'number',                     // number | letter
        'step'             => 1,
        'pad_zeros'        => true,
        'no_digit_start'   => 2,
        'letter_alphabet'  => 'abcdefghijklmnopqrstuvwxyz',
        'letter_wrap'      => true,     // при 'z' расширять группу (dz→ea); иначе — инкремент числа
        'sync_with_domain' => true,     // число sub_id брать из нового домена
        'prefix_enabled'   => false,    // дописывать префикс сотрудника
        'prefix'           => '',       // например 'A_'
    ];

    /** @var array */
    private $opts;

    /**
     * @param array $override      Точечное переопределение параметров.
     * @param bool  $ignoreGlobals v5 (P1): не читать app_settings — только DEFAULTS + override.
     *                             Нужно для строгого snapshot'а джобы.
     */
    public function __construct(array $override = [], bool $ignoreGlobals = false)
    {
        $this->opts = $this->loadOpts($override, $ignoreGlobals);
    }

    /**
     * Фабрика с персональными настройками сайта.
     * $site — строка sites_managed (нужна колонка mask_settings_json).
     * Если use_global=1 или колонки нет — работают глобальные настройки.
     */
    public static function forSite($site): self
    {
        $per = [];
        $raw = '';
        if (is_array($site)) {
            $raw = (string)($site['mask_settings_json'] ?? '');
        } elseif (is_string($site)) {
            $raw = $site;
        }

        if ($raw !== '') {
            $j = json_decode($raw, true);
            if (is_array($j) && empty($j['use_global'])) {
                unset($j['use_global']);
                $per = $j;
            }
        }
        return new self($per);
    }

    /**
     * v4 (B1, B5): сервис из НЕИЗМЕНЯЕМОГО snapshot'а настроек джобы.
     *
     * Раньше настройки читались заново на каждой стадии (создание джобы, покупка,
     * пересчёт sub_id, построение плана). Если оператор менял глобальные или
     * персональные параметры, пока джоба стояла в очереди, разные стадии одной
     * джобы работали с разными стратегиями. Плюс сама покупка вообще игнорировала
     * персональные настройки сайта.
     *
     * Snapshot пишется в refresh_jobs.artifacts_json.mask_options_snapshot при
     * создании джобы и далее используется всеми стадиями без обращения к БД.
     *
     * @param string|array $artifactsJson JSON или уже распакованный массив
     */
    public static function fromJobSnapshot($artifactsJson): self
    {
        $opts = [];

        $arr = null;
        if (is_array($artifactsJson)) {
            $arr = $artifactsJson;
        } elseif (is_string($artifactsJson) && trim($artifactsJson) !== '') {
            $decoded = json_decode($artifactsJson, true);
            if (is_array($decoded)) $arr = $decoded;
        }

        if (is_array($arr)
            && isset($arr['mask_options_snapshot'])
            && is_array($arr['mask_options_snapshot'])
        ) {
            $opts = $arr['mask_options_snapshot'];
        }

        return new self($opts);
    }

    /**
     * v5 (P1): СТРОГИЙ snapshot джобы.
     *
     * Прежний fromJobSnapshot() работал fail-open: при пустом, битом или неполном
     * snapshot конструктор всё равно читал текущие app_settings, и джоба незаметно
     * переключалась на глобальную маску (при глобальном step=9 пустой snapshot давал
     * 7k109 вместо ожидаемого 7k105). Это ломало саму гарантию неизменяемости.
     *
     * Здесь: параметры строятся ТОЛЬКО из DEFAULTS + snapshot, app_settings не читается.
     * Отсутствие или повреждение snapshot'а — исключение, а не тихий откат.
     *
     * @throws \RuntimeException если snapshot отсутствует или неполон
     */
    public static function fromJobSnapshotStrict($artifactsJson): self
    {
        $arr = null;
        if (is_array($artifactsJson)) {
            $arr = $artifactsJson;
        } elseif (is_string($artifactsJson) && trim($artifactsJson) !== '') {
            $decoded = json_decode($artifactsJson, true);
            if (is_array($decoded)) $arr = $decoded;
        }

        if (!is_array($arr) || !isset($arr['mask_options_snapshot']) || !is_array($arr['mask_options_snapshot'])) {
            throw new \RuntimeException(
                'mask_options_snapshot отсутствует в artifacts_json джобы. '
                . 'Джоба создана до внедрения snapshot или запись повреждена.'
            );
        }

        $snap = $arr['mask_options_snapshot'];
        $missing = [];
        foreach (array_keys(self::DEFAULTS) as $key) {
            if (!array_key_exists($key, $snap)) $missing[] = $key;
        }
        if ($missing) {
            throw new \RuntimeException(
                'mask_options_snapshot неполон, отсутствуют ключи: ' . implode(', ', $missing)
            );
        }

        // DEFAULTS + snapshot, без обращения к app_settings
        return new self($snap, true);
    }

    /**
     * Полный набор параметров для записи в snapshot джобы.
     */
    public function snapshotPayload(): array
    {
        return $this->opts;
    }

    /** Текущие параметры (для UI и логов). */
    public function options(): array
    {
        return $this->opts;
    }

    private function loadOpts(array $override, bool $ignoreGlobals = false): array
    {
        $o = self::DEFAULTS;

        try {
            if (!$ignoreGlobals && class_exists('AppSettings')) {
                $o['strategy']         = (string)AppSettings::getRaw('mask.strategy', $o['strategy']);
                $o['step']             = (int)AppSettings::getInt('mask.step', $o['step']);
                $o['pad_zeros']        = (bool)AppSettings::getBool('mask.pad_zeros', $o['pad_zeros']);
                $o['no_digit_start']   = (int)AppSettings::getInt('mask.no_digit_start', $o['no_digit_start']);
                $o['letter_alphabet']  = (string)AppSettings::getRaw('mask.letter_alphabet', $o['letter_alphabet']);
                $o['letter_wrap']      = (bool)AppSettings::getBool('mask.letter_wrap', $o['letter_wrap']);
                $o['sync_with_domain'] = (bool)AppSettings::getBool('mask.sync_with_domain', $o['sync_with_domain']);
                $o['prefix_enabled']   = (bool)AppSettings::getBool('mask.prefix_enabled', $o['prefix_enabled']);
                $o['prefix']           = (string)AppSettings::getRaw('mask.prefix', $o['prefix']);
            }
        } catch (\Throwable $e) {
            // Настройки недоступны — работаем на дефолтах.
        }

        foreach ($override as $k => $v) {
            if (array_key_exists($k, $o)) {
                $o[$k] = $v;
            }
        }

        return $this->sanitizeOpts($o);
    }

    private function sanitizeOpts(array $o): array
    {
        if (!in_array($o['strategy'], ['number', 'letter'], true)) {
            $o['strategy'] = 'number';
        }

        $o['step'] = (int)$o['step'];
        if ($o['step'] < 1)    $o['step'] = 1;
        if ($o['step'] > 1000) $o['step'] = 1000;

        $o['no_digit_start'] = (int)$o['no_digit_start'];
        if ($o['no_digit_start'] < 0)      $o['no_digit_start'] = 0;
        if ($o['no_digit_start'] > 999999) $o['no_digit_start'] = 999999;

        // v4 (B4): алфавит нормализуем до УНИКАЛЬНЫХ символов и требуем минимум два.
        // Алфавит из повторов ('aa') раньше давал вечный цикл: значение не менялось.
        $abc = strtolower(preg_replace('~[^A-Za-z]~', '', (string)$o['letter_alphabet']));
        $abc = implode('', array_unique(str_split($abc !== '' ? $abc : '')));
        $o['letter_alphabet'] = strlen($abc) >= 2 ? $abc : self::DEFAULTS['letter_alphabet'];

        // Префикс: безопасный набор символов для трекинг-параметра
        $pref = preg_replace('~[^A-Za-z0-9_\-]~', '', (string)$o['prefix']);
        $o['prefix'] = substr((string)$pref, 0, 16);

        $o['pad_zeros']        = (bool)$o['pad_zeros'];
        $o['letter_wrap']      = (bool)$o['letter_wrap'];
        $o['sync_with_domain'] = (bool)$o['sync_with_domain'];
        $o['prefix_enabled']   = (bool)$o['prefix_enabled'];

        return $o;
    }

    private function resolve(array $override): array
    {
        return $override ? $this->sanitizeOpts(array_merge($this->opts, $override)) : $this->opts;
    }

    /* ===================== РАЗБОР ТОКЕНА ===================== */

    /**
     * Разобрать токен на [префикс][последняя группа цифр][хвост не-цифр].
     *   'vodka104x'            → prefix='vodka',     num='104', suffix='x'
     *   '7k5265'               → prefix='7k',        num='5265', suffix=''
     *   'A_azino_777df_casino' → prefix='A_azino_',  num='777', suffix='df_casino'
     *   'pinko'                → has_num=false
     */
    public function parseToken(string $token): array
    {
        if (preg_match('~^(.*?)(\d+)([^\d]*)$~', $token, $m)) {
            return ['prefix' => $m[1], 'num' => $m[2], 'suffix' => $m[3], 'has_num' => true];
        }
        return ['prefix' => $token, 'num' => '', 'suffix' => '', 'has_num' => false];
    }

    /* ===================== ИНКРЕМЕНТ ===================== */

    /**
     * Инкремент токена по текущей стратегии (домен или автономный sub_id).
     */
    public function incrementToken(string $token, array $override = []): string
    {
        $token = (string)$token;
        if ($token === '') return '';

        $o = $this->resolve($override);
        $p = $this->parseToken($token);

        if ($o['strategy'] === 'letter') {
            return $this->shiftLetters($token, $p, $o);
        }

        // Правило 2: цифр нет вообще — дописываем число в конец.
        if (!$p['has_num']) {
            return $token . $o['no_digit_start'];
        }

        return $this->bumpNumber($p, $o);
    }

    /**
     * Правила 1 и 3: +step к последней группе цифр; хвостовые буквы
     * и ведущие нули сохраняются.
     */
    private function bumpNumber(array $p, array $o): string
    {
        // v4 (H5): строковая арифметика — (int) ломался на числах длиннее PHP_INT_MAX
        // (brand9223372036854775807 → brand9.2233720368548E+18).
        $newNum = $this->addNumericStrings($p['num'], (string)(int)$o['step']);

        if (!empty($o['pad_zeros'])
            && strlen($p['num']) > 1
            && $p['num'][0] === '0'
            && strlen($newNum) < strlen($p['num'])
        ) {
            $newNum = str_pad($newNum, strlen($p['num']), '0', STR_PAD_LEFT);
        }

        return $p['prefix'] . $newNum . $p['suffix'];
    }

    /**
     * v4 (H5): сложение двух неотрицательных целых, представленных строками.
     * Не зависит от диапазона PHP int. Использует bcadd, если доступен.
     */
    private function addNumericStrings(string $a, string $b): string
    {
        if (function_exists('bcadd')) {
            return bcadd($a === '' ? '0' : $a, $b === '' ? '0' : $b, 0);
        }

        $a = ltrim($a, '0');
        $b = ltrim($b, '0');
        if ($a === '') $a = '0';
        if ($b === '') $b = '0';

        $i = strlen($a) - 1;
        $j = strlen($b) - 1;
        $carry = 0;
        $res = '';

        while ($i >= 0 || $j >= 0 || $carry > 0) {
            $sum = $carry;
            if ($i >= 0) { $sum += (int)$a[$i]; $i--; }
            if ($j >= 0) { $sum += (int)$b[$j]; $j--; }
            $res = ((string)($sum % 10)) . $res;
            $carry = intdiv($sum, 10);
        }

        return $res === '' ? '0' : $res;
    }

    /**
     * Правило 4: буквенный счётчик.
     * Сдвигается буквенная группа, идущая сразу ПОСЛЕ числа
     * ('A_azino_777df_casino' → группа 'df' → 'dg' → 'A_azino_777dg_casino').
     * Если числа нет — сдвигается хвостовая буквенная группа токена.
     * Число (часть бренда) не изменяется.
     */
    private function shiftLetters(string $token, array $p, array $o): string
    {
        $abc = (string)$o['letter_alphabet'];

        if ($p['has_num']) {
            $suffix = (string)$p['suffix'];
            if ($suffix !== '' && preg_match('~^([A-Za-z]+)~', $suffix, $mm)) {
                list($newRun, $carry) = $this->incLetterRun($mm[1], $abc, !empty($o['letter_wrap']));
                if (!$carry) {
                    return $p['prefix'] . $p['num'] . $newRun . substr($suffix, strlen($mm[1]));
                }
                // Переполнение при выключенном wrap — инкрементим число.
                return $this->bumpNumber($p, $o);
            }
            // Букв после числа нет вовсе — счётчику не за что зацепиться,
            // безопасно инкрементируем число (бренд-числа тут нет по определению).
            return $this->bumpNumber($p, $o);
        }

        // Числа нет вовсе: сдвигаем хвостовую буквенную группу.
        if (preg_match('~([A-Za-z]+)$~', $token, $mm)) {
            list($newRun, $carry) = $this->incLetterRun($mm[1], $abc, !empty($o['letter_wrap']));
            if (!$carry) {
                return substr($token, 0, strlen($token) - strlen($mm[1])) . $newRun;
            }
        }

        return $token . $o['no_digit_start'];
    }

    /**
     * Инкремент буквенной группы как счётчика по алфавиту.
     *   df → dg,  dz → ea,  z → aa,  zz → aaa
     * Регистр каждой позиции сохраняется.
     *
     * @return array [newRun, carryToNumber]
     */
    private function incLetterRun(string $run, string $abc, bool $wrap): array
    {
        $chars = str_split($run);
        $i = count($chars) - 1;
        $len = strlen($abc);

        while ($i >= 0) {
            $c = $chars[$i];
            $isUpper = ctype_upper($c);
            $pos = strpos($abc, strtolower($c));

            if ($pos === false) {
                // v4 (B4): раньше был тихий фолбэк на инкремент числа — а это
                // возвращало исходный критический дефект: у sub_id вида
                // A_azino_777df_casino менялось 777 (часть бренда).
                // Теперь — явная ошибка, оператор чинит алфавит или стратегию.
                throw new \RuntimeException(
                    "Буква '{$c}' отсутствует в алфавите счётчика ('{$abc}'). "
                    . "Исправьте алфавит в настройках маски или переключите сайт на стратегию 'number'."
                );
            }

            if ($pos + 1 < $len) {
                $nc = $abc[$pos + 1];
                $chars[$i] = $isUpper ? strtoupper($nc) : $nc;
                return [implode('', $chars), false];
            }

            if (!$wrap) {
                // Перенос выключен: расширять группу нельзя, а менять число нельзя
                // (оно может быть частью бренда) — сообщаем явно.
                throw new \RuntimeException(
                    "Счётчик '{$run}' достиг конца алфавита, а перенос выключен. "
                    . "Включите перенос букв или измените sub_id вручную."
                );
            }

            $nc = $abc[0];
            $chars[$i] = $isUpper ? strtoupper($nc) : $nc;
            $i--;
        }

        // Все позиции переполнились — расширяем группу (z → aa).
        $first = ctype_upper($run[0]) ? strtoupper($abc[0]) : $abc[0];
        return [$first . implode('', $chars), false];
    }

    /** Опциональный префикс сотрудника (по умолчанию выключен). */
    private function applyPrefix(string $sub, array $o): string
    {
        if (empty($o['prefix_enabled'])) return $sub;
        $p = (string)$o['prefix'];
        if ($p === '' || $sub === '') return $sub;
        if (strpos($sub, $p) === 0) return $sub; // уже есть
        return $p . $sub;
    }

    /* ===================== ХОСТ / SLD / TLD ===================== */

    public function extractHost(string $url): string
    {
        $u = trim($url);
        $u = preg_replace('~^https?://~i', '', $u);
        $u = preg_replace('~^www\.~i', '', $u);
        $u = preg_replace('~[/?#].*$~', '', $u);
        $u = preg_replace('~:\d+$~', '', $u);
        return strtolower(trim($u));
    }

    public function splitSldTld(string $host): array
    {
        $host = $this->extractHost($host);
        if ($host === '' || strpos($host, '.') === false) {
            return ['', ''];
        }

        $parts = explode('.', $host);
        $multiTlds = [
            'co.uk','co.kr','co.jp','com.au','com.br','com.cn','com.hk','com.mx','com.ru','com.tr',
            'co.in','co.za','co.nz',
        ];

        if (count($parts) >= 3) {
            $last2 = $parts[count($parts) - 2] . '.' . $parts[count($parts) - 1];
            if (in_array($last2, $multiTlds, true)) {
                $tld = $last2;
                $sld = implode('.', array_slice($parts, 0, -2));
                return [$sld, $tld];
            }
        }

        $tld = array_pop($parts);
        $sld = implode('.', $parts);
        return [$sld, $tld];
    }

    /* ===================== ДОМЕН ===================== */

    /**
     * Следующий домен по маске. Возвращает host (без схемы).
     *   vodka104x.casino → vodka105x.casino
     *   7k5265.casino    → 7k5266.casino
     *
     * Домен всегда считается по числовой стратегии: буквенный счётчик —
     * это соглашение sub_id, к покупке доменов оно не применяется.
     */
    public function nextDomain(string $currentDomain, array $override = []): string
    {
        $host = $this->extractHost($currentDomain);
        list($sld, $tld) = $this->splitSldTld($host);

        if ($sld === '' || $tld === '') {
            return '';
        }

        $o = $this->resolve($override);
        $o['strategy'] = 'number';

        $p = $this->parseToken($sld);
        $newSld = $p['has_num'] ? $this->bumpNumber($p, $o) : ($sld . $o['no_digit_start']);

        $host = $newSld . '.' . $tld;

        // v4 (H5): не отдаём заведомо невалидный хост наружу — его бы попытались купить.
        return $this->isValidHost($host) ? $host : '';
    }

    /**
     * N следующих доменов (когда первые кандидаты заняты).
     */
    public function nextDomains(string $currentDomain, int $count, array $override = []): array
    {
        $out = [];
        $cur = $currentDomain;
        for ($i = 0; $i < $count; $i++) {
            $next = $this->nextDomain($cur, $override);
            if ($next === '') break;
            $out[] = $next;
            $cur = $next;
        }
        return $out;
    }

    /**
     * v4 (H5): проверка, что сгенерированный host синтаксически валиден.
     * Защищает от попытки купить домен вида brand9.2233720368548E+18.casino.
     */
    public function isValidHost(string $host): bool
    {
        if ($host === '' || strpos($host, '.') === false) return false;
        if (strlen($host) > 253) return false;

        foreach (explode('.', $host) as $label) {
            if ($label === '' || strlen($label) > 63) return false;
            if (!preg_match('~^[a-z0-9]([a-z0-9-]*[a-z0-9])?$~i', $label)) return false;
        }
        return true;
    }

    /* ===================== SUB_ID ===================== */

    /**
     * ОСНОВНОЙ метод: новый sub_id с учётом нового домена.
     *
     * strategy=number + sync_with_domain=1 (дефолт):
     *   число берётся из НОВОГО ДОМЕНА, префикс/хвост sub_id сохраняются.
     *     ('Mvolna202', 'volna-205.casino')   → 'Mvolna205'
     *     ('7k5212',    '7k5265.casino')      → '7k5265'
     *     ('vodka104x', 'vodka105x.casino')   → 'vodka105x'
     *     ('sykaknopka','sykaaa-casino5.top') → 'sykaknopka5'  (в sub нет цифр)
     *
     * strategy=letter:
     *   число не трогаем (бренд), сдвигаем буквенный счётчик.
     *     ('A_azino_777df_casino', любой домен) → 'A_azino_777dg_casino'
     *
     * Если домен без цифр или sync выключен — автономный инкремент (nextSubId).
     */
    public function subIdForDomain(string $oldSubId, string $newDomain, array $override = []): string
    {
        $oldSubId = trim($oldSubId);
        if ($oldSubId === '') return '';

        $o = $this->resolve($override);

        // Буквенный счётчик — от домена не зависит (число = бренд).
        if ($o['strategy'] === 'letter') {
            return $this->applyPrefix($this->incrementToken($oldSubId, $o), $o);
        }

        if (!empty($o['sync_with_domain']) && trim($newDomain) !== '') {
            list($sld, $tld) = $this->splitSldTld($newDomain);
            if ($sld !== '') {
                $dp = $this->parseToken($sld);
                if ($dp['has_num']) {
                    $sp = $this->parseToken($oldSubId);
                    $new = $sp['has_num']
                        ? $sp['prefix'] . $dp['num'] . $sp['suffix']   // число из домена
                        : $oldSubId . $dp['num'];                      // в sub цифр не было
                    return $this->applyPrefix($new, $o);
                }
            }
        }

        // Фолбэк — автономный инкремент.
        return $this->applyPrefix($this->incrementToken($oldSubId, $o), $o);
    }

    /**
     * Автономный инкремент sub_id (без привязки к домену).
     * Оставлен для обратной совместимости и как фолбэк.
     *   vodka104x → vodka105x,  Dstake204 → Dstake205,  pinko → pinko2
     */
    public function nextSubId(string $oldSubId, array $override = []): string
    {
        $oldSubId = trim($oldSubId);
        if ($oldSubId === '') return '';
        $o = $this->resolve($override);
        return $this->applyPrefix($this->incrementToken($oldSubId, $o), $o);
    }

    /**
     * Получить sub_id из URL.
     * https://x.com/l/abc?sub_id=Dirwincasino102 → Dirwincasino102
     */
    public function extractSubIdFromUrl(string $url): string
    {
        if ($url === '') return '';
        $parts = @parse_url($url);
        if (!is_array($parts) || empty($parts['query'])) return '';
        parse_str((string)$parts['query'], $q);
        return (string)($q['sub_id'] ?? '');
    }

    /**
     * v21: найти sub_id в распознанном config.php сайта.
     *
     * sub_id живёт не только в internal_reg_url. По боевой базе:
     *   base_new_url     — 31 сайт
     *   base_second_url  — 31 сайт
     *   internal_reg_url — 28 сайтов
     * У части сайтов internal_reg_url ПУСТОЙ (например mellstroy112), и раньше
     * панель не находила sub_id вообще: в карточке не было строк sub_id,
     * а в джобу уходил пустой new_sub_id.
     *
     * @return array ['sub_id' => string, 'field' => string] — field пуст, если не найден
     */
    public function extractSubIdFromConfig(array $config): array
    {
        // v4 (H6): приоритет — ПАРТНЁРСКИЕ ссылки. Именно в них живёт боевой sub_id,
        // по которому партнёрка считает трафик. На sykaaa-casino5.top значения
        // расходятся (internal_reg_url='sykaknopka', base_new_url='syka4'),
        // и правильным является значение из партнёрской ссылки.
        $fields = ['base_new_url', 'base_second_url', 'internal_reg_url', 'partner_override_url'];

        $found = [];

        foreach ($fields as $f) {
            $val = (string)($config[$f] ?? '');
            if ($val === '') continue;

            $sub = $this->extractSubIdFromUrl($val);
            if ($sub === '') {
                // URL мог быть без схемы или с нестандартным видом — берём регуляркой
                if (preg_match('~[?&]sub_id=([^&"\'\s<>#]+)~i', $val, $m)) {
                    $sub = $m[1];
                }
            }
            if ($sub !== '') {
                $found[$f] = $sub;
            }
        }

        if (!$found) {
            return ['sub_id' => '', 'field' => '', 'conflict' => [], 'all' => []];
        }

        $firstField = array_key_first($found);
        $distinct   = array_values(array_unique($found));

        return [
            'sub_id'   => $found[$firstField],
            'field'    => $firstField,
            // Расхождение значений между полями — повод показать оператору предупреждение.
            'conflict' => count($distinct) > 1 ? $found : [],
            'all'      => $found,
        ];
    }

    /**
     * Установить sub_id в URL (заменяет значение или добавляет параметр).
     */
    public function setSubIdInUrl(string $url, string $newSubId): string
    {
        if ($url === '') return '';
        $parts = @parse_url($url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) return $url;

        $query = [];
        if (!empty($parts['query'])) parse_str((string)$parts['query'], $query);
        $query['sub_id'] = $newSubId;
        $parts['query'] = http_build_query($query, '', '&', PHP_QUERY_RFC3986);

        return $this->unparseUrl($parts);
    }

    private function unparseUrl(array $p): string
    {
        $scheme   = isset($p['scheme']) ? $p['scheme'] . '://' : '';
        $user     = $p['user'] ?? '';
        $pass     = isset($p['pass']) ? ':' . $p['pass'] : '';
        $auth     = ($user !== '' || $pass !== '') ? $user . $pass . '@' : '';
        $host     = $p['host'] ?? '';
        $port     = isset($p['port']) ? ':' . $p['port'] : '';
        $path     = $p['path'] ?? '';
        $query    = isset($p['query']) && $p['query'] !== '' ? '?' . $p['query'] : '';
        $fragment = isset($p['fragment']) ? '#' . $p['fragment'] : '';
        return $scheme . $auth . $host . $port . $path . $query . $fragment;
    }
}
