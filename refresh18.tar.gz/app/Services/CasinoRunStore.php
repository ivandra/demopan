<?php

/**
 * CasinoRunStore — обёртка над таблицами casino_runs / casino_run_events.
 *
 * Концепция: каждое долгое действие (купить домен, прописать поддомены и т.д.)
 * — это «run». casino-panel дёргает «start», получает run_id, поллит status.
 * Под капотом cron refresh-panel'и каждую минуту смотрит runs в state='queued'
 * и продвигает их.
 */
class CasinoRunStore
{
    /** Сгенерировать публичный run_id. */
    public static function generateRunId(): string
    {
        return bin2hex(random_bytes(8)); // 16 hex chars
    }

    /**
     * Создать новый run. Возвращает run_id.
     */
    public static function create(int $projectId, string $kind, array $input): string
    {
        $runId = self::generateRunId();
        $st = DB::pdo()->prepare(
            "INSERT INTO casino_runs (run_id, project_id, kind, state, input_json)
             VALUES (?,?,?,?,?)"
        );
        $st->execute([
            $runId, $projectId, $kind, 'queued',
            json_encode($input, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);
        self::log($runId, 'info', "Run создан (kind=$kind)");
        return $runId;
    }

    public static function loadByRunId(string $runId): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM casino_runs WHERE run_id = ?");
        $st->execute([$runId]);
        $r = $st->fetch();
        return $r ?: null;
    }

    public static function updateState(string $runId, string $state, array $patch = []): void
    {
        $sets = ['state = ?'];
        $vals = [$state];
        foreach ($patch as $k => $v) {
            $sets[] = "$k = ?";
            $vals[] = $v;
        }
        if ($state === 'running' && empty($patch['started_at'])) {
            $sets[] = 'started_at = CURRENT_TIMESTAMP';
        }
        if (in_array($state, ['done', 'failed', 'cancelled'], true)) {
            $sets[] = 'finished_at = CURRENT_TIMESTAMP';
        }
        $vals[] = $runId;
        $sql = "UPDATE casino_runs SET " . implode(', ', $sets) . " WHERE run_id = ?";
        $st = DB::pdo()->prepare($sql);
        $st->execute($vals);
    }

    public static function setProgress(string $runId, int $progress, string $message): void
    {
        $st = DB::pdo()->prepare(
            "UPDATE casino_runs SET progress = ?, last_message = ?,
             tick_count = tick_count + 1 WHERE run_id = ?"
        );
        $st->execute([max(0, min(100, $progress)), $message, $runId]);
    }

    public static function log(string $runId, string $level, string $message, ?array $payload = null): void
    {
        try {
            $st = DB::pdo()->prepare(
                "INSERT INTO casino_run_events (run_id, level, message, payload_json)
                 VALUES (?,?,?,?)"
            );
            $st->execute([
                $runId, $level, $message,
                $payload !== null
                    ? json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                    : null,
            ]);
        } catch (Throwable $e) { /* never break primary flow */ }
    }

    public static function loadEvents(string $runId, int $limit = 200): array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM casino_run_events WHERE run_id = ? ORDER BY id ASC LIMIT ?"
        );
        $st->bindValue(1, $runId);
        $st->bindValue(2, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }

    /**
     * Найти queued/running run'ы для cron-обработки.
     * Лимит по умолчанию маленький — cron не должен зависать.
     */
    public static function pickQueuedRuns(int $limit = 3): array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM casino_runs
             WHERE state = 'queued'
             ORDER BY id ASC
             LIMIT ?"
        );
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }

    public static function listRunsForProject(int $projectId, int $limit = 50): array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM casino_runs WHERE project_id = ? ORDER BY id DESC LIMIT ?"
        );
        $st->bindValue(1, $projectId, PDO::PARAM_INT);
        $st->bindValue(2, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }

    public static function toApiArray(array $row, bool $withEvents = false): array
    {
        $out = [
            'run_id'       => (string)$row['run_id'],
            'project_id'   => (int)$row['project_id'],
            'kind'         => (string)$row['kind'],
            'state'        => (string)$row['state'],
            'progress'     => (int)$row['progress'],
            'last_message' => $row['last_message'],
            'error'        => $row['error'],
            'tick_count'   => (int)$row['tick_count'],
            'started_at'   => $row['started_at'],
            'finished_at'  => $row['finished_at'],
            'created_at'   => $row['created_at'],
            'updated_at'   => $row['updated_at'],
            'input'        => $row['input_json'] ? json_decode((string)$row['input_json'], true) : null,
            'result'       => $row['result_json'] ? json_decode((string)$row['result_json'], true) : null,
        ];
        if ($withEvents) {
            $out['events'] = array_map(function ($e) {
                return [
                    'ts'      => (string)$e['ts'],
                    'level'   => (string)$e['level'],
                    'message' => (string)$e['message'],
                    'payload' => $e['payload_json'] ? json_decode((string)$e['payload_json'], true) : null,
                ];
            }, self::loadEvents((string)$row['run_id']));
        }
        return $out;
    }
}
