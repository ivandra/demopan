<?php

/**
 * PATCH 047 revision 2 §17 — единая политика распознавания critical routing failure.
 *
 * Любой WebmasterTransportException с critical reason НЕ должен быть поглощён никаким catch
 * внутри production Yandex call-path (превращён в temporary/optional/not_found/OK). Этот helper
 * даёт единственный источник истины о том, что считать critical routing failure, чтобы orchestrator
 * И все вложенные сервисы (WmHostPollingService, SiteWebmasterMappingService, MoveStatusChecker,
 * fetchRobotsFromApi, IndexCheck) вели себя одинаково.
 *
 * critical  = source_ip_mismatch | bind_failed | resolve_failed | unexpected_redirect
 * transient = network_timeout (обычный retry на ТОМ ЖЕ IP; смены IP нет)
 */
class WebmasterRoutingFailurePolicy
{
    public const CRITICAL_REASONS = [
        WebmasterTransportException::SOURCE_IP_MISMATCH,
        WebmasterTransportException::BIND_FAILED,
        WebmasterTransportException::RESOLVE_FAILED,
        WebmasterTransportException::UNEXPECTED_REDIRECT,
    ];

    /** Найти исходное WebmasterTransportException в цепочке getPrevious(). */
    public static function extract(\Throwable $e): ?WebmasterTransportException
    {
        $cur = $e;
        while ($cur instanceof \Throwable) {
            if ($cur instanceof WebmasterTransportException) return $cur;
            $cur = $cur->getPrevious();
        }
        return null;
    }

    /** Является ли исключение (или его причина в цепочке) critical routing failure. */
    public static function isCritical(\Throwable $e): bool
    {
        $te = self::extract($e);
        return $te !== null && in_array($te->getReason(), self::CRITICAL_REASONS, true);
    }

    /** Является ли исключение транзиентной routing-ошибкой (network_timeout). */
    public static function isTransient(\Throwable $e): bool
    {
        $te = self::extract($e);
        return $te !== null && $te->getReason() === WebmasterTransportException::NETWORK_TIMEOUT;
    }

    /** reason routing-исключения или null, если это не routing failure. */
    public static function reason(\Throwable $e): ?string
    {
        $te = self::extract($e);
        return $te !== null ? $te->getReason() : null;
    }
}
