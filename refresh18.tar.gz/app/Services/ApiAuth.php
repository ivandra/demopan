<?php

/**
 * ApiAuth — проверка API-ключей внешних потребителей (Casino Panel, и т.п.).
 *
 * Использование в API-контроллере:
 *   $client = ApiAuth::require('webmaster.credentials');
 *   // $client = ['id'=>int, 'label'=>string, 'scopes'=>[...]]
 *
 * Возвращает только если ключ валиден и scope разрешён. Иначе делает
 * jsonErr() + exit (401/403).
 *
 * Ключ передаётся в заголовке Authorization: Bearer <ключ>.
 */
class ApiAuth
{
    /**
     * Сгенерировать новый API-ключ.
     * Формат: prefix.body — где prefix 8 символов (для отображения), body 32 символа.
     * Полный ключ — 41 символ.
     */
    public static function generateKey(): string
    {
        $prefix = bin2hex(random_bytes(4)); // 8 hex chars
        $body   = bin2hex(random_bytes(16)); // 32 hex chars
        return $prefix . '.' . $body;
    }

    public static function hashKey(string $rawKey): string
    {
        return hash('sha256', $rawKey);
    }

    public static function keyPrefix(string $rawKey): string
    {
        $i = strpos($rawKey, '.');
        return $i !== false ? substr($rawKey, 0, $i) : substr($rawKey, 0, 8);
    }

    /**
     * Достать raw-ключ из заголовка Authorization. Возвращает '' если нет.
     */
    public static function extractKey(): string
    {
        $h = '';
        if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
            $h = (string)$_SERVER['HTTP_AUTHORIZATION'];
        } elseif (function_exists('getallheaders')) {
            $all = getallheaders() ?: [];
            foreach ($all as $k => $v) {
                if (strcasecmp($k, 'Authorization') === 0) { $h = (string)$v; break; }
            }
        }
        if ($h === '') return '';
        if (stripos($h, 'Bearer ') === 0) return trim(substr($h, 7));
        return trim($h);
    }

    /**
     * Найти клиента по сырому ключу. Возвращает row или null.
     * НЕ проверяет scope, только валидность ключа.
     */
    public static function findClient(string $rawKey): ?array
    {
        if ($rawKey === '') return null;
        $hash = self::hashKey($rawKey);
        $st = DB::pdo()->prepare(
            "SELECT * FROM api_clients WHERE key_hash = ? AND revoked_at IS NULL LIMIT 1"
        );
        $st->execute([$hash]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /**
     * Главная функция: проверить ключ + scope. На ошибке делает exit.
     *
     * @param string $requiredScope например 'webmaster.credentials'. Можно пустую строку — тогда только аутентификация.
     * @return array client row
     */
    public static function require(string $requiredScope = ''): array
    {
        header('Content-Type: application/json; charset=utf-8');

        $key = self::extractKey();
        if ($key === '') {
            self::abort(401, 'auth_required', 'Provide Authorization: Bearer <api_key>');
        }

        try {
            $client = self::findClient($key);
        } catch (Throwable $e) {
            // Скорее всего таблица api_clients ещё не мигрирована
            self::abort(503, 'api_not_initialized',
                'API table missing — run /system/diagnose or apply migration 020.');
        }

        if (!$client) {
            self::abort(401, 'invalid_key', 'API key is invalid or revoked');
        }

        // Проверка scope
        if ($requiredScope !== '') {
            $scopes = self::parseScopes((string)($client['scopes'] ?? ''));
            if (!in_array('*', $scopes, true) && !in_array($requiredScope, $scopes, true)) {
                self::abort(403, 'scope_denied', "Scope '$requiredScope' not allowed for this key");
            }
        }

        // Лог использования (best-effort, без падений)
        try {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
            $upd = DB::pdo()->prepare(
                "UPDATE api_clients SET last_used_at = CURRENT_TIMESTAMP, last_used_ip = ? WHERE id = ?"
            );
            $upd->execute([$ip, (int)$client['id']]);
        } catch (Throwable $e) {
            // ignore
        }

        return [
            'id'     => (int)$client['id'],
            'label'  => (string)$client['label'],
            'scopes' => self::parseScopes((string)($client['scopes'] ?? '')),
        ];
    }

    public static function parseScopes(string $raw): array
    {
        $out = [];
        foreach (preg_split('~[,\s]+~', trim($raw)) ?: [] as $s) {
            $s = trim($s);
            if ($s !== '') $out[] = $s;
        }
        return $out;
    }

    /**
     * Аккуратный JSON-error с правильным HTTP-кодом + exit.
     */
    public static function abort(int $code, string $errKind, string $message): void
    {
        http_response_code($code);
        if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok'    => false,
            'error' => $errKind,
            'message' => $message,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * Стандартный JSON-ok response + exit.
     */
    public static function ok(array $data = []): void
    {
        if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => true] + $data,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}
