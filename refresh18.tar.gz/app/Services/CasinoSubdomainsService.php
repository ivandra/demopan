<?php
/**
 * CasinoSubdomainsService — B3: поддомены casino-проекта.
 *
 * Логика ТОЧНО как в Hub (SiteSubdomainsController::applyBatch):
 *   1. DNS Namecheap: ИНДИВИДУАЛЬНЫЕ A-записи на каждый поддомен (host=label, type=A,
 *      address=IP, ttl=300). IP берётся от A(@) корневого домена (detectRootA),
 *      fallback на vps_ip. Существующие записи МЕРЖАТСЯ (не стираются).
 *      ВАЖНО: НЕ wildcard '*' в DNS — каждый сабдомен своей A-записью.
 *   2. FastPanel: alias = ОДИН wildcard '*.<domain>' через setSiteAliasesExact.
 *      (DDoS-Guard / хостинг разруливает wildcard на стороне FP-вхоста.)
 *   3. SSL: self-signed с CN=<domain>, SAN='*.<domain>', применяется к vhost.
 *
 * Guard: перед setHosts проверяем что getHosts вернул >= 2 записи — иначе
 * подозрительно (можем стереть всю зону), пропускаем DNS.
 */
class CasinoSubdomainsService
{
    public static function execute(array $run, array $project): array
    {
        $runId = (string)$run['run_id'];
        $input = is_array($run['input_json'] ?? null)
            ? $run['input_json']
            : (json_decode((string)($run['input_json'] ?? ''), true) ?: []);

        $rootDomain = strtolower(trim((string)($project['root_domain'] ?? '')));
        $fpServerId = (int)($project['fp_server_id'] ?? 0);
        $fpSiteId   = (int)($project['fp_site_id'] ?? 0);
        $vpsIp      = (string)($project['vps_ip'] ?? '');
        $regAccId   = (int)($project['registrar_account_id'] ?? ($input['registrar_account_id'] ?? 0));

        // Список LABELS поддоменов (без корня, без TLD): arkada, ez-cash, ...
        // Из input.subdomains (FQDN или label) либо из sites проекта.
        $labels = [];
        $rawSubs = is_array($input['subdomains'] ?? null) ? $input['subdomains'] : [];
        if (empty($rawSubs)) {
            $sites = CasinoProjectStore::loadSites((int)$project['id']);
            foreach ($sites as $s) {
                $host = strtolower(trim((string)($s['host'] ?? '')));
                if ($host === '' || $host === $rootDomain || $host === 'www.' . $rootDomain) continue;
                $rawSubs[] = $host;
            }
        }
        // Преобразуем FQDN → label (убираем .<root>)
        foreach ($rawSubs as $sub) {
            $sub = strtolower(trim((string)$sub));
            if ($sub === '') continue;
            // если это FQDN вида arkada.kazik7.casino → label=arkada
            if ($rootDomain !== '' && substr($sub, -strlen('.' . $rootDomain)) === '.' . $rootDomain) {
                $label = substr($sub, 0, -strlen('.' . $rootDomain));
            } else {
                $label = $sub; // уже label
            }
            $label = trim($label, '.');
            // ВАЖНО: '*' (wildcard) НЕ должен попадать в DNS как A-запись.
            // Wildcard живёт только в FastPanel-алиасах. В DNS — конкретные поддомены.
            // (Как Hub: mergeDnsHostsUpsertSubA ставит только реальные labels.)
            if ($label === '*' || strpos($label, '*') !== false) continue;
            if ($label !== '' && $label !== '_default' && $label !== '_main') $labels[$label] = true;
        }
        $labels = array_keys($labels);
        sort($labels);

        if ($rootDomain === '') return ['ok' => false, 'reason' => 'no_root_domain (купи root-домен в B2)'];
        if ($fpServerId <= 0 || $fpSiteId <= 0) return ['ok' => false, 'reason' => 'no_fp_server_or_site_id'];
        if (empty($labels)) return ['ok' => false, 'reason' => 'no_subdomains'];

        CasinoRunStore::log($runId, 'info', "B3 старт. Root={$rootDomain}, labels=" . count($labels) . " (" . implode(', ', array_slice($labels, 0, 10)) . (count($labels) > 10 ? '…' : '') . ")");

        $result = [
            'ok'            => true,
            'labels'        => $labels,
            'dns_applied'   => false,
            'dns_error'     => '',
            'fp_alias'      => false,
            'fp_error'      => '',
            'ssl_applied'   => false,
            'ssl_error'     => '',
            'target_ip'     => '',
        ];

        // ============ FastPanel client ============
        $stmt = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $stmt->execute([$fpServerId]);
        $server = $stmt->fetch();
        if (!$server) return ['ok' => false, 'reason' => "fp_server #{$fpServerId} not found"];

        $fp = null;
        try {
            $fpPass = Crypto::decrypt((string)$server['password_enc']);
            $fp = new FastpanelClient(
                (string)$server['host'],
                (bool)($server['verify_tls'] ?? false),
                (int)config('fastpanel.timeout', 30)
            );
            $fp->login((string)$server['username'], $fpPass);
        } catch (Throwable $e) {
            return ['ok' => false, 'reason' => 'fp_login_failed: ' . $e->getMessage()];
        }

        // ============ 1) DNS Namecheap — индивидуальные A на каждый label ============
        CasinoRunStore::setProgress($runId, 25, 'DNS: A-записи поддоменов');
        if ($regAccId > 0) {
            try {
                $stmt = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'");
                $stmt->execute([$regAccId]);
                $account = $stmt->fetch();
                if (!$account) throw new RuntimeException("registrar_account #{$regAccId} not found");

                $apiKey = Crypto::decrypt((string)$account['api_key_enc']);
                $endpoint = !empty($account['is_sandbox'])
                    ? (string)config('namecheap.endpoint_sandbox', 'https://api.sandbox.namecheap.com/xml.response')
                    : (string)config('namecheap.endpoint', 'https://api.namecheap.com/xml.response');
                $nc = new NamecheapClient(
                    $endpoint,
                    (string)$account['api_user'],
                    $apiKey,
                    (string)($account['username'] ?? ''),
                    (string)$account['client_ip'],
                    (int)config('namecheap.timeout', 30)
                );

                [$sld, $tld] = $nc->splitSldTld($rootDomain);

                // Читаем существующие записи
                $existing = $nc->getHosts($sld, $tld);

                // GUARD: если записей <2 — подозрительно, не трогаем (защита от стирания зоны)
                if (count($existing) < 2) {
                    throw new RuntimeException('Подозрительно мало DNS-записей (' . count($existing) . '), пропускаю setHosts чтобы не стереть зону');
                }

                // IP = A(@) корня, fallback vps_ip
                $targetIp = self::detectRootAFromHosts($existing);
                if ($targetIp === '') $targetIp = $vpsIp;
                if ($targetIp === '') throw new RuntimeException('Не удалось определить target IP (нет A(@) и нет vps_ip)');
                $result['target_ip'] = $targetIp;

                CasinoRunStore::log($runId, 'info', "DNS target IP={$targetIp} (от A(@) корня). Существующих записей: " . count($existing));

                // Мерж: убираем старые A для наших labels (и www.label), добавляем свежие
                $merged = self::mergeDnsHostsUpsertSubA($existing, $labels, $targetIp, 300, $rootDomain);

                $nc->setHosts($sld, $tld, $merged);
                CasinoRunStore::log($runId, 'success', "DNS: добавлено " . count($labels) . " A-записей поддоменов → {$targetIp} (всего записей в зоне: " . count($merged) . ")");
                $result['dns_applied'] = true;
            } catch (Throwable $e) {
                $result['dns_error'] = $e->getMessage();
                CasinoRunStore::log($runId, 'warn', "DNS не настроен: " . $e->getMessage());
            }
        } else {
            $result['dns_error'] = 'no_registrar_account_id';
            CasinoRunStore::log($runId, 'warn', "DNS пропущен: у проекта нет registrar_account_id");
        }

        // ============ 2) FastPanel alias = КОНКРЕТНЫЕ зеркала на каждый поддомен ============
        CasinoRunStore::setProgress($runId, 55, 'FastPanel: алиасы поддоменов');
        try {
            // Конкретные алиасы (зеркала) на каждый поддомен. БЕЗ www и БЕЗ wildcard.
            // setSiteAliasesExact заменяет список целиком, поэтому собираем ВСЕ сразу.
            $aliases = [];
            foreach ($labels as $lb) {
                $aliases[] = $lb . '.' . $rootDomain;
            }
            $aliases = array_values(array_unique($aliases));
            $fp->setSiteAliasesExact($fpSiteId, $aliases);
            CasinoRunStore::log($runId, 'success', "FastPanel: " . count($aliases) . " алиасов установлены на vhost #{$fpSiteId}: " . implode(', ', array_slice($aliases, 0, 8)) . (count($aliases) > 8 ? '…' : ''));
            $result['fp_alias'] = true;
            $result['fp_aliases'] = $aliases;
        } catch (Throwable $e) {
            $result['fp_error'] = $e->getMessage();
            CasinoRunStore::log($runId, 'warn', "FastPanel alias не установлен: " . $e->getMessage());
        }

        // ============ 3) SSL self-signed, SAN = конкретные поддомены ============
        CasinoRunStore::setProgress($runId, 75, 'SSL: self-signed');
        try {
            $email = (string)($input['ssl_email'] ?? config('fastpanel.ssl_email', ''));
            if ($email === '') $email = 'admin@' . $rootDomain;
            // SAN покрывает каждый поддомен (конкретные, без www, без wildcard).
            // FastPanel принимает alternative_name списком через запятую.
            $sanList = [];
            foreach ($labels as $lb) {
                $sanList[] = $lb . '.' . $rootDomain;
            }
            $sanList = array_values(array_unique($sanList));
            $desiredAlt = implode(',', $sanList);

            // Проверим — нет ли уже self-signed для этого домена
            $certificates = [];
            try { $certificates = $fp->certificates(); } catch (Throwable $e) {}
            $existingId = self::findSelfSignedFor(is_array($certificates) ? $certificates : [], $rootDomain);

            if ($existingId > 0) {
                $fp->applyCertificateToSite($fpSiteId, $existingId, false, false, true, false);
                CasinoRunStore::log($runId, 'success', "SSL: переиспользован self-signed cert #{$existingId}, применён к vhost");
                $result['ssl_applied'] = true;
            } else {
                $created = $fp->createSelfSignedCertificate($fpSiteId, $email, $rootDomain, $desiredAlt, 2048, 365);
                $newId = (int)($created['id'] ?? $created['data']['id'] ?? 0);
                if ($newId <= 0) throw new RuntimeException('createSelfSignedCertificate не вернул id: ' . json_encode($created, JSON_UNESCAPED_UNICODE));

                CasinoRunStore::log($runId, 'success', "SSL: self-signed cert #{$newId} создан (CN={$rootDomain}, SAN={$desiredAlt})");
                try { $fp->waitQueueSslCertificateJob($fpSiteId, $newId, 60, 2); } catch (Throwable $e) {
                    CasinoRunStore::log($runId, 'info', "Ожидание генерации: " . $e->getMessage());
                }
                $fp->applyCertificateToSite($fpSiteId, $newId, false, false, true, false);
                CasinoRunStore::log($runId, 'success', "SSL: cert #{$newId} применён к vhost #{$fpSiteId} (HTTP/2 вкл)");
                $result['ssl_applied'] = true;
            }
        } catch (Throwable $e) {
            $result['ssl_error'] = $e->getMessage();
            CasinoRunStore::log($runId, 'warn', "SSL не настроен (поддомены работают по HTTP): " . $e->getMessage());
        }

        // ============ 4) Статус проекта ============
        try {
            $stmt = DB::pdo()->prepare("UPDATE casino_projects SET status='subs_ready', updated_at=? WHERE id=?");
            $stmt->execute([date('Y-m-d H:i:s'), (int)$project['id']]);
        } catch (Throwable $e) {}

        CasinoRunStore::setProgress($runId, 100, 'Поддомены готовы');
        $result['aliases_added'] = count($labels);
        return $result;
    }

    /**
     * IP из A(@) записи (как Hub::detectRootAFromHosts).
     */
    private static function detectRootAFromHosts(array $hosts): string
    {
        foreach ($hosts as $h) {
            if (!is_array($h)) continue;
            $host = strtolower(trim((string)($h['host'] ?? '')));
            $type = strtoupper(trim((string)($h['type'] ?? '')));
            if ($host !== '@' || $type !== 'A') continue;
            $ip = trim((string)($h['address'] ?? ''));
            if ($ip !== '' && preg_match('~^(?:\d{1,3}\.){3}\d{1,3}$~', $ip)) return $ip;
        }
        return '';
    }

    /**
     * Мерж DNS: удаляем старые A для наших labels + www.label, добавляем свежие.
     * Чужие записи (@ A, MX, TXT и т.д.) сохраняем. (Как Hub::mergeDnsHostsUpsertSubA.)
     */
    private static function mergeDnsHostsUpsertSubA(array $existing, array $labels, string $ip, int $ttl = 300, string $rootDomain = ''): array
    {
        $labelsSet = [];
        $wwwLabelsSet = [];
        foreach ($labels as $l) {
            $l = strtolower(trim((string)$l));
            if ($l === '' || $l === '_default') continue;
            $labelsSet[$l] = true;
            $wwwLabelsSet['www.' . $l] = true;
        }

        $out = [];
        $hasWwwRoot = false;
        foreach ($existing as $h) {
            if (!is_array($h)) continue;
            $host = strtolower(trim((string)($h['host'] ?? '')));
            $type = strtoupper(trim((string)($h['type'] ?? '')));
            $addr = trim((string)($h['address'] ?? ''));
            if ($host === '' || $type === '' || $addr === '') continue;
            // удаляем старую wildcard A '*' — в DNS она не нужна (только в FP-алиасах),
            // и могла остаться от прошлой ошибочной записи (как на kazik7)
            if ($type === 'A' && $host === '*') continue;
            // выкидываем старые записи для наших labels (перезапишем)
            if (isset($labelsSet[$host]) || isset($wwwLabelsSet[$host])) continue;
            // отметим есть ли уже www корня (любого типа)
            if ($host === 'www') $hasWwwRoot = true;
            $out[] = $h;
        }

        // добавляем свежие A на каждый label
        foreach (array_keys($labelsSet) as $l) {
            $out[] = ['host' => $l, 'type' => 'A', 'address' => $ip, 'ttl' => $ttl];
        }

        // www CNAME на корень (www.<root> → <root>), если ещё нет и известен root-домен
        if ($rootDomain !== '' && !$hasWwwRoot) {
            $out[] = ['host' => 'www', 'type' => 'CNAME', 'address' => $rootDomain . '.', 'ttl' => $ttl];
        }

        return $out;
    }

    /**
     * Ищет self-signed с CN=domain (как Hub::findSelfSignedFor). Возвращает cert id или 0.
     */
    private static function findSelfSignedFor(array $certificates, string $domain): int
    {
        $domain = strtolower(trim($domain));
        foreach ($certificates as $cert) {
            if (!is_array($cert)) continue;
            $type = strtolower(trim((string)($cert['type'] ?? '')));
            if ($type !== 'self_signed') continue;
            $cn = strtolower(trim((string)($cert['common_name'] ?? '')));
            if ($cn === $domain) return (int)($cert['id'] ?? 0);
        }
        return 0;
    }
}
