<?php

/**
 * PATCH 047 §7–§10, §18, §48 — ЕДИНСТВЕННЫЙ transport ко всем запросам
 * api.webmaster.yandex.net. Жёсткая привязка исходящего IPv4 к аккаунту:
 *
 *   assigned/default IP → CURLOPT_INTERFACE(expected) → curl_exec()
 *   → CURLINFO_LOCAL_IP → actual===expected → только тогда обрабатываем ответ.
 *
 * Инварианты:
 *   - строит URL из API_HOST . $path (path, не произвольный URL) — анти-SSRF, OAuth не уходит на чужой host;
 *   - CURLOPT_IPRESOLVE=V4, FOLLOWLOCATION=false (любой 3xx → FAIL), TLS verify ON;
 *   - CURLINFO_LOCAL_IP проверяется ДО бизнес-обработки; пусто/≠expected → FAIL CLOSED;
 *   - НИКАКОГО fallback на другой IP;
 *   - каждый запрос пишет строку в webmaster_api_request_log (без токена/Authorization/секретов/полного тела);
 *   - структурированный результат (§48) не теряет network-метаданные даже при исключении.
 */
class YandexWebmasterHttpTransport
{
    public const API_HOST = 'https://api.webmaster.yandex.net';

    private const CONNECT_TIMEOUT = 15;
    private const TIMEOUT = 30;

    /**
     * @param string     $method            GET|POST|DELETE|...
     * @param string     $path              напр. '/v4/user' (НЕ полный URL)
     * @param string     $oauthToken        OAuth токен (в аудит НЕ пишется)
     * @param string     $expectedOutboundIp ожидаемый исходящий IPv4 (из resolver)
     * @param array      $query
     * @param mixed      $jsonBody
     * @param array      $context           ['webmaster_account_id'=>int,'refresh_job_id'=>?int,'stage'=>?string]
     * @return array structured result (§48)
     * @throws WebmasterTransportException FAIL CLOSED: bind_failed|source_ip_mismatch|network_timeout|unexpected_redirect
     */
    public function request(
        string $method,
        string $path,
        string $oauthToken,
        string $expectedOutboundIp,
        array $query = [],
        $jsonBody = null,
        array $context = []
    ): array {
        $method = strtoupper($method);
        $requestUid = bin2hex(random_bytes(8));
        $accountId  = (int)($context['webmaster_account_id'] ?? 0);
        $jobId      = isset($context['refresh_job_id']) && $context['refresh_job_id'] !== null
                      ? (int)$context['refresh_job_id'] : null;
        $stage      = isset($context['stage']) ? (string)$context['stage'] : null;

        // path-only → URL. Отбрасываем любой протокол/host в path (анти-SSRF).
        $safePath = '/' . ltrim($path, '/');
        if (preg_match('~^/+(https?:)?//~i', $safePath) || strpos($safePath, '://') !== false) {
            throw new WebmasterTransportException(
                WebmasterTransportException::HTTP_ERROR,
                'transport: path не должен содержать host/scheme: ' . $path
            );
        }
        $url = self::API_HOST . $safePath;
        if (!empty($query)) {
            $url .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($query);
        }
        $endpointForAudit = mb_substr($method . ' ' . $safePath, 0, 255);

        // Валидация expected IP — только IPv4 из approved pool (§59).
        if (filter_var($expectedOutboundIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) {
            throw new WebmasterTransportException(
                WebmasterTransportException::BIND_FAILED,
                'transport: expectedOutboundIp не является IPv4: ' . $expectedOutboundIp
            );
        }

        $headers = ['Authorization: OAuth ' . $oauthToken, 'Accept: application/json'];
        $postBody = null;
        if ($jsonBody !== null) {
            $postBody = json_encode($jsonBody, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $headers[] = 'Content-Type: application/json';
        }

        $opts = [
            CURLOPT_URL            => $url,
            CURLOPT_INTERFACE      => $expectedOutboundIp,
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_CONNECTTIMEOUT => self::CONNECT_TIMEOUT,
            CURLOPT_TIMEOUT        => self::TIMEOUT,
            CURLOPT_FOLLOWLOCATION => false,   // §8: OAuth не должен уходить на другой host
            CURLOPT_SSL_VERIFYPEER => true,    // §8: TLS verify не отключать
            CURLOPT_SSL_VERIFYHOST => 2,
        ];
        if ($postBody !== null) {
            $opts[CURLOPT_POSTFIELDS] = $postBody;
        }

        $raw = $this->executeCurl($opts, $headers);

        $actualLocalIp = (string)($raw['local_ip'] ?? '');
        $remoteIp      = (string)($raw['remote_ip'] ?? '');
        $httpCode      = (int)($raw['http_code'] ?? 0);
        $errno         = (int)($raw['errno'] ?? 0);
        $curlError     = (string)($raw['error'] ?? '');
        $durationMs    = (int)($raw['duration_ms'] ?? 0);
        $body          = array_key_exists('body', $raw) ? $raw['body'] : null;

        // Базовый результат — метаданные не теряем ни при каком исходе.
        $result = [
            'ok'                   => false,
            'http_code'            => $httpCode,
            'body'                 => is_string($body) ? $body : '',
            'curl_errno'           => $errno,
            'curl_error'           => $curlError,
            'expected_outbound_ip' => $expectedOutboundIp,
            'actual_local_ip'      => $actualLocalIp,
            'remote_ip'            => $remoteIp,
            'source_ip_verified'   => false,
            'duration_ms'          => $durationMs,
            'request_uid'          => $requestUid,
        ];

        // ── Классификация исхода ────────────────────────────────────────────
        $auditResult = 'success';
        $errorSummary = null;
        $throw = null; // [reason, message]

        if ($errno !== 0) {
            // сетевая ошибка / bind failure — source не подтверждён
            $auditResult = 'network_error';
            if ($errno === 28 /* CURLE_OPERATION_TIMEDOUT */) {
                $errorSummary = 'network_timeout: ' . $curlError;
                $throw = [WebmasterTransportException::NETWORK_TIMEOUT,
                    "Таймаут запроса к Yandex.Webmaster через IP {$expectedOutboundIp}"];
            } elseif ($errno === 45 /* CURLE_INTERFACE_FAILED */ || $actualLocalIp === '') {
                $errorSummary = 'bind_failed: ' . ($curlError !== '' ? $curlError : 'CURLOPT_INTERFACE failed');
                $throw = [WebmasterTransportException::BIND_FAILED,
                    "Не удалось привязать соединение к исходящему IP {$expectedOutboundIp}"];
            } else {
                $errorSummary = 'network_error(' . $errno . '): ' . $curlError;
                $throw = [WebmasterTransportException::NETWORK_TIMEOUT,
                    "Сетевая ошибка запроса к Yandex.Webmaster через IP {$expectedOutboundIp}"];
            }
        } elseif ($actualLocalIp === '') {
            // §9: пустой local IP → FAIL CLOSED
            $auditResult = 'source_ip_mismatch';
            $errorSummary = 'source_ip_empty: CURLINFO_LOCAL_IP пуст';
            $throw = [WebmasterTransportException::SOURCE_IP_MISMATCH,
                "Панель не смогла подтвердить исходящий IP (фактический адрес пуст) для {$expectedOutboundIp}"];
        } elseif ($actualLocalIp !== $expectedOutboundIp) {
            // §9: mismatch → FAIL CLOSED, никакого fallback
            $auditResult = 'source_ip_mismatch';
            $errorSummary = "source_ip_mismatch: expected={$expectedOutboundIp} actual={$actualLocalIp}";
            $throw = [WebmasterTransportException::SOURCE_IP_MISMATCH,
                "Фактический исходящий IP {$actualLocalIp} не совпал с назначенным {$expectedOutboundIp}"];
        } elseif ($httpCode >= 300 && $httpCode < 400) {
            // FOLLOWLOCATION=false: любой 3xx неожидан → FAIL CLOSED
            $result['source_ip_verified'] = true;
            $auditResult = 'http_error';
            $errorSummary = 'unexpected_redirect: HTTP ' . $httpCode;
            $throw = [WebmasterTransportException::UNEXPECTED_REDIRECT,
                "Неожиданный редирект HTTP {$httpCode} от Yandex.Webmaster"];
        } else {
            // source подтверждён; 2xx=success, 4xx/5xx=http_error (тело отдаём вызывающему)
            $result['source_ip_verified'] = true;
            if ($httpCode >= 200 && $httpCode < 300) {
                $result['ok'] = true;
                $auditResult = 'success';
            } else {
                $auditResult = 'http_error';
                $errorSummary = 'http_error: HTTP ' . $httpCode;
            }
        }

        // ── Аудит КАЖДОГО запроса (без токена/секретов) ─────────────────────
        $this->writeAudit([
            'request_uid'          => $requestUid,
            'webmaster_account_id' => $accountId,
            'refresh_job_id'       => $jobId,
            'stage'                => $stage,
            'method'               => $method,
            'endpoint'             => $endpointForAudit,
            'expected_outbound_ip' => $expectedOutboundIp,
            'actual_local_ip'      => $actualLocalIp !== '' ? $actualLocalIp : null,
            'remote_ip'            => $remoteIp !== '' ? $remoteIp : null,
            'source_ip_verified'   => $result['source_ip_verified'] ? 1 : 0,
            'http_code'            => $httpCode ?: null,
            'curl_errno'           => $errno,
            'duration_ms'          => $durationMs,
            'result'               => $auditResult,
            'error_summary'        => $errorSummary !== null ? mb_substr($errorSummary, 0, 500) : null,
        ]);

        if ($throw !== null) {
            throw new WebmasterTransportException($throw[0], $throw[1], $result);
        }
        return $result;
    }

    /**
     * Реальный сетевой вызов. Выделен в seam для тестируемости без сети:
     * тесты подменяют executeCurl, эмулируя CURLINFO_LOCAL_IP / bind-fail / http.
     * @return array{body:?string,http_code:int,local_ip:string,remote_ip:string,errno:int,error:string,duration_ms:int}
     */
    protected function executeCurl(array $opts, array $headers): array
    {
        $ch = curl_init();
        if ($ch === false) {
            return ['body' => null, 'http_code' => 0, 'local_ip' => '', 'remote_ip' => '',
                    'errno' => 6, 'error' => 'curl_init failed', 'duration_ms' => 0];
        }
        $opts[CURLOPT_HTTPHEADER] = $headers;
        curl_setopt_array($ch, $opts);

        $t0 = microtime(true);
        $body = curl_exec($ch);
        $durationMs = (int)round((microtime(true) - $t0) * 1000);

        // §9: читаем local/remote/http ДО curl_close.
        $localIp  = (string)curl_getinfo($ch, CURLINFO_LOCAL_IP);
        $remoteIp = (string)curl_getinfo($ch, CURLINFO_PRIMARY_IP);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno    = (int)curl_errno($ch);
        $error    = (string)curl_error($ch);
        curl_close($ch);

        return [
            'body'        => is_string($body) ? $body : null,
            'http_code'   => $httpCode,
            'local_ip'    => $localIp,
            'remote_ip'   => $remoteIp,
            'errno'       => $errno,
            'error'       => $error,
            'duration_ms' => $durationMs,
        ];
    }

    /** Запись строки аудита. Выделено для тестируемости/подмены хранилища. */
    protected function writeAudit(array $row): void
    {
        try {
            $pdo = DB::pdo();
            $st = $pdo->prepare(
                "INSERT INTO webmaster_api_request_log
                    (request_uid, webmaster_account_id, refresh_job_id, stage, method, endpoint,
                     expected_outbound_ip, actual_local_ip, remote_ip, source_ip_verified,
                     http_code, curl_errno, duration_ms, result, error_summary)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $st->execute([
                $row['request_uid'],
                $row['webmaster_account_id'],
                $row['refresh_job_id'],
                $row['stage'],
                $row['method'],
                $row['endpoint'],
                $row['expected_outbound_ip'],
                $row['actual_local_ip'],
                $row['remote_ip'],
                $row['source_ip_verified'],
                $row['http_code'],
                $row['curl_errno'],
                $row['duration_ms'],
                $row['result'],
                $row['error_summary'],
            ]);
        } catch (\Throwable $e) {
            // Аудит не должен ронять основную операцию, но фиксируем в error_log.
            error_log('webmaster_api_request_log write failed: ' . $e->getMessage());
        }
    }

    /** Удаление строк аудита старше N дней (§20 retention). */
    public static function purgeOlderThanDays(int $days = 30): int
    {
        if ($days <= 0) return 0;
        try {
            $st = DB::pdo()->prepare(
                "DELETE FROM webmaster_api_request_log WHERE created_at < (NOW() - INTERVAL ? DAY)"
            );
            $st->execute([$days]);
            return $st->rowCount();
        } catch (\Throwable $e) {
            return 0;
        }
    }
}
