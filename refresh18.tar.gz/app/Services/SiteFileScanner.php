<?php

/**
 * Сканер файлов сайта — версия v14c-fix2.
 *
 * ИСТОРИЯ:
 *  v14c        — использовал ftp_nlist + эвристику looksLikeDirectory
 *                → отбрасывал .htaccess как папку (фейл).
 *  v14c-fix    — использовал ftp_rawlist с парсингом ls -l
 *                → на FastPanel FTP с чрутом-пользователями listing
 *                  возвращается пустым для абсолютного пути (фейл).
 *  v14c-fix2   — стратегия "probe by name": не используем listDir вообще,
 *                а пытаемся скачать каждый КАНДИДАТНЫЙ файл по имени.
 *                Если ftp_get вернул content — файл существует. Если нет —
 *                пропускаем без шума.
 *                + DISCOVERY: после скачивания PHP-файлов парсим их на
 *                require/include и docблочные упоминания, добавляем
 *                найденные имена в очередь сканирования.
 *
 * Это работает на любом FTP-сервере — даже на чрутнутых FastPanel-FTP,
 * где LIST не поддерживает абсолютные пути.
 *
 * Что скачиваем (в порядке приоритета, сначала known-имена, потом discovery):
 *   1. .htaccess
 *   2. config.php, index.php, robots.php, sitemap.php, agent-ping.php
 *   3. header.php, footer.php, link_agent.php, link_fallback.php
 *   4. robots.txt (статичный)
 *   5. + всё что упоминается в require/include в скачанных PHP-файлах
 *      (рекурсивно, до 2 уровней)
 *
 * MAX_FILES = 30 — жёсткий лимит чтобы не уйти в бесконечную рекурсию.
 */
class SiteFileScanner
{
    private const MAX_FILE_SIZE = 1024 * 1024; // 1 MB
    private const MAX_FILES = 30;
    private const MAX_DISCOVERY_DEPTH = 2;

    /** Базовый набор known-имён, которые пробуем всегда. */
    private const KNOWN_NAMES = [
        // Конфиг и .htaccess — главные таргеты
        '.htaccess',
        'config.php',
        // Точки входа и роутинг
        'index.php',
        'robots.php',
        'robots.txt',
        'sitemap.php',
        'sitemap.xml',
        // Шаблонные части (часто содержат хардкод)
        'header.php',
        'footer.php',
        // Партнёрский слой (видим у разных шаблонов)
        'link_agent.php',
        'link_fallback.php',
        'agent-ping.php',
        // Доп. служебные имена
        'page.php',
        'main.php',
        'redirect.php',
        'load.php',
        'app.php',
        'init.php',
    ];

    private string $scansBaseDir;

    public function __construct()
    {
        $this->scansBaseDir = dirname(__DIR__, 2) . '/storage/scans';
        if (!is_dir($this->scansBaseDir)) {
            @mkdir($this->scansBaseDir, 0775, true);
        }
    }

    public function scanSite(int $siteId, int $jobId, JobEventLogger $log): array
    {
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'errors' => ["Site #{$siteId} not found"]];
        }

        $siteRoot = $this->resolveSiteRoot($site);
        if ($siteRoot === '') {
            return ['ok' => false, 'errors' => ['Cannot resolve site root path']];
        }

        $scanDir = $this->scansBaseDir . '/job_' . $jobId;
        if (!is_dir($scanDir)) {
            @mkdir($scanDir, 0775, true);
        }

        $log->info('analyze_site', "Сканирую корень сайта: {$siteRoot}");

        // Диагностика: показываем какой FTP-пользователь и хост
        $ftpUser = trim((string)($site['ftp_user'] ?? '?'));
        $ftpHost = trim((string)($site['ftp_host'] ?? '?'));
        $log->info('analyze_site', "FTP: user={$ftpUser}, host={$ftpHost}");

        // Подключаемся к FTP
        try {
            $ftp = $this->makeFtp($site);
            $ftp->connect();
        } catch (\Throwable $e) {
            return ['ok' => false, 'errors' => ['FTP connect failed: ' . $e->getMessage()]];
        }

        // ШАГ 1: Найти рабочий базовый путь, пробуя config.php в нескольких вариантах.
        // Это нужно потому что FTP-пользователь может быть чрутнут в свой home,
        // и тогда абсолютный путь /var/www/owner/data/www/domain/config.php не найдётся,
        // а относительный 'config.php' (от текущей dir) — найдётся.
        $basePath = $this->findWorkingBasePath($ftp, $siteRoot, $site, $log);

        if ($basePath === null) {
            $ftp->disconnect();
            return [
                'ok' => false,
                'errors' => [
                    'Не удалось найти рабочий базовый путь. ' .
                    'Все варианты пути для config.php дали "FTP get failed". ' .
                    'Возможно, FTP-пользователь не имеет доступа к этой папке, ' .
                    'или config.php реально отсутствует.'
                ],
                'site_root' => $siteRoot,
            ];
        }

        $log->info('analyze_site', "Рабочий базовый путь найден: '{$basePath}' (используется для всех файлов)");

        $files = [];
        $errors = [];
        $tried = [];
        $queue = self::KNOWN_NAMES;
        $depth = 0;
        $totalChecked = 0;

        while (!empty($queue) && count($files) < self::MAX_FILES && $depth <= self::MAX_DISCOVERY_DEPTH) {
            $newDiscoveries = [];

            foreach ($queue as $name) {
                $name = trim($name);
                if ($name === '' || isset($files[$name]) || isset($tried[$name])) continue;

                if (count($files) >= self::MAX_FILES) {
                    $log->warn('analyze_site',
                        'Достигнут лимит MAX_FILES=' . self::MAX_FILES . ', остальные пропущены');
                    break;
                }

                $kind = $this->classifyFile($name);
                if ($kind === null) {
                    $tried[$name] = 'not_target_extension';
                    continue;
                }

                $totalChecked++;
                $remotePath = $basePath === '' ? $name : (rtrim($basePath, '/') . '/' . $name);

                // Пробуем скачать
                try {
                    $content = $ftp->getContent($remotePath);
                } catch (\Throwable $e) {
                    $tried[$name] = 'not_found';
                    continue;
                }

                $size = strlen($content);
                if ($size === 0) {
                    $tried[$name] = 'empty';
                    continue;
                }
                if ($size > self::MAX_FILE_SIZE) {
                    $tried[$name] = "too_large_{$size}";
                    continue;
                }

                // Сохраняем локально
                $localPath = $scanDir . '/' . $name;
                if (@file_put_contents($localPath, $content) === false) {
                    $errors[] = "Не удалось сохранить локально {$name}";
                    $tried[$name] = 'local_save_failed';
                    continue;
                }

                $files[$name] = [
                    'size' => $size,
                    'kind' => $kind,
                    'local_path' => $localPath,
                    'remote_path' => $remotePath,
                ];

                // Discovery: ищем require/include в свежем PHP
                if ($kind === 'php' && $depth < self::MAX_DISCOVERY_DEPTH) {
                    $discovered = $this->extractIncludes($content);
                    foreach ($discovered as $d) {
                        if (!isset($files[$d]) && !isset($tried[$d]) && !in_array($d, $newDiscoveries, true)) {
                            $newDiscoveries[] = $d;
                        }
                    }
                }
            }

            $queue = $newDiscoveries;
            $depth++;

            if (!empty($newDiscoveries)) {
                $log->info('analyze_site',
                    "Discovery (уровень {$depth}): найдено новых имён через include/require: " .
                    implode(', ', array_slice($newDiscoveries, 0, 10)) .
                    (count($newDiscoveries) > 10 ? '...' : ''));
            }
        }

        $ftp->disconnect();

        // Сводка по tried (для отладки)
        $triedCounts = array_count_values(array_values($tried));
        $triedSummary = [];
        foreach ($triedCounts as $reason => $count) {
            $triedSummary[] = "{$reason}={$count}";
        }
        $triedSummaryStr = empty($triedSummary) ? '' : ' (пропущено: ' . implode(', ', $triedSummary) . ')';

        $log->info('analyze_site',
            'Просканировано имён: ' . $totalChecked .
            '. Скачано файлов: ' . count($files) . $triedSummaryStr);

        if (!empty($files)) {
            $log->info('analyze_site',
                'Файлы: ' . implode(', ', array_keys($files)));
        }

        return [
            'ok' => count($files) > 0,
            'scan_dir' => $scanDir,
            'site_root' => $siteRoot,
            'base_path' => $basePath, // используется applier-ом, чтобы загружать по тому же пути
            'files' => $files,
            'tried_names' => $tried,
            'errors' => $errors,
        ];
    }

    /**
     * Находит рабочий базовый путь для FTP, пробуя разные варианты.
     *
     * Стратегия: используем config.php как маяк (самый частый файл-якорь).
     * Пробуем по очереди:
     *   1. абсолютный $siteRoot/config.php
     *   2. относительный без префикса 'config.php' (от текущей dir FTP)
     *   3. путь с убранным /var/www/{owner} префиксом (если ftp чрутнут в home)
     *   4. путь начинающийся с /data/www/{domain}/...
     *
     * Возвращает рабочий базовый путь (БЕЗ имени файла на конце), или null
     * если ни один вариант не подошёл.
     *
     * Возможные результаты:
     *   '/var/www/owner/data/www/domain'  — абсолютный путь работает
     *   ''                                  — пустой = относительные пути от FTP-корня
     *   '/data/www/domain'                  — чрут в /var/www/owner
     *   'data/www/domain'                   — чрут с относительным подкаталогом
     */
    private function findWorkingBasePath(
        FtpService $ftp,
        string $siteRoot,
        array $site,
        JobEventLogger $log
    ): ?string {
        $candidates = $this->buildBasePathCandidates($siteRoot, $site);
        $log->info('analyze_site',
            'Ищу рабочий базовый путь, пробую ' . count($candidates) . ' вариантов...');

        foreach ($candidates as $base) {
            $probe = $base === '' ? 'config.php' : (rtrim($base, '/') . '/config.php');
            try {
                $content = $ftp->getContent($probe);
                if ($content !== '' && stripos($content, '<?php') !== false) {
                    $log->info('analyze_site', "  ✓ работает: '{$probe}'");
                    return $base;
                }
                $log->info('analyze_site', "  ⚠ путь сработал но не похоже на PHP: '{$probe}'");
            } catch (\Throwable $e) {
                $log->info('analyze_site', "  ✗ '{$probe}' — failed");
            }
        }

        return null;
    }

    /**
     * Список кандидатов базового пути в порядке убывания вероятности.
     */
    private function buildBasePathCandidates(string $siteRoot, array $site): array
    {
        $out = [];

        // 1. Абсолютный путь как было раньше
        if ($siteRoot !== '') {
            $out[] = $siteRoot;
        }

        // 2. Пустой = относительный от FTP-корня (config.php)
        $out[] = '';

        // 3. Путь без префикса /var/www/{owner}
        // /var/www/1win177_casino/data/www/1win177.casino → /data/www/1win177.casino
        if (preg_match('~^/var/www/[^/]+(/.*)$~', $siteRoot, $m)) {
            $out[] = $m[1]; // например /data/www/1win177.casino
            $out[] = ltrim($m[1], '/'); // относительный: data/www/1win177.casino
        }

        // 4. Только последняя часть после www/
        if (preg_match('~/www/([^/]+/?)$~', $siteRoot, $m)) {
            $out[] = '/' . $m[1];
            $out[] = $m[1];
            $out[] = 'www/' . $m[1];
        }

        // 5. Префикс /home/{user} (некоторые хостинги)
        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        if ($owner !== '') {
            $out[] = "/home/{$owner}/data/www/" . trim((string)($site['current_domain'] ?? ''), '/');
        }

        // Дедупликация и фильтр
        $seen = [];
        $clean = [];
        foreach ($out as $p) {
            $p = trim($p);
            $key = ($p === '') ? '__empty__' : $p;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $clean[] = $p;
        }

        return $clean;
    }

    /**
     * Извлекает имена файлов из require/include statements в PHP-коде.
     * Ищет:
     *   - require_once 'foo.php';
     *   - require_once "foo.php";
     *   - require_once __DIR__.'/foo.php';
     *   - include('foo.php');
     *   - include_once $var . 'foo.php';
     *
     * Возвращает массив имён (basename), без путей.
     */
    private function extractIncludes(string $content): array
    {
        $found = [];

        // Паттерн ловит require/include + (опционально __DIR__./'./...) + 'filename.php' или "filename.php"
        $pattern = '~(?:require|include)(?:_once)?\s*\(?\s*(?:[^,;]*[\.\/\\\\\s])?[\'"]([^\'"]+\.php)[\'"]~i';

        if (preg_match_all($pattern, $content, $matches)) {
            foreach ($matches[1] as $path) {
                $base = basename(trim($path));
                if ($base !== '' && strpos($base, '..') === false) {
                    $found[] = $base;
                }
            }
        }

        return array_unique($found);
    }

    /**
     * Классифицирует файл по имени.
     */
    private function classifyFile(string $name): ?string
    {
        $lower = strtolower($name);
        if ($lower === '.htaccess') return 'htaccess';
        if ($lower === 'robots.txt') return 'robots_txt';
        if (substr($lower, -4) === '.php') return 'php'; // v4 (H3): PHP 7.4-совместимо
        return null;
    }

    private function loadSite(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    private function resolveSiteRoot(array $site): string
    {
        $idx = trim((string)($site['fp_index_dir'] ?? ''));
        if ($idx !== '') return $idx;
        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        $dom = trim((string)($site['current_domain'] ?? ''));
        if ($owner !== '' && $dom !== '') {
            return "/var/www/{$owner}/data/www/{$dom}";
        }
        return '';
    }

    private function makeFtp(array $site): FtpService
    {
        $host = trim((string)($site['ftp_host'] ?? ''));
        $user = trim((string)($site['ftp_user'] ?? ''));
        $pass = '';
        if (!empty($site['ftp_pass_enc'])) {
            try {
                $pass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            } catch (\Throwable $e) {}
        }

        if ($host === '') {
            $serverId = (int)($site['fastpanel_server_id'] ?? 0);
            if ($serverId > 0) {
                $st = DB::pdo()->prepare("SELECT host FROM fastpanel_servers WHERE id=?");
                $st->execute([$serverId]);
                $rawHost = (string)$st->fetchColumn();
                $rawHost = preg_replace('~^https?://~i', '', $rawHost);
                $rawHost = preg_replace('~:\d+$~', '', $rawHost);
                $rawHost = preg_replace('~/.*$~', '', $rawHost);
                $host = trim($rawHost);
            }
        }

        if ($host === '' || $user === '' || $pass === '') {
            throw new \RuntimeException('FTP credentials missing for site #' . ($site['id'] ?? '?'));
        }

        return new FtpService($host, $user, $pass, ['passive' => true, 'timeout' => 30]);
    }
}
