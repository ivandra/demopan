<?php

/**
 * SiteConfigMutationService — единственный владелец config.php.
 *
 * PREPARE (analyze): read-only fetch → scan (fail-closed) → target целиком в памяти
 *   (домен, затем sub_id) → semantic verify → target в закрытый storage (0600) →
 *   план с source_sha256 + target_sha256 + expected.
 * APPLY (config_replaced): re-fetch → SHA guard → один upload target → байтовый
 *   read-back (SHA == target) → semantic verify → persistVerified (транзакция+re-select).
 *
 * config.php исключён из generic ReplacementApplier.
 */
final class SiteConfigMutationService
{
    private SiteConfigSyncService $sync;
    private StaticSiteConfigScanner $scanner;
    private DomainMaskService $mask;

    public function __construct(SiteConfigSyncService $sync, StaticSiteConfigScanner $scanner, DomainMaskService $mask)
    {
        $this->sync = $sync;
        $this->scanner = $scanner;
        $this->mask = $mask;
    }

    private function blocked(string $reason, $details = null): array
    {
        return ['ok' => false, 'reason' => $reason, 'details' => $details, 'uploads' => 0];
    }

    // ─────────────────────────── PREPARE ───────────────────────────
    public function prepare(int $siteId, int $jobId, string $oldDomain, string $newDomain): array
    {
        $fetch = $this->sync->fetchFromVpsReadOnly($siteId);
        if (empty($fetch['ok'])) {
            $err = (string)($fetch['error'] ?? '');
            $reason = (stripos($err, 'parser') !== false || stripos($err, 'not PHP') !== false) ? 'php_parse_error' : 'config_read_failed';
            return $this->blocked($reason, $err);
        }
        $sourceRaw  = (string)$fetch['raw'];
        $remotePath = (string)($fetch['path'] ?? '');

        $sourceScan = $this->scanner->scan($sourceRaw);
        if (!$sourceScan->isSafe()) {
            return $this->blocked($sourceScan->reason(), $sourceScan->details());
        }

        $oldSubId = $sourceScan->uniqueSubIdOrNull();
        $newSubId = $oldSubId === null ? null : $this->mask->subIdForDomain($oldSubId, $newDomain);
        if ($oldSubId !== null && ($newSubId === '' || $newSubId === null)) $newSubId = $oldSubId;

        // 1. Домен — offset-aware mutation (drift-safe, ТЗ044 §3), чисто в памяти.
        $jobOldBare = $this->bare($oldDomain);
        $newBare    = $this->bare($newDomain);
        $dm = $this->mutateDomain($sourceRaw, $sourceScan, $newBare, $jobOldBare);
        if (empty($dm['ok'])) {
            return $this->blocked((string)$dm['reason'], $dm['details'] ?? null);
        }
        $targetRaw     = (string)$dm['raw'];
        $effectiveOld  = (string)$dm['effective_old_domain'];
        $driftDetected = ($effectiveOld !== '' && $effectiveOld !== $jobOldBare);

        // 2. sub_id по offset'ам из повторного скана domain-mutated raw.
        if ($newSubId !== null && $newSubId !== $oldSubId) {
            $targetScan = $this->scanner->scan($targetRaw);
            if (!$targetScan->isSafe()) {
                return $this->blocked('target_scan_failed', $targetScan->details());
            }
            $targetRaw = $this->replaceSubIdByOffsets($targetRaw, $targetScan, (string)$oldSubId, (string)$newSubId);
        }

        // 3. Семантика target ДО FTP.
        $expected = $this->buildExpected($sourceScan, $newDomain, $newSubId);
        $verr = $this->verifyRaw($targetRaw, $expected);
        if ($verr) {
            return $this->blocked('prepared_target_invalid', $verr);
        }

        $targetPath = $this->writeTargetAtomic($jobId, $targetRaw);

        $plan = [
            'version' => 1,
            'site_id' => $siteId,
            'job_id'  => $jobId,
            'remote_path' => $remotePath,
            'source_sha256' => hash('sha256', $sourceRaw),
            'target_sha256' => hash('sha256', $targetRaw),
            'target_storage_path' => $targetPath,
            'old_domain' => $oldDomain,
            'new_domain' => $newDomain,
            'old_sub_id' => $oldSubId,
            'new_sub_id' => $newSubId,
            'expected' => $expected,
            'config_domain_drift' => [
                'detected' => $driftDetected,
                'job_old_domain' => $jobOldBare,
                'live_config_domain' => $effectiveOld,
                'target_domain' => $newBare,
                'resolution' => 'offset_assignment_rewrite',
                'checked_at' => gmdate('c'),
            ],
        ];
        return ['ok' => true, 'plan' => $plan];
    }

    /**
     * ТЗ044 §11 — pre-purchase preflight (read-only). Fetch → scan → dry target build
     * (domain drift-aware + sub_id) → semantic verify. НИКАКОГО FTP write, storage write,
     * Namecheap create. Возвращает диагностику для решения «покупать / awaiting_user».
     * @return array ['ok'=>bool,'prepurchase_preflight'=>array,'reason'=>?,'details'=>?]
     */
    public function preflight(int $siteId, string $candidateDomain, string $jobOldDomain): array
    {
        $fetch = $this->sync->fetchFromVpsReadOnly($siteId);
        if (empty($fetch['ok'])) {
            return ['ok' => false, 'reason' => 'config_read_failed', 'details' => (string)($fetch['error'] ?? ''),
                    'prepurchase_preflight' => ['candidate' => $candidateDomain, 'ok' => false, 'ftp_writes' => 0]];
        }
        $sourceRaw = (string)$fetch['raw'];
        $scan = $this->scanner->scan($sourceRaw);
        if (!$scan->isSafe()) {
            return ['ok' => false, 'reason' => $scan->reason(), 'details' => $scan->details(),
                    'prepurchase_preflight' => ['candidate' => $candidateDomain, 'ok' => false,
                        'source_sha256' => hash('sha256', $sourceRaw), 'reason' => $scan->reason(), 'ftp_writes' => 0]];
        }

        $jobOldBare = $this->bare($jobOldDomain);
        $newBare    = $this->bare($candidateDomain);
        $dm = $this->mutateDomain($sourceRaw, $scan, $newBare, $jobOldBare);
        if (empty($dm['ok'])) {
            return ['ok' => false, 'reason' => (string)$dm['reason'], 'details' => $dm['details'] ?? null,
                    'prepurchase_preflight' => ['candidate' => $candidateDomain, 'ok' => false,
                        'source_sha256' => hash('sha256', $sourceRaw), 'reason' => (string)$dm['reason'], 'ftp_writes' => 0]];
        }
        $targetRaw    = (string)$dm['raw'];
        $effectiveOld = (string)$dm['effective_old_domain'];

        $oldSubId = $scan->uniqueSubIdOrNull();
        $newSubId = $oldSubId === null ? null : $this->mask->subIdForDomain($oldSubId, $candidateDomain);
        if ($oldSubId !== null && ($newSubId === '' || $newSubId === null)) $newSubId = $oldSubId;
        if ($newSubId !== null && $newSubId !== $oldSubId) {
            $tScan = $this->scanner->scan($targetRaw);
            if (!$tScan->isSafe()) {
                return ['ok' => false, 'reason' => 'target_scan_failed', 'details' => $tScan->details(),
                        'prepurchase_preflight' => ['candidate' => $candidateDomain, 'ok' => false, 'ftp_writes' => 0]];
            }
            $targetRaw = $this->replaceSubIdByOffsets($targetRaw, $tScan, (string)$oldSubId, (string)$newSubId);
        }

        $expected = $this->buildExpected($scan, $candidateDomain, $newSubId);
        $verr = $this->verifyRaw($targetRaw, $expected);
        if ($verr) {
            return ['ok' => false, 'reason' => 'prepared_target_invalid', 'details' => $verr,
                    'prepurchase_preflight' => ['candidate' => $candidateDomain, 'ok' => false,
                        'source_sha256' => hash('sha256', $sourceRaw), 'reason' => 'prepared_target_invalid',
                        'details' => $verr, 'ftp_writes' => 0]];
        }

        return ['ok' => true, 'prepurchase_preflight' => [
            'candidate' => $candidateDomain, 'ok' => true,
            'source_sha256' => hash('sha256', $sourceRaw),
            'effective_config_domain' => $effectiveOld,
            'effective_sub_id' => $oldSubId,
            'target_domain' => $newBare,
            'target_sub_id' => $newSubId,
            'domain_drift' => ($effectiveOld !== '' && $effectiveOld !== $jobOldBare),
            'ftp_writes' => 0,
            'checked_at' => gmdate('c'),
        ]];
    }

    // ─────────────────────────── APPLY ───────────────────────────
    public function applyPrepared(ConfigMutationPlan $plan): array
    {
        $current = $this->sync->fetchFromVpsReadOnly($plan->siteId);
        if (empty($current['ok'])) {
            return $this->blocked('config_read_failed', $current['error'] ?? null);
        }
        // TOCTOU прямо перед записью
        if (!hash_equals($plan->sourceSha256, (string)$current['sha256'])) {
            return $this->blocked('config_changed_after_analyze',
                ['expected' => $plan->sourceSha256, 'actual' => (string)$current['sha256']]);
        }
        // target из закрытого storage + целостность
        try {
            $targetRaw = $this->readTarget($plan->targetStoragePath);
        } catch (\Throwable $e) {
            return $this->blocked('stored_target_corrupted', $e->getMessage());
        }
        if ($targetRaw === null || !hash_equals($plan->targetSha256, hash('sha256', $targetRaw))) {
            return $this->blocked('stored_target_corrupted');
        }

        // ровно ОДИН upload
        $up = $this->sync->uploadRaw($plan->siteId, $plan->remotePath, $targetRaw);
        if (empty($up['ok'])) {
            return ['ok' => false, 'reason' => 'ftp_upload_failed', 'details' => $up['error'] ?? null, 'uploads' => 0];
        }

        // байтовый read-back
        $after = $this->sync->fetchFromVpsReadOnly($plan->siteId);
        if (empty($after['ok'])) {
            return ['ok' => false, 'reason' => 'read_back_ftp_failed', 'uploads' => 1];
        }
        if (!hash_equals($plan->targetSha256, (string)$after['sha256'])) {
            return ['ok' => false, 'reason' => 'read_back_sha_mismatch', 'uploads' => 1,
                    'expected' => $plan->targetSha256, 'actual' => (string)$after['sha256']];
        }
        // короткая бизнес-проверка
        $verr = $this->verifyRaw((string)$after['raw'], $plan->expected);
        if ($verr) {
            return ['ok' => false, 'reason' => 'read_back_semantic_mismatch', 'uploads' => 1, 'errors' => $verr];
        }

        // persist ТОЛЬКО теперь (транзакция + re-select)
        $persist = $this->sync->persistVerified($plan->siteId, $plan->remotePath,
            (array)$after['parsed'], (string)$after['kind'], (string)$after['raw'], $plan->newDomain);
        if (empty($persist['ok'])) {
            return ['ok' => false, 'reason' => (string)($persist['reason'] ?? 'snapshot_persist_failed'), 'uploads' => 1];
        }

        $this->deleteTarget($plan->targetStoragePath);
        return ['ok' => true, 'reason' => 'config_replaced_verified', 'uploads' => 1];
    }

    // ─────────────────────────── pure helpers ───────────────────────────

    /** Чистая доменная трансформация config.php (host-level str-замена). DEPRECATED (ТЗ044 §2):
     *  зависела от буквального совпадения с job.old_domain и ломалась на drift. Не используется
     *  в prepare(); оставлена только для обратной совместимости внешних вызовов. */
    public function domainTransform(string $raw, string $oldDomain, string $newDomain): string
    {
        $o = $this->bare($oldDomain); $n = $this->bare($newDomain);
        if ($o === '' || $o === $n) return $raw;
        return str_replace($o, $n, $raw);
    }

    /**
     * ТЗ044 §3 — offset-aware доменная mutation, независимая от job.old_domain.
     *  - ровно одно статическое $domain assignment → RHS := 'https://<new>' по offset'у;
     *  - >1 статических domain → domain_conflict; динамический domain → unrecognized_domain_field;
     *  - url_field'ы, несущие СОБСТВЕННЫЙ домен (host == effective_config_domain), нормализуются
     *    (host заменяется, path/query сохраняются); партнёрские хосты не трогаются.
     * @return array ['ok'=>bool,'raw'=>?,'reason'=>?,'details'=>?,'effective_old_domain'=>string,'domain_required'=>bool]
     */
    public function mutateDomain(string $raw, ConfigScanResult $scan, string $newBare, string $jobOldBare): array
    {
        $static = []; $dynamic = false;
        foreach ($scan->assignments() as $a) {
            if ($a['kind'] === 'domain') $static[] = $a;
            elseif ($a['kind'] === 'domain_dynamic') $dynamic = true;
        }
        if ($dynamic) return ['ok' => false, 'reason' => 'unrecognized_domain_field'];
        if (count($static) > 1) return ['ok' => false, 'reason' => 'domain_conflict',
            'details' => array_map(fn($a) => $a['value'], $static)];

        $effectiveOld = count($static) === 1 ? $this->bare((string)$static[0]['value']) : $jobOldBare;

        $edits = [];
        if (count($static) === 1) {
            $a = $static[0];
            $q = $a['rhs_text'][0]; if ($q !== '"' && $q !== "'") $q = "'";
            $edits[] = [$a['rhs_offset'], strlen($a['rhs_text']), $q . 'https://' . $newBare . $q];
        }
        // собственный домен внутри url_field (не партнёрский host)
        foreach ($scan->assignments() as $a) {
            if ($a['kind'] !== 'url_field') continue;
            $host = $this->hostOf((string)$a['value']);
            if ($host === null || $host !== $effectiveOld) continue; // партнёрские/чужие — не трогаем
            $newTok = preg_replace(
                '~(https?://)' . preg_quote($effectiveOld, '~') . '(?=[/:"\'?#]|$)~i',
                '${1}' . $newBare, (string)$a['rhs_text'], 1);
            if ($newTok !== $a['rhs_text']) $edits[] = [$a['rhs_offset'], strlen($a['rhs_text']), $newTok];
        }
        usort($edits, fn($x, $y) => $y[0] <=> $x[0]);
        foreach ($edits as [$off, $len, $txt]) $raw = substr($raw, 0, $off) . $txt . substr($raw, $off + $len);

        return ['ok' => true, 'raw' => $raw, 'effective_old_domain' => $effectiveOld,
                'domain_required' => count($static) === 1];
    }

    /** host без scheme/www из URL-литерала, либо null. */
    private function hostOf(string $url): ?string
    {
        if (!preg_match('~^https?://([^/:"\'?#\s]+)~i', $url, $m)) return null;
        return preg_replace('~^www\.~', '', strtolower($m[1]));
    }

    /** Заменить sub_id по offset'ам полей (от большего offset к меньшему). */
    private function replaceSubIdByOffsets(string $raw, ConfigScanResult $scan, string $old, string $new): string
    {
        $edits = [];
        foreach ($scan->assignments() as $a) {
            if ($a['kind'] === 'url_field' && $a['sub_value'] === $old) {
                $newTok = preg_replace(
                    '~([?&](?:sub_id|subid|sub)=)' . preg_quote($old, '~') . '(?=$|[&#"\'\\s])~i',
                    '${1}' . $new, $a['rhs_text']);
                $edits[] = [$a['rhs_offset'], strlen($a['rhs_text']), $newTok];
            } elseif ($a['kind'] === 'bare_sub' && $a['sub_value'] === $old) {
                $q = $a['rhs_text'][0];
                $edits[] = [$a['rhs_offset'], strlen($a['rhs_text']), $q . $new . $q];
            }
        }
        usort($edits, fn($x, $y) => $y[0] <=> $x[0]);
        foreach ($edits as [$off, $len, $txt]) {
            $raw = substr($raw, 0, $off) . $txt . substr($raw, $off + $len);
        }
        return $raw;
    }

    /** Ожидаемое состояние target (для semantic verify до и после FTP). */
    public function buildExpected(ConfigScanResult $scan, string $newDomain, ?string $newSubId): array
    {
        $fields = [];
        if ($newSubId !== null) {
            foreach ($scan->assignments() as $a) {
                if ($a['kind'] === 'url_field' && $a['sub_value'] !== null) $fields[$a['path']] = $newSubId;
                elseif ($a['kind'] === 'bare_sub') $fields[$a['path']] = $newSubId;
            }
        }
        return [
            'domain_required' => $scan->domainRequired(),
            'domain' => $scan->domainRequired() ? ('https://' . $this->bare($newDomain)) : null,
            'sub_id' => $newSubId,
            'fields' => $fields,
        ];
    }

    /** Проверить raw против expected. Возвращает [] при успехе или список ошибок. */
    public function verifyRaw(string $raw, array $expected): array
    {
        $errors = [];
        $scan = $this->scanner->scan($raw);
        if (!$scan->isSafe()) return ['scan_' . $scan->reason()];

        if (!empty($expected['domain_required'])) {
            $want = $this->bare((string)($expected['domain'] ?? ''));
            $have = null;
            foreach ($scan->assignments() as $a) if ($a['kind'] === 'domain') $have = $this->bare($a['value']);
            if ($have === null || $have !== $want) $errors[] = "domain_mismatch: have=" . var_export($have, true) . " want={$want}";
        }
        // каждое ожидаемое поле несёт new sub_id
        $byPath = [];
        foreach ($scan->assignments() as $a) $byPath[$a['path']] = $a;
        foreach ((array)($expected['fields'] ?? []) as $path => $val) {
            if (!isset($byPath[$path])) { $errors[] = "field_missing:{$path}"; continue; }
            if ((string)$byPath[$path]['sub_value'] !== (string)$val) {
                $errors[] = "field_mismatch:{$path}=" . var_export($byPath[$path]['sub_value'], true) . " want={$val}";
            }
        }
        // ни одного активного значения, отличного от expected sub_id
        if (($expected['sub_id'] ?? null) !== null) {
            foreach ($scan->activeSubIds() as $v) {
                if ($v !== (string)$expected['sub_id']) { $errors[] = "unexpected_active_sub_id:{$v}"; break; }
            }
        }
        return $errors;
    }

    // ─────────────────────────── target storage (0600, относительные пути) ─────────
    private function targetRel(int $jobId): string { return 'builds/job_' . $jobId . '/config.target.php'; }

    public function writeTargetAtomic(int $jobId, string $raw): string
    {
        $rel = $this->targetRel($jobId);
        $abs = Paths::storage($rel);
        Paths::ensureDir(dirname($abs));
        $tmp = $abs . '.tmp';
        file_put_contents($tmp, $raw, LOCK_EX);
        @chmod($tmp, 0600);
        rename($tmp, $abs);
        @chmod($abs, 0600);
        return $rel;
    }

    public function readTarget(string $rel): ?string
    {
        $abs = Paths::storage($rel);
        if (!is_file($abs)) return null;
        $c = file_get_contents($abs);
        return $c === false ? null : $c;
    }

    public function deleteTarget(string $rel): void
    {
        $abs = Paths::storage($rel);
        if (is_file($abs)) @unlink($abs);
    }

    private function bare(string $d): string
    {
        $d = strtolower(trim($d));
        $d = preg_replace('~^https?://~', '', $d);
        $d = preg_replace('~^www\.~', '', $d);
        $d = explode('/', $d)[0];
        $d = explode(':', $d)[0];
        return $d;
    }
}
