<?php

/**
 * v18: HtaccessRedirectAppender
 *
 * Добавляет в конец .htaccess сайта блок 301-редиректа со старого домена
 * на новый.
 *
 * Используется в стадиях move_htaccess_redirect (новые move-режимы).
 *
 * Идемпотентность: перед добавлением проверяет что блок для пары
 * (old_domain → new_domain) ещё не добавлен. Если уже есть — return ['was_present' => true].
 *
 * Блок выглядит так (в точности как требовал клиент):
 *
 *   # === Refresh Panel: redirect old → new (job #N at TS) ===
 *   RewriteCond %{HTTP_HOST} ^(www\.)?old-domain\.casino$ [NC]
 *   RewriteRule ^ https://new-domain.casino%{REQUEST_URI} [R=301,L]
 *
 * Перед записью делает snapshot оригинального .htaccess в storage/snapshots/job_X/
 * чтобы можно было откатить если что-то пошло не так.
 */
class HtaccessRedirectAppender
{
    private FtpService $ftp;
    private string $snapshotDir;

    /**
     * @param FtpService $ftp подключённый FTP клиент сайта
     * @param string $snapshotDir путь типа storage/snapshots/job_N/
     */
    public function __construct(FtpService $ftp, string $snapshotDir)
    {
        $this->ftp = $ftp;
        $this->snapshotDir = rtrim($snapshotDir, '/');
    }

    /**
     * Добавить блок редиректа в .htaccess.
     *
     * @param string $oldDomain Например "volna-205.casino"
     * @param string $newDomain Например "volna-206.casino"
     * @param int $jobId Для пометки в комментарии и snapshot'е
     * @return array{
     *     ok: bool,
     *     was_present_before: bool,
     *     snapshot_path: ?string,
     *     htaccess_path: string,
     *     bytes_before: int,
     *     bytes_after: int,
     *     block_added: ?string,
     *     error: ?string
     * }
     */
    public function appendRedirect(string $oldDomain, string $newDomain, int $jobId): array
    {
        $result = [
            'ok' => false,
            'was_present_before' => false,
            'snapshot_path' => null,
            'htaccess_path' => '.htaccess',
            'bytes_before' => 0,
            'bytes_after' => 0,
            'block_added' => null,
            'error' => null,
        ];

        $oldDomain = trim($oldDomain, " \t\r\n.");
        $newDomain = trim($newDomain, " \t\r\n.");

        if ($oldDomain === '' || $newDomain === '') {
            $result['error'] = 'old_domain или new_domain пуст';
            return $result;
        }

        // 1. Скачиваем существующий .htaccess (или работаем с пустым если файла нет)
        $existing = '';
        $hadFile = false;
        try {
            if ($this->ftp->fileExists('.htaccess')) {
                $existing = $this->ftp->getContent('.htaccess');
                $hadFile = true;
            }
        } catch (\Throwable $e) {
            $result['error'] = 'Не удалось скачать .htaccess: ' . $e->getMessage();
            return $result;
        }
        $result['bytes_before'] = strlen($existing);

        // 2. Идемпотентность: проверяем что блока для этой пары доменов ещё нет
        if ($this->isBlockPresent($existing, $oldDomain, $newDomain)) {
            $result['ok'] = true;
            $result['was_present_before'] = true;
            $result['bytes_after'] = $result['bytes_before'];
            return $result;
        }

        // 3. Snapshot оригинала (если файл был)
        if ($hadFile) {
            $snapshotPath = $this->snapshotDir . '/.htaccess.before.txt';
            if (!is_dir($this->snapshotDir)) {
                @mkdir($this->snapshotDir, 0775, true);
            }
            if (@file_put_contents($snapshotPath, $existing) === false) {
                $result['error'] = "Не удалось сохранить snapshot: {$snapshotPath}";
                return $result;
            }
            $result['snapshot_path'] = $snapshotPath;
        }

        // 4. Формируем блок
        $block = $this->buildBlock($oldDomain, $newDomain, $jobId);
        $result['block_added'] = $block;

        // 5. Дописываем в конец (с переводом строки если нужно)
        $newContent = $existing;
        if ($newContent !== '' && substr($newContent, -1) !== "\n") {
            $newContent .= "\n";
        }
        if ($newContent !== '') {
            $newContent .= "\n"; // отступ от существующего содержимого
        }
        $newContent .= $block;
        if (substr($newContent, -1) !== "\n") {
            $newContent .= "\n";
        }

        $result['bytes_after'] = strlen($newContent);

        // 6. Заливаем обратно через FTP
        try {
            // v18-fix: backupExt = null — наш snapshot уже сохранён в
            // storage/snapshots/job_N/, дополнительный .bak на FTP не нужен
            // (накапливается мусор по всем джобам).
            $this->ftp->putContent('.htaccess', $newContent, null);
        } catch (\Throwable $e) {
            $result['error'] = 'Не удалось залить .htaccess: ' . $e->getMessage();
            return $result;
        }

        $result['ok'] = true;
        return $result;
    }

    /**
     * Проверить что блок для пары (old, new) уже присутствует.
     *
     * Идемпотентность важна потому что при retry стадия может выполниться повторно,
     * и без проверки мы получим дубликат блока.
     */
    public function isBlockPresent(string $htaccess, string $oldDomain, string $newDomain): bool
    {
        if ($htaccess === '') return false;

        // Стратегия: ищем строки RewriteCond, в которых упомянут old_domain,
        // и проверяем что в ~3 строках ниже есть RewriteRule с new_domain.
        // Не делаем точное regex-сравнение всей структуры — потому что в живом
        // .htaccess могут быть мелкие отличия (одна или две точки экранирования,
        // разный регистр в флагах, лишние пробелы), а нам важен СМЫСЛ: блок
        // редиректа этой пары доменов уже стоит.

        $oldNeedle = $this->domainNeedleRegex($oldDomain);
        $newNeedle = $this->domainNeedleRegex($newDomain);

        $lines = preg_split('~\R~', $htaccess);
        $n = count($lines);

        for ($i = 0; $i < $n; $i++) {
            $line = $lines[$i];
            // строка должна быть RewriteCond %{HTTP_HOST} ... <old_domain> ...
            if (stripos($line, 'RewriteCond') === false) continue;
            if (stripos($line, 'HTTP_HOST') === false) continue;
            if (!preg_match('~' . $oldNeedle . '~i', $line)) continue;

            // RewriteRule в апаче всегда идёт сразу после своего RewriteCond,
            // допускаем максимум одну пустую/комментарную строку между ними
            $tailEnd = min($n - 1, $i + 2);
            for ($j = $i + 1; $j <= $tailEnd; $j++) {
                $ruleLine = trim($lines[$j]);
                // пропускаем пустые строки и комментарии
                if ($ruleLine === '' || $ruleLine[0] === '#') continue;
                // должна быть RewriteRule
                if (stripos($ruleLine, 'RewriteRule') === false) {
                    // если попалась другая директива (например другой RewriteCond)
                    // — это уже не наш блок
                    break;
                }
                if (preg_match('~' . $newNeedle . '~i', $ruleLine)) {
                    return true;
                }
                // нашли RewriteRule, но с другим целевым доменом — это другой блок
                break;
            }
        }

        return false;
    }

    /**
     * Превратить домен в regex-needle с границами слова.
     *
     * Например "sykaaa-casino.top" → "(?<![a-zA-Z0-9])sykaaa\-casino\.top(?![a-zA-Z0-9])".
     * Перед каждой точкой разрешаем опциональный backslash, чтобы матчить и
     * "casino.top", и "casino\.top" (как в исходнике .htaccess с экранированием).
     * Это не путает "casino.top" с "casino-1.top" из-за lookaround на буквы/цифры.
     */
    private function domainNeedleRegex(string $domain): string
    {
        $escaped = preg_quote($domain, '~');
        // preg_quote экранирует точку как "\." → разрешим перед "." опциональный backslash
        $escaped = str_replace('\\.', '\\\\?\\.', $escaped);
        return '(?<![a-zA-Z0-9])' . $escaped . '(?![a-zA-Z0-9])';
    }

    /**
     * Сформировать сам текст блока.
     *
     * Точно соответствует образцу клиента:
     *
     *   RewriteCond %{HTTP_HOST} ^(www\.)?old\.casino$ [NC]
     *   RewriteRule ^ https://new.casino%{REQUEST_URI} [R=301,L]
     */
    public function buildBlock(string $oldDomain, string $newDomain, int $jobId): string
    {
        // Экранируем точки в RewriteCond regex (как в примере клиента)
        $oldEscaped = str_replace('.', '\\.', $oldDomain);
        // v18.1.28: timestamp в МСК — оператор читает .htaccess глазами через FTP.
        $ts = (new \DateTime('now', new \DateTimeZone('Europe/Moscow')))->format('Y-m-d H:i:s') . ' МСК';

        return
            "# === Refresh Panel: redirect {$oldDomain} → {$newDomain} (job #{$jobId} at {$ts}) ===\n" .
            "RewriteCond %{HTTP_HOST} ^(www\\.)?{$oldEscaped}\$ [NC]\n" .
            "RewriteRule ^ https://{$newDomain}%{REQUEST_URI} [R=301,L]";
    }

    /**
     * Откатить .htaccess из snapshot'а.
     *
     * Используется при failed-стадии или при ручном rollback.
     */
    public function rollback(string $snapshotPath): array
    {
        if (!is_file($snapshotPath)) {
            return ['ok' => false, 'error' => "snapshot not found: {$snapshotPath}"];
        }
        $content = @file_get_contents($snapshotPath);
        if ($content === false) {
            return ['ok' => false, 'error' => "cannot read snapshot: {$snapshotPath}"];
        }
        try {
            // v18-fix: rollback не делает свой .bak (мы откатываемся по snapshot,
            // дополнительный backup на FTP только мусорит)
            $this->ftp->putContent('.htaccess', $content, null);
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => 'put failed: ' . $e->getMessage()];
        }
        return ['ok' => true, 'bytes' => strlen($content)];
    }
}
