<?php

/**
 * ТЗ 040 §5.2: политика допустимых IP FastPanel-сервера.
 *
 * Единый источник истины «какие IP принадлежат серверу». Allowlist сервера —
 * это IP из host (если host — IPv4) плюс все валидные IPv4 из extra_ips.
 * Используется резолвером IP сайта и валидацией серверного профиля, чтобы:
 *   • НЕ отбрасывать stored IP только потому, что он совпал с API-IP панели
 *     (сайт законно может работать на том же IP, где слушает FastPanel) — §7.1;
 *   • НЕ подставлять IP другого сервера или произвольный extra_ips[0] — §7.3.
 *
 * IP сайтов по умолчанию на уровне сервера НЕ вводится (§3.3), поэтому метода
 * resolveDefault() здесь нет.
 *
 * Только валидация и разбор строк. Ни FastPanel API, ни HTTP/FTP.
 */
final class FastpanelServerIpPolicy
{
    /**
     * Все допустимые IPv4 сервера: host-IP + extra_ips. Уникальные, в порядке
     * появления (host первым, если он IP).
     *
     * @param array $server строка fastpanel_servers (минимум host, extra_ips)
     * @return array<int,string>
     */
    public function allowedIps(array $server): array
    {
        $out = [];

        $hostIp = $this->hostIp((string)($server['host'] ?? ''));
        if ($hostIp !== '') $out[] = $hostIp;

        foreach ($this->splitIps((string)($server['extra_ips'] ?? '')) as $ip) {
            $out[] = $ip;
        }

        // уникальные, с сохранением порядка
        return array_values(array_unique($out));
    }

    /**
     * Принадлежит ли IP серверу (валидный IPv4 и входит в allowlist).
     */
    public function isAllowed(array $server, string $ip): bool
    {
        $ip = trim($ip);
        if (!$this->isValidIp($ip)) return false;
        return in_array($ip, $this->allowedIps($server), true);
    }

    /**
     * IPv4 из host вида "95.129.234.20:8888" / "https://95.129.234.20/".
     * Если host — hostname (не IP), вернёт ''.
     */
    public function hostIp(string $host): string
    {
        $host = trim($host);
        if ($host === '') return '';
        $host = preg_replace('~^https?://~i', '', $host);
        $host = preg_replace('~/.*$~', '', (string)$host);   // сначала путь
        $host = preg_replace('~:\d+$~', '', (string)$host);  // затем порт
        $host = trim((string)$host);
        return $this->isValidIp($host) ? $host : '';
    }

    /**
     * Разобрать список extra_ips (через запятую/пробел/перенос строки),
     * оставить только валидные IPv4, уникальные, в порядке появления.
     *
     * @return array<int,string>
     */
    public function splitIps(string $raw): array
    {
        $raw = trim($raw);
        if ($raw === '') return [];
        $parts = preg_split('~[,;\s]+~', $raw) ?: [];
        $out = [];
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p !== '' && $this->isValidIp($p) && !in_array($p, $out, true)) {
                $out[] = $p;
            }
        }
        return $out;
    }

    public function isValidIp(string $ip): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
    }
}
