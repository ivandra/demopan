<?php

/**
 * ТЗ044 §5 — StageInvariantGuard: централизованные server-side postcondition-инварианты
 * перед переходом status=ok → nextStage. Работает в state machine (stepInternal), а не
 * только в UI: даже если контроллер/ручной SQL/будущий код ошибочно выставил 'ok',
 * оркестратор не имеет права перейти дальше при нарушенном контракте стадии.
 *
 * Никаких внешних вызовов (FTP/HTTP/Namecheap). Чистая проверка job+artifacts.
 */
final class StageInvariantGuard
{
    /**
     * Проверить инвариант перехода со стадии $stage (status=ok) дальше.
     * @return array ['ok'=>bool,'violation'=>?string,'details'=>?array]
     */
    public static function checkAdvance(string $stage, array $job, array $artifacts): array
    {
        switch ($stage) {
            case 'analyze_site':
                return self::checkAnalyzePlan($artifacts);
            case 'config_replaced':
                return self::checkConfigReadBack($artifacts, $job);
            case 'redirect_enable':
                return self::checkRedirectEnabled($artifacts);
        }
        return ['ok' => true, 'violation' => null, 'details' => null];
    }

    /** analyze_site → config_replaced: replacement_plan + config_mutation + SHA + target + expected. */
    public static function checkAnalyzePlan(array $artifacts): array
    {
        $plan = $artifacts['replacement_plan'] ?? null;
        if (!is_array($plan)) {
            return self::bad('missing_replacement_plan');
        }
        $cm = $plan['config_mutation'] ?? null;
        if (!is_array($cm)) {
            return self::bad('missing_config_mutation');
        }
        $sha = '~^[0-9a-f]{64}$~';
        if (!preg_match($sha, (string)($cm['source_sha256'] ?? ''))) return self::bad('invalid_source_sha256');
        if (!preg_match($sha, (string)($cm['target_sha256'] ?? ''))) return self::bad('invalid_target_sha256');
        if (trim((string)($cm['target_storage_path'] ?? '')) === '') return self::bad('missing_target_storage_path');
        if (!is_array($cm['expected'] ?? null)) return self::bad('missing_expected');
        return ['ok' => true, 'violation' => null, 'details' => null];
    }

    /** config_replaced → verify_replacement: read_back.ok (+ домен, если mutation требовалась). */
    public static function checkConfigReadBack(array $artifacts, array $job = []): array
    {
        $st = $artifacts['config_replaced_stage'] ?? null;
        if (!is_array($st)) return self::bad('missing_config_replaced_stage');
        $rb = $st['read_back'] ?? null;
        if (!is_array($rb) || empty($rb['ok'])) return self::bad('read_back_not_ok', is_array($rb) ? $rb : null);

        // BLOCKER B: replacement_plan.config_mutation ОБЯЗАТЕЛЕН на config_replaced → next.
        // Отсутствие плана = незаконный advance (тот самый баг #209) → fail-closed.
        $plan = $artifacts['replacement_plan']['config_mutation'] ?? null;
        if (!is_array($plan)) return self::bad('missing_config_mutation_plan');
        $wantSha = (string)($plan['target_sha256'] ?? '');
        if ($wantSha === '' || !preg_match('~^[0-9a-f]{64}$~i', $wantSha)) {
            return self::bad('missing_or_invalid_target_sha');
        }
        $haveSha = (string)($rb['target_sha256'] ?? '');
        if (!hash_equals($wantSha, $haveSha)) {
            return self::bad('read_back_target_sha_mismatch', ['have' => $haveSha, 'want' => $wantSha]);
        }
        if (!empty($plan['expected']['domain_required'])) {
            $want = self::bareDomain((string)($job['new_domain'] ?? ($plan['new_domain'] ?? '')));
            $have = self::bareDomain((string)($rb['domain'] ?? ''));
            if ($want !== '' && $have !== $want) {
                return self::bad('read_back_domain_mismatch', ['have' => $have, 'want' => $want]);
            }
        }
        $expSub = $plan['expected']['sub_id'] ?? null;
        if ($expSub !== null && (string)$expSub !== '' && isset($rb['sub_id']) && (string)$rb['sub_id'] !== (string)$expSub) {
            return self::bad('read_back_sub_id_mismatch', ['have' => (string)$rb['sub_id'], 'want' => (string)$expSub]);
        }
        return ['ok' => true, 'violation' => null, 'details' => null];
    }

    private static function bareDomain(string $d): string
    {
        $d = strtolower(trim($d));
        $d = preg_replace('~^https?://~', '', $d);
        $d = preg_replace('~[/?#].*$~', '', (string)$d);
        $d = preg_replace('~:\d+$~', '', (string)$d);
        return (string)preg_replace('~^www\.~', '', (string)$d);
    }

    /**
     * redirect_enable → далее (ТЗ §5.1/§9, BLOCKER 3): если стадия реально включала редирект
     * (не skipped/not_required), требуем artifact с ok=true, semantic read-back value=1 и
     * marker_count=0. Отсутствие read-back при обязательном redirect — fail-closed.
     */
    public static function checkRedirectEnabled(array $artifacts): array
    {
        // BLOCKER A: на переходе redirect_enable → next artifact ОБЯЗАТЕЛЕН. Отсутствие —
        // fail-closed (кроме явного not_required/skipped_by_site_toggle, которые пишет стадия).
        $st = $artifacts['redirect_enabled_stage'] ?? null;
        if (!is_array($st)) return self::bad('redirect_enable_artifact_missing');
        $action = (string)($st['action'] ?? '');
        if ($action === 'skipped_by_site_toggle' || $action === 'not_required'
            || !empty($st['not_required']) || !empty($st['skipped'])) {
            return ['ok' => true, 'violation' => null, 'details' => null];
        }
        if (empty($st['ok'])) return self::bad('redirect_enable_not_ok');
        if (!empty($st['remaining_markers'])) return self::bad('redirect_markers_remaining', ['markers' => $st['remaining_markers']]);
        if (!empty($st['post_validation_failed'])) return self::bad('redirect_post_validation_failed');

        // read_back ОБЯЗАТЕЛЕН для реально включённого redirect (нет флага → это legacy/ручной state).
        $rb = $st['read_back'] ?? null;
        if (!is_array($rb) || empty($rb['ok'])) return self::bad('redirect_read_back_missing_or_failed');
        if (($rb['value'] ?? null) !== null) {
            if ((int)$rb['value'] !== 1) return self::bad('redirect_read_back_not_enabled', ['value' => $rb['value']]);
            if ((int)($rb['marker_count'] ?? 1) !== 0) return self::bad('redirect_read_back_markers_present', ['marker_count' => $rb['marker_count']]);
        }
        return ['ok' => true, 'violation' => null, 'details' => null];
    }

    private static function bad(string $violation, ?array $details = null): array
    {
        return ['ok' => false, 'violation' => $violation, 'details' => $details];
    }
}
