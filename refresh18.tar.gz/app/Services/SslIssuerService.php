<?php

/**
 * Сервис выпуска SSL для refresh-сайтов.
 *
 * Упрощённая адаптация hub::WildcardSslService под нашу архитектуру:
 *  - один FP-сайт с многими алиасами
 *  - SSL ставится ТОЛЬКО на актуальный (последний) домен + его www
 *  - старые алиасы остаются без SSL (они мёртвые/выведены)
 *
 * НЕ использует отдельную таблицу job-ов, состояние держится в
 * artifacts_json.ssl_self_signed_stage и artifacts_json.ssl_le_stage
 * соответствующей refresh-джобы.
 *
 * Два публичных метода:
 *   - attachSelfSigned()  — мгновенно ставит self-signed (стадия ssl_self_signed_first)
 *   - pollLetsEncrypt()   — multi-tick: запрашивает и ждёт LE (стадия ssl_le_polling)
 */
class SslIssuerService
{
    /**
     * v15: Адаптивная стратегия polling вместо фиксированных 30 тиков.
     *
     * Polling идёт до 6 часов суммарно с расширяющимися интервалами.
     * Конкретный интервал между тиками определяется текущей фазой
     * (см. computeNextRunDelay() ниже):
     *
     *   Фаза 1: 0-15 мин   — каждые 60 сек  (15 попыток, DNS пропагация)
     *   Фаза 2: 15-60 мин  — каждые 5 мин   (9 попыток)
     *   Фаза 3: 1-3 часа   — каждые 15 мин  (8 попыток)
     *   Фаза 4: 3-6 часов  — каждые 30 мин  (6 попыток)
     *   ИТОГО: ~38 тиков, 6 часов
     *
     * Через 1 час шлём первый алерт в Telegram (warning).
     * Через 6 часов — переводим в awaiting_user (требуется ручное решение).
     */
    private const POLLING_TOTAL_SEC = 6 * 3600;       // 6 часов суммарно
    /** v25.2-a1.5: grace-период после txt_synced до resume-fallback (сек). */
    private const DNS_RESUME_GRACE_SEC = 240;
    private const FIRST_ALERT_AFTER_SEC = 3600;       // через 1 час — первый алерт

    /**
     * Guard'ы для auto-restart (берём из hub::WildcardSslService::canAutoRestartGuarded).
     * Защищают от LE rate-limits.
     */
    private const RESTART_MAX_PER_JOB = 3;          // максимум 3 рестарта на джобу
    private const RESTART_MIN_INTERVAL_SEC = 600;   // минимум 10 минут между рестартами
    private const CREATES_MAX_PER_HOUR = 3;         // <3 создания cert / час (LE failed-auth limit = 5)
    private const CREATES_MAX_PER_WEEK = 4;         // <4 создания cert / 168ч (LE exact-set limit = 5)

    /**
     * Ставит self-signed CN=domain, SAN=www.domain на FP-сайт.
     * Мгновенно (один HTTP-запрос к FP).
     *
     * Если уже привязан рабочий LE сертификат на этот домен — НЕ трогаем.
     *
     * @return array {
     *   ok: bool,
     *   action: 'created'|'reused'|'skipped'|'failed',
     *   certificate_id?: int,
     *   message: string,
     * }
     */
    public function attachSelfSigned(int $siteId, string $newDomain, JobEventLogger $log): array
    {
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'action' => 'failed', 'message' => "Site #{$siteId} not found"];
        }

        $fpSiteId = (int)($site['fp_site_id'] ?? 0);
        if ($fpSiteId <= 0) {
            return ['ok' => false, 'action' => 'failed', 'message' => 'Site has no fp_site_id'];
        }

        $newDomain = $this->normalizeDomain($newDomain);
        if ($newDomain === '') {
            return ['ok' => false, 'action' => 'failed', 'message' => 'Empty domain'];
        }

        $alternativeName = 'www.' . $newDomain;

        // === PREFLIGHT LIVE CHECK ===
        // Перед попыткой ставить self-signed — проверяем, может cert уже есть
        // (DDoS-Guard может выпустить cert на новый домен сам).
        try {
            $checker = $this->makeLiveChecker();
            $live = $checker->checkDomain($newDomain);
            if (!empty($live['ok']) && empty($live['is_self_signed'])) {
                $log->ok('ssl_self_signed_first',
                    "Live check: на {$newDomain} уже есть валидный cert " .
                    "(issuer={$live['issuer']}). Self-signed не нужен.");
                return [
                    'ok' => true,
                    'action' => 'skipped',
                    'certificate_id' => null,
                    'message' => "Live cert уже есть: {$live['issuer']}",
                    'live_check' => $live,
                ];
            }
        } catch (\Throwable $e) {
            // не блокируем, продолжаем обычный путь
        }

        $alternativeName = 'www.' . $newDomain;

        try {
            $fp = $this->makeFp($site);

            // 1) Что сейчас привязано к сайту?
            $state = $fp->getSiteCertificateState($fpSiteId);
            $currentCertId = (int)($state['cert_id'] ?? 0);
            $currentEnabled = (bool)($state['enabled'] ?? false);

            // 2) Если уже есть LE на этот же домен — не трогаем
            if ($currentEnabled && $currentCertId > 0) {
                try {
                    $cert = $fp->certificate($currentCertId);
                    if ($this->isLetsEncryptForDomain($cert, $newDomain) && $this->isReady($cert)) {
                        $log->info('ssl_self_signed_first',
                            "На сайте уже привязан LE сертификат cert_id={$currentCertId} на {$newDomain} — self-signed не нужен");
                        return [
                            'ok' => true,
                            'action' => 'skipped',
                            'certificate_id' => $currentCertId,
                            'message' => 'LE certificate already attached',
                        ];
                    }
                } catch (\Throwable $e) {
                    // не получилось получить детали — продолжаем нормальный путь
                }
            }

            // 3) Ищем существующий self-signed для этого домена
            $certs = $fp->certificates();
            if (!is_array($certs)) $certs = [];

            $existing = $this->findSelfSignedFor($certs, $newDomain);
            if ($existing) {
                $existingId = (int)($existing['id'] ?? 0);
                if ($currentEnabled && $currentCertId === $existingId) {
                    $log->info('ssl_self_signed_first',
                        "Self-signed cert_id={$existingId} уже привязан к сайту");
                    return [
                        'ok' => true,
                        'action' => 'skipped',
                        'certificate_id' => $existingId,
                        'message' => 'Self-signed already attached',
                    ];
                }

                // Применяем существующий
                $fp->applyCertificateToSite(
                    $fpSiteId, $existingId,
                    true,  // https_redirect
                    false, // hsts (на казино не нужен — мешает редирект-логике)
                    true,  // http2
                    false, // http3
                    false  // owncert
                );
                $log->ok('ssl_self_signed_first',
                    "Переиспользован существующий self-signed cert_id={$existingId} для {$newDomain}");
                return [
                    'ok' => true,
                    'action' => 'reused',
                    'certificate_id' => $existingId,
                    'message' => "Reused self-signed cert_id={$existingId}",
                ];
            }

            // 4) Создаём новый self-signed
            $email = trim((string)config('fastpanel.ssl_email', ''));
            if ($email === '') $email = 'admin@' . $newDomain;

            $created = $fp->createSelfSignedCertificate(
                $fpSiteId,
                $email,
                $newDomain,           // CN
                $alternativeName,     // SAN — одно имя www.domain
                2048,
                365
            );

            $newId = (int)($created['id'] ?? 0);
            if ($newId <= 0) {
                return [
                    'ok' => false,
                    'action' => 'failed',
                    'message' => 'FP did not return self-signed certificate id',
                ];
            }

            // 5) Привязываем к сайту
            $fp->applyCertificateToSite(
                $fpSiteId, $newId,
                true, false, true, false, false
            );

            $log->ok('ssl_self_signed_first',
                "Создан self-signed cert_id={$newId} (CN={$newDomain}, SAN={$alternativeName}) и привязан к FP-сайту");

            return [
                'ok' => true,
                'action' => 'created',
                'certificate_id' => $newId,
                'message' => "Created self-signed cert_id={$newId}",
            ];
        } catch (\Throwable $e) {
            $log->error('ssl_self_signed_first', "Ошибка self-signed: " . $e->getMessage());
            return [
                'ok' => false,
                'action' => 'failed',
                'message' => $e->getMessage(),
            ];
        }
    }

    /**
     * Запрашивает или поллит LE сертификат для нового домена.
     *
     * Это multi-tick стадия: оркестратор вызывает её многократно через cron,
     * каждый раз с актуальным состоянием из artifacts.ssl_le_stage.
     *
     * Tick 1 (state.cert_id отсутствует):
     *   — создаём LE-cert в FP с force_dns_validation=true
     *   — получаем auth_records (TXT-челленджи)
     *   — синхронизируем TXT в Namecheap (merge с существующими A/CNAME!)
     *   — возвращаем status='pending', cert_id=N
     *
     * Tick 2-N:
     *   — берём cert_id из state
     *   — вызываем certificate(certId) — проверяем status_id/error
     *   — если ready → applyCertificateToSite → возвращаем status='issued'
     *   — если errored:
     *     - rate-limit или stuck → status='failed_with_self_signed'
     *     - иначе ждём ещё → 'pending'
     *
     * @return array {
     *   status: 'pending'|'issued'|'failed_with_self_signed'|'failed',
     *   certificate_id?: int,
     *   message: string,
     *   tick_count: int,
     *   challenges?: array,    // для отладки (показывается в UI)
     * }
     */
    /**
     * v25.2-a1.1 (§Блокер 5): нормализованный результат тика с ПОЛНЫМ durable
     * ACME-state. Reconciler сохраняет result['state'] целиком, не зная схему.
     * Служебные поля (outcome/reason/message/next_poll_at) — отдельно от state.
     *
     * @param string $status issued|pending|awaiting_user|failed
     * @param string $phase  текущая фаза state machine
     * @param array  $extra  доп. служебные поля (reason/rate_limit_resume_at/live_check/...)
     */
    /**
     * §Блокер 4: гарантирует наличие полного 'state' в ЛЮБОМ return из
     * pollLetsEncrypt (даже терминальном issued/failed/rate_limited), не теряя
     * auto_restart_* и неизвестные поля. Мержит прежний state + текущие значения.
     */
    private function finalizeReturn(array $result, array $prevState, array $stateOverrides = []): array
    {
        $phase = (string)($stateOverrides['phase'] ?? ($prevState['phase'] ?? ''));
        $certId = array_key_exists('certificate_id', $result)
            ? (int)$result['certificate_id']
            : (int)($prevState['cert_id'] ?? 0);
        $startedAt = (int)($result['polling_started_at'] ?? ($prevState['polling_started_at'] ?? time()));
        $tickCount = (int)($result['tick_count'] ?? ($prevState['tick_count'] ?? 0));
        $extra = $stateOverrides;
        // reset_cert прокидывается через overrides при необходимости
        $result['state'] = $this->buildState($prevState, $phase, $certId, $startedAt, $tickCount, $extra);
        if (!isset($result['outcome'])) $result['outcome'] = (string)($result['status'] ?? '');
        return $result;
    }

    private function tickResult(string $status, string $phase, string $message,
        int $startedAt, int $tickCount, int $certId, array $prevState, array $extra = []): array
    {
        $state = $this->buildState($prevState, $phase, $certId, $startedAt, $tickCount, $extra);
        $next = $this->computeNextRunDelay($startedAt);
        $result = [
            // Служебные поля результата (не часть durable state):
            'status'      => $status,          // обратная совместимость со старым контрактом
            'outcome'     => $status,
            'reason'      => (string)($extra['reason'] ?? ''),
            'message'     => $message,
            'next_poll_at'=> date('Y-m-d H:i:s', time() + $next),
            // Обратная совместимость: старые вызовы читают эти ключи напрямую.
            'certificate_id' => $certId,
            'tick_count'  => $tickCount,
            'polling_started_at' => $startedAt,
            // Полный durable ACME-state (Блокер 5):
            'state'       => $state,
        ];
        foreach (['rate_limit_resume_at', 'guard_reason', 'live_check', 'challenges',
                  'auto_restart_count', 'auto_restart_last_at', 'auto_restart_last_reason'] as $k) {
            if (array_key_exists($k, $extra)) $result[$k] = $extra[$k];
            elseif (array_key_exists($k, $state)) $result[$k] = $state[$k];
        }
        return $result;
    }

    /**
     * Собрать нормализованный durable ACME-state по фиксированной внутренней схеме.
     * Мержит предыдущий state (сохраняя auto_restart_*, txt_synced_at, resume_sent_at
     * и любые уже накопленные поля), поверх — текущие значения.
     */
    private function buildState(array $prev, string $phase, int $certId, int $startedAt, int $tickCount, array $extra): array
    {
        // §Блокер 4: explicit reset — если явно передан reset_cert=true, cert_id=0
        // должен ОБНУЛИТЬ, а не восстановить старый. Иначе 0 = «не передан, взять прежний».
        $resetCert = !empty($extra['reset_cert']) || !empty($prev['_reset_cert']);
        if ($resetCert) {
            $effectiveCertId = 0;
        } else {
            $effectiveCertId = $certId > 0 ? $certId : (int)($prev['cert_id'] ?? 0);
        }
        $state = [
            'phase'                    => $phase,
            'cert_id'                  => $effectiveCertId,
            'polling_started_at'       => $startedAt,
            'tick_count'               => $tickCount,
            'challenges'               => $prev['challenges']            ?? null,
            'txt_synced_at'            => $prev['txt_synced_at']         ?? null,
            'dns_last_checked_at'      => $prev['dns_last_checked_at']   ?? null,
            'resume_sent_at'           => $prev['resume_sent_at']        ?? null,
            'auto_restart_count'       => (int)($prev['auto_restart_count'] ?? 0),
            'auto_restart_last_at'     => $prev['auto_restart_last_at']     ?? null,
            'auto_restart_last_reason' => $prev['auto_restart_last_reason'] ?? null,
            'rate_limit_resume_at'     => $prev['rate_limit_resume_at']  ?? null,
            'last_error'               => $prev['last_error']            ?? null,
            'long_wait_alerted_at'     => $prev['long_wait_alerted_at']  ?? null,
        ];
        // Сохраняем любые НЕИЗВЕСТНЫЕ поля из prev (Блокер 5: не терять то, что
        // reconciler не перечисляет) — кроме тех, что перекрываем ниже и служебного _reset_cert.
        foreach ($prev as $k => $v) {
            if ($k === '_reset_cert') continue;
            if (!array_key_exists($k, $state)) $state[$k] = $v;
        }
        // Текущий тик перекрывает поля из extra и служебных.
        foreach (['challenges','txt_synced_at','dns_last_checked_at','resume_sent_at',
                  'auto_restart_count','auto_restart_last_at','auto_restart_last_reason',
                  'rate_limit_resume_at','last_error','long_wait_alerted_at'] as $k) {
            if (array_key_exists($k, $extra)) $state[$k] = $extra[$k];
        }
        return $state;
    }

    public function pollLetsEncrypt(
        int $jobId,
        int $siteId,
        string $newDomain,
        ?int $registrarAccountId,
        ?array $stateFromArtifacts,
        JobEventLogger $log
    ): array {
        $state = $stateFromArtifacts ?? [];
        $tickCount = (int)($state['tick_count'] ?? 0) + 1;
        $newDomainNormalized = $this->normalizeDomain($newDomain);

        // === PREFLIGHT LIVE CHECK ===
        // Перед каждым тиком проверяем https://domain:443 напрямую через TLS-handshake.
        // Если cert уже валидный (выпущен Let's Encrypt / DDoS-Guard / Cloudflare) —
        // polling прекращается, считаем что задача SSL решена.
        // Это покрывает 3 кейса:
        //   1. DDoS-Guard сам выпустил cert на наш домен
        //   2. Наш LE-cert успел выпуститься между тиками (или после нашего timeout)
        //   3. Кто-то поправил cert вручную через FP UI
        $liveCheck = null;
        try {
            $checker = $this->makeLiveChecker();
            $liveCheck = $checker->checkDomain($newDomainNormalized);

            if (!empty($liveCheck['ok']) && empty($liveCheck['is_self_signed'])) {
                $issuerInfo = $liveCheck['issuer'] ?? 'unknown';
                $expiresInfo = $liveCheck['expires_at'] ?? '?';

                $log->ok('ssl_le_polling',
                    "✓ Live check: на {$newDomainNormalized} уже есть валидный cert " .
                    "(issuer={$issuerInfo}, expires={$expiresInfo}). LE polling завершается.");

                return $this->finalizeReturn([
                    'status' => 'issued',
                    'certificate_id' => (int)($state['cert_id'] ?? 0),
                    'message' => "Live check OK: {$issuerInfo} (expires {$expiresInfo})",
                    'tick_count' => $tickCount,
                    'live_check' => $liveCheck,
                ], $state, ['phase' => 'issued']);
            } elseif (!empty($liveCheck['is_self_signed'])) {
                $log->info('ssl_le_polling',
                    "Live check: на {$newDomainNormalized} self-signed (то что мы поставили). Продолжаю polling.");
            } elseif ($liveCheck['reason'] === 'connect_failed') {
                $log->info('ssl_le_polling',
                    "Live check: TLS connect failed ({$liveCheck['error']}). Продолжаю polling FP cert.");
            } else {
                $log->info('ssl_le_polling',
                    "Live check: reason={$liveCheck['reason']}. Продолжаю polling.");
            }
        } catch (\Throwable $e) {
            // Live check не критичен — если упал, просто продолжаем обычный polling
            $log->info('ssl_le_polling', "Live check exception (некритично): " . $e->getMessage());
        }

        // === v15: Проверка лимитов времени polling и rate-limit ===
        //
        // Логика:
        //   1. Если polling идёт > 6 часов → awaiting_user (cert не выпустился, нужно решение)
        //   2. Если LE/FP вернул rate-limit → сразу awaiting_user (никаких retries)
        //
        // ВАЖНО: убрали MAX_TICKS=30. Теперь polling идёт по времени с
        // расширяющимися интервалами (см. computeNextRunDelay).

        $startedAt = (int)($state['polling_started_at'] ?? 0);
        if ($startedAt === 0) {
            $startedAt = time();
        }
        $elapsedSec = time() - $startedAt;

        // v25.2-a1.2 (§Блокер 3): 6 часов — это ДОЛГОЕ ожидание, но НЕ короткое
        // замыкание ACME. Отмечаем флаг «долгое ожидание» (для одного alert выше по
        // стеку через классификатор) и ПРОДОЛЖАЕМ обычный state-machine poll, чтобы
        // уже готовый cert был обнаружен и применён. Никакого early-return.
        $longWait = ($elapsedSec >= self::POLLING_TOTAL_SEC);
        if ($longWait && empty($state['long_wait_alerted_at'])) {
            $log->warn('ssl_le_polling',
                "LE не выпустился за " . round($elapsedSec / 3600, 1) . " часов — продолжаю polling с увеличенным интервалом (один alert).");
            $state['long_wait_alerted_at'] = date('Y-m-d H:i:s');
        }

        $site = $this->loadSite($siteId);
        if ($site === null) {
            return $this->finalizeReturn(['status' => 'failed', 'message' => "Site #{$siteId} not found", 'tick_count' => $tickCount], $state);
        }

        $fpSiteId = (int)($site['fp_site_id'] ?? 0);
        if ($fpSiteId <= 0) {
            return $this->finalizeReturn(['status' => 'failed', 'message' => 'Site has no fp_site_id', 'tick_count' => $tickCount], $state);
        }

        $newDomain = $newDomainNormalized;
        $altName = 'www.' . $newDomain;

        try {
            $fp = $this->makeFp($site);

            // === STEP 1: Reconcile (поиск ЛЮБОГО подходящего LE cert) ===
            //
            // Это ключевое улучшение по сравнению с прошлыми версиями. Вместо того
            // чтобы полагаться на cert_id из artifacts (который может быть неточным
            // или указывать на удалённый/застрявший cert), мы запрашиваем ВЕСЬ список
            // certificates() из FP и ищем самый свежий **рабочий** LE cert
            // на наш домен (CN == new_domain И SAN содержит www.new_domain).
            //
            // Если такой cert уже существует и ready — применяем к сайту, polling завершается.

            $allCerts = [];
            try {
                $allCerts = $fp->certificates();
                if (!is_array($allCerts)) $allCerts = [];
            } catch (\Throwable $e) {
                $log->warn('ssl_le_polling', "Не удалось получить список cert'ов: " . $e->getMessage());
            }

            $bestExistingCert = $this->findBestLetsEncryptCert($allCerts, $newDomain);

            if ($bestExistingCert !== null) {
                $bestId = (int)($bestExistingCert['id'] ?? 0);
                // Получаем детали (могут быть в листинге частично)
                try {
                    $detail = $fp->certificate($bestId);
                    $bestExistingCert = $this->mergeCertificateState($detail, $bestExistingCert);
                } catch (\Throwable $e) {
                    // используем то что есть из листинга
                }

                if ($this->isReady($bestExistingCert)) {
                    // Cert готов. Проверяем привязку к сайту.
                    $siteState = [];
                    try { $siteState = $fp->getSiteCertificateState($fpSiteId); } catch (\Throwable $e) {}
                    $attachedId = (int)($siteState['cert_id'] ?? 0);
                    $attachedEnabled = (bool)($siteState['enabled'] ?? false);

                    if ($attachedId === $bestId && $attachedEnabled) {
                        $log->ok('ssl_le_polling',
                            "✓ LE cert_id={$bestId} ({$newDomain}) уже выпущен и привязан к сайту. Готово.");
                    } else {
                        // Cert ready, но не привязан — применяем сейчас
                        try {
                            $fp->applyCertificateToSite(
                                $fpSiteId, $bestId,
                                true, false, true, false, false
                            );
                            $log->ok('ssl_le_polling',
                                "✓ LE cert_id={$bestId} ({$newDomain}) ready, применён к сайту.");
                        } catch (\Throwable $e) {
                            $log->error('ssl_le_polling',
                                "Cert ready, но applyCertificateToSite упал: " . $e->getMessage());
                            return $this->finalizeReturn([
                                'status' => 'failed',
                                'message' => 'apply failed: ' . $e->getMessage(),
                                'tick_count' => $tickCount,
                                'certificate_id' => $bestId,
                                'live_check' => $liveCheck,
                            ], $state, ['last_error' => 'apply failed: ' . mb_substr($e->getMessage(),0,200)]);
                        }
                    }

                    return $this->finalizeReturn([
                        'status' => 'issued',
                        'certificate_id' => $bestId,
                        'message' => "LE cert {$bestId} attached to site",
                        'tick_count' => $tickCount,
                        'live_check' => $liveCheck,
                    ], $state, ['phase' => 'issued', 'cert_id' => $bestId]);
                }

                // Cert найден но НЕ ready — продолжаем polling с этим cert_id
                $certId = $bestId;
                $log->info('ssl_le_polling',
                    "Найден существующий LE cert_id={$certId} (CN={$newDomain}), но ещё не ready. Жду.");
            } else {
                // Не нашли подходящий cert — берём ID из state (может быть устарел)
                $certId = (int)($state['cert_id'] ?? 0);
            }

            // === STEP 2: создаём cert если ещё нет ===
            if ($certId <= 0) {
                $log->info('ssl_le_polling', "Tick {$tickCount}: запрашиваю LE cert для {$newDomain}");

                $email = trim((string)config('fastpanel.ssl_email', ''));
                if ($email === '') $email = 'admin@' . $newDomain;

                // v15: лог попытки create — нужен для guard'ов и UI истории
                $this->logAttempt($jobId, $siteId, $newDomain, null, 'create_requested',
                    "tick={$tickCount}, alt={$altName}");

                $created = $fp->createLetsEncryptCertificate(
                    $fpSiteId,
                    $email,
                    $newDomain,
                    $altName,
                    2048,
                    true  // force_dns_validation — нам это нужно потому что DDoS-Guard перед сайтом, http-01 не сработает
                );

                $certId = (int)($created['id'] ?? 0);
                if ($certId <= 0) {
                    // Возможно FP не вернул id, но cert всё равно создался.
                    // Перезапросим список и попробуем найти.
                    try {
                        $allCerts2 = $fp->certificates();
                        if (is_array($allCerts2)) {
                            $found = $this->findBestLetsEncryptCert($allCerts2, $newDomain);
                            if ($found !== null) {
                                $certId = (int)($found['id'] ?? 0);
                                $log->info('ssl_le_polling',
                                    "FP не вернул id в create, но в списке нашёлся cert_id={$certId} для {$newDomain}");
                            }
                        }
                    } catch (\Throwable $e) {}

                    if ($certId <= 0) {
                        return $this->finalizeReturn([
                            'status' => 'failed',
                            'message' => 'FP did not return LE certificate id and not found in list',
                            'tick_count' => $tickCount,
                        ], $state, ['last_error' => 'FP did not return LE certificate id']);
                    }
                }

                // v15: лог что cert приняли
                $this->logAttempt($jobId, $siteId, $newDomain, $certId, 'create_accepted',
                    "FP returned cert_id={$certId}");

                $log->info('ssl_le_polling', "Создан LE cert_id={$certId}. Фаза: ожидание TXT-challenges (следующий тик).");

                // v25.2-a1.1 (§Блокер 1): БЕЗ sleep. Сохраняем фазу cert_created и
                // выходим — TXT-challenges заберём на следующем тике через 15с.
                return $this->tickResult('pending', 'txt_sync_pending',
                    'Cert создан, ждём auth_records (следующий тик)', $startedAt, $tickCount, $certId, $state, [
                        'live_check' => $liveCheck,
                    ]);
            }

            // === v25.2-a1.1: НЕБЛОКИРУЮЩИЙ DNS/resume state machine ===
            // Фазы: txt_sync_pending → dns_check_pending → resume_pending →
            // resume_sent → issuance_pending. Один внешний шаг за тик, без sleep.
            $phase = (string)($state['phase'] ?? '');
            // Legacy/recovery: если фазы нет, но cert найден и resume ещё не
            // отправляли — входим в неблокирующий DNS/resume машину, а не сразу в STEP 4.
            if ($phase === '' && empty($state['resume_sent_at'])) {
                $phase = 'txt_sync_pending';
            }
            if (in_array($phase, ['txt_sync_pending', 'dns_check_pending', 'resume_pending'], true)) {
                $cert = $fp->certificate($certId);
                $authRecords = is_array($cert['auth_records'] ?? null) ? $cert['auth_records'] : [];

                if (empty($authRecords)) {
                    // auth_records ещё не готовы — ждём следующий тик.
                    return $this->tickResult('pending', 'txt_sync_pending',
                        'Waiting for FP to generate auth_records', $startedAt, $tickCount, $certId, $state, [
                            'live_check' => $liveCheck,
                        ]);
                }

                // Синхронизируем TXT в Namecheap — ОДИН раз (идемпотентно по флагу).
                if (empty($state['txt_synced_at'])) {
                    if ($registrarAccountId !== null && $registrarAccountId > 0) {
                        try {
                            $this->syncChallengesToNamecheap($registrarAccountId, $newDomain, $authRecords, $log);
                            $state['txt_synced_at'] = date('Y-m-d H:i:s');
                        } catch (\Throwable $e) {
                            $log->error('ssl_le_polling', "TXT sync failed: " . $e->getMessage());
                            return $this->tickResult('failed', 'txt_sync_pending',
                                'TXT sync failed: ' . $e->getMessage(), $startedAt, $tickCount, $certId, $state, [
                                    'live_check' => $liveCheck,
                                ]);
                        }
                    } else {
                        $log->warn('ssl_le_polling', 'registrar_account_id не задан — TXT не синхронизированы.');
                    }
                }

                // ОДНА DNS-проверка за тик (без цикла/sleep).
                $challengesForDns = $this->extractChallengesForDns($authRecords);
                $state['challenges'] = $this->extractChallengesSummary($authRecords);
                $dnsReady = $this->checkChallengesInDnsOnce($newDomain, $challengesForDns, $log);

                // v25.2-a1.5 (live-fix, kazik5): DNS self-check — это ОПТИМИЗАЦИЯ,
                // а не жёсткий гейт навсегда. Наш resolver может не видеть TXT, даже
                // когда они реально в Namecheap: dig не установлен на сервере,
                // рекурсор держит negative-cache, apex фронтится ddos-guard и т.п.
                // Чтобы выпуск НЕ зависал вечно (как в проде на kazik5.casino), после
                // grace-периода с момента txt_synced отправляем resume ОДИН раз и
                // даём Let's Encrypt быть финальной инстанцией валидации.
                $graceSec = $this->dnsResumeGraceSec();
                $syncedAt = !empty($state['txt_synced_at']) ? strtotime((string)$state['txt_synced_at']) : 0;
                $graceElapsed = ($syncedAt > 0) && ((time() - $syncedAt) >= max(30, $graceSec));

                if (!$dnsReady && !$graceElapsed) {
                    // Ещё в grace-окне и TXT не подтверждены — ждём следующий тик (15с).
                    $state['dns_last_checked_at'] = date('Y-m-d H:i:s');
                    $waited = $syncedAt > 0 ? (time() - $syncedAt) : 0;
                    return $this->tickResult('pending', 'dns_check_pending',
                        "TXT синхронизированы, ждём пропагации ({$waited}с/{$graceSec}с до resume-fallback)", $startedAt, $tickCount, $certId, $state, [
                            'live_check' => $liveCheck,
                        ]);
                }

                // v25.2-a1.6 (§9): перед escape-hatch — защита от provider-mismatch.
                // Если РЕАЛЬНЫЕ authoritative NS определены и они НЕ Namecheap (куда
                // панель писала TXT) — resume заведомо провалится (LE спросит реальные
                // NS, там TXT нет). Не жжём 3 неуспешных order, а помечаем fatal и
                // показываем оператору конкретную причину. Escape разрешён, только
                // если: реальные NS не определить ИЛИ provider совпадает ИЛИ TXT
                // подтверждён публичным resolver (dnsReady=true).
                if (!$dnsReady && $graceElapsed && empty($state['resume_sent_at'])) {
                    $realNs = $this->resolveDomainNs($newDomain);
                    if (!empty($realNs) && !$this->nsSetUsesNamecheap($realNs, ['dns1.registrar-servers.com', 'dns2.registrar-servers.com'])) {
                        $state['fatal'] = true;
                        $state['fatal_reason'] = 'dns_provider_mismatch';
                        $state['fatal_message'] = 'Реальные authoritative NS домена не Namecheap (' . implode(', ', array_slice($realNs, 0, 4)) . '), '
                            . 'а TXT-челленджи записаны в Namecheap. Let\'s Encrypt их не увидит. '
                            . 'Проверьте делегацию NS или перенесите DNS-зону в Namecheap.';
                        $state['fatal_at'] = date('Y-m-d H:i:s');
                        $state['actual_ns'] = array_slice($realNs, 0, 8);
                        $state['txt_provider'] = 'namecheap';
                        $log->error('ssl_le_polling', 'DNS provider mismatch: ' . $state['fatal_message'] . ' Resume НЕ отправляю (fail-fast).');
                        return $this->tickResult('awaiting_user', 'dns_provider_mismatch',
                            'DNS provider mismatch — нужна корректировка делегации NS оператором', $startedAt, $tickCount, $certId, $state, [
                                'live_check' => $liveCheck,
                            ]);
                    }
                    $log->warn('ssl_le_polling',
                        "DNS self-check не подтвердил TXT за {$graceSec}с после синхронизации — " .
                        "отправляю resume (LE проверит записи сам). Если LE тоже не увидит — вернётся реальная ошибка авторизации.");
                }

                // DNS готов — resume РОВНО один раз, resume_sent_at ТОЛЬКО после
                // подтверждённого успеха (§Блокер 1). При ошибке — остаёмся в
                // resume_pending, повторим на следующем тике.
                if (empty($state['resume_sent_at'])) {
                    try {
                        $fp->resumeCertificate($certId);
                        $state['resume_sent_at'] = date('Y-m-d H:i:s');
                        $log->info('ssl_le_polling', "✓ DNS пропагирован, resume вызван — LE начинает валидацию.");
                    } catch (\Throwable $e) {
                        $emsg = $e->getMessage();
                        $emsgL = mb_strtolower($emsg);
                        // §Пункт 7: НЕ трактуем 'already failed' как успех. Только явно
                        // «уже resumed / already processing / not suspended» И только
                        // после ПОВТОРНОГО ЧТЕНИЯ cert, подтверждающего живой order.
                        $ambiguousOk = (bool)preg_match('~already\s+resumed|already\s+processing|not\s+suspend~i', $emsg);
                        $ambiguousBad = (bool)preg_match('~already\s+failed|order\s+failed|failed\s+authoriz|invalid~i', $emsg);
                        if ($ambiguousOk && !$ambiguousBad) {
                            // Перечитываем cert: подтверждаем что он НЕ failed/suspended.
                            $certOk = false;
                            try {
                                $c2 = $fp->certificate($certId);
                                $err2 = $this->extractError($c2);
                                $isFailed = ($err2 !== '' && preg_match('~fail|error|invalid|suspend~i', $err2));
                                // живой = ready ИЛИ (нет фатальной ошибки и есть auth_records/статус выпуска)
                                $certOk = $this->isReady($c2) || !$isFailed;
                            } catch (\Throwable $e2) {
                                $certOk = false; // не смогли перечитать — не подтверждаем
                            }
                            if ($certOk) {
                                $state['resume_sent_at'] = date('Y-m-d H:i:s');
                                $log->info('ssl_le_polling', "resume: '{$emsg}' — cert перечитан, order живой, считаем resume выполненным.");
                            } else {
                                $log->warn('ssl_le_polling', "resume: '{$emsg}', но повторное чтение cert показало проблему — повтор на следующем тике.");
                                $state['last_error'] = mb_substr($emsg, 0, 250);
                                return $this->tickResult('pending', 'resume_pending',
                                    'resume неоднозначен, cert не подтверждён — повтор', $startedAt, $tickCount, $certId, $state, [
                                        'live_check' => $liveCheck, 'last_error' => mb_substr($emsg, 0, 250),
                                    ]);
                            }
                        } else {
                            // Настоящая ошибка (timeout/5xx/недоступен/already failed) — resume НЕ выполнен.
                            $log->warn('ssl_le_polling', "resume не выполнен ({$emsg}) — повтор на следующем тике.");
                            $state['last_error'] = mb_substr($emsg, 0, 250);
                            return $this->tickResult('pending', 'resume_pending',
                                'resume не выполнен, повтор на следующем тике', $startedAt, $tickCount, $certId, $state, [
                                    'live_check' => $liveCheck,
                                    'last_error' => mb_substr($emsg, 0, 250),
                                ]);
                        }
                    }
                }
                return $this->tickResult('pending', 'issuance_pending',
                    'TXT пропагирован, resume отправлен. Жду валидации LE.', $startedAt, $tickCount, $certId, $state, [
                        'live_check' => $liveCheck,
                    ]);
            }

            // === STEP 4: ПОСЛЕДУЮЩИЕ ТИКИ: проверяем статус cert_id ===
            $log->info('ssl_le_polling', "Tick {$tickCount}: проверяю статус cert_id={$certId}");

            $cert = $fp->certificate($certId);
            $statusId = (int)($cert['status_id'] ?? 0);
            $errorText = $this->extractError($cert);

            if ($this->isReady($cert)) {
                // Применяем к сайту
                $fp->applyCertificateToSite(
                    $fpSiteId, $certId,
                    true, false, true, false, false
                );
                $log->ok('ssl_le_polling',
                    "✓ LE сертификат cert_id={$certId} выпущен и привязан к сайту");

                $this->logAttempt($jobId, $siteId, $newDomain, $certId, 'issued',
                    "LE issued after " . $elapsedSec . "s polling, " . $tickCount . " ticks");

                return $this->finalizeReturn([
                    'status' => 'issued',
                    'certificate_id' => $certId,
                    'message' => "LE certificate issued and applied",
                    'tick_count' => $tickCount,
                    'polling_started_at' => $startedAt,
                ], $state, ['phase' => 'issued']);
            }

            if ($errorText !== '') {
                // === v15: Rate-limit detection ===
                // Если LE/FP вернул rate-limit — НЕ продолжаем polling, переходим в
                // awaiting_user. Дальнейшие попытки только усугубят ситуацию (особенно
                // exact-set-of-identifiers — попадание = недельный бан).
                if ($this->isRateLimitMessage($errorText)) {
                    $log->error('ssl_le_polling',
                        "🚨 RATE LIMIT от Let's Encrypt: {$errorText}. " .
                        "Останавливаю polling — продолжение усугубит ситуацию.");

                    $this->logAttempt($jobId, $siteId, $newDomain, $certId, 'rate_limited', $errorText);

                    $resumeAt = $this->parseRetryAfterFromMessage($errorText);

                    return $this->finalizeReturn([
                        'status' => 'awaiting_user',
                        'certificate_id' => $certId,
                        'message' => "Rate-limit: {$errorText}",
                        'tick_count' => $tickCount,
                        'polling_started_at' => $startedAt,
                        'reason' => 'rate_limited',
                        'rate_limit_resume_at' => $resumeAt,
                    ], $state, ['rate_limit_resume_at' => $resumeAt, 'last_error' => mb_substr($errorText,0,200)]);
                }

                // === v15: Auto-restart for stuck order ===
                // Если order застрял с ACME-ошибкой (urn:ietf:params:acme:error:*) —
                // её нельзя "разлочить" обычным polling'ом, нужно создать новый order.
                // Но только с защитой от LE rate-limits!
                if ($this->isOrderStuckMessage($errorText)) {
                    [$canRestart, $guardReason] = $this->canAutoRestartGuarded(
                        $state, $siteId, $jobId, $newDomain
                    );

                    if ($canRestart) {
                        $restartCount = (int)($state['auto_restart_count'] ?? 0) + 1;
                        $log->warn('ssl_le_polling',
                            "Order застрял ({$errorText}). Auto-restart #{$restartCount}/3. " .
                            "Создаю новый order с нуля...");

                        $this->logAttempt($jobId, $siteId, $newDomain, $certId, 'auto_restart',
                            "count={$restartCount} reason=" . substr($errorText, 0, 200));

                        // Удаляем застрявший cert (не критично если упадёт)
                        try {
                            $fp->deleteCertificate($certId);
                        } catch (\Throwable $e) {
                            $log->info('ssl_le_polling', "Не удалось удалить застрявший cert_id={$certId}: " . $e->getMessage());
                        }

                        // Возвращаем pending со сброшенным cert_id — следующий tick создаст новый
                        $state['auto_restart_count'] = $restartCount;
                        $state['auto_restart_last_at'] = date('Y-m-d H:i:s');
                        $state['auto_restart_last_reason'] = substr($errorText, 0, 250);
                        // §Блокер 4: явный reset cert_id и фазы — новый order с нуля.
                        $state['phase'] = '';
                        $state['txt_synced_at'] = null;
                        $state['resume_sent_at'] = null;
                        return $this->tickResult('pending', '', "Auto-restart #{$restartCount} after stuck order",
                            $startedAt, $tickCount, 0, $state, [
                                'reset_cert' => true,
                                'auto_restart_count' => $restartCount,
                                'auto_restart_last_at' => $state['auto_restart_last_at'],
                                'auto_restart_last_reason' => $state['auto_restart_last_reason'],
                                'txt_synced_at' => null,
                                'resume_sent_at' => null,
                            ]);
                    }

                    // Guard заблокировал auto-restart — переходим в awaiting_user
                    $log->error('ssl_le_polling',
                        "Order застрял, но auto-restart заблокирован: {$guardReason}. " .
                        "Перехожу в awaiting_user, нужно ручное решение.");

                    return $this->finalizeReturn([
                        'status' => 'awaiting_user',
                        'certificate_id' => $certId,
                        'message' => "Stuck order, auto-restart blocked: {$guardReason}",
                        'tick_count' => $tickCount,
                        'polling_started_at' => $startedAt,
                        'reason' => 'restart_blocked',
                        'guard_reason' => $guardReason,
                    ], $state, ['last_error' => 'restart_blocked: ' . mb_substr((string)$guardReason,0,150)]);
                }

                // Иначе обычная "ещё не готов" — ждём следующий tick
                $log->info('ssl_le_polling',
                    "LE cert_id={$certId} ещё не готов: {$errorText}. Жду следующий tick.");
                $state['last_error'] = substr($errorText, 0, 250);
            }

            return $this->tickResult('pending', (string)($state['phase'] ?? 'issuance_pending'),
                "LE cert status_id={$statusId}, ожидаю выпуска", $startedAt, $tickCount, $certId, $state);
        } catch (\Throwable $e) {
            $log->error('ssl_le_polling', "Exception: " . $e->getMessage());
            $state['last_error'] = substr($e->getMessage(), 0, 250);
            return $this->tickResult('failed', (string)($state['phase'] ?? ''),
                $e->getMessage(), $startedAt, $tickCount, (int)($state['cert_id'] ?? 0), $state);
        }
    }

    // ===================== HELPERS =====================

    private function syncChallengesToNamecheap(
        int $registrarAccountId,
        string $domain,
        array $authRecords,
        JobEventLogger $log
    ): void {
        // Фильтруем только валидные TXT-челленджи
        $challenges = array_values(array_filter($authRecords, function ($c) {
            return is_array($c)
                && trim((string)($c['name'] ?? '')) !== ''
                && trim((string)($c['value'] ?? '')) !== '';
        }));

        if (empty($challenges)) {
            throw new \RuntimeException('No challenge records to sync');
        }

        $acc = $this->loadRegistrarAccount($registrarAccountId);
        if (!$acc) {
            throw new \RuntimeException('Namecheap account not found id=' . $registrarAccountId);
        }
        $nc = $this->makeNamecheapClient($acc);
        [$sld, $tld] = $nc->splitSldTld($domain);

        $existing = $this->normalizeNamecheapHosts($nc->getHosts($sld, $tld));
        if (empty($existing)) {
            throw new \RuntimeException('Namecheap getHosts returned empty — abort to avoid wiping zone');
        }

        // Собираем целевые TXT
        $desired = [];
        $hostsToReplace = [];
        foreach ($challenges as $challenge) {
            $host = $this->relativeHostForDomain((string)($challenge['name'] ?? ''), $domain);
            $type = strtoupper(trim((string)($challenge['type'] ?? 'TXT')));
            $value = trim((string)($challenge['value'] ?? ''));
            if ($host === '' || $type !== 'TXT' || $value === '') continue;

            $key = strtolower($host) . '|' . $type . '|' . $value;
            $desired[$key] = [
                'host' => $host,
                'type' => $type,
                'address' => $value,
                'ttl' => 300,
            ];
            $hostsToReplace[strtolower($host)] = true;
        }

        if (empty($desired)) {
            throw new \RuntimeException('Computed TXT set is empty');
        }

        // Merge: убираем старые TXT с теми же host (от прошлых попыток), сохраняем всё остальное
        $merged = [];
        foreach ($existing as $row) {
            $rowHost = strtolower(trim((string)($row['host'] ?? '')));
            $rowType = strtoupper(trim((string)($row['type'] ?? '')));
            if ($rowType === 'TXT' && isset($hostsToReplace[$rowHost])) continue;
            $merged[] = $row;
        }
        foreach ($desired as $row) {
            $merged[] = $row;
        }

        $nc->setHosts($sld, $tld, $merged);

        $log->info('ssl_le_polling',
            'TXT синхронизирован в Namecheap: ' . count($desired) . ' записей для ' . $domain);
    }

    private function extractChallengesSummary(array $authRecords): array
    {
        $out = [];
        foreach ($authRecords as $rec) {
            if (!is_array($rec)) continue;
            $name = (string)($rec['name'] ?? '');
            $value = (string)($rec['value'] ?? '');
            if ($name !== '' && $value !== '') {
                $out[] = [
                    'name' => $name,
                    'value' => mb_substr($value, 0, 50) . (mb_strlen($value) > 50 ? '...' : ''),
                    'type' => (string)($rec['type'] ?? 'TXT'),
                ];
            }
        }
        return $out;
    }

    private function relativeHostForDomain(string $recordName, string $domain): string
    {
        $recordName = strtolower(rtrim(trim($recordName), '.'));
        $domain = strtolower(rtrim(trim($domain), '.'));
        if ($recordName === '' || $domain === '') return '';
        if ($recordName === $domain) return '@';
        $suffix = '.' . $domain;
        if (substr($recordName, -strlen($suffix)) === $suffix) {
            return substr($recordName, 0, -strlen($suffix));
        }
        return $recordName;
    }

    private function normalizeNamecheapHosts(array $hosts): array
    {
        $out = [];
        foreach ($hosts as $h) {
            if (!is_array($h)) continue;
            $host = (string)($h['host'] ?? $h['HostName'] ?? $h['Name'] ?? '');
            $type = (string)($h['type'] ?? $h['RecordType'] ?? $h['Type'] ?? '');
            $addr = (string)($h['address'] ?? $h['Address'] ?? ($h['Value'] ?? ''));
            $ttl = (int)($h['ttl'] ?? $h['TTL'] ?? 300);
            $row = [
                'host' => trim($host),
                'type' => strtoupper(trim($type)),
                'address' => trim($addr),
                'ttl' => $ttl > 0 ? $ttl : 300,
            ];
            if (isset($h['mxpref']) || isset($h['MXPref'])) {
                $row['mxpref'] = (int)($h['mxpref'] ?? $h['MXPref']);
            }
            if ($row['host'] === '' || $row['type'] === '' || $row['address'] === '') continue;
            $out[] = $row;
        }
        return $out;
    }

    /**
     * Ищет в списке сертификатов self-signed для указанного домена.
     */
    private function findSelfSignedFor(array $certs, string $domain): ?array
    {
        $domainLower = strtolower(trim($domain));
        foreach ($certs as $c) {
            if (!is_array($c)) continue;
            $type = strtolower(trim((string)($c['type'] ?? '')));
            if ($type !== 'self_signed') continue;
            $cn = strtolower(trim((string)($c['common_name'] ?? '')));
            if ($cn !== $domainLower) continue;
            return $c;
        }
        return null;
    }

    /**
     * Ищет в полном списке certificates() лучший подходящий LE cert на наш домен.
     *
     * Критерии:
     *   - type == 'letsencrypt'
     *   - common_name == new_domain
     *   - В alternative_name содержит www.new_domain (или just new_domain)
     *   - НЕ просрочен (validTo > now, если поле есть)
     *
     * Сортировка (от лучшего к худшему):
     *   1. Готовые (есть body+private_key) выше pending
     *   2. Без action='SUSPEND' выше suspended
     *   3. Самые свежие created_at выше старых
     *   4. Больший id выше меньшего (тоже косвенно "новее")
     */
    private function findBestLetsEncryptCert(array $certificates, string $domain): ?array
    {
        $domainLower = strtolower(trim($domain));
        $altRequired = 'www.' . $domainLower;

        $candidates = [];
        foreach ($certificates as $cert) {
            if (!is_array($cert)) continue;
            $type = strtolower(trim((string)($cert['type'] ?? '')));
            if ($type !== 'letsencrypt') continue;

            $cn = strtolower(trim((string)($cert['common_name'] ?? '')));
            if ($cn !== $domainLower) continue;

            // Проверяем SAN — в alternative_name должно быть www
            $altNames = $this->certificateAltNames($cert);
            $hasWww = in_array($altRequired, $altNames, true) || in_array($domainLower, $altNames, true);
            if (!$hasWww && !empty($altNames)) {
                // Если SAN список заполнен и в нём нет ни domain ни www.domain — пропускаем
                continue;
            }

            // Проверка просрочки (если поле есть)
            $validTo = trim((string)($cert['valid_to'] ?? $cert['validTo'] ?? $cert['expires_at'] ?? ''));
            if ($validTo !== '') {
                $validTs = strtotime($validTo);
                if ($validTs !== false && $validTs > 0 && $validTs < time()) {
                    continue; // просрочен
                }
            }

            $candidates[] = $cert;
        }

        if (empty($candidates)) return null;

        usort($candidates, function ($a, $b) {
            // Готовые > не готовые
            $aReady = $this->isReady($a) ? 1 : 0;
            $bReady = $this->isReady($b) ? 1 : 0;
            if ($aReady !== $bReady) return $bReady - $aReady;

            // Не SUSPEND > SUSPEND
            $aAction = strtoupper(trim((string)($a['action'] ?? '')));
            $bAction = strtoupper(trim((string)($b['action'] ?? '')));
            $aSusp = ($aAction === 'SUSPEND') ? 1 : 0;
            $bSusp = ($bAction === 'SUSPEND') ? 1 : 0;
            if ($aSusp !== $bSusp) return $aSusp - $bSusp;

            // Свежие > старые
            $aCreated = strtotime((string)($a['created_at'] ?? '')) ?: 0;
            $bCreated = strtotime((string)($b['created_at'] ?? '')) ?: 0;
            if ($aCreated !== $bCreated) return $bCreated - $aCreated;

            // Бо́льший id > меньший
            return ((int)($b['id'] ?? 0)) - ((int)($a['id'] ?? 0));
        });

        return $candidates[0];
    }

    /** Извлечь список SAN-имён из cert (нормализованные lowercase). */
    private function certificateAltNames(array $cert): array
    {
        $names = [];
        $alt = $cert['alternative_name'] ?? null;
        if (is_string($alt) && $alt !== '') {
            // строка через запятую/пробел
            foreach (preg_split('~[\s,]+~', $alt) as $n) {
                $n = strtolower(trim($n, " \t\n\r\0\x0B."));
                if ($n !== '') $names[] = $n;
            }
        } elseif (is_array($alt)) {
            foreach ($alt as $n) {
                if (!is_string($n)) continue;
                $n = strtolower(trim($n, " \t\n\r\0\x0B."));
                if ($n !== '') $names[] = $n;
            }
        }
        return array_values(array_unique($names));
    }

    /** Объединить детали из certificate(id) c записью из списка certificates(). */
    private function mergeCertificateState(array $detail, array $listRow): array
    {
        if (!$listRow) return $detail;
        $out = $detail;
        $keys = ['action', 'state', 'request', 'certificate', 'body', 'chain', 'private_key',
                 'created_at', 'common_name', 'alternative_name', 'type', 'wildcard',
                 'valid_to', 'expires_at', 'auth_records'];
        foreach ($keys as $key) {
            $detailVal = $out[$key] ?? null;
            $listVal = $listRow[$key] ?? null;
            $detailEmpty = $detailVal === null || $detailVal === '' || $detailVal === [];
            if ($detailEmpty && $listVal !== null && $listVal !== '' && $listVal !== []) {
                $out[$key] = $listVal;
            }
        }
        return $out;
    }

    /** Преобразует auth_records от FP в нормализованный список TXT challenges. */
    private function extractChallengesForDns(array $authRecords): array
    {
        $out = [];
        foreach ($authRecords as $rec) {
            if (!is_array($rec)) continue;
            $name = trim((string)($rec['name'] ?? ''));
            $value = trim((string)($rec['value'] ?? ''));
            $type = strtoupper(trim((string)($rec['type'] ?? 'TXT')));
            if ($name === '' || $value === '' || $type !== 'TXT') continue;
            $out[] = ['name' => $name, 'value' => $value, 'type' => $type];
        }
        return $out;
    }

    /**
     * Запрашивает TXT-записи через указанный DNS-сервер (минуя локальный resolver).
     * Возвращает null если dig не отработал, или массив значений TXT.
     */
    protected function queryAuthoritativeTxt(string $fqdn, string $nameserver, int $timeoutSec = 5): ?array
    {
        $fqdn = trim($fqdn, ".\t \r\n");
        if ($fqdn === '') return null;

        $cmd = sprintf(
            'dig +short +tries=1 +time=%d TXT %s @%s 2>/dev/null',
            max(1, $timeoutSec),
            escapeshellarg($fqdn),
            escapeshellarg($nameserver)
        );

        $output = @shell_exec($cmd);
        if ($output === null || $output === false) return null;

        $lines = preg_split('/\r?\n/', trim((string)$output));
        $values = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;
            // dig +short может вернуть TXT в формате "abc" "def" — склеиваем
            if (preg_match_all('/"((?:[^"\\\\]|\\\\.)*)"/', $line, $matches)) {
                $values[] = implode('', $matches[1]);
            } else {
                $values[] = $line;
            }
        }
        return $values;
    }

    /**
     * Дожидается пока ВСЕ challenges реально появятся в TXT на authoritative NS Namecheap.
     *
     * Это критично: после синхронизации TXT через Namecheap API нужно ~5-30 секунд
     * чтобы записи появились на dns1./dns2.registrar-servers.com. Если LE начнёт
     * валидацию ДО пропагации — получит NXDOMAIN, и после 3-х подряд срабатывает
     * failed-auth limit (5/час) → недельный бан "exact set of identifiers".
     *
     * Возвращает true если challenges видны (или dig недоступен — fallback на sleep).
     * Возвращает false если за timeoutSec не пропагировались.
     */
    /**
     * v25.2-a1.3 (§Пункт 6): ОДНА fail-CLOSED проверка TXT на resolver'ах, с
     * ПОЛИТИКОЙ ПО RESOLVER'У. Каждый resolver независимо подтверждает ВЕСЬ набор
     * ожидаемых TXT (resolverConfirmedAll). Возвращает true только если политика
     * выполнена; иначе false (resume не шлём). Пустой нормализованный набор при
     * НЕПУСТОМ входе challenges → false (не считаем успехом).
     *
     * Политика: для Namecheap DNS — оба authoritative NS подтвердили всё; если
     * authoritative NS определить/опросить нельзя — хотя бы один проверенный
     * publiс resolver (dig @NS или PHP) подтвердил весь набор.
     */
    private function checkChallengesInDnsOnce(string $domain, array $challenges, JobEventLogger $log): bool
    {
        $domain = trim($domain, '. ');
        if ($domain === '') return true;
        // §6: различаем «нет challenges» и «challenges были, но не распознались».
        if (empty($challenges)) return true; // действительно нечего проверять

        $expected = [];
        foreach ($challenges as $c) {
            $name = trim((string)($c['name'] ?? ''), '. ');
            $value = trim((string)($c['value'] ?? ''));
            $type = strtoupper(trim((string)($c['type'] ?? 'TXT')));
            if ($name === '' || $value === '' || $type !== 'TXT') continue;
            if (!isset($expected[$name])) $expected[$name] = [];
            $expected[$name][$value] = true;
        }
        // §6: вход был непустой, но нормализация дала пустой набор → НЕ успех.
        if (empty($expected)) {
            $log->warn('ssl_le_polling',
                'DNS: auth_records непустые, но TXT-challenges не распознаны — resume НЕ шлём (fail-closed).');
            return false;
        }

        // v25.2-a1.4/a1.4.1 (§Блокер): определяем РЕАЛЬНЫЕ authoritative NS домена.
        $realNs = $this->resolveDomainNs($domain);          // список реальных NS или []

        // PHP recursive resolver (публичный) — независимый и всегда опрашивается.
        $phpConfirmed = $this->resolverConfirmedAll(
            $expected, function ($fqdn) { return $this->queryTxtViaPhp($fqdn); }
        );

        // ───────────────────────────────────────────────────────────────────
        // v25.2-a1.4.1 (§Блокер): если реальная делегация NS ещё НЕ видна
        // (realNs=[]), прямой ответ hardcoded Namecheap NS НЕЛЬЗЯ считать
        // доказательством публичной DNS-готовности — LE валидирует через
        // публичную делегацию, а не через принудительный запрос к предполагаемому
        // Namecheap NS. Требуем подтверждение публичным recursive resolver.
        // ───────────────────────────────────────────────────────────────────
        if (empty($realNs)) {
            if ($phpConfirmed === true) {
                $log->info('ssl_le_polling', 'DNS: делегация NS ещё не видна, но public resolver подтвердил весь TXT-набор.');
                return true;
            }
            $log->info('ssl_le_polling',
                'DNS: публичная делегация NS ещё не определена, public resolver не подтвердил TXT (fail-closed). '
                . 'Прямые ответы Namecheap NS не считаем доказательством публичной готовности.');
            return false;
        }

        // realNs определены → опрашиваем ИМЕННО реальные authoritative NS.
        // (queryAuthoritativeTxt сам вернёт null, если dig недоступен/не ответил —
        // тогда сработает public-resolver fallback ниже.)
        $resolverResults = ['php' => $phpConfirmed];
        foreach ($realNs as $ns) {
            $resolverResults['ns:' . $ns] = $this->resolverConfirmedAll(
                $expected, function ($fqdn) use ($ns) { return $this->queryAuthoritativeTxt($fqdn, $ns, 5); }
            );
        }

        // authoritative-политика: все реальные NS ответили и подтвердили весь набор.
        $authoritativeKeys = [];
        foreach ($realNs as $ns) $authoritativeKeys[] = 'ns:' . $ns;
        $allAuthAnswered = !empty($authoritativeKeys);
        foreach ($authoritativeKeys as $k) {
            if (!isset($resolverResults[$k]) || $resolverResults[$k] === null) { $allAuthAnswered = false; break; }
        }

        if ($allAuthAnswered) {
            $ok = true;
            foreach ($authoritativeKeys as $k) { if ($resolverResults[$k] !== true) { $ok = false; break; } }
            if (!$ok) $log->info('ssl_le_polling', 'DNS: не все authoritative NS подтвердили TXT.');
            return $ok;
        }

        // authoritative NS определены, но опросить не удалось (dig недоступен/не
        // ответили) — допускаем подтверждение публичным recursive resolver.
        if ($phpConfirmed === true) {
            $log->info('ssl_le_polling', 'DNS: authoritative NS не опрошены (dig), но public resolver подтвердил весь набор.');
            return true;
        }
        $log->info('ssl_le_polling', 'DNS: authoritative NS не подтвердили и public resolver не подтвердил весь набор TXT.');
        return false;
    }

    /** v25.2-a1.4: реальные authoritative NS домена (lowercase, без точки), или []. */
    protected function resolveDomainNs(string $domain): array
    {
        $domain = trim($domain, '. ');
        if ($domain === '') return [];
        try {
            $recs = @dns_get_record($domain, DNS_NS);
            if (!is_array($recs)) return [];
            $out = [];
            foreach ($recs as $r) {
                $t = strtolower(trim((string)($r['target'] ?? ''), '. '));
                if ($t !== '') $out[$t] = true;
            }
            return array_keys($out);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** v25.2-a1.4: реально ли домен использует Namecheap NS (registrar-servers.com). */
    private function nsSetUsesNamecheap(array $realNs, array $namecheapNs): bool
    {
        if (empty($realNs)) return false;
        foreach ($realNs as $ns) {
            if (strpos($ns, 'registrar-servers.com') !== false) return true;
        }
        return false;
    }

    /**
     * Проверить, подтвердил ли ОДИН resolver ВЕСЬ набор expected TXT.
     * @param callable $lookup fn(string $fqdn): ?array — значения TXT или null (не ответил)
     * @return bool|null true=всё подтверждено, false=чего-то нет, null=resolver не ответил
     */
    private function resolverConfirmedAll(array $expected, callable $lookup)
    {
        $answeredAny = false;
        foreach ($expected as $fqdn => $valuesSet) {
            $values = $lookup($fqdn);
            if ($values === null) {
                // этот fqdn resolver не ответил — считаем resolver неполным
                return $answeredAny ? false : null;
            }
            $answeredAny = true;
            foreach (array_keys($valuesSet) as $expectedValue) {
                if (!in_array($expectedValue, $values, true)) {
                    return false;
                }
            }
        }
        return $answeredAny ? true : null;
    }

    /** PHP-fallback резолв TXT: null = не смогли проверить; иначе список значений. */
    protected function queryTxtViaPhp(string $fqdn): ?array
    {
        try {
            $recs = @dns_get_record($fqdn, DNS_TXT);
            if ($recs === false) return null;
            $out = [];
            foreach ($recs as $r) {
                if (isset($r['txt'])) $out[] = (string)$r['txt'];
                elseif (isset($r['entries']) && is_array($r['entries'])) {
                    foreach ($r['entries'] as $e) $out[] = (string)$e;
                }
            }
            return $out;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * v25.2-a1.1: DEPRECATED блокирующий вариант. Больше НЕ используется в
     * pollLetsEncrypt (там неблокирующий state machine + checkChallengesInDnsOnce).
     * Оставлен как тонкий делегат без sleep для обратной совместимости.
     */
    private function waitForChallengesInDns(
        string $domain,
        array $challenges,
        int $timeoutSec,
        JobEventLogger $log
    ): bool {
        return $this->checkChallengesInDnsOnce($domain, $challenges, $log);
    }

    private function isLetsEncryptForDomain(array $cert, string $domain): bool
    {
        $domainLower = strtolower(trim($domain));
        $type = strtolower(trim((string)($cert['type'] ?? '')));
        if ($type !== 'letsencrypt') return false;
        $cn = strtolower(trim((string)($cert['common_name'] ?? '')));
        return $cn === $domainLower;
    }

    private function isReady(array $cert): bool
    {
        // Сертификат "готов" если у него есть body и private key
        // (это надёжнее чем смотреть на status_id который зависит от версии FP)
        $body = trim((string)($cert['body'] ?? ''));
        $key = trim((string)($cert['private_key'] ?? ''));
        if ($body === '' || $key === '') return false;
        // Дополнительная проверка: в body должно быть BEGIN CERTIFICATE
        if (stripos($body, 'BEGIN CERTIFICATE') === false) return false;
        return true;
    }

    private function extractError(array $cert): string
    {
        $err = trim((string)($cert['error'] ?? ''));
        if ($err !== '') return $err;
        $msg = trim((string)($cert['error_message'] ?? ''));
        if ($msg !== '') return $msg;
        $statusText = trim((string)($cert['status_text'] ?? ''));
        if ($statusText !== '' && stripos($statusText, 'error') !== false) return $statusText;
        return '';
    }

    /**
     * v15: точная классификация rate-limit ошибок от LE/FP.
     * Берём из hub::WildcardSslService::isRateLimitMessage.
     *
     * При попадании сюда — НИКОГДА не делаем auto-restart,
     * иначе можем попасть в exact-set-of-identifiers (бан на 7 дней).
     */
    private function isRateLimitMessage(string $msg): bool
    {
        $m = strtolower($msg);
        if ($m === '') return false;
        return strpos($m, 'ratelimited') !== false
            || strpos($m, 'rate limit') !== false
            || strpos($m, 'too many certificates') !== false
            || strpos($m, 'too many failed authorizations') !== false
            || strpos($m, 'exact set of identifiers') !== false
            || strpos($m, 'exact set of domains') !== false;
    }

    /**
     * v15: cert застрял в ACME-ошибке которую можно "разлочить" только
     * новым order. Берём из hub::WildcardSslService::isOrderStuckMessage.
     */
    private function isOrderStuckMessage(string $msg): bool
    {
        $m = strtolower($msg);
        if ($m === '') return false;

        // Сначала отсекаем настоящие rate-limit'ы — они НЕ для auto-restart
        if ($this->isRateLimitMessage($m)) return false;

        $hasAcmeUrn = (strpos($m, 'urn:ietf:params:acme:error:') !== false);

        $stuckKeywords = [
            'ordernotready',
            'not acceptable for finalization',
            'badnonce',
            'badsignaturealgorithm',
            'alreadyrevoked',
            'malformed',
            'serverinternal',
            'dns problem',
            'no txt record',
            'unauthorized',
            'incorrectresponse',
            'caaerror',
            'connection refused',
            'connection reset',
            'authorization failed',
            'authorisation failed',
        ];

        foreach ($stuckKeywords as $kw) {
            if (strpos($m, $kw) !== false) return true;
        }

        // ACME URN тоже считаем stuck (кроме rateLimited которое уже отсеяли)
        return $hasAcmeUrn;
    }

    /**
     * @deprecated v15: оставляем для обратной совместимости с другими местами кода,
     * но новая логика использует isRateLimitMessage / isOrderStuckMessage.
     */
    private function isRateLimit(string $msg): bool
    {
        return $this->isRateLimitMessage($msg);
    }

    /** @deprecated v15: см. isOrderStuckMessage */
    private function isStuck(string $msg): bool
    {
        return $this->isOrderStuckMessage($msg);
    }

    /**
     * v15: проверяет можно ли сейчас сделать auto-restart cert.
     *
     * 4 уровня защиты от LE rate-limits (взято из hub):
     *   1. Не больше 3 рестартов на джобу
     *   2. Минимум 10 минут с прошлого рестарта
     *   3. Не больше 2 createов / час (LE failed-auth limit = 5)
     *   4. Не больше 3 createов / 7 дней (LE exact-set limit = 5)
     *
     * @return array{0: bool, 1: string} [canRestart, reasonIfBlocked]
     */
    private function canAutoRestartGuarded(
        array $state,
        int $siteId,
        int $jobId,
        string $domain
    ): array {
        // Guard 1: лимит на job
        $count = (int)($state['auto_restart_count'] ?? 0);
        if ($count >= self::RESTART_MAX_PER_JOB) {
            return [false, "auto_restart_count={$count} (max " . self::RESTART_MAX_PER_JOB . " per job)"];
        }

        // Guard 2: интервал
        $lastAt = trim((string)($state['auto_restart_last_at'] ?? ''));
        if ($lastAt !== '') {
            $ts = strtotime($lastAt);
            if ($ts !== false) {
                $sinceLast = time() - $ts;
                if ($sinceLast < self::RESTART_MIN_INTERVAL_SEC) {
                    $waitSec = self::RESTART_MIN_INTERVAL_SEC - $sinceLast;
                    return [false, "last restart was {$sinceLast}s ago, must wait {$waitSec}s more"];
                }
            }
        }

        // Guard 3: createов / час
        $hourCount = $this->countRecentCreateAttempts($domain, 1);
        if ($hourCount >= self::CREATES_MAX_PER_HOUR) {
            return [false,
                "create_attempts(1h)={$hourCount} >= " . self::CREATES_MAX_PER_HOUR .
                " (LE failed-auth-limit guard, max 5/h)"];
        }

        // Guard 4: createов / неделю
        $weekCount = $this->countRecentCreateAttempts($domain, 168);
        if ($weekCount >= self::CREATES_MAX_PER_WEEK) {
            return [false,
                "create_attempts(7d)={$weekCount} >= " . self::CREATES_MAX_PER_WEEK .
                " (LE exact-set-of-identifiers guard, max 5/168h)"];
        }

        return [true, "all guards passed (job={$count}, hour={$hourCount}, week={$weekCount})"];
    }

    /**
     * v15: пишет событие в ssl_attempt_log.
     * Используется для guard'ов и для UI (история попыток).
     */
    private function logAttempt(
        int $jobId,
        int $siteId,
        string $domain,
        ?int $certId,
        string $eventType,
        string $message
    ): void {
        try {
            DB::pdo()->prepare(
                "INSERT INTO ssl_attempt_log
                 (job_id, site_id, domain, cert_id, event_type, message)
                 VALUES (?, ?, ?, ?, ?, ?)"
            )->execute([
                $jobId,
                $siteId,
                $this->normalizeDomain($domain),
                $certId !== null && $certId > 0 ? $certId : null,
                $eventType,
                mb_substr($message, 0, 1000),
            ]);
        } catch (\Throwable $e) {
            // Не критично — лог это вспомогательная штука
            error_log("SslIssuerService::logAttempt failed: " . $e->getMessage());
        }
    }

    /**
     * Считает сколько раз мы создавали (или пытались создать) cert на этот
     * домен за последние N часов. Используется в guard'ах.
     */
    private function countRecentCreateAttempts(string $domain, int $hours): int
    {
        try {
            $cutoff = date('Y-m-d H:i:s', time() - max(1, $hours) * 3600);
            $st = DB::pdo()->prepare(
                "SELECT COUNT(*) FROM ssl_attempt_log
                 WHERE domain = ? AND event_type IN ('create_requested', 'auto_restart')
                 AND created_at >= ?"
            );
            $st->execute([$this->normalizeDomain($domain), $cutoff]);
            return (int)$st->fetchColumn();
        } catch (\Throwable $e) {
            // Если таблица не существует или ошибка — возвращаем 0 (не блокируем)
            return 0;
        }
    }

    /**
     * v15: парсит "retry after YYYY-MM-DD HH:MM:SS UTC" из сообщения LE.
     * Если не нашёл — возвращает время через час.
     */
    private function parseRetryAfterFromMessage(string $message): string
    {
        if (preg_match('~retry after\s+([0-9]{4}-[0-9]{2}-[0-9]{2}\s+[0-9]{2}:[0-9]{2}:[0-9]{2})\s*utc~i', $message, $m)) {
            $ts = strtotime($m[1] . ' UTC');
            if ($ts) return date('Y-m-d H:i:s', $ts);
        }
        if (preg_match('~retry after\s+([0-9]{4}-[0-9]{2}-[0-9]{2}\s+[0-9]{2}:[0-9]{2}:[0-9]{2})~i', $message, $m)) {
            $ts = strtotime($m[1]);
            if ($ts) return date('Y-m-d H:i:s', $ts);
        }
        // Дефолт — час от текущего времени
        return date('Y-m-d H:i:s', time() + 3600);
    }

    /**
     * v15: вычисляет задержку до следующего тика на основе времени polling.
     * Используется orchestrator'ом для next_run_at.
     *
     *   Фаза 1: 0-15 мин   — каждые 60 сек
     *   Фаза 2: 15-60 мин  — каждые 5 мин
     *   Фаза 3: 1-3 часа   — каждые 15 мин
     *   Фаза 4: 3-6 часов  — каждые 30 мин
     */
    public function computeNextRunDelay(int $pollingStartedAt): int
    {
        $elapsed = time() - $pollingStartedAt;

        if ($elapsed < 15 * 60)        return 60;        // < 15 мин → 60 сек
        if ($elapsed < 60 * 60)        return 5 * 60;    // < 1 ч   → 5 мин
        if ($elapsed < 3 * 3600)       return 15 * 60;   // < 3 ч   → 15 мин
        return 30 * 60;                                  // ≥ 3 ч   → 30 мин
    }

    private function normalizeDomain(string $domain): string
    {
        $d = preg_replace('~^https?://~i', '', trim($domain));
        $d = preg_replace('~/.*$~', '', $d);
        $d = preg_replace('~:\d+$~', '', $d);
        return strtolower(rtrim($d, '.'));
    }

    /**
     * v25.2-a1.5: grace-период (сек) между txt_synced и resume-fallback. Читает
     * config('ssl.dns_resume_grace_sec') если доступен (прод/cron), иначе — константа.
     * protected — тесты могут переопределить на малое значение.
     */
    /** v25.2-a1.5: сеам для инъекции live-checker в тестах (в проде — реальный). */
    protected function makeLiveChecker(): SslLiveCheckService
    {
        return new SslLiveCheckService();
    }

    protected function dnsResumeGraceSec(): int
    {
        if (function_exists('config')) {
            $v = (int)config('ssl.dns_resume_grace_sec', self::DNS_RESUME_GRACE_SEC);
            if ($v > 0) return $v;
        }
        return self::DNS_RESUME_GRACE_SEC;
    }

    protected function loadSite(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    /**
     * Загрузить аккаунт регистратора (Namecheap) по id.
     * Использует ту же таблицу что DomainPurchaseService.
     */
    private function loadRegistrarAccount(int $id): ?array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'"
        );
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    /**
     * Создаёт FastpanelClient — точно так же как AliasService::makeFastpanelClient.
     * Колонки: username, password_enc (НЕ admin_user/admin_pass_enc).
     */
    protected function makeFp(array $site): FastpanelClient
    {
        $serverId = (int)($site['fastpanel_server_id'] ?? 0);
        if ($serverId <= 0) {
            throw new \RuntimeException('Site has no fastpanel_server_id');
        }
        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $st->execute([$serverId]);
        $server = $st->fetch();
        if (!$server) {
            throw new \RuntimeException("FastPanel server #{$serverId} not found");
        }

        $password = Crypto::decrypt((string)$server['password_enc']);
        $client = new FastpanelClient(
            (string)$server['host'],
            (bool)($server['verify_tls'] ?? false),
            (int)config('fastpanel.timeout', 30)
        );
        $client->login((string)$server['username'], $password);
        return $client;
    }

    /**
     * Создаёт NamecheapClient — точно так же как DomainPurchaseService.
     */
    private function makeNamecheapClient(array $acc): NamecheapClient
    {
        $endpoint = $acc['is_sandbox']
            ? (string)config('namecheap.endpoint_sandbox', 'https://api.sandbox.namecheap.com/xml.response')
            : (string)config('namecheap.endpoint', 'https://api.namecheap.com/xml.response');

        $apiKey = Crypto::decrypt((string)$acc['api_key_enc']);

        return new NamecheapClient(
            $endpoint,
            (string)$acc['api_user'],
            $apiKey,
            (string)$acc['username'],
            (string)$acc['client_ip'],
            (int)config('namecheap.timeout', 30)
        );
    }
}
