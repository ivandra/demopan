<?php

/**
 * v25.2-a: быстрый WM/SSL pipeline. Инкапсулирует кешируемые подэтапы стадии
 * wm_verified, чтобы на retry НЕ повторять уже выполненную работу:
 *
 *   1. verifier_received        — verifier получен у Yandex (uin/file/content/sha)
 *   2. verifier_uploaded        — файл залит по FTP (один раз, кешируется по sha)
 *   3. verifier_publicly_reachable — файл виден публично (нестрогий probe A/B/C)
 *   4. trusted_https_ready      — строгий HTTPS-gate пройден (доверенный TLS)
 *   5. verification_submitted   — POST verify отправлен (один раз)
 *   6. verification_confirmed   — Yandex подтвердил
 *
 * Durable-state: полное состояние подэтапов хранится в artifacts JSON
 * (wm_verified_stage). Диагностические «зеркала» — в колонках refresh_jobs
 * (миграция 030). При повреждённом/пустом JSON подэтап НЕ считается выполненным;
 * восстановление — по факту (быстрый probe/строгий gate), без повтора внешних
 * действий, если факт уже подтверждён.
 *
 * Класс НЕ трогает сеть напрямую в чистых методах-оценщиках (evaluate*) —
 * они статичны и покрываются поведенческими тестами. Сетевые вызовы идут через
 * инъектируемый HttpProbeInterface и WebmasterFileVerifier.
 */
class WmVerifierPipeline
{
    // Имена подэтапов (для диагностики и durable-state).
    public const SUB_RECEIVED   = 'verifier_received';
    public const SUB_UPLOADED   = 'verifier_uploaded';
    public const SUB_PUBLIC     = 'verifier_publicly_reachable';
    public const SUB_TRUSTED    = 'trusted_https_ready';
    public const SUB_SUBMITTED  = 'verification_submitted';
    public const SUB_CONFIRMED  = 'verification_confirmed';

    /** @var HttpProbeInterface */
    private $probe;

    public function __construct(HttpProbeInterface $probe)
    {
        $this->probe = $probe;
    }

    // ================= ЧИСТЫЕ ОЦЕНЩИКИ (тестируемы без сети) =================

    /**
     * §5.2: нужна ли (повторная) FTP-загрузка. Загружаем только если файл ещё
     * не заливали, изменился filename/содержимое, или контрольное чтение по FTP
     * показало отсутствие/иное содержимое.
     *
     * @param array $stage текущий wm_verified_stage
     * @param string $fileName актуальный verifier filename
     * @param string $contentSha256 sha256 актуального содержимого
     * @param ?string $ftpProbeSha sha256 прочитанного по FTP (null = не читали)
     */
    public static function needsUpload(array $stage, string $fileName, string $contentSha256, ?string $ftpProbeSha = null): bool
    {
        if (empty($stage['uploaded_at']))                    return true;
        if ((string)($stage['uploaded_filename'] ?? '') !== $fileName) return true;
        if ((string)($stage['uploaded_content_sha256'] ?? '') !== $contentSha256) return true;
        if ($ftpProbeSha !== null && $ftpProbeSha !== $contentSha256) return true;
        return false;
    }

    /**
     * §5.1: нужно ли (повторно) запрашивать verifier у Yandex. Используем
     * сохранённый, пока host_id не изменился, Yandex не сообщил об устаревании и
     * recovery не потребовал новый.
     */
    public static function needsFetchVerifier(array $stage, string $hostId, bool $yandexSaidStale = false, bool $recoveryForcesNew = false): bool
    {
        if ($recoveryForcesNew || $yandexSaidStale)          return true;
        if (empty($stage['uin']) || empty($stage['file']) || !isset($stage['content'])) return true;
        if ((string)($stage['host_id'] ?? '') !== $hostId)   return true;
        // sha целостности: content должен соответствовать сохранённому sha
        $sha = hash('sha256', (string)$stage['content']);
        if ((string)($stage['content_sha256'] ?? '') !== $sha) return true;
        return false;
    }

    /**
     * §5.3: оценка нестрогого публичного размещения (способы A/B/C). Успех, если
     * HTTP 200, финальная схема https ЛИБО http (для способа B), финальный host —
     * наш домен/www, НЕТ перехода на чужой домен, тело === verifier content.
     * Возвращает ['ok'=>bool, 'reason'=>string, 'fatal'=>bool].
     *
     * fatal=true только при редиректе на ВНЕШНИЙ домен (§8) — это не transient.
     */
    public static function evaluatePublicPlacement(
        int $httpCode, ?string $finalScheme, ?string $finalHost, ?string $body,
        string $expectedDomain, string $expectedContent, string $method
    ): array {
        $expHost = strtolower($expectedDomain);
        $fhost = strtolower((string)$finalHost);

        // Редирект на чужой host — FATAL (не наш домен и не www.наш).
        if ($fhost !== '' && $fhost !== $expHost && $fhost !== 'www.' . $expHost) {
            return ['ok' => false, 'fatal' => true, 'reason' => "foreign_redirect:{$fhost}"];
        }
        if ($httpCode !== 200) {
            return ['ok' => false, 'fatal' => false, 'reason' => "http_{$httpCode}"];
        }
        // способ A/C — транспорт https; способ B — допускаем http.
        $scheme = strtolower((string)$finalScheme);
        if ($method === 'http') {
            if ($scheme !== '' && $scheme !== 'http' && $scheme !== 'https') {
                return ['ok' => false, 'fatal' => false, 'reason' => "bad_scheme:{$scheme}"];
            }
        } else { // insecure_https | resolve_https
            if ($scheme !== '' && $scheme !== 'https') {
                return ['ok' => false, 'fatal' => false, 'reason' => "not_https:{$scheme}"];
            }
        }
        if ($body === null) {
            return ['ok' => false, 'fatal' => false, 'reason' => 'empty_body'];
        }
        if (trim($body) !== trim($expectedContent)) {
            return ['ok' => false, 'fatal' => false, 'reason' => 'content_mismatch'];
        }
        return ['ok' => true, 'fatal' => false, 'reason' => 'ok'];
    }

    /**
     * §3: derive «следующий незавершённый подэтап» из durable-state. При
     * повреждённом JSON (не массив) — начинаем с verifier_received.
     */
    public static function nextSubphase(?array $stage): string
    {
        if (!is_array($stage)) return self::SUB_RECEIVED;
        if (empty($stage['uin']) || empty($stage['file']) || !isset($stage['content'])) return self::SUB_RECEIVED;
        // целостность content по sha
        if ((string)($stage['content_sha256'] ?? '') !== hash('sha256', (string)$stage['content'])) return self::SUB_RECEIVED;
        if (empty($stage['uploaded_at']))         return self::SUB_UPLOADED;
        if (empty($stage['public_at']))           return self::SUB_PUBLIC;
        if (empty($stage['strict_https_at']))     return self::SUB_TRUSTED;
        if (empty($stage['submitted_at']))        return self::SUB_SUBMITTED;
        if (empty($stage['confirmed_at']))        return self::SUB_CONFIRMED;
        return self::SUB_CONFIRMED;
    }

    // ================= СЕТЕВЫЕ ПОДЭТАПЫ (через инъекцию) =================

    /**
     * §5.3: быстрый публичный probe размещения verifier, способы по порядку:
     *   A insecure-HTTPS  → B HTTP  → C resolve-HTTPS (если известен IP).
     * Возвращает ['ok','method','http_code','final_url','fatal','reason'].
     * Останавливается на первом успехе. fatal=true при чужом редиректе.
     */
    public function publicProbe(string $domain, string $fileName, string $expectedContent, ?string $resolveIp = null): array
    {
        $path = '/' . ltrim($fileName, '/');
        $attempts = [];

        // A — insecure HTTPS
        $a = $this->probe->fetchHttpsAllowUntrusted('https://' . $domain . $path);
        $ev = self::evaluatePublicPlacement((int)$a['http_code'], $a['final_scheme'] ?? null, $a['final_host'] ?? null, $a['body'] ?? null, $domain, $expectedContent, 'insecure_https');
        $attempts[] = ['method' => 'insecure_https'] + $ev;
        if ($ev['ok'])   return ['ok' => true, 'method' => 'insecure_https', 'http_code' => (int)$a['http_code'], 'final_url' => $a['final_url'] ?? null, 'fatal' => false, 'reason' => 'ok', 'attempts' => $attempts];
        if ($ev['fatal']) return ['ok' => false, 'method' => 'insecure_https', 'http_code' => (int)$a['http_code'], 'final_url' => $a['final_url'] ?? null, 'fatal' => true, 'reason' => $ev['reason'], 'attempts' => $attempts];

        // B — plain HTTP
        $b = $this->probe->fetchHttpBody('http://' . $domain . $path);
        $ev = self::evaluatePublicPlacement((int)$b['http_code'], $b['final_scheme'] ?? null, $b['final_host'] ?? null, $b['body'] ?? null, $domain, $expectedContent, 'http');
        $attempts[] = ['method' => 'http'] + $ev;
        if ($ev['ok'])   return ['ok' => true, 'method' => 'http', 'http_code' => (int)$b['http_code'], 'final_url' => $b['final_url'] ?? null, 'fatal' => false, 'reason' => 'ok', 'attempts' => $attempts];
        if ($ev['fatal']) return ['ok' => false, 'method' => 'http', 'http_code' => (int)$b['http_code'], 'final_url' => $b['final_url'] ?? null, 'fatal' => true, 'reason' => $ev['reason'], 'attempts' => $attempts];

        // C — resolve HTTPS (только если известен IP)
        if ($resolveIp !== null && $resolveIp !== '') {
            $c = $this->probe->fetchHttpsResolved('https://' . $domain . $path, $domain, $resolveIp);
            $ev = self::evaluatePublicPlacement((int)$c['http_code'], $c['final_scheme'] ?? null, $c['final_host'] ?? null, $c['body'] ?? null, $domain, $expectedContent, 'resolve_https');
            $attempts[] = ['method' => 'resolve_https'] + $ev;
            if ($ev['ok'])   return ['ok' => true, 'method' => 'resolve_https', 'http_code' => (int)$c['http_code'], 'final_url' => $c['final_url'] ?? null, 'fatal' => false, 'reason' => 'ok', 'attempts' => $attempts];
            if ($ev['fatal']) return ['ok' => false, 'method' => 'resolve_https', 'http_code' => (int)$c['http_code'], 'final_url' => $c['final_url'] ?? null, 'fatal' => true, 'reason' => $ev['reason'], 'attempts' => $attempts];
        }

        // Все способы не подтвердили размещение — transient.
        return ['ok' => false, 'method' => null, 'http_code' => 0, 'final_url' => null, 'fatal' => false, 'reason' => 'not_public_yet', 'attempts' => $attempts];
    }

    /**
     * §5.4: строгий HTTPS-gate (доверенный TLS + hostname + 200 + наш host +
     * точное тело). Только его успех разрешает POST verification. Использует
     * строгий fetchHttps (VERIFYPEER/VERIFYHOST) + evaluateStrictResponse.
     * Возвращает ['ok','http_code','reason'].
     */
    public function strictHttpsGate(string $domain, string $fileName, string $expectedContent): array
    {
        $path = '/' . ltrim($fileName, '/');
        // Сначала убедимся, что цепочка доверенная (self-signed/expired не проходят).
        $https = $this->probe->probeHttps('https://' . $domain . $path);
        if (empty($https['ssl_valid'])) {
            return ['ok' => false, 'http_code' => (int)($https['final_code'] ?? 0), 'reason' => 'tls_not_trusted'];
        }
        if (empty($https['hostname_valid'])) {
            return ['ok' => false, 'http_code' => (int)($https['final_code'] ?? 0), 'reason' => 'hostname_mismatch'];
        }
        // Тело — строгий fetch (полная валидация, без follow, ровно по URL).
        $fetch = $this->probe->fetchHttps('https://' . $domain . $path);
        if (empty($fetch['ssl_valid'])) {
            return ['ok' => false, 'http_code' => (int)($fetch['http_code'] ?? 0), 'reason' => 'tls_error_on_fetch'];
        }
        $ev = WebmasterFileVerifier::evaluateStrictResponse(
            (int)($fetch['http_code'] ?? 0),
            (string)('https://' . $domain . $path),
            (string)($fetch['body'] ?? ''),
            $domain,
            $expectedContent
        );
        return ['ok' => !empty($ev['ok']), 'http_code' => (int)($ev['http_code'] ?? 0), 'reason' => $ev['message'] ?? ''];
    }
}
