<?php

/**
 * v25.2-a1: reconciler фактического выпуска trusted SSL. Запускается из ОСНОВНОГО
 * /cron (не зависит от отдельного /cron/ssl), чтобы активная refresh-job не
 * застревала на self-signed из-за незапущенного SSL-cron (ТЗ §Блокер 1/2/3).
 *
 * Ответственность reconciler:
 *   - выбрать активные job (aliases_added+), у которых SSL ещё не trusted;
 *   - backfill ssl_issue_requested_at (в т.ч. для уже прошедших aliases_added,
 *     например job #174 на wm_verified);
 *   - под advisory-lock rfp_ssl_issue_<jobId> вызвать pollLetsEncrypt();
 *   - классифицировать исход общим SslOutcomeClassifier (transient vs fatal);
 *   - назначить next_run_at, сохранить diagnostic-state;
 *   - после issued выполнить реальную SSL-проверку → saveResult (что при trusted
 *     автоматически будит job через nudgeJobOnTrusted §6.1).
 *
 * ACME-логику НЕ дублирует — переиспользует SslIssuerService::pollLetsEncrypt.
 * Идемпотентен, ограничен batch-size, частые тики делают в основном GET/poll.
 */
class TrustedSslReconciler
{
    /** Стадии ДО aliases_added — SSL ещё рано выпускать. */
    private const STAGES_BEFORE_ALIASES = ['queued', 'domain_purchasing'];
    private const TERMINAL = ['done', 'failed', 'cancelled', 'superseded'];

    /** @var callable|null фабрика SslIssuerService (для тестов) */
    private $issuerFactory = null;
    /** @var callable|null фабрика DomainSslCheckService (для тестов) */
    private $sslCheckFactory = null;

    public function setIssuerFactory(callable $f): void { $this->issuerFactory = $f; }
    public function setSslCheckFactory(callable $f): void { $this->sslCheckFactory = $f; }

    private function makeIssuer()
    {
        if ($this->issuerFactory !== null) return ($this->issuerFactory)();
        return new SslIssuerService();
    }
    private function makeSslCheck()
    {
        if ($this->sslCheckFactory !== null) return ($this->sslCheckFactory)();
        return new DomainSslCheckService();
    }

    /** @var array<int,bool> джобы, уже обработанные в этом cron-tick (Блокер 2) */
    private $processedJobIds = [];

    /**
     * v25.2-a1.1 (§Блокер 2): единственный публичный владелец выпуска для одной
     * джобы. И runSslLeStage, и runTick идут ТОЛЬКО через него — двойного вызова
     * pollLetsEncrypt в одном cron-tick быть не может. Возвращает outcome-decision.
     *
     * @return array{decision:string, reason:string, message:string,
     *                rate_limit_resume_at:?string, status:string}
     */
    public function reconcileJob(int $jobId): array
    {
        // Дедуп в пределах одного cron-запроса.
        if (!empty($this->processedJobIds[$jobId])) {
            return ['decision' => 'skipped_same_tick', 'reason' => 'already_processed', 'message' => '', 'rate_limit_resume_at' => null, 'status' => 'pending'];
        }
        $this->processedJobIds[$jobId] = true;

        $job = $this->loadJob($jobId);
        if ($job === null) {
            return ['decision' => 'skipped', 'reason' => 'job_not_found', 'message' => '', 'rate_limit_resume_at' => null, 'status' => 'failed'];
        }

        $lock = 'rfp_ssl_issue_' . $jobId;
        if (!$this->acquireLock($lock, 2)) {
            return ['decision' => 'skipped_lock', 'reason' => 'lock_busy', 'message' => '', 'rate_limit_resume_at' => null, 'status' => 'pending'];
        }
        try {
            $stats = ['processed' => 0, 'issued' => 0, 'pending' => 0, 'fatal' => 0];
            return $this->reconcileOne($job, $stats);
        } finally {
            $this->releaseLock($lock);
        }
    }

    private function loadJob(int $jobId): ?array
    {
        try {
            $st = DB::pdo()->prepare("SELECT id, site_id, new_domain, stage, stage_status, artifacts_json, next_run_at FROM refresh_jobs WHERE id=?");
            $st->execute([$jobId]);
            $r = $st->fetch(PDO::FETCH_ASSOC);
            return $r ?: null;
        } catch (\Throwable $e) { return null; }
    }

    /**
     * Один тик reconciler: обработать до $limit активных джоб, ожидающих trusted.
     * @return array статистика (processed/issued/pending/fatal/skipped)
     */
    public function runTick(int $limit = 3): array
    {
        $stats = ['processed' => 0, 'issued' => 0, 'pending' => 0, 'fatal' => 0, 'skipped_lock' => 0, 'candidates' => 0];

        $candidates = $this->selectCandidates($limit);
        $stats['candidates'] = count($candidates);

        foreach ($candidates as $job) {
            $jobId = (int)$job['id'];
            // Блокер 2: если джобу уже обработал runSslLeStage в этом же тике — пропускаем.
            if (!empty($this->processedJobIds[$jobId])) { continue; }
            $this->processedJobIds[$jobId] = true;
            $lock = 'rfp_ssl_issue_' . $jobId;
            if (!$this->acquireLock($lock, 2)) { $stats['skipped_lock']++; continue; }
            try {
                $d = $this->reconcileOne($job, $stats);
            } catch (\Throwable $e) {
                // Никогда не роняем cron из-за одной джобы — но фиксируем throttle+diagnostic.
                error_log('TrustedSslReconciler job #' . $jobId . ' failed: ' . $e->getMessage());
                $this->handleReconcileException($jobId, (string)($job['stage'] ?? ''), $e);
            } finally {
                $this->releaseLock($lock);
            }
        }
        return $stats;
    }

    /**
     * Backfill + выбор: активные job, достигшие aliases_added, new_domain задан,
     * не терминальные, SSL ещё не trusted. Backfill ssl_issue_requested_at.
     * НЕ импортирует исторические sites_managed без активной job.
     */
    public function selectCandidates(int $limit): array
    {
        $before = "'" . implode("','", self::STAGES_BEFORE_ALIASES) . "'";
        $terminal = "'" . implode("','", self::TERMINAL) . "'";

        // Backfill: проставить ssl_issue_requested_at всем подходящим активным job.
        try {
            DB::pdo()->exec(
                "UPDATE refresh_jobs
                    SET ssl_issue_requested_at = COALESCE(ssl_issue_requested_at, NOW())
                  WHERE new_domain IS NOT NULL AND new_domain <> ''
                    AND stage NOT IN ($before)
                    AND stage NOT IN ($terminal)
                    AND ssl_issue_requested_at IS NULL"
            );
        } catch (\Throwable $e) { /* колонка 030 может отсутствовать до миграции */ }

        // Кандидаты: SSL ещё не trusted (нет trusted-записи в domain_ssl_statuses).
        // §Пункт 5: НЕ исключаем весь awaiting_user (джоба может ждать человека на
        // НЕСВЯЗАННОЙ операции — move_submit_request и т.п., а SSL должен идти
        // параллельно). Исключаем ТОЛЬКО настоящий SSL-fatal:
        // artifacts.ssl_le_stage.fatal = true (или skipped_by_operator).
        $sslFatalCond =
            "COALESCE(JSON_UNQUOTE(JSON_EXTRACT(j.artifacts_json,'$.ssl_le_stage.fatal')), 'false') <> 'true'
             AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(j.artifacts_json,'$.ssl_le_stage.skipped_by_operator')), 'false') <> 'true'";
        try {
            $st = DB::pdo()->prepare(
                "SELECT j.id, j.site_id, j.new_domain, j.stage, j.stage_status,
                        j.artifacts_json, j.next_run_at, j.ssl_issue_requested_at
                   FROM refresh_jobs j
                   LEFT JOIN domain_ssl_statuses s
                          ON s.domain = j.new_domain COLLATE utf8mb4_unicode_ci
                  WHERE j.new_domain IS NOT NULL AND j.new_domain <> ''
                    AND j.stage NOT IN ($before)
                    AND j.stage NOT IN ($terminal)
                    AND ($sslFatalCond)
                    AND (s.status IS NULL OR s.status <> 'trusted')
                    AND (j.ssl_issue_next_poll_at IS NULL OR j.ssl_issue_next_poll_at <= NOW())
                  ORDER BY j.ssl_issue_requested_at ASC, j.id ASC
                  LIMIT " . max(1, min(20, $limit))
            );
            $st->execute();
            return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) {
            // Колонки ssl_issue_next_poll_at может не быть до миграции 031 — fallback без throttle.
            try {
                $st = DB::pdo()->prepare(
                    "SELECT j.id, j.site_id, j.new_domain, j.stage, j.stage_status,
                            j.artifacts_json, j.next_run_at, j.ssl_issue_requested_at
                       FROM refresh_jobs j
                       LEFT JOIN domain_ssl_statuses s
                              ON s.domain = j.new_domain COLLATE utf8mb4_unicode_ci
                      WHERE j.new_domain IS NOT NULL AND j.new_domain <> ''
                        AND j.stage NOT IN ($before)
                        AND j.stage NOT IN ($terminal)
                        AND ($sslFatalCond)
                        AND (s.status IS NULL OR s.status <> 'trusted')
                      ORDER BY j.ssl_issue_requested_at ASC, j.id ASC
                      LIMIT " . max(1, min(20, $limit))
                );
                $st->execute();
                return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
            } catch (\Throwable $e2) { return []; }
        }
    }

    /** Обработать одну джобу под уже полученным локом. */
    private function reconcileOne(array $job, array &$stats): array
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));
        $stage = (string)($job['stage'] ?? '');
        if ($newDomain === '') {
            return ['decision' => 'skipped', 'reason' => 'no_domain', 'message' => '', 'rate_limit_resume_at' => null, 'status' => 'failed'];
        }

        $log = new JobEventLogger($jobId);
        $artifacts = [];
        if (!empty($job['artifacts_json'])) $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
        $state = $artifacts['ssl_le_stage'] ?? null;
        $registrarAccountId = (int)($artifacts['namecheap_account_id'] ?? 0);

        $issuer = $this->makeIssuer();
        $outcome = $issuer->pollLetsEncrypt(
            $jobId, $siteId, $newDomain,
            $registrarAccountId > 0 ? $registrarAccountId : null,
            $state, $log
        );
        $stats['processed']++;

        // Блокер 5: сохранить ПОЛНЫЙ durable ACME-state целиком (если issuer вернул
        // 'state'), иначе — обратная совместимость через whitelisted-поля.
        $this->saveIssuanceState($jobId, $outcome, $log);

        $decision = SslOutcomeClassifier::classify($outcome);
        $decision['status'] = (string)($outcome['status'] ?? '');

        if ($decision['decision'] === SslOutcomeClassifier::DECISION_ISSUED) {
            $stats['issued']++;
            // Единый owner на ветке issued: ставим короткий throttle, чтобы второй
            // reconciler в конце того же cron не выбрал джобу снова (даже если
            // SSL-check пока показывает self-signed).
            $this->setIssueThrottle($jobId, null, 30);
            try {
                $check = $this->makeSslCheck();
                $r = $check->check($newDomain, $siteId, $jobId, null, 'reconciler');
                (new DomainSslStatusRepository())->saveResult($r);
                $log->ok('ssl_reconciler', 'Сертификат применён, выполнена SSL-проверка: ' . ($r['status'] ?? '?'));
            } catch (\Throwable $e) {
                $log->warn('ssl_reconciler', 'SSL-проверка после issued не удалась (повторим): ' . $e->getMessage());
            }
            return $decision;
        }

        if ($decision['decision'] === SslOutcomeClassifier::DECISION_FATAL) {
            $stats['fatal']++;
            $log->error('ssl_reconciler', 'Fatal при выпуске SSL: ' . $decision['message']);
            // Блокер 4.2: настоящий fatal ДОЛЖЕН быть виден оператору, когда SSL уже
            // блокирует текущую стадию — это и ssl_le_polling, И wm_verified.
            if ($stage === 'ssl_le_polling' || $stage === 'wm_verified') {
                $this->persistFatalToArtifacts($jobId, $decision);
                $this->setAwaiting($jobId, ($stage === 'wm_verified' ? 'wm_verified/ssl' : 'ssl_le') . ': ' . mb_substr($decision['message'], 0, 200));
                $this->maybeReconcilerFatalAlert($jobId, $newDomain, $decision, $log);
            } else {
                // Ранняя независимая стадия — сохраняем fatal в artifacts (покажется/
                // остановит на SSL-gate), основной pipeline не роняем.
                $this->persistFatalToArtifacts($jobId, $decision);
                $this->scheduleNext($jobId, $outcome, $decision, true);
            }
            return $decision;
        }

        // TRANSIENT — продолжаем автоматически, awaiting_user НЕ ставим.
        $stats['pending']++;
        $this->scheduleNext($jobId, $outcome, $decision, ($stage !== 'ssl_le_polling'));
        // §Пункт 8: однократный Telegram при transient rate_limited/long_wait/
        // restart_blocked (anti-spam по alert_key). НЕ переводит в awaiting_user.
        $this->maybeTransientAlert($jobId, $newDomain, $decision, $outcome, $log);
        $log->info('ssl_reconciler', 'SSL issuance продолжается (' . $decision['reason'] . '), следующая проверка запланирована.');
        return $decision;
    }

    /**
     * §Пункт 8: единый transient-alert helper. Шлёт один Telegram при переходе в
     * rate_limited / long_wait / restart_blocked (по alert_key из классификатора
     * или по флагу long_wait_alerted_at из issuer-state). Anti-spam по last_alert_key.
     */
    private function maybeTransientAlert(int $jobId, string $domain, array $decision, array $outcome, JobEventLogger $log): void
    {
        $key = (string)($decision['alert_key'] ?? '');
        $hint = (string)($decision['telegram_hint'] ?? '');
        // long_wait: issuer выставил long_wait_alerted_at в state — уведомим один раз.
        $stateLong = !empty($outcome['state']['long_wait_alerted_at']);
        if ($key === '' && $stateLong) { $key = 'ssl_long_wait'; $hint = 'long_wait'; }
        if ($key === '') return;
        try {
            $st = DB::pdo()->prepare("SELECT artifacts_json FROM refresh_jobs WHERE id=?");
            $st->execute([$jobId]);
            $arts = json_decode((string)$st->fetchColumn(), true) ?: [];
            if ((string)($arts['ssl_le_stage']['last_alert_key'] ?? '') === $key) return; // уже уведомляли
            DB::pdo()->prepare("UPDATE refresh_jobs SET artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'),?) WHERE id=?")
                ->execute([json_encode(['ssl_le_stage' => ['last_alert_key' => $key, 'last_alert_at' => date('Y-m-d H:i:s')]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
            $label = [
                'rate_limit'       => "🚦 Rate-limit Let's Encrypt — ждём и продолжаем автоматически",
                'long_wait'        => "⏳ SSL выпускается дольше обычного — продолжаем автоматически",
                'restart_cooldown' => "♻️ Auto-restart на cooldown — продолжаем существующий issuance",
            ][$hint] ?? "ℹ️ SSL issuance продолжается";
            if (class_exists('TelegramService')) {
                $tg = new TelegramService();
                $safe = htmlspecialchars($domain, ENT_QUOTES, 'UTF-8');
                $tg->send("⏳ <b>refresh #{$jobId} | {$safe}</b>\nSSL: {$label}\nДжоба НЕ остановлена — выпуск продолжается автоматически.");
            }
        } catch (\Throwable $e) { $log->warn('ssl_reconciler', 'transient alert failed: ' . $e->getMessage()); }
    }

    /** Блокер 4.1: исключение из issuer → throttle + diagnostic, без спама и без awaiting (кроме явного fatal). */
    private function handleReconcileException(int $jobId, string $stage, \Throwable $e): void
    {
        $log = new JobEventLogger($jobId);
        $msg = $e->getMessage();
        $isFatal = SslOutcomeClassifier::looksFatal($msg);
        // Сохраним ошибку в diagnostic-state и поставим throttle (не выбираем снова через 15с бесконечно).
        try {
            $patch = ['ssl_le_stage' => ['last_error' => mb_substr($msg, 0, 250), 'last_exception_at' => date('Y-m-d H:i:s')]];
            DB::pdo()->prepare("UPDATE refresh_jobs SET artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'),?), ssl_issue_next_poll_at=DATE_ADD(NOW(), INTERVAL 60 SECOND) WHERE id=?")
                ->execute([json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
        } catch (\Throwable $e2) {}
        if ($isFatal && ($stage === 'ssl_le_polling' || $stage === 'wm_verified')) {
            $decision = ['decision' => 'fatal', 'reason' => 'exception_fatal', 'message' => $msg, 'alert_key' => 'ssl_exception_fatal', 'rate_limit_resume_at' => null, 'telegram_hint' => null];
            $this->persistFatalToArtifacts($jobId, $decision);
            $this->setAwaiting($jobId, mb_substr($msg, 0, 200));
        } else {
            $log->warn('ssl_reconciler', 'Временная ошибка issuer (throttle 60с, продолжаем): ' . $msg);
        }
    }

    /** Сохранить fatal-причину в artifacts (Блокер 4.2: видимость/остановка на SSL-gate). */
    private function persistFatalToArtifacts(int $jobId, array $decision): void
    {
        try {
            $patch = ['ssl_le_stage' => [
                'fatal' => true,
                'fatal_reason' => (string)($decision['reason'] ?? ''),
                'fatal_message' => mb_substr((string)($decision['message'] ?? ''), 0, 250),
                'fatal_at' => date('Y-m-d H:i:s'),
            ]];
            DB::pdo()->prepare("UPDATE refresh_jobs SET artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'),?) WHERE id=?")
                ->execute([json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
        } catch (\Throwable $e) {}
    }

    /** Один Telegram по alert-key при fatal из reconciler. */
    private function maybeReconcilerFatalAlert(int $jobId, string $domain, array $decision, JobEventLogger $log): void
    {
        $key = (string)($decision['alert_key'] ?? 'ssl_fatal');
        try {
            $st = DB::pdo()->prepare("SELECT artifacts_json FROM refresh_jobs WHERE id=?");
            $st->execute([$jobId]);
            $arts = json_decode((string)$st->fetchColumn(), true) ?: [];
            if ((string)($arts['ssl_le_stage']['last_alert_key'] ?? '') === $key) return;
            DB::pdo()->prepare("UPDATE refresh_jobs SET artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'),?) WHERE id=?")
                ->execute([json_encode(['ssl_le_stage' => ['last_alert_key' => $key]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
            if (class_exists('TelegramService')) {
                $tg = new TelegramService();
                $safe = htmlspecialchars($domain, ENT_QUOTES, 'UTF-8');
                $tg->send("🛑 <b>refresh #{$jobId} | {$safe}</b>\nSSL выпуск остановлен (fatal): " .
                    htmlspecialchars(mb_substr((string)($decision['message'] ?? ''), 0, 120), ENT_QUOTES, 'UTF-8') .
                    "\nТребуется решение оператора.");
            }
        } catch (\Throwable $e) { $log->warn('ssl_reconciler', 'fatal alert failed: ' . $e->getMessage()); }
    }

    /** Назначить next_run_at по классификации (rate_limit — строго по resume). */
    private function scheduleNext(int $jobId, array $outcome, array $decision, bool $onlyBackground = false): void
    {
        $startedAt = (int)($outcome['polling_started_at'] ?? time());
        $elapsed = max(0, time() - $startedAt);
        $delay = SslOutcomeClassifier::nextDelaySec($elapsed);

        // rate_limited — ждём строго до resume-времени.
        $resumeAt = $decision['rate_limit_resume_at'] ?? null;

        // Throttle самого issuance (не чаще, чем классификатор разрешает).
        $this->setIssueThrottle($jobId, $resumeAt, $delay);

        try {
            if ($onlyBackground) {
                // Джоба НЕ на ssl_le_polling: не трогаем её основной stage_status/
                // next_run_at, только diagnostic-таймер выпуска (колонка 030).
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET wm_verification_last_poll_at = NOW() WHERE id = ?"
                )->execute([$jobId]);
                return;
            }
            if ($resumeAt) {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs
                        SET stage_status='pending', next_run_at=?
                      WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([$resumeAt, $jobId]);
            } else {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs
                        SET stage_status='pending', next_run_at=DATE_ADD(NOW(), INTERVAL ? SECOND)
                      WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([$delay, $jobId]);
            }
        } catch (\Throwable $e) { /* best-effort */ }
    }

    /** Throttle issuance-тиков: не запускать раньше resume/delay (best-effort). */
    private function setIssueThrottle(int $jobId, ?string $resumeAt, int $delaySec): void
    {
        try {
            if ($resumeAt) {
                DB::pdo()->prepare("UPDATE refresh_jobs SET ssl_issue_next_poll_at=? WHERE id=?")
                    ->execute([$resumeAt, $jobId]);
            } else {
                DB::pdo()->prepare("UPDATE refresh_jobs SET ssl_issue_next_poll_at=DATE_ADD(NOW(), INTERVAL ? SECOND) WHERE id=?")
                    ->execute([$delaySec, $jobId]);
            }
        } catch (\Throwable $e) { /* колонка 031 может отсутствовать — не критично */ }
    }

    private function saveIssuanceState(int $jobId, array $outcome, JobEventLogger $log): void
    {
        // Блокер 5: если issuer вернул нормализованный полный state — сохраняем его
        // ЦЕЛИКОМ заменой поддерева ssl_le_stage (не теряем неизвестные поля,
        // включая auto_restart_*). Иначе — обратная совместимость (whitelist).
        if (isset($outcome['state']) && is_array($outcome['state'])) {
            $sub = $outcome['state'];
            // добавим сервис-инфо последнего тика (не мешает schema issuer'а)
            $sub['reconciled_at'] = date('Y-m-d H:i:s');
            $sub['last_status'] = (string)($outcome['status'] ?? '');
            try {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id = ?"
                )->execute([json_encode(['ssl_le_stage' => $sub], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
            } catch (\Throwable $e) { $log->warn('ssl_reconciler', 'Не сохранил issuance-state: ' . $e->getMessage()); }
            return;
        }

        // Fallback (старый контракт без 'state').
        $patch = ['ssl_le_stage' => [
            'status' => $outcome['status'] ?? '',
            'reason' => $outcome['reason'] ?? '',
            'tick_count' => $outcome['tick_count'] ?? 0,
            'cert_id' => $outcome['certificate_id'] ?? null,
            'message' => $outcome['message'] ?? '',
            'challenges' => $outcome['challenges'] ?? null,
            'polling_started_at' => $outcome['polling_started_at'] ?? time(),
            'rate_limit_resume_at' => $outcome['rate_limit_resume_at'] ?? null,
            'auto_restart_count' => $outcome['auto_restart_count'] ?? null,
            'auto_restart_last_at' => $outcome['auto_restart_last_at'] ?? null,
            'auto_restart_last_reason' => $outcome['auto_restart_last_reason'] ?? null,
            'reconciled_at' => date('Y-m-d H:i:s'),
        ]];
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id = ?"
            )->execute([json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
        } catch (\Throwable $e) { $log->warn('ssl_reconciler', 'Не сохранил issuance-state: ' . $e->getMessage()); }
    }

    private function setAwaiting(int $jobId, string $reason): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([mb_substr($reason, 0, 250), $jobId]);
        } catch (\Throwable $e) {}
    }

    private function acquireLock(string $name, int $timeoutSec = 2): bool
    {
        try {
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, ?)");
            $st->execute([$name, $timeoutSec]);
            return ((int)$st->fetchColumn() === 1);
        } catch (\Throwable $e) { return false; }
    }
    private function releaseLock(string $name): void
    {
        try { DB::pdo()->prepare("SELECT RELEASE_LOCK(?)")->execute([$name]); } catch (\Throwable $e) {}
    }
}
