<?php

/**
 * Загружает HTML-файл верификации Yandex.Webmaster на VPS через FTP.
 *
 * В hub этот файл писался в локальную ФС build'а. У нас сайт живёт на отдельном
 * VPS, доступ только через FTP — поэтому используем FtpService.
 *
 * Также проверяет что файл действительно доступен по HTTPS (HTTP 200) перед
 * запуском верификации в Yandex.
 */
class WebmasterFileVerifier
{
    /**
     * Загрузить файл верификации в корень сайта.
     *
     * @param ?string $vpsIp v18.1.18: VPS IP для --resolve fallback в HTTP-проверке
     *                      (DNS нового домена может ещё не пропагироваться)
     * @return array {ok: bool, path: string, http_check: array, message: string}
     */
    public function uploadVerificationFile(
        int $siteId,
        string $newDomain,
        string $fileName,
        string $content,
        JobEventLogger $log,
        ?string $vpsIp = null
    ): array {
        // 1. Грузим site из БД
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$siteId]);
        $site = $st->fetch();
        if (!$site) {
            return ['ok' => false, 'path' => '', 'http_check' => [], 'message' => "Site #{$siteId} not found"];
        }

        // 2. FTP-загрузка
        try {
            $ftp = new FtpService(
                (string)$site['ftp_host'],
                (string)$site['ftp_user'],
                Crypto::decrypt((string)$site['ftp_pass_enc'])
            );
            $ftp->connect();
            try {
                // Без backup'а — это новый файл
                $ftp->putContent($fileName, $content, null);
                $log->info('wm_verified',
                    "✓ Файл верификации загружен через FTP: {$fileName} (" . strlen($content) . " байт)");
            } finally {
                $ftp->disconnect();
            }
        } catch (\Throwable $e) {
            return [
                'ok' => false,
                'path' => $fileName,
                'http_check' => [],
                'message' => "FTP upload failed: " . $e->getMessage(),
            ];
        }

        // 3. HTTP-проверка через https://newdomain/yandex_xxx.html
        $url = 'https://' . $newDomain . '/' . $fileName;
        $log->info('wm_verified', "Проверяю доступность файла: {$url}");

        // Даём пару секунд на opcache / диск-синк
        sleep(2);

        // v25.0-b1 (B3): строгая проверка — файл ДОЛЖЕН быть доступен публично по
        // валидному HTTPS с точным телом. Это gate: если публичный HTTPS ещё не
        // работает, запускать verification в Яндексе рано. --resolve fallback НЕ
        // используем (иначе «проверили» через VPS IP, а Яндекс файл не увидит).
        $httpCheck = $this->httpCheckFileStrict($url, $newDomain, $content, $log);

        if (!$httpCheck['ok']) {
            return [
                'ok' => false,
                'path' => $fileName,
                'http_check' => $httpCheck,
                'message' => "Файл загружен но строгая HTTP-проверка не пройдена: " . $httpCheck['message'],
            ];
        }

        $log->ok('wm_verified',
            "✓ Файл доступен по валидному HTTPS с точным содержимым: {$url} (HTTP {$httpCheck['http_code']})");

        return [
            'ok' => true,
            'path' => $fileName,
            'url' => $url,
            'http_check' => $httpCheck,
            'message' => "Verification file ready",
        ];
    }

    /**
     * v25.0-b1 (B3): строгая публичная проверка verification-файла.
     * Требует: валидный HTTPS (VERIFYPEER=true, VERIFYHOST=2), без DNS-подмены
     * через resolve, финальный host = новый домен, HTTP 200, тело === ожидаемое.
     * Никаких «в теле есть слово yandex» — только точное совпадение.
     */
    private function httpCheckFileStrict(string $url, string $expectedDomain, string $expectedContent, ?JobEventLogger $log = null): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) refresh-panel-wm-file',
        ]);
        $body = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $err = curl_error($ch);
        curl_close($ch);

        if ($body === false) {
            return ['ok' => false, 'http_code' => 0, 'message' => 'curl error (строгий TLS): ' . $err, 'curl_error' => $err];
        }
        // Чистая (без сети) оценка ответа — вынесена, чтобы боевые ветки
        // (host/код/тело) можно было исполнять в тестах напрямую.
        return self::evaluateStrictResponse($httpCode, $finalUrl, (string)$body, $expectedDomain, $expectedContent);
    }

    /**
     * v25.0-b1: чистая проверка строгого ответа verification-файла.
     * Требования: HTTP 200, финальный host = новый домен (или www), тело ===
     * ожидаемое содержимое. Публична и статична — для поведенческих тестов.
     */
    public static function evaluateStrictResponse(int $httpCode, string $finalUrl, string $body, string $expectedDomain, string $expectedContent): array
    {
        if ($httpCode !== 200) {
            return ['ok' => false, 'http_code' => $httpCode, 'message' => "HTTP {$httpCode} (ожидался 200)"];
        }
        // v25.0-b1.1 (Блокер 4): финальная схема после редиректов должна быть
        // https. HTTPS→HTTP downgrade (даже с верным телом) — провал gate
        // публичного HTTPS.
        $finalScheme = strtolower((string)parse_url($finalUrl, PHP_URL_SCHEME));
        if ($finalScheme !== '' && $finalScheme !== 'https') {
            return ['ok' => false, 'http_code' => $httpCode,
                    'message' => "Финальная схема {$finalScheme} (после редиректа), требуется https"];
        }
        $finalHost = strtolower((string)parse_url($finalUrl, PHP_URL_HOST));
        $expHost = strtolower($expectedDomain);
        if ($finalHost !== '' && $finalHost !== $expHost && $finalHost !== 'www.' . $expHost) {
            return ['ok' => false, 'http_code' => $httpCode,
                    'message' => "Редирект на чужой host: {$finalHost} (ожидался {$expHost})"];
        }
        $bodyTrim = trim($body);
        $expTrim = trim($expectedContent);
        if ($bodyTrim !== $expTrim) {
            return ['ok' => false, 'http_code' => $httpCode,
                    'message' => 'Тело файла не совпадает с ожидаемым (CDN/заглушка?)',
                    'body_excerpt' => mb_substr($bodyTrim, 0, 80)];
        }
        return ['ok' => true, 'http_code' => $httpCode, 'final_url' => $finalUrl, 'message' => 'strict OK'];
    }

    /**
     * v25.2-a (§5.2): ТОЛЬКО FTP-загрузка verifier-файла, без HTTP-проверки и
     * без sleep(). Публичную достижимость подтверждает отдельный быстрый probe,
     * строгий HTTPS-gate — ещё позже. Разделение позволяет кешировать заливку
     * (не переподключаться к FTP на каждом retry).
     *
     * @return array{ok:bool, path:string, message:string}
     */
    public function uploadFileOnly(int $siteId, string $fileName, string $content, JobEventLogger $log): array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$siteId]);
        $site = $st->fetch();
        if (!$site) {
            return ['ok' => false, 'path' => '', 'message' => "Site #{$siteId} not found"];
        }
        try {
            $ftp = new FtpService(
                (string)$site['ftp_host'],
                (string)$site['ftp_user'],
                Crypto::decrypt((string)$site['ftp_pass_enc'])
            );
            $ftp->connect();
            try {
                $ftp->putContent($fileName, $content, null);
                $log->info('wm_verified', "✓ Verifier загружен по FTP: {$fileName} (" . strlen($content) . " байт)");
            } finally {
                $ftp->disconnect();
            }
        } catch (\Throwable $e) {
            return ['ok' => false, 'path' => $fileName, 'message' => "FTP upload failed: " . $e->getMessage()];
        }
        return ['ok' => true, 'path' => $fileName, 'message' => 'uploaded'];
    }

    /**
     * v25.2-a (§5.2): контрольное чтение файла по FTP → sha256 содержимого
     * (или null, если файла нет / ошибка). Позволяет решить, нужна ли повторная
     * заливка, не полагаясь только на сохранённое состояние.
     */
    public function readRemoteSha(int $siteId, string $fileName, JobEventLogger $log): ?string
    {
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $site = $st->fetch();
            if (!$site) return null;
            $ftp = new FtpService(
                (string)$site['ftp_host'],
                (string)$site['ftp_user'],
                Crypto::decrypt((string)$site['ftp_pass_enc'])
            );
            $ftp->connect();
            try {
                $content = $ftp->tryGetContent($fileName);
                if ($content === null) return null;
                return hash('sha256', $content);
            } finally {
                $ftp->disconnect();
            }
        } catch (\Throwable $e) {
            $log->info('wm_verified', 'Контрольное чтение FTP не удалось (не критично): ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Удалить verification-файл после успешной верификации (опционально).
     * Вызывается из стадии wm_verified после того как Yandex confirmed.
     */
    public function deleteVerificationFile(
        int $siteId,
        string $fileName,
        JobEventLogger $log
    ): bool {
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $site = $st->fetch();
            if (!$site) return false;

            $ftp = new FtpService(
                (string)$site['ftp_host'],
                (string)$site['ftp_user'],
                Crypto::decrypt((string)$site['ftp_pass_enc'])
            );
            $ftp->connect();
            try {
                if ($ftp->fileExists($fileName)) {
                    if (method_exists($ftp, 'delete')) {
                        $ftp->delete($fileName);
                        $log->info('wm_verified',
                            "Verification-файл {$fileName} удалён с VPS (после успешной верификации)");
                        return true;
                    }
                }
            } finally {
                $ftp->disconnect();
            }
        } catch (\Throwable $e) {
            $log->info('wm_verified',
                "Не удалось удалить verification-файл (не критично): " . $e->getMessage());
        }
        return false;
    }

}
