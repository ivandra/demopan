<?php

/**
 * Клиент Yandex.Webmaster API v4.
 *
 * Адаптация hub::YandexWebmasterService (1764 строки) под наши задачи —
 * только то что нужно для refresh-pipeline (без массовых операций hub'а).
 *
 * Ключевые методы:
 *   - getUserId()                    — получить yandex_user_id из API
 *   - getHosts($userId)              — список всех хостов аккаунта
 *   - findHostInAccount($userId, $domain) — найти hostId по домену
 *   - addHost($userId, $hostUrl)     — добавить новый хост
 *   - getOrCreateHostId($userId, $hostUrl) — найти или создать
 *   - getHtmlFileVerifier($userId, $hostId) — получить uin/file/content для HTML_FILE
 *   - verifyHost($userId, $hostId)   — запустить верификацию
 *   - addSitemap($userId, $hostId, $sitemapUrl)
 *   - recrawlUrl($userId, $hostId, $url)
 *   - getRecrawlQuota($userId, $hostId)
 *   - getInSearchHistory($userId, $hostId) — для index_watching
 *   - deleteHost($userId, $hostId)   — удалить старый
 *
 * Аутентификация: OAuth токен из yandex_webmaster_accounts.access_token_enc
 */
class YandexWebmasterClient
{
    // PATCH047: host owned by YandexWebmasterHttpTransport (API_HOST removed to avoid bypass).
    private const API_TIMEOUT = 30;

    private int $accountId;
    private string $accessToken = '';
    private array $accountRow = [];

    // PATCH 047: единый transport + resolver + контекст аудита.
    private ?YandexWebmasterHttpTransport $transport = null;
    private ?array $resolvedOutbound = null;
    private ?int $ctxJobId = null;
    private ?string $ctxStage = null;
    private $ctxLog = null;                 // ?JobEventLogger — для routing_verified
    private bool $ctxVerifiedLogged = false;
    private array $lastRoutingMeta = [];    // PATCH 048 (Gate W): routing-evidence последнего apiRequest

    public function __construct(int $accountId)
    {
        if ($accountId <= 0) {
            throw new \InvalidArgumentException('YandexWebmasterClient: accountId must be > 0');
        }
        $this->accountId = $accountId;
        $this->loadAccount();
    }

    private function loadAccount(): void
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM yandex_webmaster_accounts WHERE id = ?"
        );
        $st->execute([$this->accountId]);
        $row = $st->fetch();
        if (!$row) {
            throw new \RuntimeException("YandexWebmasterClient: account #{$this->accountId} not found");
        }
        $this->accountRow = $row;

        $tokenEnc = (string)($row['access_token_enc'] ?? '');
        if ($tokenEnc === '') {
            throw new \RuntimeException(
                "YandexWebmasterClient: account #{$this->accountId} has no access_token. " .
                "Авторизуйся через /system/webmaster-tokens"
            );
        }
        $this->accessToken = Crypto::decrypt($tokenEnc);
        if ($this->accessToken === '') {
            throw new \RuntimeException("YandexWebmasterClient: failed to decrypt token");
        }
    }

    public function getAccountInfo(): array
    {
        return $this->accountRow;
    }

    /**
     * GET /v4/user — возвращает yandex_user_id.
     */
    public function getUserId(): string
    {
        $cached = trim((string)($this->accountRow['yandex_user_id'] ?? ''));
        if ($cached !== '' && $cached !== '0') {
            return $cached;
        }
        $res = $this->apiRequest('GET', '/v4/user');
        $userId = (string)($res['user_id'] ?? '');
        if ($userId === '') {
            throw new \RuntimeException("Yandex API /v4/user не вернул user_id: " . json_encode($res));
        }

        // Кешируем в БД
        try {
            DB::pdo()->prepare(
                "UPDATE yandex_webmaster_accounts SET yandex_user_id = ? WHERE id = ?"
            )->execute([$userId, $this->accountId]);
        } catch (\Throwable $e) {}

        return $userId;
    }

    /**
     * GET /v4/user/{userId}/hosts — список всех хостов аккаунта.
     * Возвращает array hosts (распакованных, как пришло).
     */
    public function getHosts(string $userId): array
    {
        $res = $this->apiRequest('GET', '/v4/user/' . rawurlencode($userId) . '/hosts');
        $hosts = $res['hosts'] ?? $res['data']['hosts'] ?? [];
        return is_array($hosts) ? $hosts : [];
    }

    /**
     * Ищет в списке хостов аккаунта тот что соответствует домену.
     * Сравнение по unicode_host_url или ascii_host_url, без схемы.
     *
     * @return ?array Возвращает host-объект (с host_id внутри) или null
     */
    public function findHostInAccount(string $userId, string $domain): ?array
    {
        $domain = $this->normalizeDomain($domain);
        if ($domain === '') return null;

        $hosts = $this->getHosts($userId);
        foreach ($hosts as $h) {
            $unicode = $this->normalizeDomain((string)($h['unicode_host_url'] ?? ''));
            $ascii = $this->normalizeDomain((string)($h['ascii_host_url'] ?? ''));

            if ($unicode === $domain || $ascii === $domain) {
                return $h;
            }
            // Также проверяем без www.
            $domainNoWww = preg_replace('~^www\.~i', '', $domain);
            $unicodeNoWww = preg_replace('~^www\.~i', '', $unicode);
            $asciiNoWww = preg_replace('~^www\.~i', '', $ascii);
            if ($domainNoWww === $unicodeNoWww || $domainNoWww === $asciiNoWww) {
                return $h;
            }
        }
        return null;
    }

    /**
     * POST /v4/user/{userId}/hosts — добавить новый хост.
     * @param string $hostUrl  Например "https://newdomain.casino:443"
     */
    public function addHost(string $userId, string $hostUrl): array
    {
        return $this->apiRequest(
            'POST',
            '/v4/user/' . rawurlencode($userId) . '/hosts',
            [],
            ['host_url' => $hostUrl]
        );
    }

    /**
     * Получить host_id если уже есть, или добавить и вернуть.
     */
    public function getOrCreateHostId(string $userId, string $hostUrl): string
    {
        // Сначала ищем по списку
        $domain = $this->normalizeDomain($hostUrl);
        $host = $this->findHostInAccount($userId, $domain);
        if ($host !== null) {
            $hid = (string)($host['host_id'] ?? '');
            if ($hid !== '') return $hid;
        }

        // Создаём
        $res = $this->addHost($userId, $hostUrl);
        $newId = $this->extractHostIdFromAddResponse($res);
        if ($newId !== '') return $newId;

        // Перечитываем список
        $hosts2 = $this->getHosts($userId);
        foreach ($hosts2 as $h) {
            $u = $this->normalizeDomain((string)($h['unicode_host_url'] ?? ''));
            $a = $this->normalizeDomain((string)($h['ascii_host_url'] ?? ''));
            if ($u === $domain || $a === $domain) {
                return (string)($h['host_id'] ?? '');
            }
        }

        throw new \RuntimeException("Не удалось получить host_id после addHost для {$hostUrl}");
    }

    private function extractHostIdFromAddResponse(array $res): string
    {
        if (!empty($res['host_id'])) return (string)$res['host_id'];
        if (!empty($res['data']['host_id'])) return (string)$res['data']['host_id'];
        if (!empty($res['data']['host']['host_id'])) return (string)$res['data']['host']['host_id'];
        return '';
    }

    /**
     * GET verification — текущий статус + applicable_verifiers.
     */
    public function checkVerification(string $userId, string $hostId): array
    {
        return $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/verification'
        );
    }

    /**
     * Возвращает данные для HTML_FILE верификации:
     *   ['type' => 'HTML_FILE', 'uin' => 'abc123', 'file' => 'yandex_abc123.html', 'content' => '<html>...']
     */
    public function getHtmlFileVerifier(string $userId, string $hostId): array
    {
        $info = $this->checkVerification($userId, $hostId);

        // Поищем HTML_FILE в applicable_verifiers
        $app = $info['applicable_verifiers'] ?? $info['data']['applicable_verifiers'] ?? null;
        if (is_array($app)) {
            foreach ($app as $v) {
                if ((string)($v['verification_type'] ?? '') !== 'HTML_FILE') continue;

                $uin = (string)($v['verification_uin'] ?? '');
                $file = (string)($v['verification_file'] ?? ($v['file'] ?? ($v['file_name'] ?? '')));
                $content = (string)($v['verification_content'] ?? ($v['content'] ?? ''));

                if ($file === '' && $uin !== '') $file = 'yandex_' . $uin . '.html';
                if ($content === '' && $uin !== '') $content = $this->buildHtmlFileContent($uin);

                if ($file !== '' && $content !== '') {
                    return [
                        'type' => 'HTML_FILE',
                        'uin' => $uin,
                        'file' => $file,
                        'content' => $content,
                        'raw' => $info,
                    ];
                }
            }
        }

        // Fallback: ищем uin на верхнем уровне
        $uin = (string)($info['verification_uin'] ?? $info['data']['verification_uin'] ?? '');
        if ($uin !== '') {
            return [
                'type' => 'HTML_FILE',
                'uin' => $uin,
                'file' => 'yandex_' . $uin . '.html',
                'content' => $this->buildHtmlFileContent($uin),
                'raw' => $info,
            ];
        }

        throw new \RuntimeException(
            "Не удалось получить HTML_FILE verifier (нет uin в ответе): " .
            json_encode($info, JSON_UNESCAPED_UNICODE)
        );
    }

    private function buildHtmlFileContent(string $uin): string
    {
        $uin = trim($uin);
        return "<html>\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n</head>\n<body>Verification: {$uin}</body>\n</html>\n";
    }

    /**
     * POST verification/{type} — запустить процесс проверки.
     */
    public function verifyHost(string $userId, string $hostId, string $type = 'HTML_FILE'): array
    {
        try {
            return $this->apiRequest(
                'POST',
                '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId)
                . '/verification/' . rawurlencode($type)
            );
        } catch (\Throwable $e) {
            // Fallback: query string variant
            return $this->apiRequest(
                'POST',
                '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/verification',
                ['verification_type' => $type]
            );
        }
    }

    /**
     * POST sitemap (user-added).
     */
    public function addSitemap(string $userId, string $hostId, string $sitemapUrl): array
    {
        return $this->apiRequest(
            'POST',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/user-added-sitemaps',
            [],
            ['url' => $sitemapUrl]
        );
    }


    /**
     * GET recrawl quota.
     * Возвращает ['daily_quota' => N, 'quota_remainder' => M, 'raw' => ...]
     */
    public function getRecrawlQuota(string $userId, string $hostId): array
    {
        $data = $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/recrawl/quota'
        );
        return [
            'daily_quota' => (int)($data['daily_quota'] ?? 0),
            'quota_remainder' => (int)($data['quota_remainder'] ?? 0),
            'raw' => $data,
        ];
    }

    /**
     * POST recrawl/queue — запросить переобход URL.
     */
    public function recrawlUrl(string $userId, string $hostId, string $url): array
    {
        return $this->apiRequest(
            'POST',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/recrawl/queue',
            [],
            ['url' => $url]
        );
    }

    /**
     * PATCH 048 (Gate W W1): typed GET очереди переобхода.
     * GET /v4/user/{user_id}/hosts/{host_id}/recrawl/queue
     * Использует тот же routed apiRequest, что getRecrawlQuota()/recrawlUrl() — отдельный curl запрещён.
     * Возвращает список задач + routing-evidence (_routing) + HTTP code (_http_code).
     * @return array{tasks:array<int,array>, _http_code:int, _routing:array}
     */
    public function getRecrawlTasks(string $userId, string $hostId, int $offset = 0, int $limit = 100, ?string $dateFrom = null): array
    {
        // P1-4: typed date_from — фильтр окна на стороне API, через ТОТ ЖЕ routed apiRequest (IP-pin).
        $query = ['offset' => $offset, 'limit' => $limit];
        if ($dateFrom !== null && $dateFrom !== '') { $query['date_from'] = $dateFrom; }
        $data = $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/recrawl/queue',
            $query
        );
        $tasks = [];
        foreach ((array)($data['tasks'] ?? []) as $tk) {
            if (!is_array($tk)) continue;
            $tasks[] = [
                'task_id'    => (string)($tk['task_id'] ?? ($tk['id'] ?? '')),
                'url'        => (string)($tk['url'] ?? ''),
                'state'      => (string)($tk['state'] ?? ''),
                'added_time' => (string)($tk['added_time'] ?? ''),
                'raw'        => $tk,
            ];
        }
        return [
            'tasks'      => $tasks,
            '_http_code' => (int)($data['_http_code'] ?? $this->lastRoutingMeta['http_code'] ?? 0),
            '_routing'   => $this->lastRoutingMeta,
        ];
    }

    /**
     * PATCH 048 (Gate W W1): typed GET отдельной задачи переобхода.
     * GET /v4/user/{user_id}/hosts/{host_id}/recrawl/queue/{task_id}
     * @return array{task_id:string,url:string,state:string,added_time:string,_http_code:int,_routing:array,raw:array}
     */
    public function getRecrawlTask(string $userId, string $hostId, string $taskId): array
    {
        $data = $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId)
                . '/recrawl/queue/' . rawurlencode($taskId)
        );
        // 2.3: НЕ фабрикуем task_id. Валидная задача = непустые url И state; иначе _valid=false и
        // reconciliation не считает её найденной (иначе строка уходит в бесконечное UNKNOWN-ожидание).
        $url   = (string)($data['url'] ?? '');
        $state = (string)($data['state'] ?? '');
        $respTaskId = (string)($data['task_id'] ?? ($data['id'] ?? ''));
        $valid = ($url !== '' && $state !== '');
        return [
            'task_id'    => $valid ? ($respTaskId !== '' ? $respTaskId : $taskId) : '',
            'url'        => $url,
            'state'      => $state,
            'added_time' => (string)($data['added_time'] ?? ''),
            'done_time'  => (string)($data['done_time'] ?? ''),
            '_valid'     => $valid,
            '_http_code' => (int)($data['_http_code'] ?? $this->lastRoutingMeta['http_code'] ?? 0),
            '_routing'   => $this->lastRoutingMeta,
            'raw'        => $data,
        ];
    }

    /** PATCH 048 (Gate W): routing-evidence последнего apiRequest. */
    public function getLastRoutingMeta(): array
    {
        return $this->lastRoutingMeta;
    }

    /**
     * GET search-urls/in-search/history — история индекса.
     * Используется для index_watching: смотрим есть ли страницы в индексе.
     */
    public function getInSearchHistory(string $userId, string $hostId, ?string $dateFrom = null, ?string $dateTo = null): array
    {
        $query = [];
        if ($dateFrom) $query['date_from'] = $dateFrom;
        if ($dateTo) $query['date_to'] = $dateTo;

        return $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/search-urls/in-search/history',
            $query
        );
    }

    /**
     * v17.1: GET host summary — агрегированные метрики хоста.
     * Возвращает в т.ч. searchable_pages_count, excluded_pages_count.
     * Самый быстрый способ узнать «есть ли что-то в индексе».
     */
    public function getHostSummary(string $userId, string $hostId): array
    {
        return $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId)
        );
    }

    /**
     * v17.1: GET search-urls/in-search/samples — сэмплы URL что в индексе.
     */
    public function getInSearchSamples(string $userId, string $hostId, int $offset = 0, int $limit = 100): array
    {
        return $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/search-urls/in-search/samples',
            ['offset' => $offset, 'limit' => $limit]
        );
    }

    /**
     * v17.1: GET search-urls/events/samples — события APPEARED_IN_SEARCH / REMOVED_FROM_SEARCH.
     */
    public function getSearchEventSamples(string $userId, string $hostId, int $offset = 0, int $limit = 100): array
    {
        return $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/search-urls/events/samples',
            ['offset' => $offset, 'limit' => $limit]
        );
    }

    /**
     * DELETE host — удалить хост из аккаунта.
     */
    public function deleteHost(string $userId, string $hostId): array
    {
        return $this->apiRequest(
            'DELETE',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId)
        );
    }

    /**
     * Главный HTTP-вызов API.
     */
    /**
     * v18: публичный wrapper над apiRequest — для случаев когда нужно
     * вызвать произвольный эндпоинт (например диагностический GET /robots
     * который не задокументирован, но иногда работает).
     *
     * Использует ту же обработку ошибок что и apiRequest:
     *   - HTTP 401 → бросает RuntimeException про протухший токен
     *   - HTTP 4xx/5xx → бросает RuntimeException с сообщением Yandex
     *   - HTTP 2xx → возвращает декодированный JSON
     */
    public function rawRequest(string $method, string $path, array $query = [], $jsonBody = null): array
    {
        return $this->apiRequest($method, $path, $query, $jsonBody);
    }

    /**
     * PATCH 047 §35/§42: контекст для аудита/логов (job id + логическая стадия).
     * Не влияет на маршрутизацию — только обогащает webmaster_api_request_log.
     */
    public function setRequestContext(?int $jobId, ?string $stage, $log = null): void
    {
        $this->ctxJobId = $jobId;
        $this->ctxStage = $stage;
        if ($log !== null) $this->ctxLog = $log;
        $this->ctxVerifiedLogged = false;   // новый контекст стадии — снова ждём первый verified
    }

    /**
     * PATCH 047 §43: source IP разрешается через resolver (а не берётся из row),
     * все запросы идут через единый YandexWebmasterHttpTransport с жёсткой привязкой IP.
     */
    private function apiRequest(string $method, string $path, array $query = [], $jsonBody = null): array
    {
        // path-only (transport сам строит URL из API_HOST; отбрасываем host если пришёл полный URL).
        $safePath = $path;
        if (preg_match('~^https?://[^/]+(/.*)$~i', $path, $m)) {
            $safePath = $m[1];
        }

        $resolved = $this->resolveOutboundIp();          // fail-closed при отсутствии/disabled IP
        $expectedIp = $resolved['ip_address'];

        try {
            $res = $this->transport()->request(
                $method,
                $safePath,
                $this->accessToken,
                $expectedIp,
                $query,
                $jsonBody,
                [
                    'webmaster_account_id' => $this->accountId,
                    'refresh_job_id'       => $this->ctxJobId,
                    'stage'                => $this->ctxStage,
                ]
            );
        } catch (WebmasterTransportException $e) {
            // Fail-closed: никакого fallback. Пробрасываем понятное сообщение выше
            // (исходный тип сохранён в getPrevious() — orchestrator распознаёт routing failure).
            throw new \RuntimeException(
                'Yandex.Webmaster routing (' . $e->getReason() . '): ' . $e->getMessage(),
                0,
                $e
            );
        }

        // §10/§11: routing_verified — ТОЛЬКО после реального запроса с подтверждённым
        // фактическим source IP (CURLINFO_LOCAL_IP===expected). Одна строка на стадию.
        if (!$this->ctxVerifiedLogged && !empty($res['source_ip_verified']) && $this->ctxLog !== null) {
            $this->ctxVerifiedLogged = true;
            try {
                $this->ctxLog->info((string)($this->ctxStage ?? 'webmaster'),
                    "✓ Исходящий IP подтверждён фактическим соединением. Ожидался {$res['expected_outbound_ip']}, "
                    . "фактически {$res['actual_local_ip']}.",
                    ['event_code' => 'webmaster.routing_verified']);
            } catch (\Throwable $ignore) { /* лог не должен ронять запрос */ }
        }

        $httpCode = (int)$res['http_code'];
        // PATCH 048 (Gate W W1): фиксируем routing-evidence КАЖДОГО запроса (через тот же
        // routed transport). Используется typed queue/task GET для доказательства маршрутизации.
        $this->lastRoutingMeta = [
            'webmaster_account_id' => $this->accountId,
            'expected_source_ip'   => (string)($res['expected_outbound_ip'] ?? $expectedIp),
            'actual_source_ip'     => $res['actual_local_ip'] ?? null,   // = CURLINFO_LOCAL_IP
            'source_ip_verified'   => !empty($res['source_ip_verified']) ? 1 : 0,
            'request_context'      => ['job_id' => $this->ctxJobId, 'stage' => $this->ctxStage],
            'http_code'            => $httpCode,
        ];
        $body = (string)$res['body'];
        $decoded = $body !== '' ? json_decode($body, true) : [];
        if (!is_array($decoded)) $decoded = [];

        if ($httpCode >= 400) {
            $errMsg = $decoded['error_message']
                ?? $decoded['error_description']
                ?? $decoded['error']
                ?? "HTTP {$httpCode}";
            if (is_array($errMsg)) $errMsg = json_encode($errMsg, JSON_UNESCAPED_UNICODE);

            if ($httpCode === 401) {
                throw new \RuntimeException(
                    "Yandex API HTTP 401: токен аккаунта #{$this->accountId} протух или невалиден. " .
                    "Перевыпусти через /system/webmaster-tokens"
                );
            }
            throw new \RuntimeException("Yandex API HTTP {$httpCode}: {$errMsg}");
        }

        // v25.0-b1.1: пробрасываем HTTP-код успешного ответа (RecrawlSubmitService требует 202).
        if (!array_key_exists('_http_code', $decoded)) {
            $decoded['_http_code'] = $httpCode;
        }
        return $decoded;
    }

    /** Ленивое разрешение исходящего IP аккаунта (кэш на время жизни клиента). */
    private function resolveOutboundIp(): array
    {
        if ($this->resolvedOutbound === null) {
            $resolver = new WebmasterOutboundIpResolver();
            $this->resolvedOutbound = $resolver->resolveForAccount($this->accountId);
        }
        return $this->resolvedOutbound;
    }

    /** @return array{ip_id:int,ip_address:string,source:string} */
    public function getResolvedOutbound(): array
    {
        return $this->resolveOutboundIp();
    }

    private function transport(): YandexWebmasterHttpTransport
    {
        if ($this->transport === null) {
            $this->transport = new YandexWebmasterHttpTransport();
        }
        return $this->transport;
    }

    private function normalizeDomain(string $url): string
    {
        $u = preg_replace('~^https?://~i', '', trim($url));
        $u = preg_replace('~/.*$~', '', $u);
        $u = preg_replace('~:\d+$~', '', $u);
        return strtolower(rtrim($u, '.'));
    }

    /**
     * v25.0-b1 (B1): разложить host URL Яндекса на scheme/host/port с
     * эффективным портом (https→443, http→80 по умолчанию) и IDN-нормализацией
     * хоста в ASCII (punycode). www НЕ сворачивается — это отдельная сущность.
     *
     * @return array{scheme:string, host:string, port:int}|null
     */
    public static function parseHostComponents(string $url): ?array
    {
        $url = trim($url);
        if ($url === '') return null;
        // Добавим схему, если её нет, чтобы parse_url отработал корректно.
        if (!preg_match('~^https?://~i', $url)) {
            // может быть "host:443" или "host"
            $url = 'https://' . $url;
        }
        $p = parse_url($url);
        if ($p === false || empty($p['host'])) return null;

        $scheme = strtolower($p['scheme'] ?? 'https');
        if ($scheme !== 'http' && $scheme !== 'https') return null;

        $host = strtolower(rtrim($p['host'], '.'));
        // IDN → ASCII (punycode), если доступно расширение.
        if (function_exists('idn_to_ascii')) {
            $ascii = @idn_to_ascii($host, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46);
            if (is_string($ascii) && $ascii !== '') $host = strtolower($ascii);
        }

        $port = isset($p['port']) ? (int)$p['port'] : ($scheme === 'https' ? 443 : 80);
        return ['scheme' => $scheme, 'host' => $host, 'port' => $port];
    }

    /**
     * v25.0-b1 (B1): точный поиск host в аккаунте по полному host URL
     * (scheme+host+port). Возвращает host-объект ТОЛЬКО при точном совпадении
     * всех трёх компонент. www ≠ non-www, http ≠ https, :80 ≠ :443.
     *
     * @param string $expectedHostUrl например "https://new-domain:443"
     * @return ?array host-объект (с host_id) либо null
     */
    public function findHostExact(string $userId, string $expectedHostUrl): ?array
    {
        $want = self::parseHostComponents($expectedHostUrl);
        if ($want === null) return null;

        foreach ($this->getHosts($userId) as $h) {
            foreach (['ascii_host_url', 'unicode_host_url'] as $field) {
                $comp = self::parseHostComponents((string)($h[$field] ?? ''));
                if ($comp === null) continue;
                if ($comp['scheme'] === $want['scheme']
                    && $comp['host'] === $want['host']
                    && $comp['port'] === $want['port']) {
                    return $h;
                }
            }
        }
        return null;
    }
}
