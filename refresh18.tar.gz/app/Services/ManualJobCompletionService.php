<?php
require_once __DIR__ . '/ManualJobCompletionEligibility.php';

/**
 * HOTFIX «ручное завершение технически готовой джобы» — сервис завершения.
 *
 * Переводит технически готовую джобу в штатное terminal-состояние панели (stage='done')
 * с пометкой completion_mode=manual. Оставшиеся финальные стадии → skipped_manual (НЕ ok).
 * НИКАКИХ внешних вызовов/мутаций сайта. Хэши файлов сайта до/после совпадают.
 *
 * Синхронизация с cron — ЧЕРЕЗ ТОТ ЖЕ advisory-lock панели `rfp_job_<id>` (GET_LOCK),
 * ПЛЮС SELECT … FOR UPDATE. Это исключает возврат завершённой джобы обратно в pipeline.
 * Идемпотентность: повторный вызов возвращает already_completed без изменений.
 */
final class ManualJobCompletionService
{
    private \PDO $pdo;
    private ManualJobCompletionEligibility $gate;
    /** @var callable|null fn(int,string,string,string,array):void */
    private $eventSink;
    /** @var callable|null fn(array $job):?array — реальный pipeline джобы */
    private $pipelineProvider;
    /** @var callable|null fn(int $jobId):object — фабрика job-lock (acquireJobLock/releaseJobLock) */
    private $lockFactory;

    private const TERMINAL_STAGES = ['done', 'failed', 'cancelled', 'superseded'];
    private const JOB_LOCK_PREFIX = 'rfp_job_'; // == CronGuard::JOB_LOCK_PREFIX

    public function __construct(\PDO $pdo, ?ManualJobCompletionEligibility $gate = null,
                                ?callable $eventSink = null, ?callable $pipelineProvider = null,
                                ?callable $lockFactory = null)
    {
        $this->pdo = $pdo;
        $this->gate = $gate ?? new ManualJobCompletionEligibility();
        $this->eventSink = $eventSink;
        $this->pipelineProvider = $pipelineProvider;
        $this->lockFactory = $lockFactory;
    }

    public function complete(int $jobId, string $operator, string $comment): array
    {
        $comment = $this->normalizeComment($comment);
        $cv = $this->validateComment($comment);
        if ($cv !== null) return ['ok' => false, 'http' => 422, 'code' => $cv];

        // (1) ТОТ ЖЕ advisory-lock панели, что и cron: CronGuard::forJob(id)->acquireJobLock()
        //     (`rfp_job_<id>`). Иначе cron/worker может вернуть завершённую джобу в pipeline.
        $lock = $this->lockFactory
            ? ($this->lockFactory)($jobId)
            : (class_exists('CronGuard') ? CronGuard::forJob($jobId) : null);
        if ($lock !== null) {
            if (!$lock->acquireJobLock()) return ['ok' => false, 'http' => 409, 'code' => 'job_locked'];
        } else {
            // окружение без CronGuard — прямой GET_LOCK на том же соединении
            if (!$this->acquireRawLock(self::JOB_LOCK_PREFIX . $jobId)) return ['ok' => false, 'http' => 409, 'code' => 'job_locked'];
        }
        try {
            $this->pdo->beginTransaction();
            try {
                $st = $this->pdo->prepare("SELECT * FROM refresh_jobs WHERE id = :id FOR UPDATE");
                $st->execute([':id' => $jobId]);
                $job = $st->fetch(\PDO::FETCH_ASSOC);
                if (!$job) { $this->pdo->rollBack(); return ['ok' => false, 'http' => 404, 'code' => 'job_not_found']; }

                $artifacts = $this->decode($job['artifacts_json'] ?? null);
                if (!empty($artifacts['manual_completion']['done'])) {
                    $this->pdo->commit();
                    return ['ok' => true, 'already_completed' => true, 'completion_mode' => 'manual',
                            'skipped_stages' => $artifacts['manual_completion']['skipped_stages'] ?? []];
                }
                if (in_array((string)$job['stage'], self::TERMINAL_STAGES, true)) {
                    $this->pdo->commit();
                    return ['ok' => true, 'already_terminal' => true, 'stage' => (string)$job['stage']];
                }

                // повторная eligibility на свежей строке + реальный pipeline режима джобы
                $pipeline = $this->pipelineFor($job);
                $decision = $this->gate->evaluate($job, $pipeline);
                if (!$decision['allowed']) {
                    $this->pdo->rollBack();
                    return ['ok' => false, 'http' => 409, 'code' => 'manual_completion_not_allowed', 'reasons' => $decision['reasons']];
                }

                $oldStage  = (string)$job['stage'];
                $oldStatus = (string)$job['stage_status'];
                $skipped   = $decision['skipped_stages'];

                $artifacts['manual_completion'] = [
                    'done' => true,
                    'completed_manually_at' => gmdate('Y-m-d H:i:s'),
                    'completed_manually_by' => $operator,           // логин из $_SESSION['user']
                    'comment' => $comment,
                    'from_stage' => $oldStage, 'from_status' => $oldStatus,
                    'skipped_stages' => $skipped,
                    'prev_snapshot' => ['stage' => $oldStage, 'stage_status' => $oldStatus, 'next_run_at' => $job['next_run_at'] ?? null],
                ];
                $artifacts['stage_results'] = $artifacts['stage_results'] ?? [];
                foreach ($skipped as $s) $artifacts['stage_results'][$s] = 'skipped_manual';

                $upd = $this->pdo->prepare(
                    "UPDATE refresh_jobs
                        SET stage='done', stage_status='ok', stage_error=NULL, stage_finished_at=NOW(),
                            next_run_at=NULL, artifacts_json=:art
                      WHERE id=:id AND stage NOT IN ('done','failed','cancelled','superseded')"
                );
                $upd->execute([':art' => json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ':id' => $jobId]);
                if ($upd->rowCount() === 0) { $this->pdo->commit(); return ['ok' => true, 'already_terminal' => true, 'race' => true]; }

                $this->audit($jobId, $operator, $oldStatus, $oldStage, $skipped, $comment);
                $this->pdo->commit();
                return ['ok' => true, 'completed' => true, 'completion_mode' => 'manual', 'skipped_stages' => $skipped, 'from_stage' => $oldStage];
            } catch (\Throwable $e) {
                if ($this->pdo->inTransaction()) $this->pdo->rollBack();
                return ['ok' => false, 'http' => 500, 'code' => 'manual_completion_error', 'error' => $e->getMessage()];
            }
        } finally {
            if ($lock !== null) { $lock->releaseJobLock(); }
            else { $this->releaseRawLock(self::JOB_LOCK_PREFIX . $jobId); }
        }
    }

    private function pipelineFor(array $job): ?array
    {
        if ($this->pipelineProvider) { $p = ($this->pipelineProvider)($job); return is_array($p) ? $p : null; }
        if (class_exists('RefreshOrchestrator') && method_exists('RefreshOrchestrator', 'pipelineStagesFor')) {
            $mode = (string)($job['mode'] ?? 'refresh');
            return RefreshOrchestrator::pipelineStagesFor($mode, false);
        }
        return null;
    }

    private function acquireRawLock(string $name): bool
    {
        try { $st = $this->pdo->prepare("SELECT GET_LOCK(:n, 0)"); $st->execute([':n' => $name]);
              return (int)$st->fetchColumn() === 1; }
        catch (\Throwable $e) { return false; }
    }
    private function releaseRawLock(string $name): void
    {
        try { $st = $this->pdo->prepare("SELECT RELEASE_LOCK(:n)"); $st->execute([':n' => $name]); }
        catch (\Throwable $e) { /* лок снимется с закрытием соединения */ }
    }

    private function audit(int $jobId, string $operator, string $oldStatus, string $oldStage, array $skipped, string $comment): void
    {
        $payload = ['job_id' => $jobId, 'operator' => $operator, 'old_status' => $oldStatus ?: 'running',
            'old_stage' => $oldStage, 'new_status' => 'ok', 'new_stage' => 'done', 'completion_mode' => 'manual',
            'comment' => $comment, 'skipped_stages' => $skipped, 'created_at' => gmdate('c'),
            // §3.2/§4: production-эмит job.manual_completed с machine-readable skipped_stages + source=operator.
            'event_code' => 'job.manual_completed', 'source' => 'operator'];
        $human = "Оператор вручную завершил джобу. Технические этапы подтверждены. "
               . "Пропущены финальные стадии: " . (implode(', ', $skipped) ?: '—') . ".";
        if ($comment !== '') {
            $human .= " Причина: " . $comment;
        }
        if ($this->eventSink) { ($this->eventSink)($jobId, 'manual_job_completed', $oldStage, $human, $payload); return; }
        if (class_exists('JobEventLogger')) (new JobEventLogger($jobId))->info($oldStage, $human, ['event' => 'manual_job_completed'] + $payload);
    }

    private function normalizeComment(string $c): string { return trim(preg_replace('~\s+~u', ' ', $c)); }
    private function validateComment(string $c): ?string
    {
        // Причина ручного завершения необязательна.
        if ($c === '') return null;
        if ($c !== strip_tags($c)) return 'comment_html_not_allowed';
        $len = function_exists('mb_strlen') ? mb_strlen($c, 'UTF-8') : strlen($c);
        if ($len > 1000) return 'comment_too_long';
        return null;
    }
    private function decode($raw): array
    {
        if (!is_string($raw) || $raw === '') return [];
        $d = json_decode($raw, true);
        return is_array($d) ? $d : [];
    }
}
