<?php

/**
 * v25.0-a: драйвер readiness-подстадии (substate внутри verify_replacement).
 *
 * Реализует ожидание фактической готовности домена БЕЗ изменения STAGES_ORDER:
 * состояние (streak, probe_token, коды, тайминги) живёт в
 * artifacts_json.domain_readiness_stage, а флаги-гейты — в новых колонках
 * refresh_jobs (миграция 025).
 *
 * Многотиковость: каждый вызов tick() выполняет ОДНУ проверку и планирует
 * следующую через next_run_at. Успех накапливает streak; порог (2/2) ставит
 * domain_https_ready_at. Timeout → awaiting_user (не failed).
 *
 * Конкурентность (v24.3): tick() вызывается ТОЛЬКО когда вызывающий уже держит
 * rfp_job_<id> lock и перечитал джобу. Сам раннер лок не берёт, но все его
 * UPDATE'ы содержат terminal-guard и проверяют rowCount.
 *
 * @return string один из: 'ready' | 'waiting' | 'awaiting_user' | 'terminal'
 */
class DomainReadinessRunner
{
    private DomainReadinessService $svc;
    private ProbeFileManager $probeFiles;

    public function __construct(?DomainReadinessService $svc = null, ?ProbeFileManager $probeFiles = null)
    {
        $this->svc = $svc ?? new DomainReadinessService();
        $this->probeFiles = $probeFiles ?? new ProbeFileManager();
    }

    /**
     * Один тик проверки готовности.
     *
     * @param array $job СВЕЖАЯ строка джобы (перечитана под lock)
     */
    public function tick(array $job, JobEventLogger $log): string
    {
        $jobId  = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $domain = strtolower(trim((string)($job['new_domain'] ?? '')));

        // Терминальную/закрытую не трогаем (v24.3).
        if (JobLifecycleService::isTerminal((string)$job['stage'])) {
            return 'terminal';
        }

        // Уже готово (строго ИЛИ технически) — не проверяем снова.
        if (!empty($job['domain_https_ready_at']) || !empty($job['domain_technical_ready_at'])) {
            return 'ready';
        }

        if ($domain === '') {
            $this->awaitUser($jobId, 'domain_readiness: new_domain пуст');
            return 'awaiting_user';
        }

        $arts = json_decode((string)($job['artifacts_json'] ?? ''), true) ?: [];
        $stage = $arts['domain_readiness_stage'] ?? [];

        // Инициализация подстадии. v25.0-a1 (B2): started_at_unix + probe_token
        // сохраняем СРАЗУ, ДО попытки FTP-upload. Иначе при постоянно
        // недоступном FTP started_at никогда не записывался, и 90-минутный
        // timeout не наступал — джоба висела бесконечно. Теперь timeout
        // покрывает и ожидание FTP, и DNS, и SSL, и HTTP 200.
        if (empty($stage['started_at_unix'])) {
            $token = DomainReadinessService::makeToken();
            $stage = [
                'started_at_unix'      => time(),
                'started_at'           => date('Y-m-d H:i:s'),
                'probe_token'          => $token,
                'probe_file'           => DomainReadinessService::probeFileName($jobId, $token),
                'probe_uploaded'       => false,
                'probe_upload_attempts'=> 0,
                'checks'               => 0,
                'streak'               => 0,
                'last_reason'          => '',
            ];
            $this->saveStage($jobId, $stage);
            $log->info('domain_readiness',
                "Старт ожидания готовности {$domain}. Порог: "
                . DomainReadinessService::requiredSuccesses() . ' успеха(ов) подряд, timeout '
                . DomainReadinessService::timeoutMinutes() . ' мин.');
        }

        $token = (string)$stage['probe_token'];
        $startedUnix = (int)$stage['started_at_unix'];

        // Timeout проверяем ПЕРЕД upload — чтобы вечный FTP-сбой не крутился
        // бесконечно, а ушёл в awaiting_user по общему таймауту.
        if (DomainReadinessService::isTimedOut($startedUnix)) {
            $mins = DomainReadinessService::timeoutMinutes();
            $lastReason = (string)($stage['last_reason'] ?? '');
            if (empty($stage['probe_uploaded'])) {
                $lastReason = $lastReason ?: 'probe_upload_failed';
            }
            $log->warn('domain_readiness',
                "Домен {$domain} не подтвердил HTTPS 200 за {$mins} мин. Перевод в ожидание оператора.");
            $this->awaitUser($jobId,
                "domain_readiness: {$domain} не готов за {$mins} мин "
                . "(последняя причина: " . DomainReadinessService::explainReason($lastReason) . ")");
            return 'awaiting_user';
        }

        // Probe-файл: заливаем (или до-заливаем, если прошлый раз FTP был занят).
        if (empty($stage['probe_uploaded'])) {
            $up = $this->probeFiles->upload($siteId, $jobId, $token, $log);
            $stage['probe_upload_attempts'] = (int)($stage['probe_upload_attempts'] ?? 0) + 1;
            if (empty($up['ok'])) {
                $stage['last_reason'] = 'probe_upload_failed';
                $this->saveStage($jobId, $stage);
                $log->warn('domain_readiness',
                    'probe-файл не залит (попытка ' . $stage['probe_upload_attempts'] . '): '
                    . $up['message'] . ' — повтор позже');
                $this->scheduleNext($jobId, DomainReadinessService::initialIntervalSec());
                return 'waiting';
            }
            $stage['probe_uploaded'] = true;
            $this->saveStage($jobId, $stage);
            $log->info('domain_readiness', 'probe-файл готов: ' . $up['file']);
        }

        // === Одна проверка ===
        $prevStage = $stage; // v25.0-a1 (H4): снимок ДО мутации для дельта-логов
        $res = $this->svc->checkOnce($domain, $jobId, $token);
        $streakInfo = DomainReadinessService::applyToStreak((int)$stage['streak'], (bool)$res['success']);

        $stage['checks']      = (int)$stage['checks'] + 1;
        $stage['streak']      = $streakInfo['streak'];
        $stage['last_reason'] = (string)$res['reason'];
        $stage['last_check']  = [
            'http_initial'  => $res['http_initial'],
            'https_final'   => $res['https_final'],
            'ssl_valid'     => $res['ssl_valid'],
            'self_signed'   => $res['self_signed'],
            'probe_ok'      => $res['probe_ok'],
            'reason'        => $res['reason'],
            'checked_at'    => $res['checked_at'],
        ];
        $this->saveStage($jobId, $stage);
        $this->recordCodes($jobId, (int)$res['http_initial'], (int)$res['https_final'], (int)$stage['streak']);

        // v25.1-a: ТЕХНИЧЕСКАЯ доступность — отдельный, более ранний сигнal.
        // Как только домен публично ответил корректным 301→HTTPS того же
        // домена (в т.ч. YandexBot) ЛИБО живым HTTPS 2xx/3xx (даже self-signed) —
        // фиксируем domain_technical_ready_at и открываем продолжение pipeline,
        // НЕ дожидаясь строгого streak / trusted SSL / HTTPS 200.
        if (!empty($res['technical_ready'])) {
            $firstTime = $this->markTechnicalReady(
                $jobId,
                (string)($res['http_location'] ?? ''),
                (int)($res['yandexbot_http'] ?? 0),
                (string)($res['yandexbot_location'] ?? ''),
                (bool)($res['self_signed'] ?? false),
                (bool)($res['ssl_valid'] ?? false)
            );
            if ($firstTime) {
                $log->ok('domain_readiness',
                    'Домен технически доступен (' . (string)$res['technical_reason']
                    . '). Продолжаем pipeline; SSL отслеживается отдельно'
                    . (!empty($res['self_signed']) ? ' (сейчас self-signed)' : '') . '.');
            }
        }

        $required = DomainReadinessService::requiredSuccesses();
        if ($res['success']) {
            $log->ok('domain_readiness',
                "HTTPS 200, SSL valid, probe OK — успех {$streakInfo['streak']}/{$required}");
        } else {
            // v25.0-a1 (H4): не засоряем журнал одинаковыми строками каждые 30–60с.
            // Логируем только смену причины / HTTP-кода / streak, плюс редкий
            // summary раз в ~10 проверок, если ничего не менялось.
            $prevReason = (string)($prevStage['last_reason'] ?? '');
            $prevHttps  = (int)($prevStage['last_check']['https_final'] ?? -1);
            $prevStreak = (int)($prevStage['streak'] ?? -1);
            $changed = ($res['reason'] !== $prevReason)
                || ((int)$res['https_final'] !== $prevHttps)
                || ($streakInfo['streak'] !== $prevStreak);
            if ($changed || ((int)$stage['checks'] % 10 === 0)) {
                $log->info('domain_readiness',
                    '[' . $res['reason'] . '] ' . DomainReadinessService::explainReason((string)$res['reason'])
                    . ($res['http_location'] ? (' → ' . $res['http_location']) : '')
                    . (!$changed ? ' (проверка #' . (int)$stage['checks'] . ')' : ''));
            }
        }

        // Достигли строгого порога ИЛИ технической готовности → продолжаем.
        // v25.1-a: технической достаточно для перехода к PHP-уникализации.
        $technicallyReady = !empty($res['technical_ready']) || $this->hasTechnicalReady($jobId);
        if ($streakInfo['ready'] || $technicallyReady) {
            // Строгую готовность (domain_https_ready_at) ставим ТОЛЬКО при полном
            // строгом успехе — это отдельный сигнал для verification/recrawl.
            if ($streakInfo['ready']) {
                if (!$this->markReady($jobId)) {
                    return 'terminal';
                }
                // probe больше не нужен — удаляем сразу после строгого подтверждения.
                $this->probeFiles->removeForJob($jobId, $log);
                $log->ok('domain_readiness', "✓ Новый домен {$domain} готов строго (HTTPS 200 подтверждён {$required}/{$required})");
            }
            return 'ready';
        }

        // Ещё ждём — планируем следующую проверку.
        $ageSec = time() - $startedUnix;
        $this->scheduleNext($jobId, DomainReadinessService::nextIntervalSec($ageSec));
        return 'waiting';
    }

    /* ==================== запись состояния (guarded) ==================== */

    private function saveStage(int $jobId, array $stage): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?),
                domain_readiness_last_checked_at = NOW()
             WHERE id = ?
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([
            json_encode(['domain_readiness_stage' => $stage], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            $jobId,
        ]);
    }

    private function recordCodes(int $jobId, int $httpInitial, int $httpsFinal, int $streak): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                domain_http_initial_code = ?,
                domain_https_final_code = ?,
                domain_readiness_success_streak = ?
             WHERE id = ?
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([$httpInitial, $httpsFinal, $streak, $jobId]);
    }

    /** @return bool false если джоба закрыта (0 строк). */
    private function markReady(int $jobId): bool
    {
        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                domain_https_ready_at = NOW(),
                domain_readiness_success_streak = ?
             WHERE id = ?
               AND domain_https_ready_at IS NULL
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        );
        $st->execute([DomainReadinessService::requiredSuccesses(), $jobId]);
        return $st->rowCount() === 1
            // Уже стояло ready (гонка двух тиков) — тоже считаем успехом.
            || $this->alreadyReady($jobId);
    }

    /**
     * v25.1-a: зафиксировать техническую готовность (027). Идемпотентно —
     * ставит domain_technical_ready_at только если ещё пусто.
     * @return bool true если это ПЕРВАЯ фиксация (для однократного лога).
     */
    private function markTechnicalReady(int $jobId, string $httpLocation, int $yandexbotCode, string $yandexbotLocation, bool $selfSigned, bool $sslValid): bool
    {
        $sslState = $sslValid ? 'trusted' : ($selfSigned ? 'self_signed' : 'no_tls');
        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                domain_technical_ready_at = NOW(),
                domain_readiness_state = 'technical_ready',
                domain_http_location = ?,
                domain_yandexbot_http_code = ?,
                domain_yandexbot_location = ?,
                domain_ssl_state = ?,
                domain_ssl_last_checked_at = NOW()
             WHERE id = ?
               AND domain_technical_ready_at IS NULL
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        );
        $st->execute([
            mb_substr($httpLocation, 0, 2048),
            $yandexbotCode ?: null,
            mb_substr($yandexbotLocation, 0, 2048),
            $sslState,
            $jobId,
        ]);
        if ($st->rowCount() === 1) return true;

        // Не первая фиксация — обновим текущий SSL-статус (для UI), без лога.
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET domain_ssl_state = ?, domain_ssl_last_checked_at = NOW()
             WHERE id = ? AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([$sslState, $jobId]);
        return false;
    }

    private function hasTechnicalReady(int $jobId): bool
    {
        $st = DB::pdo()->prepare("SELECT domain_technical_ready_at FROM refresh_jobs WHERE id = ?");
        $st->execute([$jobId]);
        return !empty($st->fetchColumn());
    }

    private function alreadyReady(int $jobId): bool
    {
        $st = DB::pdo()->prepare("SELECT domain_https_ready_at FROM refresh_jobs WHERE id = ?");
        $st->execute([$jobId]);
        return !empty($st->fetchColumn());
    }

    private function scheduleNext(int $jobId, int $intervalSec): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage_status = 'pending',
                next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
             WHERE id = ?
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([max(5, $intervalSec), $jobId]);
    }

    private function awaitUser(int $jobId, string $reason): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage_status = 'awaiting_user',
                stage_error = ?,
                next_run_at = NULL
             WHERE id = ?
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([mb_substr($reason, 0, 1000), $jobId]);
    }
}
