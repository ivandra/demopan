<?php

/**
 * v25.0-a: боевая реализация HttpProbe на cURL со СТРОГОЙ TLS-валидацией.
 *
 * Отличия от Hub-проверки (которую ТЗ запрещает копировать как gate):
 *   - НЕТ CURLOPT_RESOLVE / принудительного IP — проверяем ровно то, что
 *     видит поисковик из публичной сети (DNS должен быть пропагирован);
 *   - HTTP-проба БЕЗ follow — фиксируем исходный 301/302, а не финальный 200;
 *   - HTTPS-проба с VERIFYPEER=true, VERIFYHOST=2 — self-signed и битая
 *     цепочка не проходят как «валидный SSL».
 */
class CurlHttpProbe implements HttpProbeInterface
{
    private string $userAgent;

    public function __construct(string $userAgent = 'RefreshPanel-Readiness/1.0 (+https://refresh-panel.seotop-one.ru)')
    {
        $this->userAgent = $userAgent;
    }

    public function probeHttp(string $url, int $timeoutSec = 10): array
    {
        return $this->probeHttpAs($url, $this->userAgent, $timeoutSec);
    }

    /**
     * v25.1-a: HTTP-проба с явным User-Agent (например YandexBot), без follow.
     */
    public function probeHttpAs(string $url, string $userAgent, int $timeoutSec = 10): array
    {
        $now = date('Y-m-d H:i:s');
        $ch = curl_init($url);
        if ($ch === false) {
            return ['http_code' => 0, 'location' => null, 'error' => 'curl_init failed', 'checked_at' => $now];
        }
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET        => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => true,
            CURLOPT_NOBODY         => false,
            CURLOPT_FOLLOWLOCATION => false, // фиксируем ИСХОДНЫЙ код
            CURLOPT_TIMEOUT        => $timeoutSec,
            CURLOPT_CONNECTTIMEOUT => min(5, $timeoutSec),
            CURLOPT_USERAGENT      => $userAgent,
            CURLOPT_HTTPHEADER     => ['Accept: */*', 'Connection: close'],
            // НЕТ CURLOPT_RESOLVE — публичный DNS.
        ]);
        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        $errno = curl_errno($ch);
        curl_close($ch);

        $location = null;
        if (is_string($resp) && preg_match('~^location:\s*(.+?)\r?$~im', $resp, $m)) {
            $location = trim($m[1]);
        }

        return [
            'http_code' => $code,
            'location'  => $location,
            'error'     => ($errno !== 0 && $err !== '') ? $err : null,
            'checked_at' => $now,
        ];
    }

    public function probeHttps(string $url, int $timeoutSec = 15): array
    {
        $now  = date('Y-m-d H:i:s');
        $host = (string)(parse_url($url, PHP_URL_HOST) ?: '');

        $ch = curl_init($url);
        if ($ch === false) {
            return $this->httpsError('curl_init failed', $now);
        }
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET        => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_NOBODY         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => $timeoutSec,
            CURLOPT_CONNECTTIMEOUT => min(6, $timeoutSec),
            CURLOPT_USERAGENT      => $this->userAgent,
            CURLOPT_HTTPHEADER     => ['Accept: */*', 'Connection: close'],
            // СТРОГАЯ TLS-проверка:
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_CERTINFO       => true,
            // НЕТ CURLOPT_RESOLVE.
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $err   = curl_error($ch);
        $initialCode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $finalCode   = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl    = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $certInfo    = curl_getinfo($ch, CURLINFO_CERTINFO);
        curl_close($ch);

        // TLS-ошибка (errno 51/60 и т.п.) → SSL невалиден. Это НЕ "готово".
        $tlsErrnos = [35, 51, 58, 59, 60, 64, 66, 77, 82, 83, 90, 91];
        if ($errno !== 0 && in_array($errno, $tlsErrnos, true)) {
            $r = $this->httpsError('TLS error: ' . $err, $now);
            $r['self_signed'] = (stripos($err, 'self') !== false && stripos($err, 'signed') !== false)
                || (stripos($err, 'self-signed') !== false);
            return $r;
        }
        if ($errno !== 0 && $body === false && $finalCode === 0) {
            // Соединение не установлено вовсе (DNS/connect) — не TLS.
            return $this->httpsError($err !== '' ? $err : ('curl errno ' . $errno), $now);
        }

        // Сертификат: cURL с VERIFYPEER=true уже подтвердил цепочку и hostname,
        // раз запрос дошёл без TLS-ошибки. Достаём метаданные для логов/UI.
        $issuer = null; $notBefore = null; $notAfter = null; $selfSigned = false;
        if (is_array($certInfo) && isset($certInfo[0])) {
            $c = $certInfo[0];
            $issuer    = $c['Issuer']   ?? null;
            $subject   = $c['Subject']  ?? null;
            $notBefore = $c['Start date'] ?? ($c['Start Date'] ?? null);
            $notAfter  = $c['Expire date'] ?? ($c['Expire Date'] ?? null);
            $selfSigned = ($issuer !== null && $subject !== null && trim((string)$issuer) === trim((string)$subject));
        }

        // ssl_valid: цепочка прошла строгую проверку cURL и это не TLS-ошибка.
        $sslValid = ($errno === 0 || !in_array($errno, $tlsErrnos, true)) && !$selfSigned && $finalCode > 0;

        return [
            'initial_code'  => $initialCode ?: $finalCode,
            'final_code'    => $finalCode,
            'final_url'     => $finalUrl !== '' ? $finalUrl : null,
            'ssl_valid'     => $sslValid,
            'hostname_valid'=> $sslValid, // VERIFYHOST=2 прошёл вместе с peer
            'self_signed'   => $selfSigned,
            'certificate_issuer'     => $issuer,
            'certificate_not_before' => $notBefore,
            'certificate_not_after'  => $notAfter,
            'error'         => ($errno !== 0 && $err !== '') ? $err : null,
            'checked_at'    => $now,
        ];
    }

    /**
     * v25.1-a1 (Блокер 1): non-strict HTTPS transport. Доверие цепочке
     * отключено ТОЛЬКО здесь (self-signed на старте bootstrap). Публичный DNS,
     * БЕЗ CURLOPT_RESOLVE. Ограниченный follow. Возвращает реальный код и
     * effective URL; отдельно сообщает, была ли цепочка доверенной.
     */
    public function probeHttpsAllowUntrusted(string $url, int $timeoutSec = 15): array
    {
        $now = date('Y-m-d H:i:s');
        $ch = curl_init($url);
        if ($ch === false) {
            return ['final_code'=>0,'final_url'=>null,'self_signed'=>false,'ssl_trusted'=>false,'error'=>'curl_init failed','checked_at'=>$now];
        }
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET        => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_NOBODY         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => $timeoutSec,
            CURLOPT_CONNECTTIMEOUT => min(6, $timeoutSec),
            CURLOPT_USERAGENT      => $this->userAgent,
            CURLOPT_HTTPHEADER     => ['Accept: */*', 'Connection: close'],
            // НЕ доверяем цепочке (self-signed допустим) — ТОЛЬКО тут.
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            // НЕТ CURLOPT_RESOLVE — публичный DNS.
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $err   = curl_error($ch);
        $finalCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl  = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);

        // Отдельно оценим, доверенная ли цепочка: строгий повтор без изменения
        // публичного результата. Дёшево и без RESOLVE.
        $sslTrusted = false; $selfSigned = false;
        $strict = $this->probeHttps($url, $timeoutSec);
        if (!empty($strict['ssl_valid']) && (int)$strict['final_code'] > 0) {
            $sslTrusted = true;
        } elseif (!empty($strict['self_signed'])) {
            $selfSigned = true;
        }

        // Ошибка соединения (не TLS): DNS/connect — считаем недоступным.
        if ($finalCode === 0 && $body === false) {
            return ['final_code'=>0,'final_url'=>($finalUrl!==''?$finalUrl:null),'self_signed'=>$selfSigned,'ssl_trusted'=>$sslTrusted,'error'=>($err!==''?$err:('curl errno '.$errno)),'checked_at'=>$now];
        }

        return [
            'final_code' => $finalCode,
            'final_url'  => $finalUrl !== '' ? $finalUrl : null,
            'self_signed'=> $selfSigned,
            'ssl_trusted'=> $sslTrusted,
            'error'      => ($errno !== 0 && $err !== '') ? $err : null,
            'checked_at' => $now,
        ];
    }

    public function fetchHttps(string $url, int $timeoutSec = 15): array
    {
        $now = date('Y-m-d H:i:s');
        $ch = curl_init($url);
        if ($ch === false) {
            return ['http_code' => 0, 'body' => null, 'ssl_valid' => false, 'error' => 'curl_init failed', 'checked_at' => $now];
        }
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET        => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_FOLLOWLOCATION => false, // probe-файл должен лежать РОВНО по URL
            CURLOPT_TIMEOUT        => $timeoutSec,
            CURLOPT_CONNECTTIMEOUT => min(6, $timeoutSec),
            CURLOPT_USERAGENT      => $this->userAgent,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $err   = curl_error($ch);
        $code  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return [
            'http_code' => $code,
            'body'      => is_string($body) ? $body : null,
            'ssl_valid' => ($errno === 0),
            'error'     => ($errno !== 0 && $err !== '') ? $err : null,
            'checked_at' => $now,
        ];
    }

    /**
     * v25.1-b: разбор TLS-сертификата без требования доверия. Публичный DNS
     * (stream_socket_client резолвит host обычным образом, без RESOLVE).
     */
    public function inspectCertificate(string $host, int $port = 443, int $timeoutSec = 12): array
    {
        $out = [
            'tls_present' => false, 'tls_trusted' => false, 'is_self_signed' => false,
            'hostname_valid' => false, 'expired' => false, 'issuer' => null, 'subject' => null,
            'serial_number' => null, 'valid_from' => null, 'valid_to' => null,
            'days_remaining' => null, 'error' => null,
        ];
        $host = strtolower(trim($host));
        if ($host === '') { $out['error'] = 'empty_host'; return $out; }

        // Контекст: НЕ требуем доверия (получаем сертификат даже у self-signed),
        // но захватываем peer-cert для разбора.
        $ctx = stream_context_create(['ssl' => [
            'capture_peer_cert' => true,
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
            'SNI_enabled'       => true,
            'peer_name'         => $host,
        ]]);
        $errno = 0; $errstr = '';
        $client = @stream_socket_client(
            'ssl://' . $host . ':' . $port, $errno, $errstr, $timeoutSec,
            STREAM_CLIENT_CONNECT, $ctx
        );
        if ($client === false) {
            $out['error'] = $errstr !== '' ? $errstr : ('connect errno ' . $errno);
            return $out;
        }
        $params = stream_context_get_params($client);
        @fclose($client);
        $cert = $params['options']['ssl']['peer_certificate'] ?? null;
        if ($cert === null) { $out['error'] = 'no_peer_certificate'; return $out; }

        $info = @openssl_x509_parse($cert);
        if (!is_array($info)) { $out['error'] = 'cert_parse_failed'; return $out; }

        $out['tls_present'] = true;
        $issuer  = $this->dnToString($info['issuer'] ?? []);
        $subject = $this->dnToString($info['subject'] ?? []);
        $out['issuer']  = $issuer !== '' ? $issuer : null;
        $out['subject'] = $subject !== '' ? $subject : null;
        $out['serial_number'] = isset($info['serialNumberHex']) ? (string)$info['serialNumberHex']
            : (isset($info['serialNumber']) ? (string)$info['serialNumber'] : null);
        $vf = isset($info['validFrom_time_t']) ? (int)$info['validFrom_time_t'] : 0;
        $vt = isset($info['validTo_time_t']) ? (int)$info['validTo_time_t'] : 0;
        if ($vf > 0) $out['valid_from'] = date('Y-m-d H:i:s', $vf);
        if ($vt > 0) {
            $out['valid_to'] = date('Y-m-d H:i:s', $vt);
            $out['days_remaining'] = (int)floor(($vt - time()) / 86400);
            $out['expired'] = ($vt < time());
        }
        // self-signed: issuer == subject.
        $out['is_self_signed'] = ($issuer !== '' && $issuer === $subject);
        // hostname match: CN или SAN покрывает host.
        $out['hostname_valid'] = $this->certCoversHost($info, $host);

        // trusted: строгая проверка через отдельный cURL (цепочка + hostname).
        $strict = $this->probeHttps('https://' . $host . '/', $timeoutSec);
        $out['tls_trusted'] = !empty($strict['ssl_valid']) && (int)$strict['final_code'] > 0;

        return $out;
    }

    /** DN-массив openssl → строка вида "CN=..., O=...". */
    private function dnToString($dn): string
    {
        if (!is_array($dn)) return '';
        $parts = [];
        foreach ($dn as $k => $v) {
            if (is_array($v)) $v = implode('/', $v);
            $parts[] = $k . '=' . $v;
        }
        return implode(', ', $parts);
    }

    /** Покрывает ли сертификат (CN + SAN) данный host (с учётом wildcard). */
    private function certCoversHost(array $info, string $host): bool
    {
        $names = [];
        $cn = $info['subject']['CN'] ?? null;
        if (is_string($cn)) $names[] = strtolower($cn);
        $san = $info['extensions']['subjectAltName'] ?? '';
        if (is_string($san) && $san !== '') {
            foreach (explode(',', $san) as $entry) {
                $entry = trim($entry);
                if (stripos($entry, 'DNS:') === 0) $names[] = strtolower(trim(substr($entry, 4)));
            }
        }
        foreach ($names as $name) {
            if ($name === $host) return true;
            if (strpos($name, '*.') === 0) {
                $suffix = substr($name, 1); // ".example.com"
                if (substr($host, -strlen($suffix)) === $suffix
                    && substr_count($host, '.') === substr_count($name, '.')) {
                    return true;
                }
            }
        }
        return false;
    }

    private function httpsError(string $msg, string $now): array
    {
        return [
            'initial_code' => 0, 'final_code' => 0, 'final_url' => null,
            'ssl_valid' => false, 'hostname_valid' => false, 'self_signed' => false,
            'certificate_issuer' => null, 'certificate_not_before' => null,
            'certificate_not_after' => null, 'error' => $msg, 'checked_at' => $now,
        ];
    }

    /** v25.2-a: разбор финального URL на scheme/host для оценки размещения. */
    private static function splitFinal(string $finalUrl): array
    {
        $scheme = strtolower((string)parse_url($finalUrl, PHP_URL_SCHEME));
        $host   = strtolower((string)parse_url($finalUrl, PHP_URL_HOST));
        return [$scheme !== '' ? $scheme : null, $host !== '' ? $host : null];
    }

    public function fetchHttpsAllowUntrusted(string $url, int $timeoutSec = 15): array
    {
        $now = date('Y-m-d H:i:s');
        $ch = curl_init($url);
        if ($ch === false) return ['http_code'=>0,'final_url'=>null,'body'=>null,'final_scheme'=>null,'final_host'=>null,'error'=>'curl_init failed','checked_at'=>$now];
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET        => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => $timeoutSec,
            CURLOPT_CONNECTTIMEOUT => min(6, $timeoutSec),
            CURLOPT_USERAGENT      => $this->userAgent,
            CURLOPT_HTTPHEADER     => ['Accept: */*', 'Connection: close'],
            CURLOPT_SSL_VERIFYPEER => false, // способ A: TLS только транспорт
            CURLOPT_SSL_VERIFYHOST => 0,
            // НЕТ CURLOPT_RESOLVE — публичный DNS.
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch); $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        [$scheme, $host] = self::splitFinal($finalUrl);
        return [
            'http_code' => $code,
            'final_url' => $finalUrl !== '' ? $finalUrl : null,
            'body'      => is_string($body) ? $body : null,
            'final_scheme' => $scheme, 'final_host' => $host,
            'error'     => ($errno !== 0 && $err !== '') ? $err : null,
            'checked_at' => $now,
        ];
    }

    public function fetchHttpBody(string $url, int $timeoutSec = 10): array
    {
        $now = date('Y-m-d H:i:s');
        $ch = curl_init($url);
        if ($ch === false) return ['http_code'=>0,'final_url'=>null,'body'=>null,'final_scheme'=>null,'final_host'=>null,'error'=>'curl_init failed','checked_at'=>$now];
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET        => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => $timeoutSec,
            CURLOPT_CONNECTTIMEOUT => min(6, $timeoutSec),
            CURLOPT_USERAGENT      => $this->userAgent,
            CURLOPT_HTTPHEADER     => ['Accept: */*', 'Connection: close'],
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch); $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        [$scheme, $host] = self::splitFinal($finalUrl);
        return [
            'http_code' => $code,
            'final_url' => $finalUrl !== '' ? $finalUrl : null,
            'body'      => is_string($body) ? $body : null,
            'final_scheme' => $scheme, 'final_host' => $host,
            'error'     => ($errno !== 0 && $err !== '') ? $err : null,
            'checked_at' => $now,
        ];
    }

    public function fetchHttpsResolved(string $url, string $host, string $ip, int $port = 443, int $timeoutSec = 15): array
    {
        $now = date('Y-m-d H:i:s');
        $ch = curl_init($url);
        if ($ch === false) return ['http_code'=>0,'final_url'=>null,'body'=>null,'final_scheme'=>null,'final_host'=>null,'error'=>'curl_init failed','checked_at'=>$now];
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET        => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => $timeoutSec,
            CURLOPT_CONNECTTIMEOUT => min(6, $timeoutSec),
            CURLOPT_USERAGENT      => $this->userAgent,
            CURLOPT_HTTPHEADER     => ['Accept: */*', 'Connection: close'],
            CURLOPT_SSL_VERIFYPEER => false, // способ C: транспорт через прямой IP
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_RESOLVE        => [$host . ':' . $port . ':' . $ip],
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch); $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        [$scheme, $fhost] = self::splitFinal($finalUrl);
        return [
            'http_code' => $code,
            'final_url' => $finalUrl !== '' ? $finalUrl : null,
            'body'      => is_string($body) ? $body : null,
            'final_scheme' => $scheme, 'final_host' => $fhost,
            'error'     => ($errno !== 0 && $err !== '') ? $err : null,
            'checked_at' => $now,
        ];
    }
}
