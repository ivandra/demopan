<?php

/**
 * v25.0-a: отслеживание фактической готовности нового домена.
 *
 * Главный принцип (приоритет заказчика): следим за кодом ответа домена.
 *   - код 0                → DNS/соединение ещё не готовы, ждём;
 *   - 301/302/307/308      → домен начал работать, «скоро 200» — но ДАЛЬШЕ НЕ ИДЁМ;
 *   - HTTPS 200 + валидный SSL + probe-token → успех одной проверки;
 *   - ДВА успеха подряд    → domain_https_ready_at, и только тогда pipeline
 *                            двигается к смене классов (PHP-уникализации).
 *
 * Устойчивость (ТЗ раздел 8): нужен streak из двух успехов; любой сбой между
 * ними сбрасывает счётчик. Обычная задержка DNS/SSL НЕ переводит джобу в
 * failed — по timeout джоба уходит в awaiting_user.
 *
 * Проверка изолирована за HttpProbeInterface: в проде — строгий cURL, в
 * тестах — фейк со сценарными ответами (внешняя сеть не нужна).
 *
 * Конкурентность: сервис НЕ трогает БД и НЕ лочит — состояние (streak, ready)
 * пишет вызывающая стадия оркестратора под rfp_job_<id> (v24.3). Сервис
 * возвращает решение, запись — снаружи.
 */
class DomainReadinessService
{
    /** Промежуточные положительные коды: «домен ожил, скоро 200». */
    const INTERMEDIATE_CODES = [301, 302, 303, 307, 308];

    private HttpProbeInterface $probe;

    public function __construct(?HttpProbeInterface $probe = null)
    {
        // По умолчанию — боевой строгий cURL. Тесты передают фейк.
        $this->probe = $probe ?? new CurlHttpProbe();
    }

    /* ==================== НАСТРОЙКИ ==================== */

    public static function initialIntervalSec(): int   { return max(5,  AppSettings::getInt('readiness.initial_interval_seconds', 30)); }
    public static function normalIntervalSec(): int    { return max(15, AppSettings::getInt('readiness.normal_interval_seconds', 60)); }
    public static function timeoutMinutes(): int       { return max(1,  AppSettings::getInt('readiness.timeout_minutes', 90)); }
    public static function requiredSuccesses(): int    { return max(1,  AppSettings::getInt('readiness.required_successes', 2)); }

    /**
     * Интервал до следующей проверки: первые 5 минут чаще, затем реже.
     * @param int $stageAgeSec сколько секунд идёт readiness-стадия
     */
    public static function nextIntervalSec(int $stageAgeSec): int
    {
        return $stageAgeSec < 300
            ? self::initialIntervalSec()
            : self::normalIntervalSec();
    }

    /* ==================== PROBE-ТОКЕН ==================== */

    /** Имя probe-файла в корне сайта. */
    public static function probeFileName(int $jobId, string $token): string
    {
        return '/.refresh-ready-' . $jobId . '-' . $token . '.txt';
    }

    /** Содержимое probe-файла. */
    public static function probeContent(int $jobId, string $token): string
    {
        return 'refresh-job=' . $jobId . ';token=' . $token;
    }

    /** Сгенерировать случайный token. */
    public static function makeToken(): string
    {
        return bin2hex(random_bytes(16));
    }

    /* ==================== ОДНА ПРОВЕРКА ==================== */

    /**
     * Выполнить один цикл проверки готовности.
     *
     * @param string $domain    новый домен (без схемы)
     * @param int    $jobId
     * @param string $token     probe-token, ранее записанный в артефакты
     * @return array подробный результат: success(bool), reason(string),
     *         http/https/probe детали — для лога, UI и записи в артефакты.
     */
    public function checkOnce(string $domain, int $jobId, string $token): array
    {
        $domain = strtolower(trim($domain));
        $out = [
            'success'        => false,
            'reason'         => '',
            'http_initial'   => 0,
            'http_location'  => null,
            'yandexbot_http' => 0,
            'yandexbot_location' => null,
            'https_initial'  => 0,
            'https_final'    => 0,
            'https_final_url'=> null,
            'ssl_valid'      => false,
            'self_signed'    => false,
            'hostname_valid' => false,
            'certificate_issuer'    => null,
            'certificate_not_after' => null,
            'probe_ok'       => false,
            'technical_ready'=> false,          // v25.1-a: техническая доступность
            'technical_reason' => '',
            'checked_at'     => date('Y-m-d H:i:s'),
        ];

        if ($domain === '') {
            $out['reason'] = 'empty_domain';
            return $out;
        }

        // 1) HTTP без follow — фиксируем исходный код.
        $http = $this->probe->probeHttp('http://' . $domain . '/');
        $out['http_initial']  = (int)$http['http_code'];
        $out['http_location'] = $http['location'] ?? null;

        // v25.1-a: отдельный запрос «как YandexBot» — публичный, без RESOLVE.
        $yb = $this->probe->probeHttpAs('http://' . $domain . '/', self::yandexBotUserAgent());
        $out['yandexbot_http']     = (int)$yb['http_code'];
        $out['yandexbot_location'] = $yb['location'] ?? null;

        // 2) HTTPS со строгой TLS-валидацией.
        $https = $this->probe->probeHttps('https://' . $domain . '/');
        $out['https_initial']  = (int)$https['initial_code'];
        $out['https_final']    = (int)$https['final_code'];
        $out['https_final_url']= $https['final_url'] ?? null;
        $out['ssl_valid']      = (bool)$https['ssl_valid'];
        $out['self_signed']    = (bool)$https['self_signed'];
        $out['hostname_valid'] = (bool)$https['hostname_valid'];
        $out['certificate_issuer']    = $https['certificate_issuer'] ?? null;
        $out['certificate_not_after'] = $https['certificate_not_after'] ?? null;

        // v25.1-a1 (Блокер 1): строгий probeHttps на self-signed возвращает
        // final_code=0, поэтому «живой HTTPS 2xx/3xx даже self-signed» строгим
        // пробом не виден. Делаем отдельный non-strict transport-замер ТОЛЬКО
        // для оценки технической доступности (variant B). Публичный DNS, без
        // RESOLVE. Строгие ssl_valid/self_signed/streak берём из strict-проба.
        $untrustedFinal = (int)$out['https_final'];
        $untrustedFinalUrl = (string)($out['https_final_url'] ?? '');
        if ($untrustedFinal === 0) {
            $u = $this->probe->probeHttpsAllowUntrusted('https://' . $domain . '/');
            $untrustedFinal    = (int)($u['final_code'] ?? 0);
            $untrustedFinalUrl = (string)($u['final_url'] ?? '');
            if (!empty($u['self_signed'])) $out['self_signed'] = true;
        }

        // v25.1-a: ТЕХНИЧЕСКАЯ доступность — отдельно от строгого success.
        // Достаточно ЛИБО публичного 3xx-редиректа на HTTPS того же домена
        // (в т.ч. с YandexBot UA), ЛИБО живого HTTPS 2xx/3xx (даже self-signed).
        $tech = self::evaluateTechnicalReady($domain, [
            'http_code'          => $out['http_initial'],
            'http_location'      => $out['http_location'],
            'yandexbot_http'     => $out['yandexbot_http'],
            'yandexbot_location' => $out['yandexbot_location'],
            'https_initial'      => $out['https_initial'],
            'https_final'        => $untrustedFinal,       // v25.1-a1: non-strict для variant B
            'https_final_url'    => $untrustedFinalUrl !== '' ? $untrustedFinalUrl : $out['https_final_url'],
        ]);
        $out['technical_ready']  = $tech['ready'];
        $out['technical_reason'] = $tech['reason'];

        // --- Классификация НЕуспеха (в порядке приоритета причин) ---

        // Соединения нет вообще.
        if ($out['https_final'] === 0 && $out['http_initial'] === 0) {
            $out['reason'] = 'no_connection';
            return $out;
        }
        // HTTP есть, но HTTPS ещё не поднялся (только 301 на https / TLS не готов).
        if ($out['self_signed']) {
            $out['reason'] = 'self_signed';        // временный bootstrap, НЕ готов
            return $out;
        }
        if (!$out['ssl_valid']) {
            $out['reason'] = 'ssl_not_valid';
            return $out;
        }
        // Промежуточный редирект как финал — домен ожил, но не 200.
        if (in_array($out['https_final'], self::INTERMEDIATE_CODES, true)) {
            $out['reason'] = 'redirect_' . $out['https_final'];
            return $out;
        }
        if ($out['https_final'] !== 200) {
            $out['reason'] = 'http_' . $out['https_final'];
            return $out;
        }
        // hostname обязан совпадать (иначе SNI/чужой сертификат).
        if (!$out['hostname_valid']) {
            $out['reason'] = 'hostname_mismatch';
            return $out;
        }
        // v25.0-a1 (B8): финальный URL после follow должен остаться на HTTPS
        // и на нашем домене (или www.<домен>). Иначе главная могла увести
        // редиректом на чужой сайт с 200 — ложная готовность.
        if (!self::finalHostAllowed((string)($out['https_final_url'] ?? ''), $domain)) {
            $out['reason'] = 'unexpected_redirect_host';
            return $out;
        }

        // 3) HTTPS 200 + валидный SSL — теперь probe-файл: попали ли в НУЖНЫЙ сайт?
        $probeUrl = 'https://' . $domain . self::probeFileName($jobId, $token);
        $fetch = $this->probe->fetchHttps($probeUrl);
        $expected = self::probeContent($jobId, $token);
        $body = (string)($fetch['body'] ?? '');

        if ((int)$fetch['http_code'] !== 200) {
            $out['reason'] = 'probe_http_' . (int)$fetch['http_code'];
            return $out;
        }
        if (empty($fetch['ssl_valid'])) {
            $out['reason'] = 'probe_ssl_invalid';
            return $out;
        }
        // Точное совпадение токена — защита от чужого vhost / заглушки сервера,
        // которые тоже могут отдать 200 на главной.
        if (trim($body) !== $expected) {
            $out['reason'] = 'probe_token_mismatch';
            return $out;
        }

        $out['probe_ok'] = true;
        $out['success']  = true;
        $out['reason']   = 'ok';
        return $out;
    }

    /**
     * Применить результат одной проверки к текущему streak.
     * Чистая функция (без БД) — вызывающая стадия сохраняет новый streak
     * и, при достижении порога, ставит domain_https_ready_at.
     *
     * @return array{streak:int, ready:bool}
     */
    public static function applyToStreak(int $currentStreak, bool $success): array
    {
        if ($success) {
            $streak = $currentStreak + 1;
            return ['streak' => $streak, 'ready' => $streak >= self::requiredSuccesses()];
        }
        // Любой сбой между успехами обнуляет прогресс (ТЗ 20.1 п.10).
        return ['streak' => 0, 'ready' => false];
    }

    /**
     * v25.0-a1 (B8): допустим ли финальный URL после follow.
     * Пустой final_url трактуем как «без редиректа» (допустимо — код 200 без
     * Location). Иначе требуем https и host ∈ {domain, www.domain}.
     */
    public static function finalHostAllowed(string $finalUrl, string $domain): bool
    {
        $finalUrl = trim($finalUrl);
        if ($finalUrl === '') return true; // прямой 200 без редиректа

        $scheme = strtolower((string)(parse_url($finalUrl, PHP_URL_SCHEME) ?: ''));
        $host   = strtolower((string)(parse_url($finalUrl, PHP_URL_HOST) ?: ''));
        if ($scheme !== 'https') return false;

        $domain = strtolower(trim($domain));
        return $host === $domain || $host === 'www.' . $domain;
    }

    /** v25.1-a: User-Agent Яндекс-бота для публичной проверки редиректа. */
    public static function yandexBotUserAgent(): string
    {
        return 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)';
    }

    /**
     * v25.1-a: ЧИСТАЯ оценка технической доступности домена (без сети/БД).
     *
     * Домен технически готов для продолжения pipeline, если получен ПЕРВЫЙ
     * корректный публичный ответ:
     *   A) HTTP 301/302/307/308 (обычный UA ИЛИ YandexBot) с Location на HTTPS
     *      того же нового домена (допускается domain↔www того же домена);
     *   B) публичный HTTPS отвечает 2xx/3xx (даже self-signed).
     *
     * НЕ готов при: код 0 / нет DNS; редирект на старый/чужой домен; цикл;
     * редирект не на HTTPS; 4xx/5xx без корректного редиректа.
     *
     * @param array $r http_code, http_location, yandexbot_http, yandexbot_location,
     *                 https_initial, https_final, https_final_url
     * @return array{ready:bool, reason:string}
     */
    public static function evaluateTechnicalReady(string $domain, array $r): array
    {
        $domain = strtolower(trim($domain));
        if ($domain === '') return ['ready' => false, 'reason' => 'empty_domain'];

        // Вариант A: корректный 3xx-редирект на HTTPS того же домена.
        foreach ([
            ['code' => (int)($r['http_code'] ?? 0),     'loc' => (string)($r['http_location'] ?? ''),     'via' => 'http_redirect'],
            ['code' => (int)($r['yandexbot_http'] ?? 0), 'loc' => (string)($r['yandexbot_location'] ?? ''), 'via' => 'yandexbot_redirect'],
        ] as $probe) {
            if (in_array($probe['code'], self::INTERMEDIATE_CODES, true) && $probe['loc'] !== '') {
                if (self::redirectTargetIsSameDomainHttps($probe['loc'], $domain)) {
                    return ['ready' => true, 'reason' => $probe['via'] . '_' . $probe['code']];
                }
            }
        }

        // Вариант B: публичный HTTPS ответил 2xx/3xx (даже self-signed).
        $httpsFinal = (int)($r['https_final'] ?? 0);
        $httpsInit  = (int)($r['https_initial'] ?? 0);
        $httpsCode  = $httpsFinal ?: $httpsInit;
        if ($httpsCode >= 200 && $httpsCode < 400) {
            // Если был follow и известен финальный URL — он должен остаться на
            // HTTPS того же домена (не увёл на чужой/старый).
            $finalUrl = (string)($r['https_final_url'] ?? '');
            if ($finalUrl === '' || self::finalHostAllowed($finalUrl, $domain)) {
                return ['ready' => true, 'reason' => 'https_' . $httpsCode];
            }
            return ['ready' => false, 'reason' => 'https_unexpected_host'];
        }

        // Ничего технически готового.
        if (($r['http_code'] ?? 0) === 0 && $httpsCode === 0) {
            return ['ready' => false, 'reason' => 'no_connection'];
        }
        return ['ready' => false, 'reason' => 'not_technically_ready'];
    }

    /**
     * v25.1-a: цель редиректа — HTTPS того же нового домена (domain или www.domain).
     * Location может быть относительным (тогда схему/хост берём как есть — но
     * для технической готовности нам нужен ЯВНЫЙ переход на https того же домена).
     */
    public static function redirectTargetIsSameDomainHttps(string $location, string $domain): bool
    {
        $location = trim($location);
        if ($location === '') return false;
        $scheme = strtolower((string)(parse_url($location, PHP_URL_SCHEME) ?: ''));
        $host   = strtolower((string)(parse_url($location, PHP_URL_HOST) ?: ''));
        if ($scheme !== 'https') return false; // downgrade / http-цель не считается
        if ($host === '') return false;
        $domain = strtolower(trim($domain));
        $domainBare = preg_replace('~^www\.~', '', $domain);
        $hostBare   = preg_replace('~^www\.~', '', $host);
        return $hostBare === $domainBare; // domain ↔ www того же домена
    }

    /** Истёк ли timeout readiness-стадии. */
    public static function isTimedOut(int $stageStartedUnix): bool
    {
        if ($stageStartedUnix <= 0) return false;
        return (time() - $stageStartedUnix) >= self::timeoutMinutes() * 60;
    }

    /** Человеко-читаемое пояснение причины (для лога/UI). */
    public static function explainReason(string $reason): string
    {
        if (strpos($reason, 'redirect_') === 0) {
            return 'HTTP ' . substr($reason, 9) . ' — домен ожил, ждём HTTPS 200';
        }
        if (strpos($reason, 'http_') === 0) {
            return 'HTTPS ' . substr($reason, 5) . ' — сайт/бэкенд ещё не готов';
        }
        if (strpos($reason, 'probe_http_') === 0) {
            return 'probe-файл вернул HTTP ' . substr($reason, 11) . ' — не тот docroot или файл не залит';
        }
        $map = [
            'ok'                  => 'HTTPS 200, SSL valid, probe OK',
            'no_connection'       => 'DNS/соединение ещё не готовы',
            'self_signed'         => 'Self-signed сертификат — временный, ждём валидный',
            'ssl_not_valid'       => 'TLS handshake/цепочка ещё не готовы',
            'hostname_mismatch'   => 'Сертификат не для этого домена',
            'probe_ssl_invalid'   => 'probe-файл: SSL невалиден',
            'probe_token_mismatch'=> 'probe-файл: токен не совпал (чужой vhost/заглушка)',
            'empty_domain'        => 'домен не задан',
        ];
        return $map[$reason] ?? $reason;
    }
}
