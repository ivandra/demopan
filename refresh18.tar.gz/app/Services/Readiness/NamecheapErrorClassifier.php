<?php

/**
 * v25.0-a2 (аудит B3): классификация ошибок Namecheap по ОФИЦИАЛЬНЫМ кодам
 * с учётом КОНКРЕТНОЙ команды.
 *
 * Источник: https://www.namecheap.com/support/api/error-codes/ (загружено и
 * сверено). Ключевые факты, из-за которых прежняя таблица была неверной:
 *   - в domains.create кода 2019166 НЕТ; «Domain not available» = 3019166/4019166;
 *   - 2019166 в разных командах = «Domain not found»/«UserName not available»;
 *   - отдельного кода «нет баланса» в create НЕТ — провал заказа это 2528166
 *     (Order creation failed) и семейство 4023166/5050900; баланс проверяется
 *     отдельно users.getBalances;
 *   - 1011102 = «APIKey is missing» (не invalid); 1011150/1017150/1017105/
 *     1017101 = IP/User disabled|locked|invalid — вот истинные account-fatal;
 *   - 500000 = «Too many requests» (глобальный rate-limit, вне таблицы команд).
 *
 * Категории:
 *   ACCOUNT_FATAL       — проблема аккаунта/ключа/IP: искать другие домены
 *                         бессмысленно, останавливаем поиск (→ FAILED+account_fatal);
 *   CANDIDATE_SPECIFIC  — проблема конкретного домена/TLD/промокода: можно к
 *                         следующему кандидату (→ FAILED+candidate_specific);
 *   RETRYABLE           — временная (rate-limit, unknown-from-provider): повтор
 *                         безопасен позже (→ UNKNOWN);
 *   ACCOUNT_OR_ORDER    — провал заказа/списания без явной причины: НЕ угадываем
 *                         «нет баланса», уводим оператора (→ UNKNOWN, с пометкой,
 *                         что стоит проверить баланс через getBalances).
 */
class NamecheapErrorClassifier
{
    const ACCOUNT_FATAL      = 'account_fatal';
    const CANDIDATE_SPECIFIC = 'candidate_specific';
    const RETRYABLE          = 'retryable';
    const ACCOUNT_OR_ORDER   = 'account_or_order_failure';
    const UNKNOWN            = 'unknown';
    const TRANSIENT          = 'transient'; // ТЗ044 §10: транспортная временная ошибка

    /** ТЗ044 §10 — транспортная transient-ошибка read-only операции (без кода Namecheap):
     *  curl/connect timeout, refused/reset, DNS, HTTP 5xx, пустой/битый upstream, unavailable. */
    public static function isTransientTransport(string $message): bool
    {
        $m = strtolower($message);
        $needles = [
            'timeout', 'timed out', 'connection refused', 'connection reset', 'could not connect',
            'couldn\'t connect', 'failed to connect', 'couldn\'t resolve', 'could not resolve',
            'temporarily unavailable', 'service unavailable', 'temporarily', 'try again',
            'empty reply', 'empty response', 'malformed', 'bad gateway', 'gateway timeout',
            'network is unreachable', 'ssl connect error', 'operation timed out', 'registry unavailable',
        ];
        foreach ($needles as $n) { if (strpos($m, $n) !== false) return true; }
        // HTTP 5xx
        if (preg_match('~\b(50[0-9]|5[0-9]{2})\b~', $m) && (strpos($m,'http')!==false || strpos($m,'status')!==false || strpos($m,'server error')!==false)) return true;
        if (strpos($m,'500000')!==false || strpos($m,'too many requests')!==false) return true; // NC глобальный rate-limit
        return false;
    }

    /** ТЗ044 §10 — bounded backoff: 30 → 60 → 120s; max 3 попытки. */
    public static function backoffSeconds(int $attempt): int
    {
        $schedule = [1 => 30, 2 => 60, 3 => 120];
        return $schedule[$attempt] ?? 120;
    }

    const MAX_TRANSIENT_ATTEMPTS = 3;


    /**
     * Коды аутентификации — общие для ВСЕХ команд. Проблема аккаунта/ключа/IP.
     * Все ACCOUNT_FATAL: перебирать домены дальше нет смысла.
     */
    private const AUTH_FATAL = [
        1010101 => 'APIUser is missing',
        1010104 => 'Command is missing',
        1010102 => 'APIKey is missing',
        1011102 => 'APIKey is missing',
        1010105 => 'ClientIP is missing',
        1011105 => 'ClientIP is missing',
        1050900 => 'Unknown error validating APIUser',
        1011150 => 'RequestIP is invalid',
        1017150 => 'RequestIP is disabled or locked',
        1017105 => 'ClientIP is disabled or locked',
        1017101 => 'ApiUser is disabled or locked',
        1017410 => 'Too many declined payments',
        1017411 => 'Too many login attempts',
        1019103 => 'UserName is not available',
        1016103 => 'UserName is unauthorized',
        1017103 => 'UserName is disabled or locked',
        1030408 => 'Unsupported authentication type',
    ];

    /** Глобальный rate-limit (вне поком-таблиц, подтверждён на практике). */
    private const RATE_LIMIT = [500000 => 'Too many requests'];

    /**
     * Пер-командные таблицы. Значение — категория для КОНКРЕТНОГО кода в этой
     * команде (один код может значить разное в разных методах!).
     */
    private const BY_COMMAND = [
        'namecheap.domains.create' => [
            2033409 => self::ACCOUNT_OR_ORDER,   // order chargeable for Username not found
            2528166 => self::ACCOUNT_OR_ORDER,   // Order creation failed
            4023166 => self::ACCOUNT_OR_ORDER,   // Error while adding domain
            5050900 => self::ACCOUNT_OR_ORDER,   // Unknown error adding domain to account
            3019166 => self::CANDIDATE_SPECIFIC, // Domain not available
            4019166 => self::CANDIDATE_SPECIFIC, // Domain not available
            2030280 => self::CANDIDATE_SPECIFIC, // TLD is not supported in API
            2011280 => self::CANDIDATE_SPECIFIC, // Validation error from TLD
            2011168 => self::CANDIDATE_SPECIFIC, // Nameservers are not valid
            2011170 => self::CANDIDATE_SPECIFIC, // PromotionCode validation error
            2011322 => self::CANDIDATE_SPECIFIC, // Extended Attributes not valid
            2010323 => self::CANDIDATE_SPECIFIC, // billing domain contacts missing
            2015182 => self::CANDIDATE_SPECIFIC, // contact phone invalid
            2015167 => self::CANDIDATE_SPECIFIC, // Years validation
            2015267 => self::CANDIDATE_SPECIFIC, // EUAgreeDelete option
            3031166 => self::RETRYABLE,          // provider error
            3028166 => self::RETRYABLE,          // Enom error
            3031900 => self::RETRYABLE,          // unknown provider response
        ],
        'namecheap.domains.check' => [
            3031510 => self::RETRYABLE,          // Enom errorcount != 0
            3011511 => self::RETRYABLE,          // unknown provider response
        ],
        'namecheap.users.getPricing' => [
            2011170 => self::CANDIDATE_SPECIFIC, // PromotionCode invalid (не фатально)
            2011298 => self::ACCOUNT_FATAL,      // ProductType invalid — конфиг сломан
        ],
        'namecheap.domains.getInfo' => [
            5019169 => self::RETRYABLE,          // unknown exceptions
        ],
        'namecheap.domains.getContacts' => [
            2019166 => self::CANDIDATE_SPECIFIC, // Domain not found
            2016166 => self::CANDIDATE_SPECIFIC, // not associated with account
        ],
        'namecheap.domains.dns.setHosts' => [
            2019166 => self::CANDIDATE_SPECIFIC, // Domain not found
            2016166 => self::CANDIDATE_SPECIFIC, // not associated with account
            2030166 => self::CANDIDATE_SPECIFIC, // edit permission not supported
            3013288 => self::RETRYABLE,          // too many records
            4013288 => self::RETRYABLE,
            3031510 => self::RETRYABLE,
            3050900 => self::RETRYABLE,
            4022288 => self::RETRYABLE,
        ],
        'namecheap.domains.dns.getHosts' => [
            2019166 => self::CANDIDATE_SPECIFIC,
            2030166 => self::CANDIDATE_SPECIFIC,
            2030288 => self::CANDIDATE_SPECIFIC, // not using proper DNS servers
            3031510 => self::RETRYABLE,
            3050900 => self::RETRYABLE,
            4023330 => self::RETRYABLE,
        ],
    ];

    /**
     * Классифицировать по коду + команде.
     * @return array{category:string, code:?int, message:string, retryable:bool,
     *               account_fatal:bool, candidate_specific:bool}
     */
    public static function classify(?int $code, string $command, string $message = ''): array
    {        if ($code === null) {
            return self::make(self::UNKNOWN, null, $message);
        }
        // Аутентификация/IP — фатально для всего аккаунта, вне зависимости от команды.
        if (isset(self::AUTH_FATAL[$code])) {
            return self::make(self::ACCOUNT_FATAL, $code, $message ?: self::AUTH_FATAL[$code]);
        }
        if (isset(self::RATE_LIMIT[$code])) {
            return self::make(self::RETRYABLE, $code, $message ?: self::RATE_LIMIT[$code]);
        }
        $table = self::BY_COMMAND[$command] ?? [];
        if (isset($table[$code])) {
            return self::make($table[$code], $code, $message);
        }
        // Код есть, но для этой команды не расписан — не угадываем.
        return self::make(self::UNKNOWN, $code, $message);
    }

    /** Извлечь код [NNNN] из текста ошибки (его кладёт extractErrors). */
    public static function extractCode(string $message): ?int
    {
        if (preg_match('~\[(\d{3,7})\]~', $message, $m)) {
            return (int)$m[1];
        }
        return null;
    }

    private static function make(string $category, ?int $code, string $message): array
    {
        return [
            'category'           => $category,
            'code'               => $code,
            'message'            => $message,
            'retryable'          => $category === self::RETRYABLE,
            'account_fatal'      => $category === self::ACCOUNT_FATAL,
            'candidate_specific' => $category === self::CANDIDATE_SPECIFIC,
            'account_or_order'   => $category === self::ACCOUNT_OR_ORDER,
        ];
    }
}
