<?php

/**
 * PATCH 048 (Gate W W2): reconciliation локальной строки переобхода с внешней задачей Яндекса
 * ДО нового POST. Использует typed getRecrawlTasks()/getRecrawlTask() (routed apiRequest).
 *
 * Порядок (§7.1):
 *   1. queue GET через назначенный IP;
 *   2. если локально сохранён task_id — сначала искать по нему (в очереди, затем прямым task GET);
 *   3. иначе — искать по точному нормализованному URL И временному окну текущего execution;
 *   4. старую задачу того же URL, созданную ДО окна, НЕ сопоставлять;
 *   5. обработать найденное состояние;
 *   6. только если подходящей задачи нет — разрешить POST.
 *
 * Состояния (§7.2): IN_PROGRESS/DONE → accepted (POST не нужен; DONE ≠ indexed);
 *                   FAILED → evidence, accepted НЕ ставим; UNKNOWN → сохранить, success не ставим.
 *
 * Сервис НЕ делает POST и НЕ пишет в БД сам — возвращает решение + evidence; стадия применяет их.
 * Критические routing-сбои getRecrawlTasks/getRecrawlTask пробрасываются наружу (fail-closed).
 */
final class RecrawlReconciliationService
{
    /** @var object WM-клиент: getRecrawlTasks(u,h,off,lim), getRecrawlTask(u,h,taskId) */
    private $client;

    public function __construct($client)
    {
        $this->client = $client;
    }

    /**
     * @param int $windowStartTs epoch начала временного окна текущего recrawl execution
     * @return array{
     *   action:string,            // 'reconciled' | 'allow_post'
     *   reason:string,
     *   state:?string,            // IN_PROGRESS|DONE|FAILED|UNKNOWN
     *   accept:bool,              // ставить ли accepted
     *   indexed:bool,             // DONE != indexed → всегда false здесь
     *   task:?array,
     *   get_http_code:int,        // код reconciliation GET (отдельно от POST)
     *   routing:array
     * }
     */
    public function reconcile(string $userId, string $hostId, string $url, ?string $localTaskId, int $windowStartTs): array
    {
        // (1) queue GET с пагинацией (routing-сбои пробрасываются). Читаем до maxPages страниц,
        // чтобы нужная задача не потерялась за первой сотней (2.2). Блокер 6: если safety-cap
        // страниц исчерпан (очередь не дочитана до конца), нельзя доказать отсутствие задачи.
        $tasks = [];
        $getCode = 0; $routing = [];
        $limit = 100; $maxPages = 5;
        $exhausted = true;
        // P1-4: пагинация ВНУТРИ временного окна — date_from из windowStartTs (ISO 8601, UTC).
        // Отклонение фильтра API (HTTP 4xx, не routing) → fail-closed indeterminate (POST запрещён).
        $dateFrom = $windowStartTs > 0 ? gmdate('c', $windowStartTs) : null;
        for ($page = 0; $page < $maxPages; $page++) {
            try {
                $q = $this->client->getRecrawlTasks($userId, $hostId, $page * $limit, $limit, $dateFrom);
            } catch (\RuntimeException $e) {
                $msg = $e->getMessage();
                $up  = strtoupper($msg);
                // routing/IP-pin сбой — hard-stop без fallback (инвариант), пробрасываем.
                if (strpos($msg, 'routing (') !== false) { throw $e; }
                // account/auth ошибки (INVALID_USER_ID, 401/403 auth) — account/routing blocker, hard-stop.
                if (strpos($up, 'INVALID_USER_ID') !== false || strpos($up, 'INVALID_OAUTH') !== false
                    || preg_match('~HTTP 401~', $msg)
                    || (preg_match('~HTTP 403~', $msg) && strpos($up, 'HOST_NOT_VERIFIED') === false)) {
                    throw $e;
                }
                // P1b (REV3.1): различаем причины 4xx, не маскируя всё как отказ date_from.
                if (preg_match('~HTTP 4\d\d~', $msg)) {
                    // (a) права на host не подтверждены — штатная ветка ожидания/повторной проверки.
                    if (strpos($up, 'HOST_NOT_VERIFIED') !== false) {
                        return ['action' => 'indeterminate', 'reason' => 'host_not_verified', 'state' => null,
                                'accept' => false, 'indexed' => false, 'task' => null,
                                'get_http_code' => $getCode, 'routing' => $routing, 'diag' => $msg];
                    }
                    // (b) доказанный отказ САМОГО параметра/контракта date_from.
                    if (strpos($up, 'DATE_FROM') !== false || strpos($up, 'INVALID_PARAM') !== false
                        || strpos($up, 'PARAMETER') !== false || strpos($up, 'BAD_REQUEST') !== false
                        || preg_match('~HTTP 400~', $msg)) {
                        return ['action' => 'indeterminate', 'reason' => 'date_from_filter_rejected', 'state' => null,
                                'accept' => false, 'indexed' => false, 'task' => null,
                                'get_http_code' => $getCode, 'routing' => $routing, 'diag' => $msg];
                    }
                    // (c) прочий 4xx — fail-closed indeterminate, но НЕ под видом ошибки date_from.
                    return ['action' => 'indeterminate', 'reason' => 'queue_get_4xx', 'state' => null,
                            'accept' => false, 'indexed' => false, 'task' => null,
                            'get_http_code' => $getCode, 'routing' => $routing, 'diag' => $msg];
                }
                throw $e;
            }
            $getCode = (int)($q['_http_code'] ?? $getCode);
            $routing = (array)($q['_routing'] ?? $routing);
            $batch = (array)($q['tasks'] ?? []);
            foreach ($batch as $b) { $tasks[] = $b; }
            if (count($batch) < $limit) { $exhausted = false; break; } // окно дочитано до конца
        }

        $match = null; $matchHadTime = true;

        // (2) по локальному task_id — в очереди, затем прямым task GET (валидируем ответ)
        if ($localTaskId !== null && $localTaskId !== '') {
            // P1c (REV3.1): совпадение по task_id в очереди принимаем ТОЛЬКО если queue-item полный
            // (task_id+url+state). Неполный queue-item (есть ID, нет url/state) НЕ считаем найденной задачей —
            // выполняем прямой typed task GET.
            foreach ($tasks as $t) {
                if ((string)($t['task_id'] ?? '') === $localTaskId && self::taskValidQueue($t)) { $match = $t; break; }
            }
            if ($match === null) {
                $tk = $this->client->getRecrawlTask($userId, $hostId, $localTaskId);
                // 2.3: неполный ответ (нет url/state) НЕ считаем найденной задачей.
                if (self::taskValid($tk)) {
                    // P1-3: task_id известен из запроса — проставляем явно в нормализованную задачу,
                    // чтобы downstream accept не получил пустой task ID.
                    if ((string)($tk['task_id'] ?? '') === '') { $tk['task_id'] = $localTaskId; }
                    $match = $tk;
                    $getCode = (int)($tk['_http_code'] ?? $getCode);
                    $routing = (array)($tk['_routing'] ?? $routing);
                } else {
                    // P1c: и queue-item, и direct GET неполные → fail-closed indeterminate, POST запрещён.
                    // (task_id локально известен, но состояние задачи недоказуемо — повторно слать POST нельзя).
                    $qItemSeen = false;
                    foreach ($tasks as $t) { if ((string)($t['task_id'] ?? '') === $localTaskId) { $qItemSeen = true; break; } }
                    if ($qItemSeen) {
                        return ['action' => 'indeterminate', 'reason' => 'local_task_incomplete', 'state' => null,
                                'accept' => false, 'indexed' => false, 'task' => null,
                                'get_http_code' => $getCode, 'routing' => $routing];
                    }
                }
            }
        }

        // (3)/(4) по нормализованному URL.
        // Блокер 6 (REV2): added_time в API Yandex НЕОБЯЗАТЕЛЕН. Валидная задача = task_id + state.
        //  - URL совпал И задача валидна (task_id+state) И added_time валиден в окне → accept (reconciled);
        //  - URL совпал, задача валидна, НО added_time отсутствует/невалиден → INDETERMINATE (POST запрещён),
        //    чтобы не отправить повторно то, что уже в очереди;
        //  - старая задача вне окна (added_time валиден и < window) → пропуск (не наша).
        if ($match === null) {
            $nurl = self::normalizeUrl($url);
            $indeterminateByTime = false;
            foreach ($tasks as $t) {
                if (self::normalizeUrl((string)($t['url'] ?? '')) !== $nurl) continue;
                if (!self::taskValidQueue($t)) continue;            // P1-3: queue-item без task_id — не задача
                $addedTs = self::parseTime((string)($t['added_time'] ?? ''));
                if ($addedTs === null) { $indeterminateByTime = true; continue; } // валидная задача без времени → indeterminate
                if ($addedTs < $windowStartTs) continue;            // старая задача вне окна — пропуск
                $match = $t; $matchHadTime = true;
                break;
            }
            if ($match === null && $indeterminateByTime) {
                return ['action' => 'indeterminate', 'reason' => 'matched_task_without_added_time', 'state' => null,
                        'accept' => false, 'indexed' => false, 'task' => null,
                        'get_http_code' => $getCode, 'routing' => $routing];
            }
        }

        // (6) подходящей задачи нет.
        if ($match === null) {
            // Блокер 6: если safety-cap страниц исчерпан — отсутствие задачи НЕ доказано → indeterminate (no POST).
            if ($exhausted) {
                return ['action' => 'indeterminate', 'reason' => 'page_cap_exhausted', 'state' => null,
                        'accept' => false, 'indexed' => false, 'task' => null,
                        'get_http_code' => $getCode, 'routing' => $routing];
            }
            return ['action' => 'allow_post', 'reason' => 'no_matching_task', 'state' => null,
                    'accept' => false, 'indexed' => false, 'task' => null,
                    'get_http_code' => $getCode, 'routing' => $routing];
        }

        // (5) обработка состояния
        $state = strtoupper(trim((string)($match['state'] ?? '')));
        if ($state === '') $state = 'UNKNOWN';
        $accept = in_array($state, ['IN_PROGRESS', 'DONE'], true);
        $reason = 'task_' . strtolower($state);

        return ['action' => 'reconciled', 'reason' => $reason, 'state' => $state,
                'accept' => $accept, 'indexed' => false, 'task' => $match,
                'get_http_code' => $getCode, 'routing' => $routing];
    }

    /** Нормализация URL для точного сопоставления (scheme+host lower, без завершающего слэша, без фрагмента). */
    public static function normalizeUrl(string $url): string
    {
        $u = trim($url);
        if ($u === '') return '';
        $parts = parse_url($u);
        if ($parts === false) return mb_strtolower($u);
        $scheme = mb_strtolower((string)($parts['scheme'] ?? 'https'));
        $host   = mb_strtolower(rtrim((string)($parts['host'] ?? ''), '.'));
        $path   = (string)($parts['path'] ?? '/');
        if ($path === '') $path = '/';
        if ($path !== '/') $path = rtrim($path, '/');
        $query  = isset($parts['query']) && $parts['query'] !== '' ? '?' . $parts['query'] : '';
        return $scheme . '://' . $host . $path . $query;
    }

    /** ISO/RFC время задачи → epoch, либо null если не распознано. */
    public static function parseTime(string $t): ?int
    {
        $t = trim($t);
        if ($t === '') return null;
        $ts = strtotime($t);
        return $ts === false ? null : $ts;
    }

    /** Direct task GET: валидна при непустых url И state (task_id известен из запроса и проставляется вызовом). */
    public static function taskValid($tk): bool
    {
        if (!is_array($tk)) return false;
        return (string)($tk['url'] ?? '') !== '' && (string)($tk['state'] ?? '') !== '';
    }

    /** Queue-list item (P1-3): валиден ТОЛЬКО при непустых task_id, url И state.
     *  Без task_id задачу нельзя accept'ить (markAcceptedFromQueue получил бы пустой task ID). */
    public static function taskValidQueue($tk): bool
    {
        if (!is_array($tk)) return false;
        return (string)($tk['task_id'] ?? '') !== ''
            && (string)($tk['url'] ?? '') !== ''
            && (string)($tk['state'] ?? '') !== '';
    }
}
