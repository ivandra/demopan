<?php

/**
 * v25.0-a: строгая проверка результата покупки домена в Namecheap.
 *
 * ТЗ раздел 5: отсутствие PHP-исключения — НЕ доказательство покупки. После
 * domains.create нужно однозначное подтверждение:
 *   - парсится DomainCreateResult;
 *   - домен совпадает;
 *   - Registered=true (признак фактической регистрации).
 *
 * Неоднозначный результат (timeout / connection reset / 5xx / пустой или
 * битый XML) — это purchase_outcome=unknown. В этом случае ЗАПРЕЩЕНО повторно
 * покупать тот же домен, брать следующего кандидата или покупать другой домен.
 * Сначала — read-only domains.getInfo: если домен уже в аккаунте, покупка
 * успешна; если долго не удаётся установить — awaiting_user (решает оператор).
 *
 * Классификация здесь ЧИСТАЯ (без сети), чтобы её можно было юнит-тестировать.
 * Сетевой getInfo вызывает потребитель (DomainPurchaseService).
 */
class NamecheapPurchaseVerifier
{
    const OUTCOME_SUCCESS = 'success';
    const OUTCOME_FAILED  = 'failed';   // однозначный отказ (можно к следующему кандидату)
    const OUTCOME_UNKNOWN = 'unknown';  // неоднозначно — трогать НЕЛЬЗЯ, сначала getInfo

    /**
     * Классифицировать результат createDomain().
     *
     * @param string          $domain   ожидаемый домен (sld.tld)
     * @param array|null      $response результат createDomain() (CommandResponse) либо null
     * @param \Throwable|null $error    исключение createDomain(), если было
     */
    public static function classifyCreate(string $domain, ?array $response, ?\Throwable $error = null): array
    {
        $domain = strtolower(trim($domain));

        // 1) Было исключение — разбираем его характер.
        if ($error !== null) {
            $msg = $error->getMessage();

            // v25.0-a2 (аудит B3): классификация по ОФИЦИАЛЬНОМУ коду Namecheap
            // с учётом команды domains.create. Прежняя таблица кодов была
            // неверной (2019166 ≠ «нет баланса»); теперь — из документации.
            $code = NamecheapErrorClassifier::extractCode($msg);
            $cls = NamecheapErrorClassifier::classify($code, 'namecheap.domains.create', $msg);
            $mapped = self::mapClassification($cls, $msg);
            if ($mapped !== null) return $mapped;

            // Кода нет/не распознан — эвристика по тексту как fallback.
            if (self::isAmbiguousError($msg)) {
                return self::result(self::OUTCOME_UNKNOWN, 'ambiguous_error', $msg);
            }
            return self::result(self::OUTCOME_FAILED, 'api_error', $msg);
        }

        // 2) Ответа нет вовсе — неоднозначно.
        if (!is_array($response) || empty($response)) {
            return self::result(self::OUTCOME_UNKNOWN, 'empty_response', 'no DomainCreateResult in response');
        }

        // 3) Ищем DomainCreateResult (устойчиво к формам xmlToArray).
        $result = self::findCreateResult($response);
        if ($result === null) {
            return self::result(self::OUTCOME_UNKNOWN, 'no_create_result', 'DomainCreateResult missing');
        }

        // 4) Совпадение домена.
        $respDomain = strtolower(trim((string)(
            $result['@Domain'] ?? $result['Domain'] ?? ''
        )));
        if ($respDomain !== '' && $respDomain !== $domain) {
            return self::result(self::OUTCOME_FAILED, 'domain_mismatch',
                "response domain '{$respDomain}' != expected '{$domain}'");
        }

        // 5) Признак фактической регистрации.
        $registered = self::boolAttr($result, 'Registered');
        if ($registered === false) {
            return self::result(self::OUTCOME_FAILED, 'not_registered', 'Registered=false');
        }
        if ($registered === null) {
            // Есть DomainCreateResult, но Registered не читается — неоднозначно.
            return self::result(self::OUTCOME_UNKNOWN, 'registered_unknown', 'Registered flag absent');
        }

        // Успех: есть result, домен совпал, Registered=true.
        $extra = [
            'order_id'       => $result['@OrderID']       ?? ($result['OrderID'] ?? null),
            'transaction_id' => $result['@TransactionID'] ?? ($result['TransactionID'] ?? null),
            'charged_amount' => $result['@ChargedAmount'] ?? ($result['ChargedAmount'] ?? null),
        ];
        return self::result(self::OUTCOME_SUCCESS, 'registered', 'Registered=true', $extra);
    }

    /**
     * Интерпретировать результат read-only getInfo() при outcome=unknown.
     * Если домен в аккаунте — покупка де-факто успешна.
     *
     * @param array|null $infoResponse результат getDomainInfo() либо null
     */
    public static function classifyGetInfo(string $domain, ?array $infoResponse, ?\Throwable $error = null): array
    {
        $domain = strtolower(trim($domain));

        if ($error !== null) {
            // getInfo сам упал — статус по-прежнему неизвестен.
            return self::result(self::OUTCOME_UNKNOWN, 'getinfo_error', $error->getMessage());
        }
        if (!is_array($infoResponse) || empty($infoResponse)) {
            return self::result(self::OUTCOME_UNKNOWN, 'getinfo_empty', 'empty getInfo response');
        }

        // DomainGetInfoResult присутствует и домен совпадает → домен НАШ.
        $res = $infoResponse['DomainGetInfoResult'] ?? $infoResponse;
        $respDomain = strtolower(trim((string)(
            $res['@DomainName'] ?? $res['DomainName'] ?? ''
        )));
        $status = strtolower(trim((string)($res['@Status'] ?? $res['Status'] ?? '')));

        if ($respDomain === $domain || ($respDomain === '' && $status !== '')) {
            // Namecheap возвращает getInfo только для доменов аккаунта.
            return self::result(self::OUTCOME_SUCCESS, 'found_in_account', "status={$status}");
        }

        return self::result(self::OUTCOME_UNKNOWN, 'not_confirmed', 'domain not confirmed in account');
    }

    /* ==================== ВНУТРЕННЕЕ ==================== */

    /**
     * v25.0-a2: перевести результат NamecheapErrorClassifier в outcome покупки.
     * @return array|null null если категория UNKNOWN и текст стоит проверить эвристикой.
     */
    private static function mapClassification(array $cls, string $msg): ?array
    {
        switch ($cls['category']) {
            case NamecheapErrorClassifier::ACCOUNT_FATAL:
                return self::result(self::OUTCOME_FAILED, 'account_fatal', $msg,
                    ['api_error_code' => $cls['code'], 'account_fatal' => true, 'candidate_specific' => false]);

            case NamecheapErrorClassifier::CANDIDATE_SPECIFIC:
                return self::result(self::OUTCOME_FAILED, 'candidate_specific', $msg,
                    ['api_error_code' => $cls['code'], 'candidate_specific' => true, 'account_fatal' => false]);

            case NamecheapErrorClassifier::RETRYABLE:
                return self::result(self::OUTCOME_UNKNOWN, 'temporary', $msg,
                    ['api_error_code' => $cls['code'], 'retryable' => true]);

            case NamecheapErrorClassifier::ACCOUNT_OR_ORDER:
                // Провал заказа/списания без явной причины. НЕ угадываем «нет
                // баланса» — уводим в unknown с подсказкой проверить баланс.
                return self::result(self::OUTCOME_UNKNOWN, 'account_or_order_failure', $msg,
                    ['api_error_code' => $cls['code'], 'check_balance' => true]);

            default:
                return null; // UNKNOWN — пусть решает текстовая эвристика вызывателя
        }
    }

    private static function isAmbiguousError(string $msg): bool
    {
        $m = strtolower($msg);
        $needles = [
            'timeout', 'timed out', 'connection reset', 'connection refused',
            'could not resolve', 'ssl', 'curl error', 'empty reply',
            'bad xml', 'bad gateway', 'gateway timeout', 'service unavailable',
            'http 5', // HTTP 5xx
        ];
        foreach ($needles as $n) {
            if (strpos($m, $n) !== false) return true;
        }
        return false;
    }

    private static function findCreateResult(array $response): ?array
    {
        if (isset($response['DomainCreateResult']) && is_array($response['DomainCreateResult'])) {
            return $response['DomainCreateResult'];
        }
        // Иногда обёрнуто глубже.
        foreach ($response as $v) {
            if (is_array($v) && isset($v['DomainCreateResult']) && is_array($v['DomainCreateResult'])) {
                return $v['DomainCreateResult'];
            }
        }
        return null;
    }

    /** Прочитать булев атрибут (@Name или Name) как true/false/null. */
    private static function boolAttr(array $result, string $key): ?bool
    {
        foreach (['@' . $key, $key] as $k) {
            if (array_key_exists($k, $result)) {
                $v = strtolower(trim((string)$result[$k]));
                if ($v === 'true'  || $v === '1' || $v === 'yes') return true;
                if ($v === 'false' || $v === '0' || $v === 'no')  return false;
            }
        }
        return null;
    }

    private static function result(string $outcome, string $reason, string $message, array $extra = []): array
    {
        return array_merge([
            'outcome' => $outcome,
            'reason'  => $reason,
            'message' => $message,
        ], $extra);
    }
}
