<?php

/**
 * v25.0-a: заливка/удаление probe-файла готовности через FTP.
 *
 * Probe-файл /.refresh-ready-<job>-<token>.txt подтверждает, что публичный
 * HTTPS-запрос попал ИМЕННО в нужный сайт (правильные alias/vhost/docroot),
 * а не в чужой virtual host или заглушку сервера, которые тоже отдают 200.
 *
 * Использует тот же FtpService, что и WebmasterFileVerifier (yandex_*.html).
 * Удаление обязательно после успеха, при rollback/cancel/supersede/cleanup
 * (ТЗ раздел 7) — за это отвечает removeForJob().
 */
class ProbeFileManager
{
    /** Залить probe-файл в корень сайта. @return array{ok:bool,message:string,file:string} */
    public function upload(int $siteId, int $jobId, string $token, JobEventLogger $log): array
    {
        $file = DomainReadinessService::probeFileName($jobId, $token);
        $content = DomainReadinessService::probeContent($jobId, $token);

        $site = $this->loadSite($siteId);
        if (!$site) {
            return ['ok' => false, 'message' => "site #{$siteId} not found", 'file' => $file];
        }

        try {
            $ftp = $this->ftp($site);
            $ftp->connect();
            try {
                // Без backup — это новый временный файл.
                $ftp->putContent(ltrim($file, '/'), $content, null);
            } finally {
                $ftp->disconnect();
            }
        } catch (\Throwable $e) {
            return ['ok' => false, 'message' => 'FTP upload failed: ' . $e->getMessage(), 'file' => $file];
        }

        $log->info('domain_readiness', "probe-файл залит: {$file}");
        return ['ok' => true, 'message' => 'uploaded', 'file' => $file];
    }

    /**
     * Удалить probe-файл. Идемпотентно: отсутствие файла — не ошибка.
     * token берём из артефактов джобы; если его там нет — тихо выходим.
     */
    public function removeForJob(int $jobId, ?JobEventLogger $log = null): void
    {
        try {
            $st = DB::pdo()->prepare("SELECT site_id, artifacts_json FROM refresh_jobs WHERE id = ?");
            $st->execute([$jobId]);
            $row = $st->fetch();
            if (!$row) return;

            $arts = json_decode((string)($row['artifacts_json'] ?? ''), true) ?: [];
            $token = (string)($arts['domain_readiness_stage']['probe_token'] ?? '');
            if ($token === '') return; // probe не создавался

            $siteId = (int)$row['site_id'];
            $site = $this->loadSite($siteId);
            if (!$site) return;

            $file = ltrim(DomainReadinessService::probeFileName($jobId, $token), '/');
            $ftp = $this->ftp($site);
            $ftp->connect();
            try {
                if ($ftp->fileExists($file)) {
                    $ftp->deleteFile($file);
                    if ($log) $log->info('domain_readiness', "probe-файл удалён: /{$file}");
                }
            } finally {
                $ftp->disconnect();
            }
        } catch (\Throwable $e) {
            // Удаление probe не должно ломать основной сценарий.
            if ($log) $log->warn('domain_readiness', 'probe cleanup failed: ' . $e->getMessage());
            else error_log("ProbeFileManager::removeForJob({$jobId}) failed: " . $e->getMessage());
        }
    }

    private function loadSite(int $siteId): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
        $st->execute([$siteId]);
        $s = $st->fetch();
        return is_array($s) ? $s : null;
    }

    private function ftp(array $site): FtpService
    {
        return new FtpService(
            (string)$site['ftp_host'],
            (string)$site['ftp_user'],
            Crypto::decrypt((string)$site['ftp_pass_enc'])
        );
    }
}
