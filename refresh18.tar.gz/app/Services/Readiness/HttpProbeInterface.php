<?php

/**
 * v25.0-a: абстракция публичной HTTP/HTTPS-проверки.
 *
 * Зачем интерфейс: сетевой вызов изолирован, чтобы (1) в проде работал
 * реальный cURL со строгой TLS-валидацией, а (2) в автотестах подставлялся
 * фейк с заранее заданными ответами — без внешней сети и без обращений к
 * боевым доменам.
 *
 * ВАЖНО (ТЗ раздел 3.1, 6): реализация НЕ должна использовать
 * CURLOPT_RESOLVE / принудительный IP и НЕ должна отключать TLS-проверку.
 * Источник истины — реальная публичная доступность домена.
 */
interface HttpProbeInterface
{
    /**
     * HTTP-проверка http://<url> БЕЗ follow-redirect.
     * Фиксирует исходный код (0 / 200 / 301 / 4xx / 5xx) и Location.
     *
     * @return array{
     *   http_code:int, location:?string, error:?string, checked_at:string
     * }
     */
    public function probeHttp(string $url, int $timeoutSec = 10): array;

    /**
     * v25.1-a: HTTP-проверка с заданным User-Agent (для запроса «как YandexBot»)
     * БЕЗ follow-redirect. Тот же контракт, что probeHttp, но UA задаётся явно.
     *
     * @return array{ http_code:int, location:?string, error:?string, checked_at:string }
     */
    public function probeHttpAs(string $url, string $userAgent, int $timeoutSec = 10): array;

    /**
     * HTTPS-проверка https://<url> с ПОЛНОЙ TLS-валидацией и ограниченным
     * follow. Возвращает исходный и финальный код, данные сертификата.
     *
     * @return array{
     *   initial_code:int, final_code:int, final_url:?string,
     *   ssl_valid:bool, hostname_valid:bool, self_signed:bool,
     *   certificate_issuer:?string, certificate_not_before:?string,
     *   certificate_not_after:?string, error:?string, checked_at:string
     * }
     */
    public function probeHttps(string $url, int $timeoutSec = 15): array;

    /**
     * v25.1-a1 (Блокер 1): публичный HTTPS-transport БЕЗ доверия цепочке —
     * только для внутренней проверки достижимости (self-signed на старте).
     * По-прежнему: публичный DNS, БЕЗ CURLOPT_RESOLVE; ограниченный follow;
     * возвращает реальный HTTP-код и effective URL. НЕ использовать для
     * verification/recrawl — там строгий probeHttps.
     *
     * @return array{
     *   final_code:int, final_url:?string, self_signed:bool,
     *   ssl_trusted:bool, error:?string, checked_at:string
     * }
     */
    public function probeHttpsAllowUntrusted(string $url, int $timeoutSec = 15): array;

    /**
     * Получить тело по публичному HTTPS (для probe-файла).
     * Полная TLS-валидация, без CURLOPT_RESOLVE.
     *
     * @return array{
     *   http_code:int, body:?string, ssl_valid:bool, error:?string, checked_at:string
     * }
     */
    public function fetchHttps(string $url, int $timeoutSec = 15): array;

    /**
     * v25.1-b: разобрать TLS-сертификат домена БЕЗ требования доверия цепочке
     * (для SSL-вкладки: issuer/subject/serial/срок даже у self-signed/expired/
     * mismatch). Публичный DNS. Возвращает разобранные поля + флаги trusted/
     * self_signed/hostname_valid/expired.
     *
     * @return array{
     *   tls_present:bool, tls_trusted:bool, is_self_signed:bool,
     *   hostname_valid:bool, expired:bool, issuer:?string, subject:?string,
     *   serial_number:?string, valid_from:?string, valid_to:?string,
     *   days_remaining:?int, error:?string
     * }
     */
    public function inspectCertificate(string $host, int $port = 443, int $timeoutSec = 12): array;

    /**
     * v25.2-a (§5.3, способ A): insecure-HTTPS GET (TLS как транспорт, без
     * доверия цепочке) с ТЕЛОМ ответа — для подтверждения размещения verifier
     * ДО появления trusted SSL. Публичный DNS, БЕЗ CURLOPT_RESOLVE, follow до
     * 5 редиректов. НЕ доказывает trusted — только достижимость+тело.
     *
     * @return array{ http_code:int, final_url:?string, body:?string,
     *                final_scheme:?string, final_host:?string, error:?string, checked_at:string }
     */
    public function fetchHttpsAllowUntrusted(string $url, int $timeoutSec = 15): array;

    /**
     * v25.2-a (§5.3, способ B): обычный HTTP GET с телом и follow-redirect.
     * Возвращает финальный код/URL/тело для нестрогого подтверждения размещения.
     *
     * @return array{ http_code:int, final_url:?string, body:?string,
     *                final_scheme:?string, final_host:?string, error:?string, checked_at:string }
     */
    public function fetchHttpBody(string $url, int $timeoutSec = 10): array;

    /**
     * v25.2-a (§5.3, способ C): HTTPS GET через принудительный IP (--resolve)
     * для обхода DNS-пропагации. TLS как транспорт (без доверия), тело
     * возвращается. Только для нестрогого подтверждения размещения.
     *
     * @return array{ http_code:int, final_url:?string, body:?string,
     *                final_scheme:?string, final_host:?string, error:?string, checked_at:string }
     */
    public function fetchHttpsResolved(string $url, string $host, string $ip, int $port = 443, int $timeoutSec = 15): array;
}
