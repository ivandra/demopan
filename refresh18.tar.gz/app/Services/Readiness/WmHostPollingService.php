<?php

/**
 * v25.0-b: асинхронное ожидание регистрации host в Яндекс.Вебмастере.
 *
 * Проблема (жалоба заказчика): «спотыкается на добавлении host». Яндекс
 * регистрирует хост АСИНХРОННО — сразу после addHost его ещё нет в списке,
 * а прежний код брал host_id одним махом и падал/шёл дальше с пустым id.
 *
 * Логика (по решению заказчика):
 *   1) проверить, нет ли host уже в аккаунте → есть: сохранить host_id, готово;
 *   2) если нет — отправить addHost ОДИН раз (флаг add_sent в артефактах);
 *   3) периодически перечитывать список hosts, искать точное совпадение;
 *   4) нашли — сохранить host_id, готово;
 *   5) timeout → awaiting_user (НЕ failed, НЕ повторный addHost вслепую —
 *      Яндекс мог уже принять запрос).
 *
 * Многотиковость: состояние в artifacts.wm_added_stage. Вызывается под
 * job-lock из оркестратора. Все UPDATE — с terminal-guard.
 *
 * @return string 'ready' | 'waiting' | 'awaiting_user' | 'terminal'
 */
class WmHostPollingService
{
    public static function intervalSec(): int   { return max(10, AppSettings::getInt('wm.host_poll_interval_seconds', 25)); }
    public static function timeoutMinutes(): int { return max(1, AppSettings::getInt('wm.host_poll_timeout_minutes', 30)); }

    /** @var callable|null фабрика WM-клиента для тестов (accountId → client). */
    private $clientFactory = null;

    /** v25.0-b1: внедрить фабрику клиента (для поведенческих тестов). */
    public function setClientFactory(callable $f): void { $this->clientFactory = $f; }

    private function makeClient(int $accountId)
    {
        if ($this->clientFactory !== null) return ($this->clientFactory)($accountId);
        return new YandexWebmasterClient($accountId);
    }

    /**
     * Один тик ожидания host_id.
     *
     * @param array  $job       свежая строка джобы (перечитана под lock)
     * @param int    $accountId WM-аккаунт
     * @param string $newDomain новый домен
     * @return array{result:string, host_id:?string, user_id:?string}
     */
    public function tick(array $job, int $accountId, string $newDomain, JobEventLogger $log): array
    {
        $jobId = (int)$job['id'];
        $out = ['result' => 'waiting', 'host_id' => null, 'user_id' => null];

        if (JobLifecycleService::isTerminal((string)$job['stage'])) {
            $out['result'] = 'terminal';
            return $out;
        }

        $arts = json_decode((string)($job['artifacts_json'] ?? ''), true) ?: [];
        $stage = $arts['wm_added_stage'] ?? [];
        $expectedHostUrl = 'https://' . $newDomain . ':443';

        // Уже готово (host_id получен ранее).
        if (!empty($stage['host_id']) && !empty($stage['ok'])) {
            $out['result'] = 'ready';
            $out['host_id'] = (string)$stage['host_id'];
            $out['user_id'] = (string)($stage['user_id'] ?? '');
            return $out;
        }

        // v25.0-b1.1 (Блокер 1): окно timeout стартует ДО первого обращения к
        // API. Иначе, если getUserId() падает на самом первом тике (протух
        // токен в начале wm_added), poll_started_unix никогда не запишется —
        // и общий timeout не сработает (вечный poll). Инициализируем окно
        // синхронно, до try, чтобы часы шли независимо от здоровья API.
        if (empty($stage['poll_started_unix'])) {
            $stage['poll_started_unix'] = time();
            $stage['poll_started_at'] = date('Y-m-d H:i:s');
            $stage['account_id'] = $accountId;
            $stage['add_sent'] = false;
            $stage['checks'] = 0;
            $this->saveStage($jobId, $stage);
            $log->info('wm_added',
                "Ожидание регистрации host {$expectedHostUrl} в аккаунте #{$accountId} "
                . "(timeout " . self::timeoutMinutes() . " мин).");
        }

        // Единая проверка общего timeout — работает и когда API стабильно падает.
        $timedOut = (time() - (int)$stage['poll_started_unix']) >= self::timeoutMinutes() * 60;

        try {
            $client = $this->makeClient($accountId);
            // revision 2 §8/§19: job/stage context для аудита + routing_selected/verified.
            if (is_object($client) && method_exists($client, 'setRequestContext')) {
                try { $client->setRequestContext($jobId, 'wm_added', $log); } catch (\Throwable $ctxE) { /* ignore */ }
            }
            $userId = $client->getUserId();
            $out['user_id'] = $userId;
            if (empty($stage['user_id'])) { $stage['user_id'] = $userId; $this->saveStage($jobId, $stage); }

            // 1) Уже есть в аккаунте? ТОЧНОЕ совпадение scheme+host+port.
            $host = $client->findHostExact($userId, $expectedHostUrl);
            if ($host !== null && !empty($host['host_id'])) {
                return $this->finish($jobId, $stage, $accountId, $userId, (string)$host['host_id'], $newDomain, $log, $out);
            }

            // 2) Отправить addHost ОДИН раз (с классификацией ошибок).
            if (empty($stage['add_sent'])) {
                $log->info('wm_added', "Отправляю addHost: {$expectedHostUrl}");
                try {
                    $res = $client->addHost($userId, $expectedHostUrl);
                    // candidate host_id из ответа — подтвердим перечитыванием.
                    if (!empty($res['host_id'])) {
                        $stage['candidate_host_id'] = (string)$res['host_id'];
                    }
                } catch (\Throwable $e) {
                    // revision 2 §7/§8: critical routing failure НЕ проглатываем как temporary.
                    if (WebmasterRoutingFailurePolicy::isCritical($e)) throw $e;
                    $cls = $this->classifyAddHostError($e);
                    if ($cls === 'account_fatal' || $cls === 'invalid_host') {
                        $log->error('wm_added',
                            "addHost: постоянная ошибка ({$cls}) — в ожидание оператора: " . $e->getMessage());
                        $this->awaitUser($jobId,
                            "wm_added: addHost вернул постоянную ошибку ({$cls}): " . $e->getMessage()
                            . ". Проверьте аккаунт/домен вручную.");
                        $out['result'] = 'awaiting_user';
                        return $out;
                    }
                    // already_added_or_ambiguous / temporary — продолжаем polling.
                    $log->warn('wm_added',
                        "addHost вернул неоднозначную/временную ошибку (продолжаю ожидание): " . $e->getMessage());
                }
                $stage['add_sent'] = true;
                $stage['add_sent_at'] = date('Y-m-d H:i:s');
                $this->saveStage($jobId, $stage);
            }

            // 3) Timeout после успешного цикла?
            if ($timedOut) {
                $this->handleTimeout($jobId, $newDomain, $log);
                $out['result'] = 'awaiting_user';
                return $out;
            }

            // 4) Ещё ждём — планируем следующий тик.
            $stage['checks'] = (int)($stage['checks'] ?? 0) + 1;
            $this->saveStage($jobId, $stage);
            $this->scheduleNext($jobId, self::intervalSec());
            $out['result'] = 'waiting';
            return $out;

        } catch (\Throwable $e) {
            // revision 2 §7/§8: critical routing failure (mismatch/bind/resolve/redirect) —
            // НЕ обычный polling retry: пробрасываем в runWmAddedStage → stopIfWmRoutingFatal.
            if (WebmasterRoutingFailurePolicy::isCritical($e)) throw $e;
            // v25.0-b1 (B2): даже при постоянном сбое API проверяем общий timeout.
            if ($timedOut) {
                $log->warn('wm_added', 'API стабильно недоступен и истёк общий timeout — в ожидание оператора.');
                $this->handleTimeout($jobId, $newDomain, $log);
                $out['result'] = 'awaiting_user';
                return $out;
            }
            $log->warn('wm_added', 'Ошибка опроса hosts (повтор позже): ' . $e->getMessage());
            $this->scheduleNext($jobId, self::intervalSec());
            $out['result'] = 'waiting';
            return $out;
        }
    }

    /**
     * v25.0-b1 (B2): классификация ошибки addHost.
     * @return string already_added_or_ambiguous | temporary_api_error | account_fatal | invalid_host
     */
    private function classifyAddHostError(\Throwable $e): string
    {
        $m = strtolower($e->getMessage());
        // Уже добавлен — допустимо продолжать polling.
        if (strpos($m, 'already') !== false || strpos($m, 'host_already') !== false) {
            return 'already_added_or_ambiguous';
        }
        // Аккаунт/аутентификация — фатально.
        if (strpos($m, '401') !== false || strpos($m, '403') !== false
            || strpos($m, 'unauthorized') !== false || strpos($m, 'forbidden') !== false
            || strpos($m, 'invalid_oauth') !== false || strpos($m, 'access denied') !== false
            || strpos($m, 'user not found') !== false || strpos($m, 'limit') !== false) {
            return 'account_fatal';
        }
        // Некорректный host.
        if (strpos($m, 'invalid') !== false && (strpos($m, 'host') !== false || strpos($m, 'url') !== false)) {
            return 'invalid_host';
        }
        if (strpos($m, '400') !== false) return 'invalid_host';
        // Таймаут/5xx/сеть — временная.
        return 'temporary_api_error';
    }

    private function handleTimeout(int $jobId, string $newDomain, JobEventLogger $log): void
    {
        $log->warn('wm_added',
            "Host {$newDomain} не появился в аккаунте за " . self::timeoutMinutes()
            . " мин. Перевод в ожидание оператора (addHost повторно НЕ шлём).");
        $this->awaitUser($jobId,
            "wm_added: host {$newDomain} не зарегистрирован Яндексом за "
            . self::timeoutMinutes() . " мин. Проверьте вручную или продолжите ожидание.");
    }

    /** Ручное подтверждение host_id оператором (аварийное). */
    public function manualConfirm(int $jobId, int $accountId, string $userId, string $hostId, string $newDomain, string $operator, string $comment, JobEventLogger $log): void
    {
        $arts = json_decode((string)(($this->reload($jobId)['artifacts_json']) ?? ''), true) ?: [];
        $stage = $arts['wm_added_stage'] ?? [];
        $stage['manual_confirm'] = [
            'by' => $operator, 'at' => date('Y-m-d H:i:s'), 'comment' => $comment,
        ];
        $out = ['result' => 'waiting', 'host_id' => null, 'user_id' => null];
        $this->finish($jobId, $stage, $accountId, $userId, $hostId, $newDomain, $log, $out, true);
        $log->warn('wm_added', "Host_id подтверждён ВРУЧНУЮ оператором {$operator}: {$hostId}. Причина: {$comment}");
    }

    /* ==================== внутреннее ==================== */

    private function finish(int $jobId, array $stage, int $accountId, string $userId, string $hostId, string $newDomain, JobEventLogger $log, array $out, bool $manual = false): array
    {
        // Кешируем связь.
        try {
            (new SiteWebmasterMappingService())->updateLink(
                (int)($this->reload($jobId)['site_id'] ?? 0), $newDomain,
                ['user_id' => $userId, 'host_id' => $hostId]
            );
        } catch (\Throwable $e) {
            $log->warn('wm_added', 'updateLink failed: ' . $e->getMessage());
        }

        $stage['ok'] = true;
        $stage['account_id'] = $accountId;
        $stage['user_id'] = $userId;
        $stage['host_id'] = $hostId;
        $stage['host_url'] = 'https://' . $newDomain . ':443';
        $stage['confirmed_at'] = date('Y-m-d H:i:s');
        if ($manual) $stage['confirmed_manually'] = true;

        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage_status = 'ok',
                stage_finished_at = NOW(),
                next_run_at = NULL,
                artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
             WHERE id = ?
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        );
        $st->execute([
            json_encode(['wm_added_stage' => $stage], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            $jobId,
        ]);

        $log->ok('wm_added', "✓ Host зарегистрирован: account #{$accountId}, host_id={$hostId}");
        $out['result'] = 'ready';
        $out['host_id'] = $hostId;
        $out['user_id'] = $userId;
        return $out;
    }

    private function saveStage(int $jobId, array $stage): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
             WHERE id = ?
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([
            json_encode(['wm_added_stage' => $stage], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            $jobId,
        ]);
    }

    private function scheduleNext(int $jobId, int $sec): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage_status = 'pending',
                next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
             WHERE id = ?
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([max(5, $sec), $jobId]);
    }

    private function awaitUser(int $jobId, string $reason): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage_status = 'awaiting_user',
                stage_error = ?,
                next_run_at = NULL
             WHERE id = ?
               AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([mb_substr($reason, 0, 1000), $jobId]);
    }

    private function reload(int $jobId): array
    {
        $st = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE id=?");
        $st->execute([$jobId]);
        return $st->fetch() ?: [];
    }
}
