<?php

/**
 * Проверка SSL-сертификата на домене через прямое TLS-подключение к :443.
 *
 * Используется в стадии ssl_le_polling чтобы понять надо ли продолжать
 * polling или cert уже есть (например DDoS-Guard сам выпустил, или LE
 * выпустился асинхронно после нашего timeout).
 *
 * Адаптировано из hub::SslCheckService — упрощённая версия только с
 * проверкой через TLS-handshake.
 */
class SslLiveCheckService
{
    /**
     * Проверяет TLS на домене.
     *
     * @return array {
     *   ok: bool,             // true если есть валидный сертификат
     *   reason: string,       // 'live'|'self_signed'|'mismatch'|'no_cert'|'connect_failed'
     *   issuer: ?string,      // CN issuer'а — например "Let's Encrypt R3", "DDoS-Guard"
     *   subject: ?string,
     *   expires_at: ?string,  // YYYY-MM-DD HH:MM:SS
     *   match_name: ?string,  // если не совпадает с host — null
     *   error: ?string,
     *   is_self_signed: bool, // true если cert self-signed
     *   is_letsencrypt: bool,
     *   is_ddos_guard: bool,
     *   is_cloudflare: bool,
     * }
     */
    public function checkDomain(string $domain): array
    {
        $domain = trim($domain);
        if ($domain === '') {
            return $this->errorResult('empty domain');
        }

        $ctx = stream_context_create([
            'ssl' => [
                'capture_peer_cert' => true,
                'verify_peer' => false,
                'verify_peer_name' => false,
                'SNI_enabled' => true,
                'SNI_server_name' => $domain,
                'peer_name' => $domain,
                'allow_self_signed' => true,
            ],
        ]);

        $errno = 0;
        $errstr = '';
        $client = @stream_socket_client(
            'ssl://' . $domain . ':443',
            $errno,
            $errstr,
            10,
            STREAM_CLIENT_CONNECT,
            $ctx
        );

        if (!$client) {
            return $this->errorResult("ssl connect failed: {$errno} {$errstr}", 'connect_failed');
        }

        $params = stream_context_get_params($client);
        @fclose($client);

        $cert = $params['options']['ssl']['peer_certificate'] ?? null;
        if (!$cert) {
            return $this->errorResult('peer_certificate missing', 'no_cert');
        }

        $info = openssl_x509_parse($cert);
        if (!is_array($info)) {
            return $this->errorResult('cannot parse certificate', 'no_cert');
        }

        $expiresAt = isset($info['validTo_time_t'])
            ? date('Y-m-d H:i:s', (int)$info['validTo_time_t'])
            : null;
        $issuer = $this->dnToString($info['issuer'] ?? null);
        $subject = $this->dnToString($info['subject'] ?? null);

        $matchName = $this->certificateMatchedName($domain, $info);

        $isSelfSigned = $issuer !== null && $subject !== null
            && trim((string)$issuer) === trim((string)$subject);

        $issuerLower = strtolower((string)$issuer);
        $isLetsEncrypt = strpos($issuerLower, "let's encrypt") !== false
                      || strpos($issuerLower, 'letsencrypt') !== false
                      || strpos($issuerLower, 'r3') !== false
                      || strpos($issuerLower, 'r10') !== false
                      || strpos($issuerLower, 'r11') !== false
                      || strpos($issuerLower, 'e1') !== false
                      || strpos($issuerLower, 'isrg') !== false;
        $isDdosGuard = strpos($issuerLower, 'ddos-guard') !== false
                    || strpos($issuerLower, 'ddosguard') !== false;
        $isCloudflare = strpos($issuerLower, 'cloudflare') !== false;

        if ($matchName === '') {
            return [
                'ok' => false,
                'reason' => 'mismatch',
                'issuer' => $issuer,
                'subject' => $subject,
                'expires_at' => $expiresAt,
                'match_name' => null,
                'error' => "certificate does not match host {$domain}",
                'is_self_signed' => $isSelfSigned,
                'is_letsencrypt' => $isLetsEncrypt,
                'is_ddos_guard' => $isDdosGuard,
                'is_cloudflare' => $isCloudflare,
            ];
        }

        if ($isSelfSigned) {
            return [
                'ok' => false,
                'reason' => 'self_signed',
                'issuer' => $issuer,
                'subject' => $subject,
                'expires_at' => $expiresAt,
                'match_name' => $matchName,
                'error' => null,
                'is_self_signed' => true,
                'is_letsencrypt' => false,
                'is_ddos_guard' => false,
                'is_cloudflare' => false,
            ];
        }

        return [
            'ok' => true,
            'reason' => 'live',
            'issuer' => $issuer,
            'subject' => $subject,
            'expires_at' => $expiresAt,
            'match_name' => $matchName,
            'error' => null,
            'is_self_signed' => false,
            'is_letsencrypt' => $isLetsEncrypt,
            'is_ddos_guard' => $isDdosGuard,
            'is_cloudflare' => $isCloudflare,
        ];
    }

    private function errorResult(string $msg, string $reason = 'connect_failed'): array
    {
        return [
            'ok' => false,
            'reason' => $reason,
            'issuer' => null,
            'subject' => null,
            'expires_at' => null,
            'match_name' => null,
            'error' => $msg,
            'is_self_signed' => false,
            'is_letsencrypt' => false,
            'is_ddos_guard' => false,
            'is_cloudflare' => false,
        ];
    }

    private function certificateMatchedName(string $host, array $info): string
    {
        $host = strtolower(trim($host));
        if ($host === '') return '';

        // CN
        $subject = $info['subject'] ?? [];
        $cn = '';
        if (is_array($subject) && isset($subject['CN'])) {
            $cn = strtolower(trim((string)$subject['CN']));
        }

        // SANs
        $sans = [];
        $extensions = $info['extensions'] ?? [];
        if (isset($extensions['subjectAltName'])) {
            foreach (explode(',', (string)$extensions['subjectAltName']) as $part) {
                $part = trim($part);
                if (stripos($part, 'DNS:') === 0) {
                    $sans[] = strtolower(trim(substr($part, 4)));
                }
            }
        }

        $candidates = array_unique(array_merge([$cn], $sans));

        foreach ($candidates as $pattern) {
            if ($pattern === '') continue;
            if ($this->hostMatchesPattern($host, $pattern)) {
                return $pattern;
            }
        }
        return '';
    }

    private function hostMatchesPattern(string $host, string $pattern): bool
    {
        if ($host === $pattern) return true;
        // Wildcard
        if (strpos($pattern, '*.') === 0) {
            $base = substr($pattern, 2);
            $hostParts = explode('.', $host);
            if (count($hostParts) >= 2) {
                $hostBase = implode('.', array_slice($hostParts, 1));
                return $hostBase === $base;
            }
        }
        return false;
    }

    private function dnToString($dn): ?string
    {
        if (!is_array($dn)) return null;
        $parts = [];
        foreach ($dn as $k => $v) {
            if (is_array($v)) $v = implode(',', $v);
            $parts[] = "{$k}={$v}";
        }
        return implode(', ', $parts);
    }
}
