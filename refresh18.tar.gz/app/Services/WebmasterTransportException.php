<?php

/**
 * PATCH 047 §49 — типизированное исключение единого Yandex.Webmaster transport.
 *
 * reason ∈ {bind_failed, source_ip_mismatch, network_timeout, http_error, unexpected_redirect,
 *           resolve_failed}. Позволяет JobEventPresenter/DiagnosticCatalog дать нормальное
 *           русское объяснение без regex по строке. Network-метаданные НЕ теряются (§48):
 *           к исключению прикреплён структурированный результат transport ($result).
 */
class WebmasterTransportException extends \RuntimeException
{
    public const BIND_FAILED         = 'bind_failed';
    public const SOURCE_IP_MISMATCH  = 'source_ip_mismatch';
    public const NETWORK_TIMEOUT     = 'network_timeout';
    public const HTTP_ERROR          = 'http_error';
    public const UNEXPECTED_REDIRECT = 'unexpected_redirect';
    public const RESOLVE_FAILED      = 'resolve_failed';

    /** @var string */
    private $reason;
    /** @var array structured transport result (§48) — не терять network metadata */
    private $result;

    public function __construct(string $reason, string $message, array $result = [], ?\Throwable $prev = null)
    {
        parent::__construct($message, 0, $prev);
        $this->reason = $reason;
        $this->result = $result;
    }

    public function getReason(): string
    {
        return $this->reason;
    }

    /** @return array structured result: expected/actual/remote/http_code/curl_errno/request_uid/... */
    public function getResult(): array
    {
        return $this->result;
    }
}
