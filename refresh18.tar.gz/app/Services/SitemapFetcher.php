<?php

/**
 * v18: SitemapFetcher
 *
 * Скачивает sitemap.xml/sitemap.php с указанного домена и парсит из него
 * URL'ы (теги <loc>...</loc>).
 *
 * Использует HTTP, а не FTP — потому что sitemap у нас часто генерируется
 * динамически из sitemap.php, и парсить PHP-исходник смысла нет, нужен
 * результат. Все наши сайты на момент вызова уже имеют LE SSL и принимают
 * HTTPS-запросы.
 *
 * Никаких зависимостей кроме curl (как остальные сервисы).
 *
 * Используется в стадии old_delurl_notify как fallback, если в
 * replacement_plan нашлось мало URL'ов.
 */
class SitemapFetcher
{
    /** @var int Curl timeout, секунд */
    private int $timeoutSec;

    public function __construct(int $timeoutSec = 30)
    {
        $this->timeoutSec = $timeoutSec;
    }

    /**
     * Скачать sitemap и вернуть массив URL'ов.
     *
     * Пробует несколько стандартных путей (sitemap.xml, sitemap.php,
     * sitemap_index.xml) — возвращает первый который вернул валидный XML.
     *
     * @param string $domain Например "volna-205.casino" (без схемы и слеша)
     * @return array{urls: string[], source_url: string, http_code: int, raw_size: int, error: ?string}
     */
    public function fetchByDomain(string $domain): array
    {
        $domain = trim($domain, " /\t\r\n");
        $candidates = [
            "https://{$domain}/sitemap.xml",
            "https://{$domain}/sitemap.php",
            "https://{$domain}/sitemap_index.xml",
        ];

        $lastError = null;
        $lastHttpCode = 0;
        $lastSourceUrl = '';

        foreach ($candidates as $url) {
            [$body, $code, $err] = $this->httpGet($url);
            $lastSourceUrl = $url;
            $lastHttpCode = $code;

            if ($err !== null) {
                $lastError = $err;
                continue;
            }
            if ($code !== 200 || $body === '' || $body === false) {
                $lastError = "HTTP {$code}";
                continue;
            }

            $urls = $this->extractLocs($body);
            if (!empty($urls)) {
                return [
                    'urls' => $urls,
                    'source_url' => $url,
                    'http_code' => $code,
                    'raw_size' => strlen($body),
                    'error' => null,
                ];
            }

            // 200, но XML пустой или не sitemap — пробуем следующий
            $lastError = 'no <loc> tags found';
        }

        return [
            'urls' => [],
            'source_url' => $lastSourceUrl,
            'http_code' => $lastHttpCode,
            'raw_size' => 0,
            'error' => $lastError ?? 'unknown',
        ];
    }

    /**
     * Извлечь все URL'ы из <loc>...</loc> тегов.
     *
     * Регексп простой и устойчивый — не используем XML-парсер потому что
     * sitemap.php нередко возвращает невалидный или неполный XML, а нам
     * нужно вытащить максимум из того что есть.
     *
     * @return string[]
     */
    public function extractLocs(string $xml): array
    {
        if ($xml === '') return [];
        $matches = [];
        // Примеры: <loc>https://x.com/page</loc>, <loc> https://x.com </loc>
        if (!preg_match_all('~<loc[^>]*>\s*([^<\s][^<]*?)\s*</loc>~i', $xml, $matches)) {
            return [];
        }
        $urls = [];
        foreach ($matches[1] as $u) {
            $u = html_entity_decode(trim($u), ENT_QUOTES | ENT_XML1, 'UTF-8');
            if ($u !== '' && (strpos($u, 'http://') === 0 || strpos($u, 'https://') === 0)) {
                $urls[] = $u;
            }
        }
        // Дедуплицируем
        return array_values(array_unique($urls));
    }

    /**
     * Заменить домен в каждом URL списка.
     *
     * Используется когда мы получили sitemap нового домена и хотим
     * получить эквивалентные URL'ы старого домена для отправки в del-url.
     *
     * @param string[] $urls
     * @return string[]
     */
    public function rewriteDomain(array $urls, string $fromDomain, string $toDomain): array
    {
        $out = [];
        // v18-fix CRITICAL: используем preg_replace_callback вместо preg_replace
        // с backreference в строке.
        //
        // Контекст: и '$1' и '\1' в строке ЗАМЕНЫ — амбивалентны если ПОСЛЕ них
        // идёт цифра. Например для $toDomain='7k5212.casino':
        //   '$1' . '7k5212.casino' = '$17k5212.casino' = backreference 17 (нет → '')
        //   '\1' . '7k5212.casino' = '\17k5212.casino' = тоже backreference 17
        //
        // Реальный баг проявился на джобе #12 (7k5212→7k5213): URL
        // 'https://7k5213.casino/' переписался в 'k5212.casino/' вместо
        // 'https://7k5212.casino/'. Префикс 'https://7' был отрезан.
        //
        // Решение: callback не использует строковую интерполяцию backreferences,
        // получает $matches[1] как обычный аргумент → конкатенация безопасна.
        //
        // Альтернатива '${1}' тоже работает, но callback явнее и не зависит от
        // PHP-версии (в PHP 8+ '${1}' deprecated в double-quoted strings).
        $regex = '~^(https?://)' . preg_quote($fromDomain, '~') . '(?=/|:|$)~i';
        foreach ($urls as $u) {
            $rewritten = preg_replace_callback($regex, function ($m) use ($toDomain) {
                return $m[1] . $toDomain;
            }, $u, 1);
            if ($rewritten !== null && $rewritten !== '') {
                $out[] = $rewritten;
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * Простой curl GET.
     *
     * @return array{0: string|false, 1: int, 2: ?string} [body, http_code, error_message]
     */
    private function httpGet(string $url): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => $this->timeoutSec,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false, // self-signed может быть в любой момент
            CURLOPT_SSL_VERIFYHOST => 0,
            // v18.1.10: yandex UA — см. комментарий выше про 1win шаблоны
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) refresh-panel-sitemap',
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        return [$body, $code, $err !== '' ? $err : null];
    }
}
