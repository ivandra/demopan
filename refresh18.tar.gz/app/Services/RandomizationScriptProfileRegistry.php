<?php
/**
 * ТЗ 039 v4 §8.2: реестр известных профилей скриптов рандомизации.
 *
 * Для автоматически найденного update_classes.php инспектор определяет
 * КОНКРЕТНОЕ семейство по имени файла + минимум двум независимым структурным
 * сигнатурам (не по маркеру ответа). Каждому семейству соответствует РОВНО
 * ОДИН точный completion-marker. Общий список маркеров (classic) удалён —
 * ответ одного семейства не должен подтверждать успех другого.
 *
 * Сигнатуры — реальные устойчивые фрагменты из поддерживаемых скриптов
 * (fixtures/sites/{7k2500,r7,irvin}/update_classes.php):
 *   7k    — split mobile/desktop, templates/2, generateNewFileName + ___<hex8>;
 *   r7    — templates/r7, updateClassNameMapping, update_classes.log;
 *   irvin — image-first: generateImageSuffix, renameImagesAlways, replaceImagesInCss.
 */
final class RandomizationScriptProfileRegistry
{
    /**
     * @return array<int,array{family:string,script:string,required_signatures:array<int,string>,completion_marker:string}>
     */
    public function profiles(): array
    {
        return [
            [
                'family' => '7k',
                'script' => 'update_classes.php',
                'required_signatures' => [
                    'updateClassMappings',      // уникальное имя функции 7k
                    'generateNewFileName',      // 7k переименовывает файлы (___<hex8>)
                    'mobilePath',               // split mobile/desktop
                    'templates/2',              // путь шаблонов 7k
                ],
                'min_signatures' => 2,
                'completion_marker' => 'Update process completed.',
                'completion_contract' => 'exact_marker',
                'verification_strategy' => 'class_mapping',
            ],
            [
                'family' => 'r7',
                'script' => 'update_classes.php',
                'required_signatures' => [
                    'updateClassNameMapping',   // r7: ClassName (не ClassMappings)
                    'templates/r7',             // путь шаблонов r7
                    'update_classes.log',       // r7 пишет собственный лог
                ],
                'min_signatures' => 2,
                'completion_marker' => 'Скрипт успешно выполнен!',
                'completion_contract' => 'exact_marker',
                'verification_strategy' => 'class_mapping',
            ],
            [
                'family' => 'irvin',
                'script' => 'update_classes.php',
                'required_signatures' => [
                    'generateImageSuffix',      // irvin работает с картинками
                    'renameImagesAlways',
                    'replaceImagesInCss',
                    'processPhpFiles',
                ],
                'min_signatures' => 2,
                'completion_marker' => '✅ Готово.',
                'completion_contract' => 'exact_marker',
                'verification_strategy' => 'class_mapping',
            ],
            // HOTPATCH §5.1: новая JSON split-версия. Контракт ответа = json_ok_true,
            // но verification_strategy = СУЩЕСТВУЮЩИЙ class_mapping (НЕ новая стратегия).
            [
                'family' => '7k_json_split_v2',
                'script' => 'update_classes.php',
                'required_signatures' => [
                    't2_refresh_publish_device',
                    't2_refresh_rollback_devices',
                    'class_name_mapping_',
                    '.update-classes.lock',
                    't2_refresh_respond(200',
                ],
                'mandatory_signatures' => [
                    't2_refresh_publish_device',
                    't2_refresh_rollback_devices',
                    'class_name_mapping_',
                ],
                'min_signatures' => 4,
                'completion_contract' => 'json_ok_true',
                'completion_marker' => null,
                'verification_strategy' => 'class_mapping',
            ],
        ];
    }

    /**
     * Определить семейство по содержимому файла.
     * @return array{status:string,family?:string,marker?:string,matched?:array<int,string>,fingerprint?:string,conflicts?:array<int,string>}
     *   status: supported | needs_review | conflict
     */
    public function detect(string $fileContent): array
    {
        $fingerprint = hash('sha256', $fileContent);
        $matchedProfiles = [];
        $matchedSignaturesByFamily = [];

        foreach ($this->profiles() as $profile) {
            $hits = [];
            foreach ($profile['required_signatures'] as $sig) {
                if (strpos($fileContent, $sig) !== false) {
                    $hits[] = $sig;
                }
            }
            $need = (int)($profile['min_signatures'] ?? 2);
            if (count($hits) < $need) { continue; }
            // §5.1: обязательные структурные признаки должны присутствовать ВСЕ.
            $mandatoryOk = true;
            foreach (($profile['mandatory_signatures'] ?? []) as $ms) {
                if (strpos($fileContent, $ms) === false) { $mandatoryOk = false; break; }
            }
            if (!$mandatoryOk) { continue; }
            $matchedProfiles[] = $profile;
            $matchedSignaturesByFamily[$profile['family']] = $hits;
        }

        if (count($matchedProfiles) === 1) {
            $p = $matchedProfiles[0];
            $contract = (string)($p['completion_contract'] ?? 'exact_marker');
            return [
                'status' => 'supported',
                'family' => $p['family'],
                'contract' => $contract,
                'marker' => $contract === 'exact_marker' ? ($p['completion_marker'] ?? null) : null,
                'verification_strategy' => (string)($p['verification_strategy'] ?? 'class_mapping'),
                'matched' => $matchedSignaturesByFamily[$p['family']],
                'fingerprint' => $fingerprint,
            ];
        }
        if (count($matchedProfiles) >= 2) {
            return [
                'status' => 'conflict',
                'conflicts' => array_map(static fn($p) => $p['family'], $matchedProfiles),
                'fingerprint' => $fingerprint,
            ];
        }
        return ['status' => 'needs_review', 'fingerprint' => $fingerprint];
    }

    /** §5.2/§5.3: валидация целостности реестра. */
    public function validateRegistry(): array
    {
        $errors = []; $seen = [];
        foreach ($this->profiles() as $i => $p) {
            $fam = (string)($p['family'] ?? '');
            if ($fam === '') { $errors[] = "profile#$i: empty family"; continue; }
            if (isset($seen[$fam])) $errors[] = "family not unique: $fam";
            $seen[$fam] = true;
            $c = (string)($p['completion_contract'] ?? 'exact_marker');
            if (!in_array($c, ['exact_marker','json_ok_true'], true)) $errors[] = "$fam: bad contract $c";
            if ($c === 'exact_marker' && trim((string)($p['completion_marker'] ?? '')) === '') $errors[] = "$fam: exact_marker needs marker";
            if ($c === 'json_ok_true' && ($p['completion_marker'] ?? null) !== null) $errors[] = "$fam: json_ok_true must not carry marker";
            $vs = (string)($p['verification_strategy'] ?? '');
            if (!in_array($vs, ['class_mapping'], true)) $errors[] = "$fam: verification_strategy must be class_mapping in hotpatch (got $vs)";
            if ((int)($p['min_signatures'] ?? 0) < 2) $errors[] = "$fam: min_signatures>=2";
        }
        return $errors;
    }
}
