<?php

/**
 * Сервис управления алиасами сайта в FastPanel.
 *
 * Используется на стадии 'aliases_added' оркестратора перевыставления.
 *
 * Что делает:
 *  - Авторизуется в FastPanel API
 *  - Читает текущие алиасы сайта
 *  - Добавляет новые (без удаления старых)
 *  - Сохраняет результат в sites_managed.aliases
 *  - Возвращает диф в artifacts_json (что было / что стало / что добавлено)
 *
 * Использование:
 *   $svc = new AliasService();
 *   $result = $svc->addAliases($siteId, ['volna-203.casino', 'www.volna-203.casino'], $log);
 *
 * Возвращает:
 *   [
 *     'ok' => true,
 *     'aliases_before' => ['www.volna-202.casino'],
 *     'aliases_after' => ['www.volna-202.casino', 'volna-203.casino', 'www.volna-203.casino'],
 *     'aliases_added' => ['volna-203.casino', 'www.volna-203.casino'],
 *     'aliases_already_existed' => [],
 *   ]
 *
 * Или при ошибке:
 *   ['ok' => false, 'reason' => '...']
 */
class AliasService
{
    /**
     * Добавить домены в список алиасов сайта.
     *
     * @param int $siteId id из sites_managed
     * @param array $newDomains список FQDN для добавления (например ['volna-203.casino', 'www.volna-203.casino'])
     * @param JobEventLogger $log логгер для записи событий стадии
     * @return array результат
     */
    public function addAliases(int $siteId, array $newDomains, JobEventLogger $log): array
    {
        // 1. Загружаем сайт
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'reason' => "Site #{$siteId} not found"];
        }

        $serverId = (int)($site['fastpanel_server_id'] ?? 0);
        $fpSiteId = (int)($site['fp_site_id'] ?? 0);
        if ($serverId <= 0 || $fpSiteId <= 0) {
            return ['ok' => false, 'reason' => "Site has no fp_site_id or fastpanel_server_id"];
        }

        // 2. Нормализуем входящие домены
        $newDomainsNormalized = [];
        foreach ($newDomains as $d) {
            $d = strtolower(trim((string)$d));
            if ($d !== '') {
                $newDomainsNormalized[$d] = true;
            }
        }
        if (empty($newDomainsNormalized)) {
            return ['ok' => false, 'reason' => 'No new domains provided'];
        }

        $log->info('aliases_added',
            'Добавляю в FP алиасы: ' . implode(', ', array_keys($newDomainsNormalized)));

        // 3. Авторизуемся в FastPanel
        try {
            $fp = $this->makeFastpanelClient($serverId);
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => 'FP login failed: ' . $e->getMessage()];
        }

        // 4. Читаем текущий список алиасов
        $existingAliases = [];
        try {
            $detail = $fp->site($fpSiteId);
            $existingAliases = $this->extractAliases($detail);
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => 'Could not read site detail: ' . $e->getMessage()];
        }

        $log->info('aliases_added',
            'Текущие алиасы (' . count($existingAliases) . '): ' .
            (empty($existingAliases) ? '— нет —' : implode(', ', $existingAliases)));

        // 5. Вычисляем что реально нужно добавить (а что уже было)
        $existingMap = array_flip(array_map('strtolower', $existingAliases));
        $toAdd = [];
        $alreadyExisted = [];
        foreach (array_keys($newDomainsNormalized) as $d) {
            if (isset($existingMap[$d])) {
                $alreadyExisted[] = $d;
            } else {
                $toAdd[] = $d;
            }
        }

        if (!empty($alreadyExisted)) {
            $log->warn('aliases_added',
                'Уже есть в алиасах: ' . implode(', ', $alreadyExisted));
        }

        // 6. Если все домены уже есть — короткое замыкание
        if (empty($toAdd)) {
            $log->ok('aliases_added',
                'Все требуемые алиасы уже на месте, ничего добавлять не нужно');
            return [
                'ok' => true,
                'aliases_before' => $existingAliases,
                'aliases_after' => $existingAliases,
                'aliases_added' => [],
                'aliases_already_existed' => $alreadyExisted,
            ];
        }

        // 7. Добавляем
        try {
            // addSiteAliases сам делает merge со существующими.
            // Возвращает обновлённый объект сайта.
            $updated = $fp->addSiteAliases($fpSiteId, $toAdd);
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => 'FP addSiteAliases failed: ' . $e->getMessage()];
        }

        // 8. Перечитываем актуальный список (после updateSite)
        $afterAliases = $this->extractAliases($updated);
        if (empty($afterAliases)) {
            // updateSite иногда не возвращает aliases в response — перечитаем явно
            try {
                $detail = $fp->site($fpSiteId);
                $afterAliases = $this->extractAliases($detail);
            } catch (\Throwable $e) {
                // не страшно — у нас уже есть toAdd для отчёта
            }
        }

        // 9. Сохраняем в БД
        try {
            $st = DB::pdo()->prepare(
                "UPDATE sites_managed SET aliases = ? WHERE id = ?"
            );
            $st->execute([
                json_encode($afterAliases, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $siteId,
            ]);
        } catch (\Throwable $e) {
            // FP-апдейт уже прошёл, в БД не записалось — это recoverable, но логируем
            $log->warn('aliases_added',
                'Алиас в FP добавлен, но в БД не сохранён: ' . $e->getMessage());
        }

        $log->ok('aliases_added',
            'Добавлено в FP: ' . implode(', ', $toAdd) .
            '. Всего алиасов теперь: ' . count($afterAliases));

        return [
            'ok' => true,
            'aliases_before' => $existingAliases,
            'aliases_after' => $afterAliases,
            'aliases_added' => $toAdd,
            'aliases_already_existed' => $alreadyExisted,
        ];
    }

    private function loadSite(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    private function makeFastpanelClient(int $serverId): FastpanelClient
    {
        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $st->execute([$serverId]);
        $server = $st->fetch();
        if (!$server) {
            throw new \RuntimeException("FastPanel server #{$serverId} not found");
        }

        $password = Crypto::decrypt((string)$server['password_enc']);
        $client = new FastpanelClient(
            (string)$server['host'],
            (bool)($server['verify_tls'] ?? false),
            (int)config('fastpanel.timeout', 30)
        );
        $client->login((string)$server['username'], $password);
        return $client;
    }

    /**
     * Извлекает список алиасов из FP-объекта сайта в виде ['name1', 'name2'].
     * FP возвращает их как [{name: 'foo.com'}, ...] но иногда плоско.
     */
    private function extractAliases(array $detail): array
    {
        $out = [];
        if (!isset($detail['aliases']) || !is_array($detail['aliases'])) {
            return $out;
        }
        foreach ($detail['aliases'] as $a) {
            if (is_array($a) && !empty($a['name'])) {
                $out[] = (string)$a['name'];
            } elseif (is_string($a) && $a !== '') {
                $out[] = $a;
            }
        }
        return $out;
    }
}
