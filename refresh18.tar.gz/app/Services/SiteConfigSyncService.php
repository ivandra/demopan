<?php

/**
 * Сервис чтения и записи config.php сайтов на VPS через FTP.
 *
 * Использует FTP-данные из карточки сайта (sites_managed: ftp_user, ftp_pass_enc, ftp_host).
 * Если их нет — кидает исключение.
 *
 * v12: multi-path стратегия для chroot'нутых FTP-юзеров. FastPanel при создании
 * FTP-аккаунта c home_dir = /var/www/owner/data/www/domain делает chroot, и
 * абсолютный путь /var/www/owner/data/www/domain/config.php виден FTP-юзеру
 * как /config.php (или просто config.php).
 */
class SiteConfigSyncService
{
    private SiteConfigParser $parser;
    private array $debugLog = [];

    public function __construct()
    {
        $this->parser = new SiteConfigParser();
    }

    /**
     * Записать сырое содержимое config.php на VPS (offset-writer). Делает .bak.
     * FTP-клиент можно подменить в тестах через makeFtp() (seam).
     */
    public function uploadConfigRaw(int $siteId, string $remotePath, string $content): array
    {
        $site = $this->loadSite($siteId);
        $ftp = $this->makeFtp($site);
        if ($remotePath === '') {
            $remotePath = trim((string)($site['config_remote_path'] ?? '')) ?: 'config.php';
        }
        try {
            $ftp->putContent($remotePath, $content, '.bak');
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage(), 'path' => $remotePath];
        }
        return ['ok' => true, 'path' => $remotePath, 'bytes' => strlen($content)];
    }

    /** Канонический одиночный upload target-файла (алиас uploadConfigRaw). */
    public function uploadRaw(int $siteId, string $remotePath, string $content): array
    {
        return $this->uploadConfigRaw($siteId, $remotePath, $content);
    }

    /**
     * Persist ПОСЛЕ подтверждённого read-back: snapshot + config_parsed_json +
     * current_domain в ОДНОЙ транзакции, с re-select подтверждением обеих записей.
     */
    public function persistVerified(int $siteId, string $remotePath, array $parsed, string $kind, string $raw, string $newDomain): array
    {
        $pdo = DB::pdo();
        $pdo->beginTransaction();
        try {
            $snapDir = Paths::storage('configs_snapshots');
            Paths::ensureDir($snapDir);
            @file_put_contents("{$snapDir}/site_{$siteId}_" . date('Ymd_His') . ".php.txt", $raw);

            $json = json_encode($parsed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $pdo->prepare("UPDATE sites_managed SET
                config_remote_path=?, config_parsed_json=?, config_template_kind=?,
                config_last_synced_at=UTC_TIMESTAMP(), current_domain=?
                WHERE id=?")->execute([$remotePath, $json, $kind, $newDomain, $siteId]);

            $chk = $pdo->prepare("SELECT config_parsed_json, current_domain FROM sites_managed WHERE id=?");
            $chk->execute([$siteId]);
            $row = $chk->fetch(PDO::FETCH_ASSOC) ?: [];
            if ((string)($row['current_domain'] ?? '') !== $newDomain
                || (string)($row['config_parsed_json'] ?? '') !== $json) {
                throw new RuntimeException('persist_reselect_mismatch');
            }
            $pdo->commit();
            // ТЗ 039 §7.1 (ревью P0#1): применимость рандомизации определяется
            // ПОСЛЕ коммита конфига (вне транзакции — инспектор пишет своим UPDATE).
            $this->inspectRandomization($siteId);
            return ['ok' => true];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            return ['ok' => false, 'reason' => 'snapshot_persist_failed', 'error' => $e->getMessage()];
        }
    }

    /**
     * Скачать config.php с VPS, распарсить, сохранить в БД.
     * = read-only fetch + persist. Обёртка сохранена для обратной совместимости.
     */
    public function syncFromVps(int $siteId): array
    {
        $r = $this->fetchFromVpsReadOnly($siteId);
        if (empty($r['ok'])) return $r;
        $this->persistSyncedConfig($siteId, (string)$r['path'], (array)$r['parsed'], (string)$r['kind'], (string)$r['raw']);
        return ['ok' => true, 'data' => $r['parsed'], 'kind' => $r['kind'], 'path' => $r['path'], 'raw' => $r['raw']];
    }

    /**
     * READ-ONLY получение config.php с VPS. НИЧЕГО не пишет (ни snapshot, ни БД,
     * ни import_log). Единый источник сырого config для analyze / TOCTOU /
     * read-back / fleet / remediation-dry-run.
     *
     * @return array ok|error + raw, path, sha256, parsed, kind
     */
    public function fetchFromVpsReadOnly(int $siteId): array
    {
        $this->debugLog = [];
        $site = $this->loadSite($siteId);
        $ftp = $this->makeFtp($site);

        try {
            $pwd = $ftp->pwd();
            $this->log("FTP connected. pwd='{$pwd}'");
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'FTP connect failed: ' . $e->getMessage()];
        }

        $candidates = $this->buildConfigPathCandidates($site);
        $content = null; $usedPath = '';
        foreach ($candidates as $p) {
            $r = $ftp->tryGetContent($p);
            if ($r !== null && $r !== '') { $content = $r; $usedPath = $p; break; }
        }
        if ($content === null) {
            return ['ok' => false, 'error' => 'FTP read failed: tried ' . count($candidates) . ' paths, none worked.', 'tried' => $candidates];
        }
        if (stripos($content, '<?php') === false) {
            return ['ok' => false, 'error' => 'config.php empty or not PHP', 'path' => $usedPath, 'raw' => $content];
        }
        try {
            $data = $this->parser->parse($content);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'parser exception: ' . $e->getMessage(), 'path' => $usedPath, 'raw' => $content];
        }
        $kind = $this->detectTemplateKind($data, $content);
        return [
            'ok' => true, 'raw' => $content, 'path' => $usedPath,
            'sha256' => hash('sha256', $content), 'parsed' => $data, 'kind' => $kind,
        ];
    }

    /**
     * Persist: snapshot + config_parsed_json/kind/last_synced_at. Вызывается ТОЛЬКО
     * после успешного semantic read-back (persist ≠ fetch).
     */
    public function persistSyncedConfig(int $siteId, string $usedPath, array $data, string $kind, string $content): void
    {
        $snapDir = Paths::storage('configs_snapshots');
        Paths::ensureDir($snapDir);
        @file_put_contents("{$snapDir}/site_{$siteId}_" . date('Ymd_His') . ".php.txt", $content);

        DB::pdo()->prepare("UPDATE sites_managed SET
            config_remote_path = ?,
            config_parsed_json = ?,
            config_template_kind = ?,
            config_last_synced_at = NOW()
            WHERE id = ?")->execute([
                $usedPath,
                json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $kind,
                $siteId,
            ]);

        // ТЗ 039 §7.1 (ревью P0#1): после успешного чтения live config.php —
        // сразу определить применимость рандомизации по FTP и сохранить в
        // sites_managed. Ошибка инспекции НЕ ломает sync: инспектор сам пишет
        // ftp_error (а не «скриптов нет»), поэтому поле не остаётся unknown.
        $this->inspectRandomization($siteId);
    }

    /**
     * Read-only инспекция рандомизации после import/sync. Не бросает наружу.
     * seam для тестов (переопределяемый инспектор).
     */
    protected function inspectRandomization(int $siteId): void
    {
        try {
            $this->makeRandomizationInspector()->inspectAndPersist($siteId);
        } catch (\Throwable $e) {
            // sync не должен падать из-за инспекции; сам инспектор уже записал
            // ftp_error при сбое FTP.
            $this->log('randomization inspect after sync failed: ' . $e->getMessage(), 'warn');
        }
    }

    protected function makeRandomizationInspector(): SiteRandomizationInspector
    {
        return new SiteRandomizationInspector();
    }

    /**
     * @deprecated внутренняя старая реализация syncFromVps сохранена ниже как _syncFromVpsLegacy
     *             на случай отладки; в проде используется новая пара fetch+persist.
     */
    private function _syncFromVpsLegacy(int $siteId): array
    {
        $this->debugLog = [];
        $site = $this->loadSite($siteId);
        $ftp = $this->makeFtp($site);

        // Проверим pwd чтобы понять, в чём оказался FTP-юзер
        try {
            $pwd = $ftp->pwd();
            $this->log("FTP connected. pwd='{$pwd}'");
        } catch (Throwable $e) {
            $err = 'FTP connect failed: ' . $e->getMessage();
            $this->log($err, 'error');
            $this->saveDebugLog($siteId);
            return ['ok' => false, 'error' => $err];
        }

        // Список путей-кандидатов. Порядок важен — chroot-сценарий идёт первым,
        // т.к. для FastPanel-FTP это норма.
        $candidates = $this->buildConfigPathCandidates($site);
        $this->log('Trying paths: ' . implode(', ', $candidates));

        $content = null;
        $usedPath = '';
        foreach ($candidates as $p) {
            $this->log("ftp_get('{$p}')");
            $r = $ftp->tryGetContent($p);
            if ($r !== null && $r !== '') {
                $content = $r;
                $usedPath = $p;
                $this->log("OK got " . strlen($r) . " bytes from '{$p}'", 'ok');
                break;
            }
            $this->log("failed for '{$p}'");
        }

        if ($content === null) {
            // Дополнительная диагностика — что вообще видно в корне FTP?
            $rootListing = [];
            try {
                $rootListing = $ftp->listDir('.');
            } catch (Throwable $e) {
                $this->log('listDir(.) failed: ' . $e->getMessage(), 'warn');
            }
            $this->log('Root listing: ' . (empty($rootListing) ? '(empty)' : implode(', ', array_slice($rootListing, 0, 30))));
            $this->saveDebugLog($siteId);
            return [
                'ok' => false,
                'error' => 'FTP read failed: tried ' . count($candidates) . ' paths, none worked. See diagnose page for details.',
                'tried' => $candidates,
                'pwd' => $pwd,
                'root_listing' => $rootListing,
            ];
        }

        if (stripos($content, '<?php') === false) {
            $this->log('content does not contain <?php', 'error');
            $this->saveDebugLog($siteId);
            return ['ok' => false, 'error' => 'config.php empty or not PHP', 'path' => $usedPath];
        }

        // Парсим
        try {
            $data = $this->parser->parse($content);
        } catch (Throwable $e) {
            $this->log('parser exception: ' . $e->getMessage(), 'error');
            $this->saveDebugLog($siteId);
            return ['ok' => false, 'error' => 'parser exception: ' . $e->getMessage(), 'path' => $usedPath];
        }

        $kind = $this->detectTemplateKind($data, $content);
        $this->log('parsed ' . count($data) . ' fields, kind=' . $kind, 'ok');

        // Snapshot — расширение .php.txt чтобы Apache не парсил
        $snapDir = Paths::storage('configs_snapshots');
        Paths::ensureDir($snapDir);
        @file_put_contents("{$snapDir}/site_{$siteId}_" . date('Ymd_His') . ".php.txt", $content);

        DB::pdo()->prepare("UPDATE sites_managed SET
            config_remote_path = ?,
            config_parsed_json = ?,
            config_template_kind = ?,
            config_last_synced_at = NOW()
            WHERE id = ?")->execute([
                $usedPath,
                json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $kind,
                $siteId,
            ]);

        $this->saveDebugLog($siteId);
        return ['ok' => true, 'data' => $data, 'kind' => $kind, 'path' => $usedPath, 'raw' => $content];
    }

    /**
     * Применить набор изменений к config.php на VPS.
     * Делает бэкап на стороне FTP (config.php.bak_YYYYMMDD_HHMMSS).
     */
    public function applyToVps(int $siteId, array $changes, string $oldHost = '', string $newHost = ''): array
    {
        $site = $this->loadSite($siteId);
        $ftp = $this->makeFtp($site);
        // Используем сохранённый успешный путь, если он есть
        $remotePath = trim((string)($site['config_remote_path'] ?? ''));
        if ($remotePath === '') {
            // fallback — пробуем кандидатов
            $candidates = $this->buildConfigPathCandidates($site);
            foreach ($candidates as $p) {
                $r = $ftp->tryGetContent($p);
                if ($r !== null && $r !== '') {
                    $remotePath = $p;
                    break;
                }
            }
            if ($remotePath === '') {
                return ['ok' => false, 'error' => 'cannot find config.php via FTP'];
            }
        }

        try {
            $content = $ftp->getContent($remotePath);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'FTP read failed: ' . $e->getMessage()];
        }

        $modified = $this->parser->applyChanges($content, $changes);

        if ($oldHost !== '' && $newHost !== '' && $oldHost !== $newHost) {
            $modified = $this->parser->replaceAllOccurrences($modified, $oldHost, $newHost);
        }

        // Snapshot
        $snapDir = Paths::storage('configs_snapshots');
        Paths::ensureDir($snapDir);
        @file_put_contents("{$snapDir}/site_{$siteId}_before_" . date('Ymd_His') . ".php.txt", $content);
        @file_put_contents("{$snapDir}/site_{$siteId}_after_"  . date('Ymd_His') . ".php.txt", $modified);

        try {
            $ftp->putContent($remotePath, $modified, '.bak');
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'FTP put failed: ' . $e->getMessage()];
        }

        $reparsed = $this->parser->parse($modified);
        DB::pdo()->prepare("UPDATE sites_managed SET
            config_parsed_json = ?,
            config_last_synced_at = NOW(),
            current_domain = COALESCE(NULLIF(?, ''), current_domain)
            WHERE id = ?")->execute([
                json_encode($reparsed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $newHost !== '' ? $newHost : '',
                $siteId,
            ]);

        return ['ok' => true, 'data' => $reparsed, 'path' => $remotePath];
    }

    /**
     * Залить произвольный файл в корень сайта (например, HTML-верификатор Yandex).
     */
    public function uploadFile(int $siteId, string $filename, string $content): array
    {
        $site = $this->loadSite($siteId);
        $ftp = $this->makeFtp($site);

        // Для chroot'нутого FTP файл лежит в корне FTP — '/'
        // Сначала пробуем относительный путь
        $candidates = [$filename, '/' . ltrim($filename, '/')];
        $rootDir = $this->resolveSiteRoot($site);
        if ($rootDir !== '') {
            $candidates[] = rtrim($rootDir, '/') . '/' . ltrim($filename, '/');
        }

        $lastErr = '';
        foreach ($candidates as $p) {
            try {
                $ftp->putContent($p, $content, null);
                return ['ok' => true, 'path' => $p];
            } catch (Throwable $e) {
                $lastErr = $e->getMessage();
            }
        }
        return ['ok' => false, 'error' => 'FTP put failed: ' . $lastErr];
    }

    public function getLatestSnapshot(int $siteId): ?string
    {
        $snapDir = Paths::storage('configs_snapshots');
        $files = glob("{$snapDir}/site_{$siteId}_*.php.txt");
        if (!$files) {
            // legacy snapshots без .txt
            $files = glob("{$snapDir}/site_{$siteId}_*.php");
            if (!$files) return null;
        }
        sort($files);
        return file_get_contents(end($files)) ?: null;
    }

    // ---------------- Внутренние helper'ы ----------------

    protected function loadSite(int $id): array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $site = $st->fetch();
        if (!$site) throw new RuntimeException("Site #{$id} not found");
        return $site;
    }

    protected function makeFtp(array $site): FtpService
    {
        $host = trim((string)($site['ftp_host'] ?? ''));
        $user = trim((string)($site['ftp_user'] ?? ''));
        $passEnc = (string)($site['ftp_pass_enc'] ?? '');
        if ($host === '' || $user === '' || $passEnc === '') {
            throw new RuntimeException('FTP credentials not set for this site');
        }
        $pass = Crypto::decrypt($passEnc);
        return new FtpService($host, $user, $pass, ['passive' => true, 'timeout' => 30]);
    }

    /**
     * Список путей-кандидатов для config.php — пробуем по очереди.
     */
    protected function buildConfigPathCandidates(array $site): array
    {
        $list = [];

        // 1. Сохранённый успешный путь (если был)
        $saved = trim((string)($site['config_remote_path'] ?? ''));
        if ($saved !== '') {
            $list[] = $saved;
        }

        // 2. Самые вероятные при chroot'нутом FTP-юзере
        $list[] = 'config.php';
        $list[] = '/config.php';

        // 3. Возможно сайт в подкаталоге public/ или htdocs/
        $list[] = 'public/config.php';
        $list[] = '/public/config.php';

        // 4. Абсолютный путь — если FTP-юзер не chroot
        $idxDir = trim((string)($site['fp_index_dir'] ?? ''));
        if ($idxDir !== '') {
            $list[] = rtrim($idxDir, '/') . '/config.php';
        }
        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        $dom = trim((string)($site['current_domain'] ?? ''));
        if ($owner !== '' && $dom !== '') {
            $absDom = preg_replace('~^www\.~i', '', $dom);
            $list[] = "/var/www/{$owner}/data/www/{$absDom}/config.php";
        }

        return array_values(array_unique($list));
    }

    private function resolveSiteRoot(array $site): string
    {
        $idx = trim((string)($site['fp_index_dir'] ?? ''));
        if ($idx !== '') return $idx;
        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        $dom = trim((string)($site['current_domain'] ?? ''));
        if ($owner !== '' && $dom !== '') {
            $absDom = preg_replace('~^www\.~i', '', $dom);
            return "/var/www/{$owner}/data/www/{$absDom}";
        }
        return '';
    }

    /**
     * Эвристика: какого "типа" сайт. Для будущей логики (template_kind).
     */
    protected function detectTemplateKind(array $data, string $rawSrc): string
    {
        // v17.13: новый формат шаблонов enomo v3 — массивы $site и $variant_settings
        if (preg_match('~\$site\s*=\s*\[~', $rawSrc)
            && preg_match('~\$variant_settings\s*=\s*\[~', $rawSrc)) {
            return 'enomo-v3';
        }

        if (isset($data['catalog']) && $data['catalog'] !== '') {
            return 'pages-catalog-' . $data['catalog']; // 1win/7k/drgnmn/flagman
        }
        if (isset($data['template']) && (int)$data['template'] === 2) {
            return 'casino-template-2';
        }
        if (stripos($rawSrc, 'header.php') !== false) {
            return 'beef-pages';
        }
        return 'unknown';
    }

    // ---------------- Debug log helpers ----------------

    private function log(string $msg, string $level = 'info'): void
    {
        $this->debugLog[] = [
            'ts' => date('c'),
            'level' => $level,
            'msg' => $msg,
        ];
    }

    /**
     * Дописывает накопленный лог попытки sync в import_log сайта,
     * чтобы пользователь мог открыть страницу диагностики и увидеть детали.
     */
    private function saveDebugLog(int $siteId): void
    {
        if (empty($this->debugLog)) return;
        $st = DB::pdo()->prepare("SELECT import_log FROM sites_managed WHERE id=?");
        $st->execute([$siteId]);
        $row = $st->fetch();
        $existing = [];
        if (!empty($row['import_log'])) {
            $decoded = json_decode((string)$row['import_log'], true);
            if (is_array($decoded)) $existing = $decoded;
        }
        $marker = [
            'ts' => date('c'),
            'level' => 'info',
            'msg' => '=== syncFromVps attempt ===',
        ];
        $merged = array_merge($existing, [$marker], $this->debugLog);
        // Ограничим размер до последних 200 записей
        if (count($merged) > 200) {
            $merged = array_slice($merged, -200);
        }
        $upd = DB::pdo()->prepare("UPDATE sites_managed SET import_log=? WHERE id=?");
        $upd->execute([json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $siteId]);
    }
}
