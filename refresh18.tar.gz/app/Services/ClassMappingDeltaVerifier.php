<?php

/**
 * ClassMappingDeltaVerifier (ТЗ 046 §6/§7) — прямой семантический proof факта рандомизации
 * классов: сравнение правых частей mapping-файлов ДО и ПОСЛЕ вызова update_classes.php.
 *
 * Бизнес-правило (§11/§18): если хотя бы одно значение класса реально изменилось между
 * snapshot BEFORE и read-back AFTER — рандомизация подтверждена (changed_pairs >= 1).
 * НЕ смешивать с HTTP-ответом: HTTP 200 / «Update process completed» / mtime / размер / SHA
 * произвольного файла сами по себе доказательством НЕ являются (§8).
 *
 * Компонент чистый: читает файлы через переданный reader (fn(string $path): ?string), поэтому
 * тестируется без реального FTP и переиспользуется с $ftp->tryGetContent в оркестраторе.
 */
final class ClassMappingDeltaVerifier
{
    /**
     * Распарсить mapping «oldClass:newClass» построчно. Пустые/битые строки игнорируются.
     * Разделитель — первый ':'. Пробелы по краям срезаются (для семантики важны значения,
     * а не whitespace — §9).
     * @return array<string,string> old => new
     */
    public static function parsePairs(string $content): array
    {
        $pairs = [];
        foreach (preg_split('~\r\n|\r|\n~', $content) as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, ':') === false) continue;
            [$old, $new] = explode(':', $line, 2);
            $old = trim($old);
            $new = trim($new);
            if ($old === '') continue;
            $pairs[$old] = $new;
        }
        return $pairs;
    }

    /**
     * BEFORE-снимок mapping-файлов (прямо перед mutating HTTP call).
     * @param callable $read fn(string $path): ?string
     * @param string[] $paths относительные пути mapping-файлов
     * @return array{ok:bool, captured_at:string, files:array<string,array>}
     */
    public static function snapshot(callable $read, array $paths): array
    {
        $files = [];
        $allOk = !empty($paths);
        foreach ($paths as $path) {
            $path = (string)$path;
            $content = null;
            try { $content = $read($path); } catch (\Throwable $e) { $content = null; }
            if (!is_string($content) || trim($content) === '') {
                $files[$path] = ['ok' => false, 'reason' => 'mapping_absent', 'pairs_count' => 0, 'sha256' => null, 'pairs' => []];
                $allOk = false;
                continue;
            }
            $pairs = self::parsePairs($content);
            if (empty($pairs)) {
                $files[$path] = ['ok' => false, 'reason' => 'mapping_invalid', 'pairs_count' => 0, 'sha256' => null, 'pairs' => []];
                $allOk = false;
                continue;
            }
            $files[$path] = [
                'ok' => true,
                'pairs_count' => count($pairs),
                'sha256' => hash('sha256', $content),
                'pairs' => $pairs,
            ];
        }
        return ['ok' => $allOk, 'captured_at' => gmdate('Y-m-d H:i:s'), 'files' => $files];
    }

    /**
     * AFTER-diff: перечитать ТЕ ЖЕ пути и посчитать семантические изменения правых частей.
     * @param array  $before результат snapshot()
     * @param callable $read fn(string $path): ?string
     * @return array{ok:bool, changed_pairs:int, added:int, removed:int, unchanged:int,
     *               before_count:int, after_count:int, files:array, sample:?array, error:?string}
     */
    public static function diff(array $before, callable $read): array
    {
        $beforeFiles = is_array($before['files'] ?? null) ? $before['files'] : [];
        if (empty($beforeFiles)) {
            return self::err('before_snapshot_missing');
        }
        // BEFORE обязан быть достоверно прочитан для всех файлов (§12: BEFORE snapshot отсутствует → блок).
        foreach ($beforeFiles as $path => $bf) {
            if (empty($bf['ok'])) return self::err('before_unreadable:' . $path);
        }

        $changed = 0; $added = 0; $removed = 0; $unchanged = 0; $common = 0; $beforeCount = 0; $afterCount = 0;
        $files = []; $sample = null; $examples = [];

        foreach ($beforeFiles as $path => $bf) {
            $beforePairs = is_array($bf['pairs'] ?? null) ? $bf['pairs'] : [];
            $content = null;
            try { $content = $read((string)$path); } catch (\Throwable $e) { $content = null; }
            // §12: mapping AFTER невозможно прочитать → verification_error (блок).
            if (!is_string($content) || trim($content) === '') {
                return self::err('after_unreadable:' . $path);
            }
            $afterPairs = self::parsePairs($content);
            if (empty($afterPairs)) {
                return self::err('after_invalid:' . $path);
            }

            $cChanged = 0; $cUnchanged = 0; $cAdded = 0; $cRemoved = 0;
            foreach ($beforePairs as $old => $newBefore) {
                if (array_key_exists($old, $afterPairs)) {
                    if ($afterPairs[$old] !== $newBefore) {
                        $cChanged++;
                        if ($sample === null) $sample = ['key' => (string)$old, 'before' => (string)$newBefore, 'after' => (string)$afterPairs[$old]];
                        if (count($examples) < 10) $examples[] = ['key' => (string)$old, 'before' => (string)$newBefore, 'after' => (string)$afterPairs[$old]];
                    } else {
                        $cUnchanged++;
                    }
                } else {
                    $cRemoved++;
                }
            }
            foreach ($afterPairs as $old => $_) {
                if (!array_key_exists($old, $beforePairs)) $cAdded++;
            }

            $changed += $cChanged; $unchanged += $cUnchanged; $added += $cAdded; $removed += $cRemoved;
            $common += ($cChanged + $cUnchanged);
            $beforeCount += count($beforePairs); $afterCount += count($afterPairs);
            $files[(string)$path] = [
                'changed_pairs' => $cChanged, 'unchanged_pairs' => $cUnchanged,
                'added_pairs' => $cAdded, 'removed_pairs' => $cRemoved,
                'before_count' => count($beforePairs), 'after_count' => count($afterPairs),
                'sha_before' => $bf['sha256'] ?? null, 'sha_after' => hash('sha256', $content),
            ];
        }

        return [
            'ok' => true,
            'changed_pairs' => $changed, 'added' => $added, 'removed' => $removed, 'unchanged' => $unchanged,
            'common' => $common, 'before_count' => $beforeCount, 'after_count' => $afterCount,
            'files' => $files, 'sample' => $sample, 'examples' => $examples, 'error' => null,
        ];
    }

    /**
     * Итоговый вердикт (§7 «Главный бизнес-критерий»):
     * FTP identity verified AND mapping BEFORE прочитан AND mapping AFTER прочитан AND changed_pairs>=1
     * = RANDOMIZATION VERIFIED (именно >=1, не 95%).
     *
     * @return array{verified:bool, changed_pairs:int, reason:string, files_checked:int, sample:?array}
     */
    public static function verdict(bool $identityVerified, array $before, array $diff): array
    {
        $changed = (int)($diff['changed_pairs'] ?? 0);
        $filesChecked = is_array($diff['files'] ?? null) ? count($diff['files']) : 0;
        $sample = $diff['sample'] ?? null;

        if (!$identityVerified) {
            return ['verified' => false, 'changed_pairs' => $changed, 'reason' => 'ftp_identity_unverified', 'files_checked' => $filesChecked, 'sample' => $sample];
        }
        if (empty($before['ok'])) {
            return ['verified' => false, 'changed_pairs' => $changed, 'reason' => 'before_snapshot_incomplete', 'files_checked' => $filesChecked, 'sample' => $sample];
        }
        if (empty($diff['ok'])) {
            return ['verified' => false, 'changed_pairs' => $changed, 'reason' => (string)($diff['error'] ?? 'diff_error'), 'files_checked' => $filesChecked, 'sample' => $sample];
        }
        if ($changed < 1) {
            // §17: нет общих logical keys → структура полностью изменилась → inconclusive (не «0 изменений»).
            if ((int)($diff['common'] ?? 0) === 0) {
                return ['verified' => false, 'changed_pairs' => 0, 'reason' => 'no_common_keys', 'files_checked' => $filesChecked, 'sample' => $sample];
            }
            return ['verified' => false, 'changed_pairs' => 0, 'reason' => 'no_class_change', 'files_checked' => $filesChecked, 'sample' => $sample];
        }
        return ['verified' => true, 'changed_pairs' => $changed, 'reason' => 'class_delta_confirmed', 'files_checked' => $filesChecked, 'sample' => $sample];
    }

    private static function err(string $reason): array
    {
        return ['ok' => false, 'changed_pairs' => 0, 'added' => 0, 'removed' => 0, 'unchanged' => 0,
                'before_count' => 0, 'after_count' => 0, 'files' => [], 'sample' => null, 'error' => $reason];
    }
}
