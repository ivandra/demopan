<?php
/**
 * CasinoWebmasterService — клиент Яндекс.Вебмастера для casino-проектов.
 *
 * Порт логики Hub (app/Services/YandexWebmasterService.php), адаптированный под
 * refresh-panel:
 *   - токен берётся из таблицы `yandex_webmaster_accounts` (Crypto::decrypt),
 *     а не из webmaster_accounts/webmaster_settings как в Hub;
 *   - verification-файл пишется в КОРЕНЬ docroot проекта (а не в subs/{label}/),
 *     потому что в мульти-сайте все поддомены делят один docroot и host-router
 *     (index.php) отдаёт реальный файл из корня напрямую (.htaccess: RewriteCond !-f);
 *   - сервис без записи статусов в БД: статусы хранит casino-panel в project.json.
 *
 * API: https://api.webmaster.yandex.net/v4  (OAuth-токен в заголовке Authorization).
 *
 * Эндпоинты (как в Hub, проверено по его коду):
 *   GET  /v4/user                                             → user_id
 *   GET  /v4/user/{u}/hosts                                   → список хостов
 *   POST /v4/user/{u}/hosts {host_url}                        → добавить хост
 *   GET  /v4/user/{u}/hosts/{h}/verification                  → applicable_verifiers / uin
 *   POST /v4/user/{u}/hosts/{h}/verification/HTML_FILE        → запустить проверку
 *   POST /v4/user/{u}/hosts/{h}/recrawl/queue {url}           → переобход URL
 *   POST /v4/user/{u}/hosts/{h}/user-added-sitemaps {url}     → добавить sitemap
 *   POST /v4/user/{u}/hosts/{h}/robots                        → подтвердить robots
 */
class CasinoWebmasterService
{
    // PATCH047: host owned by YandexWebmasterHttpTransport (API_HOST const removed).

    /** @var int id строки в yandex_webmaster_accounts */
    private $accountId = 0;

    public function __construct(int $accountId)
    {
        $this->accountId = $accountId;
    }

    /* =========================================================
       ТОКЕН
       ========================================================= */

    private function getAccessToken(): string
    {
        if ($this->accountId <= 0) {
            throw new RuntimeException('webmaster account_id is empty');
        }
        $st = DB::pdo()->prepare(
            "SELECT access_token_enc, token_expires_at FROM yandex_webmaster_accounts WHERE id = ? LIMIT 1"
        );
        $st->execute([$this->accountId]);
        $row = $st->fetch();
        if (!$row) {
            throw new RuntimeException("webmaster account #{$this->accountId} not found");
        }
        $token = trim((string)Crypto::decrypt((string)$row['access_token_enc']));
        if ($token === '') {
            throw new RuntimeException("webmaster account #{$this->accountId}: empty access_token");
        }
        return $token;
    }

    /** Информация об аккаунте (для UI/диагностики), без расшифровки токена. */
    public function accountInfo(): array
    {
        $st = DB::pdo()->prepare(
            "SELECT id, label, email, yandex_user_id, token_expires_at, flow_type FROM yandex_webmaster_accounts WHERE id = ? LIMIT 1"
        );
        $st->execute([$this->accountId]);
        return $st->fetch() ?: [];
    }

    /* =========================================================
       ХОСТЫ
       ========================================================= */

    public function getUserId(): string
    {
        $j = $this->apiRequest('GET', '/v4/user', [], null);
        if (isset($j['user_id'])) return (string)$j['user_id'];
        if (isset($j['data']['user_id'])) return (string)$j['data']['user_id'];
        throw new RuntimeException('Webmaster API: cannot extract user_id from /v4/user');
    }

    public function getHosts(string $userId): array
    {
        return $this->apiRequest('GET', '/v4/user/' . rawurlencode($userId) . '/hosts', [], null);
    }

    public function addHost(string $userId, string $hostUrl): array
    {
        return $this->apiRequest(
            'POST',
            '/v4/user/' . rawurlencode($userId) . '/hosts',
            [],
            ['host_url' => $hostUrl]
        );
    }

    /**
     * Возвращает host_id по host_url; если в Яндексе его нет — добавляет.
     * @return array{host_id:string, already_existed:bool}
     */
    public function getOrCreateHostId(string $userId, string $hostUrl): array
    {
        $hosts = $this->getHosts($userId);
        $hostId = $this->findHostIdInHostsResponse($hosts, $hostUrl);
        if ($hostId !== null) {
            return ['host_id' => $hostId, 'already_existed' => true];
        }

        $res = $this->addHost($userId, $hostUrl);
        $newId = null;
        if (isset($res['host_id'])) $newId = (string)$res['host_id'];
        if (isset($res['data']['host_id'])) $newId = (string)$res['data']['host_id'];
        if (isset($res['data']['host']['host_id'])) $newId = (string)$res['data']['host']['host_id'];
        if ($newId !== null && $newId !== '') {
            return ['host_id' => $newId, 'already_existed' => false];
        }

        // ответ странный — перечитать список
        $hosts2 = $this->getHosts($userId);
        $hostId2 = $this->findHostIdInHostsResponse($hosts2, $hostUrl);
        if ($hostId2 !== null) {
            return ['host_id' => $hostId2, 'already_existed' => true];
        }
        throw new RuntimeException('Cannot get host_id after addHost for ' . $hostUrl);
    }

    /* =========================================================
       ПОДТВЕРЖДЕНИЕ ПРАВ (HTML_FILE)
       ========================================================= */

    public function checkVerification(string $userId, string $hostId): array
    {
        return $this->apiRequest(
            'GET',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/verification',
            [],
            null
        );
    }

    public function verifyHost(string $userId, string $hostId, string $type = 'HTML_FILE'): array
    {
        try {
            return $this->apiRequest(
                'POST',
                '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/verification/' . rawurlencode($type),
                [],
                null
            );
        } catch (Throwable $e) {
            return $this->apiRequest(
                'POST',
                '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/verification',
                ['verification_type' => $type],
                null
            );
        }
    }

    private function buildHtmlFileVerificationContent(string $uin): string
    {
        $uin = trim($uin);
        return "<html>\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n</head>\n<body>Verification: {$uin}</body>\n</html>\n";
    }

    /**
     * Достаёт имя файла + содержимое для HTML_FILE из ответа verification.
     * @return array{type:string, uin:string, file:string, content:string}
     */
    public function getHtmlFileVerifier(string $userId, string $hostId): array
    {
        $info = $this->checkVerification($userId, $hostId);

        $app = null;
        if (isset($info['applicable_verifiers']) && is_array($info['applicable_verifiers'])) {
            $app = $info['applicable_verifiers'];
        } elseif (isset($info['data']['applicable_verifiers']) && is_array($info['data']['applicable_verifiers'])) {
            $app = $info['data']['applicable_verifiers'];
        }

        if (is_array($app)) {
            foreach ($app as $v) {
                if ((string)($v['verification_type'] ?? '') !== 'HTML_FILE') continue;
                $uin     = (string)($v['verification_uin'] ?? '');
                $file    = (string)($v['verification_file'] ?? ($v['file'] ?? ($v['file_name'] ?? '')));
                $content = (string)($v['verification_content'] ?? ($v['content'] ?? ''));
                if ($file === '' && $uin !== '')    $file = 'yandex_' . $uin . '.html';
                if ($content === '' && $uin !== '') $content = $this->buildHtmlFileVerificationContent($uin);
                if ($file !== '' && $content !== '') {
                    return ['type' => 'HTML_FILE', 'uin' => $uin, 'file' => $file, 'content' => $content];
                }
            }
        }

        $uin = null;
        if (isset($info['verification_uin']))         $uin = (string)$info['verification_uin'];
        if (isset($info['data']['verification_uin'])) $uin = (string)$info['data']['verification_uin'];
        if ($uin) {
            return [
                'type'    => 'HTML_FILE',
                'uin'     => $uin,
                'file'    => 'yandex_' . $uin . '.html',
                'content' => $this->buildHtmlFileVerificationContent($uin),
            ];
        }
        throw new RuntimeException('Cannot extract HTML_FILE verifier from checkVerification response');
    }

    /**
     * Пишет verification-файл в КОРЕНЬ docroot проекта.
     * Важно: именно в корень — тогда .htaccess (RewriteCond !-f) отдаёт его
     * статикой по http://{любой-поддомен}/yandex_xxx.html, минуя index.php/guard.
     * Возвращает абсолютный путь записанного файла.
     */
    public function writeVerificationFileToDocroot(string $docroot, string $fileName, string $content): string
    {
        $docroot = rtrim($docroot, '/');
        if ($docroot === '' || !is_dir($docroot)) {
            throw new RuntimeException('docroot not found: ' . $docroot);
        }
        // имя файла — только базовое, без путей (защита от traversal)
        $fileName = basename($fileName);
        if ($fileName === '' || !preg_match('~^yandex_[A-Za-z0-9]+\.html$~', $fileName)) {
            throw new RuntimeException('unexpected verification file name: ' . $fileName);
        }
        $full = $docroot . '/' . $fileName;
        if (@file_put_contents($full, $content) === false) {
            throw new RuntimeException('Cannot write verification file: ' . $full);
        }
        return $full;
    }

    /** Статус верификации в коротком виде: VERIFICATION_STATE / verified bool. */
    public function verificationStatus(string $userId, string $hostId): array
    {
        $info = $this->checkVerification($userId, $hostId);
        $state = (string)($info['verification_state'] ?? ($info['data']['verification_state'] ?? ''));
        return [
            'state'    => $state,
            'verified' => ($state === 'VERIFIED'),
            'raw'      => $info,
        ];
    }

    /* =========================================================
       РУЧНЫЕ ОПЕРАЦИИ: переобход / sitemap / robots
       ========================================================= */

    public function recrawlUrl(string $userId, string $hostId, string $url): array
    {
        $url = trim($url);
        if ($url === '') return ['ok' => false, 'message' => 'empty url'];
        return $this->apiRequest(
            'POST',
            '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/recrawl/queue',
            [],
            ['url' => $url]
        );
    }

    public function recrawlUrls(string $userId, string $hostId, array $urls): array
    {
        $urls = array_values(array_unique(array_filter(array_map('trim', $urls))));
        if (!$urls) return ['ok' => false, 'message' => 'empty url_list', 'sent' => 0, 'success' => 0, 'failed' => 0, 'errors' => []];
        $ok = 0; $err = 0; $errors = []; $successUrls = [];
        foreach ($urls as $u) {
            try { $this->recrawlUrl($userId, $hostId, $u); $ok++; $successUrls[] = $u; }
            catch (Throwable $e) { $err++; if (count($errors) < 10) $errors[] = $u . ' :: ' . $e->getMessage(); }
        }
        return [
            'ok' => ($err === 0), 'sent' => count($urls), 'success' => $ok, 'failed' => $err,
            'errors' => $errors, 'success_urls' => $successUrls,
        ];
    }

    public function addSitemap(string $userId, string $hostId, string $sitemapUrl): array
    {
        $payload = ['url' => $sitemapUrl];
        try {
            return $this->apiRequest(
                'POST',
                '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/user-added-sitemaps',
                [],
                $payload
            );
        } catch (Throwable $e) {
            return $this->apiRequest(
                'POST',
                '/v4/user/' . rawurlencode($userId) . '/hosts/' . rawurlencode($hostId) . '/sitemaps',
                [],
                $payload
            );
        }
    }

    /**
     * "Подтверждение" robots.txt. У Яндекс.Вебмастера НЕТ API-эндпоинта для этого
     * (POST /robots → 404). Поэтому, как и Hub (его robotsConfirm делает HTTP-проверку
     * без API Яндекса), просто проверяем что {host}/robots.txt реально отдаётся (HTTP 2xx/3xx).
     * @return array{ok:bool, http:int, robots_url:string, final_url:string}
     */
    public function confirmRobots(string $hostUrl): array
    {
        $robotsUrl = rtrim($hostUrl, '/') . '/robots.txt';
        [$http, $finalUrl] = $this->httpProbe($robotsUrl);
        return [
            'ok'         => ($http >= 200 && $http < 400),
            'http'       => $http,
            'robots_url' => $robotsUrl,
            'final_url'  => $finalUrl,
        ];
    }

    /** HTTP-проба URL (GET, с редиректами, без проверки self-signed SSL). */
    private function httpProbe(string $url): array
    {
        $ch = curl_init($url);
        if ($ch === false) return [0, ''];
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // на сайтах self-signed сертификаты
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'CasinoPanel-RobotsCheck');
        curl_exec($ch);
        $http  = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        return [$http, $final];
    }

    /* =========================================================
       ВНУТРЕННЕЕ
       ========================================================= */

    private function findHostIdInHostsResponse(array $resp, string $hostUrl): ?string
    {
        $need = $this->normalizeHostUrl($hostUrl);
        $list = [];
        if (isset($resp['data']['hosts']) && is_array($resp['data']['hosts'])) $list = $resp['data']['hosts'];
        elseif (isset($resp['hosts']) && is_array($resp['hosts'])) $list = $resp['hosts'];

        foreach ($list as $h) {
            $url = '';
            if (isset($h['host_url'])) $url = (string)$h['host_url'];
            elseif (isset($h['unicode_host_url'])) $url = (string)$h['unicode_host_url'];
            $id = isset($h['host_id']) ? (string)$h['host_id'] : null;
            if ($url !== '' && $id !== null && $this->normalizeHostUrl($url) === $need) {
                return $id;
            }
        }
        return null;
    }

    /**
     * Нормализация host_url: lower-case, без хвостового слэша и без дефолтного
     * порта (:443/:80). Доп. к Hub: снятие порта — Яндекс отдаёт host_url вида
     * https://site:443, а добавляем мы https://site → без нормализации порта
     * findHostId не находил бы существующий хост и плодил дубль.
     */
    private function normalizeHostUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') return '';
        $url = function_exists('mb_strtolower') ? mb_strtolower($url) : strtolower($url);
        $url = preg_replace('~:(443|80)(/|$)~', '$2', $url);
        return rtrim($url, '/');
    }

    private function apiRequest(string $method, string $path, array $query = [], $jsonBody = null): array
    {
        // PATCH 047 §44: тот же resolver+transport, что и refresh pipeline. Один аккаунт
        // не может ходить в Yandex.Webmaster с разных IP из разных сервисов.
        $token = $this->getAccessToken();
        $safePath = $path;
        if (preg_match('~^https?://[^/]+(/.*)$~i', $path, $m)) {
            $safePath = $m[1];
        }

        $resolver = new WebmasterOutboundIpResolver();
        $resolved = $resolver->resolveForAccount($this->accountId);   // fail-closed
        $expectedIp = $resolved['ip_address'];

        try {
            $res = (new YandexWebmasterHttpTransport())->request(
                $method, $safePath, $token, $expectedIp, $query, $jsonBody,
                ['webmaster_account_id' => $this->accountId, 'refresh_job_id' => null, 'stage' => null]
            );
        } catch (WebmasterTransportException $e) {
            throw new RuntimeException('Yandex.Webmaster routing (' . $e->getReason() . '): ' . $e->getMessage(), 0, $e);
        }

        $http = (int)$res['http_code'];
        $raw  = (string)$res['body'];
        if ($raw === '') {
            if ($http >= 200 && $http < 300) return [];
            throw new RuntimeException('Webmaster API HTTP ' . $http . '; empty body');
        }
        $data = json_decode($raw, true);
        if ($http < 200 || $http >= 300) {
            $msg = 'Webmaster API HTTP ' . $http;
            if (is_array($data)) {
                if (isset($data['error_message'])) $msg .= '; ' . $data['error_message'];
                elseif (isset($data['message']))   $msg .= '; ' . $data['message'];
                elseif (isset($data['error']))     $msg .= '; ' . $data['error'];
            } else {
                $msg .= '; ' . trim(substr($raw, 0, 500));
            }
            throw new RuntimeException($msg);
        }
        return is_array($data) ? $data : [];
    }

}
