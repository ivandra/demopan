<?php
/**
 * RobotsCheckDecision — ЧИСТАЯ (без I/O) политика решения стадии wm_robots.
 *
 * Вынесена из RefreshOrchestrator, чтобы поведение (а не только наличие строк) можно было
 * исполнять в тестах по таблице §10 обзора. Разводит три независимых факта:
 *   - $httpOk       — прямой HTTP GET robots.txt дал валидный транспорт (2xx + верный конечный host);
 *   - $contentOk    — тело распознано как robots-директивы (не HTML/редирект/пусто);
 *   - $api          — результат ДОПОЛНИТЕЛЬНОГО Webmaster API: ['attempted','ok','http_code','routing_fatal'].
 *
 * Инварианты (P0-1/P0-2/P1-1/P1-2):
 *   1. routing_fatal (любое состояние HTTP) → fail-closed стоп; НИКОГДА не best-effort.
 *   2. robots.verified — ТОЛЬКО при $httpOk && $contentOk (не по одному HEAD).
 *   3. провал прямого HTTP → robots.http_unavailable; валидный HTTP + плохое тело → robots.content_invalid;
 *      недоступность/401 доп. API → robots.api_unavailable (отдельно, не маскирует HTTP).
 *   4. 401 доп. API — best-effort: warning, БЕЗ error/setStatusFailed, pipeline продолжается.
 */
final class RobotsCheckDecision
{
    /**
     * @param array{attempted?:bool,ok?:bool,http_code?:int|null,routing_fatal?:bool} $api
     * @return array{action:string,events:array<int,array<string,mixed>>,verified:bool,reason:string}
     *   action: 'continue' (stage → ok, best-effort) | 'stop_fatal' (fail-closed, awaiting_user)
     */
    public static function decide(bool $httpOk, bool $contentOk, array $api): array
    {
        // (1) routing fatal доминирует над всем — fail-closed, без маскировки.
        if (!empty($api['routing_fatal'])) {
            return ['action' => 'stop_fatal', 'events' => [], 'verified' => false, 'reason' => 'routing_fatal'];
        }

        $events = [];
        $verified = $httpOk && $contentOk;

        // (2/3) состояние ПРЯМОГО robots.txt на сайте.
        if ($verified) {
            $events[] = ['code' => 'robots.verified', 'level' => 'ok', 'source' => 'site',
                        'robots_http_ok' => true, 'robots_content_ok' => true];
        } elseif (!$httpOk) {
            $events[] = ['code' => 'robots.http_unavailable', 'level' => 'warn', 'source' => 'site',
                        'robots_http_ok' => false];
        } else { // httpOk, но содержимое не валидно
            $events[] = ['code' => 'robots.content_invalid', 'level' => 'warn', 'source' => 'site',
                        'robots_http_ok' => true, 'robots_content_ok' => false];
        }

        // (3/4) результат ДОПОЛНИТЕЛЬНОГО API — отдельным событием, точный http_code.
        if (!empty($api['attempted']) && empty($api['ok'])) {
            $events[] = ['code' => 'robots.api_unavailable', 'level' => 'warn', 'source' => 'external_service',
                        'api_http' => $api['http_code'] ?? null];
        }

        return ['action' => 'continue', 'events' => $events, 'verified' => $verified, 'reason' => 'best_effort'];
    }

    /** Валидатор содержимого robots.txt: директивы, не HTML, не пусто. */
    public static function contentLooksLikeRobots(?string $body): bool
    {
        if ($body === null) return false;
        $b = trim($body);
        if ($b === '') return false;
        if (stripos($b, '<html') !== false || stripos($b, '<!doctype') !== false) return false;
        // хотя бы одна директива robots
        return (bool)preg_match('/^\s*(user-agent|disallow|allow|sitemap|crawl-delay)\s*:/im', $b);
    }
}
