<?php

/**
 * Результат StaticSiteConfigScanner. Отдельный файл (autoload в новом PHP-процессе).
 *
 * assignments[] — распознанные статические присваивания:
 *   ['path','kind'(url_field|bare_sub|domain),'field','value','rhs_offset','rhs_text',
 *    'sub_param'(sub_id|subid|sub|null),'sub_value'(?string)]
 */
final class ConfigScanResult
{
    /** @var string ok|parse_error|blocked */
    public string $state;
    public string $reasonCode = '';
    public $detailsData = null;
    /** @var array[] */
    public array $assignments = [];

    public static function ok(array $assignments): self
    {
        $r = new self();
        $r->state = 'ok';
        $r->assignments = $assignments;
        return $r;
    }

    public static function parseError(string $code): self
    {
        $r = new self();
        $r->state = 'parse_error';
        $r->reasonCode = $code;
        return $r;
    }

    public static function blocked(string $reason, $details = null): self
    {
        $r = new self();
        $r->state = 'blocked';
        $r->reasonCode = $reason;
        $r->detailsData = $details;
        return $r;
    }

    public function isSafe(): bool { return $this->state === 'ok'; }
    public function reason(): string { return $this->reasonCode; }
    public function details() { return $this->detailsData; }
    public function assignments(): array { return $this->assignments; }

    /** Есть ли статическое поле domain. */
    public function domainRequired(): bool
    {
        foreach ($this->assignments as $a) if ($a['kind'] === 'domain') return true;
        return false;
    }

    /** Все активные значения sub_id (url_field с sub-параметром + bare_sub). */
    public function activeSubIds(): array
    {
        $vals = [];
        foreach ($this->assignments as $a) {
            if ($a['kind'] === 'bare_sub') $vals[] = (string)$a['sub_value'];
            elseif ($a['kind'] === 'url_field' && $a['sub_value'] !== null) $vals[] = (string)$a['sub_value'];
        }
        return array_values(array_unique($vals));
    }

    /** Единственное активное значение sub_id (или null, если sub_id нет). */
    public function uniqueSubIdOrNull(): ?string
    {
        $v = $this->activeSubIds();
        return count($v) === 1 ? $v[0] : null;
    }
}
