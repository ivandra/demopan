<?php
/**
 * CasinoRunner — обработчик casino_runs очереди.
 *
 * Вызывается из cron'а (тот же per-minute tick что и refresh-jobs).
 * Берёт queued-runs (kind='buy' пока что), вызывает соответствующий service,
 * обновляет state.
 *
 * Дизайн: вместо отдельного cron — просто добавляется одна строчка в существующий
 * cron-handler: (new CasinoRunner())->tick();
 *
 * Конкуренция: используется CronGuard::pickQueuedRuns с UPDATE для атомарного захвата.
 * Параллельные cron-tick'и не возьмут одну и ту же run.
 */
class CasinoRunner
{
    public function tick(int $maxRuns = 3): array
    {
        $out = ['picked' => 0, 'processed' => 0, 'failed' => 0, 'results' => []];

        // Watchdog: берём только queued-runs СТАРШЕ 90 секунд. Свежие (только что
        // созданные) обрабатывает фоновый процесс из buyStart/subdomainsStart —
        // не хватаем их чтобы не запустить покупку дважды.
        $runs = self::pickStaleQueuedRuns($maxRuns, 90);
        $out['picked'] = count($runs);

        foreach ($runs as $run) {
            $ok = $this->processRun($run);
            if ($ok) $out['processed']++; else $out['failed']++;
            $out['results'][] = ['run_id' => (string)$run['run_id'], 'kind' => (string)$run['kind'], 'ok' => $ok];
        }
        return $out;
    }

    /**
     * Queued-runs старше N секунд (фоновый запуск по ним точно не сработал/упал).
     */
    private static function pickStaleQueuedRuns(int $limit, int $olderThanSec): array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM casino_runs
              WHERE state = 'queued'
                AND created_at <= (NOW() - INTERVAL ? SECOND)
              ORDER BY id ASC
              LIMIT ?"
        );
        $st->bindValue(1, $olderThanSec, PDO::PARAM_INT);
        $st->bindValue(2, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }

    /**
     * Обработать ОДИН конкретный run по его run_id (для синхронного/фонового запуска
     * сразу после buyStart/subdomainsStart — без ожидания cron).
     */
    public function tickRun(string $runId): bool
    {
        $run = CasinoRunStore::loadByRunId($runId);
        if (!$run) {
            @error_log('[CasinoRunner::tickRun] run not found: ' . $runId);
            return false;
        }
        // Только если ещё queued (защита от двойного запуска cron'ом)
        if ((string)($run['state'] ?? '') !== 'queued') {
            return false;
        }
        return $this->processRun($run);
    }

    /**
     * Единая логика обработки одного run.
     */
    private function processRun(array $run): bool
    {
        $runId = (string)$run['run_id'];
        $kind  = (string)$run['kind'];

        try {
            CasinoRunStore::updateState($runId, 'running');
            CasinoRunStore::log($runId, 'info', "Run starts. kind={$kind}");

            $project = CasinoProjectStore::loadProject((int)$run['project_id']);
            if (!$project) {
                CasinoRunStore::updateState($runId, 'failed', ['error' => 'project_not_found']);
                return false;
            }

            switch ($kind) {
                case 'buy':
                    $result = CasinoBuyService::execute($run, $project);
                    break;
                case 'subdomains':
                    $result = CasinoSubdomainsService::execute($run, $project);
                    break;
                // в B4: 'webmaster', в B5: 'fastpanel_cron'
                default:
                    $result = ['ok' => false, 'reason' => 'unknown_kind: ' . $kind];
            }

            if (!empty($result['ok'])) {
                CasinoRunStore::updateState($runId, 'done', ['result_json' => json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
                CasinoRunStore::log($runId, 'success', "Run done");
                return true;
            }
            CasinoRunStore::updateState($runId, 'failed', [
                'error'       => (string)($result['reason'] ?? 'unknown'),
                'result_json' => json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
            CasinoRunStore::log($runId, 'error', "Run failed: " . ($result['reason'] ?? 'unknown'));
            return false;
        } catch (Throwable $e) {
            CasinoRunStore::updateState($runId, 'failed', ['error' => 'exception: ' . $e->getMessage()]);
            CasinoRunStore::log($runId, 'error', "Exception: " . $e->getMessage());
            return false;
        }
    }
}
