<?php

/**
 * XmlStockRequestContext — контекст одного XMLStock-запроса для централизованного
 * учёта. Любой production-вызов XMLStock идёт через XmlStockRequestService с этим
 * контекстом; прямые HTTP-запросы запрещены.
 */
final class XmlStockRequestContext
{
    public const PURPOSES = ['index_watching', 'final_monitoring', 'ban_monitoring', 'manual_test'];
    public const INITIATORS = ['cron', 'operator', 'system_test'];

    private string $purpose;
    private string $domain;
    private ?int $sourceJobId;
    private ?int $siteId;
    private ?int $monitorId;
    private ?string $phase;
    private ?int $sequenceNo;
    private string $initiatedBy;

    public function __construct(
        string $purpose,
        string $domain,
        ?int $sourceJobId = null,
        ?int $siteId = null,
        ?int $monitorId = null,
        ?string $phase = null,
        ?int $sequenceNo = null,
        string $initiatedBy = 'cron'
    ) {
        if (!in_array($purpose, self::PURPOSES, true)) {
            throw new InvalidArgumentException("Invalid xmlstock purpose: {$purpose}");
        }
        if (!in_array($initiatedBy, self::INITIATORS, true)) {
            throw new InvalidArgumentException("Invalid initiated_by: {$initiatedBy}");
        }
        $this->purpose = $purpose;
        $this->domain = $domain;
        $this->sourceJobId = $sourceJobId;
        $this->siteId = $siteId;
        $this->monitorId = $monitorId;
        $this->phase = $phase;
        $this->sequenceNo = $sequenceNo;
        $this->initiatedBy = $initiatedBy;
    }

    public function purpose(): string { return $this->purpose; }
    public function domain(): string { return $this->domain; }
    public function sourceJobId(): ?int { return $this->sourceJobId; }
    public function siteId(): ?int { return $this->siteId; }
    public function monitorId(): ?int { return $this->monitorId; }
    public function phase(): ?string { return $this->phase; }
    public function sequenceNo(): ?int { return $this->sequenceNo; }
    public function initiatedBy(): string { return $this->initiatedBy; }

    /**
     * Детерминированный idempotency-ключ для scheduled-проверок (§8.1):
     * ban:<monitor_id>:<series_no>:<phase>:<sequence_no>:<due_timestamp>
     */
    public static function scheduledUuid(int $monitorId, int $seriesNo, string $phase, ?int $sequenceNo, string $dueTs): string
    {
        $raw = 'ban:' . $monitorId . ':' . $seriesNo . ':' . $phase . ':' . ($sequenceNo ?? 0) . ':' . $dueTs;
        // 36-символьный UUID-подобный детерминированный ключ (uq_xmlstock_request_uuid CHAR(36))
        $h = md5($raw);
        return substr($h, 0, 8) . '-' . substr($h, 8, 4) . '-' . substr($h, 12, 4) . '-' . substr($h, 16, 4) . '-' . substr($h, 20, 12);
    }
}
