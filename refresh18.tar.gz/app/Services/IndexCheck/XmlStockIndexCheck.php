<?php

require_once __DIR__ . '/IndexCheckMethod.php';

/**
 * Проверка индексации через xmlstock.com (XML Search API Яндекса).
 *
 * Это основной (самый быстрый) метод проверки. Уже через 1-5 минут после recrawl
 * результат может появиться — намного быстрее чем Webmaster API (который кешируется).
 *
 * Запрос: GET https://xmlstock.com/yandexlive/xml/?user=X&key=Y&query=site:HOST
 * Ответ:  XML с <url>...</url> элементами
 *
 * Логика:
 *   - Если XML вернул хотя бы 1 <url> на нашем домене → indexed=true
 *   - Если 0 URL → indexed=false
 *
 * Стоимость: расход lim из xmlstock на каждый вызов. Поэтому мы делаем
 * adaptive polling и останавливаемся через 30 минут (по требованию).
 */
class XmlStockIndexCheck implements IndexCheckMethod
{
    private array $settings;

    public function __construct()
    {
        $this->settings = $this->loadSettings();
    }

    public function getName(): string
    {
        return 'xmlstock';
    }

    public function isAvailable(): bool
    {
        if ((int)($this->settings['enabled'] ?? 0) !== 1) return false;
        if (trim((string)($this->settings['user_id'] ?? '')) === '') return false;
        if (trim((string)($this->settings['api_key'] ?? '')) === '') return false;
        return true;
    }

    public function checkIndexed(string $hostUrl, ?string $userId = null, ?string $hostId = null, bool $skipCounter = false): array
    {
        if (!$this->isAvailable()) {
            return [
                'ok' => false,
                'indexed' => false,
                'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'xmlstock not configured (enabled=0 or no keys)',
                'error' => 'not_available',
            ];
        }

        $host = $this->extractHost($hostUrl);
        if ($host === '') {
            return [
                'ok' => false,
                'indexed' => false,
                'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'empty host',
                'error' => 'empty_host',
            ];
        }

        // Нормализуем URL для site: — Yandex принимает host без протокола
        $query = 'site:' . $host;

        $endpoint = trim((string)($this->settings['endpoint_xml'] ?? 'https://xmlstock.com/yandexlive/xml/'));
        $params = [
            'user' => (string)$this->settings['user_id'],
            'key' => (string)$this->settings['api_key'],
            'query' => $query,
            'page' => 0,
        ];
        $url = $endpoint . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_HTTPHEADER => [
                'Accept: application/xml,text/xml,*/*',
                'User-Agent: RefreshPanel/v17.1-xmlstock',
            ],
        ]);
        $body = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        // Считаем запрос (даже неудачный — лимит xmlstock уже потрачен).
        // §4.2: при вызове через XmlStockRequestService счётчик ведёт сервис (ledger),
        // поэтому internal-инкремент пропускается, чтобы не задваивать queries_today.
        if (!$skipCounter) {
            $this->incrementQueryCounter();
        }

        if ($body === false || $body === '' || $err !== '') {
            return [
                'ok' => false,
                'indexed' => false,
                'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'curl error: ' . ($err ?: 'empty body'),
                'error' => 'curl_error',
            ];
        }

        if ($httpCode !== 200) {
            return [
                'ok' => false,
                'indexed' => false,
                'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => "HTTP {$httpCode}",
                'error' => "http_{$httpCode}",
                'raw_excerpt' => mb_substr((string)$body, 0, 300),
            ];
        }

        // Проверка xmlstock-specific ошибок
        $xmlError = $this->extractXmlStockError((string)$body);
        if ($xmlError !== null) {
            // Code 15 = "Нет результатов" — НЕ ошибка, просто 0 индексированных
            if ((int)$xmlError['code'] === 15) {
                return [
                    'ok' => true,
                    'indexed' => false,
                    'pages_indexed' => 0,
                    'method' => $this->getName(),
                    'message' => 'xmlstock: no results (code 15)',
                ];
            }
            return [
                'ok' => false,
                'indexed' => false,
                'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => "xmlstock error {$xmlError['code']}: {$xmlError['message']}",
                'error' => "xmlstock_error_{$xmlError['code']}",
            ];
        }

        // Парсим <url> теги
        $urls = $this->extractUrlsFromXml((string)$body);

        // Считаем сколько из них на нашем домене
        $matchingUrls = 0;
        $needleHost = $this->normalizeHost($host);
        foreach ($urls as $u) {
            $urlHost = $this->normalizeHost($this->extractHost($u));
            if ($urlHost === $needleHost) $matchingUrls++;
        }

        $indexed = $matchingUrls > 0;
        return [
            'ok' => true,
            'indexed' => $indexed,
            'pages_indexed' => $matchingUrls,
            'method' => $this->getName(),
            'message' => $indexed
                ? "✓ Indexed: найдено {$matchingUrls} URL на {$host}"
                : "Not indexed: 0 URL найдено в выдаче",
            'urls_count_total' => count($urls),
        ];
    }

    /**
     * Загружает настройки. Если таблицы нет — пустые.
     */
    private function loadSettings(): array
    {
        try {
            $st = DB::pdo()->query("SELECT * FROM xmlstock_settings WHERE id = 1");
            $row = $st->fetch();
            return is_array($row) ? $row : [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Инкремент счётчика запросов для информационного UI.
     */
    private function incrementQueryCounter(): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE xmlstock_settings
                 SET queries_today = IF(queries_today_date = CURDATE(), queries_today + 1, 1),
                     queries_today_date = CURDATE()
                 WHERE id = 1"
            )->execute();
        } catch (\Throwable $e) {
            // Не критично
        }
    }

    private function extractXmlStockError(string $xml): ?array
    {
        if (preg_match('~<error[^>]*code="(\d+)"[^>]*>(.*?)</error>~si', $xml, $m)) {
            return [
                'code' => (int)$m[1],
                'message' => trim(strip_tags((string)$m[2])),
            ];
        }
        return null;
    }

    private function extractUrlsFromXml(string $xml): array
    {
        $urls = [];
        if (preg_match_all('~<url>\s*(https?://[^<\s]+)\s*</url>~iu', $xml, $m)) {
            foreach ($m[1] as $url) {
                $u = trim((string)$url);
                if ($u !== '') $urls[$u] = true;
            }
        }
        return array_values(array_keys($urls));
    }

    private function extractHost(string $url): string
    {
        $u = preg_replace('~^https?://~i', '', trim($url));
        $u = preg_replace('~/.*$~', '', $u);
        $u = preg_replace('~:\d+$~', '', $u);
        return strtolower(rtrim($u, '.'));
    }

    private function normalizeHost(string $host): string
    {
        $h = strtolower(trim($host));
        return preg_replace('~^www\.~', '', $h);
    }
}
