<?php

require_once __DIR__ . '/IndexCheckMethod.php';

/**
 * Базовый класс для методов через Webmaster API.
 * Подразумевает что у нас есть accountId (передан в конструктор).
 */
abstract class AbstractWebmasterIndexCheck implements IndexCheckMethod
{
    protected int $accountId;

    // revision 2 §14/§19: опциональный job/stage context для аудита job-bound index-проверок.
    protected $ctxJobId = null;
    protected $ctxStage = null;
    protected $ctxLog = null;
    public function setJobContext(?int $jobId, ?string $stage, $log = null): void
    {
        $this->ctxJobId = $jobId; $this->ctxStage = $stage; $this->ctxLog = $log;
    }

    /** Клиент с проставленным (если есть) контекстом job/stage. */
    protected function makeClient(): YandexWebmasterClient
    {
        $client = $this->makeClient();
        if (method_exists($client, 'setRequestContext')) {
            try { $client->setRequestContext($this->ctxJobId, $this->ctxStage, $this->ctxLog); }
            catch (\Throwable $e) { /* ignore */ }
        }
        return $client;
    }

    public function __construct(int $accountId)
    {
        $this->accountId = $accountId;
    }

    public function isAvailable(): bool
    {
        // Метод доступен если есть подключённый аккаунт с токеном
        try {
            $st = DB::pdo()->prepare(
                "SELECT 1 FROM yandex_webmaster_accounts
                 WHERE id = ? AND access_token_enc IS NOT NULL AND access_token_enc <> ''
                 LIMIT 1"
            );
            $st->execute([$this->accountId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Безопасный вызов API — возвращает [ok, data, error]. */
    protected function safeCall(callable $fn): array
    {
        try {
            $data = $fn();
            return ['ok' => true, 'data' => $data, 'error' => null];
        } catch (\Throwable $e) {
            // revision 2 §14: диагностически отличаем routing failure от обычного api_error
            // (source binding здесь уже корректен — это НЕ риск выхода с другого IP).
            $routingCritical = class_exists('WebmasterRoutingFailurePolicy')
                && WebmasterRoutingFailurePolicy::isCritical($e);
            return ['ok' => false, 'data' => [], 'error' => $e->getMessage(),
                    'routing_critical' => $routingCritical,
                    'routing_reason' => $routingCritical ? WebmasterRoutingFailurePolicy::reason($e) : null];
        }
    }
}

/**
 * Method 1: getHostSummary — самый быстрый Webmaster метод.
 *
 * Возвращает агрегированные данные:
 *   searchable_pages_count — страниц в индексе
 *   excluded_pages_count   — исключённых
 *
 * Yandex обновляет эти данные ~раз в час, но они УЖЕ покажут что-то
 * пока getInSearchHistory ещё пустой.
 */
class WebmasterSummaryIndexCheck extends AbstractWebmasterIndexCheck
{
    public function getName(): string
    {
        return 'webmaster_summary';
    }

    public function checkIndexed(string $hostUrl, ?string $userId = null, ?string $hostId = null): array
    {
        if (!$this->isAvailable() || $userId === null || $hostId === null) {
            return [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'no userId/hostId',
                'error' => 'no_user_host',
            ];
        }

        $client = $this->makeClient();
        $call = $this->safeCall(function () use ($client, $userId, $hostId) {
            return $client->getHostSummary($userId, $hostId);
        });

        if (!$call['ok']) {
            return [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'getHostSummary failed: ' . $call['error'],
                'error' => (!empty($call['routing_critical']) ? 'routing_error' : 'api_error'),
            ];
        }

        $resp = $call['data'];
        $pagesInSearch = (int)($resp['searchable_pages_count'] ?? $resp['data']['searchable_pages_count'] ?? 0);

        return [
            'ok' => true,
            'indexed' => $pagesInSearch > 0,
            'pages_indexed' => $pagesInSearch,
            'method' => $this->getName(),
            'message' => "summary: searchable_pages={$pagesInSearch}",
        ];
    }
}

/**
 * Method 2: getInSearchHistory — история по дням.
 * Самый стабильный, но обновляется медленнее (раз в день примерно).
 */
class WebmasterHistoryIndexCheck extends AbstractWebmasterIndexCheck
{
    public function getName(): string
    {
        return 'webmaster_history';
    }

    public function checkIndexed(string $hostUrl, ?string $userId = null, ?string $hostId = null): array
    {
        if (!$this->isAvailable() || $userId === null || $hostId === null) {
            return [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'no userId/hostId',
                'error' => 'no_user_host',
            ];
        }

        $client = $this->makeClient();
        $call = $this->safeCall(function () use ($client, $userId, $hostId) {
            return $client->getInSearchHistory(
                $userId, $hostId,
                date('c', strtotime('-30 days')),
                date('c')
            );
        });

        if (!$call['ok']) {
            return [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'getInSearchHistory failed: ' . $call['error'],
                'error' => (!empty($call['routing_critical']) ? 'routing_error' : 'api_error'),
            ];
        }

        $resp = $call['data'];
        $rows = $resp['history'] ?? $resp['data']['history'] ?? [];

        // Иногда returned как indicators.SEARCHABLE — проверяем оба варианта
        if (empty($rows)) {
            $points = $resp['indicators']['SEARCHABLE']
                ?? $resp['data']['indicators']['SEARCHABLE']
                ?? [];
            if (is_array($points)) {
                foreach ($points as $p) {
                    $rows[] = ['value' => (int)($p['value'] ?? 0)];
                }
            }
        }

        $values = [];
        foreach ($rows as $r) {
            if (is_array($r)) $values[] = (int)($r['value'] ?? 0);
        }
        $maxValue = $values ? max($values) : 0;
        $lastValue = $values ? (int)end($values) : 0;
        $current = max($maxValue, $lastValue);

        return [
            'ok' => true,
            'indexed' => $current > 0,
            'pages_indexed' => $current,
            'method' => $this->getName(),
            'message' => "history: points=" . count($values) . ", max={$maxValue}, last={$lastValue}",
        ];
    }
}

/**
 * Method 3: getInSearchSamples — сэмплы URL в индексе.
 */
class WebmasterSamplesIndexCheck extends AbstractWebmasterIndexCheck
{
    public function getName(): string
    {
        return 'webmaster_samples';
    }

    public function checkIndexed(string $hostUrl, ?string $userId = null, ?string $hostId = null): array
    {
        if (!$this->isAvailable() || $userId === null || $hostId === null) {
            return [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'no userId/hostId',
                'error' => 'no_user_host',
            ];
        }

        $client = $this->makeClient();
        $call = $this->safeCall(function () use ($client, $userId, $hostId) {
            return $client->getInSearchSamples($userId, $hostId, 0, 50);
        });

        if (!$call['ok']) {
            return [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'getInSearchSamples failed: ' . $call['error'],
                'error' => (!empty($call['routing_critical']) ? 'routing_error' : 'api_error'),
            ];
        }

        $resp = $call['data'];
        $count = (int)($resp['count'] ?? $resp['data']['count'] ?? 0);
        $samples = $resp['samples'] ?? $resp['data']['samples'] ?? [];
        $samplesCount = is_array($samples) ? count($samples) : 0;

        return [
            'ok' => true,
            'indexed' => ($count > 0 || $samplesCount > 0),
            'pages_indexed' => max($count, $samplesCount),
            'method' => $this->getName(),
            'message' => "samples: count={$count}, returned={$samplesCount}",
        ];
    }
}

/**
 * Method 4: getSearchEventSamples — события APPEARED_IN_SEARCH / REMOVED.
 * Полезно когда нужно понять "недавно ли что-то появилось".
 */
class WebmasterEventsIndexCheck extends AbstractWebmasterIndexCheck
{
    public function getName(): string
    {
        return 'webmaster_events';
    }

    public function checkIndexed(string $hostUrl, ?string $userId = null, ?string $hostId = null): array
    {
        if (!$this->isAvailable() || $userId === null || $hostId === null) {
            return [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'no userId/hostId',
                'error' => 'no_user_host',
            ];
        }

        $client = $this->makeClient();
        $call = $this->safeCall(function () use ($client, $userId, $hostId) {
            return $client->getSearchEventSamples($userId, $hostId, 0, 50);
        });

        if (!$call['ok']) {
            return [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'method' => $this->getName(),
                'message' => 'getSearchEventSamples failed: ' . $call['error'],
                'error' => (!empty($call['routing_critical']) ? 'routing_error' : 'api_error'),
            ];
        }

        $resp = $call['data'];
        $samples = $resp['samples'] ?? $resp['data']['samples'] ?? [];
        $appeared = 0;
        $removed = 0;
        if (is_array($samples)) {
            foreach ($samples as $s) {
                $event = (string)($s['event'] ?? '');
                if ($event === 'APPEARED_IN_SEARCH') $appeared++;
                elseif ($event === 'REMOVED_FROM_SEARCH') $removed++;
            }
        }

        return [
            'ok' => true,
            'indexed' => $appeared > 0,
            'pages_indexed' => $appeared,
            'method' => $this->getName(),
            'message' => "events: returned=" . count($samples) . ", appeared={$appeared}, removed={$removed}",
        ];
    }
}
