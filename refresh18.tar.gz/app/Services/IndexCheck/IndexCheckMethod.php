<?php

/**
 * Интерфейс метода проверки индексации сайта в Яндексе.
 *
 * Реализации хранятся в app/Services/IndexCheck/. Текущие:
 *   - XmlStockIndexCheck         — основной (если enabled и ключи заданы)
 *   - WebmasterSummaryIndexCheck — getHostSummary, быстрая агрегация
 *   - WebmasterHistoryIndexCheck — getInSearchHistory, по дням
 *   - WebmasterSamplesIndexCheck — getInSearchSamples
 *   - WebmasterEventsIndexCheck  — getSearchEventSamples (APPEARED_IN_SEARCH)
 *
 * Добавление новых методов: создать новый класс с этим интерфейсом и
 * зарегистрировать в IndexCheckOrchestrator::buildMethods().
 *
 * Контракт checkIndexed():
 *   Возвращает массив:
 *     [
 *       'ok'              => bool,    // удалось вызвать API без ошибки
 *       'indexed'         => bool,    // сайт в индексе
 *       'pages_indexed'   => int,     // количество страниц в индексе (если знаем)
 *       'method'          => string,  // имя метода (для логирования)
 *       'message'         => string,  // human-readable
 *       'raw'             => mixed,   // raw response (для debug)
 *       'error'           => ?string, // если ok=false
 *     ]
 */
interface IndexCheckMethod
{
    /** Уникальное имя метода (для логов и UI). */
    public function getName(): string;

    /** Доступен ли метод (настройки заданы и т.д.). */
    public function isAvailable(): bool;

    /**
     * Главная проверка.
     *
     * @param string  $hostUrl  Полный URL хоста (например "https://newdomain.casino")
     * @param ?string $userId   Yandex userId (нужен для Webmaster API методов)
     * @param ?string $hostId   Yandex hostId (нужен для Webmaster API методов)
     * @return array Контракт см. в комментарии выше
     */
    public function checkIndexed(string $hostUrl, ?string $userId = null, ?string $hostId = null): array;
}
