<?php

/**
 * Применитель плана замен.
 *
 * Используется на стадии 'config_replaced' оркестратора.
 *
 * Алгоритм для каждого файла:
 *  1. Скачать актуальную версию через FTP (НЕ используем scan_dir, потому что
 *     между сканированием и применением кто-то мог изменить файл — race condition)
 *  2. Сохранить snapshot в /storage/snapshots/job_{N}/{filename}.before.txt
 *  3. Применить все замены этого файла через str_replace
 *     - Если before-строка не найдена → fail для этой замены
 *     - Если before-строка найдена несколько раз → fail (неоднозначно)
 *  4. Залить через FTP
 *
 * Если хотя бы один файл провалился — НЕ откатываем уже изменённые
 * (это сделает rollback() в контроллере на основе snapshot'ов).
 * Просто помечаем как failed и оставляем для пользователя.
 */
class ReplacementApplier
{
    private string $snapshotsBaseDir;

    public function __construct()
    {
        $this->snapshotsBaseDir = dirname(__DIR__, 2) . '/storage/snapshots';
        if (!is_dir($this->snapshotsBaseDir)) {
            @mkdir($this->snapshotsBaseDir, 0775, true);
        }
    }

    /**
     * Применить план.
     *
     * @return array {
     *   ok: bool,
     *   files_changed: int,
     *   replacements_applied: int,
     *   replacements_failed: int,
     *   snapshot_dir: string,
     *   snapshots: array<string, string>,  // имя файла → имя snapshot-файла
     *   per_file_results: array,           // подробности по каждому файлу
     *   errors: string[],
     * }
     */
    public function applyPlan(int $siteId, int $jobId, array $plan, JobEventLogger $log): array
    {
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return $this->errorResult("Site #{$siteId} not found");
        }

        $siteRoot = $this->resolveSiteRoot($site);
        if ($siteRoot === '') {
            return $this->errorResult("Cannot resolve site root path");
        }

        $snapshotDir = $this->snapshotsBaseDir . '/job_' . $jobId;
        if (!is_dir($snapshotDir)) {
            @mkdir($snapshotDir, 0775, true);
        }

        // Группируем замены по файлам
        $byFile = $this->groupByFile($plan['replacements'] ?? []);
        // AC01: config.php НИКОГДА не применяется generic-applier'ом — он полностью
        // на выделенном SiteConfigMutationService (exact-target pipeline).
        foreach (array_keys($byFile) as $fn) {
            if (basename((string)$fn) === 'config.php') {
                unset($byFile[$fn]);
                $log->warn('config_replaced', 'config.php пропущен generic-applier\'ом (dedicated mutation pipeline).');
            }
        }
        if (empty($byFile)) {
            $log->warn('config_replaced', 'План пуст — нечего применять');
            return [
                'ok' => true,
                'files_changed' => 0,
                'replacements_applied' => 0,
                'replacements_failed' => 0,
                'snapshot_dir' => $snapshotDir,
                'snapshots' => [],
                'per_file_results' => [],
                'errors' => [],
            ];
        }

        $log->info('config_replaced',
            'Применяю план: ' . count($byFile) . ' файлов, ' .
            array_sum(array_map('count', $byFile)) . ' замен');

        // Базовый путь — берём из плана (его нашёл сканер).
        // Если в плане не сохранился — fallback на siteRoot.
        $basePath = $plan['base_path'] ?? null;
        if ($basePath === null) {
            $basePath = $siteRoot;
            $log->warn('config_replaced',
                'В плане нет base_path, использую siteRoot: ' . $siteRoot);
        } else {
            $log->info('config_replaced',
                'Использую base_path из плана: ' . ($basePath === '' ? '(пустой = от FTP-корня)' : $basePath));
        }

        // Подключаемся к FTP
        try {
            $ftp = $this->makeFtp($site);
            $ftp->connect();
        } catch (\Throwable $e) {
            return $this->errorResult('FTP connect failed: ' . $e->getMessage());
        }

        $filesChanged = 0;
        $appliedTotal = 0;
        $failedTotal = 0;
        $snapshots = [];
        $perFile = [];
        $errors = [];

        foreach ($byFile as $fileName => $replacements) {
            $remoteAbs = $basePath === '' ? $fileName : (rtrim($basePath, '/') . '/' . $fileName);
            $fileResult = [
                'file' => $fileName,
                'replacements_applied' => 0,
                'replacements_failed' => 0,
                'snapshot' => null,
                'errors' => [],
            ];

            // 1. Скачать актуальный контент
            try {
                $content = $ftp->getContent($remoteAbs);
            } catch (\Throwable $e) {
                $fileResult['errors'][] = "download failed: " . $e->getMessage();
                $perFile[] = $fileResult;
                $errors[] = "{$fileName}: download failed";
                $failedTotal += count($replacements);
                continue;
            }

            // 2. Snapshot
            $snapshotName = $this->makeSnapshotName($fileName);
            $snapshotPath = $snapshotDir . '/' . $snapshotName;
            if (@file_put_contents($snapshotPath, $content) === false) {
                $fileResult['errors'][] = 'snapshot save failed';
                $perFile[] = $fileResult;
                $errors[] = "{$fileName}: snapshot save failed";
                $failedTotal += count($replacements);
                continue;
            }
            $snapshots[$fileName] = $snapshotName;
            $fileResult['snapshot'] = $snapshotName;

            // 3. Применить все замены поочерёдно
            $modified = $content;
            $localApplied = 0;
            $localFailed = 0;
            $appliedDetails = [];

            foreach ($replacements as $r) {
                $before = (string)($r['before'] ?? '');
                $after = (string)($r['after'] ?? '');
                if ($before === '' || $after === '' || $before === $after) {
                    $localFailed++;
                    $fileResult['errors'][] = 'invalid replacement (empty or same)';
                    continue;
                }

                // Проверяем сколько раз встречается before
                $count = substr_count($modified, $before);
                if ($count === 0) {
                    $localFailed++;
                    $fileResult['errors'][] = "before-string not found (line {$r['line']}, rule {$r['rule_id']})";
                    continue;
                }
                if ($count > 1) {
                    $localFailed++;
                    $fileResult['errors'][] = "before-string ambiguous ({$count} matches, line {$r['line']}, rule {$r['rule_id']})";
                    continue;
                }

                // Заменяем
                $newModified = str_replace($before, $after, $modified, $cnt);
                if ($cnt !== 1) {
                    // Не должно произойти после проверок выше, но защитимся
                    $localFailed++;
                    $fileResult['errors'][] = "str_replace returned unexpected count {$cnt}";
                    continue;
                }
                $modified = $newModified;
                $localApplied++;
                $appliedDetails[] = [
                    'line' => $r['line'] ?? null,
                    'rule_id' => $r['rule_id'] ?? null,
                ];
            }

            $fileResult['replacements_applied'] = $localApplied;
            $fileResult['replacements_failed'] = $localFailed;
            $fileResult['applied_details'] = $appliedDetails;

            // 4. Если хоть одна замена применилась — заливаем
            if ($localApplied > 0 && $modified !== $content) {
                try {
                    // v18-fix: НЕ создаём .bak.refresh-panel на FTP-стороне.
                    //
                    // Контекст: раньше putContent() создавал на FTP файл вида
                    //   .htaccess.bak.refresh-panel_20260508_113900
                    // на каждом запуске applier'а. За много джоб накапливалось
                    // 5-10+ .bak файлов на сайте — мусор, путал оператора.
                    //
                    // Snapshot сохраняется отдельно в storage/snapshots/job_N/
                    // на стороне панели (см. шаг 1 выше) — полная копия
                    // оригинала ПЕРЕД изменением. Откат идёт оттуда через
                    // ReplacementApplier::rollback() — кнопка «Откатить
                    // snapshot» в UI. Дублирование на FTP не нужно.
                    //
                    // Передаём backupExt = null чтобы putContent не делал .bak.
                    $ftp->putContent($remoteAbs, $modified, null);
                    $filesChanged++;
                } catch (\Throwable $e) {
                    $fileResult['errors'][] = 'upload failed: ' . $e->getMessage();
                    $errors[] = "{$fileName}: upload failed - " . $e->getMessage();
                    $localFailed += $localApplied;
                    $localApplied = 0;
                    $fileResult['replacements_applied'] = 0;
                    $fileResult['replacements_failed'] = $localFailed;
                }
            }

            $appliedTotal += $localApplied;
            $failedTotal += $localFailed;
            $perFile[] = $fileResult;

            if ($localApplied > 0) {
                $log->ok('config_replaced',
                    "✓ {$fileName}: применено {$localApplied} замен" .
                    ($localFailed > 0 ? ", провалилось {$localFailed}" : ''));
            } else {
                $log->warn('config_replaced',
                    "✗ {$fileName}: ни одна замена не применена" .
                    (!empty($fileResult['errors']) ? ' (' . implode('; ', $fileResult['errors']) . ')' : ''));
            }
        }

        $ftp->disconnect();

        $ok = ($failedTotal === 0 && $appliedTotal > 0);

        return [
            'ok' => $ok,
            'files_changed' => $filesChanged,
            'replacements_applied' => $appliedTotal,
            'replacements_failed' => $failedTotal,
            'snapshot_dir' => $snapshotDir,
            'snapshots' => $snapshots,
            'per_file_results' => $perFile,
            'errors' => $errors,
        ];
    }

    /**
     * Восстановить файлы из снапшотов (rollback).
     *
     * @return array {ok: bool, restored: array<string>, errors: string[]}
     */
    public function rollback(int $siteId, int $jobId, array $snapshots, JobEventLogger $log, ?string $basePath = null): array
    {
        $site = $this->loadSite($siteId);
        if ($site === null) {
            return ['ok' => false, 'restored' => [], 'errors' => ["Site #{$siteId} not found"]];
        }

        $siteRoot = $this->resolveSiteRoot($site);
        if ($siteRoot === '') {
            return ['ok' => false, 'restored' => [], 'errors' => ['Cannot resolve site root']];
        }

        // Если base_path не передан — fallback на siteRoot (старое поведение)
        if ($basePath === null) {
            $basePath = $siteRoot;
        }

        $snapshotDir = $this->snapshotsBaseDir . '/job_' . $jobId;
        if (!is_dir($snapshotDir)) {
            return ['ok' => false, 'restored' => [], 'errors' => ["Snapshot dir not found: {$snapshotDir}"]];
        }

        try {
            $ftp = $this->makeFtp($site);
            $ftp->connect();
        } catch (\Throwable $e) {
            return ['ok' => false, 'restored' => [], 'errors' => ['FTP connect failed: ' . $e->getMessage()]];
        }

        $restored = [];
        $errors = [];

        foreach ($snapshots as $fileName => $snapshotName) {
            $snapshotPath = $snapshotDir . '/' . $snapshotName;
            if (!is_file($snapshotPath)) {
                $errors[] = "{$fileName}: snapshot file not found ({$snapshotName})";
                continue;
            }
            $snapshotContent = @file_get_contents($snapshotPath);
            if ($snapshotContent === false) {
                $errors[] = "{$fileName}: cannot read snapshot";
                continue;
            }

            $remoteAbs = $basePath === '' ? $fileName : (rtrim($basePath, '/') . '/' . $fileName);
            try {
                $ftp->putContent($remoteAbs, $snapshotContent, null);
                $restored[] = $fileName;
                $log->ok('rollback', "↩ Восстановлен: {$fileName}");
            } catch (\Throwable $e) {
                $errors[] = "{$fileName}: upload failed - " . $e->getMessage();
                $log->error('rollback', "✗ {$fileName}: " . $e->getMessage());
            }
        }

        $ftp->disconnect();

        return [
            'ok' => empty($errors) && !empty($restored),
            'restored' => $restored,
            'errors' => $errors,
        ];
    }

    /**
     * Группировать массив замен по файлам.
     */
    private function groupByFile(array $replacements): array
    {
        $out = [];
        foreach ($replacements as $r) {
            $f = (string)($r['file'] ?? '');
            if ($f === '') continue;
            $out[$f][] = $r;
        }
        return $out;
    }

    /**
     * Имя файла снапшота. Заменяет точки на _ для безопасности
     * и добавляет суффикс .before.txt чтобы Apache не парсил .php-файлы.
     */
    private function makeSnapshotName(string $fileName): string
    {
        // .htaccess → htaccess_before.txt
        // config.php → config_php_before.txt
        $safe = ltrim($fileName, '.');
        $safe = str_replace(['.', '/', '\\'], '_', $safe);
        return $safe . '.before.txt';
    }

    private function errorResult(string $msg): array
    {
        return [
            'ok' => false,
            'files_changed' => 0,
            'replacements_applied' => 0,
            'replacements_failed' => 0,
            'snapshot_dir' => '',
            'snapshots' => [],
            'per_file_results' => [],
            'errors' => [$msg],
        ];
    }

    private function loadSite(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    private function resolveSiteRoot(array $site): string
    {
        $idx = trim((string)($site['fp_index_dir'] ?? ''));
        if ($idx !== '') return $idx;
        $owner = trim((string)($site['fp_site_owner'] ?? ''));
        $dom = trim((string)($site['current_domain'] ?? ''));
        if ($owner !== '' && $dom !== '') {
            return "/var/www/{$owner}/data/www/{$dom}";
        }
        return '';
    }

    private function makeFtp(array $site): FtpService
    {
        $host = trim((string)($site['ftp_host'] ?? ''));
        $user = trim((string)($site['ftp_user'] ?? ''));
        $pass = '';
        if (!empty($site['ftp_pass_enc'])) {
            try {
                $pass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            } catch (\Throwable $e) {}
        }

        if ($host === '') {
            $serverId = (int)($site['fastpanel_server_id'] ?? 0);
            if ($serverId > 0) {
                $st = DB::pdo()->prepare("SELECT host FROM fastpanel_servers WHERE id=?");
                $st->execute([$serverId]);
                $rawHost = (string)$st->fetchColumn();
                $rawHost = preg_replace('~^https?://~i', '', $rawHost);
                $rawHost = preg_replace('~:\d+$~', '', $rawHost);
                $rawHost = preg_replace('~/.*$~', '', $rawHost);
                $host = trim($rawHost);
            }
        }

        if ($host === '' || $user === '' || $pass === '') {
            throw new \RuntimeException('FTP credentials missing for site #' . ($site['id'] ?? '?'));
        }

        return new FtpService($host, $user, $pass, ['passive' => true, 'timeout' => 30]);
    }
}
