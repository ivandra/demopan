<?php

/**
 * v18: MoveStatusChecker
 *
 * Проверяет успешность заявки на переезд сайта через публичное Yandex API v4.
 *
 * Логика: у каждого host'а в Webmaster есть опциональное поле main_mirror.
 * Если у старого домена main_mirror.host_id указывает на новый домен — значит
 * Yandex обработал заявку на переезд успешно (host'ы стали зеркалами с new
 * как главным).
 *
 * Используется в стадии move_poll_status (multi-tick polling).
 *
 * НЕ использует cookies — только OAuth-токены через YandexWebmasterClient,
 * как все остальные wm_* стадии.
 */
class MoveStatusChecker
{
    // revision 2 §13/§19: контекст job/stage для аудита job-bound Yandex-запросов.
    private $ctxJobId = null;
    private $ctxStage = null;
    private $ctxLog = null;
    public function setJobContext(?int $jobId, ?string $stage, $log = null): void
    {
        $this->ctxJobId = $jobId; $this->ctxStage = $stage; $this->ctxLog = $log;
    }

    /** @var callable|null фабрика WM-клиента (accountId → client) для тестов. */
    private $clientFactory = null;
    public function setClientFactory(callable $f): void { $this->clientFactory = $f; }
    private function makeWmClient(int $accountId)
    {
        if ($this->clientFactory !== null) return ($this->clientFactory)($accountId);
        return new YandexWebmasterClient($accountId);
    }

    /**
     * Проверить статус переезда old → new в Webmaster аккаунте.
     *
     * @param int $accountId ID аккаунта в yandex_webmaster_accounts (для YandexWebmasterClient)
     * @param string $userId Yandex user-id (получен ранее в wm_account_resolve)
     * @param string $oldDomain Например "volna-205.casino"
     * @param string $newDomain Например "volna-206.casino"
     * @return array{
     *     status: string,
     *     reason: string,
     *     old_host_found: bool,
     *     old_host_main_mirror: ?string,
     *     hosts_count: int
     * }
     *
     * Возможные значения status:
     *   - 'success'        — main_mirror старого = новый (переезд успешен)
     *   - 'in_progress'    — старый ещё сам по себе (заявка обрабатывается)
     *   - 'wrong_mirror'   — main_mirror указывает не на наш новый (что-то пошло не так)
     *   - 'old_not_found'  — старого больше нет в Webmaster (странно)
     *   - 'api_error'      — ошибка вызова API
     */
    public function checkMoveStatus(
        int $accountId,
        string $userId,
        string $oldDomain,
        string $newDomain
    ): array {
        $result = [
            'status' => 'api_error',
            'reason' => '',
            'old_host_found' => false,
            'old_host_main_mirror' => null,
            'hosts_count' => 0,
        ];

        try {
            $client = $this->makeWmClient($accountId);
            // revision 2 §13/§19: job/stage context для аудита job-bound запросов move/status.
            if (method_exists($client, 'setRequestContext')) {
                try { $client->setRequestContext($this->ctxJobId, $this->ctxStage, $this->ctxLog); }
                catch (\Throwable $ctxE) { /* ignore */ }
            }
            $hosts = $client->getHosts($userId);
        } catch (\Throwable $e) {
            // revision 2 §13/§18: critical routing failure отличаем от обычного api_error.
            if (class_exists('WebmasterRoutingFailurePolicy') && WebmasterRoutingFailurePolicy::isCritical($e)) {
                $result['status'] = 'routing_error';
                $result['routing_reason'] = WebmasterRoutingFailurePolicy::reason($e);
                $result['reason'] = 'routing failure: ' . $e->getMessage();
                return $result;
            }
            $result['reason'] = 'getHosts failed: ' . $e->getMessage();
            return $result;
        }

        $result['hosts_count'] = count($hosts);

        // Найдём старый домен в списке
        $oldNorm = $this->normalizeDomain($oldDomain);
        $newNorm = $this->normalizeDomain($newDomain);

        $oldHost = null;
        foreach ($hosts as $h) {
            $hostDomain = $this->normalizeDomain((string)($h['unicode_host_url'] ?? $h['ascii_host_url'] ?? ''));
            if ($hostDomain === $oldNorm) {
                $oldHost = $h;
                break;
            }
        }

        if ($oldHost === null) {
            $result['status'] = 'old_not_found';
            $result['reason'] = "Старый домен {$oldDomain} не найден среди {$result['hosts_count']} хостов аккаунта";
            return $result;
        }

        $result['old_host_found'] = true;

        // Проверяем main_mirror у старого
        $mainMirror = $oldHost['main_mirror'] ?? null;
        if (!is_array($mainMirror) || empty($mainMirror)) {
            // main_mirror отсутствует — старый сам по себе главный, переезд ещё не обработан
            $result['status'] = 'in_progress';
            $result['reason'] = 'main_mirror у старого домена ещё не установлен';
            return $result;
        }

        $mainMirrorDomain = $this->normalizeDomain(
            (string)($mainMirror['unicode_host_url'] ?? $mainMirror['ascii_host_url'] ?? '')
        );
        $result['old_host_main_mirror'] = $mainMirrorDomain;

        if ($mainMirrorDomain === $newNorm) {
            $result['status'] = 'success';
            $result['reason'] = "main_mirror старого = {$newDomain} — переезд завершён";
            return $result;
        }

        // main_mirror установлен, но не на наш новый
        $result['status'] = 'wrong_mirror';
        $result['reason'] = "main_mirror = {$mainMirrorDomain}, ожидали {$newDomain}";
        return $result;
    }

    /**
     * Привести домен к каноническому виду: нижний регистр, без схемы, без / в конце,
     * без www.
     */
    private function normalizeDomain(string $raw): string
    {
        $d = trim(strtolower($raw));
        $d = preg_replace('~^https?://~', '', $d);
        $d = rtrim($d, '/');
        $d = preg_replace('~^www\.~', '', $d);
        return (string)$d;
    }
}
