<?php

/**
 * Построитель плана замен.
 *
 * На вход получает scan_dir со скачанными файлами + старый и новый домены.
 * Анализирует файлы по правилам-детекторам и строит ПЛАН замен.
 *
 * План — это список структур:
 *   [
 *     'file' => 'config.php',     // имя файла относительно scan_dir
 *     'kind' => 'php',
 *     'before' => "...exact line in file...",
 *     'after'  => "...modified line...",
 *     'rule_id' => 'php_var_domain',
 *     'reason' => 'PHP variable $domain',
 *   ]
 *
 * Правила (детекторы):
 *   - php_var_domain          : $domain = '...old_domain...' → '...new_domain...'
 *   - php_string_old_domain   : любая строка PHP содержащая old_domain
 *   - htaccess_url_old_domain : любая строка .htaccess со ссылкой на old_domain
 *   - sub_id_pattern          : 'sub_id=XXX' / 'sub_id'=>'XXX' / $sub_id='XXX' — инкремент XXX
 *
 * Никаких массовых замен. Только точечные паттерны со специфичными regex'ами.
 */
class ReplacementPlanBuilder
{
    /**
     * v4: artifacts_json джобы — источник неизменяемого snapshot'а маски.
     * Используется только для справки/логов: генерацию значений builder больше
     * не выполняет, он получает готовую пару old_sub_id → new_sub_id.
     * @var string
     */
    private $jobArtifactsJson = '';

    public function __construct(string $jobArtifactsJson = '')
    {
        $this->jobArtifactsJson = $jobArtifactsJson;
    }

    /**
     * @param string $oldSubId v4 (B2): ТОЧНОЕ старое значение sub_id из конфига сайта.
     * @param string $newSubId v4 (B2): ТОЧНОЕ новое значение (посчитано заранее по домену).
     *
     * Раньше builder сам генерировал новое значение для КАЖДОГО tracking-параметра
     * (btag, tag, click_id, pid, aff_id, s1..s5) через маску. После перехода на
     * «число из домена» это стало разрушительным: click_id=click999 превращался
     * в click20, pid=42 → 20, tag=summer2026 → summer20, то есть уничтожались
     * уникальные click ID, ID партнёра и метки кампаний.
     * Теперь меняется ТОЛЬКО sub_id и только при точном совпадении значения.
     */
    public function buildPlan(
        string $scanDir,
        string $oldDomain,
        string $newDomain,
        JobEventLogger $log,
        string $oldSubId = '',
        string $newSubId = ''
    ): array {
        if (!is_dir($scanDir)) {
            return ['ok' => false, 'errors' => ["Scan dir not found: {$scanDir}"], 'replacements' => []];
        }

        $oldDomainBare = $this->stripScheme($oldDomain);
        $newDomainBare = $this->stripScheme($newDomain);

        $replacements = [];
        $totalFilesScanned = 0;

        $files = $this->listScannedFiles($scanDir);
        foreach ($files as $localPath) {
            $name = basename($localPath);
            $totalFilesScanned++;

            $content = @file_get_contents($localPath);
            if ($content === false) {
                continue;
            }

            $kind = $this->classifyFile($name);

            // 1) Замены домена (работают везде)
            $domainReps = $this->findDomainReplacements(
                $content, $name, $kind,
                $oldDomainBare, $newDomainBare
            );

            // 2) Замена sub_id — только точная пара old → new, только sub_id-параметры
            $subIdReps = $this->findSubIdReplacementsExact(
                $content, $name, $kind, $oldSubId, $newSubId
            );

            // 3) v4 (B3): склеиваем замены ОДНОЙ строки в одну запись.
            // Раньше домен и sub_id давали две записи с одинаковым 'before' и разными
            // 'after'. ReplacementApplier применяет их последовательно по точному
            // совпадению before, поэтому после первой замены вторая падала с
            // "before-string not found": домен обновлялся, а sub_id оставался старым.
            $merged = $this->mergeLineReplacements($domainReps, $subIdReps, $oldSubId, $newSubId);
            $replacements = array_merge($replacements, $merged);
        }

        // Дедупликация: одинаковая замена в одном файле не должна повторяться
        $replacements = $this->dedupReplacements($replacements);

        $log->info('analyze_site',
            "Сканер: проверено файлов: {$totalFilesScanned}, найдено потенциальных замен: " . count($replacements));

        return [
            'ok' => true,
            'old_domain' => $oldDomain,
            'new_domain' => $newDomain,
            'replacements' => $replacements,
            'files_scanned' => $totalFilesScanned,
        ];
    }

    /**
     * Найти замены домена в контенте.
     * Работает для PHP, .htaccess, robots.txt одинаково — ищем везде в строках.
     */
    private function findDomainReplacements(
        string $content,
        string $fileName,
        string $kind,
        string $oldDomain,
        string $newDomain
    ): array {
        $reps = [];

        if ($oldDomain === '' || $newDomain === '' || $oldDomain === $newDomain) {
            return $reps;
        }

        // === v14i FIX ===
        // current_domain в БД может содержать www. (в зависимости от того что
        // FastPanel отдал при импорте). А в config.php обычно записано без www
        // ($domain = 'https://volna-202.casino';). Поэтому ищем ОБЕ версии:
        // www.X и X. Заменяем на newDomain без www.
        $oldDomainCanonical = preg_replace('~^www\.~i', '', $oldDomain);
        $newDomainCanonical = preg_replace('~^www\.~i', '', $newDomain);

        $domainsToFind = [$oldDomainCanonical];
        if ($oldDomain !== $oldDomainCanonical) {
            // если изначально был www — добавим его впереди (чтобы матчилось более
            // длинное сначала), но canonical всё равно будет проверен
            array_unshift($domainsToFind, $oldDomain);
        }
        // также добавим www-версию canonical (на случай если в файле явно с www)
        $wwwVariant = 'www.' . $oldDomainCanonical;
        if (!in_array($wwwVariant, $domainsToFind, true)) {
            array_unshift($domainsToFind, $wwwVariant);
        }

        // Работаем построчно, чтобы before/after были хорошо локализованы
        $lines = preg_split('/\R/', $content);
        if ($lines === false) return $reps;

        // v18-fix: для .htaccess пропускаем строки которые являются частью
        // цепочки SEO-редиректов между доменами (RewriteCond %{HTTP_HOST} + RewriteRule).
        //
        // Контекст: на sykaaa-casino-сайтах есть цепочка:
        //   RewriteCond %{HTTP_HOST} ^(www\.)?casino\.top$ [NC]
        //   RewriteRule ^ https://casino1.top%{REQUEST_URI} [R=301,L]
        //   RewriteCond %{HTTP_HOST} ^(www\.)?casino1\.top$ [NC]
        //   RewriteRule ^ https://casino2.top%{REQUEST_URI} [R=301,L]
        //   ...
        //
        // При переезде casino4 → casino5 НЕЛЬЗЯ трогать строку
        // "RewriteRule ^ https://casino4.top%{REQUEST_URI}" — она часть
        // цепочки casino3 → casino4 (читать: "если HTTP_HOST = casino3, редирект на casino4").
        //
        // Новая пара "RewriteCond casino4 / RewriteRule casino5" будет
        // ДОБАВЛЕНА в конец файла стадией move_htaccess_redirect.
        // А найти текущие строки этой цепочки и заменить — НЕЛЬЗЯ, иначе
        // получится `casino3 → casino5` (минуя casino4), что ломает SEO.
        //
        // Эвристика: если строка — RewriteCond с %{HTTP_HOST} ИЛИ RewriteRule
        // у которой ПРЕДЫДУЩАЯ непустая строка — RewriteCond с %{HTTP_HOST},
        // то это часть цепочки → не трогать.
        // v5 (P3): доменные замены тоже пропускают комментарии. Раньше фильтр
        // применялся только к sub_id, поэтому в план попадали исторические маркеры
        // вида "# === Refresh Panel: redirect A → B" и примеры в docblock'ах:
        // маркер начинал указывать на новый домен, хотя описывал прошлую операцию.
        // (Маркеры панель только пишет и никогда не парсит — менять их не нужно.)
        $skipLineIdx = $this->commentLineIndex($content, $kind);

        if ($kind === 'htaccess') {
            $prevNonEmpty = null;
            foreach ($lines as $idx => $rawLine) {
                $trim = trim($rawLine);
                if ($trim === '' || $trim[0] === '#') {
                    // не сдвигаем prevNonEmpty (комменты и пустые между правилами игнорируем)
                    continue;
                }

                $isHostCond = (bool)preg_match('~^\s*RewriteCond\s+%\{HTTP_HOST\}~i', $rawLine);
                $isRewriteRule = (bool)preg_match('~^\s*RewriteRule~i', $rawLine);

                if ($isHostCond) {
                    $skipLineIdx[$idx] = true;
                } elseif ($isRewriteRule && $prevNonEmpty !== null) {
                    // Если prevNonEmpty — RewriteCond %{HTTP_HOST}, эта RewriteRule — часть цепочки
                    $prevLine = $lines[$prevNonEmpty] ?? '';
                    if (preg_match('~^\s*RewriteCond\s+%\{HTTP_HOST\}~i', $prevLine)) {
                        $skipLineIdx[$idx] = true;
                    }
                }

                $prevNonEmpty = $idx;
            }
        }

        foreach ($lines as $lineNum => $line) {
            // v18-fix: пропускаем строки доменной цепочки
            if (isset($skipLineIdx[$lineNum])) {
                continue;
            }

            $newLine = $line;
            $changed = false;

            // Идём по domainsToFind в порядке: сначала длинные (с www) чтобы не разорвать
            // www.foo.com → newdomain.com www.<orig> (порядок важен)
            foreach ($domainsToFind as $candidate) {
                $regex = '~(?<![a-zA-Z0-9.-])' . preg_quote($candidate, '~') . '(?![a-zA-Z0-9-])~';
                if (preg_match($regex, $newLine)) {
                    // Если кандидат с www → заменяем на www.newCanonical
                    // Если без www → на newCanonical
                    $replacement = (stripos($candidate, 'www.') === 0)
                        ? 'www.' . $newDomainCanonical
                        : $newDomainCanonical;
                    $newLine = preg_replace($regex, $replacement, $newLine);
                    $changed = true;
                }
            }

            if ($changed && $newLine !== $line) {
                $ruleId = $this->classifyDomainReplacement($line, $kind);
                $reps[] = [
                    'file' => $fileName,
                    'kind' => $kind,
                    'line' => $lineNum + 1,
                    'before' => $line,
                    'after' => $newLine,
                    'rule_id' => $ruleId,
                    'reason' => $this->explainDomainRule($ruleId, $kind),
                ];
            }
        }

        return $reps;
    }

    /**
     * v4 (B2): замена sub_id по ТОЧНОЙ паре old → new.
     *
     * Меняются только параметры sub_id / subid / sub и только если значение
     * в точности равно $oldSubId. Все прочие tracking-идентификаторы
     * (btag, tag, click_id, clickid, click, pid, aff_sub, aff_id, s1..s5)
     * не трогаются: это уникальные click ID, ID партнёра и метки кампаний,
     * пересобирать их по номеру домена нельзя.
     */
    private function findSubIdReplacementsExact(
        string $content,
        string $fileName,
        string $kind,
        string $oldSubId,
        string $newSubId
    ): array {
        // config.php полностью на выделенном SiteConfigMutationService (exact-target
        // pipeline). Builder НЕ содержит собственного распознавания форм sub_id и не
        // порождает sub_id-замен; config.php исключается из generic apply (AC01).
        // Здесь builder отвечает ТОЛЬКО за домен остальных файлов.
        return [];
    }

    /**
     * sub_id-формы больше не определяются в builder (config.php — на mutation service).
     * Метод оставлен как no-op для совместимости вызовов из merge-логики.
     */
    private function transformSubIdInLine(string $line, string $oldSubId, string $newSubId): array
    {
        return ['line' => $line, 'changed' => false, 'count' => 0, 'reason' => ''];
    }

    /**
     * v5 (P3): индекс строк, состоящих ТОЛЬКО из комментария.
     *
     * Возвращает [0-based индекс строки => true].
     *
     * Для PHP используется token_get_all: строится «маска» контента, где символы
     * комментариев заменены пробелами. Строка считается комментарной, только если
     * после этого в ней не осталось непробельного содержимого. Это важно —
     * иначе строка вида
     *     $domain = 'https://old.casino'; // старый домен
     * была бы ошибочно пропущена целиком вместе с реальным кодом.
     *
     * Для .htaccess и robots.txt — строки, начинающиеся с '#'.
     */
    private function commentLineIndex(string $content, string $kind): array
    {
        $idx = [];
        $lines = preg_split('/\R/', $content);
        if ($lines === false) return $idx;

        if ($kind === 'htaccess' || $kind === 'robots_txt') {
            foreach ($lines as $i => $l) {
                $t = ltrim($l);
                if ($t !== '' && $t[0] === '#') $idx[$i] = true;
            }
            return $idx;
        }

        if ($kind !== 'php') {
            return $idx;
        }

        $tokens = null;
        try {
            $tokens = @token_get_all($content);
        } catch (\Throwable $e) {
            $tokens = null;
        }

        if (!is_array($tokens) || !$tokens) {
            // Фолбэк: построчная эвристика (файл не разобрался как PHP)
            foreach ($lines as $i => $l) {
                $t = ltrim($l);
                if ($t === '') continue;
                if (strpos($t, '//') === 0 || strpos($t, '#') === 0
                    || strpos($t, '/*') === 0 || strpos($t, '*') === 0) {
                    $idx[$i] = true;
                }
            }
            return $idx;
        }

        // Гасим содержимое комментариев пробелами, сохраняя переводы строк
        $masked = $content;
        $pos = 0;
        foreach ($tokens as $t) {
            $text = is_array($t) ? $t[1] : $t;
            $len = strlen($text);
            if (is_array($t) && ($t[0] === T_COMMENT || $t[0] === T_DOC_COMMENT)) {
                for ($i = $pos; $i < $pos + $len && $i < strlen($masked); $i++) {
                    if ($masked[$i] !== "\n" && $masked[$i] !== "\r") {
                        $masked[$i] = ' ';
                    }
                }
            }
            $pos += $len;
        }

        $maskedLines = preg_split('/\R/', $masked);
        if ($maskedLines === false) return $idx;

        foreach ($lines as $i => $orig) {
            if (trim($orig) === '') continue;
            $m = $maskedLines[$i] ?? '';
            if (trim($m) === '') {
                $idx[$i] = true; // в строке не осталось ничего, кроме комментария
            }
        }

        return $idx;
    }

    /**
     * v4 (B3): объединяет замены домена и sub_id, относящиеся к ОДНОЙ строке,
     * в одну запись before → final_after.
     *
     * Для строк, где сработали оба правила, sub_id-замена применяется поверх уже
     * изменённой доменом строки — так итоговый after содержит обе правки, а
     * ReplacementApplier видит ровно одну запись на строку.
     */
    private function mergeLineReplacements(
        array $domainReps,
        array $subIdReps,
        string $oldSubId,
        string $newSubId
    ): array {
        $byKey = [];

        foreach ($domainReps as $r) {
            $byKey[$r['file'] . '|' . $r['line']] = $r;
        }

        foreach ($subIdReps as $r) {
            $key = $r['file'] . '|' . $r['line'];

            if (!isset($byKey[$key])) {
                $byKey[$key] = $r;
                continue;
            }

            // Строку уже меняет доменное правило — накладываем sub_id поверх результата.
            $base = $byKey[$key];
            $t = $this->transformSubIdInLine($base['after'], $oldSubId, $newSubId);

            $base['after']   = $t['changed'] ? $t['line'] : $base['after'];
            $base['rule_id'] = $base['rule_id'] . '+sub_id_exact';
            $base['reason']  = $base['reason'] . ' | ' . $r['reason'];
            $byKey[$key] = $base;
        }

        return array_values($byKey);
    }

    private function classifyDomainReplacement(string $line, string $fileKind): string
    {
        $trimmed = ltrim($line);

        if ($fileKind === 'htaccess') {
            if (preg_match('~^\s*(Redirect|RewriteRule|RewriteCond)~i', $trimmed)) {
                return 'htaccess_directive_url';
            }
            return 'htaccess_url';
        }

        if ($fileKind === 'php') {
            if (preg_match('~\$domain\s*=~', $trimmed)) {
                return 'php_var_domain';
            }
            if (preg_match('~\$\w+\s*=\s*[\'"]~', $trimmed)) {
                return 'php_var_url';
            }
            if (preg_match('~^\s*//|^\s*/\*|^\s*\*~', $trimmed)) {
                return 'php_comment';
            }
            return 'php_string_url';
        }

        return 'plain_url';
    }

    private function explainDomainRule(string $ruleId, string $kind): string
    {
        $map = [
            'php_var_domain'        => 'PHP variable $domain assignment',
            'php_var_url'           => 'PHP variable holding URL',
            'php_string_url'        => 'PHP string with URL',
            'php_comment'           => '⚠ in PHP comment (will be replaced anyway)',
            'htaccess_directive_url'=> '.htaccess directive (Redirect/RewriteRule/RewriteCond)',
            'htaccess_url'          => '.htaccess line containing URL',
            'plain_url'             => 'plain text URL',
        ];
        return $map[$ruleId] ?? $ruleId;
    }

    /**
     * Дедуплицируем — иногда два правила могут зацепить одно изменение.
     * Ключ дедупликации: file + before + after.
     */
    private function dedupReplacements(array $reps): array
    {
        $seen = [];
        $out = [];
        foreach ($reps as $r) {
            $key = $r['file'] . '|' . $r['before'] . '|' . $r['after'];
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $out[] = $r;
        }
        return $out;
    }

    /**
     * Список файлов в scan_dir (плоско, не рекурсивно).
     */
    private function listScannedFiles(string $scanDir): array
    {
        $out = [];
        $dh = @opendir($scanDir);
        if (!$dh) return $out;
        while (($entry = readdir($dh)) !== false) {
            if ($entry === '.' || $entry === '..') continue;
            $full = $scanDir . '/' . $entry;
            if (is_file($full)) $out[] = $full;
        }
        closedir($dh);
        sort($out);
        return $out;
    }

    private function classifyFile(string $name): string
    {
        $lower = strtolower($name);
        if ($lower === '.htaccess') return 'htaccess';
        if ($lower === 'robots.txt') return 'robots_txt';
        if (substr($lower, -4) === '.php') return 'php'; // v4 (H3): PHP 7.4-совместимо
        return 'unknown';
    }

    /**
     * Извлекает голый домен из строки (без https://, без слеша).
     */
    private function stripScheme(string $url): string
    {
        $u = trim($url);
        $u = preg_replace('~^https?://~i', '', $u);
        $u = preg_replace('~/.*$~', '', $u);
        return strtolower(trim($u));
    }
}
