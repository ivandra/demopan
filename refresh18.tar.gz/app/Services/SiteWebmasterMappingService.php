<?php

/**
 * Управление привязками site → Yandex.Webmaster account.
 *
 * Логика поиска аккаунта по старому домену (с кешем):
 *   1. Смотрим в site_webmaster_links для (siteId, oldDomain) — если есть, берём
 *   2. Иначе пробегаем по всем yandex_webmaster_accounts (active+non-empty token):
 *      для каждого вызываем YandexWebmasterClient::findHostInAccount()
 *   3. Если найден — записываем в site_webmaster_links и возвращаем
 *   4. Если ни в одном не найден — null (нужно либо создать вручную, либо
 *      использовать override_id из формы джобы)
 *
 * Также этот сервис управляет состоянием уже привязанных хостов — verified,
 * sitemap_added и т.д. — для UI и для логики стадий.
 */
class SiteWebmasterMappingService
{
    // revision 2 §10/§19: контекст job/stage для аудита job-bound Yandex-запросов.
    private $ctxJobId = null;
    private $ctxStage = null;
    private $ctxLog = null;

    public function setJobContext(?int $jobId, ?string $stage, $log = null): void
    {
        $this->ctxJobId = $jobId;
        $this->ctxStage = $stage;
        $this->ctxLog = $log;
    }

    /** @var callable|null фабрика WM-клиента (accountId → client) для тестов. */
    private $clientFactory = null;
    public function setClientFactory(callable $f): void { $this->clientFactory = $f; }
    private function makeWmClient(int $accountId)
    {
        if ($this->clientFactory !== null) return ($this->clientFactory)($accountId);
        return new YandexWebmasterClient($accountId);
    }

    /**
     * Ищет аккаунт Webmaster которому принадлежит данный домен.
     *
     * Логика:
     *   1. Кеш для текущего old_domain → use it
     *   2. API: ищем old_domain в каждом аккаунте → нашли → use it
     *   3. v17.4 CASCADE: fallback по другим алиасам сайта из sites_managed.aliases.
     *      Берём список всех алиасов сайта, исключаем текущий old_domain и new_domain,
     *      нормализуем (без www, lowercase, dedupe), пробуем каждый по порядку.
     *      На первом найденном → возвращаем (его и привяжем к этому сайту в БД).
     *   4. Ничего не нашли → null (в стадии = awaiting_user)
     *
     * @return ?array site_webmaster_links row + ['source' => 'cache'|'api'|'cascade'] + ['matched_domain' => ?string]
     */
    public function resolveAccountForDomain(int $siteId, string $domain, JobEventLogger $log, string $newDomain = ''): ?array
    {
        $domain = $this->normalizeDomain($domain);
        if ($domain === '') return null;

        // 1. Кеш для основного запрашиваемого домена
        $cached = $this->getCachedLink($siteId, $domain);
        if ($cached !== null) {
            $log->info('wm_account_resolve',
                "Аккаунт найден в кеше (БД): account_id={$cached['webmaster_account_id']}, " .
                "user_id={$cached['user_id']}, host_id={$cached['host_id']}");
            $cached['source'] = 'cache';
            $cached['matched_domain'] = $domain;
            return $cached;
        }

        // 2. Прямой поиск old_domain в API всех аккаунтов
        $accounts = $this->loadAllAccounts();
        if (empty($accounts)) {
            $log->error('wm_account_resolve',
                'Нет аккаунтов Yandex.Webmaster в БД! Авторизуйся через /system/webmaster-tokens');
            return null;
        }

        $log->info('wm_account_resolve',
            "Кеша нет. Шаг 1/2: ищу '{$domain}' среди " . count($accounts) . " аккаунтов...");

        $found = $this->searchDomainInAllAccounts($accounts, $domain, $log);
        if ($found !== null) {
            $row = $this->saveFoundDomain($siteId, $domain, $found, $log);
            if ($row !== null) {
                $row['source'] = 'api';
                $row['matched_domain'] = $domain;
            }
            return $row;
        }

        // 3. v17.4 CASCADE: fallback по aliases
        $log->info('wm_account_resolve',
            "Шаг 2/2: основной домен не найден. Пробую cascade fallback по aliases сайта...");

        $candidates = $this->getCascadeCandidates($siteId, $domain, $newDomain);
        if (empty($candidates)) {
            $log->warn('wm_account_resolve',
                "Aliases сайта пусты или все исключены. Cascade невозможен.");
            $log->warn('wm_account_resolve',
                "Домен '{$domain}' НЕ найден ни в одном аккаунте Webmaster (cascade тоже не помог).");
            return null;
        }

        $log->info('wm_account_resolve',
            "Cascade кандидаты (" . count($candidates) . "): " . implode(', ', $candidates));

        foreach ($candidates as $candidateDomain) {
            $log->info('wm_account_resolve',
                "  Cascade: пробую '{$candidateDomain}'...");

            $found = $this->searchDomainInAllAccounts($accounts, $candidateDomain, $log);
            if ($found !== null) {
                $log->ok('wm_account_resolve',
                    "  ✓ Cascade успех: '{$candidateDomain}' найден в аккаунте #{$found['account_id']}");

                // Сохраняем кеш ПО НАЙДЕННОМУ домену (не по запрошенному)
                $row = $this->saveFoundDomain($siteId, $candidateDomain, $found, $log);
                if ($row !== null) {
                    $row['source'] = 'cascade';
                    $row['matched_domain'] = $candidateDomain;
                }
                return $row;
            }
        }

        $log->warn('wm_account_resolve',
            "Домен '{$domain}' НЕ найден ни в одном аккаунте Webmaster (даже через cascade по " .
            count($candidates) . " кандидатам).");
        return null;
    }

    /**
     * v17.4: ищет указанный домен во всех аккаунтах. Возвращает первый найденный.
     * @return ?array ['account_id', 'account_label', 'user_id', 'host_id', 'host', 'verified']
     */
    private function searchDomainInAllAccounts(array $accounts, string $domain, JobEventLogger $log): ?array
    {
        foreach ($accounts as $account) {
            $accId = (int)$account['id'];
            $label = (string)($account['label'] ?? $account['email'] ?? "id={$accId}");

            try {
                $client = $this->makeWmClient($accId);
                // revision 2 §10/§19: job/stage context для аудита job-bound запросов resolve.
                if (method_exists($client, 'setRequestContext')) {
                    try { $client->setRequestContext($this->ctxJobId, $this->ctxStage ?? 'wm_account_resolve', $this->ctxLog); }
                    catch (\Throwable $ctxE) { /* ignore */ }
                }
                $userId = $client->getUserId();
                $host = $client->findHostInAccount($userId, $domain);
                if ($host === null) {
                    $log->info('wm_account_resolve',
                        "    ✗ {$label}: '{$domain}' не найден");
                    continue;
                }

                $hostId = (string)($host['host_id'] ?? '');
                $log->info('wm_account_resolve',
                    "    ✓ {$label}: '{$domain}' НАЙДЕН (host_id={$hostId})");

                return [
                    'account_id' => $accId,
                    'account_label' => $label,
                    'user_id' => $userId,
                    'host_id' => $hostId,
                    'host' => $host,
                    'verified' => $this->isHostVerified($host),
                ];
            } catch (\Throwable $e) {
                // revision 2 §9/§10: critical routing failure НЕ считаем «очередным неудачным
                // аккаунтом». Пробрасываем — resolve-стадия остановит job (awaiting_user), иначе
                // выдали бы ложное «домен не найден» при реальной ошибке исходящего IP.
                if (WebmasterRoutingFailurePolicy::isCritical($e)) throw $e;
                $log->warn('wm_account_resolve',
                    "    ⚠ {$label}: API упал — {$e->getMessage()}");
                continue;
            }
        }

        return null;
    }

    /**
     * v17.4: сохраняет найденный домен в site_webmaster_links и возвращает row.
     */
    private function saveFoundDomain(int $siteId, string $domain, array $found, JobEventLogger $log): ?array
    {
        $this->upsertLink([
            'site_id' => $siteId,
            'domain' => $domain,
            'webmaster_account_id' => (int)$found['account_id'],
            'user_id' => (string)$found['user_id'],
            'host_id' => (string)$found['host_id'],
            'verified' => !empty($found['verified']) ? 1 : 0,
        ]);

        return $this->getCachedLink($siteId, $domain);
    }

    /**
     * v17.4: собирает cascade-кандидатов из sites_managed.aliases.
     * Исключает: $excludeDomain (текущий old_domain), $newDomain (новый который скоро купим),
     * www-префиксы, дубликаты, пустые.
     */
    private function getCascadeCandidates(int $siteId, string $excludeDomain, string $newDomain = ''): array
    {
        $excludeDomain = $this->normalizeDomain($excludeDomain);
        $newDomain = $this->normalizeDomain($newDomain);

        try {
            $st = DB::pdo()->prepare("SELECT aliases, current_domain FROM sites_managed WHERE id = ?");
            $st->execute([$siteId]);
            $row = $st->fetch();
            if (!$row) return [];
        } catch (\Throwable $e) {
            return [];
        }

        $candidates = [];

        // 1. aliases JSON
        $aliasesJson = (string)($row['aliases'] ?? '');
        if ($aliasesJson !== '') {
            $aliases = json_decode($aliasesJson, true);
            if (is_array($aliases)) {
                foreach ($aliases as $a) {
                    $a = $this->normalizeDomain((string)$a);
                    if ($a !== '') $candidates[$a] = true;
                }
            }
        }

        // 2. Также добавляем current_domain (на всякий случай — может отличаться от excludeDomain)
        $current = $this->normalizeDomain((string)($row['current_domain'] ?? ''));
        if ($current !== '') $candidates[$current] = true;

        // Исключаем то что уже пробовали и новый
        unset($candidates[$excludeDomain]);
        if ($newDomain !== '') unset($candidates[$newDomain]);

        return array_keys($candidates);
    }

    /**
     * Принудительно создать привязку — для override через форму джобы.
     * Если хост ещё не существует в этом аккаунте — НЕ добавляем (это делает
     * стадия wm_added). Просто записываем намерение.
     */
    public function createOverrideLink(int $siteId, string $domain, int $accountId): int
    {
        return $this->upsertLink([
            'site_id' => $siteId,
            'domain' => $this->normalizeDomain($domain),
            'webmaster_account_id' => $accountId,
            'user_id' => '',  // получим при wm_added
            'host_id' => '',  // получим при wm_added
            'verified' => 0,
        ]);
    }

    /**
     * Берёт привязку из кеша.
     */
    public function getCachedLink(int $siteId, string $domain): ?array
    {
        $domain = $this->normalizeDomain($domain);
        $st = DB::pdo()->prepare(
            "SELECT * FROM site_webmaster_links
             WHERE site_id = ? AND domain = ? AND removed_at IS NULL
             LIMIT 1"
        );
        $st->execute([$siteId, $domain]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /**
     * Все привязки для сайта (включая удалённые).
     */
    public function getAllLinksForSite(int $siteId): array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM site_webmaster_links
             WHERE site_id = ?
             ORDER BY created_at DESC"
        );
        $st->execute([$siteId]);
        return $st->fetchAll();
    }

    /**
     * INSERT ON DUPLICATE KEY UPDATE привязки.
     * Возвращает id строки.
     */
    public function upsertLink(array $data): int
    {
        $domain = $this->normalizeDomain((string)$data['domain']);

        $st = DB::pdo()->prepare(
            "INSERT INTO site_webmaster_links
                (site_id, domain, webmaster_account_id, user_id, host_id, verified,
                 verification_uin, verification_file, sitemap_added, recrawl_requested, indexed)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                webmaster_account_id = VALUES(webmaster_account_id),
                user_id = IF(VALUES(user_id) <> '', VALUES(user_id), user_id),
                host_id = IF(VALUES(host_id) <> '', VALUES(host_id), host_id),
                verified = GREATEST(verified, VALUES(verified)),
                removed_at = NULL,
                updated_at = NOW()"
        );
        $st->execute([
            (int)$data['site_id'],
            $domain,
            (int)$data['webmaster_account_id'],
            (string)($data['user_id'] ?? ''),
            (string)($data['host_id'] ?? ''),
            (int)($data['verified'] ?? 0),
            (string)($data['verification_uin'] ?? ''),
            (string)($data['verification_file'] ?? ''),
            (int)($data['sitemap_added'] ?? 0),
            (int)($data['recrawl_requested'] ?? 0),
            (int)($data['indexed'] ?? 0),
        ]);

        // Узнаём id
        $st2 = DB::pdo()->prepare(
            "SELECT id FROM site_webmaster_links WHERE site_id=? AND domain=? LIMIT 1"
        );
        $st2->execute([(int)$data['site_id'], $domain]);
        return (int)$st2->fetchColumn();
    }

    /**
     * Обновить произвольные поля привязки.
     */
    public function updateLink(int $siteId, string $domain, array $fields): void
    {
        $domain = $this->normalizeDomain($domain);
        if (empty($fields)) return;

        $allowed = ['user_id', 'host_id', 'verified', 'verification_uin',
                    'verification_file', 'sitemap_added', 'recrawl_requested',
                    'indexed', 'indexed_pages_count'];

        $sets = [];
        $params = [];
        foreach ($fields as $key => $val) {
            if (!in_array($key, $allowed, true)) continue;
            $sets[] = "{$key} = ?";
            $params[] = $val;
        }
        if (empty($sets)) return;

        $params[] = $siteId;
        $params[] = $domain;

        $sql = "UPDATE site_webmaster_links SET " . implode(', ', $sets) .
               " WHERE site_id = ? AND domain = ?";
        DB::pdo()->prepare($sql)->execute($params);
    }

    /**
     * Помечаем link удалённым (после deleteHost из старого аккаунта).
     */
    public function markRemoved(int $siteId, string $domain): void
    {
        $domain = $this->normalizeDomain($domain);
        DB::pdo()->prepare(
            "UPDATE site_webmaster_links SET removed_at = NOW() WHERE site_id = ? AND domain = ?"
        )->execute([$siteId, $domain]);
    }

    /**
     * Загружает все валидные аккаунты (с токеном).
     */
    public function loadAllAccounts(): array
    {
        $st = DB::pdo()->query(
            "SELECT * FROM yandex_webmaster_accounts
             WHERE access_token_enc IS NOT NULL AND access_token_enc <> ''
             ORDER BY is_default DESC, host_count DESC, id ASC"
        );
        return $st->fetchAll();
    }

    private function isHostVerified(array $host): bool
    {
        $vState = (string)($host['verified'] ?? $host['verification_state'] ?? '');
        if ($vState === 'true' || $vState === '1' || $vState === 'VERIFIED') return true;
        if (isset($host['verified']) && $host['verified'] === true) return true;
        return false;
    }

    private function normalizeDomain(string $domain): string
    {
        $d = preg_replace('~^https?://~i', '', trim($domain));
        $d = preg_replace('~/.*$~', '', $d);
        $d = preg_replace('~:\d+$~', '', $d);
        $d = strtolower(rtrim($d, '.'));
        // v17.4: режем www. префикс чтобы избежать дубликатов в кандидатах cascade.
        // findHostInAccount() в YandexWebmasterClient всё равно умеет искать с/без www.
        $d = preg_replace('~^www\.~', '', $d);
        return $d;
    }
}
