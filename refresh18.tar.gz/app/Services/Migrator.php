<?php

class Migrator
{
    public function ensureMigrationsTable(): void
    {
        try {
            DB::pdo()->exec("CREATE TABLE IF NOT EXISTS migrations (
                id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(128) NOT NULL UNIQUE,
                applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch (Throwable $e) {
            // ignore
        }
    }

    public function listMigrations(): array
    {
        $dir = Paths::appRoot() . '/app/Migrations';
        $files = glob($dir . '/*.php') ?: [];
        sort($files);
        $out = [];
        foreach ($files as $f) {
            $out[] = ['file' => $f, 'name' => basename($f, '.php')];
        }
        return $out;
    }

    public function appliedNames(): array
    {
        $rows = DB::pdo()->query("SELECT name FROM migrations")->fetchAll();
        $out = [];
        foreach ($rows as $r) $out[$r['name']] = true;
        return $out;
    }

    /**
     * Применить все непримененные миграции. Возвращает массив с отчетом.
     */
    public function migrate(): array
    {
        $this->ensureMigrationsTable();
        $applied = $this->appliedNames();
        $report = ['ok' => true, 'ran' => [], 'errors' => []];

        foreach ($this->listMigrations() as $m) {
            if (isset($applied[$m['name']])) continue;

            $def = require $m['file'];
            if (!is_array($def) || empty($def['up'])) {
                $report['errors'][] = $m['name'] . ': bad definition';
                continue;
            }

            try {
                foreach ($def['up'] as $step) {
                    // v18.1.28: step может быть строкой SQL ИЛИ callable
                    // для сложных idempotent проверок (например, ADD COLUMN
                    // только если колонки нет — потому что 'IF NOT EXISTS' для
                    // ADD COLUMN не поддерживается старыми MySQL/MariaDB).
                    if (is_callable($step)) {
                        $step(DB::pdo());
                    } elseif (is_string($step)) {
                        DB::pdo()->exec($step);
                    } else {
                        throw new RuntimeException(
                            'Migration step must be string SQL or callable, got: ' . gettype($step));
                    }
                }
                $st = DB::pdo()->prepare("INSERT INTO migrations(name) VALUES (?)");
                $st->execute([$m['name']]);
                $report['ran'][] = $m['name'];
            } catch (Throwable $e) {
                $report['ok'] = false;
                $report['errors'][] = $m['name'] . ': ' . $e->getMessage();
                break; // не применяем дальше
            }
        }

        return $report;
    }
}
