<?php

class TelegramService
{
    /**
     * Прочитать настройки телеграма (с расшифровкой токена).
     */
    public function getSettings(): array
    {
        $row = DB::pdo()->query("SELECT * FROM telegram_settings WHERE id=1")->fetch();
        if (!$row) {
            DB::pdo()->exec("INSERT INTO telegram_settings (id) VALUES (1)");
            $row = DB::pdo()->query("SELECT * FROM telegram_settings WHERE id=1")->fetch();
        }

        $token = '';
        if (!empty($row['bot_token_enc'])) {
            try { $token = Crypto::decrypt((string)$row['bot_token_enc']); } catch (Throwable $e) {}
        }

        return [
            'enabled'              => (int)($row['enabled'] ?? 0) === 1,
            'chat_id'              => (string)($row['chat_id'] ?? ''),
            'bot_token'            => $token,
            'notify_on_stage_ok'   => (int)($row['notify_on_stage_ok'] ?? 1) === 1,
            'notify_on_stage_fail' => (int)($row['notify_on_stage_fail'] ?? 1) === 1,
            'notify_on_done'       => (int)($row['notify_on_done'] ?? 1) === 1,
            // v14h: фильтр для масштаба
            'min_level'            => (string)($row['min_level'] ?? 'milestones'),
            'ok_per_stage_limit'   => (int)($row['ok_per_stage_limit'] ?? 1),
            'job_summary_enabled'  => (int)($row['job_summary_enabled'] ?? 1) === 1,
            // v18.1.28: список @usernames для упоминания в balance-low алертах
            'mention_usernames'    => (string)($row['mention_usernames'] ?? ''),
        ];
    }

    public function saveSettings(array $data): void
    {
        $tokenEnc = null;
        if (!empty($data['bot_token'])) {
            $tokenEnc = Crypto::encrypt((string)$data['bot_token']);
        }

        // Валидация min_level
        $allowedLevels = ['all', 'milestones', 'errors_only', 'off'];
        $minLevel = (string)($data['min_level'] ?? 'milestones');
        if (!in_array($minLevel, $allowedLevels, true)) {
            $minLevel = 'milestones';
        }

        // v18.1.28: mention_usernames — колонка добавлена миграцией 015.
        // Если миграция ещё не применена — отдельно UPDATE без mention_usernames.
        $hasMentionColumn = $this->columnExists('telegram_settings', 'mention_usernames');

        if ($hasMentionColumn) {
            $st = DB::pdo()->prepare("UPDATE telegram_settings SET
                enabled = ?,
                chat_id = ?,
                bot_token_enc = COALESCE(?, bot_token_enc),
                notify_on_stage_ok = ?,
                notify_on_stage_fail = ?,
                notify_on_done = ?,
                min_level = ?,
                ok_per_stage_limit = ?,
                job_summary_enabled = ?,
                mention_usernames = ?
                WHERE id = 1");
            $st->execute([
                !empty($data['enabled']) ? 1 : 0,
                (string)($data['chat_id'] ?? ''),
                $tokenEnc,
                !empty($data['notify_on_stage_ok']) ? 1 : 0,
                !empty($data['notify_on_stage_fail']) ? 1 : 0,
                !empty($data['notify_on_done']) ? 1 : 0,
                $minLevel,
                max(0, (int)($data['ok_per_stage_limit'] ?? 1)),
                !empty($data['job_summary_enabled']) ? 1 : 0,
                trim((string)($data['mention_usernames'] ?? '')),
            ]);
        } else {
            $st = DB::pdo()->prepare("UPDATE telegram_settings SET
                enabled = ?,
                chat_id = ?,
                bot_token_enc = COALESCE(?, bot_token_enc),
                notify_on_stage_ok = ?,
                notify_on_stage_fail = ?,
                notify_on_done = ?,
                min_level = ?,
                ok_per_stage_limit = ?,
                job_summary_enabled = ?
                WHERE id = 1");
            $st->execute([
                !empty($data['enabled']) ? 1 : 0,
                (string)($data['chat_id'] ?? ''),
                $tokenEnc,
                !empty($data['notify_on_stage_ok']) ? 1 : 0,
                !empty($data['notify_on_stage_fail']) ? 1 : 0,
                !empty($data['notify_on_done']) ? 1 : 0,
                $minLevel,
                max(0, (int)($data['ok_per_stage_limit'] ?? 1)),
                !empty($data['job_summary_enabled']) ? 1 : 0,
            ]);
        }
    }

    /**
     * v18.1.28: проверка существования колонки (для backward-compatible UPDATE).
     */
    private function columnExists(string $table, string $column): bool
    {
        try {
            $st = DB::pdo()->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
            $st->execute([$table, $column]);
            return (int)$st->fetchColumn() > 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Отправить сообщение. Возвращает true/false.
     */
    public function send(string $text): bool
    {
        $s = $this->getSettings();
        if (!$s['enabled'] || $s['bot_token'] === '' || $s['chat_id'] === '') {
            return false;
        }

        $url = "https://api.telegram.org/bot{$s['bot_token']}/sendMessage";
        $payload = [
            'chat_id' => $s['chat_id'],
            'text' => mb_substr($text, 0, 4000),
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true,
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code !== 200) {
            @error_log('[telegram] send failed: HTTP ' . $code . ' resp=' . substr((string)$resp, 0, 200));
            return false;
        }
        return true;
    }

    public function notifyStageOk(int $jobId, string $stage, string $msg, array $payload = []): void
    {
        $s = $this->getSettings();
        if (!$s['notify_on_stage_ok']) return;
        // ТЗ 039 §18 (ревью P1): тот же presenter, что и UI, с ПОЛНЫМ payload —
        // человекочитаемый текст формируется по event_code, а не по сырой строке.
        $label = class_exists('JobEventPresenter') ? JobEventPresenter::stageLabel($stage)
               : (JobEventLogger::STAGE_LABELS_RU[$stage] ?? $stage);
        $human = class_exists('JobEventPresenter')
               ? JobEventPresenter::telegramText($stage, 'ok', $msg, $payload) : $msg;
        $header = $this->formatJobHeader($jobId);
        $this->send("✅ <b>{$header}</b>\n{$label}\n" . htmlspecialchars($human, ENT_QUOTES, 'UTF-8'));
    }

    public function notifyStageFail(int $jobId, string $stage, string $msg, array $payload = []): void
    {
        $s = $this->getSettings();
        if (!$s['notify_on_stage_fail']) return;
        $label = class_exists('JobEventPresenter') ? JobEventPresenter::stageLabel($stage)
               : (JobEventLogger::STAGE_LABELS_RU[$stage] ?? $stage);
        $human = class_exists('JobEventPresenter')
               ? JobEventPresenter::telegramText($stage, 'error', $msg, $payload) : $msg;
        $header = $this->formatJobHeader($jobId);
        $this->send("❌ <b>{$header}</b>\n{$label}\n<i>" . htmlspecialchars($human, ENT_QUOTES, 'UTF-8') . "</i>");
    }

    public function notifyDone(int $jobId, string $oldDomain, string $newDomain): void
    {
        $s = $this->getSettings();
        if (!$s['notify_on_done']) return;
        $oldDomainSafe = htmlspecialchars($oldDomain, ENT_QUOTES, 'UTF-8');
        $newDomainSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
        $this->send("🎉 <b>refresh #{$jobId} готово</b>\n{$oldDomainSafe} → <b>{$newDomainSafe}</b>\nНовый домен в индексе.");
    }

    /**
     * v18: критичные уведомления — отправляются ВСЕГДА если TG включён,
     * независимо от notify_on_done / notify_on_stage_ok / min_level.
     *
     * Используется для:
     *   - "Новый домен в индексе" (после успешного index_watching)
     *   - "Джоба завершена" (markJobDone)
     *   - другие важные вехи которые оператор не должен пропустить
     */
    public function notifyImportant(int $jobId, string $title, string $body): void
    {
        $s = $this->getSettings();
        if (empty($s['enabled']) || empty($s['bot_token']) || empty($s['chat_id'])) {
            return;
        }
        $header = $this->formatJobHeader($jobId);
        $titleSafe = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        // body может содержать HTML (передаётся уже экранированным)
        $this->send("🔔 <b>{$header}</b>\n<b>{$titleSafe}</b>\n\n{$body}");
    }

    /**
     * v14i-fix1: формирует шапку сообщения с информацией о сайте.
     *
     * Возвращает строку вида:
     *   "refresh #8 | volna-202.casino → volna-204.casino"
     *   "refresh #2 | zooma-21.casino → ?"  (если new_domain ещё не куплен)
     *   "refresh #5"                         (если домены не загрузились — fallback)
     *
     * Это критично для масштаба: когда параллельно идут 30 джоб, по номеру
     * "refresh #N" непонятно какой это сайт. С шапкой видно сразу.
     */
    private function formatJobHeader(int $jobId): string
    {
        try {
            $st = DB::pdo()->prepare(
                "SELECT old_domain, new_domain FROM refresh_jobs WHERE id = ?"
            );
            $st->execute([$jobId]);
            $row = $st->fetch();
            if (!$row) {
                return "refresh #{$jobId}";
            }
            $old = trim((string)($row['old_domain'] ?? ''));
            $new = trim((string)($row['new_domain'] ?? ''));

            // HTML-экранирование (вдруг в домене будет что-то странное)
            $oldSafe = htmlspecialchars($old, ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($new, ENT_QUOTES, 'UTF-8');

            if ($old === '' && $new === '') {
                return "refresh #{$jobId}";
            }
            if ($new === '') {
                // Покупка ещё не прошла
                return "refresh #{$jobId} | {$oldSafe} → ?";
            }
            return "refresh #{$jobId} | {$oldSafe} → {$newSafe}";
        } catch (\Throwable $e) {
            return "refresh #{$jobId}";
        }
    }

    /**
     * Отправить сводку джобы — одно сообщение в конце с разбивкой по стадиям.
     * Используется когда job_summary_enabled=1 (по умолчанию для масштаба).
     *
     * @param array $stages Один из двух форматов:
     *   1. { stage => 'ok'|'fail'|'skip' } — старый, безликий
     *   2. { stage => ['status' => 'ok'|..., 'human' => 'Куплен X за $Y'] } — v14h-fix1, человеческий
     */
    public function notifyJobSummary(int $jobId, string $oldDomain, string $newDomain, array $stages, ?string $finalError = null): void
    {
        $s = $this->getSettings();
        if (empty($s['enabled'])) return;
        if (empty($s['job_summary_enabled'])) return;

        $statusIcon = $finalError === null ? '🎉' : '⚠️';
        $statusText = $finalError === null ? 'готово' : 'завершено с ошибками';

        $oldDomainSafe = htmlspecialchars($oldDomain, ENT_QUOTES, 'UTF-8');
        $newDomainSafe = htmlspecialchars($newDomain !== '' ? $newDomain : '?', ENT_QUOTES, 'UTF-8');

        $msg = "{$statusIcon} <b>refresh #{$jobId} {$statusText}</b>\n";
        $msg .= "{$oldDomainSafe} → <b>{$newDomainSafe}</b>\n\n";

        if (!empty($stages)) {
            $msg .= "<b>Что сделано:</b>\n";
            foreach ($stages as $stage => $result) {
                // Поддержка двух форматов
                if (is_array($result)) {
                    $status = (string)($result['status'] ?? 'ok');
                    $human = trim((string)($result['human'] ?? $stage));
                } else {
                    $status = (string)$result;
                    $human = $stage; // fallback на машинный код
                }

                $icon = $status === 'ok' ? '✅' : ($status === 'skip' ? '⏭' : '❌');
                // Экранируем HTML-спецсимволы в human-тексте (могут быть < > &)
                $humanSafe = htmlspecialchars($human, ENT_QUOTES, 'UTF-8');
                $msg .= "{$icon} {$humanSafe}\n";
            }
        }

        if ($finalError !== null) {
            $msg .= "\n<b>Ошибка:</b> <i>" . htmlspecialchars(mb_substr($finalError, 0, 200), ENT_QUOTES, 'UTF-8') . "</i>";
        }

        $this->send($msg);
    }
}
