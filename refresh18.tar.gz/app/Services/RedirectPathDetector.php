<?php

/**
 * v18.1.24: автодетектор реального path'а для smoke-теста редиректа.
 *
 * Раньше smoke-тест бил curl'ом по /play — это работало только для одной семьи
 * шаблонов (7k/promo с Redirect 302 /play). Шаблоны olymp-* используют /reg,
 * другие могут использовать /go, /redirect и т.д. В результате smoke всегда
 * падал с HTTP 404 на нестандартных шаблонах.
 *
 * Стратегия (приоритет — сверху):
 *
 *  1. Из .htaccess вытащить Redirect-директивы:
 *     "Redirect 30[12] /<path> https://...partner..."
 *     "RewriteRule ^<path> https://...partner..." [R=30x,L]
 *     Берём path. Если их несколько — приоритет тот что ведёт на партнёрку (kpromooffer/partners7k).
 *
 *  2. Из .htaccess вытащить RewriteRule которые ведут в index.php (внутренний роутинг):
 *     "RewriteRule ^<path>(?:/.*)?$ index.php [L,QSA]"
 *     Это значит /<path> обрабатывается PHP — тоже валидно для smoke.
 *
 *  3. Из index.php / guard.php найти преимущественные совпадения регулярных
 *     выражений типа preg_match('~^/<path>~') — реже, но иногда так пишут.
 *
 *  4. Fallback: общие имена кандидатов /play, /reg, /go, /redirect, /partner.
 *     Для каждого делаем HEAD-запрос и берём первый кто возвращает 30x.
 *
 *  5. Если ничего — возвращаем null (smoke-тест пропустить).
 *
 * Результат кешируется в artifacts['redirect_path_stage'] чтобы не повторять
 * детект на каждом тике.
 */
class RedirectPathDetector
{
    /**
     * v18.1.35: Извлечь partner path из config.php.
     *
     * Многие шаблоны (mellstroy/7k/olymp/fugu стиль) хранят партнёрский path
     * в config.php как `$promolink = '/reg';` или внутри $site['promolink'].
     * Это САМЫЙ ДОСТОВЕРНЫЙ источник — значение явно прописано разработчиком,
     * никакой эвристики.
     *
     * Поддерживаемые форматы:
     *   - $promolink = '/reg';                     (плоский)
     *   - $promolink = "/reg";
     *   - $site['promolink'] = '/reg';
     *   - $site = [..., 'promolink' => '/reg', ...]
     *
     * @return string|null Path или null если не нашли.
     */
    public function detectFromConfigPhp(string $configContent): ?string
    {
        // 1) Плоское присваивание: $promolink = '/reg';  или  $promolink="/reg";
        if (preg_match('~\$promolink\s*=\s*[\'"]([^\'"]+)[\'"]~', $configContent, $m)) {
            $p = $this->normalizePath($m[1]);
            if ($p !== null) return $p;
        }

        // 2) Массив-стиль:  $site['promolink'] = '/reg';
        if (preg_match('~\$site\s*\[\s*[\'"]promolink[\'"]\s*\]\s*=\s*[\'"]([^\'"]+)[\'"]~', $configContent, $m)) {
            $p = $this->normalizePath($m[1]);
            if ($p !== null) return $p;
        }

        // 3) Внутри литерала массива:  'promolink' => '/reg'
        if (preg_match('~[\'"]promolink[\'"]\s*=>\s*[\'"]([^\'"]+)[\'"]~', $configContent, $m)) {
            $p = $this->normalizePath($m[1]);
            if ($p !== null) return $p;
        }

        return null;
    }

    /**
     * Найти redirect path по содержимому .htaccess.
     *
     * @return string|null Path вида '/play', '/reg', '/go' или null если не нашли.
     */
    public function detectFromHtaccess(string $htaccessContent): ?string
    {
        // 1) Сначала ищем явные Redirect / RewriteRule с внешним URL на партнёрку.
        //    Партнёрский домен распознаём по характерным маркерам: kpromooffer, partners7k, partners-, promo-, .com/l/, redirect, lp.
        $partnerMarkers = '(?:kpromooffer|partners7k|partners-|promo-|7k-promo|slotwinredirect|partnersolymp|olymp-promo|stake-promo|\.com/l/|\.com/r/)';

        // Redirect 30[12] /<path> https://partner...
        if (preg_match_all(
            '~^\s*Redirect\s+(?:30[12]|permanent|temp)\s+(/\S+)\s+https?://[^\s]*' . $partnerMarkers . '~mi',
            $htaccessContent,
            $matches
        )) {
            foreach ($matches[1] as $path) {
                $path = $this->normalizePath($path);
                if ($path !== null) return $path;
            }
        }

        // RewriteRule ^<path>... https://partner... [R=30x,L]
        if (preg_match_all(
            '~^\s*RewriteRule\s+\^([^\s\[\]]+?)(?:\$|\?)?\s+https?://[^\s]*' . $partnerMarkers . '[^[]*\[[^\]]*R=30[12][^\]]*\]~mi',
            $htaccessContent,
            $matches
        )) {
            foreach ($matches[1] as $rawPath) {
                $path = $this->cleanRewritePath($rawPath);
                if ($path !== null) return $path;
            }
        }

        // 2) RewriteRule which routes to index.php — это внутренний PHP-роут на партнёрку.
        //    Пример из olymp-шаблона: RewriteRule ^reg(?:/.*)?$ index.php [L,QSA]
        //
        // v18.1.28: ВАЖНО — приоритизируем path'ы которые "похожи на партнёрский редирект"
        // (reg, go, redirect, partner, play, out, r, link) над прочими (en, ru, about, ...).
        // Иначе на сайтах с i18n routes ('RewriteRule ^en/?$ index.php?lang=en') детектор
        // ловил /en вместо /reg. Видели на сайтах группы 1win-77x.
        $partnerLikeNames = ['reg', 'go', 'redirect', 'partner', 'play', 'out', 'r', 'link', 'p'];
        if (preg_match_all(
            '~^\s*RewriteRule\s+\^([^\s\[\]]+?)(?:\$|\?)?\s+index\.php\b~mi',
            $htaccessContent,
            $matches
        )) {
            $candidates = [];
            foreach ($matches[1] as $rawPath) {
                $path = $this->cleanRewritePath($rawPath);
                if ($path === null) continue;
                if (in_array($path, ['/', '/robots', '/sitemap'], true)) continue;
                $candidates[] = $path;
            }
            // Сначала ищем partner-like
            foreach ($candidates as $path) {
                $name = ltrim($path, '/');
                if (in_array(strtolower($name), $partnerLikeNames, true)) {
                    return $path;
                }
            }
            // Затем — первый встретившийся (старое поведение fallback)
            if (!empty($candidates)) {
                return $candidates[0];
            }
        }

        return null;
    }

    /**
     * Найти redirect path в PHP-коде (index.php, guard.php).
     *
     * Ищем паттерны:
     *   preg_match('~^/reg(?:/.*)?$~', $reqPath)
     *   if ($_SERVER['REQUEST_URI'] === '/play')
     *   if (strpos($_SERVER['REQUEST_URI'], '/redirect') === 0)
     *
     * @return string|null
     */
    public function detectFromPhp(string $phpContent): ?string
    {
        // Pattern A: preg_match('~^/<path>~', ...) или preg_match('!^/<path>!', ...)
        // Используем @ как delimiter регекса чтобы избежать конфликта с ~ внутри pattern
        if (preg_match_all(
            '@preg_match\s*\(\s*[\'"][~/!%]+\^?(/[a-z][a-z0-9_-]*)@i',
            $phpContent,
            $matches
        )) {
            foreach ($matches[1] as $path) {
                $clean = $this->normalizePath($path);
                if ($clean !== null && !in_array($clean, ['/robots', '/sitemap'], true)) {
                    return $clean;
                }
            }
        }

        // Pattern B: $reqPath === '/<path>' или REQUEST_URI === '/<path>'
        if (preg_match_all(
            '@(?:REQUEST_URI|reqPath|requestPath|path)\s*(?:===|==|=)\s*[\'"](/[a-z][a-z0-9_-]*)[\'"]@i',
            $phpContent,
            $matches
        )) {
            foreach ($matches[1] as $path) {
                $clean = $this->normalizePath($path);
                if ($clean !== null && !in_array($clean, ['/robots', '/sitemap'], true)) {
                    return $clean;
                }
            }
        }

        return null;
    }

    /**
     * Объединённый детектор.
     *
     * v18.1.35: ПОРЯДОК ИЗМЕНЁН — config.php теперь первым приоритетом, так как
     * `$promolink` это явно прописанное значение, а не эвристика по .htaccess.
     *
     * @param array $fileContents Ассоциативный массив 'имя.файла' => 'содержимое'.
     *                            Ожидаются ключи: config.php, .htaccess, index.php, guard.php (опционально).
     * @return array{path: ?string, source: string}
     */
    public function detect(array $fileContents): array
    {
        // 1) config.php — самый достоверный источник ($promolink)
        if (!empty($fileContents['config.php'])) {
            $p = $this->detectFromConfigPhp((string)$fileContents['config.php']);
            if ($p !== null) {
                return ['path' => $p, 'source' => 'config.php'];
            }
        }

        // 2) .htaccess (Apache Redirect / RewriteRule на партнёрку)
        if (!empty($fileContents['.htaccess'])) {
            $p = $this->detectFromHtaccess((string)$fileContents['.htaccess']);
            if ($p !== null) {
                return ['path' => $p, 'source' => '.htaccess'];
            }
        }

        // 3) PHP-файлы (guard.php, index.php)
        foreach (['guard.php', 'index.php'] as $f) {
            if (!empty($fileContents[$f])) {
                $p = $this->detectFromPhp((string)$fileContents[$f]);
                if ($p !== null) {
                    return ['path' => $p, 'source' => $f];
                }
            }
        }
        return ['path' => null, 'source' => 'not_found'];
    }

    /**
     * Список fallback-кандидатов если детект не сработал.
     * Можно по очереди пробовать каждый через HEAD-запрос.
     */
    public function getFallbackCandidates(): array
    {
        return ['/play', '/reg', '/go', '/redirect', '/r', '/partner'];
    }

    private function normalizePath(?string $p): ?string
    {
        if ($p === null) return null;
        $p = trim($p);
        if ($p === '') return null;
        if ($p[0] !== '/') $p = '/' . $p;
        // Убираем хвост типа /(...) или регексп-метасимволы
        $p = preg_replace('~[\(\)\$\^\?].*$~', '', $p);
        $p = rtrim($p, '/');
        if ($p === '' || $p === '/') return null;
        // Должно быть простое имя [a-z0-9_-]+ после слэша
        if (!preg_match('~^/[a-z][a-z0-9_-]*$~i', $p)) return null;
        return strtolower($p);
    }

    private function cleanRewritePath(string $rawPath): ?string
    {
        // RewriteRule может иметь скобки/метасимволы: ^reg(?:/.*)?$ → "reg"
        // Снимем regex-обвес.
        $p = $rawPath;
        // Убираем якоря и quantifiers
        $p = preg_replace('~\(\?[:=].*$~', '', $p);  // (?:...)
        $p = preg_replace('~[\(\)\[\]\{\}\$\^\?\*\+\\\\].*$~', '', $p);
        $p = '/' . ltrim($p, '/');
        return $this->normalizePath($p);
    }
}
