<?php

/**
 * PATCH 048 (Gate W W4): политика допуска запроса переобхода при активном собственном
 * редиректоре. Решение принимается ТОЛЬКО по ТЕКУЩИМ ФАКТАМ, а не по ручному вечному
 * boolean (cloaking_confirmed_at запрещён), не по списку IP в коде сайта и не по UA-bypass.
 *
 * Локальный preflight не доказывает, что запрос пришёл с реального IP Яндекса — он используется
 * лишь для transport/final-host классификации. Итоговое решение:
 *
 *   1. final host == домен сайта                 → ALLOW (при валидном исходном URL)
 *   2. final host ∈ wm.own_redirect_domains      → ALLOW только при ОДНОВРЕМЕННО:
 *        - host verification evidence (Webmaster host verified)
 *        - redirect_enabled = 1
 *        - успешный semantic read-back включённого редиректа
 *        - final host входит в allowlist (точное совпадение / настоящий поддомен)
 *   3. неизвестный host                          → BLOCK (точная диагностика)
 *
 * Host matching: lower-case, удаление завершающей точки, точное совпадение либо НАСТОЯЩИЙ
 * поддомен (host === d ИЛИ host заканчивается на '.'.d). 'evil-dealredirectfast.com' и
 * 'dealredirectfast.com.attacker.tld' НЕ совпадают с 'dealredirectfast.com'.
 */
final class CloakedRedirectPolicy
{
    public const ALLOW = 'allow';
    public const BLOCK = 'block';

    /**
     * @param array $facts {
     *   source_url_valid: bool,
     *   final_host: string,
     *   site_domain: string,
     *   own_redirect_domains: string[],
     *   host_verified: bool,
     *   redirect_enabled: bool,
     *   redirect_readback_ok: bool
     * }
     * @return array{decision:string, reason:string, matched_host:?string, matched_kind:?string}
     */
    public function decide(array $facts): array
    {
        $sourceValid = !empty($facts['source_url_valid']);
        $finalHost   = self::normalizeHost((string)($facts['final_host'] ?? ''));
        $siteDomain  = self::normalizeHost((string)($facts['site_domain'] ?? ''));
        $allow       = array_values(array_filter(array_map(
            [self::class, 'normalizeHost'], (array)($facts['own_redirect_domains'] ?? [])
        ), fn($h) => $h !== ''));

        if (!$sourceValid) {
            return self::block('source_url_invalid', null, null);
        }
        if ($finalHost === '') {
            return self::block('final_host_empty', null, null);
        }

        // (1) final host == домен сайта → ALLOW
        if ($siteDomain !== '' && self::hostMatches($finalHost, $siteDomain)) {
            return ['decision' => self::ALLOW, 'reason' => 'final_host_is_site_domain',
                    'matched_host' => $siteDomain, 'matched_kind' => 'site'];
        }

        // (2) final host ∈ own_redirect_domains
        $matched = self::matchAllowlist($finalHost, $allow);
        if ($matched !== null) {
            $missing = [];
            if (empty($facts['host_verified']))        $missing[] = 'host_verification';
            if (empty($facts['redirect_enabled']))     $missing[] = 'redirect_enabled';
            if (empty($facts['redirect_readback_ok'])) $missing[] = 'redirect_readback';
            if (!empty($missing)) {
                return self::block('own_redirector_missing_facts:' . implode(',', $missing),
                    $matched, 'own_redirector');
            }
            return ['decision' => self::ALLOW, 'reason' => 'own_redirector_all_facts_present',
                    'matched_host' => $matched, 'matched_kind' => 'own_redirector'];
        }

        // (3) неизвестный host → BLOCK
        return self::block('unknown_final_host:' . $finalHost, null, null);
    }

    /** Нормализация host: lower-case + удаление завершающей точки + отбрасывание порта. */
    public static function normalizeHost(string $host): string
    {
        $h = trim($host);
        if ($h === '') return '';
        // если пришёл URL — вытащить host
        if (preg_match('~^[a-z][a-z0-9+.\-]*://~i', $h)) {
            $parsed = parse_url($h, PHP_URL_HOST);
            if (is_string($parsed) && $parsed !== '') $h = $parsed;
        }
        $h = mb_strtolower($h);
        $h = rtrim($h, '.');
        if (($pos = strpos($h, ':')) !== false) $h = substr($h, 0, $pos); // отбросить порт
        return $h;
    }

    /** Точное совпадение или НАСТОЯЩИЙ поддомен ($host === $base ИЛИ $host заканчивается на '.'.$base). */
    public static function hostMatches(string $host, string $base): bool
    {
        $host = self::normalizeHost($host);
        $base = self::normalizeHost($base);
        if ($host === '' || $base === '') return false;
        if ($host === $base) return true;
        $suffix = '.' . $base;
        return substr($host, -strlen($suffix)) === $suffix;
    }

    /** @return ?string совпавший allowlist-домен или null */
    public static function matchAllowlist(string $host, array $allowlist): ?string
    {
        foreach ($allowlist as $d) {
            if (self::hostMatches($host, $d)) return self::normalizeHost($d);
        }
        return null;
    }

    private static function block(string $reason, ?string $matched, ?string $kind): array
    {
        return ['decision' => self::BLOCK, 'reason' => $reason,
                'matched_host' => $matched, 'matched_kind' => $kind];
    }
}
