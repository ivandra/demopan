<?php

/**
 * ТЗ 040 FINAL-3 §3.10: единый нормализатор FastPanel host.
 *
 * Единственный источник канонизации host. Используется миграцией 040,
 * ServerProfileValidator, FastpanelServerController (create/edit) и unit-тестами.
 * НЕ обращается к БД и сети (никакого DNS lookup).
 *
 * Канонические правила (§3.10):
 *   trim → снять http(s):// → снять один хвостовой / → запретить
 *   userinfo/path/query/fragment/control-символы → порт по умолчанию 8888 →
 *   порт integer 1..65535 → IPv4 через FILTER_VALIDATE_IP → hostname по
 *   DNS-label правилам, lower-case → вернуть "host:port".
 */
final class FastpanelHostNormalizer
{
    /**
     * @return array{ok:bool, host:string, error:?string}
     */
    public static function normalize(string $raw): array
    {
        $h = trim($raw);
        if ($h === '') return self::err('пустой host');

        // control characters
        if (preg_match('~[\x00-\x1F\x7F]~', $h)) return self::err('host содержит управляющие символы');

        // схема
        if (preg_match('~^https?://~i', $h)) {
            $h = preg_replace('~^https?://~i', '', $h);
        }
        // ровно один хвостовой слэш допустим — снимаем
        if (substr($h, -1) === '/') $h = substr($h, 0, -1);

        // после снятия схемы и хвостового слэша путь/query/fragment/userinfo запрещены
        if (strpos($h, '/') !== false) return self::err('путь в host запрещён');
        if (strpos($h, '?') !== false) return self::err('query в host запрещён');
        if (strpos($h, '#') !== false) return self::err('fragment в host запрещён');
        if (strpos($h, '@') !== false) return self::err('userinfo в host запрещён');

        // host[:port]
        $port = 8888;
        $hostPart = $h;
        if (preg_match('~^(.*):(\d+)$~', $h, $m)) {
            // двоеточие есть — это порт (IPv6 не поддерживается для FastPanel host)
            $hostPart = $m[1];
            $portStr = $m[2];
            if ($portStr === '' || !ctype_digit($portStr)) return self::err('некорректный порт');
            $port = (int)$portStr;
        }
        if ($port < 1 || $port > 65535) return self::err('порт вне диапазона 1..65535');
        if ($hostPart === '') return self::err('пустой host');

        // IPv4?
        if (filter_var($hostPart, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
            return ['ok' => true, 'host' => $hostPart . ':' . $port, 'error' => null];
        }

        // §5 (аудит ver3): строка вида «только цифры и точки» — это попытка ввести
        // IPv4. Не пропускать её как hostname (999.999.999.999 / 256.1.1.1 /
        // 01.02.03.04 → ошибка, а не «hostname»).
        if (preg_match('~^[0-9.]+$~', $hostPart)) {
            return self::err('некорректный IPv4-адрес');
        }

        // hostname по DNS-label правилам
        $lower = strtolower($hostPart);
        if (strlen($lower) > 253) return self::err('слишком длинный hostname');
        $labels = explode('.', $lower);
        foreach ($labels as $lab) {
            if ($lab === '' || strlen($lab) > 63) return self::err('некорректный hostname');
            if (!preg_match('~^[a-z0-9]([a-z0-9-]*[a-z0-9])?$~', $lab)) return self::err('некорректный hostname');
        }
        return ['ok' => true, 'host' => $lower . ':' . $port, 'error' => null];
    }

    private static function err(string $m): array
    {
        return ['ok' => false, 'host' => '', 'error' => $m];
    }
}
