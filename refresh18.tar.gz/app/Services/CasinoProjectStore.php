<?php

/**
 * CasinoProjectStore — обёртка над таблицами casino_projects / casino_project_sites.
 *
 * Изоляция SQL в одном месте. Все controllers и orchestrators ходят сюда.
 */
class CasinoProjectStore
{
    /**
     * Зарегистрировать новый проект (или обновить если external_id+api_client_id уже есть).
     * Возвращает project_id.
     */
    public static function registerOrUpdate(array $input, int $apiClientId): int
    {
        $external = (string)($input['external_id'] ?? '');
        $existing = null;
        if ($external !== '') {
            $st = DB::pdo()->prepare(
                "SELECT id FROM casino_projects WHERE api_client_id = ? AND external_id = ? LIMIT 1"
            );
            $st->execute([$apiClientId, $external]);
            $row = $st->fetch();
            if ($row) $existing = (int)$row['id'];
        }

        $fields = [
            'label'                => (string)($input['label'] ?? ''),
            'main_host'            => (string)($input['main_host'] ?? ''),
            'docroot'              => (string)($input['docroot'] ?? ''),
            'vps_ip'               => (string)($input['vps_ip'] ?? '') ?: null,
            'webmaster_account_id' => isset($input['webmaster_account_id']) ? (int)$input['webmaster_account_id'] : null,
            'registrar_account_id' => isset($input['registrar_account_id']) ? (int)$input['registrar_account_id'] : null,
            'registrar_contact_id' => isset($input['registrar_contact_id']) ? (int)$input['registrar_contact_id'] : null,
            'fp_server_id'         => isset($input['fp_server_id']) ? (int)$input['fp_server_id'] : null,
            'fp_site_id'           => isset($input['fp_site_id']) ? (int)$input['fp_site_id'] : null,
            'note'                 => (string)($input['note'] ?? '') ?: null,
        ];

        if ($existing !== null) {
            $sets = []; $vals = [];
            foreach ($fields as $k => $v) { $sets[] = "$k = ?"; $vals[] = $v; }
            $vals[] = $existing;
            $st = DB::pdo()->prepare("UPDATE casino_projects SET " . implode(', ', $sets) . " WHERE id = ?");
            $st->execute($vals);
            return $existing;
        }

        $cols = array_keys($fields);
        $cols[] = 'api_client_id';
        $cols[] = 'external_id';
        $cols[] = 'status';
        $placeholders = implode(',', array_fill(0, count($cols), '?'));
        $vals = array_values($fields);
        $vals[] = $apiClientId;
        $vals[] = $external;
        $vals[] = 'registered';
        $sql = "INSERT INTO casino_projects (" . implode(',', $cols) . ") VALUES ($placeholders)";
        $st = DB::pdo()->prepare($sql);
        $st->execute($vals);
        return (int)DB::pdo()->lastInsertId();
    }

    /**
     * Сохранить/обновить список сайтов проекта.
     * Сайты с slug'ом которого нет в новом списке — удаляются.
     */
    public static function setSites(int $projectId, array $sites): void
    {
        // Загружаем существующие slug'и
        $st = DB::pdo()->prepare("SELECT id, site_slug FROM casino_project_sites WHERE project_id = ?");
        $st->execute([$projectId]);
        $existing = [];
        foreach ($st->fetchAll() as $row) {
            $existing[(string)$row['site_slug']] = (int)$row['id'];
        }

        $newSlugs = [];
        $updateStmt = DB::pdo()->prepare(
            "UPDATE casino_project_sites
             SET brand=?, host=?, path_prefix=?, path_repeats=?, subid=?, is_main=?,
                 updated_at=CURRENT_TIMESTAMP
             WHERE id=?"
        );
        $insertStmt = DB::pdo()->prepare(
            "INSERT INTO casino_project_sites
              (project_id, site_slug, brand, host, path_prefix, path_repeats, subid, is_main)
             VALUES (?,?,?,?,?,?,?,?)"
        );

        foreach ($sites as $s) {
            $slug = (string)($s['site_slug'] ?? '');
            if ($slug === '') continue;
            $newSlugs[$slug] = true;

            $brand       = (string)($s['brand'] ?? '');
            $host        = (string)($s['host'] ?? '');
            $pathPrefix  = (string)($s['path_prefix'] ?? 'en');
            $pathRepeats = (int)($s['path_repeats'] ?? 11);
            $subid       = (string)($s['subid'] ?? '');
            $isMain      = ($slug === '_main' ? 1 : 0);

            if (isset($existing[$slug])) {
                $updateStmt->execute([
                    $brand, $host, $pathPrefix, $pathRepeats, $subid, $isMain,
                    $existing[$slug],
                ]);
            } else {
                $insertStmt->execute([
                    $projectId, $slug, $brand, $host, $pathPrefix, $pathRepeats, $subid, $isMain,
                ]);
            }
        }

        // Удаляем сайты которых нет в новом списке
        if (!empty($newSlugs)) {
            $placeholders = implode(',', array_fill(0, count($newSlugs), '?'));
            $params = array_merge([$projectId], array_keys($newSlugs));
            $st = DB::pdo()->prepare(
                "DELETE FROM casino_project_sites WHERE project_id = ? AND site_slug NOT IN ($placeholders)"
            );
            $st->execute($params);
        } else {
            $st = DB::pdo()->prepare("DELETE FROM casino_project_sites WHERE project_id = ?");
            $st->execute([$projectId]);
        }
    }

    public static function loadProject(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM casino_projects WHERE id = ?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    public static function loadProjectByExternal(int $apiClientId, string $externalId): ?array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM casino_projects WHERE api_client_id = ? AND external_id = ? LIMIT 1"
        );
        $st->execute([$apiClientId, $externalId]);
        $r = $st->fetch();
        return $r ?: null;
    }

    public static function loadSites(int $projectId): array
    {
        $st = DB::pdo()->prepare(
            "SELECT * FROM casino_project_sites WHERE project_id = ? ORDER BY is_main DESC, site_slug ASC"
        );
        $st->execute([$projectId]);
        return $st->fetchAll() ?: [];
    }

    public static function listProjects(?int $apiClientId = null, int $limit = 200): array
    {
        if ($apiClientId !== null) {
            $st = DB::pdo()->prepare(
                "SELECT * FROM casino_projects WHERE api_client_id = ? ORDER BY id DESC LIMIT ?"
            );
            $st->bindValue(1, $apiClientId, PDO::PARAM_INT);
            $st->bindValue(2, $limit, PDO::PARAM_INT);
            $st->execute();
        } else {
            $st = DB::pdo()->prepare("SELECT * FROM casino_projects ORDER BY id DESC LIMIT ?");
            $st->bindValue(1, $limit, PDO::PARAM_INT);
            $st->execute();
        }
        return $st->fetchAll() ?: [];
    }

    /**
     * Сериализация проекта для возврата по API (включая sites).
     */
    public static function toApiArray(array $project, ?array $sites = null): array
    {
        if ($sites === null) {
            $sites = self::loadSites((int)$project['id']);
        }
        return [
            'id'                    => (int)$project['id'],
            'external_id'           => (string)$project['external_id'],
            'label'                 => (string)$project['label'],
            'main_host'             => (string)$project['main_host'],
            'docroot'               => (string)$project['docroot'],
            'vps_ip'                => $project['vps_ip'],
            'webmaster_account_id'  => $project['webmaster_account_id'] !== null ? (int)$project['webmaster_account_id'] : null,
            'registrar_account_id'  => $project['registrar_account_id'] !== null ? (int)$project['registrar_account_id'] : null,
            'registrar_contact_id'  => $project['registrar_contact_id'] !== null ? (int)$project['registrar_contact_id'] : null,
            'fp_server_id'          => $project['fp_server_id'] !== null ? (int)$project['fp_server_id'] : null,
            'fp_site_id'            => $project['fp_site_id'] !== null ? (int)$project['fp_site_id'] : null,
            'root_domain'           => (string)$project['root_domain'],
            'status'                => (string)$project['status'],
            'created_at'            => $project['created_at'],
            'updated_at'            => $project['updated_at'],
            'sites'                 => array_map(function ($s) {
                return [
                    'site_slug'    => (string)$s['site_slug'],
                    'brand'        => (string)$s['brand'],
                    'host'         => (string)$s['host'],
                    'path_prefix'  => (string)$s['path_prefix'],
                    'path_repeats' => (int)$s['path_repeats'],
                    'subid'        => (string)$s['subid'],
                    'is_main'      => (int)$s['is_main'] === 1,
                    'dns_status'   => (string)$s['dns_status'],
                    'fp_alias_status' => (string)$s['fp_alias_status'],
                    'ssl_status'   => (string)$s['ssl_status'],
                    'wm_verified'  => (int)$s['wm_verified'] === 1,
                    'wm_host_id'   => (string)$s['wm_host_id'],
                ];
            }, $sites),
        ];
    }
    /**
     * v0.4-b2: Сохранить купленный root_domain в casino_projects.
     * Также проставляет дату покупки и переводит статус в domain_bought.
     */
    public static function setRootDomain(int $projectId, string $rootDomain): void
    {
        $stmt = DB::pdo()->prepare(
            'UPDATE casino_projects
                SET root_domain = :rd,
                    root_domain_purchased_at = :pa,
                    status = :st,
                    updated_at = :ts
              WHERE id = :id'
        );
        $stmt->execute([
            ':rd' => $rootDomain,
            ':pa' => date('Y-m-d H:i:s'),
            ':st' => 'domain_bought',
            ':ts' => date('Y-m-d H:i:s'),
            ':id' => $projectId,
        ]);
    }
}
