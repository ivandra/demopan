<?php

/**
 * v18.1.28: BalanceCheckService — централизованная проверка балансов
 * внешних сервисов и сохранение результатов в БД для:
 *   1) UI status-bar (через таблицу balance_current)
 *   2) истории (balance_snapshots)
 *   3) TG-алертов при низком балансе
 *
 * Поддерживаемые сервисы:
 *   - namecheap (баланс в USD, threshold по умолчанию $100)
 *   - xmlstock  (баланс в RUB,  threshold по умолчанию 100₽)
 *
 * Триггеры запуска:
 *   - cron (раз в час)
 *   - manual (UI кнопка)
 *   - after_purchase (после успешной покупки домена)
 *   - after_index_check (после запуска index-watching через XMLStock)
 *
 * Anti-spam для TG-алертов: повторный алерт о низком балансе того же
 * сервиса шлётся не чаще раз в 6 часов (через колонку last_low_alert_at).
 */
class BalanceCheckService
{
    /** Anti-spam window для TG-алертов о низком балансе (сек). */
    private const LOW_ALERT_COOLDOWN_SEC = 6 * 3600;

    /** Threshold'ы по умолчанию — если в balance_current не заданы. */
    private const DEFAULT_THRESHOLDS = [
        'namecheap' => 100.0,  // USD
        'xmlstock'  => 100.0,  // RUB
    ];

    /**
     * Проверить баланс конкретного сервиса.
     *
     * @param string $service 'namecheap' | 'xmlstock'
     * @param string $trigger 'cron' | 'manual' | 'after_purchase' | 'after_index_check'
     * @param string $accountLabel Для namecheap может быть несколько аккаунтов.
     * @return array {
     *     ok: bool, balance?: float, currency?: string, status: 'ok'|'low'|'error',
     *     threshold?: float, error?: string, alert_sent?: bool
     * }
     */
    public function checkOne(string $service, string $trigger = 'manual', string $accountLabel = 'default'): array
    {
        $service = strtolower(trim($service));
        if (!in_array($service, ['namecheap', 'xmlstock'], true)) {
            return ['ok' => false, 'status' => 'error', 'error' => "unknown service: {$service}"];
        }

        // v18.1.28 fix: canonical accountLabel.
        // Каллер может передать username аккаунта Namecheap (например 'rodion.minskoff'
        // из after_purchase trigger), но это **тот же** account который cron и manual
        // получают через 'default'. Чтобы не создавать дубликаты в balance_current
        // (PRIMARY KEY = service + account_label), резолвим к canonical labels:
        //   - Если это namecheap username, который соответствует is_default=1 prod-аккаунту,
        //     → используем 'default'.
        //   - Если это конкретный username непрофиля-default — оставляем как есть.
        // Для xmlstock — всегда 'default' (нет multi-account).
        $accountLabel = $this->canonicalAccountLabel($service, $accountLabel);

        // Тянем текущий threshold (если зарегистрирован, иначе default).
        $current = $this->getCurrentRow($service, $accountLabel);
        $threshold = $current
            ? (float)$current['threshold']
            : (self::DEFAULT_THRESHOLDS[$service] ?? 0.0);

        try {
            if ($service === 'namecheap') {
                $check = $this->fetchNamecheapBalance($accountLabel);
            } else {
                $check = $this->fetchXmlStockBalance();
            }
        } catch (Throwable $e) {
            return $this->recordError($service, $accountLabel, $e->getMessage(), $threshold, $trigger);
        }

        if (!$check['ok']) {
            return $this->recordError($service, $accountLabel,
                (string)($check['error'] ?? 'unknown'), $threshold, $trigger);
        }

        $balance = (float)$check['balance'];
        $currency = (string)$check['currency'];
        $isLow = ($balance < $threshold);
        $status = $isLow ? 'low' : 'ok';

        // Записываем снапшот
        $snapshotId = $this->writeSnapshot($service, $accountLabel, $balance, $currency, $status, null, $trigger);

        // Обновляем current state
        $this->updateCurrent($service, $accountLabel, $balance, $currency, $status, $threshold, null);

        // Если low — может быть нужен TG-алерт
        $alertSent = false;
        if ($isLow && $this->shouldSendLowAlert($service, $accountLabel)) {
            try {
                $this->sendLowBalanceAlert($service, $accountLabel, $balance, $currency, $threshold, $trigger);
                $this->markLowAlertSent($service, $accountLabel, $snapshotId);
                $alertSent = true;
            } catch (Throwable $e) {
                // Не падаем — баланс уже записан. Алерт можно повторить позже.
                error_log("BalanceCheckService: TG alert failed: " . $e->getMessage());
            }
        }

        return [
            'ok'         => true,
            'balance'    => $balance,
            'currency'   => $currency,
            'status'     => $status,
            'threshold'  => $threshold,
            'alert_sent' => $alertSent,
        ];
    }

    /**
     * Проверить все зарегистрированные сервисы (для cron'а).
     *
     * @return array<string, array> service => check_result
     */
    public function checkAll(string $trigger = 'cron'): array
    {
        $out = [];
        // По умолчанию проверяем default-лейблы. Можно расширить — итерировать
        // по всем строкам balance_current.
        // v18.1.28 fix: дедупликация — могли остаться дубликаты с разными labels
        // (например 'default' и username аккаунта) после бага в after_purchase.
        // Резолвим каждую запись к canonical-label и проверяем каждую canonical-комбинацию
        // максимум один раз.
        try {
            $rows = DB::pdo()->query("SELECT service, account_label FROM balance_current
                ORDER BY service, account_label")->fetchAll();
            $seen = [];
            foreach ($rows as $r) {
                $service = (string)$r['service'];
                $label = (string)$r['account_label'];
                $canonical = $this->canonicalAccountLabel($service, $label);
                $key = "{$service}:{$canonical}";
                if (isset($seen[$key])) continue; // уже проверили этот canonical вариант
                $seen[$key] = true;
                $out[$key] = $this->checkOne($service, $trigger, $canonical);
            }
        } catch (Throwable $e) {
            $out['_error'] = ['ok' => false, 'error' => $e->getMessage()];
        }
        return $out;
    }

    /**
     * v18.1.28: резолвит accountLabel к canonical-значению чтобы избежать дубликатов
     * в balance_current.
     *
     * Проблема: разные триггеры передают разные labels для одного и того же аккаунта:
     *   - cron / initial INSERT IGNORE / status-bar  → 'default'
     *   - after_purchase trigger в DomainPurchaseService → '$account[username]'
     *
     * Хотя BalanceCheckService::resolveNamecheapAccount('default') и
     * resolveNamecheapAccount('rodion.minskoff') возвращают **один и тот же** prod-аккаунт,
     * в balance_current создавались две строки (PRIMARY KEY = service+account_label).
     *
     * Решение: если accountLabel соответствует prod-аккаунту с is_default=1, резолвим
     * его к 'default'. Иначе оставляем как есть (для случая когда у вас несколько
     * Namecheap-аккаунтов и каждый нужен отдельно).
     *
     * Для xmlstock — всегда 'default' (нет multi-account).
     */
    private function canonicalAccountLabel(string $service, string $accountLabel): string
    {
        if ($service === 'xmlstock') {
            return 'default'; // один сервис — одна запись
        }

        if ($service !== 'namecheap') {
            return $accountLabel;
        }

        $accountLabel = trim($accountLabel);
        if ($accountLabel === '' || $accountLabel === 'default') {
            return 'default';
        }

        // Если это id числовой — оставляем как есть (явный выбор не-default аккаунта)
        if (ctype_digit($accountLabel)) {
            return $accountLabel;
        }

        // Если это username — проверяем не он ли соответствует is_default=1 prod-аккаунту.
        // Если да → канонизируем к 'default'.
        try {
            $st = DB::pdo()->prepare(
                "SELECT id, username, is_default FROM registrar_accounts
                 WHERE provider='namecheap' AND username=? AND COALESCE(is_sandbox,0)=0 LIMIT 1");
            $st->execute([$accountLabel]);
            $row = $st->fetch();
            if ($row && (int)$row['is_default'] === 1) {
                return 'default';
            }
        } catch (Throwable $e) {
            // БД упала — оставляем как есть, не блокируем
        }

        return $accountLabel;
    }

    // ==================================================
    // Внутренние методы — fetch баланса с провайдеров
    // ==================================================

    /**
     * Тянет баланс с Namecheap. Использует prod-аккаунт по умолчанию.
     *
     * @return array{ok: bool, balance?: float, currency?: string, error?: string}
     */
    private function fetchNamecheapBalance(string $accountLabel): array
    {
        // Подбираем prod-аккаунт. По умолчанию — is_default=1 AND is_sandbox=0.
        // Если accountLabel — конкретный id или username, ищем по нему.
        $account = $this->resolveNamecheapAccount($accountLabel);
        if (!$account) {
            return ['ok' => false, 'error' => 'no prod namecheap account found'];
        }

        $apiKey = Crypto::decrypt((string)$account['api_key_enc']);
        $clientIp = (string)($account['client_ip'] ?? '');
        if ($clientIp === '') {
            // Fallback на нашу панель-IP (Namecheap требует whitelist в API IP)
            $clientIp = trim((string)config('namecheap.client_ip', ''));
        }
        if ($clientIp === '') {
            return ['ok' => false, 'error' => 'no client_ip configured for namecheap account'];
        }

        $endpoint = (string)$account['endpoint'];
        if ($endpoint === '') {
            $endpoint = $account['is_sandbox']
                ? 'https://api.sandbox.namecheap.com/xml.response'
                : 'https://api.namecheap.com/xml.response';
        }

        $client = new NamecheapClient(
            $endpoint,
            (string)$account['api_user'],
            $apiKey,
            (string)$account['username'],
            $clientIp,
            30
        );
        $data = $client->getBalances();

        return [
            'ok'       => true,
            'balance'  => (float)$data['available_balance'],
            'currency' => (string)$data['currency'],
            'meta'     => $data,
        ];
    }

    /**
     * Тянет баланс с XMLStock.
     *
     * v18.1.28 hot-fix: точный endpoint balance API скрыт за авторизацией.
     * Пробуем известные кандидаты по очереди:
     *   1) /api/balance/  — стандартный REST-like
     *   2) /api/getbalance/  — альтернатива (по аналогии с другими сервисами)
     *   3) /balance/  — короткий
     *   4) /yandexxml/balance/  — по аналогии с /yandexlive/xml/ endpoint'ом
     *
     * Возвращаем первый ответ который вернул HTTP 200 с валидным JSON и balance-полем.
     * Если все 404 — возвращаем ошибку с указанием что endpoint нужно поправить.
     *
     * Можно переопределить через xmlstock_settings.balance_endpoint (если в БД задан).
     *
     * @return array{ok: bool, balance?: float, currency?: string, error?: string}
     */
    private function fetchXmlStockBalance(): array
    {
        $settings = $this->getXmlStockSettings();
        if (!$settings || empty($settings['user_id']) || empty($settings['api_key'])) {
            return ['ok' => false, 'error' => 'xmlstock not configured (user_id or api_key missing)'];
        }

        // Список endpoints для проверки. Если в БД переопределён — он идёт первым.
        $candidates = [];
        if (!empty($settings['balance_endpoint'])) {
            $candidates[] = (string)$settings['balance_endpoint'];
        }
        $candidates = array_merge($candidates, [
            'https://xmlstock.com/api/balance/',
            'https://xmlstock.com/api/getbalance/',
            'https://xmlstock.com/balance/',
            'https://xmlstock.com/yandexxml/balance/',
            'https://xmlstock.com/api/?do=balance',
            'https://xmlstock.com/?do=balance',
        ]);

        $errors = [];
        foreach ($candidates as $endpoint) {
            $url = $endpoint . (strpos($endpoint, '?') !== false ? '&' : '?')
                 . http_build_query([
                     'user' => $settings['user_id'],
                     'key'  => $settings['api_key'],
                 ]);

            [$body, $code, $err] = $this->httpGet($url);

            if ($err !== '') {
                $errors[$endpoint] = "curl: {$err}";
                continue;
            }
            if ($code === 404) {
                $errors[$endpoint] = '404';
                continue;
            }
            if ($code !== 200) {
                $errors[$endpoint] = "HTTP {$code}";
                continue;
            }

            // Пробуем JSON-парсинг
            $balance = $this->parseXmlStockBalanceBody($body);
            if ($balance !== null) {
                // Сохраним рабочий endpoint в БД чтобы в следующий раз не перебирать.
                $this->saveWorkingXmlStockEndpoint($endpoint);
                return [
                    'ok'       => true,
                    'balance'  => $balance,
                    'currency' => 'RUB',
                    'meta'     => ['endpoint' => $endpoint, 'raw' => mb_substr($body, 0, 300)],
                ];
            }
            $errors[$endpoint] = 'no balance in response: ' . mb_substr($body, 0, 150);
        }

        // Все endpoints провалились
        $summary = "Не нашли рабочий balance endpoint. Попробованы:\n";
        foreach ($errors as $ep => $errMsg) {
            $summary .= "  - {$ep} → {$errMsg}\n";
        }
        $summary .= "Найди правильный URL balance API в личном кабинете xmlstock.com (Помощь → API) " .
                    "и пропиши в БД: UPDATE xmlstock_settings SET balance_endpoint='URL' WHERE id=1";
        return ['ok' => false, 'error' => $summary];
    }

    /**
     * Простой curl GET (helper).
     */
    private function httpGet(string $url): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json,application/xml,*/*',
                'User-Agent: RefreshPanel/v18.1.28-balance-check',
            ],
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($body === false) $body = '';
        return [(string)$body, $code, $err];
    }

    /**
     * Парсит body XMLStock balance-ответа (JSON или XML с balance-полем).
     * Возвращает float баланса или null если не нашёл.
     */
    private function parseXmlStockBalanceBody(string $body): ?float
    {
        $body = trim($body);
        if ($body === '') return null;

        // JSON
        if ($body[0] === '{' || $body[0] === '[') {
            $data = json_decode($body, true);
            if (is_array($data)) {
                // Возможные ключи: balance, amount, rub, money, account_balance, available
                foreach (['balance', 'amount', 'rub', 'money', 'account_balance', 'available'] as $key) {
                    if (isset($data[$key]) && is_numeric($data[$key])) {
                        return (float)$data[$key];
                    }
                    if (isset($data['data'][$key]) && is_numeric($data['data'][$key])) {
                        return (float)$data['data'][$key];
                    }
                    if (isset($data['result'][$key]) && is_numeric($data['result'][$key])) {
                        return (float)$data['result'][$key];
                    }
                }
                // Если в data есть error — это не баланс, а ошибка API
                if (isset($data['error']) || isset($data['errors'])) return null;
            }
        }

        // XML — если расширение simplexml доступно
        if ($body[0] === '<' && function_exists('simplexml_load_string')) {
            $xml = @simplexml_load_string($body);
            if ($xml !== false) {
                // Ищем <balance>...</balance> или атрибут balance
                $vals = $xml->xpath('//balance') ?: [];
                foreach ($vals as $v) {
                    $s = trim((string)$v);
                    if (is_numeric($s)) return (float)$s;
                }
            }
        }

        // Regex fallback — иногда балансы в plain text типа "balance: 123.45"
        if (preg_match('~(?:balance|баланс)\D{0,5}(\d+(?:[.,]\d+)?)~iu', $body, $m)) {
            return (float)str_replace(',', '.', $m[1]);
        }

        return null;
    }

    /**
     * Сохраняет рабочий balance endpoint в xmlstock_settings, чтобы
     * в следующий раз не перебирать все варианты.
     */
    private function saveWorkingXmlStockEndpoint(string $endpoint): void
    {
        try {
            // Колонка может отсутствовать (старая БД) — не падаем
            DB::pdo()->prepare("UPDATE xmlstock_settings SET balance_endpoint=? WHERE id=1")
                ->execute([$endpoint]);
        } catch (\Throwable $e) {
            // Колонки нет — это ок, в следующий раз перебор будет повторно (быстро если первый угадан)
        }
    }

    // ==================================================
    // БД helpers
    // ==================================================

    private function resolveNamecheapAccount(string $accountLabel): ?array
    {
        // Если label похож на числовой id — ищем по id
        if (ctype_digit($accountLabel) && (int)$accountLabel > 0) {
            $st = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'");
            $st->execute([(int)$accountLabel]);
            $r = $st->fetch();
            if ($r) return $r;
        }

        // 'default' → is_default=1 AND prod (не sandbox)
        if ($accountLabel === 'default' || $accountLabel === '') {
            $st = DB::pdo()->query("SELECT * FROM registrar_accounts
                WHERE provider='namecheap' AND is_default=1 AND COALESCE(is_sandbox,0)=0 LIMIT 1");
            $r = $st->fetch();
            if ($r) return $r;

            // fallback: первый prod
            $st = DB::pdo()->query("SELECT * FROM registrar_accounts
                WHERE provider='namecheap' AND COALESCE(is_sandbox,0)=0 ORDER BY id LIMIT 1");
            $r = $st->fetch();
            if ($r) return $r;
        }

        // Иначе — по username
        $st = DB::pdo()->prepare("SELECT * FROM registrar_accounts
            WHERE provider='namecheap' AND username=? AND COALESCE(is_sandbox,0)=0 LIMIT 1");
        $st->execute([$accountLabel]);
        $r = $st->fetch();
        return $r ?: null;
    }

    private function getXmlStockSettings(): ?array
    {
        try {
            $st = DB::pdo()->query("SELECT * FROM xmlstock_settings WHERE id=1");
            $r = $st->fetch();
            return $r ?: null;
        } catch (Throwable $e) {
            return null;
        }
    }

    private function getCurrentRow(string $service, string $label): ?array
    {
        try {
            $st = DB::pdo()->prepare("SELECT * FROM balance_current
                WHERE service=? AND account_label=?");
            $st->execute([$service, $label]);
            $r = $st->fetch();
            return $r ?: null;
        } catch (Throwable $e) {
            return null;
        }
    }

    private function writeSnapshot(
        string $service, string $label, float $balance, string $currency,
        string $status, ?string $errMsg, string $trigger
    ): int {
        $st = DB::pdo()->prepare("INSERT INTO balance_snapshots
            (service, account_label, balance, currency, status, error_message, trigger_source, checked_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        $st->execute([$service, $label, $balance, $currency, $status, $errMsg, $trigger]);
        return (int)DB::pdo()->lastInsertId();
    }

    private function updateCurrent(
        string $service, string $label, float $balance, string $currency,
        string $status, float $threshold, ?string $errMsg
    ): void {
        // Сохраняем previous threshold если уже был — обновляем только если в default ещё.
        DB::pdo()->prepare("INSERT INTO balance_current
            (service, account_label, balance, currency, status, threshold, error_message, last_checked_at, last_ok_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)
            ON DUPLICATE KEY UPDATE
                balance = VALUES(balance),
                currency = VALUES(currency),
                status = VALUES(status),
                error_message = VALUES(error_message),
                last_checked_at = NOW(),
                last_ok_at = CASE WHEN VALUES(status) <> 'error' THEN NOW() ELSE last_ok_at END
        ")->execute([
            $service, $label, $balance, $currency, $status, $threshold, $errMsg,
            $status === 'error' ? null : date('Y-m-d H:i:s'),
        ]);
    }

    private function recordError(
        string $service, string $label, string $errMsg, float $threshold, string $trigger
    ): array {
        $this->writeSnapshot($service, $label, 0, '', 'error', $errMsg, $trigger);
        // current — обновляем status=error, но balance/currency оставляем прежними
        DB::pdo()->prepare("INSERT INTO balance_current
            (service, account_label, balance, currency, status, threshold, error_message, last_checked_at)
            VALUES (?, ?, 0, '', 'error', ?, ?, NOW())
            ON DUPLICATE KEY UPDATE
                status = 'error',
                error_message = VALUES(error_message),
                last_checked_at = NOW()
        ")->execute([$service, $label, $threshold, $errMsg]);

        return [
            'ok'     => false,
            'status' => 'error',
            'error'  => $errMsg,
        ];
    }

    // ==================================================
    // TG-алерты
    // ==================================================

    private function shouldSendLowAlert(string $service, string $label): bool
    {
        $row = $this->getCurrentRow($service, $label);
        if (!$row) return true;
        $lastAlert = (string)($row['last_low_alert_at'] ?? '');
        if ($lastAlert === '') return true;
        $sec = time() - strtotime($lastAlert);
        return $sec >= self::LOW_ALERT_COOLDOWN_SEC;
    }

    private function markLowAlertSent(string $service, string $label, int $snapshotId): void
    {
        DB::pdo()->prepare("UPDATE balance_current
            SET last_low_alert_at = NOW()
            WHERE service=? AND account_label=?")->execute([$service, $label]);
        DB::pdo()->prepare("UPDATE balance_snapshots
            SET tg_alert_sent = 1, tg_alert_sent_at = NOW()
            WHERE id=?")->execute([$snapshotId]);
    }

    /**
     * Отправляет TG-алерт о низком балансе с упоминанием всех участников.
     * Список получателей берётся из telegram_settings.mention_usernames.
     */
    private function sendLowBalanceAlert(
        string $service, string $label, float $balance, string $currency,
        float $threshold, string $trigger
    ): void {
        $serviceTitle = $service === 'namecheap' ? 'Namecheap' : 'XMLStock';
        $balanceStr = $currency === 'USD'
            ? '$' . number_format($balance, 2)
            : number_format($balance, 2) . ' ₽';
        $thresholdStr = $currency === 'USD'
            ? '$' . number_format($threshold, 2)
            : number_format($threshold, 2) . ' ₽';

        $mentions = $this->collectTgMentions();
        $mentionsLine = $mentions !== '' ? "\n\n👥 " . $mentions : '';

        // HTML формат (TelegramService::send использует parse_mode=HTML)
        $msg = "⚠️ <b>Низкий баланс {$serviceTitle}</b>\n\n"
             . "Аккаунт: <code>" . htmlspecialchars($label) . "</code>\n"
             . "Текущий баланс: <b>{$balanceStr}</b>\n"
             . "Порог уведомления: {$thresholdStr}\n"
             . "Триггер проверки: <code>" . htmlspecialchars($trigger) . "</code>\n\n"
             . "💸 Пополни баланс чтобы pipeline не остановился."
             . $mentionsLine;

        // Используем существующий TelegramService
        if (class_exists('TelegramService')) {
            $tg = new TelegramService();
            $tg->send($msg);
        }
    }

    /**
     * Собирает строку с @упоминаниями всех участников для алерта.
     * Источник: telegram_settings.mention_usernames (v18.1.28).
     */
    private function collectTgMentions(): string
    {
        try {
            $st = DB::pdo()->query("SELECT mention_usernames FROM telegram_settings WHERE id=1");
            $r = $st->fetch();
            if (!$r || empty($r['mention_usernames'])) return '';

            $usernames = preg_split('~[\s,]+~', (string)$r['mention_usernames'], -1, PREG_SPLIT_NO_EMPTY);
            $tags = [];
            foreach ($usernames as $u) {
                $u = ltrim($u, '@');
                if ($u !== '') $tags[] = '@' . $u;
            }
            return implode(' ', $tags);
        } catch (Throwable $e) {
            // mention_usernames колонка может отсутствовать (миграция 015 не применена) — silent.
            return '';
        }
    }
}
