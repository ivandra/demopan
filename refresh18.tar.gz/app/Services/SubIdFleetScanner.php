<?php

/**
 * SubIdFleetScanner — read-only обход парка: классификация каждого сайта по
 * StaticSiteConfigScanner. Ядро CLI bin/fleet_subid_dry_run.php; в тестах
 * прогоняется через seam (fake sync + fake rows) без FTP/БД.
 *
 * Никаких записей: только fetchFromVpsReadOnly + scan.
 */
final class SubIdFleetScanner
{
    private StaticSiteConfigScanner $scanner;

    public function __construct(?StaticSiteConfigScanner $scanner = null)
    {
        $this->scanner = $scanner ?: new StaticSiteConfigScanner();
    }

    /** decision: SAFE | DOMAIN_ONLY | NO_SUB_ID | <blocker-reason> | FTP_ERROR */
    public function classify(array $site, array $fetch): array
    {
        $sid = (int)($site['id'] ?? 0);
        if (empty($fetch['ok'])) {
            return ['site_id' => $sid, 'decision' => 'FTP_ERROR', 'error' => (string)($fetch['error'] ?? 'read failed')];
        }
        $scan = $this->scanner->scan((string)$fetch['raw']);
        if ($scan->state === 'parse_error') {
            return ['site_id' => $sid, 'decision' => 'php_parse_error'];
        }
        if (!$scan->isSafe()) {
            return ['site_id' => $sid, 'decision' => $scan->reason(),
                    'details' => $scan->details()];
        }
        $sub = $scan->uniqueSubIdOrNull();
        $decision = $sub !== null ? 'SAFE' : ($scan->domainRequired() ? 'DOMAIN_ONLY' : 'NO_SUB_ID');
        return ['site_id' => $sid, 'decision' => $decision, 'sub_id' => $sub,
                'domain_required' => $scan->domainRequired()];
    }

    private function isBlocker(string $decision): bool
    {
        return !in_array($decision, ['SAFE', 'DOMAIN_ONLY', 'NO_SUB_ID'], true);
    }

    /**
     * @param array    $sites     строки sites_managed
     * @param callable $fetchFn   fn(array $site): array  (read-only fetch)
     * @param int      $totalCount  SELECT COUNT(*) FROM sites_managed
     * @return array ['rows','processed','total','blockers','exit']
     */
    public function run(array $sites, callable $fetchFn, int $totalCount): array
    {
        $rows = [];
        foreach ($sites as $site) {
            try {
                $fetch = $fetchFn($site);
                $rows[] = $this->classify((array)$site, (array)$fetch);
            } catch (\Throwable $e) {
                $rows[] = ['site_id' => (int)($site['id'] ?? 0), 'decision' => 'FTP_ERROR', 'error' => $e->getMessage()];
            }
        }
        $processed = count($rows);
        $blockers = false;
        foreach ($rows as $r) if ($this->isBlocker((string)$r['decision'])) { $blockers = true; break; }

        if ($processed === 0 || $processed !== $totalCount) {
            $exit = 3;
        } else {
            $exit = $blockers ? 2 : 0;
        }
        return ['rows' => $rows, 'processed' => $processed, 'total' => $totalCount,
                'blockers' => $blockers, 'exit' => $exit];
    }
}
