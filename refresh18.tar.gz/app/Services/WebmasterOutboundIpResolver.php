<?php

/**
 * PATCH 047 §15/§16 — резолвер жёсткого исходящего IPv4 для аккаунта Yandex.Webmaster.
 *
 * account.outbound_ip_id задан → взять этот IP (обязан существовать и быть enabled).
 * account.outbound_ip_id NULL   → взять единственный enabled is_default=1.
 *
 * FAIL CLOSED (WebmasterTransportException::RESOLVE_FAILED), если:
 *   - нет default / default disabled / несколько default;
 *   - assigned IP отсутствует / disabled.
 * Никакого system fallback: NULL НЕ означает «пусть Linux сам выберет адрес» (§2).
 */
class WebmasterOutboundIpResolver
{
    /**
     * @return array{ip_id:int, ip_address:string, source:'assigned'|'default', is_enabled:bool}
     * @throws WebmasterTransportException RESOLVE_FAILED
     */
    public function resolveForAccount(int $accountId): array
    {
        if ($accountId <= 0) {
            $this->fail("resolveForAccount: некорректный accountId ({$accountId})");
        }
        $pdo = DB::pdo();

        $st = $pdo->prepare("SELECT outbound_ip_id FROM yandex_webmaster_accounts WHERE id = ? LIMIT 1");
        $st->execute([$accountId]);
        $row = $st->fetch();
        if (!$row) {
            $this->fail("Аккаунт Webmaster #{$accountId} не найден");
        }
        $assignedId = $row['outbound_ip_id'];

        if ($assignedId !== null && $assignedId !== '') {
            $ip = $this->loadIpRow((int)$assignedId);
            if ($ip === null) {
                $this->fail("Назначенный исходящий IP (id={$assignedId}) аккаунта #{$accountId} отсутствует в пуле");
            }
            if ((int)$ip['is_enabled'] !== 1) {
                $this->fail("Назначенный исходящий IP {$ip['ip_address']} аккаунта #{$accountId} выключен");
            }
            return [
                'ip_id'      => (int)$ip['id'],
                'ip_address' => (string)$ip['ip_address'],
                'source'     => 'assigned',
                'is_enabled' => true,
            ];
        }

        // NULL → DEFAULT (строго: ровно один enabled default).
        $def = $this->resolveDefault();
        return [
            'ip_id'      => (int)$def['id'],
            'ip_address' => (string)$def['ip_address'],
            'source'     => 'default',
            'is_enabled' => true,
        ];
    }

    /**
     * Единственный enabled default. FAIL CLOSED при count!=1.
     * @return array{id:int, ip_address:string}
     */
    public function resolveDefault(): array
    {
        $pdo = DB::pdo();
        $rows = $pdo->query(
            "SELECT id, ip_address FROM webmaster_outbound_ips WHERE is_default=1 AND is_enabled=1"
        )->fetchAll();
        $n = count($rows);
        if ($n === 0) {
            $this->fail('В пуле нет включённого DEFAULT исходящего IP');
        }
        if ($n > 1) {
            $this->fail("В пуле несколько DEFAULT исходящих IP ({$n}) — конфигурация некорректна");
        }
        return ['id' => (int)$rows[0]['id'], 'ip_address' => (string)$rows[0]['ip_address']];
    }

    /** @return array|null */
    private function loadIpRow(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM webmaster_outbound_ips WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    /** @throws WebmasterTransportException */
    private function fail(string $msg): void
    {
        throw new WebmasterTransportException(
            WebmasterTransportException::RESOLVE_FAILED,
            $msg
        );
    }
}
