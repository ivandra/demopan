<?php

/**
 * Helper для cron-эндпоинта.
 *
 * v18.1.29: РЕАРХИТЕКТУРА для параллельной обработки джоб.
 *
 * Раньше был ОДИН глобальный lock `rfp_refresh_orchestrator` — все джобы
 * обрабатывались строго sequential, одна за другой. Это превращало панель
 * в очередь: 10 джоб = 10+ минут обработки.
 *
 * Теперь:
 *   - PICKING LOCK — короткий лок ТОЛЬКО на момент SELECT'а джоб из очереди
 *     (~10ms). Защищает от race condition между параллельными cron-инстансами.
 *   - PER-JOB LOCK `rfp_job_<id>` — берётся для каждой джобы перед обработкой.
 *     Защищает джобу от двойной обработки (cron + manual runStep, или 2 cron-tick'а).
 *
 * Использование:
 *   $guard = new CronGuard('refresh_orchestrator');
 *
 *   // Token check (без lock'ов)
 *   if (!$guard->checkToken(...)) { http_response_code(403); exit; }
 *
 *   // Picking lock (короткий, для SELECT'а)
 *   if (!$guard->acquirePickingLock()) { echo "busy_picking"; exit; }
 *   $jobs = $guard->pickJobs($limit);
 *   $guard->releasePickingLock();
 *
 *   // Per-job обработка (без global lock!)
 *   foreach ($jobs as $job) {
 *       $jobGuard = CronGuard::forJob($job['id']);
 *       if (!$jobGuard->acquireJobLock()) continue; // другой воркер обрабатывает
 *       try {
 *           $orch->step($job);
 *       } finally {
 *           $jobGuard->releaseJobLock();
 *       }
 *   }
 *
 *   $guard->finishOk(['jobs_processed' => 3]);
 */
class CronGuard
{
    /** Lock name prefixes */
    private const PICKING_LOCK_NAME = 'rfp_picking';
    private const JOB_LOCK_PREFIX   = 'rfp_job_';

    /** Maximum jobs to pick per cron tick (configurable). */
    public const DEFAULT_MAX_JOBS_PER_TICK = 5;

    /** Stale lock threshold — если воркер крашнулся, считаем lock протухшим через N минут. */
    public const STALE_JOB_LOCK_SEC = 600; // 10 минут

    private string $cronName;
    private string $lockName;
    private float $startedAtMicro = 0.0;
    private bool $hasPickingLock = false;
    private ?int $jobLockedId = null;
    private bool $legacyGlobalLocked = false;

    public function __construct(string $cronName)
    {
        $this->cronName = $cronName;
        $this->startedAtMicro = microtime(true); // v25.2-b: для duration_sec в heartbeat
        // GET_LOCK имена ограничены 64 символами
        $this->lockName = 'rfp_' . preg_replace('~[^a-zA-Z0-9_]~', '_', $cronName);
        $this->lockName = mb_substr($this->lockName, 0, 60);
    }

    /**
     * v18.1.29: Создать CronGuard для конкретной джобы.
     * Возвращает instance с настроенным per-job lock name.
     */
    public static function forJob(int $jobId): self
    {
        $self = new self("job_{$jobId}");
        $self->lockName = self::JOB_LOCK_PREFIX . $jobId;
        $self->jobLockedId = null; // будет установлен при acquireJobLock
        return $self;
    }

    /**
     * Безопасное сравнение токена (защита от timing attack).
     */
    public function checkToken(string $providedToken): bool
    {
        $expected = (string)config('cron.token', '');
        if ($expected === '') {
            // Не настроен — считаем 403, чтобы не оставлять открытым случайно
            return false;
        }
        if (strlen($providedToken) !== strlen($expected)) {
            return false;
        }
        return hash_equals($expected, $providedToken);
    }

    // ============================================================
    // v18.1.29: PICKING LOCK — короткий лок ТОЛЬКО на момент SELECT'а
    // ============================================================

    /**
     * Захватить picking-lock. Используется для атомарного SELECT'а
     * следующих джоб в очереди. Параллельный cron-tick подождёт ~10ms
     * и возьмёт следующую партию (без пересечения с этой).
     *
     * Возвращает false если другой cron-tick прямо сейчас выбирает >5сек.
     * Это сигнал что что-то пошло не так — лучше пропустить tick.
     */
    public function acquirePickingLock(): bool
    {
        try {
            // 5 секунд таймаут — picking операция короткая (~10ms), но даём запас
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, 5)");
            $st->execute([self::PICKING_LOCK_NAME]);
            $r = $st->fetchColumn();
            $this->hasPickingLock = ((int)$r === 1);
            return $this->hasPickingLock;
        } catch (\Throwable $e) {
            error_log("CronGuard: acquirePickingLock failed: " . $e->getMessage());
            return false;
        }
    }

    public function releasePickingLock(): void
    {
        if (!$this->hasPickingLock) return;
        try {
            $st = DB::pdo()->prepare("SELECT RELEASE_LOCK(?)");
            $st->execute([self::PICKING_LOCK_NAME]);
            $this->hasPickingLock = false;
        } catch (\Throwable $e) {
            error_log("CronGuard: releasePickingLock failed: " . $e->getMessage());
        }
    }

    /**
     * v18.1.29: Выбрать следующие джобы для обработки.
     *
     * ВАЖНО: вызывать ТОЛЬКО под picking-lock'ом (acquirePickingLock() = true).
     *
     * Возвращает массив джоб (может быть пустой).
     */
    public function pickJobs(int $limit = self::DEFAULT_MAX_JOBS_PER_TICK): array
    {
        if (!$this->hasPickingLock) {
            error_log("CronGuard::pickJobs called without picking lock — refusing");
            return [];
        }

        $limit = max(1, min(50, $limit));

        // Те же условия что были в CronController.
        // ORDER BY id ASC — справедливая очередь (FIFO).
        $stalledThreshold = "(stage_status = 'running' AND stage_started_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE))";
        $retryAwaiting = "(stage_status = 'awaiting_user' AND next_run_at IS NOT NULL AND next_run_at <= NOW())";

        $sql = "SELECT * FROM refresh_jobs
                WHERE stage NOT IN ('done','failed','cancelled','superseded')
                  AND (
                      (stage_status IN ('pending','ok') AND (next_run_at IS NULL OR next_run_at <= NOW()))
                      OR {$stalledThreshold}
                      OR {$retryAwaiting}
                  )
                ORDER BY id ASC
                LIMIT " . (int)$limit;

        try {
            $rows = DB::pdo()->query($sql)->fetchAll();
            return $rows ?: [];
        } catch (\Throwable $e) {
            error_log("CronGuard::pickJobs failed: " . $e->getMessage());
            return [];
        }
    }

    // ============================================================
    // v18.1.29: PER-JOB LOCK — для индивидуальной обработки джобы
    // ============================================================

    /**
     * v18.1.29: Захватить per-job lock.
     *
     * Использование (после CronGuard::forJob($id)):
     *   $jobGuard = CronGuard::forJob($jobId);
     *   if (!$jobGuard->acquireJobLock()) {
     *       // другой воркер обрабатывает эту джобу прямо сейчас — пропускаем
     *       continue;
     *   }
     *   try { ... } finally { $jobGuard->releaseJobLock(); }
     */
    public function acquireJobLock(): bool
    {
        if (strpos($this->lockName, self::JOB_LOCK_PREFIX) !== 0) {
            error_log("CronGuard::acquireJobLock called on non-job guard ({$this->lockName})");
            return false;
        }

        try {
            // 0 sec timeout — non-blocking. Если занят — другой обрабатывает.
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, 0)");
            $st->execute([$this->lockName]);
            $r = $st->fetchColumn();
            $ok = ((int)$r === 1);
            if ($ok) {
                $this->jobLockedId = (int)substr($this->lockName, strlen(self::JOB_LOCK_PREFIX));
            }
            return $ok;
        } catch (\Throwable $e) {
            error_log("CronGuard::acquireJobLock failed: " . $e->getMessage());
            return false;
        }
    }

    public function releaseJobLock(): void
    {
        if ($this->jobLockedId === null) return;
        try {
            $st = DB::pdo()->prepare("SELECT RELEASE_LOCK(?)");
            $st->execute([$this->lockName]);
            $this->jobLockedId = null;
        } catch (\Throwable $e) {
            error_log("CronGuard::releaseJobLock failed: " . $e->getMessage());
        }
    }

    // ============================================================
    // LEGACY: глобальный lock (для совместимости и переходного периода)
    // ============================================================

    /**
     * @deprecated v18.1.29: Используй acquirePickingLock + acquireJobLock.
     * Оставлено для случаев когда нужен глобальный лок (например балансы).
     */
    public function acquireLock(): bool
    {
        try {
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, 0)");
            $st->execute([$this->lockName]);
            $r = $st->fetchColumn();
            $this->legacyGlobalLocked = ((int)$r === 1);
            return $this->legacyGlobalLocked;
        } catch (\Throwable $e) {
            error_log("CronGuard: GET_LOCK failed: " . $e->getMessage());
            return false;
        }
    }

    public function releaseLock(): void
    {
        if ($this->legacyGlobalLocked) {
            try {
                $st = DB::pdo()->prepare("SELECT RELEASE_LOCK(?)");
                $st->execute([$this->lockName]);
                $this->legacyGlobalLocked = false;
            } catch (\Throwable $e) {
                error_log("CronGuard: RELEASE_LOCK failed: " . $e->getMessage());
            }
        }
        // На всякий случай освободим и picking-lock + job-lock если остались
        $this->releasePickingLock();
        $this->releaseJobLock();
    }

    public function finishOk(array $stats = []): void
    {
        if ($this->startedAtMicro > 0 && !isset($stats['duration_sec'])) {
            $stats['duration_sec'] = round(microtime(true) - $this->startedAtMicro, 2);
        }
        $this->upsertState(true, null, $stats);
    }

    public function finishError(string $err): void
    {
        $this->upsertState(false, $err, []);
    }

    private function upsertState(bool $ok, ?string $err, array $stats): void
    {
        try {
            $statsJson = json_encode($stats, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $st = DB::pdo()->prepare(
                "INSERT INTO cron_state (cron_name, last_run_at, last_ok, last_error, stats_json)
                 VALUES (?, NOW(), ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                   last_run_at = NOW(),
                   last_ok = VALUES(last_ok),
                   last_error = VALUES(last_error),
                   stats_json = VALUES(stats_json)"
            );
            $st->execute([
                $this->cronName,
                $ok ? 1 : 0,
                $err === null ? null : mb_substr($err, 0, 1000),
                $statsJson,
            ]);
        } catch (\Throwable $e) {
            error_log("CronGuard: upsertState failed: " . $e->getMessage());
        }
    }
}
