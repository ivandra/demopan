<?php

/**
 * SubIdRemediationRunner — прогон remediation для конкретных сайтов через тот же
 * SiteConfigMutationService. Домен не меняется (old==new = текущий домен), sub_id
 * пересчитывается маской и приводится к актуальному значению.
 *
 * dry-run: ТОЛЬКО prepare (read-only), никогда upload/persist; target-файл удаляется.
 * apply:   prepare → applyPrepared (один upload + read-back + persist).
 *
 * Exit:
 *   0 — APPLIED / ALREADY_CURRENT для всех targets;
 *   2 — есть conflict/unknown/parse/FTP/read-back blocker;
 *   3 — targets не найдены.
 */
final class SubIdRemediationRunner
{
    /**
     * @param array $targets [['site_id'=>int,'domain'=>string], ...]
     */
    public function run(array $targets, SiteConfigMutationService $svc, bool $apply, int $jobIdBase = 990000): array
    {
        $summary = ['targeted' => count($targets), 'processed' => 0, 'applied' => 0,
                    'already_current' => 0, 'blocked' => 0, 'errors' => 0, 'rows' => []];

        if (count($targets) === 0) {
            $summary['exit'] = 3;
            return $summary;
        }

        foreach ($targets as $i => $tg) {
            $sid = (int)($tg['site_id'] ?? 0);
            $dom = (string)($tg['domain'] ?? '');
            $jobId = $jobIdBase + $i;
            $summary['processed']++;

            try {
                $prep = $svc->prepare($sid, $jobId, $dom, $dom); // домен не меняется
            } catch (\Throwable $e) {
                $summary['errors']++;
                $summary['rows'][] = ['site_id' => $sid, 'decision' => 'ERROR', 'error' => $e->getMessage()];
                continue;
            }
            if (empty($prep['ok'])) {
                $summary['blocked']++;
                $summary['rows'][] = ['site_id' => $sid, 'decision' => 'BLOCKED', 'reason' => (string)($prep['reason'] ?? 'blocked')];
                continue;
            }
            $plan = $prep['plan'];
            $already = ((string)($plan['old_sub_id'] ?? '') === (string)($plan['new_sub_id'] ?? ''));

            if ($already) {
                $summary['already_current']++;
                $summary['rows'][] = ['site_id' => $sid, 'decision' => 'ALREADY_CURRENT', 'sub_id' => $plan['new_sub_id']];
                $svc->deleteTarget((string)$plan['target_storage_path']); // dry-run/no-op residue
                continue;
            }

            if (!$apply) {
                // dry-run: ничего не пишем; убираем подготовленный target.
                $svc->deleteTarget((string)$plan['target_storage_path']);
                $summary['rows'][] = ['site_id' => $sid, 'decision' => 'WOULD_APPLY',
                    'old_sub_id' => $plan['old_sub_id'], 'new_sub_id' => $plan['new_sub_id']];
                continue;
            }

            $res = $svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
            if (!empty($res['ok'])) {
                $summary['applied']++;
                $summary['rows'][] = ['site_id' => $sid, 'decision' => 'APPLIED',
                    'old_sub_id' => $plan['old_sub_id'], 'new_sub_id' => $plan['new_sub_id']];
            } else {
                $summary['blocked']++;
                $summary['rows'][] = ['site_id' => $sid, 'decision' => 'BLOCKED', 'reason' => (string)($res['reason'] ?? 'apply_failed')];
            }
        }

        $summary['exit'] = ($summary['blocked'] > 0 || $summary['errors'] > 0) ? 2 : 0;
        return $summary;
    }
}
