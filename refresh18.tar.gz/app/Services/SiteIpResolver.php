<?php

/**
 * Резолвер IP-адреса сайта для DNS A-записей.
 *
 * На VPS обычно несколько IP. Сайт в FastPanel «привязан» к одному из них;
 * DNS A-запись нового домена должна указывать на ТОТ ЖЕ IP, что и текущий
 * домен сайта, иначе FastPanel/Apache не направит запросы куда нужно.
 *
 * ТЗ 040 §5.1/§5.3: IP считается корректным по ПРИНАДЛЕЖНОСТИ серверу
 * (allowlist = host-IP + extra_ips), а НЕ по признаку «не равен API-IP».
 * Сайт законно может работать на том же IP, где слушает FastPanel API.
 *
 * Стратегия (для сайта, привязанного к серверу):
 *  1. sites_managed.vps_ip — валиден и входит в allowlist сервера
 *  2. fp_raw_json IP — валиден и входит в allowlist → persist + return
 *  3. live FastPanel /api/sites/{id} IP — валиден и в allowlist → persist + return
 *     (если live вернул IP ВНЕ allowlist — остановка с понятной ошибкой §5.3)
*  (шаг default_site_ip удалён — §3.3: IP по умолчанию на уровне сервера не вводится)
 *  5. RuntimeException до покупки домена
 * Fallback на IP другого сервера или произвольный extra_ips[0] ЗАПРЕЩЁН.
 *
 * Для legacy-сайта БЕЗ fastpanel_server_id допустим старый глобальный
 * fallback config('fastpanel.default_ip') (§5.3 п.6).
 */
class SiteIpResolver
{
    private FastpanelServerIpPolicy $policy;

    public function __construct(?FastpanelServerIpPolicy $policy = null)
    {
        // require_once fallback для юнит-тестов без autoload
        if ($policy === null && !class_exists('FastpanelServerIpPolicy')) {
            require_once __DIR__ . '/FastpanelServerIpPolicy.php';
        }
        $this->policy = $policy ?: new FastpanelServerIpPolicy();
    }

    /**
     * Получить IP сайта.
     *
     * @throws RuntimeException если ни одним допустимым способом не получилось
     */
    public function resolveForSite(int $siteId): string
    {
        $site = $this->loadSite($siteId);
        $serverId = (int)($site['fastpanel_server_id'] ?? 0);
        $server = $serverId > 0 ? $this->loadServer($serverId) : null;

        // ── Legacy-сайт без сервера: старое глобальное поведение (§5.3 п.6) ──
        if ($server === null) {
            $stored = trim((string)($site['vps_ip'] ?? ''));
            if ($stored !== '' && $this->isValidIp($stored)) {
                return $stored;
            }
            $rawIp = $this->extractFromRaw($this->decodeRaw($site));
            if ($rawIp !== '') {
                $this->persist($siteId, $rawIp);
                return $rawIp;
            }
            $defaultIp = trim((string)config('fastpanel.default_ip', ''));
            if ($defaultIp !== '' && $this->isValidIp($defaultIp)) {
                return $defaultIp;
            }
            throw new RuntimeException(
                "Не удалось определить IP сайта #{$siteId} (legacy без сервера). " .
                "Привяжите сайт к серверу или заполни 'fastpanel.default_ip' в config/app.php."
            );
        }

        // ── Сайт привязан к серверу: строго по allowlist (§3.9) ──
        // 1. stored vps_ip
        $stored = trim((string)($site['vps_ip'] ?? ''));
        if ($stored !== '' && $this->policy->isAllowed($server, $stored)) {
            return $stored;
        }

        // 2. fp_raw_json: перебрать ВСЕ кандидаты, взять первый allowed
        //    (не останавливаться на первом запрещённом).
        foreach ($this->candidateIpsFromRaw($this->decodeRaw($site)) as $cand) {
            if ($this->policy->isAllowed($server, $cand)) {
                $this->persist($siteId, $cand);
                return $cand;
            }
        }

        // 3. live FastPanel API: снова перебрать все кандидаты detail
        $fpSiteId = (int)($site['fp_site_id'] ?? 0);
        $liveCandidates = [];
        if ($fpSiteId > 0) {
            try {
                $svc = $this->makeSearchService($serverId);
                $detail = $svc->getSiteDetail($fpSiteId);
                // §2 (аудит ver3): getSiteDetail() возвращает wrapper
                // ['vps_ip'=>.., 'raw'=>$fpDetail]. Кандидаты извлекаем из raw
                // FastPanel-детали (там ips[*]), иначе теряется второй допустимый IP.
                $rawDetail = is_array($detail['raw'] ?? null) ? $detail['raw'] : (is_array($detail) ? $detail : null);
                $liveCandidates = $this->candidateIpsFromData($rawDetail);
                // подстрахуемся верхним vps_ip, если raw его не содержит
                $topIp = is_array($detail) ? trim((string)($detail['vps_ip'] ?? '')) : '';
                if ($topIp !== '' && $this->isValidIp($topIp) && !in_array($topIp, $liveCandidates, true)) {
                    $liveCandidates[] = $topIp;
                }
                foreach ($liveCandidates as $cand) {
                    if ($this->policy->isAllowed($server, $cand)) {
                        $this->persist($siteId, $cand);
                        return $cand;
                    }
                }
            } catch (\Throwable $e) {
                error_log("SiteIpResolver: live FP fetch failed for site #{$siteId}: " . $e->getMessage());
            }
        }

        // live содержит валидные IP, но ни один не в allowlist — стоп с перечислением
        if ($liveCandidates) {
            $allow = implode(', ', $this->policy->allowedIps($server)) ?: '(пусто)';
            throw new RuntimeException(
                "FastPanel сообщил IP " . implode(', ', $liveCandidates) . ", которых нет в настройках сервера " .
                "«" . (string)($server['title'] ?? ('#' . $serverId)) . "» (allowlist: {$allow}). " .
                "Добавьте нужный IP в дополнительные IP сервера или исправьте привязку сайта."
            );
        }

        // 4. Ни одного кандидата — остановка ДО покупки домена (§3.9 п.8)
        throw new RuntimeException(
            "Не удалось определить IP сайта. Обновите данные сайта из FastPanel и " .
            "проверьте его IP перед запуском перевыставления."
        );
    }

    /**
     * Резолв БЕЗ live-запроса (для UI). Тот же приоритет, но без обращения к FP API.
     */
    public function resolveOffline(int $siteId): ?string
    {
        try {
            $site = $this->loadSite($siteId);
        } catch (\Throwable $e) {
            return null;
        }
        $serverId = (int)($site['fastpanel_server_id'] ?? 0);
        $server = $serverId > 0 ? $this->loadServer($serverId) : null;

        if ($server === null) {
            $stored = trim((string)($site['vps_ip'] ?? ''));
            if ($stored !== '' && $this->isValidIp($stored)) return $stored;
            $rawIp = $this->extractFromRaw($this->decodeRaw($site));
            if ($rawIp !== '') return $rawIp;
            $defaultIp = trim((string)config('fastpanel.default_ip', ''));
            if ($defaultIp !== '' && $this->isValidIp($defaultIp)) return $defaultIp;
            return null;
        }

        $stored = trim((string)($site['vps_ip'] ?? ''));
        if ($stored !== '' && $this->policy->isAllowed($server, $stored)) return $stored;

        foreach ($this->candidateIpsFromRaw($this->decodeRaw($site)) as $cand) {
            if ($this->policy->isAllowed($server, $cand)) return $cand;
        }

        return null;
    }

    /**
     * Фабрика live-клиента FastPanel. Выделена, чтобы тесты подменяли
     * live-ответ без реального обращения к API (см. _tests/multi_server).
     */
    protected function makeSearchService(int $serverId): object
    {
        return new FastpanelSearchService($serverId);
    }

    private function loadSite(int $id): array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$id]);
        $site = $st->fetch();
        if (!$site) throw new RuntimeException("Site #{$id} not found");
        return $site;
    }

    private function loadServer(int $serverId): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $st->execute([$serverId]);
        $row = $st->fetch();
        return $row ?: null;
    }

    private function decodeRaw(array $site): ?array
    {
        if (empty($site['fp_raw_json'])) return null;
        $raw = json_decode((string)$site['fp_raw_json'], true);
        return is_array($raw) ? $raw : null;
    }

    /**
     * ТЗ 040 FINAL-3 §3.8/§3.9: извлечь ВСЕ валидные IPv4-кандидаты из массива
     * FastPanel-детали/raw. Обходит одиночные поля, массивы и вложенный server.*.
     * Уникальные, в порядке появления. НЕ выбирает host-IP «просто так».
     *
     * @return array<int,string>
     */
    public function candidateIpsFromData(?array $data): array
    {
        if (!is_array($data)) return [];
        $out = [];
        $add = function ($v) use (&$out) {
            if (is_string($v)) {
                $v = trim($v);
                if ($v !== '' && $this->isValidIp($v) && !in_array($v, $out, true)) $out[] = $v;
            }
        };
        // одиночные поля верхнего уровня
        foreach (['ip_addr', 'ip', 'ipv4', 'address', 'vps_ip'] as $f) {
            if (isset($data[$f])) $add($data[$f]);
        }
        // массивы IP
        foreach (['ip_addrs', 'ips'] as $f) {
            if (isset($data[$f]) && is_array($data[$f])) {
                foreach ($data[$f] as $el) {
                    if (is_string($el)) { $add($el); continue; }
                    if (is_array($el)) {
                        foreach (['ip', 'address', 'value', 'ipv4', 'ip_addr'] as $k) {
                            if (isset($el[$k])) $add($el[$k]);
                        }
                    }
                }
            }
        }
        // вложенный server.*
        if (isset($data['server']) && is_array($data['server'])) {
            foreach (['ip', 'ip_addr', 'address', 'ipv4'] as $k) {
                if (isset($data['server'][$k])) $add($data['server'][$k]);
            }
        }
        return $out;
    }

    /** Все IP-кандидаты из fp_raw_json (decode + extract). @return array<int,string> */
    public function candidateIpsFromRaw(?array $raw): array
    {
        return $this->candidateIpsFromData($raw);
    }

    /** Первый валидный IP из raw (для legacy-пути без сервера). */
    private function extractFromRaw(?array $raw): string
    {
        $c = $this->candidateIpsFromRaw($raw);
        return $c[0] ?? '';
    }

    private function persist(int $siteId, string $ip): void
    {
        try {
            $st = DB::pdo()->prepare(
                "UPDATE sites_managed SET vps_ip=? WHERE id=? AND (vps_ip IS NULL OR vps_ip='' OR vps_ip<>?)"
            );
            $st->execute([$ip, $siteId, $ip]);
        } catch (\Throwable $e) {
            error_log("SiteIpResolver::persist failed: " . $e->getMessage());
        }
    }

    private function isValidIp(string $ip): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
    }
}
