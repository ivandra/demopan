<?php

/**
 * v25.1-b: полная проверка одного домена для SSL-вкладки и мониторинга.
 *
 * ОТЛИЧАЕТСЯ от существующего SslLiveCheckService (тот проверяет TLS для стадии
 * ssl_le_polling выпуска сертификата и НЕ трогается). Здесь — комплексная
 * проверка доступности + SSL для UI/мониторинга.
 *
 * Выполняет (ТЗ §5): публичный DNS → HTTP без follow (+Location) → запрос с
 * YandexBot UA → HTTPS с анализом redirect → отдельный разбор сертификата
 * (даже self-signed/expired/mismatch) → probe при активной джобе → нормализует
 * и классифицирует статус. НИЧЕГО не пишет в БД — это делает репозиторий.
 *
 * Публичный DNS, без CURLOPT_RESOLVE (ТЗ §3.1). Секреты не логирует.
 */
class DomainSslCheckService
{
    /** @var HttpProbeInterface */
    private $probe;

    public function __construct(?HttpProbeInterface $probe = null)
    {
        $this->probe = $probe ?? new CurlHttpProbe();
    }

    /* ==================== СТАТУСЫ ==================== */
    const S_TRUSTED        = 'trusted';        // 🟢 доступен, SSL доверенный
    const S_SELF_SIGNED    = 'self_signed';    // 🟡 доступен, SSL временный
    const S_ISSUING        = 'ssl_issuing';    // 🟡 301, выпуск SSL продолжается
    const S_VERIFY_PENDING = 'verify_pending'; // 🟠 доступен, verification не прошла
    const S_MISMATCH       = 'hostname_mismatch'; // 🔴 SSL не соответствует домену
    const S_EXPIRED        = 'expired';        // 🔴 сертификат просрочен
    const S_NOT_YET_VALID  = 'not_yet_valid';  // 🔴 сертификат ещё не действует
    const S_SITE_ERROR     = 'site_error';     // 🔴 TLS есть, но сайт не отвечает корректно
    const S_UNREACHABLE    = 'unreachable';    // 🔴 сайт недоступен
    const S_NOT_CHECKED    = 'not_checked';    // ⚪ ещё не проверялся

    /**
     * Полная проверка. Возвращает нормализованный массив полей ровно под
     * колонки domain_ssl_statuses + человекочитаемый reason.
     *
     * @param string      $domain
     * @param int|null    $siteId
     * @param int|null    $jobId      активная джоба (для probe), если есть
     * @param string|null $probeToken токен probe-файла активной джобы
     * @param string      $source     'manual'|'cron'|'job'
     */
    public function check(string $domain, ?int $siteId = null, ?int $jobId = null,
        ?string $probeToken = null, string $source = 'manual'): array
    {
        $domain = strtolower(trim($domain));
        $startedUnix = microtime(true);
        $r = $this->emptyResult($domain, $siteId, $jobId, $source);

        if ($domain === '') {
            $r['status'] = self::S_UNREACHABLE;
            $r['reason'] = 'empty_domain';
            return $r;
        }

        // 1) DNS
        $ips = $this->resolveIps($domain);
        $r['dns_ok'] = !empty($ips) ? 1 : 0;
        $r['resolved_ips_json'] = $ips ? json_encode($ips) : null;

        // 2) HTTP без follow
        $http = $this->probe->probeHttp('http://' . $domain . '/');
        $r['http_code'] = (int)$http['http_code'];
        $r['http_location'] = $http['location'] ?? null;

        // 3) YandexBot UA
        $yb = $this->probe->probeHttpAs('http://' . $domain . '/', DomainReadinessService::yandexBotUserAgent());
        $r['yandexbot_http_code'] = (int)$yb['http_code'];
        $r['yandexbot_location'] = $yb['location'] ?? null;

        // 4) HTTPS строгий (для finalUrl/кодов при trusted)
        $https = $this->probe->probeHttps('https://' . $domain . '/');
        $r['https_initial_code'] = (int)$https['initial_code'];
        $r['https_final_code'] = (int)$https['final_code'];
        $r['https_final_url'] = $https['final_url'] ?? null;

        // 4b) non-strict transport (видит код при self-signed)
        $untrustedFinal = (int)$r['https_final_code'];
        $untrustedFinalUrl = (string)($r['https_final_url'] ?? '');
        if ($untrustedFinal === 0) {
            $u = $this->probe->probeHttpsAllowUntrusted('https://' . $domain . '/');
            $untrustedFinal = (int)($u['final_code'] ?? 0);
            $untrustedFinalUrl = (string)($u['final_url'] ?? '');
            if ($r['https_final_code'] === 0 && $untrustedFinal > 0) {
                $r['https_final_code'] = $untrustedFinal;
                if ($r['https_final_url'] === null && $untrustedFinalUrl !== '') {
                    $r['https_final_url'] = $untrustedFinalUrl;
                }
            }
        }

        // 5) Техническая доступность (та же логика, что pipeline)
        $tech = DomainReadinessService::evaluateTechnicalReady($domain, [
            'http_code'          => $r['http_code'],
            'http_location'      => $r['http_location'],
            'yandexbot_http'     => $r['yandexbot_http_code'],
            'yandexbot_location' => $r['yandexbot_location'],
            'https_initial'      => $r['https_initial_code'],
            'https_final'        => $untrustedFinal,
            'https_final_url'    => $untrustedFinalUrl !== '' ? $untrustedFinalUrl : $r['https_final_url'],
        ]);
        $r['technical_ready'] = !empty($tech['ready']) ? 1 : 0;

        // 6) Разбор сертификата (даже self-signed/expired/mismatch)
        $cert = $this->probe->inspectCertificate($domain);
        $r['tls_present'] = !empty($cert['tls_present']) ? 1 : 0;
        $r['tls_trusted'] = !empty($cert['tls_trusted']) ? 1 : 0;
        $r['is_self_signed'] = !empty($cert['is_self_signed']) ? 1 : 0;
        $r['hostname_valid'] = !empty($cert['hostname_valid']) ? 1 : 0;
        $r['issuer'] = $cert['issuer'] ?? null;
        $r['subject'] = $cert['subject'] ?? null;
        $r['serial_number'] = $cert['serial_number'] ?? null;
        $r['valid_from'] = $cert['valid_from'] ?? null;
        $r['valid_to'] = $cert['valid_to'] ?? null;
        $r['days_remaining'] = $cert['days_remaining'] ?? null;
        $expired = !empty($cert['expired']);

        // 7) site_reachable (Блокер 2, b1.1): строго. Требуем ОДНОВРЕМЕННО:
        //    technical_ready=1; HTTPS final = 2xx/3xx; финальная схема = https;
        //    финальный host = наш домен или разрешённый www. Пустой final URL
        //    больше НЕ считается достижимостью.
        $finalUrlForHost = (string)($r['https_final_url'] ?? '');
        $httpsFinal = (int)$r['https_final_code'];
        $finalIs2or3xx = ($httpsFinal >= 200 && $httpsFinal < 400);
        $finalHostOk = ($finalUrlForHost !== '')
            && DomainReadinessService::finalHostAllowed($finalUrlForHost, $domain);
        $r['site_reachable'] = ($r['technical_ready'] === 1 && $finalIs2or3xx && $finalHostOk) ? 1 : 0;

        // valid_from в будущем → сертификат ещё не действует.
        $notYetValid = false;
        if (!empty($cert['valid_from'])) {
            $vfTs = strtotime((string)$cert['valid_from']);
            if ($vfTs !== false && $vfTs > time()) $notYetValid = true;
        }

        // 8) probe (если активная джоба + токен)
        if ($jobId !== null && $probeToken !== null && $probeToken !== '') {
            $probeUrl = 'https://' . $domain . DomainReadinessService::probeFileName($jobId, $probeToken);
            $fetch = $this->probe->fetchHttps($probeUrl);
            $r['probe_http_code'] = (int)$fetch['http_code'];
            $expected = DomainReadinessService::probeContent($jobId, $probeToken);
            $r['probe_ok'] = ((int)$fetch['http_code'] === 200 && trim((string)($fetch['body'] ?? '')) === $expected) ? 1 : 0;
        }

        // 9) Классификация статуса
        [$status, $reason] = $this->classify($r, $expired, $notYetValid, (string)($cert['error'] ?? ''), (string)($tech['reason'] ?? ''));
        $r['status'] = $status;
        $r['reason'] = $reason;
        $r['error_message'] = $this->safeError((string)($cert['error'] ?? ''), (string)($https['error'] ?? ''));
        $r['checked_at'] = date('Y-m-d H:i:s');
        $r['check_duration_ms'] = (int)round((microtime(true) - $startedUnix) * 1000);

        return $r;
    }

    /** Классификация в единый статус (ТЗ §4.5 + b1.1). */
    private function classify(array $r, bool $expired, bool $notYetValid, string $certError, string $techReason): array
    {
        $reachable = ((int)($r['site_reachable'] ?? 0) === 1);

        // Полностью недоступен (нет ни HTTP, ни HTTPS).
        if ($r['technical_ready'] !== 1 && (int)$r['http_code'] === 0 && (int)$r['https_final_code'] === 0) {
            return [self::S_UNREACHABLE, $techReason !== '' ? $techReason : 'no_connection'];
        }
        // Просрочен / ещё не действует — приоритет над «доверенный».
        if ($expired) return [self::S_EXPIRED, 'certificate_expired'];
        if ($notYetValid) return [self::S_NOT_YET_VALID, 'certificate_not_yet_valid'];
        // Есть TLS, но hostname не соответствует (и не self-signed bootstrap).
        if ($r['tls_present'] === 1 && $r['hostname_valid'] !== 1 && $r['is_self_signed'] !== 1) {
            return [self::S_MISMATCH, 'hostname_mismatch'];
        }
        // Блокер 2: доверенный/self-signed СТАТУС только при реальной достижимости.
        // Trusted-сертификат + HTTP 500 / чужой redirect → site_error (не зелёный).
        if ($r['tls_trusted'] === 1) {
            if ($reachable) return [self::S_TRUSTED, 'trusted'];
            return [self::S_SITE_ERROR, $this->siteErrorReason($r)];
        }
        if ($r['is_self_signed'] === 1) {
            if ($reachable) return [self::S_SELF_SIGNED, 'self_signed'];
            return [self::S_SITE_ERROR, $this->siteErrorReason($r)];
        }
        // 301 живёт, выпуск SSL ещё идёт (TLS не поднялся).
        if ($r['technical_ready'] === 1 && $r['tls_present'] !== 1) {
            return [self::S_ISSUING, 'ssl_issuing'];
        }
        // Доступен технически, но vhost/probe ещё не тот — verification ждёт.
        if ($r['technical_ready'] === 1) {
            return [self::S_VERIFY_PENDING, 'verify_pending'];
        }
        return [self::S_UNREACHABLE, $techReason !== '' ? $techReason : 'not_ready'];
    }

    /** Причина site_error: 5xx, чужой redirect или HTTPS не открылся. */
    private function siteErrorReason(array $r): string
    {
        $httpsFinal = (int)($r['https_final_code'] ?? 0);
        if ($httpsFinal >= 500) return 'http_5xx';
        if ($httpsFinal === 0) return 'https_not_served';
        $finalUrl = (string)($r['https_final_url'] ?? '');
        if ($finalUrl !== '') return 'foreign_redirect';
        return 'site_unreachable';
    }

    /** Следующая проверка по статусу (ТЗ §6) — интервалы из настроек. */
    public static function nextCheckAt(string $status, ?int $daysRemaining): string
    {
        return date('Y-m-d H:i:s', time() + self::intervalSecondsFor($status, $daysRemaining));
    }

    public static function intervalSecondsFor(string $status, ?int $daysRemaining): int
    {
        $expWarn = max(1, AppSettings::getInt('ssl.expiring_days_warning', 30));
        $expCrit = max(1, AppSettings::getInt('ssl.expiring_days_critical', 7));
        if ($daysRemaining !== null && $daysRemaining <= $expCrit) return 3600;      // ≤7 дней: каждый час
        if ($daysRemaining !== null && $daysRemaining <= $expWarn) return 6 * 3600;  // ≤30 дней: каждые 6ч
        switch ($status) {
            case self::S_UNREACHABLE:
                return max(30, AppSettings::getInt('ssl.pending_interval_seconds', 60));
            case self::S_ISSUING:
            case self::S_SELF_SIGNED:
            case self::S_VERIFY_PENDING:
                return max(30, AppSettings::getInt('ssl.self_signed_interval_seconds', 90));
            case self::S_MISMATCH:
            case self::S_EXPIRED:
            case self::S_NOT_YET_VALID:
            case self::S_SITE_ERROR:
                return 10 * 60;                                                       // каждые 10 мин
            case self::S_TRUSTED:
                return max(60, AppSettings::getInt('ssl.trusted_interval_minutes', 720)) * 60;
            default:
                return max(30, AppSettings::getInt('ssl.pending_interval_seconds', 60));
        }
    }

    /* ==================== helpers ==================== */

    private function resolveIps(string $domain): array
    {
        $ips = [];
        $a = @gethostbynamel($domain);
        if (is_array($a)) $ips = array_values(array_unique($a));
        if (function_exists('dns_get_record')) {
            $aaaa = @dns_get_record($domain, DNS_AAAA);
            if (is_array($aaaa)) foreach ($aaaa as $rec) if (!empty($rec['ipv6'])) $ips[] = $rec['ipv6'];
        }
        return array_values(array_unique($ips));
    }

    private function safeError(string $certErr, string $httpsErr): ?string
    {
        $msg = trim($certErr !== '' ? $certErr : $httpsErr);
        if ($msg === '') return null;
        return mb_substr($msg, 0, 512);
    }

    private function emptyResult(string $domain, ?int $siteId, ?int $jobId, string $source): array
    {
        return [
            'domain' => $domain, 'site_id' => $siteId, 'job_id' => $jobId,
            'dns_ok' => 0, 'resolved_ips_json' => null,
            'http_code' => null, 'http_location' => null,
            'yandexbot_http_code' => null, 'yandexbot_location' => null,
            'https_initial_code' => null, 'https_final_code' => null, 'https_final_url' => null,
            'technical_ready' => 0, 'site_reachable' => 0,
            'probe_ok' => null, 'probe_http_code' => null,
            'tls_present' => 0, 'tls_trusted' => 0, 'is_self_signed' => 0, 'hostname_valid' => 0,
            'issuer' => null, 'subject' => null, 'serial_number' => null,
            'valid_from' => null, 'valid_to' => null, 'days_remaining' => null,
            'status' => self::S_NOT_CHECKED, 'reason' => null, 'error_message' => null,
            'checked_at' => null, 'check_source' => $source, 'next_check_at' => null,
            'check_duration_ms' => 0,
        ];
    }
}
