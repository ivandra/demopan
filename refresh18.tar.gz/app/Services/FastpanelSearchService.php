<?php

/**
 * Поиск сайтов на FastPanel + добавление одного выбранного в БД.
 *
 * Стратегия:
 *   1) Кешируем список всех сайтов сервера (lightweight simpleSites) в fp_sites_cache.
 *   2) Поиск идёт по этому кешу (LIKE по server_name) — мгновенно даже на 1000 сайтов.
 *   3) Подробная информация (алиасы, IP, индекс-директория) — только при выборе одного сайта.
 *   4) При финальном добавлении: создаём FTP-аккаунт через FastPanel API, читаем config.php,
 *      сохраняем все данные в sites_managed.
 */
class FastpanelSearchService
{
    private array $server;
    private FastpanelClient $client;
    private ?FastpanelServerIpPolicy $ipPolicy = null;

    public function __construct(int $serverId)
    {
        $st = DB::pdo()->prepare("SELECT * FROM fastpanel_servers WHERE id=?");
        $st->execute([$serverId]);
        $srv = $st->fetch();
        if (!$srv) throw new RuntimeException("FastPanel server not found: {$serverId}");
        $this->server = $srv;

        $pass = Crypto::decrypt((string)$srv['password_enc']);
        $this->client = new FastpanelClient(
            (string)$srv['host'],
            (bool)($srv['verify_tls'] ?? false),
            (int)config('fastpanel.timeout', 30)
        );
        $this->client->login((string)$srv['username'], $pass);
    }

    /** Ленивая политика IP выбранного сервера. */
    private function ipPolicy(): FastpanelServerIpPolicy
    {
        if ($this->ipPolicy === null) {
            require_once __DIR__ . '/FastpanelServerIpPolicy.php';
            $this->ipPolicy = new FastpanelServerIpPolicy();
        }
        return $this->ipPolicy;
    }

    /**
     * ТЗ «Единый безопасный выбор IP» §5/§12: ЕДИНСТВЕННЫЙ production-метод выбора
     * IP сайта во всех операциях FastPanel (импорт, preview, обновление, FTP, resolver).
     *
     * Поддерживает wrapper getSiteDetail() (['vps_ip'=>..., 'raw'=>{...}]) — анализирует
     * ПОЛНЫЙ raw detail, а не только vps_ip. Извлекает ВСЕ IPv4-кандидаты, берёт первый
     * из allowlist. Правило стабильности §12: если сохранённый $preferredCurrentIp всё
     * ещё среди разрешённых кандидатов — вернуть его (не переключать между двумя
     * допустимыми IP без причины). Ни $ips[0], ни host-IP-fallback, ни extra_ips[0].
     *
     * @throws RuntimeException если IP есть, но ни один не разрешён, или IP нет вовсе.
     */
    public function selectAllowedVpsIp(array $rawDetail, ?string $preferredCurrentIp = null): string
    {
        $source = (isset($rawDetail['raw']) && is_array($rawDetail['raw'])) ? $rawDetail['raw'] : $rawDetail;
        $candidates = $this->candidateIpsFromDetail($source);

        $allowed = array_values(array_filter(
            $candidates,
            fn(string $ip): bool => $this->ipPolicy()->isAllowed($this->server, $ip)
        ));

        // §12: сохранённый допустимый IP стабилен, если FastPanel всё ещё его возвращает.
        if ($preferredCurrentIp !== null && $preferredCurrentIp !== ''
            && in_array($preferredCurrentIp, $allowed, true)) {
            return $preferredCurrentIp;
        }
        if ($allowed !== []) {
            return $allowed[0];
        }

        if ($candidates !== []) {
            throw new RuntimeException(sprintf(
                'FastPanel сообщил IP %s, которых нет в настройках сервера «%s». ' .
                'Добавьте нужный IP в дополнительные IP сервера или исправьте привязку сайта.',
                implode(', ', $candidates),
                (string)($this->server['title'] ?? '')
            ));
        }
        throw new RuntimeException(
            'FastPanel не вернул фактический IPv4 сайта. ' .
            'Операция остановлена без изменения сохранённых данных. Проверьте IP сайта в FastPanel.'
        );
    }

    public function getServer(): array
    {
        return $this->server;
    }

    public function getClient(): FastpanelClient
    {
        return $this->client;
    }

    /**
     * Обновить кеш списка сайтов с сервера. Возвращает количество.
     *
     * v18.1.28: после получения lightweight-списка через simpleSites() —
     * для каждого сайта дёргает site($id) чтобы получить алиасы и сохраняет
     * их в `aliases_text` (через перевод строки). Это позволяет искать
     * сайт не только по основному домену, но и по любому из его алиасов.
     *
     * Запросов: 1 (simpleSites) + N (site($id)). На 1000 сайтов это занимает
     * около 1-3 минут. Кеш TTL 30 минут — этого достаточно.
     */
    /**
     * §3 (аудит ver3): единый нормализатор payload /api/sites/simple.
     * Один и тот же контракт для preflight и refreshCache: поддерживаем прямой
     * список ИЛИ обёртку {data:[...]}. Неизвестная структура → null (не список).
     * @return array<int,mixed>|null
     */
    public static function normalizeSimpleSitesPayload($payload): ?array
    {
        if (self::isPlainList($payload)) return $payload;
        if (is_array($payload) && isset($payload['data']) && self::isPlainList($payload['data'])) {
            return $payload['data'];
        }
        return null;
    }

    /** §3: извлечь положительный site ID из поддерживаемых полей (id/site_id/ID). */
    public static function extractSimpleSiteId(array $site): int
    {
        foreach (['id', 'site_id', 'ID'] as $f) {
            if (isset($site[$f]) && (int)$site[$f] > 0) return (int)$site[$f];
        }
        return 0;
    }

    private static function isPlainList($a): bool
    {
        if (!is_array($a)) return false;
        if ($a === []) return true;
        return array_keys($a) === range(0, count($a) - 1);
    }

    public function refreshCache(): int
    {
        // §3: сначала валидируем структуру. Неподдерживаемую структуру НЕ трактуем
        // как пустой список и НЕ удаляем существующий кеш.
        $list = self::normalizeSimpleSitesPayload($this->client->simpleSites());
        if ($list === null) {
            throw new RuntimeException(
                'FastPanel /api/sites/simple вернул неизвестную структуру списка сайтов. '
                . 'Кеш не изменён.'
            );
        }

        $serverId = (int)$this->server['id'];

        // Удалим старый кеш этого сервера (только после успешной валидации структуры).
        DB::pdo()->prepare("DELETE FROM fp_sites_cache WHERE fastpanel_server_id=?")->execute([$serverId]);

        $st = DB::pdo()->prepare("INSERT INTO fp_sites_cache
            (fastpanel_server_id, fp_site_id, server_name, owner_username, aliases_text, raw_json)
            VALUES (?, ?, ?, ?, ?, ?)");

        $cnt = 0;
        foreach ($list as $s) {
            if (!is_array($s)) continue;
            $id = self::extractSimpleSiteId($s);   // §3: id/site_id/ID
            $name = (string)($s['server_name'] ?? $s['domain'] ?? '');
            if ($id <= 0 || $name === '') continue;

            $owner = '';
            if (isset($s['owner']) && is_array($s['owner'])) {
                $owner = (string)($s['owner']['username'] ?? '');
            } elseif (isset($s['owner_name'])) {
                $owner = (string)$s['owner_name'];
            }

            // v18.1.28: тянем алиасы. simpleSites() их обычно НЕ возвращает,
            // поэтому делаем дополнительный запрос site($id). Если он упал —
            // сохраняем сайт без алиасов (можно будет искать только по server_name).
            $aliasesText = '';
            $rawForCache = $s;
            try {
                $detail = $this->client->site($id);
                if (is_array($detail)) {
                    $rawForCache = $detail; // полные данные ценнее для UI и getSiteDetail later
                    $aliases = $this->extractAliases($detail);
                    if (!empty($aliases)) {
                        // Конкатенируем через "\n" — для LIKE-поиска удобно
                        // (LIKE '%домен%' матчит в любой строке).
                        $aliasesText = implode("\n", $aliases);
                    }
                }
            } catch (Throwable $e) {
                // Сайт не доступен / API упал — сохраняем без алиасов.
                // Лог не пишем (это batch-операция, лог будет огромным).
            }

            $st->execute([
                $serverId,
                $id,
                $name,
                $owner,
                $aliasesText,
                json_encode($rawForCache, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
            $cnt++;
        }

        return $cnt;
    }

    /**
     * Узнать сколько сайтов в кеше и время последнего обновления.
     */
    public function cacheInfo(): array
    {
        $st = DB::pdo()->prepare("SELECT COUNT(*) AS cnt, MAX(cached_at) AS last_at FROM fp_sites_cache WHERE fastpanel_server_id=?");
        $st->execute([(int)$this->server['id']]);
        $row = $st->fetch() ?: ['cnt' => 0, 'last_at' => null];
        return [
            'count'   => (int)$row['cnt'],
            'last_at' => $row['last_at'],
        ];
    }

    /**
     * Поиск по кешу. Возвращает максимум N результатов.
     * Если кеш пуст или старше TTL минут — обновляем.
     */
    public function search(string $query, int $limit = 20, int $cacheTtlMinutes = 30): array
    {
        $info = $this->cacheInfo();

        $stale = $info['count'] === 0;
        if (!$stale && $info['last_at']) {
            $age = time() - strtotime($info['last_at']);
            if ($age > $cacheTtlMinutes * 60) $stale = true;
        }

        if ($stale) {
            $this->refreshCache();
        }

        $serverId = (int)$this->server['id'];
        $q = trim($query);

        if ($q === '') {
            $st = DB::pdo()->prepare("SELECT * FROM fp_sites_cache WHERE fastpanel_server_id=? ORDER BY server_name LIMIT ?");
            $st->bindValue(1, $serverId, PDO::PARAM_INT);
            $st->bindValue(2, $limit, PDO::PARAM_INT);
            $st->execute();
        } else {
            // v18.1.28: поиск также по aliases_text. Колонка содержит алиасы через "\n",
            // LIKE '%X%' матчит в любой строке. Это критично для panel'ей где сайты
            // имеют несколько алиасов и пользователь ищет по любому из них (например
            // сайт 1win-777.casino имеет алиасы 1win-778, 1win-779 — ищем по любому).
            $st = DB::pdo()->prepare("SELECT * FROM fp_sites_cache
                WHERE fastpanel_server_id=? AND (
                    server_name LIKE ?
                    OR owner_username LIKE ?
                    OR aliases_text LIKE ?
                )
                ORDER BY
                    -- exact match по server_name всегда первым
                    CASE WHEN LOWER(server_name) = LOWER(?) THEN 0 ELSE 1 END,
                    -- потом server_name префиксом
                    CASE WHEN server_name LIKE ? THEN 0 ELSE 1 END,
                    server_name
                LIMIT ?");
            $like = '%' . $q . '%';
            $prefix = $q . '%';
            $st->bindValue(1, $serverId, PDO::PARAM_INT);
            $st->bindValue(2, $like, PDO::PARAM_STR);
            $st->bindValue(3, $like, PDO::PARAM_STR);
            $st->bindValue(4, $like, PDO::PARAM_STR);
            $st->bindValue(5, $q, PDO::PARAM_STR);
            $st->bindValue(6, $prefix, PDO::PARAM_STR);
            $st->bindValue(7, $limit, PDO::PARAM_INT);
            $st->execute();
        }

        $rows = $st->fetchAll();

        // Помечаем сайты, которые уже добавлены в нашу панель
        $added = [];
        if (!empty($rows)) {
            $ids = array_map(fn($r) => (int)$r['fp_site_id'], $rows);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $st2 = DB::pdo()->prepare("SELECT fp_site_id, id FROM sites_managed
                WHERE fastpanel_server_id=? AND fp_site_id IN ({$placeholders})");
            $st2->execute(array_merge([$serverId], $ids));
            while ($r = $st2->fetch()) {
                $added[(int)$r['fp_site_id']] = (int)$r['id'];
            }
        }

        $out = [];
        foreach ($rows as $r) {
            $fpId = (int)$r['fp_site_id'];
            // v18.1.28: парсим алиасы обратно из aliases_text для UI
            $aliasesText = (string)($r['aliases_text'] ?? '');
            $aliases = $aliasesText !== ''
                ? array_values(array_filter(array_map('trim', explode("\n", $aliasesText))))
                : [];

            // Какой алиас матчил? (Для UI — показать пользователю что мы нашли по алиасу.)
            $matchedAlias = null;
            if ($q !== '' && stripos((string)$r['server_name'], $q) === false) {
                foreach ($aliases as $a) {
                    if (stripos($a, $q) !== false) {
                        $matchedAlias = $a;
                        break;
                    }
                }
            }

            $out[] = [
                'fp_site_id'    => $fpId,
                'server_name'   => (string)$r['server_name'],
                'owner'         => (string)$r['owner_username'],
                'aliases'       => $aliases,
                'matched_alias' => $matchedAlias,
                'already_added' => isset($added[$fpId]),
                'managed_id'    => $added[$fpId] ?? null,
            ];
        }
        return $out;
    }

    /**
     * Получить детальную информацию по одному сайту (алиасы, IP, путь).
     * Нужно для предпросмотра перед добавлением.
     */
    public function getSiteDetail(int $fpSiteId): array
    {
        $detail = $this->client->site($fpSiteId);

        $serverName = (string)($detail['server_name'] ?? $detail['domain'] ?? '');
        $aliases = $this->extractAliases($detail);
        $owner = '';
        if (isset($detail['owner']) && is_array($detail['owner'])) {
            $owner = (string)($detail['owner']['username'] ?? '');
        }
        $vpsIp = $this->extractVpsIp($detail);
        $indexDir = $this->extractIndexDir($detail, $owner, $serverName);

        $lastAlias = !empty($aliases) ? $aliases[count($aliases) - 1] : '';

        return [
            'fp_site_id'  => $fpSiteId,
            'server_name' => $serverName,
            'aliases'     => $aliases,
            'last_alias'  => $lastAlias,
            'owner'       => $owner,
            'vps_ip'      => $vpsIp,
            'index_dir'   => $indexDir,
            'raw'         => $detail,
        ];
    }

    /**
     * Извлечь IP сайта. FastPanel в разных версиях складывает его в разные места.
     */
    private function extractVpsIp(array $detail): string
    {
        // ТЗ 040 FINAL-3 §3.8: host-IP панели допустим ТОЛЬКО если явно в detail.
        // Fallback на host FastPanel запрещён — иначе DNS уедет не на тот IP.
        $c = $this->candidateIpsFromDetail($detail);
        return $c[0] ?? '';
    }

    /**
     * §3.8: все валидные IPv4-кандидаты из detail, в порядке появления, уникальные.
     * @return array<int,string>
     */
    public function candidateIpsFromDetail(array $detail): array
    {
        $out = [];
        $add = function ($v) use (&$out) {
            if (is_string($v)) {
                $v = trim($v);
                if ($v !== '' && filter_var($v, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false && !in_array($v, $out, true)) {
                    $out[] = $v;
                }
            }
        };
        foreach (['ip_addr', 'ip', 'ipv4', 'address'] as $f) {
            if (isset($detail[$f])) $add($detail[$f]);
        }
        foreach (['ip_addrs', 'ips'] as $f) {
            if (isset($detail[$f]) && is_array($detail[$f])) {
                foreach ($detail[$f] as $el) {
                    if (is_string($el)) { $add($el); continue; }
                    if (is_array($el)) {
                        foreach (['address', 'ip', 'value', 'ipv4', 'ip_addr'] as $k) {
                            if (isset($el[$k])) $add($el[$k]);
                        }
                    }
                }
            }
        }
        if (isset($detail['server']) && is_array($detail['server'])) {
            foreach (['ip', 'ip_addr', 'address', 'ipv4'] as $k) {
                if (isset($detail['server'][$k])) $add($detail['server'][$k]);
            }
        }
        return $out;
    }

    /**
     * Импорт одного сайта в нашу БД. Создаёт FTP-аккаунт и пытается прочитать config.php.
     *
     * @return array {ok, site_id, ftp_created, config_synced, errors[], log[]}
     */
    public function importOne(int $fpSiteId): array
    {
        $log = [];
        $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' => "Начало импорта сайта FP id={$fpSiteId}"];

        try {
            $detail = $this->getSiteDetail($fpSiteId);
        } catch (Throwable $e) {
            return [
                'ok' => false,
                'error' => 'Не удалось получить детали сайта: ' . $e->getMessage(),
                'log' => array_merge($log, [['ts' => date('c'), 'level' => 'error', 'msg' => $e->getMessage()]]),
            ];
        }

        if ($detail['server_name'] === '') {
            return ['ok' => false, 'error' => 'Сайт без server_name', 'log' => $log];
        }

        // ТЗ «Единый безопасный выбор IP» §8.1: единый метод ДО любых мутаций
        // (FTP, DB, config.php). Ошибка IP → импорт останавливается без частичного сайта.
        try {
            $chosenIp = $this->selectAllowedVpsIp($detail); // wrapper: $detail['raw']
        } catch (\RuntimeException $e) {
            return ['ok' => false, 'error' => $e->getMessage(),
                'log' => array_merge($log, [['ts' => date('c'), 'level' => 'error', 'msg' => 'IP не выбран, импорт остановлен: ' . $e->getMessage()]])];
        }
        $detail['vps_ip'] = $chosenIp;

        $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' => "server_name={$detail['server_name']}, aliases=" . count($detail['aliases']) . ", ip={$detail['vps_ip']}, owner={$detail['owner']}"];

        $serverId = (int)$this->server['id'];

        // Уже добавлен?
        $st = DB::pdo()->prepare("SELECT id FROM sites_managed WHERE fastpanel_server_id=? AND fp_site_id=?");
        $st->execute([$serverId, $fpSiteId]);
        $existing = $st->fetch();

        // Текущий рабочий домен — last_alias если есть, иначе server_name. Нормализуем (без www.)
        $currentDomainRaw = $detail['last_alias'] !== '' ? $detail['last_alias'] : $detail['server_name'];
        $currentDomain = $this->normalizeDomain($currentDomainRaw);
        $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' => "current_domain={$currentDomain} (исходное: {$currentDomainRaw})"];

        $errors = [];
        $ftpCreated = false;
        $ftpUser = '';
        $ftpPassEnc = null;

        // 1) Создаём FTP-аккаунт через FastPanel API
        try {
            $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' => "Создаю FTP-аккаунт через API: home_dir={$detail['index_dir']}"];
            $ftpRes = $this->createFtpAccount($detail, $fpSiteId);
            $ftpUser = $ftpRes['user'];
            $ftpPassEnc = Crypto::encrypt($ftpRes['pass']);
            $ftpCreated = true;
            // Подключаем подробный лог из createFtpAccount
            $log = array_merge($log, $ftpRes['log']);
        } catch (Throwable $e) {
            $msg = 'FTP create: ' . $e->getMessage();
            $errors[] = $msg;
            $log[] = ['ts' => date('c'), 'level' => 'error', 'msg' => $msg];
            @error_log('[refresh-panel] ' . $msg);
        }

        // 2) Создаём/обновляем запись sites_managed
        $rawJson = json_encode($detail['raw'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($existing) {
            $sql = "UPDATE sites_managed SET
                current_domain=?, vps_ip=?, fp_site_owner=?, fp_index_dir=?, aliases=?,
                fp_raw_json=?, import_log=?";
            $params = [
                $currentDomain,
                $detail['vps_ip'],
                $detail['owner'],
                $detail['index_dir'],
                json_encode($detail['aliases'], JSON_UNESCAPED_UNICODE),
                $rawJson,
                json_encode($log, JSON_UNESCAPED_UNICODE),
            ];
            if ($ftpCreated) {
                $sql .= ", ftp_user=?, ftp_pass_enc=?, ftp_host=?";
                $params[] = $ftpUser;
                $params[] = $ftpPassEnc;
                $params[] = $this->extractHostForFtp();
            }
            $sql .= " WHERE id=?";
            $params[] = (int)$existing['id'];
            DB::pdo()->prepare($sql)->execute($params);
            $siteId = (int)$existing['id'];
        } else {
            $st = DB::pdo()->prepare("INSERT INTO sites_managed
                (fastpanel_server_id, fp_site_id, fp_site_owner, fp_index_dir,
                 current_domain, vps_ip, aliases,
                 ftp_user, ftp_pass_enc, ftp_host,
                 fp_raw_json, import_log,
                 status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'imported')");
            $st->execute([
                $serverId,
                $fpSiteId,
                $detail['owner'],
                $detail['index_dir'],
                $currentDomain,
                $detail['vps_ip'],
                json_encode($detail['aliases'], JSON_UNESCAPED_UNICODE),
                $ftpCreated ? $ftpUser : null,
                $ftpCreated ? $ftpPassEnc : null,
                $ftpCreated ? $this->extractHostForFtp() : null,
                $rawJson,
                json_encode($log, JSON_UNESCAPED_UNICODE),
            ]);
            $siteId = (int)DB::pdo()->lastInsertId();
        }

        // 3) Если FTP создан — пробуем сразу прочитать config.php
        $configSynced = false;
        if ($ftpCreated) {
            $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' => 'Читаю config.php через FTP'];
            try {
                $sync = new SiteConfigSyncService();
                $res = $sync->syncFromVps($siteId);
                if (!empty($res['ok'])) {
                    $configSynced = true;
                    $cnt = is_array($res['data']) ? count($res['data']) : 0;
                    $log[] = ['ts' => date('c'), 'level' => 'ok', 'msg' => "config.php прочитан ({$cnt} полей)"];
                    if (!empty($res['data']['domain'])) {
                        $mask = new DomainMaskService();
                        $domainHost = $mask->extractHost((string)$res['data']['domain']);
                        if ($domainHost !== '' && $domainHost !== $currentDomain) {
                            $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' => "current_domain заменён на {$domainHost} (из \$domain в config.php)"];
                            DB::pdo()->prepare("UPDATE sites_managed SET current_domain=? WHERE id=?")
                                ->execute([$domainHost, $siteId]);
                        }
                    }
                } else {
                    $msg = 'config.php: ' . ($res['error'] ?? 'unknown');
                    $errors[] = $msg;
                    $log[] = ['ts' => date('c'), 'level' => 'error', 'msg' => $msg];
                }
            } catch (Throwable $e) {
                $msg = 'config.php: ' . $e->getMessage();
                $errors[] = $msg;
                $log[] = ['ts' => date('c'), 'level' => 'error', 'msg' => $msg];
            }

            // Сохраним обновлённый log
            DB::pdo()->prepare("UPDATE sites_managed SET import_log=? WHERE id=?")
                ->execute([json_encode($log, JSON_UNESCAPED_UNICODE), $siteId]);
        }

        return [
            'ok'             => true,
            'site_id'        => $siteId,
            'is_new'         => !$existing,
            'ftp_created'    => $ftpCreated,
            'config_synced'  => $configSynced,
            'detail'         => $detail,
            'errors'         => $errors,
            'log'            => $log,
        ];
    }

    /**
     * Нормализация домена: убираем https://, www., путь, порт.
     */
    private function normalizeDomain(string $domain): string
    {
        $d = trim($domain);
        $d = preg_replace('~^https?://~i', '', $d);
        $d = preg_replace('~^www\.~i', '', $d);
        $d = preg_replace('~[/?#].*$~', '', $d);
        $d = preg_replace('~:\d+$~', '', $d);
        return strtolower(trim($d));
    }

    /**
     * Создать FTP-аккаунт для сайта через FastPanel API.
     * Возвращает [user, pass, log_entries].
     *
     * @return array{user:string,pass:string,log:array}
     * @throws RuntimeException
     */
    public function createFtpAccount(array $detail, int $fpSiteId): array
    {
        $indexDir = $detail['index_dir'];
        if ($indexDir === '') {
            throw new RuntimeException('Не определена директория сайта (fp_index_dir пуст)');
        }

        $owner = $this->resolveOwnerForFtp($detail);
        $ownerId = $owner['id'];
        $log = [];
        $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' =>
            "FTP create: owner_id={$ownerId} (username={$owner['username']}, source={$owner['source']}), home_dir={$indexDir}"];

        $baseName = 'rfr_site_' . $fpSiteId;

        // Максимум 3 попытки и ТОЛЬКО при "already exists"
        for ($try = 0; $try < 3; $try++) {
            $candidate = $try === 0 ? $baseName : ($baseName . '_' . ($try + 1));
            $candidatePass = bin2hex(random_bytes(10));

            $payload = [
                'enabled'  => true,
                'home_dir' => $indexDir,
                'limit'    => 0,
                'name'     => $candidate,
                'owner'    => $ownerId,
                'password' => $candidatePass,
            ];

            $payloadForLog = $payload;
            $payloadForLog['password'] = '***';
            $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' => "FTP create attempt {$try}: payload=" . json_encode($payloadForLog, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)];

            try {
                $resp = $this->client->createFtpAccount($payload);
                $log[] = ['ts' => date('c'), 'level' => 'ok', 'msg' => "FTP создан: user={$candidate}, fp_response=" . json_encode($resp, JSON_UNESCAPED_UNICODE)];
                return ['user' => $candidate, 'pass' => $candidatePass, 'log' => $log];
            } catch (Throwable $e) {
                $msg = $e->getMessage();
                $log[] = ['ts' => date('c'), 'level' => 'error', 'msg' => "FTP create attempt {$try} failed: {$msg}"];

                // Только при конфликте имени пробуем ещё
                if (stripos($msg, 'already exists') !== false ||
                    stripos($msg, 'duplicate') !== false ||
                    stripos($msg, 'unique') !== false) {
                    $log[] = ['ts' => date('c'), 'level' => 'info', 'msg' => "Имя занято, пробуем следующее"];
                    continue;
                }

                $err = new RuntimeException($msg);
                throw $err;
            }
        }
        throw new RuntimeException('Не удалось создать FTP-аккаунт после 3 попыток (имена все заняты)');
    }

    /**
     * Только создать FTP-аккаунт для уже импортированного сайта.
     * Используется для повтора, если автосоздание упало.
     */
    public function createFtpForExistingSite(int $managedSiteId): array
    {
        $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
        $st->execute([$managedSiteId]);
        $site = $st->fetch();
        if (!$site) {
            return ['ok' => false, 'error' => 'Сайт не найден'];
        }

        $fpSiteId = (int)$site['fp_site_id'];

        // Сначала пробуем взять из сохранённого fp_raw_json (быстро, без API),
        // если его нет — дёргаем API заново и сохраняем.
        $rawDetail = null;
        if (!empty($site['fp_raw_json'])) {
            $rawDetail = json_decode((string)$site['fp_raw_json'], true);
        }

        if (!is_array($rawDetail) || empty($rawDetail)) {
            try {
                $rawDetail = $this->client->site($fpSiteId);
                DB::pdo()->prepare("UPDATE sites_managed SET fp_raw_json=? WHERE id=?")->execute([
                    json_encode($rawDetail, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $managedSiteId,
                ]);
            } catch (Throwable $e) {
                $rawDetail = [];
            }
        }

        $detail = [
            'index_dir' => (string)($site['fp_index_dir'] ?? ''),
            'owner'     => (string)($site['fp_site_owner'] ?? ''),
            'raw'       => $rawDetail,
        ];

        $existingLog = [];
        if (!empty($site['import_log'])) {
            $existingLog = json_decode((string)$site['import_log'], true) ?: [];
        }

        // ТЗ «Единый безопасный выбор IP» §8.4: СНАЧАЛА определить допустимый IP
        // (до первого mutating FTP-вызова), затем создавать FTP, затем сохранять.
        // Ошибка IP → ни FTP, ни изменений БД (исключаем частичное выполнение).
        $currentIp = trim((string)($site['vps_ip'] ?? ''));
        try {
            $vpsIp = $this->selectAllowedVpsIp($detail, $currentIp !== '' ? $currentIp : null);
        } catch (\RuntimeException $e) {
            $errLog = $existingLog;
            $errLog[] = ['ts' => date('c'), 'level' => 'error', 'msg' => 'createFtpForExistingSite IP: ' . $e->getMessage()];
            DB::pdo()->prepare("UPDATE sites_managed SET import_log=? WHERE id=?")->execute([
                json_encode($errLog, JSON_UNESCAPED_UNICODE), $managedSiteId,
            ]);
            return ['ok' => false, 'error' => $e->getMessage()];
        }

        try {
            $res = $this->createFtpAccount($detail, $fpSiteId);
            $newLog = array_merge($existingLog, $res['log']);

            DB::pdo()->prepare("UPDATE sites_managed SET
                ftp_user=?, ftp_pass_enc=?, ftp_host=?,
                vps_ip = COALESCE(NULLIF(?, ''), vps_ip),
                import_log=?
                WHERE id=?")->execute([
                $res['user'],
                Crypto::encrypt($res['pass']),
                $this->extractHostForFtp(),
                $vpsIp,
                json_encode($newLog, JSON_UNESCAPED_UNICODE),
                $managedSiteId,
            ]);
            return ['ok' => true, 'user' => $res['user']];
        } catch (Throwable $e) {
            $errLog = $existingLog;
            $errLog[] = ['ts' => date('c'), 'level' => 'error', 'msg' => 'createFtpForExistingSite: ' . $e->getMessage()];
            DB::pdo()->prepare("UPDATE sites_managed SET import_log=? WHERE id=?")->execute([
                json_encode($errLog, JSON_UNESCAPED_UNICODE),
                $managedSiteId,
            ]);
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Получить ID владельца сайта из FastPanel.
     * Алгоритм:
     *  1) Если в ответе FastPanel `site()` есть `owner.id` — берём его (быстрее всего).
     *  2) Иначе ищем пользователя по username через GET /api/users.
     *  3) Если ничего не найдено — fallback на ID текущего API-пользователя (`me()`).
     *
     * @param array $detail   результат getSiteDetail()
     * @return array{id:int, source:string, username:string}
     */
    private function resolveOwnerForFtp(array $detail): array
    {
        // 1) ID из raw ответа /api/sites/{id}
        $raw = $detail['raw'] ?? [];
        if (is_array($raw) && isset($raw['owner']) && is_array($raw['owner'])) {
            $id = (int)($raw['owner']['id'] ?? 0);
            $name = (string)($raw['owner']['username'] ?? $raw['owner']['name'] ?? '');
            if ($id > 0) {
                return ['id' => $id, 'source' => 'site.owner.id', 'username' => $name];
            }
        }

        // 2) Поиск по username через /api/users
        $username = (string)($detail['owner'] ?? '');
        if ($username !== '') {
            $u = $this->client->userByName($username);
            if ($u && !empty($u['id'])) {
                return ['id' => (int)$u['id'], 'source' => '/api/users lookup', 'username' => $username];
            }
        }

        // 3) Fallback на текущего API-пользователя
        try {
            $me = $this->client->me();
            $id = (int)($me['id'] ?? 0);
            $name = (string)($me['username'] ?? $me['name'] ?? 'me');
            if ($id > 0) {
                return ['id' => $id, 'source' => 'me() fallback', 'username' => $name];
            }
        } catch (Throwable $e) {}

        return ['id' => 1, 'source' => 'hardcoded fallback', 'username' => '?'];
    }

    private function extractHostForFtp(): string
    {
        $host = (string)$this->server['host'];
        // strip scheme/port if any
        $host = preg_replace('~^https?://~i', '', $host);
        $host = preg_replace('~:\d+$~', '', $host);
        return strtolower(trim($host));
    }

    private function extractAliases(array $detail): array
    {
        $out = [];
        if (!empty($detail['aliases']) && is_array($detail['aliases'])) {
            foreach ($detail['aliases'] as $a) {
                if (is_array($a) && !empty($a['name'])) $out[] = strtolower(trim((string)$a['name']));
                elseif (is_string($a)) $out[] = strtolower(trim($a));
            }
        }
        return array_values(array_filter(array_unique($out)));
    }

    private function extractIndexDir(array $detail, string $owner, string $domain): string
    {
        if (!empty($detail['index_dir'])) return (string)$detail['index_dir'];
        if (!empty($detail['root_dir'])) return (string)$detail['root_dir'];
        if ($owner !== '' && $domain !== '') {
            return "/var/www/{$owner}/data/www/{$domain}";
        }
        return '';
    }
}
