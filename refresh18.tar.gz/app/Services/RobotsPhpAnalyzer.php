<?php

/**
 * v18.1.2: Анализатор robots.php — проверяет наличие правила
 * "закрывать домен если он не равен $domain из config".
 *
 * Зачем: на FastPanel у одного сайта могут быть несколько алиасов
 * (1win177.casino, 1win178.casino, www.* и т.д.). Все они физически
 * отдают ОДИН и тот же robots.php. Если в robots.php нет проверки
 * HTTP_HOST против $domain — поисковик увидит Allow:/ на ВСЕХ доменах,
 * что плохо для SEO (старые домены продолжают индексироваться).
 *
 * Корректный robots.php должен:
 *   - Сравнивать HTTP_HOST (или эквивалент) с $domain из config.php
 *   - Если разные → отдавать Disallow: /
 *   - Если одинаковые → отдавать Allow: /
 *
 * Пример КОРРЕКТНОЙ логики (7k шаблон):
 *   if (!sameHost($currentBase, $domain)) {
 *       echo "User-agent: *\n";
 *       echo "Disallow: /\n";
 *       exit;
 *   }
 *   echo "Allow: /\n";
 *
 * Пример НЕКОРРЕКТНОЙ логики (1win шаблон):
 *   echo "User-agent: *\n";
 *   echo "Allow: /\n";  // всегда Allow, без HTTP_HOST проверки
 *
 * Анализ через регексп — быстрый и безопасный (не eval'им чужой PHP).
 */
class RobotsPhpAnalyzer
{
    /**
     * Анализирует содержимое robots.php.
     *
     * @return array {
     *     ok: bool,                       // правильная логика?
     *     has_host_check: bool,           // есть проверка HTTP_HOST/host?
     *     has_disallow_branch: bool,      // есть ветка с Disallow: /?
     *     has_allow_output: bool,         // есть вывод Allow: /?
     *     reason: string,                 // человеко-читаемая причина (если ok=false)
     *     details: string[],              // диагностика
     * }
     */
    public function analyze(string $robotsPhpContent): array
    {
        $details = [];

        if (trim($robotsPhpContent) === '') {
            return [
                'ok' => false,
                'has_host_check' => false,
                'has_disallow_branch' => false,
                'has_allow_output' => false,
                'reason' => 'robots.php пустой',
                'details' => ['Файл не найден или пустой'],
            ];
        }

        // 1. Проверка наличия HTTP_HOST или эквивалента
        // Принимаем: $_SERVER['HTTP_HOST'], HTTP_HOST в $_SERVER, $request->host(),
        // gethostbyaddr и т.п. — главное что код где-то получает текущий домен.
        $hostPatterns = [
            '~\$_SERVER\s*\[\s*[\'"]HTTP_HOST[\'"]\s*\]~i',
            '~HTTP_HOST~i',  // более широкий — включая $_SERVER['HTTP_HOST'] и getenv('HTTP_HOST')
            '~\$_SERVER\s*\[\s*[\'"]SERVER_NAME[\'"]\s*\]~i',  // запасной вариант
            '~->host\s*\(\s*\)~i',  // request->host()
            '~->getHost\s*\(\s*\)~i',
        ];
        $hasHostAccess = false;
        foreach ($hostPatterns as $p) {
            if (preg_match($p, $robotsPhpContent)) {
                $hasHostAccess = true;
                $details[] = "Найден доступ к HTTP_HOST: {$p}";
                break;
            }
        }
        if (!$hasHostAccess) {
            return [
                'ok' => false,
                'has_host_check' => false,
                'has_disallow_branch' => $this->hasDisallowAll($robotsPhpContent),
                'has_allow_output' => $this->hasAllowOutput($robotsPhpContent),
                'reason' => 'В robots.php нет обращения к HTTP_HOST — невозможно проверить какой домен запрашивается',
                'details' => array_merge($details, ['Не найдены ссылки на HTTP_HOST/SERVER_NAME/->host()']),
            ];
        }

        // 2. Проверка наличия сравнения с $domain (или $config->domain и т.п.)
        // Ищем сравнение/функцию которая использует и HTTP_HOST и $domain
        $hasHostComparison = false;

        // Паттерн A: явное использование sameHost или подобной функции
        if (preg_match('~(?:sameHost|isSameHost|hostMatches|checkHost)\s*\(~i', $robotsPhpContent)) {
            $hasHostComparison = true;
            $details[] = 'Найден вызов sameHost/isSameHost/hostMatches/checkHost';
        }

        // Паттерн B: использование $domain в одном выражении с HTTP_HOST
        // (parse_url($domain) и сравнение, или strpos($domain, ...HTTP_HOST...), и т.д.)
        if (!$hasHostComparison) {
            // Берём по 200 символов вокруг каждого упоминания HTTP_HOST,
            // ищем в этом окне $domain
            if (preg_match_all('~HTTP_HOST~', $robotsPhpContent, $m, PREG_OFFSET_CAPTURE)) {
                foreach ($m[0] as $match) {
                    $offset = $match[1];
                    $start = max(0, $offset - 300);
                    $end = min(strlen($robotsPhpContent), $offset + 300);
                    $window = substr($robotsPhpContent, $start, $end - $start);
                    if (preg_match('~\$domain\b~', $window)) {
                        $hasHostComparison = true;
                        $details[] = 'Найдено сравнение HTTP_HOST с $domain (рядом в коде)';
                        break;
                    }
                }
            }
        }

        if (!$hasHostComparison) {
            return [
                'ok' => false,
                'has_host_check' => false,
                'has_disallow_branch' => $this->hasDisallowAll($robotsPhpContent),
                'has_allow_output' => $this->hasAllowOutput($robotsPhpContent),
                'reason' => 'В robots.php нет сравнения HTTP_HOST с $domain — нет проверки на правильный домен',
                'details' => array_merge($details, [
                    'HTTP_HOST упоминается, но рядом нет $domain',
                    'Возможно функция-обёртка (parse_url, getHost) — но мы не нашли её',
                ]),
            ];
        }

        // 3. Проверка наличия ветки с Disallow: /
        // v18.1.28: ВАЖНО — ищем Disallow: / именно в "closed" branch (когда домен НЕ совпадает),
        // а не в "open" branch (когда совпадает). Иначе ловим false-positive на сломанных
        // шаблонах где в "closed" branch стоит Allow:/ а Disallow:/ есть только в open-branch
        // как Disallow: /reg (исключение конкретного path'а).
        $closedBranchAnalysis = $this->analyzeClosedBranch($robotsPhpContent);
        $hasDisallowAll = $this->hasDisallowAll($robotsPhpContent);
        if (!$hasDisallowAll) {
            return [
                'ok' => false,
                'has_host_check' => true,
                'has_disallow_branch' => false,
                'has_allow_output' => $this->hasAllowOutput($robotsPhpContent),
                'reason' => 'В robots.php нет вывода Disallow: / — нет ветки чтобы закрыть неправильный домен',
                'details' => array_merge($details, ['Не найдены строки echo "Disallow: /" или подобные']),
            ];
        }

        // v18.1.28: проверяем именно "closed branch" — если в ней Allow:/ вместо Disallow:/,
        // это сломанный шаблон. Видели на сайтах группы 1win-77x.
        if ($closedBranchAnalysis['found_block']
            && !$closedBranchAnalysis['has_disallow_all']
            && $closedBranchAnalysis['has_allow']
        ) {
            return [
                'ok' => false,
                'has_host_check' => true,
                'has_disallow_branch' => false,
                'has_allow_output' => true,
                'broken_template' => true,
                'reason' => 'В robots.php "if (!sameHost)" branch стоит Allow:/ вместо Disallow:/ — шаблон сломан, старый домен будет ОТКРЫТ для поисковиков',
                'details' => array_merge($details, [
                    'В closed-branch (когда HTTP_HOST != $domain) найден Allow:/ — это пускает в индекс',
                    'Правильно: в этой ветке должен быть Disallow:/',
                ]),
                'closed_branch' => $closedBranchAnalysis,
            ];
        }

        // 4. Всё ОК
        return [
            'ok' => true,
            'has_host_check' => true,
            'has_disallow_branch' => true,
            'has_allow_output' => $this->hasAllowOutput($robotsPhpContent),
            'reason' => 'robots.php имеет проверку домена и ветку Disallow: /',
            'details' => $details,
            'closed_branch' => $closedBranchAnalysis,
        ];
    }

    /**
     * Возвращает рекомендуемый "правильный" robots.php (7k-стиль).
     * Используется для подсказки оператору что добавить в файл.
     */
    public function getRecommendedSnippet(): string
    {
        return <<<'PHP'
<?php
require_once __DIR__ . '/config.php';

header('Content-Type: text/plain; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

function sameHost($a, $b) {
    $hostA = parse_url(rtrim($a, '/'), PHP_URL_HOST);
    $hostB = parse_url(rtrim($b, '/'), PHP_URL_HOST);
    return mb_strtolower($hostA ?? '') === mb_strtolower($hostB ?? '');
}

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$currentBase = $scheme . '://' . $_SERVER['HTTP_HOST'];

// Если домен запроса не равен $domain из config — закрываем (старый домен)
if (!sameHost($currentBase, $domain)) {
    echo "User-agent: *\n";
    echo "Disallow: /\n";
    exit;
}

// Иначе — открыт (для актуального домена). /reg закрываем от поисковиков
// (страница регистрации редиректит на партнёрку, не должна индексироваться).
echo "User-agent: *\n";
echo "Allow: /\n";
echo "Disallow: /reg\n";
echo "Host: " . rtrim($domain, '/') . "/\n";
echo "Sitemap: " . rtrim($domain, '/') . "/sitemap.xml\n";
PHP;
    }

    /**
     * v18.1.28: Извлекает блок кода из `if (!sameHost(...))` (или эквивалента) и проверяет
     * что внутри идёт Disallow:/ (правильно) а не Allow:/ (сломанный шаблон).
     *
     * Сломанный шаблон видели на сайтах группы 1win-77x: внутри branch'а
     * "когда HTTP_HOST != $domain" стоит `echo "Allow: /"` вместо `echo "Disallow: /"`.
     * Это полностью обнуляет защиту старого домена от поисковиков.
     *
     * @return array {found_block: bool, has_disallow_all: bool, has_allow: bool, block_excerpt?: string}
     */
    private function analyzeClosedBranch(string $content): array
    {
        // Ищем if (!sameHost(...)) { ... } или if (! isSameHost(...)) {} или похожие
        // Паттерны:
        //   if (!sameHost(...))
        //   if ( !sameHost(...) )
        //   if (!$this->sameHost(...))
        //   if (sameHost(...) === false)
        $patterns = [
            // if (!sameHost($a, $b)) { ... }
            '~if\s*\(\s*!\s*(?:\$this->)?(?:sameHost|isSameHost|hostMatches|checkHost)\s*\([^)]*\)\s*\)\s*\{~i',
            // if (sameHost(...) !== true) или ===false
            '~if\s*\(\s*(?:\$this->)?(?:sameHost|isSameHost|hostMatches|checkHost)\s*\([^)]*\)\s*(?:!==|!=)\s*(?:true|1)\s*\)\s*\{~i',
            '~if\s*\(\s*(?:\$this->)?(?:sameHost|isSameHost|hostMatches|checkHost)\s*\([^)]*\)\s*(?:===|==)\s*(?:false|0)\s*\)\s*\{~i',
        ];

        foreach ($patterns as $p) {
            if (preg_match($p, $content, $m, PREG_OFFSET_CAPTURE)) {
                $blockStart = $m[0][1] + strlen($m[0][0]);
                // Найдём закрывающую }
                $depth = 1;
                $i = $blockStart;
                $len = strlen($content);
                while ($i < $len && $depth > 0) {
                    $ch = $content[$i];
                    if ($ch === '{') $depth++;
                    elseif ($ch === '}') $depth--;
                    $i++;
                }
                if ($depth === 0) {
                    $block = substr($content, $blockStart, $i - $blockStart - 1);
                    return [
                        'found_block' => true,
                        'has_disallow_all' => (bool)preg_match('~Disallow:\s*/(?:\s|\\\\n|$|"|\'|\R)~', $block),
                        'has_allow' => (bool)preg_match('~Allow:\s*/(?:\s|\\\\n|$|"|\'|\R)~', $block),
                        'block_excerpt' => $this->excerpt($block, 200),
                    ];
                }
            }
        }

        return ['found_block' => false, 'has_disallow_all' => false, 'has_allow' => false];
    }

    private function excerpt(string $s, int $maxLen = 200): string
    {
        $s = trim($s);
        if (mb_strlen($s) <= $maxLen) return $s;
        return mb_substr($s, 0, $maxLen) . '...';
    }

    /**
     * Проверка наличия Disallow: / в выводе (echo/print/heredoc/etc).
     */
    private function hasDisallowAll(string $content): bool
    {
        // Ищем "Disallow: /" в любом контексте: echo, print, heredoc, в одну строку с \n.
        // Не должно быть закомментировано — но регексп этого не проверяет, оставим simple.
        return (bool)preg_match('~Disallow:\s*/~', $content);
    }

    /**
     * Проверка наличия Allow: / в выводе.
     */
    private function hasAllowOutput(string $content): bool
    {
        return (bool)preg_match('~Allow:\s*/~', $content);
    }
}
