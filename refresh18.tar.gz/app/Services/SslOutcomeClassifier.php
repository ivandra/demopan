<?php

/**
 * v25.2-a1: единая классификация исходов выпуска trusted SSL
 * (SslIssuerService::pollLetsEncrypt). Используется И в runSslLeStage, И в
 * TrustedSslReconciler — чтобы два пути не расходились в трактовке.
 *
 * Главное правило (ТЗ §Блокер 4): rate_limited / timeout_6h / restart_blocked —
 * это TRANSIENT (продолжаем автоматически, awaiting_user НЕ ставим). В
 * awaiting_user переводим только реальный fatal (нет credentials/доступа,
 * неверная конфигурация FastPanel, неподдерживаемый домен, постоянная ошибка).
 */
class SslOutcomeClassifier
{
    // Категории решения.
    public const DECISION_ISSUED    = 'issued';    // сертификат выпущен/применён
    public const DECISION_TRANSIENT = 'transient'; // ждём и продолжаем (pending)
    public const DECISION_FATAL     = 'fatal';     // нужен оператор (awaiting_user)

    /**
     * @param array $outcome результат pollLetsEncrypt (status/reason/...)
     * @return array{
     *   decision:string, reason:string, alert_key:?string,
     *   rate_limit_resume_at:?string, message:string, telegram_hint:?string
     * }
     */
    public static function classify(array $outcome): array
    {
        $status = (string)($outcome['status'] ?? '');
        $reason = (string)($outcome['reason'] ?? '');
        $message = (string)($outcome['message'] ?? '');

        if ($status === 'issued') {
            return self::mk(self::DECISION_ISSUED, 'issued', $message);
        }

        if ($status === 'pending') {
            return self::mk(self::DECISION_TRANSIENT, $reason !== '' ? $reason : 'pending', $message);
        }

        // Раньше эти reason'ы шли в awaiting_user — теперь TRANSIENT.
        if ($status === 'awaiting_user') {
            if ($reason === 'rate_limited') {
                $d = self::mk(self::DECISION_TRANSIENT, 'rate_limited', $message);
                $d['rate_limit_resume_at'] = (string)($outcome['rate_limit_resume_at'] ?? '') ?: null;
                $d['alert_key'] = 'ssl_rate_limited';
                $d['telegram_hint'] = 'rate_limit';
                return $d;
            }
            if ($reason === 'timeout_6h') {
                $d = self::mk(self::DECISION_TRANSIENT, 'timeout_6h', $message);
                $d['alert_key'] = 'ssl_timeout_6h';
                $d['telegram_hint'] = 'long_wait';
                return $d;
            }
            if ($reason === 'restart_blocked') {
                $d = self::mk(self::DECISION_TRANSIENT, 'restart_blocked', $message);
                $d['alert_key'] = 'ssl_restart_blocked';
                $d['telegram_hint'] = 'restart_cooldown';
                return $d;
            }
            // Прочие awaiting_user причины трактуем как fatal (нужен оператор).
            return self::mk(self::DECISION_FATAL, $reason !== '' ? $reason : 'awaiting_user', $message);
        }

        if ($status === 'failed') {
            // Отличаем настоящий fatal (credentials/доступ/конфиг/домен) от
            // временного системного сбоя. По умолчанию — transient (не роняем
            // pipeline в оператора без явной fatal-причины).
            if (self::looksFatal($message)) {
                return self::mk(self::DECISION_FATAL, 'failed_fatal', $message);
            }
            return self::mk(self::DECISION_TRANSIENT, 'failed_transient', $message);
        }

        // Неизвестный статус — консервативно transient (продолжаем poll).
        return self::mk(self::DECISION_TRANSIENT, $status !== '' ? $status : 'unknown', $message);
    }

    /** Эвристика реального fatal по тексту сообщения. */
    public static function looksFatal(string $message): bool
    {
        $m = mb_strtolower($message);
        $fatalNeedles = [
            'credential', 'реквизит', 'unauthorized', '401', '403', 'forbidden',
            'not found', 'no fp_site_id', 'site #', 'нет доступа', 'invalid config',
            'неверн', 'unsupported domain', 'не поддерж', 'permission denied',
            'account', 'аккаунт',
        ];
        foreach ($fatalNeedles as $n) {
            if (mb_strpos($m, $n) !== false) return true;
        }
        return false;
    }

    private static function mk(string $decision, string $reason, string $message): array
    {
        return [
            'decision' => $decision,
            'reason' => $reason,
            'message' => $message,
            'alert_key' => null,
            'rate_limit_resume_at' => null,
            'telegram_hint' => null,
        ];
    }

    /**
     * Retry-интервал для активной джобы, ожидающей trusted SSL (ТЗ §Retry).
     * Быстрее обычного ssl_le, т.к. джоба заблокирована только SSL.
     * rate_limited — строго по resume-времени (в вызывающем коде).
     */
    public static function nextDelaySec(int $elapsedSec): int
    {
        if ($elapsedSec < 10 * 60)   return 15;        // первые 10 мин — 15с
        if ($elapsedSec < 60 * 60)   return 30;        // 10–60 мин — 30с
        if ($elapsedSec < 6 * 3600)  return 120;       // 1–6 ч — 2 мин (в пределах 60–180с)
        return 5 * 60;                                  // после 6 ч — 5 мин
    }
}
