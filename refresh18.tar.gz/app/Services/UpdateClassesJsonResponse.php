<?php
/**
 * UpdateClassesJsonResponse — маленький ЧИСТЫЙ (без I/O) классификатор JSON-ответа новой версии
 * update_classes.php. НЕ доказательство рандомизации: JSON ok=true — только сигнал «endpoint
 * сообщил успех»; фактический proof — существующая class_mapping delta + output verifier (§3.3/§9).
 * §13: допустимый маленький pure helper (не параллельная подсистема).
 */
final class UpdateClassesJsonResponse
{
    /** §9: строгий верхнеуровневый JSON ok === true (ok=1/"true"/вложенный/текст — НЕ success). */
    public static function isStrictJsonOk(string $body): bool
    {
        $d = json_decode(trim($body), true);
        return is_array($d) && array_key_exists('ok', $d) && $d['ok'] === true;
    }

    public static function decode(string $body): ?array
    {
        $d = json_decode(trim($body), true);
        return is_array($d) ? $d : null;
    }

    /**
     * §9: концепт concurrent — строго один из:
     *   ok===false + error_code==='refresh_in_progress' (новый HTTP 409), ИЛИ
     *   ok===false + точная строка 'Another template refresh is already running.' (legacy).
     * @return string|null 'refresh_in_progress' | null
     */
    public static function classifyConcurrent(array $d): ?string
    {
        if (($d['ok'] ?? null) !== false) return null;
        if (($d['error_code'] ?? null) === 'refresh_in_progress') return 'refresh_in_progress';
        if (isset($d['error']) && is_string($d['error'])
            && trim($d['error']) === 'Another template refresh is already running.') {
            return 'refresh_in_progress';
        }
        return null;
    }

    /** §9: явная ошибка скрипта (ok=false, НЕ concurrent) → blocking до delta. */
    public static function isExplicitFailure(array $d): bool
    {
        return (($d['ok'] ?? null) === false) && self::classifyConcurrent($d) === null;
    }

    /** Аудит-поля новой версии (не proof): run_id / variant.refresh_sequence / device counters. */
    public static function auditFields(array $d): array
    {
        return [
            'run_id' => (string)($d['run_id'] ?? ''),
            'refresh_sequence' => $d['variant']['refresh_sequence'] ?? null,
            'duration_ms' => $d['duration_ms'] ?? null,
        ];
    }
}
