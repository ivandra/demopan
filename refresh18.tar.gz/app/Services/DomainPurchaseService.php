<?php

/**
 * Покупка домена через Namecheap.
 *
 * v13b: реальная покупка вместо dummy. Поддерживает sandbox и prod.
 *
 * Алгоритм tryPurchase($job, $log):
 *  1. Загружает аккаунт Namecheap по job.artifacts_json.namecheap_account_id
 *     (или is_default=1 если не задан).
 *  2. Загружает контакт по job.artifacts_json.namecheap_contact_id
 *     (или env-matching: для sandbox-аккаунта — env=sandbox, для prod — env=prod).
 *  3. Строит endpoint (sandbox или prod).
 *  4. Получает список кандидатов (5 штук с маской +1) из DomainMaskService.
 *  5. Для каждого кандидата по очереди:
 *     - checkDomain → если не доступен / premium → следующий
 *     - getPricingRegister1Y → если цена > max_price_usd → следующий
 *     - createDomain → если не получилось → следующий
 *     - setHosts (DNS A на vpsIp + CNAME www → domain) → если не получилось,
 *       домен ВСЁ РАВНО куплен, пишем warning, переходим к успеху
 *  6. Сохраняет в job:
 *     - new_domain = купленный домен
 *     - artifacts_json: tried, vps_ip, price, dns_status
 *
 * Если ни один кандидат не подошёл — возвращает ['ok'=>false].
 */
class DomainPurchaseService
{
    /**
     * v18.1.31: лимиты вынесены в AppSettings (key: 'domain.candidates_per_tick',
     * 'domain.candidates_max_total'). Здесь только дефолты для fallback.
     *
     * Раньше: hardcoded MAX_ATTEMPTS = 5 → ошибка all_candidates_failed когда
     * подряд занято больше 5 доменов (например flagman336..340).
     *
     * Теперь: 30 кандидатов за один cron-tick (1 минута, ~15-30 сек на проверки).
     * Если все 30 заняты — следующий tick продолжит с того места где остановились
     * (через artifacts.domain_purchasing_stage.last_checked_domain).
     * Жёсткий потолок 200 (защита от runaway если что-то совсем не так).
     */
    private const DEFAULT_CANDIDATES_PER_TICK = 30;
    private const DEFAULT_CANDIDATES_MAX_TOTAL = 200;

    public function tryPurchase(array $job, JobEventLogger $log): array
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $oldDomain = (string)$job['old_domain'];

        // 1. Аккаунт + контакт + endpoint
        try {
            [$account, $contact, $endpoint] = is_callable($this->accountResolver)
                ? ($this->accountResolver)($job)
                : $this->resolveAccountAndContact($job);
        } catch (\Throwable $e) {
            $log->error('domain_purchasing', 'Не удалось найти аккаунт/контакт: ' . $e->getMessage());
            return ['ok' => false, 'reason' => $e->getMessage()];
        }

        // v25.0-a1 (B7): если предыдущий тик оставил неоднозначную покупку
        // (purchase_confirmation) — НЕ покупаем заново, а продолжаем read-only
        // polling getInfo с backoff. domains.create не повторяется никогда.
        $confResult = $this->pollPurchaseConfirmation($job, $account, $endpoint, $log);
        if ($confResult !== null) {
            return $confResult;
        }

        $modeLabel = $account['is_sandbox'] ? '🟡 SANDBOX' : '🔴 PROD (реальные деньги)';
        $log->info('domain_purchasing',
            "Режим: {$modeLabel}. Аккаунт: {$account['api_user']}. Контакт: {$contact['label']} ({$contact['email']})");

        // 2. Резолвим IP для DNS
        try {
            if (is_callable($this->ipResolverFn)) { $vpsIp = ($this->ipResolverFn)($siteId); }
            else { $resolver = new SiteIpResolver(); $vpsIp = $resolver->resolveForSite($siteId); }
            $log->info('domain_purchasing', "DNS A-запись будет указывать на: {$vpsIp}");
        } catch (\Throwable $e) {
            $log->error('domain_purchasing', 'IP не определён: ' . $e->getMessage());
            return ['ok' => false, 'reason' => 'ip_resolution_failed: ' . $e->getMessage()];
        }

        // v18.1.31: читаем лимиты из AppSettings (UI-настройка)
        $perTick = AppSettings::getInt('domain.candidates_per_tick', self::DEFAULT_CANDIDATES_PER_TICK);
        $perTick = max(1, min(200, $perTick));
        $maxTotal = AppSettings::getInt('domain.candidates_max_total', self::DEFAULT_CANDIDATES_MAX_TOTAL);
        $maxTotal = max(1, min(10000, $maxTotal));

        // 3. Continue-from-last: если предыдущий tick уже проверял какие-то домены,
        // продолжаем от последнего, а не с самого начала.
        $artifacts = !empty($job['artifacts_json'])
            ? (json_decode((string)$job['artifacts_json'], true) ?: [])
            : [];
        $stageArt = $artifacts['domain_purchasing_stage'] ?? [];
        $lastChecked = (string)($stageArt['last_checked_domain'] ?? '');
        $alreadyCheckedTotal = (int)($stageArt['checked_total'] ?? 0);

        // Если уже превысили общий лимит — окончательно проваливаем.
        if ($alreadyCheckedTotal >= $maxTotal) {
            $log->error('domain_purchasing',
                "Проверено уже {$alreadyCheckedTotal} доменов (лимит {$maxTotal}), все заняты. " .
                "Это похоже на проблему с маской — все домены по шаблону {$oldDomain}+N заняты. " .
                "Проверь регистратор вручную или измени маску.");
            return [
                'ok' => false,
                'reason' => 'max_total_exhausted',
                'checked_total' => $alreadyCheckedTotal,
            ];
        }

        // Стартовая точка для следующего батча — либо last_checked, либо oldDomain
        $startFrom = $lastChecked !== '' ? $lastChecked : $oldDomain;

        // Сколько ещё можем проверить (не превышая maxTotal)
        $remainingBudget = $maxTotal - $alreadyCheckedTotal;
        $thisBatchSize = min($perTick, $remainingBudget);

        // 4. Генерируем кандидатов от startFrom
        // v4 (B1): маска берётся из НЕИЗМЕНЯЕМОГО snapshot'а джобы. Раньше здесь был
        // new DomainMaskService() — глобальные настройки. Из-за этого карточка сайта
        // показывала превью по персональным параметрам, а покупались домены
        // по глобальным (например превью 7k105, а покупка шла за 7k101).
        // v5 (P1): строгий snapshot. Отсутствие/повреждение — остановка джобы,
        // а не тихий откат на глобальные настройки.
        try {
            $mask = is_callable($this->maskFactory) ? ($this->maskFactory)($jobId, $log) : MaskSnapshot::forJob($jobId, $log);
        } catch (\Throwable $e) {
            $log->error('domain_purchasing', 'Параметры маски недоступны: ' . $e->getMessage());
            return ['ok' => false, 'reason' => 'mask_snapshot_missing'];
        }
        $candidates = $mask->nextDomains($startFrom, $thisBatchSize);
        if (empty($candidates)) {
            $log->error('domain_purchasing',
                "Не удалось сгенерировать кандидатов от {$startFrom}. Маска не работает?");
            return ['ok' => false, 'reason' => 'mask_failed'];
        }

        // ТЗ044 §10: если по кандидату идёт transient-backoff — проверяем ЕГО первым (тот же
        // кандидат сохраняется, без сжигания следующих номеров во время outage).
        $retryCand = (string)($stageArt['transient_retry']['candidate'] ?? '');
        if ($retryCand !== '' && (int)($stageArt['transient_retry']['attempt'] ?? 0) <= NamecheapErrorClassifier::MAX_TRANSIENT_ATTEMPTS) {
            $candidates = array_values(array_unique(array_merge([$retryCand], $candidates)));
        }

        $startInfo = $alreadyCheckedTotal > 0
            ? " (продолжаем с #" . ($alreadyCheckedTotal + 1) . ", уже проверено {$alreadyCheckedTotal})"
            : '';
        $log->info('domain_purchasing',
            'Кандидаты по маске: ' . implode(', ', $candidates) . $startInfo);

        // 4. Создаём NamecheapClient (seam для E2E-тестов: ТЗ044 §18 / BLOCKER 6)
        if (is_callable($this->clientFactory)) {
            $client = ($this->clientFactory)($endpoint, $account, '');
        } else {
            $apiKey = Crypto::decrypt((string)$account['api_key_enc']);
            $client = new NamecheapClient(
                $endpoint,
                (string)$account['api_user'],
                $apiKey,
                (string)$account['username'],
                (string)$account['client_ip'],
                (int)config('namecheap.timeout', 30)
            );
        }

        $maxPrice = (float)config('namecheap.max_price_usd', 10.0);
        $tried = []; // лог попыток для artifacts
        $purchased = null;

        foreach ($candidates as $candidate) {
            $entry = ['domain' => $candidate];
            $log->info('domain_purchasing', "→ {$candidate}: проверка...");

            // checkDomain
            try {
                $check = $client->checkDomain($candidate);
            } catch (\Throwable $e) {
                // v25.0-a2 (аудит B3): классификация ошибки check с учётом
                // команды. Если это account-fatal (сломан ключ/IP/аккаунт) —
                // останавливаем ВЕСЬ поиск, а не перебираем домены впустую.
                $fatal = $this->detectAccountFatal($e, 'namecheap.domains.check');
                if ($fatal !== null) {
                    $log->error('domain_purchasing',
                        "{$candidate}: фатальная ошибка аккаунта на checkDomain ({$fatal}). Останавливаю поиск.");
                    $entry['result'] = 'account_fatal';
                    $entry['error'] = $e->getMessage();
                    $tried[] = $entry;
                    $this->setPurchaseAwaitingUser($jobId,
                        "Покупка остановлена на проверке домена: {$e->getMessage()}. "
                        . "Проверьте API-ключ / IP whitelist / статус аккаунта Namecheap.",
                        $tried, $log);
                    return ['ok' => false, 'reason' => 'account_fatal',
                            'domain' => $candidate, 'state_already_persisted' => true];
                }
                $log->warn('domain_purchasing', "{$candidate}: API check error: " . $e->getMessage());
                // ТЗ044 §10: транспортная transient-ошибка read-only check — НЕ считать домен
                // занятым и НЕ переходить к следующему кандидату. Тот же кандидат + bounded backoff.
                if (NamecheapErrorClassifier::isTransientTransport($e->getMessage())) {
                    $tr = $stageArt['transient_retry'] ?? [];
                    $prev = ((string)($tr['candidate'] ?? '') === $candidate && (string)($tr['operation'] ?? '') === 'check')
                        ? (int)($tr['attempt'] ?? 0) : 0;
                    $attempt = $prev + 1;
                    if ($attempt <= NamecheapErrorClassifier::MAX_TRANSIENT_ATTEMPTS) {
                        $this->setPurchaseTransientBackoff($jobId, $candidate, 'check', $attempt, $e->getMessage(), $tried, $log);
                        return ['ok' => false, 'reason' => 'transient_retry', 'domain' => $candidate,
                                'operation' => 'check', 'attempt' => $attempt, 'state_already_persisted' => true];
                    }
                    // лимит исчерпан → controlled awaiting_user (не runaway перебор)
                    $entry['result'] = 'transient_exhausted';
                    $entry['error'] = $e->getMessage();
                    $tried[] = $entry;
                    $this->setPurchaseAwaitingUser($jobId,
                        "Проверка домена {$candidate} недоступна из-за временной ошибки Namecheap после "
                        . NamecheapErrorClassifier::MAX_TRANSIENT_ATTEMPTS . " попыток: {$e->getMessage()}. "
                        . "Домен НЕ занят, деньги НЕ списаны. Повторите позже.", $tried, $log);
                    return ['ok' => false, 'reason' => 'transient_exhausted', 'domain' => $candidate,
                            'state_already_persisted' => true];
                }
                $entry['result'] = 'api_error_check';
                $entry['error'] = $e->getMessage();
                $tried[] = $entry;
                continue;
            }

            if (empty($check['available'])) {
                $log->info('domain_purchasing', "{$candidate}: занят, идём дальше");
                $entry['result'] = 'taken';
                $tried[] = $entry;
                continue;
            }

            if (!empty($check['premium'])) {
                $log->info('domain_purchasing', "{$candidate}: premium-домен, пропуск");
                $entry['result'] = 'premium';
                $tried[] = $entry;
                continue;
            }

            // ТЗ044 §10: check успешно разрешён — снять возможный stale transient_retry
            $this->clearTransientRetry($jobId);

            // Цена
            try {
                [$sld, $tld] = $mask->splitSldTld($mask->extractHost($candidate));
                $price = $client->getPricingRegister1Y($tld);
                // Округляем до 2 знаков — иначе в JSON попадает "138.97999999999998976..."
                $entry['price_usd'] = round($price, 2);
                $log->info('domain_purchasing', "{$candidate}: цена $" . number_format($price, 2));
                $this->clearTransientRetry($jobId); // pricing разрешён — тоже снять stale
            } catch (\Throwable $e) {
                // v25.0-a2 (аудит B3): та же проверка account-fatal для pricing.
                $fatal = $this->detectAccountFatal($e, 'namecheap.users.getPricing');
                if ($fatal !== null) {
                    $log->error('domain_purchasing',
                        "{$candidate}: фатальная ошибка аккаунта на pricing ({$fatal}). Останавливаю поиск.");
                    $entry['result'] = 'account_fatal';
                    $entry['error'] = $e->getMessage();
                    $tried[] = $entry;
                    $this->setPurchaseAwaitingUser($jobId,
                        "Покупка остановлена на получении цены: {$e->getMessage()}. "
                        . "Проверьте API-ключ / IP whitelist / статус аккаунта Namecheap.",
                        $tried, $log);
                    return ['ok' => false, 'reason' => 'account_fatal',
                            'domain' => $candidate, 'state_already_persisted' => true];
                }
                // ТЗ044 §10: transient на users.getPricing — тот же кандидат + bounded backoff (как для check).
                if (NamecheapErrorClassifier::isTransientTransport($e->getMessage())) {
                    $tr = $stageArt['transient_retry'] ?? [];
                    $prev = ((string)($tr['candidate'] ?? '') === $candidate && (string)($tr['operation'] ?? '') === 'pricing')
                        ? (int)($tr['attempt'] ?? 0) : 0;
                    $attempt = $prev + 1;
                    if ($attempt <= NamecheapErrorClassifier::MAX_TRANSIENT_ATTEMPTS) {
                        $this->setPurchaseTransientBackoff($jobId, $candidate, 'pricing', $attempt, $e->getMessage(), $tried, $log);
                        return ['ok' => false, 'reason' => 'transient_retry', 'domain' => $candidate,
                                'operation' => 'pricing', 'attempt' => $attempt, 'state_already_persisted' => true];
                    }
                    $entry['result'] = 'transient_exhausted';
                    $entry['error'] = $e->getMessage();
                    $tried[] = $entry;
                    $this->setPurchaseAwaitingUser($jobId,
                        "Цена для {$candidate} недоступна из-за временной ошибки Namecheap после "
                        . NamecheapErrorClassifier::MAX_TRANSIENT_ATTEMPTS . " попыток: {$e->getMessage()}. "
                        . "Домен НЕ куплен, деньги НЕ списаны.", $tried, $log);
                    return ['ok' => false, 'reason' => 'transient_exhausted', 'domain' => $candidate,
                            'state_already_persisted' => true];
                }
                $log->warn('domain_purchasing', "{$candidate}: цена не получена: " . $e->getMessage());
                $entry['result'] = 'pricing_error';
                $entry['error'] = $e->getMessage();
                $tried[] = $entry;
                continue;
            }

            if ($price > $maxPrice) {
                $log->warn('domain_purchasing',
                    "{$candidate}: цена $" . number_format($price, 2) .
                    " > лимит $" . number_format($maxPrice, 2) . ", пропуск");
                $entry['result'] = 'too_expensive';
                $tried[] = $entry;
                continue;
            }

            // ТЗ044 §11 — PRE-PURCHASE PREFLIGHT строго ДО реальной покупки.
            // Unsafe config → домен НЕ покупаем (createDomain=0), FTP write=0, aliases/cert/redirect
            // не трогаем, job → awaiting_user («домен не куплен, деньги не списаны»).
            $pf = $this->runPreflight($siteId, $candidate, $oldDomain, $mask);
            $this->persistPreflight($jobId, $pf);
            if (empty($pf['ok'])) {
                $reason = (string)($pf['reason'] ?? 'prepurchase_unsafe');
                $log->warn('domain_purchasing',
                    "{$candidate}: pre-purchase preflight НЕ пройден ({$reason}) → НЕ покупаю. Деньги не списаны, FTP write=0.");
                $entry['result'] = 'prepurchase_unsafe';
                $entry['preflight'] = $pf['prepurchase_preflight'] ?? ['ok' => false, 'reason' => $reason];
                $tried[] = $entry;
                $this->setPurchaseAwaitingUser($jobId,
                    "Домен {$candidate} НЕ куплен: конфигурация сайта несовместима с перевыставлением "
                    . "(preflight: {$reason}). Деньги НЕ списаны, FTP не изменялся. Нужно решение оператора.",
                    $tried, $log);
                return ['ok' => false, 'reason' => 'prepurchase_unsafe', 'domain' => $candidate,
                        'state_already_persisted' => true];
            }

            // Покупаем
            $log->info('domain_purchasing', "{$candidate}: покупаю за $" . number_format($price, 2));
            $createResp = null;
            $createErr = null;
            try {
                $createResp = $client->createDomain($sld, $tld, 1, $this->contactToNamecheap($contact));
            } catch (\Throwable $e) {
                $createErr = $e;
            }

            // v25.0-a (ТЗ §5): отсутствие исключения — НЕ доказательство покупки.
            // Классифицируем результат строго. Неоднозначный (timeout/5xx/битый
            // XML) — это outcome=unknown: ЗАПРЕЩЕНО повторно покупать тот же
            // домен, брать следующего кандидата или покупать другой. Сначала —
            // read-only getInfo; если домен уже в аккаунте, покупка успешна.
            $verdict = NamecheapPurchaseVerifier::classifyCreate($candidate, $createResp, $createErr);

            if ($verdict['outcome'] === NamecheapPurchaseVerifier::OUTCOME_UNKNOWN) {
                // v25.0-a1 (B7): вместо ОДНОГО немедленного getInfo — заводим
                // состояние подтверждения покупки и уходим в polling по тикам с
                // backoff. Домен мог зарегистрироваться через несколько секунд;
                // domains.create при этом НЕ повторяется.
                $log->warn('domain_purchasing',
                    "{$candidate}: неоднозначный результат покупки ({$verdict['reason']}: {$verdict['message']}). "
                    . "Запускаю read-only подтверждение через getInfo (polling с backoff), повторную покупку НЕ делаю.");
                $entry['result'] = 'purchase_unknown';
                $entry['verdict'] = $verdict;
                $tried[] = $entry;
                $this->startPurchaseConfirmation($jobId, $candidate, $tried, $verdict, $log);
                return ['ok' => false, 'reason' => 'purchase_confirmation_started',
                        'domain' => $candidate, 'state_already_persisted' => true];
            }

            if ($verdict['outcome'] === NamecheapPurchaseVerifier::OUTCOME_FAILED) {
                // v25.0-a1 (B6): account_fatal (нет баланса / неверный ключ / IP
                // не в whitelist) — искать другие домены бессмысленно, останавливаем
                // весь поиск, чтобы не крутить кандидатов впустую.
                if (!empty($verdict['account_fatal'])) {
                    $log->error('domain_purchasing',
                        "{$candidate}: фатальная ошибка аккаунта ({$verdict['reason']}: {$verdict['message']}). "
                        . "Останавливаю поиск — другие домены покупать бессмысленно.");
                    $entry['result'] = 'account_fatal';
                    $entry['verdict'] = $verdict;
                    $tried[] = $entry;
                    $this->setPurchaseAwaitingUser($jobId,
                        "Покупка остановлена: {$verdict['message']}. Проверьте баланс/ключ/IP аккаунта Namecheap.",
                        $tried, $log);
                    return ['ok' => false, 'reason' => 'account_fatal',
                            'domain' => $candidate, 'state_already_persisted' => true];
                }
                // Однозначный отказ по конкретному кандидату (домен занят/премиум) —
                // переходим к следующему.
                $log->warn('domain_purchasing',
                    "{$candidate}: покупка не удалась ({$verdict['reason']}: {$verdict['message']}). "
                    . "Перехожу к следующему кандидату.");
                $entry['result'] = 'create_failed';
                $entry['error'] = $verdict['message'];
                $entry['verdict'] = $verdict;
                $tried[] = $entry;
                continue;
            }

            // OUTCOME_SUCCESS — однозначно куплен.
            $log->ok('domain_purchasing', "✓ {$candidate} куплен!"
                . (!empty($verdict['order_id']) ? " (order #{$verdict['order_id']})" : ''));
            $entry['result'] = 'purchased';
            $entry['create_response'] = $createResp;
            $entry['verdict'] = $verdict;

            // DNS — если упадёт, не считаем фейлом покупки, только warning.
            // Домен уже наш, DNS можно поправить вручную.
            $hosts = [
                ['host' => '@',   'type' => 'A',     'address' => $vpsIp,    'ttl' => 300],
                ['host' => 'www', 'type' => 'CNAME', 'address' => $candidate, 'ttl' => 300],
            ];
            try {
                $dnsResp = $client->setHosts($sld, $tld, $hosts);

                // v25.0-a1 (B5): «не выбросило исключение» ≠ «DNS настроен».
                // Требуем DomainDNSSetHostsResult + IsSuccess=true + совпадение
                // домена, затем read-back через getHosts. Источником financial
                // готовности всё равно остаётся публичный HTTPS 200 (readiness),
                // поэтому неподтверждённый DNS не роняет покупку — но и «✓ DNS
                // настроен» больше не пишем вслепую.
                $dnsVerdict = $this->verifySetHosts($client, $sld, $tld, $candidate, $vpsIp, $dnsResp, $log);
                $entry['dns_status'] = $dnsVerdict['status'];
                $entry['dns_response_summary'] = $dnsVerdict['summary'];
                if ($dnsVerdict['status'] === 'ok') {
                    $log->ok('domain_purchasing',
                        "✓ DNS подтверждён: A={$vpsIp}, www CNAME={$candidate} (IsSuccess=true, read-back ok)");
                } else {
                    $log->warn('domain_purchasing',
                        "⚠ DNS не подтверждён ({$dnsVerdict['reason']}). Домен куплен; "
                        . "готовность всё равно определяется публичным HTTPS 200. "
                        . "При необходимости поправьте DNS вручную в Namecheap.");
                }
            } catch (\Throwable $e) {
                $log->warn('domain_purchasing',
                    "⚠ DNS не настроен (домен УЖЕ КУПЛЕН): " . $e->getMessage() .
                    ". Поправь DNS вручную в Namecheap.");
                $entry['dns_status'] = 'failed';
                $entry['dns_error'] = $e->getMessage();
            }

            $tried[] = $entry;
            $purchased = $candidate;

            // v18.1.28: после успешной покупки — фоновая проверка баланса Namecheap.
            // Если после списания стоимости домена баланс упал ниже threshold —
            // мгновенный TG-алерт. Не блокируем pipeline даже если check упадёт.
            try {
                $balanceChecker = new BalanceCheckService();
                // v18.1.28 fix: для is_default=1 аккаунта используем 'default' label,
                // чтобы избежать дубликатов в balance_current (BalanceCheckService
                // canonicalAccountLabel это всё равно сделает, но лучше явно).
                // Передаём username только если это НЕ дефолтный аккаунт.
                $accountLabel = ((int)($account['is_default'] ?? 0) === 1)
                    ? 'default'
                    : ((string)($account['username'] ?? 'default') ?: 'default');
                $br = $balanceChecker->checkOne('namecheap', 'after_purchase', $accountLabel);
                if (!empty($br['ok'])) {
                    $balanceStr = '$' . number_format((float)$br['balance'], 2);
                    $statusEmoji = $br['status'] === 'low' ? '⚠' : '✓';
                    $log->info('domain_purchasing',
                        "{$statusEmoji} Баланс Namecheap после покупки: {$balanceStr} " .
                        ($br['status'] === 'low' ? '(НИЖЕ порога — отправлен TG-алерт)' : '(норма)'));
                } else {
                    $log->info('domain_purchasing',
                        "Не удалось проверить баланс Namecheap: " . (string)($br['error'] ?? '?'));
                }
            } catch (\Throwable $e) {
                $log->info('domain_purchasing',
                    'Balance check после покупки упал: ' . $e->getMessage());
            }

            break;
        }

        // 5. Сохраняем артефакты в БД
        $artifacts = [
            'mode' => $account['is_sandbox'] ? 'sandbox' : 'prod',
            'namecheap_account_id' => (int)$account['id'],
            'namecheap_account_user' => (string)$account['api_user'],
            'namecheap_contact_id' => (int)$contact['id'],
            'namecheap_endpoint' => $endpoint,
            'vps_ip' => $vpsIp,
            'tried' => $tried,
            'max_price_usd' => $maxPrice,
            'purchased_domain' => $purchased,
        ];

        if ($purchased !== null) {
            // v21: пересчитываем sub_id ОТ КУПЛЕННОГО ДОМЕНА.
            // Раньше sub_id инкрементился независимо (+1 от старого значения из
            // конфига сайта) и расходился с доменом: в проде встречался разрыв до 52
            // (сайт 7k5212 — домен дошёл до 7k5265, а sub_id всё время выдавал 7k5213).
            // Теперь число sub_id всегда равно числу нового домена.
            try {
                $jq = DB::pdo()->prepare("SELECT old_sub_id FROM refresh_jobs WHERE id = ?");
                $jq->execute([$jobId]);
                $jrow = $jq->fetch();

                $oldSub = (string)($jrow['old_sub_id'] ?? '');
                if ($oldSub !== '') {
                    // v4 (B5): те же параметры, что и на остальных стадиях джобы.
                    $maskSvc = MaskSnapshot::forJob($jobId, $log);
                    $syncedSub = $maskSvc->subIdForDomain($oldSub, $purchased);
                    if ($syncedSub !== '') {
                        $su = DB::pdo()->prepare("UPDATE refresh_jobs SET new_sub_id = ? WHERE id = ?");
                        $su->execute([$syncedSub, $jobId]);
                        $artifacts['sub_id_synced'] = [
                            'old' => $oldSub,
                            'new' => $syncedSub,
                            'from_domain' => $purchased,
                        ];
                        $log->info('domain_purchasing',
                            "sub_id синхронизирован с доменом: {$oldSub} → {$syncedSub} (домен {$purchased})");
                    }
                }
            } catch (\Throwable $e) {
                // Не валим покупку из-за sub_id — остаётся предварительное значение.
                $log->error('domain_purchasing', 'Не удалось синхронизировать sub_id: ' . $e->getMessage());
            }

            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    new_domain = ?,
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            );
            $st->execute([
                $purchased,
                json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);

            // v22: новый домен зафиксирован — дописываем snapshot записи переезда.
            // Раньше запись создавалась до покупки, поэтому snapshot был пуст.
            try {
                $relRow = RelocationService::findByJobId($jobId);
                if ($relRow) {
                    RelocationService::refreshSnapshot((int)$relRow['id']);
                }
            } catch (\Throwable $e) {
                $log->warn('domain_purchasing',
                    'Не удалось дописать snapshot переезда: ' . $e->getMessage());
            }

            return ['ok' => true, 'domain' => $purchased];
        }

        // Ни один не сработал
        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
             WHERE id = ?"
        );
        $st->execute([
            json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            $jobId,
        ]);

        $reasons = array_column($tried, 'result');
        $newCheckedTotal = $alreadyCheckedTotal + count($tried);
        $lastInBatch = !empty($tried) ? (string)end($tried)['domain'] : $startFrom;

        // v18.1.31: возвращаем 'batch_exhausted' если все из этого батча заняты
        // и общий лимит ещё не превышен. RefreshOrchestrator перезапустит стадию
        // в следующем tick с last_checked_domain, начнётся новый батч.
        $allTaken = !empty($tried) && count(array_filter($reasons, function($r) {
            return in_array($r, ['taken', 'premium'], true);
        })) === count($tried);

        $canRetry = $allTaken && $newCheckedTotal < $maxTotal;

        if ($canRetry) {
            $log->warn('domain_purchasing',
                'Все ' . count($tried) . ' кандидатов в этом батче заняты: ' .
                implode(', ', $reasons) . '. ' .
                "Всего проверено: {$newCheckedTotal} / {$maxTotal}. " .
                "Продолжаем поиск в следующем tick (от " . $lastInBatch . ").");
            return [
                'ok' => false,
                'reason' => 'batch_exhausted',
                'tried' => $tried,
                'last_checked_domain' => $lastInBatch,
                'checked_total' => $newCheckedTotal,
                'max_total' => $maxTotal,
            ];
        }

        // Иначе — либо превысили общий лимит, либо были API-ошибки которые
        // не позволяют продолжить уверенно. Останавливаемся.
        $log->error('domain_purchasing',
            'Все ' . count($tried) . ' кандидатов не подошли: ' . implode(', ', $reasons) .
            ". Общий счётчик: {$newCheckedTotal} / {$maxTotal}. Остановка.");
        return [
            'ok' => false,
            'reason' => 'all_candidates_failed',
            'tried' => $tried,
            'last_checked_domain' => $lastInBatch,
            'checked_total' => $newCheckedTotal,
            'max_total' => $maxTotal,
        ];
    }

    /**
     * Загружает аккаунт Namecheap и контакт, возвращает [$account, $contact, $endpoint].
     *
     * Логика выбора аккаунта:
     *  1. Если в job.artifacts_json есть namecheap_account_id — используем его
     *  2. Иначе если в /settings установлен sandbox-режим — берём первый is_sandbox=1
     *  3. Иначе — is_default=1
     *  4. Иначе — первый попавшийся
     *
     * Логика выбора контакта:
     *  1. Если в job.artifacts_json есть namecheap_contact_id — используем его
     *  2. Иначе для sandbox-аккаунта берём env=sandbox, для prod — env=prod
     *  3. Иначе — первый попавшийся
     */
    /**
     * v25.0-a1 (B7): начать read-only подтверждение неоднозначной покупки.
     * Сохраняет состояние в artifacts и планирует следующий тик. domains.create
     * НЕ повторяется — только getInfo на последующих тиках.
     */
    private function startPurchaseConfirmation(int $jobId, string $candidate, array $tried, array $verdict, JobEventLogger $log): void
    {
        $interval = max(10, AppSettings::getInt('purchase.confirm_interval_seconds', 20));
        $patch = ['domain_purchasing_stage' => [
            'purchase_confirmation' => [
                'domain'      => $candidate,
                'started_at'  => date('Y-m-d H:i:s'),
                'started_unix'=> time(),
                'attempts'    => 0,
                'last_reason' => (string)($verdict['reason'] ?? ''),
            ],
            'tried' => $tried,
        ]];
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND),
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                $interval,
                json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('domain_purchasing', 'startPurchaseConfirmation failed: ' . $e->getMessage());
        }
    }

    /**
     * v25.0-a1 (B7): один тик read-only подтверждения покупки.
     * @return array|null null — подтверждения нет (обычная покупка), иначе
     *         результат для оркестратора (state_already_persisted=true).
     */
    private function pollPurchaseConfirmation(array $job, array $account, string $endpoint, JobEventLogger $log): ?array
    {
        $jobId = (int)$job['id'];
        $arts = json_decode((string)($job['artifacts_json'] ?? ''), true) ?: [];
        $conf = $arts['domain_purchasing_stage']['purchase_confirmation'] ?? null;
        if (!is_array($conf) || empty($conf['domain']) || !empty($conf['resolved'])) {
            return null; // подтверждения нет / уже разрешено — обычный ход
        }

        $candidate = (string)$conf['domain'];
        $attempts = (int)($conf['attempts'] ?? 0) + 1;
        $startedUnix = (int)($conf['started_unix'] ?? time());
        $windowMin = max(1, AppSettings::getInt('purchase.confirm_timeout_minutes', 15));

        // Read-only getInfo — покупку НЕ повторяем.
        $verdict = ['outcome' => NamecheapPurchaseVerifier::OUTCOME_UNKNOWN, 'reason' => 'getinfo_error'];
        try {
            $client = $this->makeClient($account, $endpoint);
            $infoResp = null; $infoErr = null;
            try { $infoResp = $client->getDomainInfo($candidate); }
            catch (\Throwable $e2) { $infoErr = $e2; }
            $verdict = NamecheapPurchaseVerifier::classifyGetInfo($candidate, $infoResp, $infoErr);
        } catch (\Throwable $e) {
            $log->warn('domain_purchasing', "confirm poll: клиент недоступен: " . $e->getMessage());
        }

        $log->info('domain_purchasing',
            "Подтверждение покупки {$candidate}: попытка {$attempts}, getInfo → {$verdict['outcome']} ({$verdict['reason']})");

        if ($verdict['outcome'] === NamecheapPurchaseVerifier::OUTCOME_SUCCESS) {
            $log->ok('domain_purchasing', "✓ Покупка {$candidate} подтверждена через getInfo. Настраиваю DNS.");
            // v25.0-a2 (Блокер 1): на пути getInfo-подтверждения DNS РАНЬШЕ не
            // настраивался (setHosts выполнялся только после createDomain).
            // Домен оставался с дефолтными NS → readiness ждал 90 мин впустую.
            // Теперь настраиваем DNS здесь же, идемпотентно, с read-back, и
            // возвращаем проверяемый результат (не глотаем ошибку в ok=true).
            $fin = $this->finalizeConfirmedPurchase($jobId, (int)$job['site_id'], $candidate, $client, $endpoint, $account, $log);
            if (empty($fin['ok'])) {
                // DNS не удалось настроить/подтвердить — НЕ завершаем покупку как ok.
                $this->setPurchaseAwaitingUser($jobId,
                    "Домен {$candidate} куплен и подтверждён, но DNS не настроен: {$fin['reason']}. "
                    . "Проверьте A-запись (VPS IP) и www CNAME в Namecheap вручную.",
                    $arts['domain_purchasing_stage']['tried'] ?? [], $log);
                return ['ok' => false, 'reason' => 'confirmed_but_dns_failed',
                        'domain' => $candidate, 'state_already_persisted' => true];
            }
            return ['ok' => true, 'domain' => $candidate];
        }

        // Окно подтверждения истекло → awaiting_user.
        if ((time() - $startedUnix) >= $windowMin * 60) {
            $log->warn('domain_purchasing',
                "Покупку {$candidate} не удалось подтвердить за {$windowMin} мин. Останавливаю для ручной проверки.");
            $this->setPurchaseAwaitingUser($jobId,
                "Неоднозначный результат покупки {$candidate}: не подтверждено за {$windowMin} мин. "
                . "Проверьте домен в Namecheap вручную. Повторная авто-покупка запрещена.",
                $arts['domain_purchasing_stage']['tried'] ?? [], $log);
            return ['ok' => false, 'reason' => 'purchase_unknown',
                    'domain' => $candidate, 'state_already_persisted' => true];
        }

        // Backoff: интервал растёт до потолка.
        $base = max(10, AppSettings::getInt('purchase.confirm_interval_seconds', 20));
        $interval = min(120, $base * (int)pow(2, min(3, $attempts - 1)));
        $conf['attempts'] = $attempts;
        $conf['last_reason'] = (string)$verdict['reason'];
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND),
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                $interval,
                json_encode(['domain_purchasing_stage' => ['purchase_confirmation' => $conf]],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('domain_purchasing', 'pollPurchaseConfirmation persist failed: ' . $e->getMessage());
        }
        return ['ok' => false, 'reason' => 'purchase_confirmation_polling',
                'domain' => $candidate, 'state_already_persisted' => true];
    }

    /**
     * v25.0-a2 (Блокер 1): зафиксировать подтверждённую покупку — настроить DNS
     * (setHosts A@=vpsIp + www CNAME), проверить через read-back, и ТОЛЬКО при
     * успехе записать new_domain + пометить стадию ok. Возвращает проверяемый
     * результат; DB/DNS-ошибку НЕ превращает в ok=true.
     *
     * @return array{ok:bool, reason:string}
     */
    private function finalizeConfirmedPurchase(
        int $jobId, int $siteId, string $candidate, $client, string $endpoint, array $account, JobEventLogger $log
    ): array {
        // 1) VPS IP заново (не полагаемся на прошлое состояние).
        try {
            $vpsIp = (new SiteIpResolver())->resolveForSite($siteId);
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => 'ip_resolution_failed: ' . $e->getMessage()];
        }

        // 2) Идемпотентный setHosts (create НЕ трогаем).
        try {
            if (!$client) $client = $this->makeClient($account, $endpoint);
            [$sld, $tld] = $client->splitSldTld($candidate);
            $hosts = [
                ['host' => '@',   'type' => 'A',     'address' => $vpsIp,     'ttl' => 300],
                ['host' => 'www', 'type' => 'CNAME', 'address' => $candidate, 'ttl' => 300],
            ];
            $dnsResp = $client->setHosts($sld, $tld, $hosts);
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => 'setHosts failed: ' . $e->getMessage()];
        }

        // 3) Проверка результата + read-back (тот же строгий путь, что основной).
        $verdict = $this->verifySetHosts($client, $sld, $tld, $candidate, $vpsIp, $dnsResp, $log);
        if ($verdict['status'] !== 'ok') {
            return ['ok' => false, 'reason' => 'dns_unconfirmed: ' . $verdict['reason']];
        }
        $log->ok('domain_purchasing', "✓ DNS подтверждён для {$candidate}: A={$vpsIp}, www CNAME={$candidate}");

        // 4) Только теперь фиксируем покупку. DB-ошибку возвращаем как есть.
        try {
            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    new_domain = ?,
                    stage_status = 'ok',
                    stage_finished_at = NOW(),
                    next_run_at = NULL,
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $st->execute([
                $candidate,
                json_encode(['domain_purchasing_stage' => [
                    'purchased_domain' => $candidate,
                    'confirmed_via' => 'getInfo_polling',
                    'dns_status' => 'ok',
                    'dns_response_summary' => $verdict['summary'],
                    'purchase_confirmation' => ['resolved' => true, 'resolved_at' => date('Y-m-d H:i:s')],
                ]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
            if ($st->rowCount() !== 1) {
                // Джобу закрыли/сменили состояние — не считаем успехом.
                return ['ok' => false, 'reason' => 'job_state_changed_during_finalize'];
            }
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => 'db_persist_failed: ' . $e->getMessage()];
        }

        return ['ok' => true, 'reason' => 'confirmed_and_dns_ok'];
    }

    /** Построить NamecheapClient из данных аккаунта (для confirm-polling). */
    private function makeClient(array $account, string $endpoint)
    {
        $apiKey = Crypto::decrypt((string)$account['api_key_enc']);
        return new NamecheapClient(
            $endpoint,
            (string)$account['api_user'],
            $apiKey,
            (string)$account['username'],
            (string)$account['client_ip'],
            (int)config('namecheap.timeout', 30)
        );
    }

    /**
     * v25.0-a (ТЗ §5.2): остановить стадию покупки на awaiting_user при
     * неоднозначном результате. Сохраняет tried в артефакты и сбрасывает
     * next_run_at, чтобы cron не пытался повторить покупку автоматически.
     * Guard по терминальным стадиям — на случай гонки с закрытием джобы.
     */
    /** ТЗ044 §11 — seam для preflight (тесты подменяют fake). fn(int,string,string):array */
    public $preflightFn = null;

    /** ТЗ044 §18 — seam для NamecheapClient (E2E-тесты). fn(string $endpoint, array $account, string $apiKey):object */
    public $clientFactory = null;

    /** ТЗ044 §18 — seam аккаунта/контакта (E2E). fn(array $job):array [account,contact,endpoint] */
    public $accountResolver = null;
    /** ТЗ044 §18 — seam маски (E2E). fn(int $jobId,$log):DomainMaskService */
    public $maskFactory = null;
    /** ТЗ044 §18 — seam IP-резолвера (E2E). fn(int $siteId):string */
    public $ipResolverFn = null;

    /** Выполнить pre-purchase preflight (read-only, FTP write=0, без Namecheap create). */
    private function runPreflight(int $siteId, string $candidate, string $oldDomain, $mask): array
    {
        try {
            if (is_callable($this->preflightFn)) return ($this->preflightFn)($siteId, $candidate, $oldDomain);
            $svc = new SiteConfigMutationService(new SiteConfigSyncService(), new StaticSiteConfigScanner(), $mask);
            return $svc->preflight($siteId, $candidate, $oldDomain);
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => 'preflight_exception',
                    'prepurchase_preflight' => ['candidate' => $candidate, 'ok' => false, 'error' => $e->getMessage(), 'ftp_writes' => 0]];
        }
    }

    private function persistPreflight(int $jobId, array $pf): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id = ?"
            )->execute([json_encode(['prepurchase_preflight' => $pf['prepurchase_preflight'] ?? ['ok' => !empty($pf['ok'])]],
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
        } catch (\Throwable $e) { /* артефакт для UI */ }
    }

    /** ТЗ044 §10 — атомарно снять stale transient_retry после успешного разрешения кандидата. */
    private function clearTransientRetry(int $jobId): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs
                    SET artifacts_json = JSON_REMOVE(artifacts_json, '$.domain_purchasing_stage.transient_retry')
                  WHERE id = ?
                    AND JSON_EXTRACT(artifacts_json, '$.domain_purchasing_stage.transient_retry') IS NOT NULL"
            )->execute([$jobId]);
        } catch (\Throwable $e) { /* не критично */ }
    }

    /**
     * ТЗ044 §10 — bounded backoff для transient read-only ошибки: сохранить кандидата,
     * поставить pending + next_run_at = now + backoff, записать transient_retry в artifacts.
     * Домен НЕ помечается taken, следующий кандидат НЕ берётся.
     */
    private function setPurchaseTransientBackoff(int $jobId, string $candidate, string $operation,
                                                 int $attempt, string $lastError, array $tried, JobEventLogger $log): void
    {
        $delay = NamecheapErrorClassifier::backoffSeconds($attempt);
        $nextAt = date('Y-m-d H:i:s', time() + $delay);
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    stage_error = ?,
                    next_run_at = ?,
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                mb_substr("transient {$operation} #{$attempt}: {$lastError}", 0, 1000),
                $nextAt,
                json_encode(['domain_purchasing_stage' => ['transient_retry' => [
                    'candidate' => $candidate, 'operation' => $operation, 'attempt' => $attempt,
                    'last_error' => mb_substr($lastError, 0, 300), 'next_retry_at' => $nextAt,
                    'backoff_seconds' => $delay,
                ]]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
            $log->warn('domain_purchasing',
                "{$candidate}: временная ошибка {$operation} (попытка {$attempt}/"
                . NamecheapErrorClassifier::MAX_TRANSIENT_ATTEMPTS . "). Тот же кандидат сохранён, "
                . "повтор через {$delay}s. Домен НЕ занят, следующий не берём.");
        } catch (\Throwable $e) {
            $log->warn('domain_purchasing', 'setPurchaseTransientBackoff failed: ' . $e->getMessage());
        }
    }

    private function setPurchaseAwaitingUser(int $jobId, string $reason, array $tried, JobEventLogger $log): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'awaiting_user',
                    stage_error = ?,
                    stage_finished_at = NOW(),
                    next_run_at = NULL,
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                mb_substr($reason, 0, 1000),
                json_encode(['domain_purchasing_stage' => [
                    'purchase_outcome' => 'unknown',
                    'tried' => $tried,
                    'awaiting_reason' => $reason,
                ]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('domain_purchasing', 'setPurchaseAwaitingUser failed: ' . $e->getMessage());
        }
    }

    /**
     * v25.0-a2 (аудит B3): вернуть описание, если ошибка команды — account-fatal
     * (сломан ключ/IP/аккаунт), иначе null. Используется на checkDomain/pricing,
     * чтобы не перебирать домены при неисправном аккаунте.
     */
    private function detectAccountFatal(\Throwable $e, string $command): ?string
    {
        $code = NamecheapErrorClassifier::extractCode($e->getMessage());
        $cls = NamecheapErrorClassifier::classify($code, $command, $e->getMessage());
        return !empty($cls['account_fatal']) ? (string)$cls['message'] : null;
    }

    private function resolveAccountAndContact(array $job): array
    {        $artifacts = [];
        if (!empty($job['artifacts_json'])) {
            $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
        }

        // Аккаунт
        $accountId = (int)($artifacts['namecheap_account_id'] ?? 0);
        $account = null;
        if ($accountId > 0) {
            $st = DB::pdo()->prepare("SELECT * FROM registrar_accounts WHERE id=? AND provider='namecheap'");
            $st->execute([$accountId]);
            $account = $st->fetch();
        }
        if (!$account) {
            // Sandbox-режим из настроек?
            $sandboxMode = $this->isSandboxModeEnabled();
            if ($sandboxMode) {
                $st = DB::pdo()->query("SELECT * FROM registrar_accounts WHERE provider='namecheap' AND is_sandbox=1 ORDER BY id LIMIT 1");
                $account = $st->fetch();
            }
            if (!$account) {
                // is_default
                $st = DB::pdo()->query("SELECT * FROM registrar_accounts WHERE provider='namecheap' AND is_default=1 LIMIT 1");
                $account = $st->fetch();
            }
            if (!$account) {
                $st = DB::pdo()->query("SELECT * FROM registrar_accounts WHERE provider='namecheap' ORDER BY id LIMIT 1");
                $account = $st->fetch();
            }
        }
        if (!$account) {
            throw new RuntimeException('Не найден ни один аккаунт Namecheap. Добавь его в /registrar/accounts.');
        }

        // Контакт
        $contactId = (int)($artifacts['namecheap_contact_id'] ?? 0);
        $contact = null;
        if ($contactId > 0) {
            $st = DB::pdo()->prepare("SELECT * FROM registrar_contacts WHERE id=?");
            $st->execute([$contactId]);
            $contact = $st->fetch();
        }
        if (!$contact) {
            $env = $account['is_sandbox'] ? 'sandbox' : 'prod';
            $st = DB::pdo()->prepare("SELECT * FROM registrar_contacts WHERE env=? ORDER BY id LIMIT 1");
            $st->execute([$env]);
            $contact = $st->fetch();
        }
        if (!$contact) {
            $st = DB::pdo()->query("SELECT * FROM registrar_contacts ORDER BY id LIMIT 1");
            $contact = $st->fetch();
        }
        if (!$contact) {
            throw new RuntimeException('Не найден ни один контакт регистратора. Добавь его в /registrar/contacts.');
        }

        // Endpoint
        $endpoint = $account['is_sandbox']
            ? (string)config('namecheap.endpoint_sandbox', 'https://api.sandbox.namecheap.com/xml.response')
            : (string)config('namecheap.endpoint', 'https://api.namecheap.com/xml.response');

        return [$account, $contact, $endpoint];
    }

    /**
     * Глобальный sandbox-режим для перевыставления (можно включить/выключить
     * в /settings без редактирования config.php).
     * Хранится в той же таблице что Telegram, чтобы не плодить таблицы.
     */
    private function isSandboxModeEnabled(): bool
    {
        try {
            $st = DB::pdo()->query("SELECT use_sandbox FROM telegram_settings WHERE id=1");
            $r = $st->fetchColumn();
            return $r !== false && (int)$r === 1;
        } catch (\Throwable $e) {
            // Колонка может не существовать (старая БД) — считаем sandbox=true по умолчанию для безопасности
            return true;
        }
    }

    private function contactToNamecheap(array $c): array
    {
        return [
            'first_name'    => (string)$c['first_name'],
            'last_name'     => (string)$c['last_name'],
            'organization'  => (string)($c['organization'] ?? ''),
            'address1'      => (string)$c['address1'],
            'address2'      => (string)($c['address2'] ?? ''),
            'city'          => (string)$c['city'],
            'state_province'=> (string)($c['state_province'] ?? ''),
            'postal_code'   => (string)$c['postal_code'],
            'country'       => (string)$c['country'],
            'phone'         => $this->normalizePhone((string)$c['phone']),
            'email'         => (string)$c['email'],
        ];
    }

    /**
     * Namecheap требует phone в формате +CC.NNNNNNNNNN (точка между кодом страны и номером).
     */
    private function normalizePhone(string $phone): string
    {
        $p = trim($phone);
        // Если уже в правильном формате (есть точка) — не трогаем
        if (strpos($p, '.') !== false && $p[0] === '+') {
            return $p;
        }
        // Удаляем всё кроме цифр, кроме лидирующего '+'
        $p = preg_replace('~(?!^\+)[^\d]~', '', $p);
        if ($p !== '' && $p[0] !== '+') {
            $p = '+' . $p;
        }
        if (preg_match('~^\+(\d{1,3})(\d{6,})$~', $p, $m)) {
            return '+' . $m[1] . '.' . $m[2];
        }
        return $phone;
    }

    /**
     * v25.0-a1 (B5): строгая проверка результата setHosts.
     * Требует DomainDNSSetHostsResult + IsSuccess=true + совпадение домена,
     * затем getHosts read-back с проверкой ожидаемых A(@)=vpsIp и CNAME(www).
     * Возвращает ['status'=>'ok'|'unconfirmed', 'reason'=>..., 'summary'=>...].
     * Не бросает — DNS не блокирует покупку (готовность = публичный HTTPS 200).
     */
    private function verifySetHosts(
        $client, string $sld, string $tld, string $candidate, string $vpsIp, array $resp, JobEventLogger $log
    ): array {
        $summary = $this->summarizeSetHostsResponse($resp);

        $result = $resp['DomainDNSSetHostsResult'] ?? null;
        if (!is_array($result)) {
            return ['status' => 'unconfirmed', 'reason' => 'no DomainDNSSetHostsResult', 'summary' => $summary];
        }
        $isSuccess = strtolower(trim((string)($result['@IsSuccess'] ?? $result['IsSuccess'] ?? '')));
        if ($isSuccess !== 'true' && $isSuccess !== '1') {
            return ['status' => 'unconfirmed', 'reason' => 'IsSuccess=' . ($isSuccess ?: 'absent'), 'summary' => $summary];
        }
        $respDomain = strtolower(trim((string)($result['@Domain'] ?? $result['Domain'] ?? '')));
        if ($respDomain !== '' && $respDomain !== strtolower($candidate)) {
            return ['status' => 'unconfirmed', 'reason' => "domain mismatch ({$respDomain})", 'summary' => $summary];
        }

        // Read-back: getHosts должен вернуть наши записи.
        try {
            $hostsResp = $client->getHosts($sld, $tld);
            $rows = $this->extractHostRecords($hostsResp);
            $hasA = false; $hasWwwCorrect = false; $wwwWrongAddr = null;
            $cand = strtolower(rtrim($candidate, '.'));
            foreach ($rows as $r) {
                $type = strtoupper((string)($r['type'] ?? ''));
                $name = strtolower((string)($r['name'] ?? ''));
                $addr = strtolower(trim((string)($r['address'] ?? ''), " ."));
                if ($type === 'A' && ($name === '@' || $name === '') && $addr === strtolower($vpsIp)) $hasA = true;
                if ($type === 'CNAME' && $name === 'www') {
                    // v25.0-a2 (аудит): проверяем АДРЕС www CNAME, а не только наличие.
                    if ($addr === $cand) $hasWwwCorrect = true;
                    else $wwwWrongAddr = $addr;
                }
            }
            $summary['readback_records'] = count($rows);
            $summary['readback_a'] = $hasA;
            $summary['readback_www_correct'] = $hasWwwCorrect;
            if ($wwwWrongAddr !== null) $summary['readback_www_addr'] = $wwwWrongAddr;

            if (!$hasA) {
                return ['status' => 'unconfirmed', 'reason' => 'read-back: A@='.$vpsIp.' не найден', 'summary' => $summary];
            }
            // www CNAME обязателен и должен указывать на купленный домен.
            $wwwRequired = AppSettings::getBool('dns.require_www_cname', true);
            if ($wwwRequired && !$hasWwwCorrect) {
                $why = $wwwWrongAddr !== null
                    ? "www CNAME указывает на '{$wwwWrongAddr}', а не на '{$cand}'"
                    : "www CNAME отсутствует";
                return ['status' => 'unconfirmed', 'reason' => 'read-back: ' . $why, 'summary' => $summary];
            }
            return ['status' => 'ok', 'reason' => 'confirmed', 'summary' => $summary];
        } catch (\Throwable $e) {
            // getHosts упал — IsSuccess был true, но подтвердить не смогли.
            $summary['readback_error'] = $e->getMessage();
            return ['status' => 'unconfirmed', 'reason' => 'getHosts failed: ' . $e->getMessage(), 'summary' => $summary];
        }
    }

    /** Достать записи хостов из ответа getHosts (устойчиво к формам xmlToArray). */
    private function extractHostRecords(array $resp): array
    {
        $result = $resp['DomainDNSGetHostsResult'] ?? $resp;
        $hosts = $result['host'] ?? $result['Host'] ?? [];
        if (isset($hosts['@Name']) || isset($hosts['Name'])) $hosts = [$hosts]; // одиночная запись
        $out = [];
        if (is_array($hosts)) {
            foreach ($hosts as $h) {
                if (!is_array($h)) continue;
                $out[] = [
                    'name'    => $h['@Name'] ?? ($h['Name'] ?? ''),
                    'type'    => $h['@Type'] ?? ($h['Type'] ?? ''),
                    'address' => $h['@Address'] ?? ($h['Address'] ?? ''),
                ];
            }
        }
        return $out;
    }

    /**
     * Свернуть ответ setHosts до краткой инфы (чтобы не раздувать artifacts_json).
     */
    private function summarizeSetHostsResponse(array $resp): array
    {
        $result = $resp['DomainDNSSetHostsResult'] ?? null;
        if (!is_array($result)) return ['raw' => 'no_result'];
        return [
            'domain' => $result['@Domain'] ?? null,
            'is_success' => $result['@IsSuccess'] ?? null,
        ];
    }
}
