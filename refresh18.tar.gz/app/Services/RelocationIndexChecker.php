<?php

/**
 * RelocationIndexChecker — проверка индекса нового домена для раздела «Переезды».
 *
 * Источник — СТРОГО XMLStock. Класс намеренно НЕ использует
 * IndexCheckOrchestrator: тот при недоступном XMLStock молча уходит в fallback
 * на Яндекс.Вебмастер (см. его докблок), а для раздела «Переезды» результат
 * Вебмастера не является основанием менять index_status или писать
 * first_indexed_at. Вебмастер применяется отдельно — только для подтверждения
 * фактического переезда через MoveStatusChecker.
 *
 * Защита от параллельных запросов:
 *   MySQL GET_LOCK по домену. Лок берётся и освобождается на ОДНОМ соединении
 *   (DB::pdo() — синглтон), RELEASE_LOCK выполняется в finally.
 *   Занятый лок — это НЕ ошибка XMLStock: он пишется в историю как
 *   ok=0/error_code=lock_busy, но index_status и index_checked_at не меняет,
 *   иначе занятый лок отложил бы реальную проверку ещё на сутки.
 *
 * Совместимо с PHP 7.4.
 */
class RelocationIndexChecker
{
    /** Сколько секунд ждать лок (0 — не ждать вовсе). */
    const LOCK_TIMEOUT_SEC = 0;

    /**
     * Выполнить проверку индекса для записи переезда.
     *
     * @param string $trigger manual|cron
     * @return array ['ok'=>bool,'skipped'=>bool,'status'=>string,'message'=>string,'indexed'=>bool,'pages'=>int]
     */
    /**
     * Имя общего лока по домену. Используется ВСЕМИ источниками проверки
     * (pipeline, manual, cron) — иначе pipeline и ручная проверка могли бы
     * отправить два платных запроса одновременно.
     */
    public static function lockName(string $domain): string
    {
        return 'reloc_idx_' . md5(strtolower(trim($domain)));
    }

    /**
     * Захватить общий XMLStock-лок по домену.
     * @return bool получен ли лок
     */
    public static function acquireLock(string $domain, int $timeoutSec = 0): bool
    {
        try {
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, ?)");
            $st->execute([self::lockName($domain), $timeoutSec]);
            return ((int)$st->fetchColumn() === 1);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Освободить общий лок (обязательно в finally у вызывающей стороны). */
    public static function releaseLock(string $domain): void
    {
        try {
            $st = DB::pdo()->prepare("SELECT RELEASE_LOCK(?)");
            $st->execute([self::lockName($domain)]);
        } catch (\Throwable $e) {
            // лок освободится при закрытии соединения
        }
    }

    /**
     * Серверные предусловия проверки. Возвращает код причины отказа или null.
     *
     * Эти проверки обязаны жить в сервисе, а не только в интерфейсе: POST
     * можно отправить напрямую или повторить, и платный запрос всё равно ушёл бы.
     */
    public static function precheck(int $relocationId, string $domain): ?string
    {
        $rel = RelocationService::findById($relocationId);
        if (!$rel)                                  return 'not_found';
        if (!empty($rel['cancelled_at']))           return 'cancelled';
        if (!empty($rel['first_indexed_at']))       return 'already_indexed';
        if ((string)$rel['index_status'] === 'indexed') return 'already_indexed';
        if (trim($domain) === '')                   return 'empty_domain';
        if (self::pipelineCheckActive($relocationId)) return 'pipeline_active';
        return null;
    }

    /** Человекочитаемые причины пропуска — для UI и истории. */
    public static function skipMessage(string $code): string
    {
        $map = [
            'not_found'       => 'Запись переезда не найдена',
            'cancelled'       => 'Учёт переезда отменён — проверка не выполняется',
            'already_indexed' => 'Домен уже зафиксирован в индексе — повторная проверка не нужна',
            'empty_domain'    => 'Новый домен ещё не зафиксирован',
            'pipeline_active' => 'Проверка уже выполняется внутри джобы (final_monitoring)',
            'lock_busy'       => 'Проверка этого домена уже выполняется другим процессом',
            'low_balance'     => 'Недостаточный баланс XMLStock — запрос не отправлен',
        ];
        return $map[$code] ?? $code;
    }

    /**
     * Выполнить проверку индекса для записи переезда.
     *
     * @param string $trigger manual|cron
     * @return array ['ok','skipped','skip_reason','status','message','indexed','pages']
     */
    public static function check(
        int $relocationId, string $domain, string $trigger,
        ?string $user = null, bool $skipBalanceCheck = false
    ): array {
        $domain = trim($domain);

        // 1) Серверные предусловия ДО любых платных действий.
        $deny = self::precheck($relocationId, $domain);
        if ($deny !== null) {
            RelocationService::recordCheck($relocationId, $trigger, [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'error' => $deny, 'message' => self::skipMessage($deny),
            ], $user);
            // Запроса не было → index_checked_at не двигаем.
            return [
                'ok' => false, 'skipped' => true, 'skip_reason' => $deny,
                'status' => 'skipped', 'message' => self::skipMessage($deny),
                'indexed' => false, 'pages' => 0,
            ];
        }

        // 2) Общий лок по домену — один на pipeline / manual / cron.
        if (!self::acquireLock($domain, self::LOCK_TIMEOUT_SEC)) {
            RelocationService::recordCheck($relocationId, $trigger, [
                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                'error' => 'lock_busy', 'message' => self::skipMessage('lock_busy'),
            ], $user);
            return [
                'ok' => false, 'skipped' => true, 'skip_reason' => 'lock_busy',
                'status' => 'skipped', 'message' => self::skipMessage('lock_busy'),
                'indexed' => false, 'pages' => 0,
            ];
        }

        try {
            // 3) Состояние могло измениться, пока мы ждали лок (другой процесс
            //    успел выполнить проверку и зафиксировать индекс). Перечитываем.
            $deny2 = self::precheck($relocationId, $domain);
            if ($deny2 !== null) {
                RelocationService::recordCheck($relocationId, $trigger, [
                    'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                    'error' => $deny2, 'message' => self::skipMessage($deny2) . ' (обнаружено после захвата лока)',
                ], $user);
                return [
                    'ok' => false, 'skipped' => true, 'skip_reason' => $deny2,
                    'status' => 'skipped', 'message' => self::skipMessage($deny2),
                    'indexed' => false, 'pages' => 0,
                ];
            }

            // H6: низкий баланс ОСТАНАВЛИВАЕТ запрос, а не просто предупреждает.
            // $skipBalance=true передаётся из cron: там баланс проверяется один раз
            // на весь batch, а не перед каждым доменом.
            if (!$skipBalanceCheck) {
                try {
                    if (class_exists('BalanceCheckService')) {
                        $br = (new BalanceCheckService())->checkOne('xmlstock', 'relocation_index_check', 'default');
                        if (!empty($br['ok']) && ($br['status'] ?? '') === 'low') {
                            RelocationService::recordCheck($relocationId, $trigger, [
                                'ok' => false, 'indexed' => false, 'pages_indexed' => 0,
                                'error' => 'low_balance',
                                'message' => 'Баланс XMLStock ниже порога — запрос не отправлен',
                            ], $user);
                            // Запроса не было → index_checked_at не двигаем.
                            return [
                                'ok' => false, 'skipped' => true, 'skip_reason' => 'low_balance',
                                'status' => 'skipped', 'message' => self::skipMessage('low_balance'),
                                'indexed' => false, 'pages' => 0,
                            ];
                        }
                    }
                } catch (\Throwable $e) {
                    // недоступность проверки баланса не должна блокировать работу
                }
            }
            $balanceWarning = null;

            // --- Запрос к XMLStock ТОЛЬКО через central service (§12, reserve-before-HTTP). ---
            $jr = DB::pdo()->prepare("SELECT job_id, site_id FROM site_relocations WHERE id=?");
            $jr->execute([$relocationId]);
            $rr = $jr->fetch(PDO::FETCH_ASSOC) ?: [];
            $exec = (new XmlStockRequestService())->execute(new XmlStockRequestContext(
                'final_monitoring', $domain,
                isset($rr['job_id']) ? (int)$rr['job_id'] : null,
                isset($rr['site_id']) && $rr['site_id'] !== null ? (int)$rr['site_id'] : null,
                null, null, null, 'cron'));
            if (!empty($exec['ok']) || !empty($exec['replayed'])) {
                $result = (array)($exec['result'] ?? []);
            } else {
                $result = ['ok' => false, 'indexed' => false, 'pages_indexed' => 0, 'method' => 'xmlstock',
                           'error' => (string)($exec['error'] ?? 'usage_unavailable'), 'message' => 'xmlstock ledger unavailable'];
            }

            $ok      = !empty($result['ok']);
            $indexed = !empty($result['indexed']);
            $pages   = (int)($result['pages_indexed'] ?? 0);

            // Запрос БЫЛ отправлен (или как минимум попытка выполнена и лимит
            // потрачен) — значит index_checked_at обновляем.
            RelocationService::recordCheck($relocationId, $trigger, [
                'ok'            => $ok,
                'indexed'       => $indexed,
                'pages_indexed' => $pages,
                'error'         => (string)($result['error'] ?? ''),
                'message'       => (string)($result['message'] ?? ''),
            ], $user);

            if (!$ok) {
                RelocationService::updateIndexState(
                    $relocationId, 'check_error',
                    (string)($result['message'] ?? 'XMLStock error'), true
                );
                return [
                    'ok' => false, 'skipped' => false, 'status' => 'check_error',
                    'message' => (string)($result['message'] ?? 'Ошибка XMLStock'),
                    'indexed' => false, 'pages' => 0,
                ];
            }

            if ($indexed) {
                // Источник гарантированно XMLStock — можно фиксировать дату.
                RelocationService::markFirstIndexed($relocationId);
                RelocationService::updateIndexState($relocationId, 'indexed', null, true);
                return [
                    'ok' => true, 'skipped' => false, 'status' => 'indexed',
                    'message' => 'В индексе, страниц: ' . $pages
                        . ($balanceWarning ? ' (' . $balanceWarning . ')' : ''),
                    'indexed' => true, 'pages' => $pages,
                ];
            }

            RelocationService::updateIndexState($relocationId, 'not_indexed', null, true);
            return [
                'ok' => true, 'skipped' => false, 'status' => 'not_indexed',
                'message' => 'Пока не в индексе'
                    . ($balanceWarning ? ' (' . $balanceWarning . ')' : ''),
                'indexed' => false, 'pages' => 0,
            ];

        } catch (\Throwable $e) {
            return self::fail($relocationId, $trigger, 'exception', $e->getMessage(), $user);

        } finally {
            self::releaseLock($domain);
        }
    }

    /**
     * Техническая ошибка до/во время запроса: пишем в историю и в статус.
     */
    private static function fail(
        int $relocationId, string $trigger, string $code, string $message, ?string $user = null
    ): array {
        RelocationService::recordCheck($relocationId, $trigger, [
            'ok'            => false,
            'indexed'       => false,
            'pages_indexed' => 0,
            'error'         => $code,
            'message'       => $message,
        ], $user);

        // Запрос фактически не ушёл — index_checked_at не двигаем,
        // чтобы не отложить реальную проверку.
        RelocationService::updateIndexState($relocationId, 'check_error', $message, false);

        return [
            'ok' => false, 'skipped' => false, 'status' => 'check_error',
            'message' => $message, 'indexed' => false, 'pages' => 0,
        ];
    }

    /**
     * v22.3: шлюз для pipeline — вызывается ПОСЛЕ захвата общего лока.
     *
     * Закрывает две дыры:
     *
     * 1) Гонка. Пока pipeline ждал лок (до 5 секунд), ручная или фоновая
     *    проверка могла завершиться и зафиксировать индекс. Без повторной
     *    проверки состояния pipeline отправлял второй платный запрос.
     *    Здесь состояние перечитывается уже под локом.
     *
     * 2) Баланс. Остановка по низкому балансу жила только в check(), а
     *    final_monitoring вызывает IndexCheckOrchestrator напрямую — и при
     *    нулевом балансе активные move-джобы продолжали тратить XMLStock.
     *
     * Отдельно: после первого подтверждения индекса продолжать опрашивать
     * XMLStock смысла нет — для move-режимов индекс не входит в критерий
     * завершения (успех = подтверждение главного зеркала).
     *
     * ВАЖНО: pipeline_active здесь НЕ проверяется — вызывающая сторона и есть
     * этот pipeline.
     *
     * @return array ['proceed'=>bool, 'reason'=>string, 'message'=>string]
     */
    public static function pipelineIndexGate(int $jobId, string $domain): array
    {
        try {
            $rel = RelocationService::findByJobId($jobId);
            if (!$rel) {
                // refresh-джоба: записи переезда нет, ограничения раздела не применяются
                return ['proceed' => true, 'reason' => '', 'message' => ''];
            }

            if (trim($domain) === '') {
                return ['proceed' => false, 'reason' => 'empty_domain',
                        'message' => self::skipMessage('empty_domain')];
            }
            if (!empty($rel['cancelled_at'])) {
                return ['proceed' => false, 'reason' => 'cancelled',
                        'message' => self::skipMessage('cancelled')];
            }
            if (!empty($rel['first_indexed_at']) || (string)$rel['index_status'] === 'indexed') {
                return ['proceed' => false, 'reason' => 'already_indexed',
                        'message' => self::skipMessage('already_indexed')];
            }

            // Баланс — один общий предохранитель для всех источников.
            try {
                if (class_exists('BalanceCheckService')) {
                    $br = (new BalanceCheckService())->checkOne('xmlstock', 'final_monitoring_index', 'default');
                    if (!empty($br['ok']) && ($br['status'] ?? '') === 'low') {
                        return ['proceed' => false, 'reason' => 'low_balance',
                                'message' => self::skipMessage('low_balance')];
                    }
                }
            } catch (\Throwable $e) {
                // недоступность проверки баланса не должна блокировать пайплайн
            }

            return ['proceed' => true, 'reason' => '', 'message' => ''];

        } catch (\Throwable $e) {
            error_log('RelocationIndexChecker::pipelineIndexGate job=' . $jobId . ': ' . $e->getMessage());
            return ['proceed' => true, 'reason' => '', 'message' => ''];
        }
    }

    /**
     * Применить к переезду результат встроенной проверки из final_monitoring.
     *
     * Вызывается из пайплайна — БЕЗ дополнительного запроса к XMLStock
     * (результат уже получен стадией, повторный запрос был бы двойной тратой
     * платного лимита).
     *
     * Строгое правило источника: менять index_status и писать first_indexed_at
     * можно ТОЛЬКО когда primary_method === 'xmlstock'. Оркестратор возвращает
     * это значение исключительно при успешном ответе XMLStock (обе его ветки
     * требуют ok=true), поэтому оно является доказательством источника.
     * Результат webmaster_* или пустой primary_method → для раздела это
     * check_error, даже если пайплайн по нему принял решение.
     *
     * @param array $indexCheck результат IndexCheckOrchestrator::checkIndexed()
     */
    public static function applyPipelineResult(int $jobId, array $indexCheck): void
    {
        try {
            $rel = RelocationService::findByJobId($jobId);
            if (!$rel) return; // refresh-джобы записи переезда не имеют

            $relocationId = (int)$rel['id'];
            $method = (string)($indexCheck['primary_method'] ?? '');
            $pages  = (int)($indexCheck['pages_indexed'] ?? 0);

            // ok берём из methods_tried: верхнеуровневый ответ оркестратора
            // поля 'ok' не содержит.
            $xmlOk = null;
            $xmlMessage = (string)($indexCheck['message'] ?? '');
            $xmlError = '';
            foreach ((array)($indexCheck['methods_tried'] ?? []) as $tried) {
                if ((string)($tried['method'] ?? '') === 'xmlstock') {
                    $xmlOk = !empty($tried['ok']);
                    if (isset($tried['message'])) $xmlMessage = (string)$tried['message'];
                    if (isset($tried['error']))   $xmlError   = (string)$tried['error'];
                    break;
                }
            }

            $isXmlStock = ($method === 'xmlstock');
            $indexed = $isXmlStock && $pages >= 1;

            RelocationService::recordCheck($relocationId, 'pipeline', [
                'ok'            => $isXmlStock ? true : (bool)$xmlOk,
                'indexed'       => $indexed,
                'pages_indexed' => $indexed ? $pages : 0,
                'error'         => $isXmlStock ? '' : ($xmlError !== '' ? $xmlError : 'not_xmlstock'),
                'message'       => $isXmlStock
                    ? $xmlMessage
                    : ('источник результата: ' . ($method !== '' ? $method : 'нет') . '; ' . $xmlMessage),
            ]);

            if (!$isXmlStock) {
                // Вебмастер-фолбэк или отсутствие результата — статус раздела
                // не переводим в indexed/not_indexed.
                //
                // v22.3: index_checked_at обновляем ТОЛЬКО если запрос к XMLStock
                // действительно отправлялся. Если XMLStock выключен или не настроен,
                // оркестратор мог вообще его не звать — отметка о проверке отложила
                // бы собственный cron-поллинг на сутки без единого платного запроса.
                $xmlRequestSent = ($xmlOk !== null);
                RelocationService::updateIndexState(
                    $relocationId, 'check_error',
                    'XMLStock не дал результата (источник: ' . ($method !== '' ? $method : 'нет') . ')',
                    $xmlRequestSent
                );
                return;
            }

            if ($indexed) {
                RelocationService::markFirstIndexed($relocationId);
                RelocationService::updateIndexState($relocationId, 'indexed', null, true);
                // §6: ban-monitor armed на первом XMLStock-подтверждении переезда
                // (move_indexed/final_monitoring). Идемпотентно (uq source_job_id+domain).
                try {
                    $j = DB::pdo()->prepare("SELECT site_id, new_domain FROM refresh_jobs WHERE id=?");
                    $j->execute([$jobId]);
                    $jr = $j->fetch(PDO::FETCH_ASSOC) ?: [];
                    if (!empty($jr['new_domain'])) {
                        (new BanMonitorService())->armFromXmlStockIndexed(
                            (int)$jobId,
                            isset($jr['site_id']) && $jr['site_id'] !== null ? (int)$jr['site_id'] : null,
                            (string)$jr['new_domain'],
                            new \DateTimeImmutable('now', new \DateTimeZone('UTC')),
                            $pages
                        );
                    }
                } catch (\Throwable $e) {
                    error_log('[ban-monitor arm/final_monitoring] ' . $e->getMessage());
                }
            } else {
                RelocationService::updateIndexState($relocationId, 'not_indexed', null, true);
            }
        } catch (\Throwable $e) {
            // Учёт переездов не должен ронять стадию пайплайна, но и молча
            // исчезать он не имеет права: при тихом глушении раздел просто
            // перестал бы обновляться, и причину пришлось бы искать вручную.
            error_log('RelocationIndexChecker::applyPipelineResult job=' . $jobId
                . ' failed: ' . $e->getMessage());
        }
    }

    /**
     * Идёт ли сейчас встроенная XMLStock-проверка внутри final_monitoring.
     * Условие согласовано: stage='final_monitoring' и
     * stage_status IN ('pending','ok','running').
     */
    public static function pipelineCheckActive(int $relocationId): bool
    {
        try {
            $st = DB::pdo()->prepare(
                "SELECT 1 FROM site_relocations r
                   JOIN refresh_jobs j ON j.id = r.job_id
                  WHERE r.id = ?
                    AND j.stage = 'final_monitoring'
                    AND j.stage_status IN ('pending','ok','running')
                  LIMIT 1"
            );
            $st->execute([$relocationId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Кандидаты для суточного фонового поллинга.
     *
     * Отбираются переезды, для которых СЕЙЧАС НЕ выполняется встроенная
     * XMLStock-проверка внутри final_monitoring. Встроенная проверка активна
     * при stage='final_monitoring' и stage_status IN ('pending','ok','running')
     * — именно эти джобы забирает cron (CronController: выборка кандидатов),
     * а максимальный интервал adaptive backoff равен суткам, то есть совпадает
     * с нашей частотой и разрыва в покрытии не создаёт.
     *
     * Не активна: awaiting_user, failed, любая другая стадия.
     */
    public static function pollCandidates(int $intervalHours = 24, int $limit = 25): array
    {
        // H2: LEFT JOIN — завершённую джобу разрешено удалять, а запись переезда
        // продолжает жить за счёт snapshot_json. С INNER JOIN такая запись
        // навсегда выпадала бы из поллинга, хотя индекс ещё не подтверждён.
        // Режим и домен берём из джобы, а при её отсутствии — из snapshot.
        $sql =
            "SELECT r.id, r.job_id,
                    COALESCE(NULLIF(j.new_domain, ''),
                             JSON_UNQUOTE(JSON_EXTRACT(r.snapshot_json, '$.new_domain'))) AS new_domain,
                    j.stage, j.stage_status
               FROM site_relocations r
               LEFT JOIN refresh_jobs j ON j.id = r.job_id
               LEFT JOIN site_webmaster_links swl
                      ON swl.site_id = j.site_id
                     AND swl.domain = j.new_domain COLLATE utf8mb4_unicode_ci
              WHERE COALESCE(j.mode,
                             JSON_UNQUOTE(JSON_EXTRACT(r.snapshot_json, '$.mode')))
                    IN ('move_indexed','move_simple')
                AND r.cancelled_at     IS NULL
                AND r.first_indexed_at IS NULL
                -- v24.2 (B5): закрытая джоба (cancelled/superseded) не должна
                -- расходовать платный XMLStock-лимит. Лайфцикл-сервис отменяет
                -- запись переезда сам, но записи, закрытые до патча или в обход
                -- сервиса, тоже обязаны выпасть из поллинга. Удалённая джоба
                -- (j.id IS NULL) продолжает поллиться по snapshot — как раньше.
                AND (j.id IS NULL OR j.stage NOT IN ('cancelled','superseded'))
                AND COALESCE(NULLIF(j.new_domain, ''),
                             JSON_UNQUOTE(JSON_EXTRACT(r.snapshot_json, '$.new_domain')), '') <> ''
                AND NOT (COALESCE(j.stage, '') = 'final_monitoring'
                         AND COALESCE(j.stage_status, '') IN ('pending','ok','running'))
                AND (r.index_checked_at IS NULL
                     OR r.index_checked_at < DATE_SUB(NOW(), INTERVAL ? HOUR))
                -- COALESCE обязателен: при отсутствии строки в site_webmaster_links
                -- сравнение с NULL даёт NULL, а NOT(NULL) — тоже NULL, и запись
                -- молча выпадала бы из выборки (поллинг не брал бы никого).
                AND NOT (COALESCE(swl.last_index_check_method, '') = 'xmlstock'
                         AND swl.last_index_check_at > DATE_SUB(NOW(), INTERVAL ? HOUR))
              ORDER BY r.index_checked_at IS NOT NULL, r.index_checked_at ASC, r.id ASC
              LIMIT " . max(1, min(200, $limit));

        $st = DB::pdo()->prepare($sql);
        $st->execute([$intervalHours, $intervalHours]);
        return $st->fetchAll() ?: [];
    }
}
