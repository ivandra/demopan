<?php

/**
 * AwaitingActionService — джобы, ожидающие действия оператора.
 *
 * Задача узкая и намеренно безопасная: логика блокировки создания джоб
 * (RefreshJobController) сама по себе не меняется — с v24 к терминальным
 * стадиям добавлены cancelled и superseded, закрываемые явным действием оператора.
 * Сервис только показывает такие джобы и напоминает о них.
 *
 * Почему это нужно: статус stage_status='awaiting_user' не входит в
 * ('done','failed'), поэтому сайт остаётся заблокированным для новых джоб
 * бессрочно. На боевой панели так висело 7 сайтов, старейший — больше двух
 * месяцев, и никакого штатного способа их увидеть в списке не было.
 *
 * Момент входа в ожидание берём из refresh_jobs.updated_at: джоба в
 * awaiting_user больше не меняется, поэтому её последнее обновление и есть
 * начало простоя.
 *
 * Совместимо с PHP 7.4.
 */
class AwaitingActionService
{
    /** Порог, после которого шлём напоминание в Telegram (суток). */
    const NOTIFY_AFTER_DAYS = 3;

    /** Ключ настройки с датой последнего напоминания. */
    const LAST_NOTIFY_KEY = 'jobs.awaiting_last_notify_at';

    /**
     * Описание ожидаемого действия для стадии.
     *
     * Тексты составлены по фактическим точкам перехода в awaiting_user
     * в RefreshOrchestrator (13 обработчиков, 26 мест).
     *
     * @return array ['action' => что сделать, 'hint' => пояснение]
     */
    public static function describeExpectedAction(string $stage, string $stageError = ''): array
    {
        $err = mb_strtolower($stageError);

        switch ($stage) {
            case 'old_delurl_notify':
                return [
                    'action' => 'Удалить старые URL из поиска и подтвердить',
                    'hint'   => 'Проверьте в Яндекс.Вебмастере, что страницы старого домена '
                              . 'удалены из поиска, затем нажмите подтверждение в карточке джобы.',
                ];

            case 'index_watching':
                // Основной случай — авто-стоп по таймауту опроса.
                if (mb_strpos($err, 'авто-стоп') !== false || mb_strpos($err, 'без результата') !== false) {
                    return [
                        'action' => 'Решить, что делать с неиндексируемым доменом',
                        'hint'   => 'Опрос остановлен автоматически: домен не появился в индексе '
                                  . 'дольше порога, дальнейшие запросы XMLStock тратили бы лимит впустую. '
                                  . 'Подтверждение удаления URL здесь НЕ применяется — нужно проверить '
                                  . 'доступность и индексируемость сайта либо закрыть джобу.',
                    ];
                }
                return [
                    'action' => 'Проверить состояние индексации',
                    'hint'   => 'Ожидание появления домена в индексе прервано. Проверьте карточку джобы.',
                ];

            case 'final_monitoring':
                if (mb_strpos($err, 'api error') !== false) {
                    return [
                        'action' => 'Проверить доступ к API Яндекс.Вебмастера',
                        'hint'   => 'Пять ошибок API подряд. Проверьте токен аккаунта и доступность сервиса.',
                    ];
                }
                return [
                    'action' => 'Проверить статус главного зеркала',
                    'hint'   => 'Яндекс не подтвердил смену главного зеркала либо вернул неожиданный статус.',
                ];

            case 'move_poll_status':
                return [
                    'action' => 'Проверить заявку на переезд в Вебмастере',
                    'hint'   => 'Опрос статуса заявки прерван (ошибки API или отказ). '
                              . 'Откройте заявку в Яндекс.Вебмастере.',
                ];

            case 'move_submit_request':
                return [
                    'action' => 'Подать заявку на переезд вручную',
                    'hint'   => 'Автоматическая подача не выполнена — подайте заявку на смену '
                              . 'главного зеркала в Яндекс.Вебмастере.',
                ];

            case 'wm_verified':
                return [
                    'action' => 'Подтвердить права на домен в Вебмастере',
                    'hint'   => 'Не удалось загрузить или проверить файл подтверждения. '
                              . 'Проверьте доступность файла верификации на сайте.',
                ];

            case 'wm_added':
            case 'wm_account_resolve':
                return [
                    'action' => 'Проверить аккаунт Яндекс.Вебмастера',
                    'hint'   => 'Хост не добавлен или аккаунт не определён. Проверьте привязку аккаунта.',
                ];

            case 'move_htaccess_redirect':
                return [
                    'action' => 'Настроить FTP и проверить .htaccess',
                    'hint'   => 'FTP не настроен либо запись правила редиректа не выполнена.',
                ];

            case 'redirect_enable':
                return [
                    'action' => 'Проверить файлы сайта: остались маркеры REFRESH-DISABLED',
                    'hint'   => 'После включения редиректа в файлах остались служебные маркеры. '
                              . 'Проверьте .htaccess и config.php по FTP.',
                ];

            case 'verify_replacement':
                return [
                    'action' => 'Проверить замены в файлах сайта',
                    'hint'   => 'Проверка после замены не прошла. Сверьте .htaccess и index.php по FTP.',
                ];

            case 'ssl_le_polling':
                return [
                    'action' => 'Проверить выпуск Let\'s Encrypt',
                    'hint'   => 'Сертификат не выпущен. Проверьте DNS и состояние домена в FastPanel.',
                ];

            default:
                return [
                    'action' => 'Открыть карточку джобы',
                    'hint'   => 'Джоба ожидает действия оператора. Причина указана в логе стадии.',
                ];
        }
    }

    /**
     * Джобы, ожидающие действия оператора.
     *
     * @param int|null $minDays если задано — только те, кто ждёт дольше N суток
     */
    public static function listAwaiting(?int $minDays = null): array
    {
        $sql = "SELECT j.*, s.current_domain,
                       TIMESTAMPDIFF(SECOND, j.updated_at, NOW()) AS waiting_sec
                  FROM refresh_jobs j
                  LEFT JOIN sites_managed s ON s.id = j.site_id
                 WHERE j.stage_status = 'awaiting_user'
                   AND j.stage NOT IN ('done','failed','cancelled','superseded')";
        $args = [];
        if ($minDays !== null) {
            $sql .= " AND j.updated_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
            $args[] = max(0, $minDays);
        }
        $sql .= " ORDER BY j.updated_at ASC";

        try {
            $st = DB::pdo()->prepare($sql);
            $st->execute($args);
            $rows = $st->fetchAll() ?: [];
        } catch (\Throwable $e) {
            error_log('AwaitingActionService::listAwaiting: ' . $e->getMessage());
            return [];
        }

        foreach ($rows as $i => $r) {
            $d = self::describeExpectedAction((string)$r['stage'], (string)($r['stage_error'] ?? ''));
            $rows[$i]['expected_action'] = $d['action'];
            $rows[$i]['expected_hint']   = $d['hint'];
            $rows[$i]['waiting_human']   = self::humanDuration((int)$r['waiting_sec']);
            $rows[$i]['waiting_days']    = intdiv((int)$r['waiting_sec'], 86400);
        }
        return $rows;
    }

    /** Счётчик для вкладки фильтра. */
    public static function countAwaiting(): int
    {
        try {
            $st = DB::pdo()->query(
                "SELECT COUNT(*) FROM refresh_jobs
                  WHERE stage_status = 'awaiting_user' AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            return (int)$st->fetchColumn();
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * Напоминание в Telegram о джобах, висящих дольше порога.
     *
     * Шлётся не чаще раза в сутки, чтобы не спамить.
     *
     * @return array сводка для лога cron
     */
    public static function notifyLongWaiting(?int $days = null): array
    {
        $days = $days ?? self::NOTIFY_AFTER_DAYS;

        try {
            $lastRaw = AppSettings::getRaw(self::LAST_NOTIFY_KEY, '');
            if ($lastRaw !== '' && (time() - strtotime($lastRaw)) < 86400) {
                return ['sent' => false, 'reason' => 'already_notified_today'];
            }
        } catch (\Throwable $e) {
            // отсутствие настроек не должно мешать напоминанию
        }

        $rows = self::listAwaiting($days);
        if (!$rows) {
            return ['sent' => false, 'reason' => 'nothing_to_report'];
        }

        $lines = [];
        $lines[] = '⏳ Джобы ждут действия оператора дольше ' . $days . ' сут.: ' . count($rows);
        $lines[] = '';
        foreach (array_slice($rows, 0, 15) as $r) {
            $site = (string)($r['current_domain'] ?: $r['old_domain']);
            $lines[] = '#' . (int)$r['id'] . ' · ' . $site;
            // Показываем и сам переход: оператору важно понимать, что именно застряло.
            $old = (string)($r['old_domain'] ?? '');
            $new = (string)($r['new_domain'] ?? '');
            if ($old !== '' && $new !== '' && $old !== $site) {
                $lines[] = '   джоба: ' . $old . ' → ' . $new;
            } elseif ($old !== '' && $new !== '') {
                $lines[] = '   джоба: ' . $old . ' → ' . $new;
            }
            $lines[] = '   стадия: ' . (string)$r['stage'] . ' · ждёт ' . (string)$r['waiting_human'];
            $lines[] = '   нужно: ' . (string)$r['expected_action'];
        }
        if (count($rows) > 15) {
            $lines[] = '';
            $lines[] = '…и ещё ' . (count($rows) - 15);
        }
        $lines[] = '';
        $lines[] = 'Пока джоба в этом статусе, для её сайта нельзя создать новую джобу.';

        try {
            $tg = new TelegramService();
            $ok = $tg->send(implode("\n", $lines));
        } catch (\Throwable $e) {
            error_log('AwaitingActionService::notifyLongWaiting: ' . $e->getMessage());
            return ['sent' => false, 'reason' => 'send_failed'];
        }

        if ($ok) {
            try {
                AppSettings::setRaw(self::LAST_NOTIFY_KEY, date('Y-m-d H:i:s'));
            } catch (\Throwable $e) {
                // не критично
            }
        }

        return ['sent' => (bool)$ok, 'count' => count($rows), 'days' => $days];
    }

    /** «3 дня 6 часов» / «5 часов» / «40 минут». */
    public static function humanDuration(int $sec): string
    {
        $sec  = max(0, $sec);
        $days = intdiv($sec, 86400);
        $hrs  = intdiv($sec % 86400, 3600);
        $min  = intdiv($sec % 3600, 60);

        $parts = [];
        if ($days > 0) $parts[] = $days . ' ' . self::plural($days, 'день', 'дня', 'дней');
        if ($hrs  > 0) $parts[] = $hrs  . ' ' . self::plural($hrs, 'час', 'часа', 'часов');
        if (!$parts && $min > 0) $parts[] = $min . ' ' . self::plural($min, 'минуту', 'минуты', 'минут');
        if (!$parts) $parts[] = 'меньше минуты';

        return implode(' ', array_slice($parts, 0, 2));
    }

    private static function plural(int $n, string $one, string $few, string $many): string
    {
        $n = abs($n) % 100;
        if ($n >= 11 && $n <= 14) return $many;
        $n %= 10;
        if ($n === 1) return $one;
        if ($n >= 2 && $n <= 4) return $few;
        return $many;
    }
}
