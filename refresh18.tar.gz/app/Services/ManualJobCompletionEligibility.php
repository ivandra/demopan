<?php
/**
 * HOTFIX «ручное завершение технически готовой джобы» — eligibility gate.
 *
 * Backend — источник истины. Разрешает завершение ТОЛЬКО когда все технические стадии
 * пройдены и остались лишь финальные read-only/polling стадии (индексация, повторный
 * обход, поисковая видимость). Технические ошибки этой кнопкой скрыть нельзя.
 * Чистая оценка массива job (+ artifacts_json); без внешних вызовов и мутаций.
 */
final class ManualJobCompletionEligibility
{
    /**
     * Реальные ID из RefreshOrchestrator::STAGES_ORDER — финальные polling/monitoring/notify.
     * move_submit_request НЕ входит: на нём заявка на переезд ещё НЕ подана (её нельзя пропускать).
     */
    private const MANUALLY_SKIPPABLE_FINAL_STAGES = [
        'index_watching',    // refresh: ожидание индексации (сценарий #199)
        'final_monitoring',  // move: объединённый финальный мониторинг (после подачи заявки)
        'move_poll_status',  // move: polling main_mirror (заявка уже подана)
        'old_delurl_notify', // refresh: финальное TG-уведомление + awaiting_user
    ];

    private const TERMINAL_STAGES = ['done', 'failed', 'cancelled', 'superseded'];

    /** Технические стадии, ошибка/awaiting по которым запрещает завершение. */
    private const TECHNICAL_STAGES = [
        'domain_purchasing','aliases_added','ssl_self_signed_first','redirect_disable','analyze_site',
        'config_replaced','verify_replacement','ssl_le_polling','update_classes_call','redirect_enable',
        'move_htaccess_redirect','trusted_ssl_gate','wm_account_resolve','wm_added','wm_verified',
        'wm_recrawl','wm_sitemap','wm_robots',
    ];

    private const BLOCKING_ARTIFACT_MARKERS = [
        'rollback_required','partial_apply','partial_state','file_repair_required',
        'redirect_enable_failed','file_state_mismatch','verification_failed',
    ];

    /** Явные небезопасные состояния technical stage_results. */
    private const BLOCKING_TECHNICAL_RESULTS = [
        'failed','error','awaiting_user','partial','partial_apply','partial_state',
        'rollback_required','blocked','needs_review','file_repair_required',
    ];

    public function skippableStages(): array { return self::MANUALLY_SKIPPABLE_FINAL_STAGES; }

    /**
     * @param array $job
     * @param array|null $pipeline реальный pipeline джобы (RefreshOrchestrator::pipelineStagesFor).
     *        Нужен, чтобы список пропущенных стадий соответствовал режиму (refresh/move).
     * @return array{allowed:bool,reasons:string[],current_stage:string,
     *               remaining_stages:string[],skipped_stages:string[]}
     */
    public function evaluate(array $job, ?array $pipeline = null): array
    {
        $stage  = (string)($job['stage'] ?? '');
        $status = (string)($job['stage_status'] ?? '');
        $reasons = [];

        if (in_array($stage, self::TERMINAL_STAGES, true))                         $reasons[] = 'job_terminal';
        if (!in_array($stage, self::MANUALLY_SKIPPABLE_FINAL_STAGES, true))        $reasons[] = 'stage_not_final_pollable';
        if ($status === 'running')                                                 $reasons[] = 'stage_running';
        if ($status === 'failed')                                                  $reasons[] = 'blocking_stage_failure';

        // (4) явные технические ошибки — скрыть нельзя
        if (trim((string)($job['new_domain'] ?? '')) === '')                       $reasons[] = 'new_domain_missing';
        if (trim((string)($job['stage_error'] ?? '')) !== '')                      $reasons[] = 'stage_error_present';

        $artifacts = $this->decodeArtifacts($job);
        // stage_results: любая ТЕХНИЧЕСКАЯ стадия в состоянии failed → блок (redirect_enable, robots, config, ssl, …)
        $sr = isset($artifacts['stage_results']) && is_array($artifacts['stage_results']) ? $artifacts['stage_results'] : [];
        foreach ($sr as $st => $res) {
            if (!in_array((string)$st, self::TECHNICAL_STAGES, true)) continue;
            $state = $this->stageResultState($res);
            if (in_array($state, self::BLOCKING_TECHNICAL_RESULTS, true)) {
                $reasons[] = 'technical_stage_blocked:' . $st . ':' . $state;
            }
        }
        foreach ($this->findBlockingMarkers($artifacts) as $m)  $reasons[] = 'blocking_artifact:' . $m;
        foreach ($this->findTechnicalAwaiting($artifacts) as $a) $reasons[] = 'awaiting_user:' . $a;

        $skipped = $this->computeSkipped($stage, $pipeline);
        return [
            'allowed'          => $reasons === [],
            'reasons'          => array_values(array_unique($reasons)),
            'current_stage'    => $stage,
            'remaining_stages' => $skipped,
            'skipped_stages'   => $reasons === [] ? $skipped : [],
        ];
    }

    /**
     * Пропущенные стадии = текущая + все последующие ИЗ РЕАЛЬНОГО pipeline джобы (без 'done').
     * Это исключает кросс-режимную ошибку (move-стадии для refresh и наоборот).
     */
    private function computeSkipped(string $stage, ?array $pipeline): array
    {
        $allowed = self::MANUALLY_SKIPPABLE_FINAL_STAGES;

        if (is_array($pipeline) && $pipeline !== []) {
            $idx = array_search($stage, $pipeline, true);
            if ($idx !== false) {
                // Берём только реально существующие в pipeline финальные стадии.
                // Никакая будущая техническая стадия не может быть пропущена этой кнопкой.
                $tail = array_slice($pipeline, $idx);
                return array_values(array_filter(
                    $tail,
                    static fn($s) => in_array((string)$s, $allowed, true)
                ));
            }

            // Legacy-стадии могут отсутствовать в новом pipeline режима.
            if ($stage === 'move_poll_status') {
                $out = ['move_poll_status'];
                if (in_array('final_monitoring', $pipeline, true)) $out[] = 'final_monitoring';
                return $out;
            }
            if ($stage === 'index_watching') {
                $out = ['index_watching'];
                if (in_array('old_delurl_notify', $pipeline, true)) {
                    $out[] = 'old_delurl_notify';
                } elseif (in_array('final_monitoring', $pipeline, true)) {
                    $out[] = 'final_monitoring';
                }
                return $out;
            }
        }

        // Fail-closed fallback: пропускается только текущая явно разрешённая стадия.
        return in_array($stage, $allowed, true) ? [$stage] : [];
    }

    private function stageResultState($result): string
    {
        if (is_string($result) || is_numeric($result)) {
            return strtolower(trim((string)$result));
        }
        if (is_array($result)) {
            foreach (['status', 'state', 'outcome', 'result'] as $key) {
                if (isset($result[$key]) && (is_string($result[$key]) || is_numeric($result[$key]))) {
                    return strtolower(trim((string)$result[$key]));
                }
            }
        }
        return '';
    }

    private function decodeArtifacts(array $job): array
    {
        $raw = $job['artifacts_json'] ?? null;
        if (!is_string($raw) || $raw === '') return [];
        $d = json_decode($raw, true);
        return is_array($d) ? $d : [];
    }
    private function findBlockingMarkers(array $artifacts): array
    {
        $hits = [];
        array_walk_recursive($artifacts, function ($v, $k) use (&$hits) {
            $key = strtolower((string)$k);
            foreach (self::BLOCKING_ARTIFACT_MARKERS as $m) if ($key === $m && !empty($v)) $hits[] = $m;
        });
        return array_values(array_unique($hits));
    }
    private function findTechnicalAwaiting(array $artifacts): array
    {
        $tech = ['ftp', 'config', 'robots', 'redirect', 'ssl', 'alias'];
        $hits = [];
        array_walk_recursive($artifacts, function ($v, $k) use (&$hits, $tech) {
            $key = strtolower((string)$k);
            if (strpos($key, 'awaiting') !== false && !empty($v)) {
                foreach ($tech as $t) if (strpos($key, $t) !== false) $hits[] = $t;
            }
        });
        return array_values(array_unique($hits));
    }
}
