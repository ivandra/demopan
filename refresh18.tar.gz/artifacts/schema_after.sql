-- schema_after.sql — схема ban-monitoring после миграций 036+037 (PATCH_2)

-- ==== ban_monitoring_settings ====

DROP TABLE IF EXISTS `ban_monitoring_settings`;
CREATE TABLE `ban_monitoring_settings` (
  `id` tinyint(3) unsigned NOT NULL,
  `enrollment_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `processing_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `activation_generation` int(10) unsigned NOT NULL DEFAULT 0,
  `activation_started_at` datetime DEFAULT NULL,
  `activation_min_job_id` bigint(20) unsigned DEFAULT NULL,
  `policy_version` int(10) unsigned NOT NULL DEFAULT 1,
  `initial_delay_minutes` int(10) unsigned NOT NULL DEFAULT 720,
  `regular_interval_minutes` int(10) unsigned NOT NULL DEFAULT 30,
  `probable_negative_count` int(10) unsigned NOT NULL DEFAULT 3,
  `confirm_interval_minutes` int(10) unsigned NOT NULL DEFAULT 10,
  `insurance_negative_count` int(10) unsigned NOT NULL DEFAULT 3,
  `insurance_interval_minutes` int(10) unsigned NOT NULL DEFAULT 10,
  `technical_error_retry_minutes` int(10) unsigned NOT NULL DEFAULT 30,
  `cron_batch_limit` int(10) unsigned NOT NULL DEFAULT 5,
  `telegram_retry_minutes` int(10) unsigned NOT NULL DEFAULT 10,
  `telegram_max_attempts` int(10) unsigned NOT NULL DEFAULT 20,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- ==== ban_monitoring_audit ====

DROP TABLE IF EXISTS `ban_monitoring_audit`;
CREATE TABLE `ban_monitoring_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(64) NOT NULL,
  `object_type` varchar(32) NOT NULL DEFAULT 'settings',
  `object_id` bigint(20) unsigned DEFAULT NULL,
  `operator` varchar(128) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `old_values` longtext DEFAULT NULL,
  `new_values` longtext DEFAULT NULL,
  `comment` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_bma_action` (`action`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- ==== ban_monitor_notifications ====

DROP TABLE IF EXISTS `ban_monitor_notifications`;
CREATE TABLE `ban_monitor_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `monitor_id` bigint(20) unsigned NOT NULL,
  `source_job_id` bigint(20) unsigned NOT NULL,
  `domain` varchar(255) NOT NULL,
  `event_key` varchar(255) NOT NULL,
  `kind` varchar(32) NOT NULL,
  `payload_json` longtext NOT NULL,
  `rendered_text` longtext NOT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'pending',
  `attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `next_attempt_at` datetime NOT NULL,
  `last_attempt_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `last_error` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ban_notification_event` (`event_key`),
  KEY `idx_ban_notification_due` (`status`,`next_attempt_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- ==== site_ban_monitors ====

DROP TABLE IF EXISTS `site_ban_monitors`;
CREATE TABLE `site_ban_monitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) unsigned DEFAULT NULL,
  `source_job_id` bigint(20) unsigned NOT NULL,
  `domain` varchar(255) NOT NULL,
  `indexed_at` datetime NOT NULL,
  `monitoring_starts_at` datetime NOT NULL,
  `next_check_at` datetime DEFAULT NULL,
  `last_check_at` datetime DEFAULT NULL,
  `last_positive_at` datetime NOT NULL,
  `last_positive_pages` int(10) unsigned NOT NULL DEFAULT 1,
  `first_negative_at` datetime DEFAULT NULL,
  `last_negative_at` datetime DEFAULT NULL,
  `state` varchar(32) NOT NULL DEFAULT 'waiting_12h',
  `negative_streak` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `insurance_checks_done` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `technical_error_count` int(10) unsigned NOT NULL DEFAULT 0,
  `last_pages_indexed` int(10) unsigned NOT NULL DEFAULT 0,
  `series_no` int(10) unsigned NOT NULL DEFAULT 0,
  `probable_notified_at` datetime DEFAULT NULL,
  `recovered_notified_at` datetime DEFAULT NULL,
  `confirmed_notified_at` datetime DEFAULT NULL,
  `telegram_retry_at` datetime DEFAULT NULL,
  `last_result_json` longtext DEFAULT NULL,
  `last_error` varchar(1000) DEFAULT NULL,
  `stopped_at` datetime DEFAULT NULL,
  `stop_reason` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `activation_generation` int(10) unsigned NOT NULL DEFAULT 0,
  `policy_version` int(10) unsigned NOT NULL DEFAULT 1,
  `policy_snapshot_json` longtext DEFAULT NULL,
  `banned_at` datetime DEFAULT NULL,
  `paused_from_state` varchar(32) DEFAULT NULL,
  `paused_next_check_at` datetime DEFAULT NULL,
  `blocked_reason` varchar(64) DEFAULT NULL,
  `blocked_notified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ban_monitor_job_domain` (`source_job_id`,`domain`),
  KEY `idx_ban_monitor_due` (`state`,`next_check_at`),
  KEY `idx_ban_monitor_domain` (`domain`),
  KEY `idx_ban_monitor_site` (`site_id`),
  KEY `idx_ban_monitor_job` (`source_job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=990078 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- ==== site_ban_monitor_checks ====

DROP TABLE IF EXISTS `site_ban_monitor_checks`;
CREATE TABLE `site_ban_monitor_checks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `monitor_id` bigint(20) unsigned NOT NULL,
  `xmlstock_request_log_id` bigint(20) unsigned DEFAULT NULL,
  `checked_at` datetime NOT NULL,
  `phase` varchar(32) NOT NULL,
  `sequence_no` tinyint(3) unsigned DEFAULT NULL,
  `series_no` int(10) unsigned NOT NULL DEFAULT 0,
  `result` varchar(24) NOT NULL,
  `pages_indexed` int(10) unsigned DEFAULT NULL,
  `xmlstock_ok` tinyint(1) NOT NULL DEFAULT 0,
  `message` varchar(1000) DEFAULT NULL,
  `error_code` varchar(128) DEFAULT NULL,
  `response_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ban_check_request` (`xmlstock_request_log_id`),
  KEY `idx_ban_checks_monitor` (`monitor_id`,`checked_at`),
  KEY `idx_ban_checks_request` (`xmlstock_request_log_id`),
  CONSTRAINT `fk_ban_checks_monitor` FOREIGN KEY (`monitor_id`) REFERENCES `site_ban_monitors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- ==== xmlstock_request_log ====

DROP TABLE IF EXISTS `xmlstock_request_log`;
CREATE TABLE `xmlstock_request_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `request_uuid` char(36) NOT NULL,
  `requested_at` datetime NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  `purpose` varchar(32) NOT NULL,
  `phase` varchar(32) DEFAULT NULL,
  `initiated_by` varchar(24) NOT NULL DEFAULT 'cron',
  `source_job_id` bigint(20) unsigned DEFAULT NULL,
  `site_id` bigint(20) unsigned DEFAULT NULL,
  `monitor_id` bigint(20) unsigned DEFAULT NULL,
  `domain` varchar(255) NOT NULL,
  `sequence_no` tinyint(3) unsigned DEFAULT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'reserved',
  `result` varchar(24) DEFAULT NULL,
  `pages_indexed` int(10) unsigned DEFAULT NULL,
  `http_code` int(11) DEFAULT NULL,
  `provider_code` varchar(64) DEFAULT NULL,
  `duration_ms` int(10) unsigned DEFAULT NULL,
  `assumed_charged` tinyint(1) NOT NULL DEFAULT 0,
  `request_cost_rub` decimal(12,4) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `response_excerpt` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `execution_state` varchar(32) NOT NULL DEFAULT 'reserved',
  `reserved_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `ambiguous_at` datetime DEFAULT NULL,
  `failed_before_http_at` datetime DEFAULT NULL,
  `normalized_result_json` longtext DEFAULT NULL,
  `transport_error` varchar(1000) DEFAULT NULL,
  `http_attempted` tinyint(1) NOT NULL DEFAULT 0,
  `replayed_from_log` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_xmlstock_request_uuid` (`request_uuid`),
  KEY `idx_xmlstock_usage_time` (`requested_at`),
  KEY `idx_xmlstock_usage_purpose` (`purpose`,`requested_at`),
  KEY `idx_xmlstock_usage_job` (`source_job_id`,`requested_at`),
  KEY `idx_xmlstock_usage_monitor` (`monitor_id`,`requested_at`),
  KEY `idx_xmlstock_usage_domain` (`domain`,`requested_at`),
  KEY `idx_xmlstock_execstate` (`requested_at`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- refresh_jobs ban-поля:
Field	Type	Null	Key	Default	Extra
ban_monitor_generation	int(10) unsigned	YES		NULL	
ban_monitor_eligible_at	datetime	YES		NULL	
