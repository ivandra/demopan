/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `refresh_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `old_domain` varchar(255) NOT NULL,
  `new_domain` varchar(255) NOT NULL DEFAULT '',
  `old_sub_id` varchar(128) NOT NULL DEFAULT '',
  `new_sub_id` varchar(128) NOT NULL DEFAULT '',
  `new_yandex_verification` varchar(64) NOT NULL DEFAULT '',
  `stage` varchar(32) NOT NULL DEFAULT 'queued',
  `stage_status` varchar(16) NOT NULL DEFAULT 'pending',
  `stage_error` text DEFAULT NULL,
  `stage_started_at` datetime DEFAULT NULL,
  `stage_finished_at` datetime DEFAULT NULL,
  `next_run_at` datetime DEFAULT NULL,
  `artifacts_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `webmaster_account_override_id` int(11) DEFAULT NULL COMMENT 'v16/v17: если задан — добавлять новый домен в этот аккаунт Webmaster (вместо same)',
  `mode` varchar(16) NOT NULL DEFAULT 'refresh' COMMENT 'v18: refresh / move_indexed / move_simple',
  `superseded_by_job_id` int(11) DEFAULT NULL COMMENT 'v24: ID новой джобы, заменившей эту (только для stage=superseded)',
  `closed_at` datetime DEFAULT NULL COMMENT 'v24: когда джоба была закрыта оператором',
  `closed_by` varchar(64) DEFAULT NULL COMMENT 'v24: логин оператора; числовых ID пользователей в панели нет',
  `closed_reason` varchar(255) DEFAULT NULL COMMENT 'v24: причина закрытия; для cancelled обязательна',
  `domain_http_initial_code` int(11) DEFAULT NULL COMMENT 'v25: исходный HTTP-код http://new/ без follow (0=нет DNS/connect, 301/302=скоро готов)',
  `domain_https_final_code` int(11) DEFAULT NULL COMMENT 'v25: финальный HTTPS-код https://new/ после ограниченного follow',
  `domain_https_ready_at` datetime DEFAULT NULL COMMENT 'v25: момент подтверждённой готовности (streak достиг порога). GATE к PHP-уникализации',
  `domain_readiness_success_streak` int(11) NOT NULL DEFAULT 0 COMMENT 'v25: подряд успешных публичных проверок HTTPS 200+SSL+probe; сбрасывается при любом сбое',
  `domain_readiness_last_checked_at` datetime DEFAULT NULL COMMENT 'v25: время последней readiness-проверки (для интервалов cron)',
  `php_uniquification_verified_at` datetime DEFAULT NULL COMMENT 'v25: PHP-уникализация применена и подтверждена (php -l + HTTPS smoke). GATE к Вебмастеру',
  `domain_technical_ready_at` datetime DEFAULT NULL COMMENT 'v25.1: момент технической доступности (301→HTTPS/HTTPS 2xx-3xx). GATE к PHP-уникализации',
  `domain_readiness_state` varchar(32) DEFAULT NULL COMMENT 'v25.1: состояние readiness (technical_ready/checking/...)',
  `domain_readiness_reason` varchar(64) DEFAULT NULL COMMENT 'v25.1: причина последнего readiness-решения',
  `domain_http_location` varchar(2048) DEFAULT NULL COMMENT 'v25.1: Location из публичного HTTP-редиректа',
  `domain_yandexbot_http_code` int(11) DEFAULT NULL COMMENT 'v25.1: HTTP-код ответа домена на запрос с YandexBot UA',
  `domain_yandexbot_location` varchar(2048) DEFAULT NULL COMMENT 'v25.1: Location из ответа YandexBot',
  `domain_ssl_state` varchar(32) DEFAULT NULL COMMENT 'v25.1: SSL-состояние (not_checked/no_tls/self_signed/trusted/hostname_mismatch/expired/...)',
  `domain_ssl_trusted_at` datetime DEFAULT NULL COMMENT 'v25.1: момент появления доверенного SSL',
  `domain_ssl_last_checked_at` datetime DEFAULT NULL COMMENT 'v25.1: время последней SSL-проверки',
  `wm_verifier_uploaded_at` datetime DEFAULT NULL COMMENT 'v25.2: verifier залит по FTP',
  `wm_verifier_public_at` datetime DEFAULT NULL COMMENT 'v25.2: verifier публично доступен (нестрогий probe)',
  `wm_verifier_strict_https_at` datetime DEFAULT NULL COMMENT 'v25.2: пройден строгий HTTPS-gate',
  `wm_verification_submitted_at` datetime DEFAULT NULL COMMENT 'v25.2: POST verification отправлен',
  `wm_verification_last_state` varchar(32) DEFAULT NULL COMMENT 'v25.2: последнее состояние верификации',
  `wm_verification_last_poll_at` datetime DEFAULT NULL COMMENT 'v25.2: время последнего poll',
  `ssl_issue_requested_at` datetime DEFAULT NULL COMMENT 'v25.2: запрошен выпуск trusted SSL (после aliases_added)',
  `ssl_issue_next_poll_at` datetime DEFAULT NULL COMMENT 'v25.2-a1: не запускать issuance-тик раньше этого времени',
  `awaiting_user_since` datetime DEFAULT NULL COMMENT 'v25.2-a1.6.4: непрерывное ожидание действия оператора',
  `uc_execution_state` varchar(20) DEFAULT NULL COMMENT 'PATCH_2: not_started|started|ambiguous|completed|verified|operator_skipped',
  `uc_execution_id` varchar(40) DEFAULT NULL COMMENT 'PATCH_2: id цикла выполнения update_classes',
  `uc_execution_started_at` datetime DEFAULT NULL COMMENT 'PATCH_2: момент резервирования запуска',
  `uc_execution_attempts` int(11) NOT NULL DEFAULT 0 COMMENT 'PATCH_2: число зарезервированных запусков',
  `ban_monitor_generation` int(10) unsigned DEFAULT NULL,
  `ban_monitor_eligible_at` datetime DEFAULT NULL,
  `pipeline_revision` varchar(64) DEFAULT NULL,
  `trusted_ssl_gate_required` tinyint(1) NOT NULL DEFAULT 0,
  `trusted_ssl_gate_completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site` (`site_id`),
  KEY `idx_stage` (`stage`,`stage_status`,`next_run_at`),
  KEY `idx_superseded_by` (`superseded_by_job_id`),
  KEY `idx_stage_status_next` (`stage`,`stage_status`,`next_run_at`),
  KEY `idx_ssl_state_checked` (`domain_ssl_state`,`domain_ssl_last_checked_at`),
  KEY `idx_wm_subphase` (`wm_verification_last_state`,`wm_verifier_strict_https_at`),
  KEY `idx_ssl_issue_next_poll` (`ssl_issue_next_poll_at`),
  KEY `idx_jobs_awaiting_since` (`stage_status`,`awaiting_user_since`),
  KEY `idx_uc_exec` (`stage`,`uc_execution_state`),
  KEY `idx_refresh_jobs_ban_generation` (`ban_monitor_generation`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_ban_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_ban_monitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) unsigned DEFAULT NULL,
  `source_job_id` bigint(20) unsigned NOT NULL,
  `domain` varchar(255) NOT NULL,
  `indexed_at` datetime NOT NULL,
  `monitoring_starts_at` datetime NOT NULL,
  `next_check_at` datetime DEFAULT NULL,
  `last_check_at` datetime DEFAULT NULL,
  `last_positive_at` datetime NOT NULL,
  `last_positive_pages` int(10) unsigned NOT NULL DEFAULT 1,
  `first_negative_at` datetime DEFAULT NULL,
  `last_negative_at` datetime DEFAULT NULL,
  `state` varchar(32) NOT NULL DEFAULT 'waiting_12h',
  `negative_streak` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `insurance_checks_done` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `technical_error_count` int(10) unsigned NOT NULL DEFAULT 0,
  `last_pages_indexed` int(10) unsigned NOT NULL DEFAULT 0,
  `series_no` int(10) unsigned NOT NULL DEFAULT 0,
  `probable_notified_at` datetime DEFAULT NULL,
  `recovered_notified_at` datetime DEFAULT NULL,
  `confirmed_notified_at` datetime DEFAULT NULL,
  `telegram_retry_at` datetime DEFAULT NULL,
  `last_result_json` longtext DEFAULT NULL,
  `last_error` varchar(1000) DEFAULT NULL,
  `stopped_at` datetime DEFAULT NULL,
  `stop_reason` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `activation_generation` int(10) unsigned NOT NULL DEFAULT 0,
  `policy_version` int(10) unsigned NOT NULL DEFAULT 1,
  `policy_snapshot_json` longtext DEFAULT NULL,
  `banned_at` datetime DEFAULT NULL,
  `paused_from_state` varchar(32) DEFAULT NULL,
  `paused_next_check_at` datetime DEFAULT NULL,
  `blocked_reason` varchar(64) DEFAULT NULL,
  `blocked_notified_at` datetime DEFAULT NULL,
  `enrollment_source` varchar(32) NOT NULL DEFAULT 'automatic',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ban_monitor_job_domain` (`source_job_id`,`domain`),
  KEY `idx_ban_monitor_due` (`state`,`next_check_at`),
  KEY `idx_ban_monitor_domain` (`domain`),
  KEY `idx_ban_monitor_site` (`site_id`),
  KEY `idx_ban_monitor_job` (`source_job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_ban_monitor_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_ban_monitor_checks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `monitor_id` bigint(20) unsigned NOT NULL,
  `xmlstock_request_log_id` bigint(20) unsigned DEFAULT NULL,
  `checked_at` datetime NOT NULL,
  `phase` varchar(32) NOT NULL,
  `sequence_no` tinyint(3) unsigned DEFAULT NULL,
  `series_no` int(10) unsigned NOT NULL DEFAULT 0,
  `result` varchar(24) NOT NULL,
  `pages_indexed` int(10) unsigned DEFAULT NULL,
  `xmlstock_ok` tinyint(1) NOT NULL DEFAULT 0,
  `message` varchar(1000) DEFAULT NULL,
  `error_code` varchar(128) DEFAULT NULL,
  `response_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ban_check_request` (`xmlstock_request_log_id`),
  KEY `idx_ban_checks_monitor` (`monitor_id`,`checked_at`),
  KEY `idx_ban_checks_request` (`xmlstock_request_log_id`),
  CONSTRAINT `fk_ban_checks_monitor` FOREIGN KEY (`monitor_id`) REFERENCES `site_ban_monitors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `xmlstock_request_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xmlstock_request_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `request_uuid` char(36) NOT NULL,
  `requested_at` datetime NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  `purpose` varchar(32) NOT NULL,
  `phase` varchar(32) DEFAULT NULL,
  `initiated_by` varchar(24) NOT NULL DEFAULT 'cron',
  `source_job_id` bigint(20) unsigned DEFAULT NULL,
  `site_id` bigint(20) unsigned DEFAULT NULL,
  `monitor_id` bigint(20) unsigned DEFAULT NULL,
  `domain` varchar(255) NOT NULL,
  `sequence_no` tinyint(3) unsigned DEFAULT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'reserved',
  `result` varchar(24) DEFAULT NULL,
  `pages_indexed` int(10) unsigned DEFAULT NULL,
  `http_code` int(11) DEFAULT NULL,
  `provider_code` varchar(64) DEFAULT NULL,
  `duration_ms` int(10) unsigned DEFAULT NULL,
  `assumed_charged` tinyint(1) NOT NULL DEFAULT 0,
  `request_cost_rub` decimal(12,4) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `response_excerpt` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `execution_state` varchar(32) NOT NULL DEFAULT 'reserved',
  `reserved_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `ambiguous_at` datetime DEFAULT NULL,
  `failed_before_http_at` datetime DEFAULT NULL,
  `normalized_result_json` longtext DEFAULT NULL,
  `transport_error` varchar(1000) DEFAULT NULL,
  `http_attempted` tinyint(1) NOT NULL DEFAULT 0,
  `replayed_from_log` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_xmlstock_request_uuid` (`request_uuid`),
  KEY `idx_xmlstock_usage_time` (`requested_at`),
  KEY `idx_xmlstock_usage_purpose` (`purpose`,`requested_at`),
  KEY `idx_xmlstock_usage_job` (`source_job_id`,`requested_at`),
  KEY `idx_xmlstock_usage_monitor` (`monitor_id`,`requested_at`),
  KEY `idx_xmlstock_usage_domain` (`domain`,`requested_at`),
  KEY `idx_xmlstock_execstate` (`execution_state`,`requested_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `ban_monitoring_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ban_monitoring_settings` (
  `id` tinyint(3) unsigned NOT NULL,
  `enrollment_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `processing_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `activation_generation` int(10) unsigned NOT NULL DEFAULT 0,
  `activation_started_at` datetime DEFAULT NULL,
  `activation_min_job_id` bigint(20) unsigned DEFAULT NULL,
  `policy_version` int(10) unsigned NOT NULL DEFAULT 1,
  `initial_delay_minutes` int(10) unsigned NOT NULL DEFAULT 720,
  `regular_interval_minutes` int(10) unsigned NOT NULL DEFAULT 30,
  `probable_negative_count` int(10) unsigned NOT NULL DEFAULT 3,
  `confirm_interval_minutes` int(10) unsigned NOT NULL DEFAULT 10,
  `insurance_negative_count` int(10) unsigned NOT NULL DEFAULT 3,
  `insurance_interval_minutes` int(10) unsigned NOT NULL DEFAULT 10,
  `technical_error_retry_minutes` int(10) unsigned NOT NULL DEFAULT 30,
  `cron_batch_limit` int(10) unsigned NOT NULL DEFAULT 5,
  `telegram_retry_minutes` int(10) unsigned NOT NULL DEFAULT 10,
  `telegram_max_attempts` int(10) unsigned NOT NULL DEFAULT 20,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `ban_monitoring_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ban_monitoring_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(64) NOT NULL,
  `object_type` varchar(32) NOT NULL DEFAULT 'settings',
  `object_id` bigint(20) unsigned DEFAULT NULL,
  `operator` varchar(128) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `old_values` longtext DEFAULT NULL,
  `new_values` longtext DEFAULT NULL,
  `comment` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_bma_action` (`action`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `ban_monitor_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ban_monitor_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `monitor_id` bigint(20) unsigned NOT NULL,
  `source_job_id` bigint(20) unsigned NOT NULL,
  `domain` varchar(255) NOT NULL,
  `event_key` varchar(255) NOT NULL,
  `kind` varchar(32) NOT NULL,
  `payload_json` longtext NOT NULL,
  `rendered_text` longtext NOT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'pending',
  `attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `next_attempt_at` datetime NOT NULL,
  `last_attempt_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `last_error` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ban_notification_event` (`event_key`),
  KEY `idx_ban_notification_due` (`status`,`next_attempt_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `xmlstock_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `xmlstock_settings` (
  `id` int(11) NOT NULL DEFAULT 1,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `endpoint_xml` varchar(255) NOT NULL DEFAULT 'https://xmlstock.com/yandexlive/xml/',
  `user_id` varchar(64) NOT NULL DEFAULT '' COMMENT 'xmlstock user (login)',
  `api_key` varchar(128) NOT NULL DEFAULT '' COMMENT 'xmlstock key',
  `daily_quota_limit` int(11) NOT NULL DEFAULT 1000 COMMENT 'Информационно — для UI',
  `queries_today` int(11) NOT NULL DEFAULT 0 COMMENT 'Счётчик запросов за сегодня',
  `queries_today_date` date DEFAULT NULL,
  `last_validated_at` datetime DEFAULT NULL,
  `last_validation_ok` tinyint(1) NOT NULL DEFAULT 0,
  `last_validation_error` varchar(500) NOT NULL DEFAULT '',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `balance_endpoint` varchar(255) NOT NULL DEFAULT '' COMMENT 'URL balance API XMLStock (auto-detected или задан вручную, v18.1.28)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='v17.1: настройки xmlstock.com — платная XML Search API для быстрой проверки индекса';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

