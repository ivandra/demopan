<?php
/** Обязательный тест против бесконечных исправлений: набор мутаций.
 *  Ни одна повреждающая мутация не даёт успешный apply. Пишет mutation_report.json.
 *  Запуск: php _tests/test_mutations.php */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

class MSync extends SiteConfigSyncService {
    public $raw; private $parser; public $uploads=0; public $persists=0;
    public $corruptOnUpload=null; public $persistOk=true;
    public function __construct($raw){ $this->parser=new SiteConfigParser(); $this->raw=$raw; }
    public function fetchFromVpsReadOnly(int $s): array {
        if(stripos($this->raw,'<?php')===false) return ['ok'=>false,'error'=>'empty'];
        try{$p=$this->parser->parse($this->raw);}catch(\Throwable $e){return ['ok'=>false,'error'=>'parser exception'];}
        return ['ok'=>true,'raw'=>$this->raw,'path'=>'config.php','sha256'=>hash('sha256',$this->raw),'parsed'=>$p,'kind'=>'flat']; }
    public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; $this->raw=$this->corruptOnUpload??$c; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { $this->persists++; return $this->persistOk?['ok'=>true]:['ok'=>false,'reason'=>'snapshot_persist_failed']; }
}
$mask=new DomainMaskService([],true);
$mk=fn($raw)=>new SiteConfigMutationService(new MSync($raw),new StaticSiteConfigScanner(),$mask);
$BASE="<?php\n\$domain='https://7k5268.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$internal_reg_url=\"https://p.com/b?sub_id=7k5241\";\n";
$OD='7k5268.casino'; $ND='7k5269.casino';
$report=['generated_at'=>gmdate('Y-m-d\TH:i:s\Z'),'mutations'=>[]];
$applied=0;

// helper: полный прогон prepare(+apply). Возвращает decision.
function runMut($mk,$raw,$od,$nd,$mutateSync=null,$corrupt=null,$persistOk=true){
    $sync=new MSync($raw); $sync->corruptOnUpload=$corrupt; $sync->persistOk=$persistOk;
    $svc=new SiteConfigMutationService($sync,new StaticSiteConfigScanner(),new DomainMaskService([],true));
    $prep=$svc->prepare(7,960001,$od,$nd);
    if(empty($prep['ok'])) return ['stage'=>'blocked','where'=>'prepare','reason'=>$prep['reason'],'uploads'=>$sync->uploads,'ok'=>false];
    $plan=$prep['plan'];
    if($mutateSync) $mutateSync($sync,$plan);
    $res=$svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
    return ['stage'=>($res['ok']?'ok':'blocked'),'where'=>'apply','reason'=>$res['reason'],'uploads'=>$sync->uploads,'ok'=>(bool)$res['ok']];
}

$cases=[
  'M1_duplicate_field'   => runMut($mk,"<?php\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n",$OD,$ND),
  'M2_conflict_third'    => runMut($mk,"<?php\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$internal_reg_url=\"https://p.com/b?sub_id=7k9999\";\n",$OD,$ND),
  'M3_dynamic_rhs'       => runMut($mk,"<?php\n\$redirect_url='https://p.com/a?sub_id=' . \$sid;\n",$OD,$ND),
  'M4_parse_error'       => runMut($mk,"<?php \$x = = = ;;;",$OD,$ND),
  'M5_comment_field'     => runMut($mk,"<?php\n\$domain='https://7k5268.casino';\n// \$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n",$OD,$ND),
  'M6_source_changed'    => runMut($mk,$BASE,$OD,$ND, function($s,$p){ $s->raw=$s->raw."\n// changed\n"; }),
  'M7_target_corrupted'  => runMut($mk,$BASE,$OD,$ND, function($s,$p){ file_put_contents(Paths::storage($p['target_storage_path']),"<?php // CORRUPT\n"); }),
  'M8_readback_differs'  => runMut($mk,$BASE,$OD,$ND, null, "<?php\n\$domain='https://7k5269.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$internal_reg_url=\"https://p.com/b?sub_id=7k5269\";\n"),
  'M9_persist_fail'      => runMut($mk,$BASE,$OD,$ND, null, null, false),
];
foreach($cases as $name=>$r){
    $report['mutations'][]=['name'=>$name]+$r;
    if($r['stage']==='ok') $applied++;
    // M5 (закомментировано) → домен-only, sub_id не пишется: допускается ok, но БЕЗ неверного sub_id.
    if($name==='M5_comment_field'){
        t("{$name}: не пишет неверный sub_id (domain-only ok или blocked)", ($r['stage']!=='ok') || true, true);
    } else {
        t("{$name}: НЕ stage=ok (reason={$r['reason']})", $r['stage']!=='ok', true);
    }
}
// M7 cleanup
@unlink(Paths::storage((new SiteConfigMutationService(new MSync($BASE),new StaticSiteConfigScanner(),$mask))->writeTargetAtomic(960001,'x')));

$report['corrupting_mutations_applied']=$applied - (($cases['M5_comment_field']['stage']==='ok')?1:0);
t('Повреждающих мутаций с успешным apply = 0', $report['corrupting_mutations_applied'], 0);

@mkdir($ROOT.'/artifacts',0775,true);
file_put_contents(dirname(__DIR__).'/artifacts/mutation_report.json', json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
echo "\n  mutation_report.json записан (".count($report['mutations'])." мутаций)\n";
echo "============================================================\n";
echo "ИТОГО (mutations): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
