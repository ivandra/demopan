<?php
/** P0 §4.6: ручные действия не обходят gate — sslSkip reject, override-блокировки,
 *  «Проверить SSL сейчас» будит trusted_ssl_gate.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/trusted_ssl/test_gate_actions.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp31t'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php'; require_once $ROOT.'/app/Controllers/RefreshJobController.php';
@session_start(); $_SESSION['auth']=true; $_SESSION['csrf_token']='tok';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
class RedirG extends \Exception{}
class CsrfDeny extends \Exception{}
class TRJ extends RefreshJobController { public $fl=[];
  protected function flash(string $t,string $m):void{ $this->fl[]=[$t,$m]; }
  protected function redirect(string $u):void{ throw new RedirG($u); }
  public function requireCsrf(): void { if(!$this->csrfValid()) throw new CsrfDeny('csrf'); }
  public function call(string $m){ $this->fl=[]; try{ $this->$m(); }catch(RedirG $e){} return $this->fl; }
  public function callDenied(string $m): bool { try{ $this->$m(); }catch(CsrfDeny $e){ return true; }catch(RedirG $e){} return false; } }
$ctl=new TRJ();
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 995100 AND 995199");
function mkjob($pdo,$id,$stage,$req=1,$arts=null,$completed=null,$status='pending'){
  $pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,trusted_ssl_gate_required,pipeline_revision,artifacts_json,trusted_ssl_gate_completed_at,created_at) VALUES (?,?,?,?,'refresh',?,?,?,?,?,?,NOW())")
      ->execute([$id,1,'o.casino','n.casino',$stage,$status,$req,$req?'ssl_before_webmaster_v1':null,$arts,$completed]); }
function job($pdo,$id){ $s=$pdo->prepare("SELECT * FROM refresh_jobs WHERE id=?"); $s->execute([$id]); return $s->fetch(); }
function lastMsg($fl){ return $fl ? $fl[count($fl)-1][1] : ''; }

echo "=== sslSkip на trusted_ssl_gate → reject ===\n";
mkjob($pdo,995101,'trusted_ssl_gate');
$_POST=['id'=>995101,'comment'=>'хочу пропустить','csrf_token'=>'tok'];
$fl=$ctl->call('sslSkip');
t('пропуск отклонён (сообщение)', strpos(lastMsg($fl),'пропустить нельзя')!==false, true);
t('стадия не изменилась', job($pdo,995101)['stage'], 'trusted_ssl_gate');

echo "=== generic skipStage: trusted_ssl_gate в forbidden ===\n";
$src=file_get_contents($ROOT.'/app/Controllers/RefreshJobController.php');
t('trusted_ssl_gate в forbiddenStages', preg_match("~forbiddenStages\s*=\s*\[[^\]]*'trusted_ssl_gate'~s",$src)===1, true);

echo "=== setWebmasterOverride из trusted_ssl_gate → reject ===\n";
$pdo->exec("INSERT IGNORE INTO yandex_webmaster_accounts (id,label,email) VALUES (990,'t','t@t')");
$_POST=['id'=>995101,'account_id'=>990,'csrf_token'=>'tok'];
$fl=$ctl->call('setWebmasterOverride');
t('override отклонён из gate-стадии', strpos(lastMsg($fl),'запрещён')!==false, true);
t('стадия осталась trusted_ssl_gate', job($pdo,995101)['stage'], 'trusted_ssl_gate');

echo "=== override при required=1 без gate.ok (awaiting_user на wm_account_resolve) → reject ===\n";
mkjob($pdo,995102,'wm_account_resolve',1,null,null,'awaiting_user');
$_POST=['id'=>995102,'account_id'=>990,'csrf_token'=>'tok'];
$fl=$ctl->call('setWebmasterOverride');
t('override отклонён без gate.ok', strpos(lastMsg($fl),'trusted_ssl_gate')!==false, true);
t('override_id не записан', job($pdo,995102)['webmaster_account_override_id'], null);

echo "=== override при required=1 С gate.ok → разрешён ===\n";
$aOk=json_encode(['trusted_ssl_gate'=>['ok'=>true]]);
mkjob($pdo,995103,'wm_account_resolve',1,$aOk,gmdate('Y-m-d H:i:s'),'awaiting_user');
$_POST=['id'=>995103,'account_id'=>990,'csrf_token'=>'tok'];
$fl=$ctl->call('setWebmasterOverride');
t('override с gate.ok прошёл', (int)job($pdo,995103)['webmaster_account_override_id'], 990);

echo "=== override legacy (required=0) → работает как раньше ===\n";
mkjob($pdo,995104,'wm_account_resolve',0,null,null,'awaiting_user');
$_POST=['id'=>995104,'account_id'=>990,'csrf_token'=>'tok'];
$ctl->call('setWebmasterOverride');
t('legacy override прошёл', (int)job($pdo,995104)['webmaster_account_override_id'], 990);

echo "=== P0 ревью v2: override — ПОЛНАЯ матрица состояний ===\n";
$aOk=json_encode(['trusted_ssl_gate'=>['ok'=>true]]);
$NOWG=gmdate('Y-m-d H:i:s');
function jstate($pdo,$id){ $r=$pdo->query("SELECT stage,stage_status,webmaster_account_override_id FROM refresh_jobs WHERE id=$id")->fetch(); return [$r['stage'],$r['stage_status'],$r['webmaster_account_override_id']===null?null:(int)$r['webmaster_account_override_id']]; }

// 1) РАЗРЕШЁН: wm_account_resolve + awaiting_user + gate ok
mkjob($pdo,995110,'wm_account_resolve',1,$aOk,$NOWG,'awaiting_user');
$_POST=['id'=>995110,'account_id'=>990,'csrf_token'=>'tok'];
$fl=$ctl->call('setWebmasterOverride');
t('S1 wm_account_resolve+awaiting_user+gate → override применён', jstate($pdo,995110), ['wm_account_resolve','pending',990]);
t('S1 flash success', ($fl[count($fl)-1][0] ?? ''), 'success');

// 2) РАЗРЕШЁН: move_poll_status + awaiting_user + awaiting_no_account=true
$aMove=json_encode(['trusted_ssl_gate'=>['ok'=>true],'move_poll_status_stage'=>['awaiting_no_account'=>true,'awaiting_reason'=>'lost']]);
mkjob($pdo,995111,'move_poll_status',1,$aMove,$NOWG,'awaiting_user');
$_POST=['id'=>995111,'account_id'=>990,'csrf_token'=>'tok'];
$ctl->call('setWebmasterOverride');
$j111=job($pdo,995111);
t('S2 move_poll_status+awaiting_no_account → переведена на wm_account_resolve/pending', [$j111['stage'],$j111['stage_status']], ['wm_account_resolve','pending']);
$a111=json_decode((string)$j111['artifacts_json'],true)?:[];
t('S2 awaiting_no_account сброшен, awaiting_reason удалён', [($a111['move_poll_status_stage']['awaiting_no_account']??null), array_key_exists('awaiting_reason',$a111['move_poll_status_stage']??[])], [false,false]);

// 3) ОТКЛОНЁН: wm_account_resolve + pending (не awaiting_user)
mkjob($pdo,995112,'wm_account_resolve',1,$aOk,$NOWG,'pending');
$_POST=['id'=>995112,'account_id'=>990,'csrf_token'=>'tok'];
$fl=$ctl->call('setWebmasterOverride');
t('wm_account_resolve+pending → отклонён, не изменена', jstate($pdo,995112), ['wm_account_resolve','pending',null]);
t('pending: сообщение об отказе', strpos(lastMsg($fl),'отклонён')!==false, true);
// running — тоже отклонён
mkjob($pdo,995113,'wm_account_resolve',1,$aOk,$NOWG,'running');
$_POST=['id'=>995113,'account_id'=>990,'csrf_token'=>'tok'];
$ctl->call('setWebmasterOverride');
t('wm_account_resolve+running → отклонён', jstate($pdo,995113), ['wm_account_resolve','running',null]);

// 4-7) ОТКЛОНЁН из продвинувшихся стадий ДАЖЕ при пройденном gate (главный P0-кейс)
foreach ([995114=>'wm_added',995115=>'wm_verified',995116=>'wm_recrawl',995117=>'index_watching',995118=>'final_monitoring'] as $jid=>$stg) {
    mkjob($pdo,$jid,$stg,1,$aOk,$NOWG,'awaiting_user'); // даже awaiting_user на чужой стадии
    $_POST=['id'=>$jid,'account_id'=>990,'csrf_token'=>'tok'];
    $ctl->call('setWebmasterOverride');
    t("override из {$stg} (gate ok) → отклонён, джоба НЕ откачена", jstate($pdo,$jid), [$stg,'awaiting_user',null]);
}

// 8) гонка: состояние изменилось между read и UPDATE → production CAS SQL даёт rowCount=0
mkjob($pdo,995119,'wm_added',1,$aOk,$NOWG,'running'); // «джоба успела уйти вперёд»
$casSql=(new ReflectionClassConstant('RefreshJobController','WM_OVERRIDE_CAS_SQL'))->getValue();
$st=$pdo->prepare($casSql); $st->execute([990,995119]);
t('race: production CAS rowCount=0', $st->rowCount(), 0);
t('race: джоба не откачена', jstate($pdo,995119), ['wm_added','running',null]);
// та же CAS-строка успешно срабатывает из валидного состояния (позитивный контроль SQL)
mkjob($pdo,995120,'wm_account_resolve',1,$aOk,$NOWG,'awaiting_user');
$st=$pdo->prepare($casSql); $st->execute([990,995120]);
t('CAS позитивный контроль: rowCount=1 из awaiting_user', $st->rowCount(), 1);
// CAS сам защищает gate: awaiting_user, но gate НЕ пройден → 0 строк
mkjob($pdo,995121,'wm_account_resolve',1,null,null,'awaiting_user');
$st=$pdo->prepare($casSql); $st->execute([990,995121]);
t('CAS: gate не пройден → rowCount=0 (WHERE-защита)', $st->rowCount(), 0);

// 9) терминальные → отклонён
foreach ([995122=>'done',995123=>'failed'] as $jid=>$stg) {
    mkjob($pdo,$jid,$stg,1,$aOk,$NOWG,'ok');
    $_POST=['id'=>$jid,'account_id'=>990,'csrf_token'=>'tok'];
    $ctl->call('setWebmasterOverride');
    t("override из {$stg} → отклонён", jstate($pdo,$jid), [$stg,'ok',null]);
}

// 10) CSRF: без токена / с неверным — denied, джоба не тронута
mkjob($pdo,995124,'wm_account_resolve',1,$aOk,$NOWG,'awaiting_user');
$_POST=['id'=>995124,'account_id'=>990];
t('override без CSRF → denied', $ctl->callDenied('setWebmasterOverride'), true);
$_POST=['id'=>995124,'account_id'=>990,'csrf_token'=>'WRONG'];
t('override с неверным CSRF → denied', $ctl->callDenied('setWebmasterOverride'), true);
t('CSRF-отказ: джоба не изменена', jstate($pdo,995124), ['wm_account_resolve','awaiting_user',null]);

// 11) форма несёт csrf_token (view-контракт)
$formSrc=file_get_contents($ROOT.'/app/Views/jobs/_wm_account_select.php');
t('форма override содержит csrf_token', strpos($formSrc,'name="csrf_token"')!==false, true);

echo "=== sslCheckNow на trusted_ssl_gate → next_run_at=NOW (§4.6) ===\n";
mkjob($pdo,995105,'trusted_ssl_gate');
$pdo->prepare("UPDATE refresh_jobs SET next_run_at=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id=995105")->execute();
$_POST=['id'=>995105,'csrf_token'=>'tok'];
$fl=$ctl->call('sslCheckNow');
$j=job($pdo,995105);
$soon = strtotime((string)$j['next_run_at']) <= time()+5;
t('next_run_at сброшен в NOW (poll немедленно)', $soon, true);
t('status=pending остался', $j['stage_status'], 'pending');

$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 995100 AND 995199");
$pdo->exec("DELETE FROM yandex_webmaster_accounts WHERE id=990");
echo "\n============================================================\n";
echo "ИТОГО (gate actions): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
