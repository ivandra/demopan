<?php
/** P0 (ТЗ §4, §11.1): trusted_ssl_gate — атомарный commit, guard wm_*, adopt revision,
 *  timeout, дисциплина логов, sslGateClosed, skip без цикла.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/trusted_ssl/test_trusted_ssl_pipeline.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp31t'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 995000 AND 995099");
$pdo->exec("DELETE FROM refresh_job_events WHERE job_id BETWEEN 995000 AND 995099");
function mkjob($pdo,$id,$dom,$stage='trusted_ssl_gate',$status='running',$req=1,$rev='ssl_before_webmaster_v1',$arts=null){
  $pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,trusted_ssl_gate_required,pipeline_revision,artifacts_json,created_at) VALUES (?,?,?,?,'refresh',?,?,?,?,?,NOW())")
      ->execute([$id,1,'old.casino',$dom,$stage,$status,$req,$rev,$arts]); }
function job($pdo,$id){ $s=$pdo->prepare("SELECT * FROM refresh_jobs WHERE id=?"); $s->execute([$id]); return $s->fetch(); }
function arts($j){ return json_decode((string)($j['artifacts_json']??''),true)?:[]; }
function events($pdo,$id,$like='%'){ $s=$pdo->prepare("SELECT COUNT(*) FROM refresh_job_events WHERE job_id=? AND message LIKE ?"); $s->execute([$id,$like]); return (int)$s->fetchColumn(); }

$orch=new RefreshOrchestrator();
$ref=new ReflectionClass($orch);
$run=$ref->getMethod('runTrustedSslGateStage'); $run->setAccessible(true);
$guard=$ref->getMethod('wmSslGateGuard'); $guard->setAccessible(true);
$adopt=$ref->getMethod('maybeAdoptSslRevision'); $adopt->setAccessible(true);
$sslClosed=$ref->getMethod('sslGateClosed'); $sslClosed->setAccessible(true);
$goodProbe=fn($d)=>['connected'=>true,'chain_verified'=>true,'hostname_verified'=>true,'self_signed'=>false,'issuer'=>"O=Let's Encrypt",'subject'=>'CN='.$d,'not_before'=>'2026-07-01 00:00:00','not_after'=>'2026-10-01 00:00:00','fingerprint'=>'fp'];
$selfSignedProbe=fn($d)=>['connected'=>true,'chain_verified'=>false,'hostname_verified'=>true,'self_signed'=>true,'issuer'=>'CN='.$d,'subject'=>'CN='.$d];

echo "=== 1. self-signed (§11.1.1) → pending, gate не закрыт, Yandex=0 ===\n";
mkjob($pdo,995001,'ssg1.casino');
$orch->setTrustedSslProbe($selfSignedProbe);
$run->invoke($orch, job($pdo,995001), new JobEventLogger(995001));
$j=job($pdo,995001);
t('стадия trusted_ssl_gate', $j['stage'], 'trusted_ssl_gate');
t('status=pending', $j['stage_status'], 'pending');
t('next_run_at установлен', !empty($j['next_run_at']), true);
t('gate.ok отсутствует', empty(arts($j)['trusted_ssl_gate']['ok']), true);
t('completed_at NULL', $j['trusted_ssl_gate_completed_at'], null);

echo "=== 2. дисциплина логов (§4.7): повтор той же причины — без нового события ===\n";
$e1=events($pdo,995001,'%Ожидание публичного доверенного SSL%');
$pdo->prepare("UPDATE refresh_jobs SET stage_status='running' WHERE id=995001")->execute();
$run->invoke($orch, job($pdo,995001), new JobEventLogger(995001));
$e2=events($pdo,995001,'%Ожидание публичного доверенного SSL%');
t('«вошёл в ожидание» один раз', [$e1,$e2], [1,1]);

echo "=== 3. валидный LE (§11.1.5) → АТОМАРНЫЙ успех одной транзакцией ===\n";
mkjob($pdo,995002,'ssg2.casino');
$orch->setTrustedSslProbe($goodProbe);
$run->invoke($orch, job($pdo,995002), new JobEventLogger(995002));
$j2=job($pdo,995002); $a2=arts($j2);
t('gate.ok=true', !empty($a2['trusted_ssl_gate']['ok']), true);
t('source=public_live_tls', $a2['trusted_ssl_gate']['source']??'', 'public_live_tls');
t('completed_at заполнен', !empty($j2['trusted_ssl_gate_completed_at']), true);
t('status=ok (advance разрешён)', $j2['stage_status'], 'ok');
t('wait очищен', empty($a2['trusted_ssl_gate_wait']), true);
t('nextStage → wm_account_resolve', RefreshOrchestrator::nextStageFor('trusted_ssl_gate','refresh',false), 'wm_account_resolve');

echo "=== 4. §11.1.7 атомарность: конкурентная смена статуса → rowCount=0 → gate НЕ закрыт ===\n";
mkjob($pdo,995003,'ssg3.casino','trusted_ssl_gate','pending'); // НЕ running — эмуляция гонки
$run->invoke($orch, job($pdo,995003), new JobEventLogger(995003));
$j3=job($pdo,995003);
t('gate.ok НЕ записан', empty(arts($j3)['trusted_ssl_gate']['ok']), true);
t('completed_at NULL', $j3['trusted_ssl_gate_completed_at'], null);
t('стадия осталась trusted_ssl_gate', $j3['stage'], 'trusted_ssl_gate');
t('ошибка атомарности залогирована', events($pdo,995003,'%Атомарная фиксация gate не подтверждена%')>=1, true);

echo "=== 5. fatal → awaiting_user (§11.1.11 путь) ===\n";
mkjob($pdo,995004,'');
$run->invoke($orch, job($pdo,995004), new JobEventLogger(995004));
t('fatal → awaiting_user', job($pdo,995004)['stage_status'], 'awaiting_user');

echo "=== 6. timeout (§4.7): >6ч ожидания → awaiting_user, Yandex=0 ===\n";
$w=json_encode(['trusted_ssl_gate_wait'=>['entered_at_unix'=>time()-25000,'last_logged_reason'=>'chain_untrusted','long_notified'=>true]]);
mkjob($pdo,995005,'ssg5.casino','trusted_ssl_gate','running',1,'ssl_before_webmaster_v1',$w);
$orch->setTrustedSslProbe($selfSignedProbe);
$run->invoke($orch, job($pdo,995005), new JobEventLogger(995005));
$j5=job($pdo,995005);
t('timeout → awaiting_user', $j5['stage_status'], 'awaiting_user');
t('timeout залогирован', events($pdo,995005,'%Timeout ожидания публичного доверенного SSL%'), 1);
t('gate.ok нет', empty(arts($j5)['trusted_ssl_gate']['ok']), true);

echo "=== 7. §4.5 guard: wm_* без gate при required=1 → возврат на gate, событие один раз ===\n";
mkjob($pdo,995006,'ssg6.casino','wm_added','running');
$g1=$guard->invoke($orch, job($pdo,995006), new JobEventLogger(995006), 'wm_added');
$j6=job($pdo,995006);
t('guard → false (Webmaster запрещён)', $g1, false);
t('джоба возвращена на trusted_ssl_gate', $j6['stage'], 'trusted_ssl_gate');
t('status=pending', $j6['stage_status'], 'pending');
t('guard-событие записано', events($pdo,995006,'%Guard: попытка входа в Webmaster%'), 1);
// повтор — событие не дублируется (bounced_from совпадает)
$pdo->prepare("UPDATE refresh_jobs SET stage='wm_added', stage_status='running' WHERE id=995006")->execute();
$guard->invoke($orch, job($pdo,995006), new JobEventLogger(995006), 'wm_added');
t('повтор guard — без нового события', events($pdo,995006,'%Guard: попытка входа в Webmaster%'), 1);

echo "=== 8. guard corrupted (ok без completed_at) → awaiting_user ===\n";
$aC=json_encode(['trusted_ssl_gate'=>['ok'=>true]]);
mkjob($pdo,995007,'ssg7.casino','wm_verified','running',1,'ssl_before_webmaster_v1',$aC);
$gc=$guard->invoke($orch, job($pdo,995007), new JobEventLogger(995007), 'wm_verified');
t('corrupted → false', $gc, false);
t('corrupted → awaiting_user', job($pdo,995007)['stage_status'], 'awaiting_user');

echo "=== 9. guard pass: ok+completed_at → Webmaster разрешён ===\n";
mkjob($pdo,995008,'ssg8.casino','wm_added','running',1,'ssl_before_webmaster_v1',$aC);
$pdo->prepare("UPDATE refresh_jobs SET trusted_ssl_gate_completed_at=NOW() WHERE id=995008")->execute();
t('guard → true', $guard->invoke($orch, job($pdo,995008), new JobEventLogger(995008), 'wm_added'), true);

echo "=== 10. legacy (§10.3): required=0 → guard true (старый путь без отката) ===\n";
mkjob($pdo,995009,'ssg9.casino','wm_verified','running',0,null);
t('legacy guard → true', $guard->invoke($orch, job($pdo,995009), new JobEventLogger(995009), 'wm_verified'), true);

echo "=== 11. §4.3 adopt: до-Webmaster джоба переводится, wm_verified — нет ===\n";
mkjob($pdo,995010,'ssg10.casino','update_classes_call','pending',0,null);
$ja=$adopt->invoke($orch, job($pdo,995010), new JobEventLogger(995010));
$j10=job($pdo,995010);
t('adopt: required=1', (int)$j10['trusted_ssl_gate_required'], 1);
t('adopt: revision установлена', $j10['pipeline_revision'], 'ssl_before_webmaster_v1');
t('adopt: возвращённый job обновлён', (int)($ja['trusted_ssl_gate_required']??0), 1);
mkjob($pdo,995011,'ssg11.casino','wm_verified','pending',0,null);
$adopt->invoke($orch, job($pdo,995011), new JobEventLogger(995011));
t('wm_verified НЕ adopted (legacy)', (int)job($pdo,995011)['trusted_ssl_gate_required'], 0);
// с wm-артефактами до wm-стадии — тоже legacy
$aW=json_encode(['wm_added_stage'=>['host_id'=>'x']]);
mkjob($pdo,995012,'ssg12.casino','redirect_enable','pending',0,null,$aW);
$adopt->invoke($orch, job($pdo,995012), new JobEventLogger(995012));
t('джоба с wm-артефактами НЕ adopted', (int)job($pdo,995012)['trusted_ssl_gate_required'], 0);

echo "=== 12. sslGateClosed признаёт gate.ok (двойная модель снята) ===\n";
t('gate.ok → sslGateClosed=true', $sslClosed->invoke($orch, ['new_domain'=>'x.casino','artifacts_json'=>$aC], []), true);

echo "=== 13. §4.8 skip Webmaster — только вперёд (нет цикла) ===\n";
require_once $ROOT.'/app/Core/Controller.php'; require_once $ROOT.'/app/Controllers/RefreshJobController.php';
$rc=new ReflectionClass('RefreshJobController');
$rs=$rc->getMethod('resolveSkipNextStage'); $rs->setAccessible(true);
$ctl=$rc->newInstanceWithoutConstructor();
t('skip wm(refresh) → index_watching', $rs->invoke($ctl,'wm_account_resolve','refresh'), 'index_watching');
t('skip wm(move_indexed) → move_submit_request', $rs->invoke($ctl,'wm_account_resolve','move_indexed'), 'move_submit_request');
t('skip wm(move_simple) → move_submit_request', $rs->invoke($ctl,'wm_account_resolve','move_simple'), 'move_submit_request');

echo "=== 14. новые джобы создаются с revision+required (статически, оба INSERT) ===\n";
$c1=file_get_contents($ROOT.'/app/Controllers/RefreshJobController.php');
$c2=file_get_contents($ROOT.'/app/Services/JobLifecycleService.php');
t('controller INSERT содержит ssl_before_webmaster_v1 + required=1', strpos($c1,"'ssl_before_webmaster_v1', 1)")!==false, true);
t('lifecycle INSERT содержит ssl_before_webmaster_v1 + required=1', strpos($c2,"'ssl_before_webmaster_v1', 1)")!==false, true);

$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 995000 AND 995099");
$pdo->exec("DELETE FROM refresh_job_events WHERE job_id BETWEEN 995000 AND 995099");
echo "\n============================================================\n";
echo "ИТОГО (trusted ssl pipeline r31): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
