<?php
/** P0: TrustedSslGate — публичная TLS-проверка (injectable probe, offline).
 *  php _tests/trusted_ssl/test_trusted_ssl_gate.php */
$ROOT=dirname(__DIR__,2);
require_once $ROOT.'/app/Services/TrustedSslGate.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$now=new DateTimeImmutable('2026-07-31 12:00:00',new DateTimeZone('UTC'));
$clock=fn()=>$now;
function gate($probeResult,$clock){ return new TrustedSslGate(fn($d)=>$probeResult,$clock); }
$good=['connected'=>true,'chain_verified'=>true,'hostname_verified'=>true,'self_signed'=>false,
  'issuer'=>'O=Let\'s Encrypt, CN=R3','subject'=>'CN=x.casino','not_before'=>'2026-07-01 00:00:00','not_after'=>'2026-10-01 00:00:00','fingerprint'=>'abc'];

echo "=== 1. FastPanel ready, публично self-signed → gate НЕ закрыт ===\n";
$ss=array_merge($good,['self_signed'=>true,'issuer'=>'CN=x.casino','subject'=>'CN=x.casino']);
$r=gate($ss,$clock)->verify('x.casino');
t('self-signed → ok=false', $r['ok'], false);
t('reason=self_signed', $r['reason'], 'self_signed');

echo "=== 2. Неправильный hostname → gate НЕ закрыт ===\n";
$wh=array_merge($good,['hostname_verified'=>false]);
$r=gate($wh,$clock)->verify('x.casino');
t('wrong hostname → ok=false', $r['ok'], false);
t('reason=hostname_mismatch', $r['reason'], 'hostname_mismatch');

echo "=== 3. Недоверенная цепочка → gate НЕ закрыт ===\n";
$uc=array_merge($good,['chain_verified'=>false]);
$r=gate($uc,$clock)->verify('x.casino');
t('untrusted chain → ok=false', $r['ok'], false);
t('reason=chain_untrusted', $r['reason'], 'chain_untrusted');

echo "=== 4. Валидный DDoS-Guard → gate закрыт (issuer не важен) ===\n";
$dg=array_merge($good,['issuer'=>'O=DDoS-Guard, CN=DDoS-Guard CA','self_signed'=>false]);
$r=gate($dg,$clock)->verify('x.casino');
t('DDoS-Guard valid → ok=true', $r['ok'], true);
t('source=public_live_tls', $r['source'], 'public_live_tls');
t('issuer сохранён', strpos((string)$r['issuer'],'DDoS-Guard')!==false, true);

echo "=== 5. Валидный Let's Encrypt → gate закрыт ===\n";
$r=gate($good,$clock)->verify('x.casino');
t('LE valid → ok=true', $r['ok'], true);
t('hostname_verified=true', $r['hostname_verified'], true);
t('chain_verified=true', $r['chain_verified'], true);
t('fingerprint сохранён', $r['fingerprint_sha256'], 'abc');

echo "=== 6. TLS не устанавливается → gate НЕ закрыт ===\n";
$nc=['connected'=>false];
$r=gate($nc,$clock)->verify('x.casino');
t('not connected → ok=false', $r['ok'], false);
t('reason=tls_not_established', $r['reason'], 'tls_not_established');

echo "=== 7. Просрочен / ещё не действует ===\n";
$exp=array_merge($good,['not_after'=>'2026-07-01 00:00:00']);
t('expired → ok=false reason=expired', gate($exp,$clock)->verify('x.casino')['reason'], 'expired');
$fut=array_merge($good,['not_before'=>'2026-08-01 00:00:00']);
t('not-yet-valid → reason=not_yet_valid', gate($fut,$clock)->verify('x.casino')['reason'], 'not_yet_valid');

echo "=== 8. probe кидает исключение → ok=false, не фатал ===\n";
$g=new TrustedSslGate(function($d){ throw new RuntimeException('conn refused'); },$clock);
$r=$g->verify('x.casino');
t('probe error → ok=false', $r['ok'], false);
t('reason probe_error', strpos((string)$r['reason'],'probe_error')===0, true);

echo "=== 9. пустой домен → fatal ===\n";
$r=gate($good,$clock)->verify('');
t('empty → ok=false fatal', [$r['ok'],!empty($r['fatal'])], [false,true]);

echo "=== 10. артефакт содержит все поля §3 ===\n";
$r=gate($good,$clock)->verify('x.casino');
$keys=['ok','domain','checked_at','issuer','subject','valid_from','valid_to','fingerprint_sha256','hostname_verified','chain_verified','source'];
$missing=array_diff($keys,array_keys($r));
t('все обязательные поля артефакта присутствуют', $missing, []);

echo "\n============================================================\n";
echo "ИТОГО (trusted ssl gate): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
