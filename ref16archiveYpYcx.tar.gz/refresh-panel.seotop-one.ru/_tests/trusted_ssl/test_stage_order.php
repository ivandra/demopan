<?php
/** P0 §8: статический порядок стадий — trusted_ssl_gate ДО любого Webmaster.
 *  php _tests/trusted_ssl/test_stage_order.php */
$ROOT=dirname(__DIR__,2);
require_once $ROOT.'/app/Services/RefreshOrchestrator.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function idx($stages,$s){ $i=array_search($s,$stages,true); return $i===false?-1:$i; }

foreach(['refresh','move_indexed','move_simple'] as $mode){
  echo "=== режим $mode ===\n";
  $stages=RefreshOrchestrator::pipelineStagesFor($mode,false);
  $g=idx($stages,'trusted_ssl_gate');
  $ar=idx($stages,'wm_account_resolve');
  $ad=idx($stages,'wm_added');
  $ve=idx($stages,'wm_verified');
  t("$mode: trusted_ssl_gate присутствует", $g>=0, true);
  t("$mode: trusted_ssl_gate < wm_account_resolve", ($g>=0 && $ar>=0 && $g<$ar) || $ar<0, true);
  if($ad>=0) t("$mode: wm_account_resolve < wm_added", $ar<$ad, true);
  if($ve>=0) t("$mode: wm_added < wm_verified", $ad<$ve, true);
  // барьер: ни один wm_* не встречается до trusted_ssl_gate
  $beforeGate=array_slice($stages,0,$g<0?count($stages):$g);
  $wmBefore=array_filter($beforeGate,fn($s)=>strpos($s,'wm_')===0);
  t("$mode: НЕТ ни одной wm_* стадии до gate", count($wmBefore), 0);
}

echo "=== nextStageFor: барьер перед Webmaster ===\n";
t('redirect_enable(refresh) → trusted_ssl_gate', RefreshOrchestrator::nextStageFor('redirect_enable','refresh',false), 'trusted_ssl_gate');
t('move_htaccess_redirect → trusted_ssl_gate', RefreshOrchestrator::nextStageFor('move_htaccess_redirect','move_indexed',false), 'trusted_ssl_gate');
t('trusted_ssl_gate → wm_account_resolve', RefreshOrchestrator::nextStageFor('trusted_ssl_gate','refresh',false), 'wm_account_resolve');
t('redirect_enable(move) → move_htaccess_redirect', RefreshOrchestrator::nextStageFor('redirect_enable','move_indexed',false), 'move_htaccess_redirect');
// gate НЕ в INSTANT_STAGES (барьер)
$ref=new ReflectionClass('RefreshOrchestrator');
$inst=$ref->getConstant('INSTANT_STAGES');
t('trusted_ssl_gate НЕ в INSTANT_STAGES (барьер)', in_array('trusted_ssl_gate',$inst,true), false);
t('trusted_ssl_gate В STAGES_ORDER', in_array('trusted_ssl_gate',$ref->getConstant('STAGES_ORDER'),true), true);

echo "\n============================================================\n";
echo "ИТОГО (stage order): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
