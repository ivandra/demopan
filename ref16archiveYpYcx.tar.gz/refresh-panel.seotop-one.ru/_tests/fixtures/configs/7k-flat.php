<?php
$domain = 'https://7k5269.casino';
$base_new_url    = "https://partners7k-promo.com/l/abc?sub_id=7k5241";
$base_second_url = "https://partners7k-promo.com/l/abc?sub_id=7k5241";
$internal_reg_url= "https://partners7k-promo.com/l/abc?sub_id=7k5241";
