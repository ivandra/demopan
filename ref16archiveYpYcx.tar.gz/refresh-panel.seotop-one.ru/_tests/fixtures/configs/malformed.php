<?php
$domain = = = 'https://bad
$base_new_url = "unterminated
