<?php
$redirect_enabled = 1;
$redirect_url    = "https://track.partner-pinco.com/l/abc?sub_id=pinco4002";
$internal_reg_url = "https://track.partner-pinco.com/l/abc?sub_id=pinco4002";
