<?php
$domain = 'https://r7-204.casino';
$base_new_url    = "https://r7partner.com/l/x?sub_id=r7203";
$internal_reg_url= "https://r7partner.com/l/x?sub_id=r7203";
