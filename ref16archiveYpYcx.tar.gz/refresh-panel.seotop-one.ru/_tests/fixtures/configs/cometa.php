<?php
$domain = 'https://cometa-51.casino';
$base_new_url = "https://cometapartner.com/l/x?sub_id=cometa50";
