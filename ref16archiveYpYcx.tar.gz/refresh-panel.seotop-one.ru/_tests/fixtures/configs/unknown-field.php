<?php
$domain = 'https://unk-1.casino';
$tracking_url = "https://partner.com/l/x?sub_id=unk777";
