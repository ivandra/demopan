<?php
$site = [
    'domain' => 'https://fenix51.casino',
    'redirect' => [
        'internal_reg_url' => 'https://promo-slotwinredirect.com/l/67d?sub_id=DFenix51',
        'base_new_url'     => 'https://promo-slotwinredirect.com/l/67d?sub_id=DFenix51',
        'base_second_url'  => 'https://promo-slotwinredirect.com/l/67d?sub_id=DFenix51',
    ],
];
