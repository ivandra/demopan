<?php
$domain = 'https://olymp-202.casino';
$base_new_url = "https://olymppartner.com/l/x?sub_id=olymp201";
