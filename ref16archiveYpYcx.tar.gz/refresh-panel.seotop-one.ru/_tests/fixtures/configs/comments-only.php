<?php
$domain = 'https://comm-1.casino';
// пример: $base_new_url = "https://partner.com/l/x?sub_id=example";
$base_new_url = "https://partner.com/l/x";
