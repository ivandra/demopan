<?php
$domain = 'https://plain-10.casino';
$base_new_url = "https://partner.com/l/x";
