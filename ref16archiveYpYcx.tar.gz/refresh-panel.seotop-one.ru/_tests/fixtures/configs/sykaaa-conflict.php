<?php
$domain = 'https://sykaaa-casino5.top';
$base_new_url    = "https://syka.partner.com/l/x?sub_id=syka4";
$internal_reg_url= "https://syka.partner.com/l/x?sub_id=sykaknopka";
