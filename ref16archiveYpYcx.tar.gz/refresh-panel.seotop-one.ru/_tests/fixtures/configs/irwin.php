<?php
$domain = 'https://irwin-19.casino';
$base_new_url = "https://irwinpartner.com/l/x?sub_id=Dirwincasino102";
