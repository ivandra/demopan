<?php
$domain = 'https://7k5278.casino';
$yandex_verification = "3db278f9029d03ca";
$yandex_metrika = "";
$promolink = "/reg";
$title = '7К онлайн казино - казино 7К официальный сайт';
$description = 'Играйте на официальном сайте онлайн-казино 7K! Бонусы для всех ❤️ МОЛНИЕНОСНАЯ регистрация ⚡ Быстрый вывод выигрышей!';
$keywords = "";
$h1 = 'Казино 7К: Ваше приключение в мире азартных игр';
$template = 2;
$altANDname = "7к казино"; //упоминания с названием казино в альтах и текстах. Например в альтах "Слоты 7К казино" будет заменяться "7К казино"
$shuffleGames = 1; //перемешивать игры 1-да, 0 - нет

//1 - комета (ленд без левого столбца)
//2 - комета (ленд с левым столбцом)
//3 - 7k (баннер,таблица, faq)
//4 - 7к красный ленд
//5 - 7k-casino-official.org (современный ленд)
//6 - Комента-казино (простенький ленд)

/* ===== новое/важное ===== */

/**
 * ПАРТНЁРСКАЯ ССЫЛКА-override (если заполнена — guard редиректит ТОЛЬКО сюда)
 * Пример: "https://partners7k-promo.com/l/687a7dd103e5f976b209bc3d?sub_id=vavada136x"
 */
$partner_override_url = "";

/**
 * Внутренняя ссылка для маршрута /reg (полный URL).
 * /reg обрабатывается в PHP внутри guard.php
 */
$internal_reg_url = "https://partners7k-promo.com/l/67d9467dce1a6a1a5a0494d7?sub_id=7k5275";

/** Переключатель общего редиректа в guard.php (1 — включено, 0 — выкл.) */
$redirect_enabled = 0; // REFRESH-DISABLED // REFRESH-DISABLED

/**
 * БАЗОВЫЕ ПАРТНЁРСКИЕ URL (как раньше были в guard.php).
 * Если override пустой, guard возьмёт активный домен из панели (la_get_active_domain)
 * и ЗАМЕНИТ ТОЛЬКО HOST у этих двух URL.
 */

$base_new_url    = "https://partners7k-promo.com/l/67d9467dce1a6a1a5a0494d7?sub_id=7k5275";
$base_second_url = "https://partners7k-promo.com/l/67d9467dce1a6a1a5a0494d7?sub_id=7k5275";
?>