<?php
/**
 * Реальный write-путь «⏭ Пропустить рандомизацию» (skipUpdateClasses) на rp30.
 * ОБЯЗАТЕЛЬНЫЙ DB-тест: при недоступной БД → exit 3 (SKIP=BLOCK, не 0).
 *
 * CSRF проверяется ПО-НАСТОЯЩЕМУ: requireAuth/requireCsrf НЕ подменяются, тест
 * поднимает реальную сессию с валидным токеном; отдельно проверяется csrfValid()
 * на valid/wrong/missing. Комментарий обязателен. Audit пишется атомарно.
 *   RP_DB_SOCKET=/tmp/mysqlrun/my.sock RP_DB_NAME=rp30 RP_DB_USER=root php _tests/test_uc_skip_controller.php
 */
$ROOT=dirname(__DIR__);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test, no pdo_mysql) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); }
catch(\Throwable $e){ echo "SKIPPED (mandatory DB test, DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php';
require_once $ROOT.'/app/Controllers/RefreshJobController.php';

// Реальная сессия с валидным auth + CSRF (requireAuth/requireCsrf НЕ подменяем).
@session_start();
$_SESSION['auth']=true; $_SESSION['csrf_token']='testtok';

$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

class Redirected extends \Exception {}
class TCtl extends RefreshJobController {
    public $flashes=[];
    protected function flash(string $t,string $m): void { $this->flashes[]=[$t,$m]; }
    protected function redirect(string $u): void { throw new Redirected($u); }
    public function doSkip(){ try{ $this->skipUpdateClasses(); }catch(Redirected $e){} }
}
function seedJob(PDO $p,int $id,string $status,$exec,$outcome,$verified=null){
    $p->prepare("DELETE FROM refresh_jobs WHERE id=?")->execute([$id]);
    $p->prepare("DELETE FROM refresh_job_events WHERE job_id=?")->execute([$id]);
    $uc=[]; if($outcome!==null)$uc['outcome']=$outcome;
    $p->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,stage,stage_status,uc_execution_state,php_uniquification_verified_at,artifacts_json) VALUES (?,?,?,?,?,?,?,?,?)")
      ->execute([$id,1,'old.casino','new.casino','update_classes_call',$status,$exec,$verified,json_encode(['update_classes_stage'=>$uc])]);
}
function row(PDO $p,int $id){ $s=$p->prepare("SELECT * FROM refresh_jobs WHERE id=?"); $s->execute([$id]); return $s->fetch()?:[]; }
function auditCount(PDO $p,int $id){ $s=$p->prepare("SELECT COUNT(*) FROM refresh_job_events WHERE job_id=? AND message LIKE '%operator_skipped%'"); $s->execute([$id]); return (int)$s->fetchColumn(); }
$JOB=900031;

echo "=== CSRF (реальный csrfValid, не заглушка) ===\n";
$c=new TCtl();
$_POST=['csrf_token'=>'testtok']; t('valid token → true', $c->csrfValid(), true);
$_POST=['csrf_token'=>'WRONG'];   t('wrong token → false', $c->csrfValid(), false);
$_POST=[];                        t('missing token → false', $c->csrfValid(), false);

echo "\n=== intervention (ambiguous + awaiting_user) → APPLIED с audit (real CSRF) ===\n";
seedJob($pdo,$JOB,'awaiting_user','ambiguous',null);
$_POST=['id'=>$JOB,'confirm'=>'yes','comment'=>'оператор: рандом уже применён руками','csrf_token'=>'testtok'];
(new TCtl())->doSkip();
$r=row($pdo,$JOB); $uc=(json_decode((string)$r['artifacts_json'],true)?:[])['update_classes_stage']??[];
t('outcome=operator_skipped', $uc['outcome']??'', 'operator_skipped');
t('skipped_by_operator=true', !empty($uc['skipped_by_operator']), true);
t('skipped_at заполнен', !empty($uc['skipped_at']), true);
t('comment сохранён', ($uc['comment']??'')!=='' , true);
t('uc_execution_state=operator_skipped', $r['uc_execution_state'], 'operator_skipped');
t('stage_status=ok', $r['stage_status'], 'ok');
t('gate проходит', RefreshOrchestrator::updateClassesGateSatisfied($r), true);
t('audit-запись operator_skipped есть', auditCount($pdo,$JOB)>=1, true);

echo "\n=== пустой комментарий → REJECTED (required skip reason) ===\n";
seedJob($pdo,$JOB,'awaiting_user','ambiguous',null);
$_POST=['id'=>$JOB,'confirm'=>'yes','comment'=>'   ','csrf_token'=>'testtok'];
$ctl=new TCtl(); $ctl->doSkip();
$r=row($pdo,$JOB); $uc=(json_decode((string)$r['artifacts_json'],true)?:[])['update_classes_stage']??[];
t('пустой comment: НЕ operator_skipped', ($uc['outcome']??'')!=='operator_skipped', true);
t('пустой comment: gate НЕ проходит', RefreshOrchestrator::updateClassesGateSatisfied($r), false);
t('пустой comment: flash error', count(array_filter($ctl->flashes,fn($f)=>$f[0]==='error'))>=1, true);
t('пустой comment: audit НЕ записан', auditCount($pdo,$JOB), 0);

echo "\n=== neutral (exec=NULL, outcome=NULL, waiting) → REJECTED ===\n";
seedJob($pdo,$JOB,'waiting',null,null);
$_POST=['id'=>$JOB,'confirm'=>'yes','comment'=>'причина','csrf_token'=>'testtok'];
$ctl=new TCtl(); $ctl->doSkip();
$r=row($pdo,$JOB); $uc=(json_decode((string)$r['artifacts_json'],true)?:[])['update_classes_stage']??[];
t('neutral: НЕ operator_skipped', ($uc['outcome']??'')!=='operator_skipped', true);
t('neutral: gate НЕ проходит', RefreshOrchestrator::updateClassesGateSatisfied($r), false);
t('neutral: flash error', count(array_filter($ctl->flashes,fn($f)=>$f[0]==='error'))>=1, true);

echo "\n=== confirm != yes → REJECTED ===\n";
seedJob($pdo,$JOB,'awaiting_user','ambiguous',null);
$_POST=['id'=>$JOB,'confirm'=>'','comment'=>'причина','csrf_token'=>'testtok'];
(new TCtl())->doSkip();
$r=row($pdo,$JOB); $uc=(json_decode((string)$r['artifacts_json'],true)?:[])['update_classes_stage']??[];
t('без confirm: пропуск не выполнен', ($uc['outcome']??'')!=='operator_skipped', true);

$pdo->prepare("DELETE FROM refresh_jobs WHERE id=?")->execute([$JOB]);
$pdo->prepare("DELETE FROM refresh_job_events WHERE job_id=?")->execute([$JOB]);
echo "\n============================================================\n";
echo "ИТОГО (uc skip controller): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
