<?php
/** Fleet: продолжает после ошибки одного сайта; обрабатывает COUNT(*) строк; exit 0/2/3.
 *  C04–C06. Запуск: php _tests/test_fleet.php */
$ROOT=dirname(__DIR__);
require_once $ROOT.'/app/Services/ConfigScanResult.php';
require_once $ROOT.'/app/Services/StaticSiteConfigScanner.php';
require_once $ROOT.'/app/Services/SubIdFleetScanner.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$fleet=new SubIdFleetScanner();
$okRaw="<?php\n\$redirect_url=\"https://p.com/a?sub_id=pinco4002\";\n";
$conflictRaw="<?php\n\$base_new_url=\"https://p.com/a?sub_id=x1\";\n\$internal_reg_url=\"https://p.com/b?sub_id=x2\";\n";
$fetchOk=fn($site)=>['ok'=>true,'raw'=>$site['raw']];

// C04: один сайт кидает FTP exception → остальные обработаны
$sites=[['id'=>1,'raw'=>$okRaw],['id'=>2,'raw'=>'THROW'],['id'=>3,'raw'=>$okRaw]];
$res=$fleet->run($sites, function($s){ if($s['raw']==='THROW') throw new RuntimeException('creds fail'); return ['ok'=>true,'raw'=>$s['raw']]; }, 3);
t('C04 processed=3 (не прервались)', $res['processed'], 3);
t('C04 сайт1 SAFE', $res['rows'][0]['decision'], 'SAFE');
t('C04 сайт2 FTP_ERROR', $res['rows'][1]['decision'], 'FTP_ERROR');
t('C04 сайт3 SAFE', $res['rows'][2]['decision'], 'SAFE');
t('C04 blockers=true → exit 2', $res['exit'], 2);

// C05: total=0
$res=$fleet->run([], $fetchOk, 0);
t('C05 total=0 → exit 3', $res['exit'], 3);

// processed != COUNT(*)
$res=$fleet->run([['id'=>1,'raw'=>$okRaw]], $fetchOk, 5);
t('C05b processed!=total → exit 3', $res['exit'], 3);

// C06: blockers (conflict) → exit 2 + полный report
$sites=[['id'=>1,'raw'=>$okRaw],['id'=>2,'raw'=>$conflictRaw]];
$res=$fleet->run($sites, $fetchOk, 2);
t('C06 blockers → exit 2', $res['exit'], 2);
t('C06 report полный (2 строки)', count($res['rows']), 2);
t('C06 сайт2 sub_id_conflict', $res['rows'][1]['decision'], 'sub_id_conflict');

// все SAFE → exit 0
$res=$fleet->run([['id'=>1,'raw'=>$okRaw],['id'=>2,'raw'=>$okRaw]], $fetchOk, 2);
t('ALL-SAFE → exit 0', $res['exit'], 0);
t('ALL-SAFE blockers=false', $res['blockers'], false);

// DOMAIN_ONLY не блокер
$res=$fleet->run([['id'=>1,'raw'=>"<?php\n\$domain='https://a.casino';\n\$base_new_url=\"https://p.com/x\";\n"]], $fetchOk, 1);
t('DOMAIN_ONLY → exit 0', $res['exit'], 0);
t('DOMAIN_ONLY decision', $res['rows'][0]['decision'], 'DOMAIN_ONLY');

echo "\n============================================================\n";
echo "ИТОГО (fleet): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
