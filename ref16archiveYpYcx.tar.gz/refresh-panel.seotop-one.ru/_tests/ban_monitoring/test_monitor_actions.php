<?php
/** Ручные действия /xmlstock монитора: pause/resume/stop (state + atomic audit),
 *  audit-fail → rollback, check-now без реального HTTP. Реальные auth+CSRF.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp30 RP_DB_USER=root php _tests/ban_monitoring/test_monitor_actions.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php'; require_once $ROOT.'/app/Controllers/XmlStockController.php';
$def=require $ROOT.'/app/Migrations/036_site_ban_monitoring.php'; foreach($def['up'] as $s) $s($pdo);
@session_start(); $_SESSION['auth']=true; $_SESSION['csrf_token']='tok';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
class Redir extends \Exception{}
class TX extends XmlStockController { public $fl=[];
  protected function flash(string $t,string $m):void{ $this->fl[]=[$t,$m]; }
  protected function redirect(string $u):void{ throw new Redir($u); }
  public function call(string $m){ try{ $this->$m(); }catch(Redir $e){} } }
function seed($pdo,$id){ $pdo->prepare("DELETE FROM site_ban_monitors WHERE id=?")->execute([$id]);
  $pdo->prepare("DELETE FROM refresh_job_events WHERE job_id=?")->execute([9001]);
  $pdo->prepare("INSERT INTO site_ban_monitors (id,site_id,source_job_id,domain,indexed_at,monitoring_starts_at,next_check_at,last_positive_at,state) VALUES (?,?,?,?,?,?,?,?, 'monitoring')")
    ->execute([$id,1,9001,'act.casino','2026-07-31 08:00:00','2026-07-31 20:00:00','2026-07-31 20:00:00','2026-07-31 08:00:00']); }
function mrow($pdo,$id){ $s=$pdo->prepare("SELECT * FROM site_ban_monitors WHERE id=?"); $s->execute([$id]); return $s->fetch(); }
function audits($pdo,$ev){ $s=$pdo->prepare("SELECT COUNT(*) FROM refresh_job_events WHERE job_id=9001 AND message LIKE ?"); $s->execute(['%'.$ev.'%']); return (int)$s->fetchColumn(); }
$MID=990010;

echo "=== pause → paused + atomic audit ===\n";
seed($pdo,$MID); $pdo->exec("INSERT INTO xmlstock_settings (id,enabled) VALUES (1,1) ON DUPLICATE KEY UPDATE enabled=1");
$_POST=['monitor_id'=>$MID,'csrf_token'=>'tok','comment'=>'оператор пауза'];
(new TX())->call('banMonitorPause');
$m=mrow($pdo,$MID);
t('pause: state=paused', $m['state'], 'paused');
t('pause: next_check_at=NULL', $m['next_check_at'], null);
t('pause: audit ban_monitor_paused', audits($pdo,'ban_monitor_paused')>=1, true);

echo "=== resume → monitoring + audit ===\n";
$_POST=['monitor_id'=>$MID,'csrf_token'=>'tok','comment'=>'возобновление'];
(new TX())->call('banMonitorResume');
$m=mrow($pdo,$MID);
t('resume: state=monitoring', $m['state'], 'monitoring');
t('resume: next_check_at установлен', !empty($m['next_check_at']), true);
t('resume: audit ban_monitor_resumed', audits($pdo,'ban_monitor_resumed')>=1, true);

echo "=== stop → stopped + reason + audit ===\n";
$_POST=['monitor_id'=>$MID,'csrf_token'=>'tok','comment'=>'стоп'];
(new TX())->call('banMonitorStop');
$m=mrow($pdo,$MID);
t('stop: state=stopped', $m['state'], 'stopped');
t('stop: stop_reason=operator_stopped', $m['stop_reason'], 'operator_stopped');
t('stop: audit ban_monitor_stopped', audits($pdo,'ban_monitor_stopped')>=1, true);

echo "=== CSRF: реальный csrfValid (requireCsrf не заглушён) ===\n";
$ctl=new TX();
$_POST=['csrf_token'=>'tok']; t('CSRF valid → true', $ctl->csrfValid(), true);
$_POST=['csrf_token'=>'WRONG']; t('CSRF wrong → false (действие было бы 403)', $ctl->csrfValid(), false);
$_POST=[]; t('CSRF missing → false', $ctl->csrfValid(), false);

echo "=== audit failure → rollback (state не меняется) ===\n";
seed($pdo,$MID);
$pdo->exec("RENAME TABLE refresh_job_events TO rje_tmp");
$_POST=['monitor_id'=>$MID,'csrf_token'=>'tok','comment'=>'x'];
(new TX())->call('banMonitorPause');
$pdo->exec("RENAME TABLE rje_tmp TO refresh_job_events");
$m=mrow($pdo,$MID);
t('audit fail → state НЕ paused (rollback)', $m['state'], 'monitoring');

echo "=== check-now: XMLStock выключен → без HTTP, audit manual_check ===\n";
seed($pdo,$MID);
$pdo->exec("UPDATE xmlstock_settings SET enabled=0 WHERE id=1");
$_POST=['monitor_id'=>$MID,'csrf_token'=>'tok','comment'=>'ручная'];
(new TX())->call('banMonitorCheckNow');
t('check-now: audit ban_monitor_manual_check', audits($pdo,'ban_monitor_manual_check')>=1, true);
$pdo->exec("UPDATE xmlstock_settings SET enabled=1 WHERE id=1");

$pdo->prepare("DELETE FROM site_ban_monitors WHERE id=?")->execute([$MID]);
$pdo->prepare("DELETE FROM refresh_job_events WHERE job_id=9001")->execute();
echo "\n============================================================\n";
echo "ИТОГО (monitor actions): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
