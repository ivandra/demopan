<?php
/** §17 job-card: ineligible/eligible/monitor динамически (offline рендер).
 *  php _tests/ban_monitoring/test_job_card.php */
$ROOT=dirname(__DIR__,2);
require_once $ROOT.'/app/Services/BanMonitoring/BanMonitoringPolicy.php';
require_once $ROOT.'/app/Services/IndexCheck/XmlStockLabels.php';
if(!class_exists('Time')){ eval('class Time { public static function msk($u,$f=null,$l=false){ return (string)$u; } }'); }
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function has($h,$n){ return strpos($h,$n)!==false; }
$CARD=$ROOT.'/app/Views/jobs/_ban_monitor_card.php';
function render($card,$vars){ extract($vars); ob_start(); include $card; return ob_get_clean(); }
$job=['stage'=>'index_watching','mode'=>'refresh'];

echo "=== §17.1 ineligible (нет monitor, нет generation) ===\n";
$h=render($CARD,['banMonitor'=>null,'banChecks'=>[],'banCounts'=>['today'=>0,'total'=>0],'job'=>$job,
    'banEligible'=>['eligible'=>false,'generation'=>null,'eligible_since'=>null,'enrollment_on'=>true]]);
t('текст «Не подключён»', has($h,'Не подключён'), true);
t('«без автоподключения исторических»', has($h,'Автоматического подключения исторических джоб нет'), true);
t('нет кнопки «создать автоматически»', has($h,'создать автоматически'), false);

echo "=== §17.2 eligible, monitor ещё не создан ===\n";
$h2=render($CARD,['banMonitor'=>null,'banChecks'=>[],'banCounts'=>['today'=>0,'total'=>0],'job'=>$job,
    'banEligible'=>['eligible'=>true,'generation'=>3,'eligible_since'=>'2026-07-31 08:00:00','enrollment_on'=>true]]);
t('eligible-состояние: будет подключён', has($h2,'Будет подключён после первой подтверждённой индексации'), true);
t('задержка по схеме упомянута', has($h2,'задержкой по действующей схеме'), true);

echo "=== §17.3/§17.4 monitor существует, динамика из snapshot ===\n";
$snap=json_encode(['initial_delay_minutes'=>720,'regular_interval_minutes'=>30,'probable_negative_count'=>3,'confirm_interval_minutes'=>10,'insurance_negative_count'=>3,'insurance_interval_minutes'=>10,'technical_error_retry_minutes'=>30,'telegram_retry_minutes'=>10,'telegram_max_attempts'=>20]);
$bm=['id'=>77,'source_job_id'=>186,'domain'=>'kazik.casino','state'=>'insurance','activation_generation'=>3,'policy_version'=>2,
     'indexed_at'=>'2026-07-30 08:00:00','monitoring_starts_at'=>'2026-07-30 20:00:00','last_positive_at'=>'2026-07-31 06:00:00',
     'last_positive_pages'=>4,'first_negative_at'=>'2026-07-31 18:00:00','negative_streak'=>4,'insurance_checks_done'=>1,
     'next_check_at'=>'2026-07-31 18:30:00','technical_error_count'=>0,'last_error'=>null,'policy_snapshot_json'=>$snap,
     'probable_notified_at'=>'2026-07-31 18:20:00','confirmed_notified_at'=>null,'recovered_notified_at'=>null];
$checks=[['checked_at'=>'2026-07-31 18:20:00','phase'=>'insurance','sequence_no'=>4,'result'=>'not_indexed','pages_indexed'=>0]];
$h3=render($CARD,['banMonitor'=>$bm,'banChecks'=>$checks,'banCounts'=>['today'=>4,'total'=>10],'job'=>$job,
    'banEligible'=>['eligible'=>true,'generation'=>3,'eligible_since'=>null,'enrollment_on'=>true]]);
t('policy version показан', has($h3,'policy v2'), true);
t('generation показан', has($h3,'gen 3'), true);
t('серия 4 из 6 (динамич.)', has($h3,'4 из 6'), true);
t('snapshot раскрываемый', has($h3,'policy snapshot'), true);
t('последние проверки', has($h3,'Последние проверки'), true);
t('ссылка на /xmlstock monitor', has($h3,'monitor_id=77'), true);

echo "=== §17.4 waiting_initial_delay текст (не «12 часов») ===\n";
$bmw=array_merge($bm,['state'=>'waiting_initial_delay','next_check_at'=>'2026-07-30 20:00:00']);
$hw=render($CARD,['banMonitor'=>$bmw,'banChecks'=>[],'banCounts'=>['today'=>0,'total'=>0],'job'=>$job,
    'banEligible'=>['eligible'=>true,'generation'=>3,'eligible_since'=>null,'enrollment_on'=>true]]);
t('«Ожидает первой проверки» (label из XmlStockLabels)', has($hw,'Ожидает первой проверки'), true);
t('интервал из snapshot в схеме (details)', has($hw,'первая через 720 мин'), true);
t('нет фикс. «Ожидание 12 часов»', has($hw,'Ожидание 12 часов'), false);
t('нет дублированной метки «МСК МСК»', has($h.$h2.$h3.$hw,'МСК МСК'), false);

echo "\n============================================================\n";
echo "ИТОГО (job card динамич.): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
