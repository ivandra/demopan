<?php
/** §14 Telegram-формат: ДИНАМИЧЕСКИ из policy snapshot (offline).
 *  php _tests/ban_monitoring/test_telegram_format.php */
$ROOT=dirname(__DIR__,2);
require_once $ROOT.'/app/Services/BanMonitoring/BanMonitoringPolicy.php';
// заглушка Time::msk
if(!class_exists('Time')){ eval('class Time { public static function msk($u,$f=null,$l=false){ return $u.=" MSK"; } }'); }
require_once $ROOT.'/app/Services/BanMonitoring/BanMonitorTelegramFormatter.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function has($h,$n){ return strpos($h,$n)!==false; }
$snap=json_encode(['initial_delay_minutes'=>720,'regular_interval_minutes'=>30,'probable_negative_count'=>3,'confirm_interval_minutes'=>10,'insurance_negative_count'=>3,'insurance_interval_minutes'=>10,'technical_error_retry_minutes'=>30,'telegram_retry_minutes'=>10,'telegram_max_attempts'=>20]);
$m=['id'=>77,'source_job_id'=>186,'domain'=>'kazik12.casino','indexed_at'=>'2026-07-30 08:00:00','last_positive_at'=>'2026-07-31 06:00:00','last_positive_pages'=>5,'first_negative_at'=>'2026-07-31 18:00:00','negative_streak'=>3,'next_check_at'=>'2026-07-31 18:10:00','policy_snapshot_json'=>$snap,'banned_at'=>'2026-07-31 19:00:00','stopped_at'=>'2026-07-31 19:00:00','probable_notified_at'=>'2026-07-31 18:00:00'];
$job=['mode'=>'refresh','old_domain'=>'old.casino','new_domain'=>'kazik12.casino'];
$counts=['today'=>4,'total'=>12];
$fmt=new BanMonitorTelegramFormatter('https://p.example');

echo "=== probable динамический ===\n";
$p=$fmt->probable($m,$job,$counts);
t('заголовок', has($p,'Скорее всего сайт в бане'), true);
t('домен', has($p,'kazik12.casino'), true);
t('джоба #186', has($p,'#186'), true);
t('серия 3 из 6 (динамич.)', has($p,'3 из 6'), true);
t('интервал 10 мин из snapshot', has($p,'Интервал: 10 мин'), true);
t('запросов сегодня 4 / всего 12', has($p,'сегодня 4 / всего 12'), true);
t('ссылка на monitor', has($p,'monitor_id=77'), true);
// вариант 2+4: TOTAL=6 но probable=2
$snap24=json_encode(array_merge(json_decode($snap,true),['probable_negative_count'=>2,'insurance_negative_count'=>4]));
$m24=array_merge($m,['policy_snapshot_json'=>$snap24,'negative_streak'=>2]);
$p24=$fmt->probable($m24,$job,$counts);
t('2+4: серия 2 из 6', has($p24,'2 из 6'), true);
t('2+4: подтверждающая часть 2 из 2', has($p24,'2 из 2'), true);

echo "=== confirmed динамический ===\n";
$c=$fmt->confirmed($m,$job,$counts);
t('заголовок бан', has($c,'Бан подтверждён'), true);
t('всего negative 6 (динамич.)', has($c,'Всего последовательных negative: 6'), true);
t('мониторинг остановлен', has($c,'остановлен'), true);
t('state=banned упомянут', has($c,'banned'), true);

echo "=== recovered динамический ===\n";
$mr=array_merge($m,['recovered_prev_streak'=>3]);
$r=$fmt->recovered($mr,$job,$counts);
t('заголовок не подтвердилось', has($r,'не подтвердилось'), true);
t('сброшенная серия 3 из 6', has($r,'3 из 6'), true);
t('штатная проверка каждые 30 мин', has($r,'каждые 30 мин'), true);

echo "=== §14.4: баланс не выводится если не передан ===\n";
t('нет строки баланса без данных', has($p,'Баланс XMLStock'), false);
$pb=$fmt->probable($m,$job,$counts,['value'=>'123.45','checked_at'=>'2026-07-31 18:00:00']);
t('баланс выводится если передан', has($pb,'Баланс XMLStock'), true);

echo "=== HTML-escape ===\n";
$mx=array_merge($m,['domain'=>'a<b>&"x']);
$px=$fmt->probable($mx,$job,$counts);
t('домен экранирован', has($px,'a&lt;b&gt;'), true);

echo "\n============================================================\n";
echo "ИТОГО (telegram format динамич.): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
