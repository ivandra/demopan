<?php
/** §21.1/§21.2: enrollment/generation, no-backfill eligibility, валидация, policy_version.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp30 RP_DB_USER=root php _tests/ban_monitoring/test_settings_eligibility.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
// сброс настроек к дефолту
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0, activation_generation=0, activation_started_at=NULL, activation_min_job_id=NULL, policy_version=1 WHERE id=1");
$repo=new BanMonitoringSettingsRepository($pdo);

echo "=== enrollment OFF после миграции ===\n";
t('enrollment_enabled=0', $repo->enrollmentEnabled(), false);
t('processing_enabled=1', $repo->processingEnabled(), true);
t('generation=0', $repo->activationGeneration(), 0);

echo "=== activate OFF→ON: generation+1 ===\n";
$r=$repo->activate();
t('activate changed=true', $r['changed'], true);
t('generation 0→1', $repo->activationGeneration(), 1);
$s=$repo->get();
t('activation_started_at заполнен', !empty($s['activation_started_at']), true);
t('activation_min_job_id заполнен', $s['activation_min_job_id']!==null, true);

echo "=== повторный activate идемпотентен ===\n";
$r2=$repo->activate();
t('повтор changed=false', $r2['changed'], false);
t('generation не изменилась', $repo->activationGeneration(), 1);

echo "=== eligibility присвоение (§7) ===\n";
$pdo->exec("DELETE FROM refresh_jobs WHERE id IN (950001,950002)");
$pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status) VALUES (?,1,'o','','refresh','queued','pending')")->execute([950001]);
$repo->assignEligibility(950001);
$j=$pdo->query("SELECT ban_monitor_generation,ban_monitor_eligible_at FROM refresh_jobs WHERE id=950001")->fetch();
t('enrollment ON → generation=1 присвоена', (int)$j['ban_monitor_generation'], 1);
t('eligible_at заполнен', !empty($j['ban_monitor_eligible_at']), true);
t('isEligible(job) = true', $repo->isEligible($j), true);

echo "=== deactivate → новые джобы NULL ===\n";
$repo->deactivate();
$pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status) VALUES (?,1,'o','','refresh','queued','pending')")->execute([950002]);
$repo->assignEligibility(950002);
$j2=$pdo->query("SELECT ban_monitor_generation FROM refresh_jobs WHERE id=950002")->fetch();
t('enrollment OFF → generation NULL', $j2['ban_monitor_generation'], null);
t('isEligible OFF → false', $repo->isEligible(['ban_monitor_generation'=>1]), false);

echo "=== OFF→ON снова: generation+1; старая generation больше не eligible ===\n";
$repo->activate();
t('generation 1→2', $repo->activationGeneration(), 2);
t('стар. job gen=1 при gen=2 → не eligible', $repo->isEligible($j), false); // gen=1 != 2
t('NULL generation → не eligible', $repo->isEligible(['ban_monitor_generation'=>null]), false);

echo "=== валидация policy (§4.3) ===\n";
t('regular=3 (мин 5) → ошибка', count($repo->validate(['regular_interval_minutes'=>3]))>0, true);
t('probable=0 (мин 1) → ошибка', count($repo->validate(['probable_negative_count'=>0]))>0, true);
t('insurance=0 (мин 0) → ОК', count($repo->validate(['insurance_negative_count'=>0])), 0);
t('initial_delay=20000 (макс 10080) → ошибка', count($repo->validate(['initial_delay_minutes'=>20000]))>0, true);
t('валидные значения → ок', count($repo->validate(['regular_interval_minutes'=>30,'probable_negative_count'=>3])), 0);

echo "=== savePolicy → policy_version+1 ===\n";
$v0=(int)$repo->get()['policy_version'];
$err=$repo->savePolicy(['regular_interval_minutes'=>45]);
t('savePolicy без ошибок', count($err), 0);
t('policy_version+1', (int)$repo->get()['policy_version'], $v0+1);
t('значение применено', (int)$repo->get()['regular_interval_minutes'], 45);
$err2=$repo->savePolicy(['regular_interval_minutes'=>2]);
t('savePolicy невалидное → ошибка, версия не растёт', [count($err2)>0,(int)$repo->get()['policy_version']], [true,$v0+1]);

$pdo->exec("DELETE FROM refresh_jobs WHERE id IN (950001,950002)");
$pdo->exec("UPDATE ban_monitoring_settings SET regular_interval_minutes=30, enrollment_enabled=0 WHERE id=1");
echo "\n============================================================\n";
echo "ИТОГО (settings/eligibility): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
