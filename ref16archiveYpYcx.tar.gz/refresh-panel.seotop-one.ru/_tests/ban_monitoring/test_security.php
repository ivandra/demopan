<?php
/** §21.7 security: activation CSRF+strict-audit, resume continue/reset, обязательный комментарий.
 *  RP_DB_SOCKET=... php _tests/ban_monitoring/test_security.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php'; require_once $ROOT.'/app/Controllers/XmlStockController.php';
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
@session_start(); $_SESSION['auth']=true; $_SESSION['csrf_token']='tok';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
class Redir2 extends \Exception{}
class TXS extends XmlStockController { public $fl=[];
  protected function flash(string $t,string $m):void{ $this->fl[]=[$t,$m]; }
  protected function redirect(string $u):void{ throw new Redir2($u); }
  public function call(string $m){ $this->fl=[]; try{ $this->$m(); }catch(Redir2 $e){} } }
$ctl=new TXS();
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0, activation_generation=0, processing_enabled=1, policy_version=1, regular_interval_minutes=30 WHERE id=1");
$pdo->exec("DELETE FROM ban_monitoring_audit");
function auditCnt($pdo,$action){ $s=$pdo->prepare("SELECT COUNT(*) FROM ban_monitoring_audit WHERE action=?"); $s->execute([$action]); return (int)$s->fetchColumn(); }
function gen($pdo){ return (int)$pdo->query("SELECT activation_generation FROM ban_monitoring_settings WHERE id=1")->fetchColumn(); }

echo "=== activate-new-jobs: CSRF ok → generation+1 + strict audit ===\n";
$_POST=['csrf_token'=>'tok','comment'=>'первая активация']; $ctl->call('banActivateNewJobs');
t('generation стала 1', gen($pdo), 1);
t('audit ban_activate_new_jobs записан', auditCnt($pdo,'ban_activate_new_jobs'), 1);
$au=$pdo->query("SELECT * FROM ban_monitoring_audit WHERE action='ban_activate_new_jobs' ORDER BY id DESC LIMIT 1")->fetch();
t('audit содержит old/new', !empty($au['old_values'])&&!empty($au['new_values']), true);
t('audit содержит comment', strpos((string)$au['comment'],'первая активация')!==false, true);

echo "=== activate повторно → идемпотентно (generation не растёт) ===\n";
$_POST=['csrf_token'=>'tok','comment'=>'повтор']; $ctl->call('banActivateNewJobs');
t('generation осталась 1', gen($pdo), 1);

echo "=== CSRF wrong → csrfValid false (действие 403) ===\n";
$_POST=['csrf_token'=>'WRONG']; t('csrf wrong → false', $ctl->csrfValid(), false);
$_POST=[]; t('csrf missing → false', $ctl->csrfValid(), false);

echo "=== toggle-processing: пустой комментарий → rejected ===\n";
$before=(int)$pdo->query("SELECT processing_enabled FROM ban_monitoring_settings WHERE id=1")->fetchColumn();
$_POST=['csrf_token'=>'tok','processing'=>'0','comment'=>'']; $ctl->call('banToggleProcessing');
t('processing не изменился (нужен комментарий)', (int)$pdo->query("SELECT processing_enabled FROM ban_monitoring_settings WHERE id=1")->fetchColumn(), $before);
$_POST=['csrf_token'=>'tok','processing'=>'0','comment'=>'пауза обработки']; $ctl->call('banToggleProcessing');
t('с комментарием processing=0', (int)$pdo->query("SELECT processing_enabled FROM ban_monitoring_settings WHERE id=1")->fetchColumn(), 0);
t('audit toggle_processing', auditCnt($pdo,'ban_toggle_processing'), 1);
$pdo->exec("UPDATE ban_monitoring_settings SET processing_enabled=1 WHERE id=1");

echo "=== save-policy: валидация + version+1 ===\n";
$v0=(int)$pdo->query("SELECT policy_version FROM ban_monitoring_settings WHERE id=1")->fetchColumn();
$_POST=['csrf_token'=>'tok','regular_interval_minutes'=>'3']; $ctl->call('banSavePolicy'); // 3<5 → ошибка
t('невалидное отклонено (version не растёт)', (int)$pdo->query("SELECT policy_version FROM ban_monitoring_settings WHERE id=1")->fetchColumn(), $v0);
$_POST=['csrf_token'=>'tok','regular_interval_minutes'=>'45','comment'=>'смена']; $ctl->call('banSavePolicy');
t('валидное → version+1', (int)$pdo->query("SELECT policy_version FROM ban_monitoring_settings WHERE id=1")->fetchColumn(), $v0+1);
t('audit save_policy', auditCnt($pdo,'ban_save_policy'), 1);

echo "=== resume continue/reset semantics (§18.5) ===\n";
$MID=990077;
$snap=json_encode(['regular_interval_minutes'=>30,'confirm_interval_minutes'=>10,'insurance_interval_minutes'=>10,'probable_negative_count'=>3,'insurance_negative_count'=>3,'initial_delay_minutes'=>720,'technical_error_retry_minutes'=>30,'telegram_retry_minutes'=>10,'telegram_max_attempts'=>20]);
function seedPaused($pdo,$id,$snap){ $pdo->prepare("DELETE FROM site_ban_monitors WHERE id=?")->execute([$id]);
  $pdo->prepare("INSERT INTO site_ban_monitors (id,site_id,source_job_id,domain,indexed_at,monitoring_starts_at,next_check_at,last_positive_at,state,negative_streak,paused_from_state,paused_next_check_at,policy_snapshot_json) VALUES (?,?,?,?,?,?,?,?, 'paused', 4, 'insurance', '2026-07-31 18:30:00', ?)")
    ->execute([$id,1,9002,'res.casino','2026-07-30 08:00:00','2026-07-30 20:00:00',null,'2026-07-31 06:00:00',$snap]); }
seedPaused($pdo,$MID,$snap);
$_POST=['csrf_token'=>'tok','monitor_id'=>$MID,'resume_mode'=>'continue','comment'=>'продолжить']; $ctl->call('banMonitorResume');
$m=$pdo->query("SELECT * FROM site_ban_monitors WHERE id=$MID")->fetch();
t('continue → восстановил фазу insurance', $m['state'], 'insurance');
t('continue → streak сохранён (4)', (int)$m['negative_streak'], 4);
seedPaused($pdo,$MID,$snap);
$_POST=['csrf_token'=>'tok','monitor_id'=>$MID,'resume_mode'=>'reset','comment'=>'сброс']; $ctl->call('banMonitorResume');
$m2=$pdo->query("SELECT * FROM site_ban_monitors WHERE id=$MID")->fetch();
t('reset → state=monitoring', $m2['state'], 'monitoring');
t('reset → streak=0', (int)$m2['negative_streak'], 0);

echo "=== stop: обязателен комментарий (§18.3) ===\n";
$pdo->prepare("UPDATE site_ban_monitors SET state='monitoring' WHERE id=?")->execute([$MID]);
$_POST=['csrf_token'=>'tok','monitor_id'=>$MID,'comment'=>'']; $ctl->call('banMonitorStop');
t('пустой комментарий → не остановлен', $pdo->query("SELECT state FROM site_ban_monitors WHERE id=$MID")->fetchColumn(), 'monitoring');
$_POST=['csrf_token'=>'tok','monitor_id'=>$MID,'comment'=>'причина стопа']; $ctl->call('banMonitorStop');
t('с комментарием → stopped', $pdo->query("SELECT state FROM site_ban_monitors WHERE id=$MID")->fetchColumn(), 'stopped');

$pdo->exec("DELETE FROM site_ban_monitors WHERE id=$MID");
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0 WHERE id=1");
echo "\n============================================================\n";
echo "ИТОГО (security §21.7): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
