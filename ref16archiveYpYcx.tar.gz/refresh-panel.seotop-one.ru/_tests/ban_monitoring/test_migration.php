<?php
/** AC17: миграция 036 up/down/idempotent на реальной MariaDB.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp30 RP_DB_USER=root php _tests/ban_monitoring/test_migration.php */
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test, no pdo_mysql) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tblExists(PDO $p,string $t):bool{ $s=$p->query("SHOW TABLES LIKE ".$p->quote($t)); return (bool)$s->fetch(); }
function colExists(PDO $p,string $t,string $c):bool{ $s=$p->query("SHOW COLUMNS FROM `$t` LIKE ".$p->quote($c)); return (bool)$s->fetch(); }

$def=require dirname(__DIR__,2).'/app/Migrations/036_site_ban_monitoring.php';
// чистим на всякий случай
foreach($def['down'] as $s) $s($pdo);

echo "=== UP ===\n";
foreach($def['up'] as $s) $s($pdo);
t('site_ban_monitors создана', tblExists($pdo,'site_ban_monitors'), true);
t('xmlstock_request_log создана', tblExists($pdo,'xmlstock_request_log'), true);
t('site_ban_monitor_checks создана', tblExists($pdo,'site_ban_monitor_checks'), true);
t('monitors.state есть', colExists($pdo,'site_ban_monitors','state'), true);
t('monitors.negative_streak есть', colExists($pdo,'site_ban_monitors','negative_streak'), true);
t('log.assumed_charged есть', colExists($pdo,'xmlstock_request_log','assumed_charged'), true);
t('log.request_uuid есть', colExists($pdo,'xmlstock_request_log','request_uuid'), true);
t('checks.phase есть', colExists($pdo,'site_ban_monitor_checks','phase'), true);
// UNIQUE и FK
$uq=$pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='site_ban_monitors' AND INDEX_NAME='uq_ban_monitor_job_domain'")->fetchColumn();
t('UNIQUE (source_job_id,domain)', (int)$uq>0, true);
$fk=$pdo->query("SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='site_ban_monitor_checks' AND CONSTRAINT_TYPE='FOREIGN KEY'")->fetchColumn();
t('FK checks→monitors', (int)$fk>0, true);

echo "\n=== IDEMPOTENT re-UP ===\n";
try{ foreach($def['up'] as $s) $s($pdo); t('повторный up без ошибки', true, true); }
catch(\Throwable $e){ t('повторный up без ошибки', $e->getMessage(), true); }

echo "\n=== DOWN ===\n";
foreach($def['down'] as $s) $s($pdo);
t('monitors удалена', tblExists($pdo,'site_ban_monitors'), false);
t('request_log удалена', tblExists($pdo,'xmlstock_request_log'), false);
t('checks удалена', tblExists($pdo,'site_ban_monitor_checks'), false);

echo "\n=== re-UP для остальных тестов ===\n";
foreach($def['up'] as $s) $s($pdo);
t('таблицы восстановлены', tblExists($pdo,'site_ban_monitors'), true);

// пост-восстановление: 036 down/up пересоздаёт таблицы — доганяем 037+038,
// чтобы последующие тесты видели полную актуальную схему.
$__mroot=dirname(__DIR__,2);
foreach(['037_ban_monitoring_activation_policy','038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){
    $d2=require $__mroot."/app/Migrations/$mg.php"; foreach($d2['up'] as $s2) $s2($pdo);
}
echo "\n============================================================\n";
echo "ИТОГО (migration): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
