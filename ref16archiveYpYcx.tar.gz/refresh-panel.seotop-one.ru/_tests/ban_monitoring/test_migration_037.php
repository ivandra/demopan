<?php
/** AC17 (PATCH_2): миграция 037 up/down/idempotent + v2-cutover + no-backfill.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp30 RP_DB_USER=root php _tests/ban_monitoring/test_migration_037.php */
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
$ROOT=dirname(__DIR__,2);
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function col($p,$t,$c){ $s=$p->query("SHOW COLUMNS FROM `$t` LIKE ".$p->quote($c)); return (bool)$s->fetch(); }
function tbl($p,$t){ return (bool)$p->query("SHOW TABLES LIKE ".$p->quote($t))->fetch(); }

$d36=require $ROOT.'/app/Migrations/036_site_ban_monitoring.php';
$d37=require $ROOT.'/app/Migrations/037_ban_monitoring_activation_policy.php';
// чистый старт
foreach($d37['down'] as $s) $s($pdo); foreach($d36['down'] as $s) $s($pdo);
foreach($d36['up'] as $s) $s($pdo);

// подготовим legacy active monitor (как от v1) + историческую джобу
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain='legacy.casino'");
$pdo->prepare("INSERT INTO site_ban_monitors (site_id,source_job_id,domain,indexed_at,monitoring_starts_at,next_check_at,last_positive_at,state) VALUES (?,?,?,?,?,?,?, 'waiting_12h')")
    ->execute([1,660001,'legacy.casino','2026-07-31 08:00:00','2026-07-31 20:00:00','2026-07-31 20:00:00','2026-07-31 08:00:00']);
$histJobMax=(int)$pdo->query("SELECT COALESCE(MAX(id),0) FROM refresh_jobs")->fetchColumn();

echo "=== UP 037 ===\n";
foreach($d37['up'] as $s) $s($pdo);
t('ban_monitoring_settings создана', tbl($pdo,'ban_monitoring_settings'), true);
t('settings id=1 enrollment=0', (int)$pdo->query("SELECT enrollment_enabled FROM ban_monitoring_settings WHERE id=1")->fetchColumn(), 0);
t('settings processing=1', (int)$pdo->query("SELECT processing_enabled FROM ban_monitoring_settings WHERE id=1")->fetchColumn(), 1);
t('refresh_jobs.ban_monitor_generation', col($pdo,'refresh_jobs','ban_monitor_generation'), true);
t('site_ban_monitors.policy_snapshot_json', col($pdo,'site_ban_monitors','policy_snapshot_json'), true);
t('site_ban_monitors.activation_generation', col($pdo,'site_ban_monitors','activation_generation'), true);
t('ban_monitor_notifications создана', tbl($pdo,'ban_monitor_notifications'), true);
t('request_log.execution_state', col($pdo,'xmlstock_request_log','execution_state'), true);
t('request_log.http_attempted', col($pdo,'xmlstock_request_log','http_attempted'), true);
$uq=$pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='site_ban_monitor_checks' AND INDEX_NAME='uq_ban_check_request'")->fetchColumn();
t('UNIQUE check→request', (int)$uq>0, true);

echo "=== v2-cutover + waiting_initial_delay + no-backfill ===\n";
$lm=$pdo->query("SELECT state,stop_reason FROM site_ban_monitors WHERE domain='legacy.casino'")->fetch();
t('legacy monitor stopped', $lm['state'], 'stopped');
t('stop_reason=v2_cutover_no_backfill', $lm['stop_reason'], 'v2_cutover_no_backfill');
t('нет waiting_12h (переведён)', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE state='waiting_12h'")->fetchColumn(), 0);
t('historical jobs: generation НЕ присвоена', (int)$pdo->query("SELECT COUNT(*) FROM refresh_jobs WHERE ban_monitor_generation IS NOT NULL")->fetchColumn(), 0);
t('миграция НЕ создала monitor (no-backfill)', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE created_at>=NOW()-INTERVAL 5 SECOND AND stop_reason IS NULL")->fetchColumn(), 0);

echo "=== IDEMPOTENT re-UP ===\n";
$gen0=(int)$pdo->query("SELECT activation_generation FROM ban_monitoring_settings WHERE id=1")->fetchColumn();
try{ foreach($d37['up'] as $s) $s($pdo); t('повтор up без ошибки', true, true); }
catch(\Throwable $e){ t('повтор up без ошибки', $e->getMessage(), true); }
t('generation не изменилась при повторе', (int)$pdo->query("SELECT activation_generation FROM ban_monitoring_settings WHERE id=1")->fetchColumn(), $gen0);

echo "=== DOWN ===\n";
foreach($d37['down'] as $s) $s($pdo);
t('settings удалена', tbl($pdo,'ban_monitoring_settings'), false);
t('notifications удалена', tbl($pdo,'ban_monitor_notifications'), false);
t('refresh_jobs.ban_monitor_generation удалён', col($pdo,'refresh_jobs','ban_monitor_generation'), false);
t('request_log.execution_state удалён', col($pdo,'xmlstock_request_log','execution_state'), false);
// re-up для остальных тестов
foreach($d37['up'] as $s) $s($pdo);
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain='legacy.casino'");

echo "\n============================================================\n";
echo "ИТОГО (migration 037): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
