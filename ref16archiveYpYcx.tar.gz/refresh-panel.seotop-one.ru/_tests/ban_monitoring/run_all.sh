#!/usr/bin/env bash
# run_all.sh (PATCH_2) — единый раннер. SKIP обязательного DB-теста = BLOCK (exit≠0),
# НЕ pass и НЕ exit 0. READY_TO_INSTALL=YES только при полном обязательном наборе.
#   RP_DB_SOCKET=/tmp/mysqlrun/my.sock RP_DB_NAME=rp30 RP_DB_USER=root bash _tests/ban_monitoring/run_all.sh
set -uo pipefail
cd "$(dirname "$0")/../.."   # -> public_html
PASS=0; FAIL=0; BLOCK=0

run(){ local name="$1" mandatory="$2"; shift 2; echo "──────── ${name}"; local out rc
  out="$(php "$@" 2>&1)"; rc=$?
  echo "$out" | tail -2
  if [ $rc -eq 3 ] || echo "$out" | grep -q 'SKIPPED'; then
    if [ "$mandatory" = "1" ]; then BLOCK=$((BLOCK+1)); echo "  → BLOCK (обязательный DB-тест пропущен, НЕ pass)";
    else echo "  → skip (offline не обязателен)"; fi
  elif [ $rc -eq 0 ] && echo "$out" | grep -q 'FAIL=0'; then PASS=$((PASS+1)); echo "  → PASS";
  else FAIL=$((FAIL+1)); echo "  → FAIL (exit $rc)"; fi
  echo; }

echo "########## PHP LINT изменённого дерева ##########"
LINT_FAIL=0
for f in \
  app/Services/BanMonitoring/BanMonitoringPolicy.php \
  app/Services/BanMonitoring/BanMonitoringSettingsRepository.php \
  app/Services/BanMonitoring/BanMonitorDecision.php \
  app/Services/BanMonitoring/BanMonitorRepository.php \
  app/Services/BanMonitoring/BanMonitorService.php \
  app/Services/BanMonitoring/BanMonitorEnrollmentService.php \
  app/Services/BanMonitoring/BanMonitorNotificationRepository.php \
  app/Services/BanMonitoring/BanMonitorNotificationService.php \
  app/Services/BanMonitoring/BanMonitorTelegramFormatter.php \
  app/Services/IndexCheck/XmlStockRequestContext.php \
  app/Services/IndexCheck/XmlStockUsageRepository.php \
  app/Services/IndexCheck/XmlStockRequestService.php \
  app/Services/IndexCheck/XmlStockIndexCheck.php \
  app/Services/IndexCheckOrchestrator.php \
  app/Services/RefreshOrchestrator.php \
  app/Services/RelocationIndexChecker.php \
  app/Services/JobLifecycleService.php \
  app/Services/JobEventLogger.php \
  app/Controllers/CronController.php \
  app/Controllers/XmlStockController.php \
  app/Controllers/RefreshJobController.php \
  app/Controllers/SettingsController.php \
  app/Views/xmlstock/index.php \
  app/Views/jobs/show.php \
  app/Views/jobs/_ban_monitor_card.php \
  app/Migrations/036_site_ban_monitoring.php \
  app/Migrations/037_ban_monitoring_activation_policy.php \
  public/index.php bin/_bootstrap.php ; do
  if ! php -l "$f" >/dev/null 2>&1; then echo "  LINT FAIL: $f"; LINT_FAIL=$((LINT_FAIL+1)); fi
done
[ "$LINT_FAIL" -eq 0 ] && echo "  lint OK (все файлы)" || echo "  LINT ОШИБОК: $LINT_FAIL"
echo

echo "########## OFFLINE тесты ##########"
run "state machine (§9 динамич.)"     0 _tests/ban_monitoring/test_state_machine.php
run "telegram format (§14 динамич.)"  0 _tests/ban_monitoring/test_telegram_format.php
run "job card (§17 динамич.)"         0 _tests/ban_monitoring/test_job_card.php

echo "########## DB тесты (обязательные, SKIP=BLOCK) ##########"
run "migration 036 (AC17)"              1 _tests/ban_monitoring/test_migration.php
run "migration 037 (§5, no-backfill)"  1 _tests/ban_monitoring/test_migration_037.php
run "settings/eligibility (§3,§7)"     1 _tests/ban_monitoring/test_settings_eligibility.php
run "exactly-once (§11)"               1 _tests/xmlstock_usage/test_exactly_once.php
run "xmlstock ui (§16.3,§16.6)"        1 _tests/xmlstock_usage/test_xmlstock_ui.php
run "ban service (§8,§13,arm)"         1 _tests/ban_monitoring/test_service.php
run "integration (§21.1,§21.4)"        1 _tests/ban_monitoring/test_integration.php
run "monitor actions (§18)"            1 _tests/ban_monitoring/test_monitor_actions.php
run "security (§21.7)"                 1 _tests/ban_monitoring/test_security.php

echo "════════════════════════════════════════════════════════════"
echo "LINT_FAIL=${LINT_FAIL}  PASS=${PASS}  FAIL=${FAIL}  BLOCKED=${BLOCK}"
if [ "$LINT_FAIL" -eq 0 ] && [ "$FAIL" -eq 0 ] && [ "$BLOCK" -eq 0 ]; then
  echo "READY_TO_INSTALL=YES"; exit 0
fi
echo "READY_TO_INSTALL=NO"
{ [ "$FAIL" -ne 0 ] || [ "$LINT_FAIL" -ne 0 ]; } && exit 1
exit 2
