<?php
/** §2.4.1/§11.2.2-5: реальный cutoff automatic enrollment (id+created_at+eligible_at+generation
 *  под FOR UPDATE); manual bootstrap — явное исключение с enrollment_source.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/ban_monitoring/test_cutoff.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp31t'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

// Снимок настроек для восстановления (тест на боевой копии).
$SNAP=$pdo->query("SELECT * FROM ban_monitoring_settings WHERE id=1")->fetch();
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 996000 AND 996999");
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'cut-%'");
// Синтетический cutoff: generation=5, min_job_id=996500, started_at=2026-08-01 10:00:00
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=1, activation_generation=5, activation_min_job_id=996500, activation_started_at='2026-08-01 10:00:00' WHERE id=1");
$set=new BanMonitoringSettingsRepository($pdo);
function mkjob($pdo,$id,$dom,$created,$gen=null,$elig=null){
  $pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,ban_monitor_generation,ban_monitor_eligible_at,created_at) VALUES (?,?,?,?,'refresh','index_watching','pending',?,?,?)")
      ->execute([$id,1,'o.casino',$dom,$gen,$elig,$created]); }
function jgen($pdo,$id){ return $pdo->query("SELECT ban_monitor_generation FROM refresh_jobs WHERE id=$id")->fetchColumn(); }

echo "=== §11.2.2 assignEligibility: джоба ДО cutoff (id<min) НЕ получает generation ===\n";
mkjob($pdo,996001,'cut-a.casino','2026-08-01 11:00:00'); // id < 996500
$set->assignEligibility(996001);
t('id<min → generation NULL', jgen($pdo,996001), null);

echo "=== created_at < started_at → НЕ получает ===\n";
mkjob($pdo,996501,'cut-b.casino','2026-08-01 09:00:00'); // id ok, created рано
$set->assignEligibility(996501);
t('created<started → generation NULL', jgen($pdo,996501), null);

echo "=== §11.2.3 джоба ПОСЛЕ cutoff получает generation+eligible_at ===\n";
mkjob($pdo,996502,'cut-c.casino','2026-08-01 11:00:00');
$set->assignEligibility(996502);
t('после cutoff → generation=5', (int)jgen($pdo,996502), 5);
t('eligible_at установлен', !empty($pdo->query("SELECT ban_monitor_eligible_at FROM refresh_jobs WHERE id=996502")->fetchColumn()), true);

echo "=== §11.2.4 arm() повторяет проверку под FOR UPDATE ===\n";
$enr=new BanMonitorEnrollmentService($pdo, new BanMonitorRepository($pdo), $set);
$T=new DateTimeImmutable('2026-08-01 12:00:00', new DateTimeZone('UTC'));
// (а) джоба до cutoff с ПОДДЕЛАННОЙ generation (прямой UPDATE) → arm отклоняет по id
$pdo->exec("UPDATE refresh_jobs SET ban_monitor_generation=5, ban_monitor_eligible_at='2026-08-01 11:00:00' WHERE id=996001");
$r=$enr->arm(996001, 1, 'cut-a.casino', $T, 3);
t('arm: id<min несмотря на generation → rejected', $r['armed'], false);
t('reason=before_cutoff_id', $r['reason'], 'before_cutoff_id');
// (б) created_at до started_at → rejected
$pdo->exec("UPDATE refresh_jobs SET ban_monitor_generation=5, ban_monitor_eligible_at='2026-08-01 11:00:00' WHERE id=996501");
$r=$enr->arm(996501, 1, 'cut-b.casino', $T, 3);
t('arm: created<started → rejected', $r['reason'], 'before_cutoff_created');
// (в) eligible_at до started_at → rejected
mkjob($pdo,996503,'cut-d.casino','2026-08-01 11:00:00',5,'2026-08-01 09:30:00');
$r=$enr->arm(996503, 1, 'cut-d.casino', $T, 3);
t('arm: eligible_at<started → rejected', $r['reason'], 'before_cutoff_eligible');
// (г) полностью валидная automatic → armed, enrollment_source=automatic
$r=$enr->arm(996502, 1, 'cut-c.casino', $T, 3);
t('валидная automatic → armed', $r['armed'], true);
$src=$pdo->query("SELECT enrollment_source FROM site_ban_monitors WHERE source_job_id=996502")->fetchColumn();
t('enrollment_source=automatic', $src, 'automatic');

echo "=== §11.2.5 manual bootstrap: только явный id, маркируется manual ===\n";
// джоба до cutoff, generation присвоен bootstrap'ом → arm с source=manual_bootstrap проходит
$pdo->exec("UPDATE refresh_jobs SET ban_monitor_generation=5, ban_monitor_eligible_at=NOW() WHERE id=996001");
$r=$enr->arm(996001, 2, 'cut-a.casino', $T, 3, 'manual_bootstrap');
t('manual: до cutoff → armed (осознанное исключение)', $r['armed'], true);
$src=$pdo->query("SELECT enrollment_source FROM site_ban_monitors WHERE source_job_id=996001")->fetchColumn();
t('enrollment_source=manual_bootstrap', $src, 'manual_bootstrap');
// manual при выключенном enrollment → всё равно rejected
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0 WHERE id=1");
mkjob($pdo,996504,'cut-e.casino','2026-08-01 11:00:00',5,'2026-08-01 11:00:00');
$r=$enr->arm(996504, 3, 'cut-e.casino', $T, 3, 'manual_bootstrap');
t('manual при enrollment OFF → rejected', $r['reason'], 'enrollment_disabled');
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=1 WHERE id=1");

echo "=== BootstrapService передаёт manual_bootstrap (сквозной) ===\n";
$checks=['cut-f.casino'=>['classification'=>'positive','pages'=>4,'completed_at'=>'2026-08-01 12:00:00']];
$runner=function($d) use ($checks){ return $checks[$d] ?? ['classification'=>'technical_error','pages'=>0,'completed_at'=>null]; };
mkjob($pdo,996010,'cut-f.casino','2026-08-01 09:00:00'); // до cutoff по created
$svc=new BanMonitorBootstrapService($pdo,$set,new BanMonitorRepository($pdo),$runner);
$res=$svc->bootstrap([996010],'op','тест cutoff-исключения');
t('bootstrap до-cutoff джобы → armed', !empty($res[0]['armed']), true);
$src=$pdo->query("SELECT enrollment_source FROM site_ban_monitors WHERE source_job_id=996010")->fetchColumn();
t('bootstrap-монитор помечен manual_bootstrap', $src, 'manual_bootstrap');

echo "=== боевые мониторы #1/#2 после 038 помечены manual_bootstrap (Сценарий B) ===\n";
$rows=$pdo->query("SELECT id,enrollment_source FROM site_ban_monitors WHERE id IN (1,2) ORDER BY id")->fetchAll();
t('мониторы 1 и 2 = manual_bootstrap', array_column($rows,'enrollment_source'), ['manual_bootstrap','manual_bootstrap']);

// восстановление настроек и чистка
$pdo->prepare("UPDATE ban_monitoring_settings SET enrollment_enabled=?,activation_generation=?,activation_min_job_id=?,activation_started_at=? WHERE id=1")
    ->execute([$SNAP['enrollment_enabled'],$SNAP['activation_generation'],$SNAP['activation_min_job_id'],$SNAP['activation_started_at']]);
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'cut-%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 996000 AND 996999");
echo "\n============================================================\n";
echo "ИТОГО (cutoff §2.4.1): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
