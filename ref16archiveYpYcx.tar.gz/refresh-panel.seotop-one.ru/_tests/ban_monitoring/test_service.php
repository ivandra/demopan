<?php
/** PATCH_2 ядро: enrollment atomic arm/supersede/eligibility (§21.6/§21.1) + полная
 *  последовательность с policy snapshot + Telegram outbox (§21.5) + exactly-once replay.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp30 RP_DB_USER=root php _tests/ban_monitoring/test_service.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
$pdo->exec("INSERT INTO xmlstock_settings (id,enabled) VALUES (1,1) ON DUPLICATE KEY UPDATE enabled=1");
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
// чистка
$pdo->exec("DELETE FROM ban_monitor_notifications"); $pdo->exec("DELETE FROM site_ban_monitor_checks");
// чистим ТОЛЬКО свои фикстуры — тест гоняется на копии боевой БД (§1.1)
$pdo->exec("DELETE FROM ban_monitor_notifications WHERE monitor_id IN (SELECT id FROM site_ban_monitors WHERE domain LIKE 'svc-%')");
$pdo->exec("DELETE FROM site_ban_monitor_checks WHERE monitor_id IN (SELECT id FROM site_ban_monitors WHERE domain LIKE 'svc-%')");
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'svc-%'"); $pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'svc-%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 990100 AND 990199");
$pdo->exec("DELETE FROM refresh_job_events WHERE job_id BETWEEN 990100 AND 990199");
// быстрая policy для теста
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0, activation_generation=0, initial_delay_minutes=1, regular_interval_minutes=5, probable_negative_count=3, confirm_interval_minutes=1, insurance_negative_count=3, insurance_interval_minutes=1, telegram_retry_minutes=1, telegram_max_attempts=3 WHERE id=1");
$set=new BanMonitoringSettingsRepository($pdo);
function mkjob($pdo,$id,$site,$dom,$gen){ $pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,ban_monitor_generation,ban_monitor_eligible_at,created_at) VALUES (?,?,?,?,'refresh','done','ok',?,IF(? IS NULL,NULL,NOW()),NOW())")->execute([$id,$site,'old.example',$dom,$gen,$gen]); }

$T=new DateTimeImmutable('2026-07-31 08:00:00',new DateTimeZone('UTC'));
$clock=function() use (&$T){ return $T; };
$calls=0; $nextResult=['ok'=>true,'indexed'=>true,'pages_indexed'=>1];
$transport=function($c) use (&$calls,&$nextResult){ $calls++; return $nextResult; };
$req=new XmlStockRequestService($transport,new XmlStockUsageRepository($pdo),$clock,fn()=>true);
$tgTexts=[]; $tg=function($s) use (&$tgTexts){ $tgTexts[]=$s; return true; };
$svc=new BanMonitorService(new BanMonitorRepository($pdo),$req,new XmlStockUsageRepository($pdo),
    new BanMonitorTelegramFormatter('https://p.example'),$clock,
    fn($id)=>['id'=>$id,'mode'=>'refresh','old_domain'=>'old.example','new_domain'=>'svc-a.casino'],
    $set,new BanMonitorNotificationRepository($pdo));

echo "=== §21.1: enrollment OFF → arm rejected (no generation) ===\n";
mkjob($pdo,990100,700,'svc-a.casino',null);
$r=$svc->armFromXmlStockIndexed(990100,700,'svc-a.casino',$T,1);
t('OFF/no-gen: armed=false', $r['armed'], false);
t('reason enrollment_disabled|no_generation', in_array($r['reason'],['enrollment_disabled','no_generation'],true), true);
t('not_eligible job-event записан', (int)$pdo->query("SELECT COUNT(*) FROM refresh_job_events WHERE job_id=990100 AND message LIKE '%not_eligible%' OR (job_id=990100 AND payload_json LIKE '%not_eligible%')")->fetchColumn()>=1, true);

echo "=== активация + eligible job → atomic arm со snapshot ===\n";
$pdo->beginTransaction(); $set->activate(); $pdo->commit();
$gen=$set->activationGeneration();
mkjob($pdo,990101,701,'svc-a.casino',$gen);
$r=$svc->armFromXmlStockIndexed(990101,701,'svc-a.casino',$T,2);
t('armed=true', $r['armed'], true);
$mid=(int)$r['monitor_id'];
$m=$pdo->query("SELECT * FROM site_ban_monitors WHERE id={$mid}")->fetch();
t('state=waiting_initial_delay', $m['state'], 'waiting_initial_delay');
t('policy_snapshot_json заполнен', !empty($m['policy_snapshot_json']), true);
t('activation_generation в мониторе', (int)$m['activation_generation'], $gen);
t('audit ban_monitor_armed', (int)$pdo->query("SELECT COUNT(*) FROM refresh_job_events WHERE job_id=990101 AND message LIKE '%armed%'")->fetchColumn()>=1, true);

echo "=== §21.6: идемпотентность + supersede ===\n";
$r2=$svc->armFromXmlStockIndexed(990101,701,'svc-a.casino',$T,2);
t('повтор идемпотентен (тот же id)', (int)$r2['monitor_id'], $mid);
t('дубля нет', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE source_job_id=990101")->fetchColumn(), 1);
mkjob($pdo,990102,701,'svc-b.casino',$gen);
$r3=$svc->armFromXmlStockIndexed(990102,701,'svc-b.casino',$T,1);
$mold=$pdo->query("SELECT state FROM site_ban_monitors WHERE id={$mid}")->fetch();
t('новый arm того же site → старый superseded', $mold['state'], 'superseded');
$activeForSite=(int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE site_id=701 AND state IN ('waiting_initial_delay','monitoring','confirming','insurance')")->fetchColumn();
t('ровно один active monitor на site', $activeForSite, 1);

echo "=== полная последовательность с outbox (probable/confirmed) ===\n";
// работаем с monitor нового домена svc-b (mid2)
$mid2=(int)$r3['monitor_id'];
$svcB=new BanMonitorService(new BanMonitorRepository($pdo),$req,new XmlStockUsageRepository($pdo),
    new BanMonitorTelegramFormatter('https://p.example'),$clock,
    fn($id)=>['id'=>$id,'mode'=>'refresh','old_domain'=>'old.example','new_domain'=>'svc-b.casino'],
    $set,new BanMonitorNotificationRepository($pdo));
$neg=['ok'=>true,'indexed'=>false,'pages_indexed'=>0];
// монитор в waiting_initial_delay, next=indexed+1мин; двигаем часы
$T=$T->modify('+2 min');
$seq=[['N1',$neg],['N2',$neg],['N3',$neg],['S1',$neg],['S2',$neg],['S3',$neg]];
$prevChecks=0;
foreach($seq as $stp){ $nextResult=$stp[1]; $r=$svcB->processMonitor($mid2);
  $mm=$pdo->query("SELECT next_check_at FROM site_ban_monitors WHERE id={$mid2}")->fetch();
  if($mm['next_check_at']) $T=new DateTimeImmutable($mm['next_check_at'],new DateTimeZone('UTC')); }
$mb=$pdo->query("SELECT * FROM site_ban_monitors WHERE id={$mid2}")->fetch();
t('после серии: banned', $mb['state'], 'banned');
t('negative_streak=6', (int)$mb['negative_streak'], 6);
$outboxKinds=$pdo->query("SELECT kind FROM ban_monitor_notifications WHERE monitor_id={$mid2} ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
t('outbox содержит probable', in_array('probable',$outboxKinds,true), true);
t('outbox содержит confirmed', in_array('confirmed',$outboxKinds,true), true);
t('probable event атомарно (probable_notified_at)', !empty($mb['probable_notified_at']), true);
$chk=(int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitor_checks WHERE monitor_id={$mid2}")->fetchColumn();
t('6 checks (1 на проверку)', $chk, 6);

echo "=== §21.5: notification worker шлёт outbox после commit ===\n";
$worker=new BanMonitorNotificationService(new BanMonitorNotificationRepository($pdo),$tg,$clock);
$tgTexts=[]; $res=$worker->runDue(10);
t('worker отправил probable+confirmed', $res['sent']>=2, true);
t('outbox status=sent', (int)$pdo->query("SELECT COUNT(*) FROM ban_monitor_notifications WHERE monitor_id={$mid2} AND status='sent'")->fetchColumn()>=2, true);
t('текст probable динамический (из snapshot)', strpos(implode("\n",$tgTexts),'из 6')!==false, true);

echo "=== §21.5.7: confirmed retry работает при state=banned ===\n";
$nowStr=$T->format('Y-m-d H:i:s');
$pdo->prepare("UPDATE ban_monitor_notifications SET status='pending', next_attempt_at=?, attempts=0 WHERE monitor_id={$mid2} AND kind='confirmed'")->execute([$nowStr]);
$failTg=function($s){ return false; };
$w2=new BanMonitorNotificationService(new BanMonitorNotificationRepository($pdo),$failTg,$clock);
$w2->runDue(10);
$st=$pdo->query("SELECT status,attempts FROM ban_monitor_notifications WHERE monitor_id={$mid2} AND kind='confirmed'")->fetch();
t('fail → retry (monitor banned, но retry идёт)', in_array($st['status'],['retry','failed'],true), true);
t('attempts увеличились', (int)$st['attempts']>=1, true);

echo "=== §21.5.9: max_attempts → failed + UI alert ===\n";
$pdo->prepare("UPDATE ban_monitor_notifications SET status='pending', next_attempt_at=?, attempts=2 WHERE monitor_id={$mid2} AND kind='confirmed'")->execute([$nowStr]); // max=3
$w2->runDue(10);
$st2=$pdo->query("SELECT status FROM ban_monitor_notifications WHERE monitor_id={$mid2} AND kind='confirmed'")->fetch();
t('max_attempts → failed', $st2['status'], 'failed');
t('failedCount alert >=1', (new BanMonitorNotificationRepository($pdo))->failedCount()>=1, true);

echo "=== exactly-once: повтор due (тот же uuid) не делает 2-й HTTP/check ===\n";
$pdo->exec("DELETE FROM ban_monitor_notifications WHERE monitor_id IN (SELECT id FROM site_ban_monitors WHERE domain LIKE 'svc-%')");
$pdo->exec("DELETE FROM site_ban_monitor_checks WHERE monitor_id IN (SELECT id FROM site_ban_monitors WHERE domain LIKE 'svc-%')");
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'svc-%'");
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'svc-%'");
$T=new DateTimeImmutable('2026-07-31 10:00:00',new DateTimeZone('UTC'));
mkjob($pdo,990110,702,'svc-eo.casino',$gen);
$rr=$svcB2=$svc->armFromXmlStockIndexed(990110,702,'svc-eo.casino',$T,1);
$mideo=(int)$rr['monitor_id'];
$T=$T->modify('+2 min'); $nextResult=$neg; $calls=0;
$svcEO=new BanMonitorService(new BanMonitorRepository($pdo),$req,new XmlStockUsageRepository($pdo),new BanMonitorTelegramFormatter('https://p.example'),$clock,fn($id)=>['id'=>$id,'mode'=>'refresh','old_domain'=>'o','new_domain'=>'svc-eo.casino'],$set,new BanMonitorNotificationRepository($pdo));
$r1=$svcEO->processMonitor($mideo);
$callsAfter1=$calls; $checks1=(int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitor_checks WHERE monitor_id={$mideo}")->fetchColumn();
// НЕ двигаем часы и next → форсим тот же due с тем же uuid: вернём next в прошлое
$pdo->prepare("UPDATE site_ban_monitors SET next_check_at=? WHERE id=?")->execute([$T->modify('-1 min')->format('Y-m-d H:i:s'),$mideo]);
// но series_no/phase изменились после N1 → uuid другой; поэтому эмулируем replay напрямую: повторный execute того же uuid
// Проверяем инвариант apply-once через checkExistsForRequest: повторная обработка того же request не добавит check.
$usageId=(int)$pdo->query("SELECT id FROM xmlstock_request_log WHERE monitor_id={$mideo} ORDER BY id DESC LIMIT 1")->fetchColumn();
$dup=(int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitor_checks WHERE xmlstock_request_log_id={$usageId}")->fetchColumn();
t('один check на request (apply-once)', $dup, 1);
t('N1 сделал ровно 1 HTTP', $callsAfter1, 1);

$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 990100 AND 990199");
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0 WHERE id=1");
echo "\n============================================================\n";
echo "ИТОГО (ban service PATCH_2): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
