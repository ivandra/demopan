<?php
/** Динамическая state machine BanMonitorDecision (§9): policy-driven, без hardcoded.
 *  Запуск: php _tests/ban_monitoring/test_state_machine.php */
$ROOT=dirname(__DIR__,2);
require_once $ROOT.'/app/Services/BanMonitoring/BanMonitoringPolicy.php';
require_once $ROOT.'/app/Services/BanMonitoring/BanMonitorDecision.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$T0=new DateTimeImmutable('2026-07-31 12:00:00', new DateTimeZone('UTC'));
function pol(array $o=[]){ return new BanMonitoringPolicy(array_merge([
  'initial_delay_minutes'=>720,'regular_interval_minutes'=>30,'probable_negative_count'=>3,
  'confirm_interval_minutes'=>10,'insurance_negative_count'=>3,'insurance_interval_minutes'=>10,
  'technical_error_retry_minutes'=>30,'telegram_retry_minutes'=>10,'telegram_max_attempts'=>20],$o)); }
function res($ok,$idx,$p){ return ['ok'=>$ok,'indexed'=>$idx,'pages_indexed'=>$p]; }
function step($m,$r,$now,$policy){ $c=BanMonitorDecision::classify($r);
  $d=BanMonitorDecision::decide($m,$c,(int)($r['pages_indexed']??0),$now,$policy);
  return [array_merge($m,$d['patch']),$d]; }
function mon(){ return ['state'=>'monitoring','negative_streak'=>0,'insurance_checks_done'=>0,'series_no'=>0,
  'technical_error_count'=>0,'last_positive_at'=>'2026-07-31 11:00:00','last_positive_pages'=>1,
  'probable_notified_at'=>null,'recovered_notified_at'=>null,'first_negative_at'=>null]; }

echo "=== Классификация (§10) ===\n";
t('positive', BanMonitorDecision::classify(res(true,true,3)), 'positive');
t('valid_negative', BanMonitorDecision::classify(res(true,false,0)), 'valid_negative');
t('code15 → valid_negative', BanMonitorDecision::classify(['ok'=>true,'indexed'=>false,'pages_indexed'=>0]), 'valid_negative');
t('ok=false → technical', BanMonitorDecision::classify(res(false,false,0)), 'technical_error');

echo "\n=== DEFAULT policy 3+3: N1→N3(probable)→S1→S3(confirmed) ===\n";
$P=pol(); $m=mon();
[$m,$d]=step($m,res(true,false,0),$T0,$P);
t('N1 confirming streak=1 next=+10', [$m['state'],$m['negative_streak'],$m['next_check_at']], ['confirming',1,'2026-07-31 12:10:00']);
t('N1 telegrams=[]', $d['telegrams'], []);
[$m,$d]=step($m,res(true,false,0),$T0->modify('+10min'),$P);
t('N2 streak=2', $m['negative_streak'], 2);
[$m,$d]=step($m,res(true,false,0),$T0->modify('+20min'),$P);
t('N3 insurance streak=3', [$m['state'],$m['negative_streak']], ['insurance',3]);
t('N3 telegrams=[probable]', $d['telegrams'], ['probable']);
t('N3 next=+10 (insurance interval)', $m['next_check_at'], '2026-07-31 12:30:00');
$m['probable_notified_at']='2026-07-31 12:20:00';
[$m,$d]=step($m,res(true,false,0),$T0->modify('+30min'),$P);
t('S1 insurance=1 streak=4', [$m['insurance_checks_done'],$m['negative_streak']], [1,4]);
[$m,$d]=step($m,res(true,false,0),$T0->modify('+40min'),$P);
t('S2 streak=5', $m['negative_streak'], 5);
[$m,$d]=step($m,res(true,false,0),$T0->modify('+50min'),$P);
t('S3 banned streak=6', [$m['state'],$m['negative_streak']], ['banned',6]);
t('S3 telegrams=[confirmed]', $d['telegrams'], ['confirmed']);
t('S3 next=NULL, banned_at set', [$m['next_check_at'],!empty($m['banned_at'])], [null,true]);

echo "\n=== Вариант 2+4 (probable=2, insurance=4, total=6) ===\n";
$P=pol(['probable_negative_count'=>2,'insurance_negative_count'=>4]); $m=mon();
[$m,$d]=step($m,res(true,false,0),$T0,$P);   // streak1 confirming
t('2+4 streak1 confirming', $m['state'], 'confirming');
[$m,$d]=step($m,res(true,false,0),$T0,$P);   // streak2 probable
t('2+4 streak2 probable', $d['telegrams'], ['probable']);
t('2+4 streak2 → insurance', $m['state'], 'insurance');
for($i=3;$i<=5;$i++){ $m['probable_notified_at']='x'; [$m,$d]=step($m,res(true,false,0),$T0,$P); }
t('2+4 streak5 ещё insurance', $m['state'], 'insurance');
[$m,$d]=step($m,res(true,false,0),$T0,$P);   // streak6 confirmed
t('2+4 streak6 banned', $m['state'], 'banned');
t('2+4 streak6 confirmed', $d['telegrams'], ['confirmed']);

echo "\n=== Вариант 4+2 (probable=4, insurance=2, total=6) ===\n";
$P=pol(['probable_negative_count'=>4,'insurance_negative_count'=>2]); $m=mon();
for($i=1;$i<=3;$i++){ [$m,$d]=step($m,res(true,false,0),$T0,$P); }
t('4+2 streak3 ещё confirming', $m['state'], 'confirming');
t('4+2 streak3 без telegram', $d['telegrams'], []);
[$m,$d]=step($m,res(true,false,0),$T0,$P); // streak4 probable
t('4+2 streak4 probable+insurance', [$d['telegrams'],$m['state']], [['probable'],'insurance']);
$m['probable_notified_at']='x';
[$m,$d]=step($m,res(true,false,0),$T0,$P); // 5
[$m,$d]=step($m,res(true,false,0),$T0,$P); // 6 confirmed
t('4+2 streak6 banned confirmed', [$m['state'],$d['telegrams']], ['banned',['confirmed']]);

echo "\n=== insurance=0 (probable и confirmed на одном переходе, без лишнего HTTP) ===\n";
$P=pol(['probable_negative_count'=>3,'insurance_negative_count'=>0]); $m=mon();
[$m,$d]=step($m,res(true,false,0),$T0,$P);
[$m,$d]=step($m,res(true,false,0),$T0,$P);
[$m,$d]=step($m,res(true,false,0),$T0,$P); // streak3 = total3 → probable+confirmed
t('ins=0 streak3 banned', $m['state'], 'banned');
t('ins=0 telegrams=[probable,confirmed]', $d['telegrams'], ['probable','confirmed']);
t('ins=0 next=NULL (нет лишней проверки)', $m['next_check_at'], null);

echo "\n=== probable=1 (первый negative → probable) ===\n";
$P=pol(['probable_negative_count'=>1,'insurance_negative_count'=>2]); $m=mon();
[$m,$d]=step($m,res(true,false,0),$T0,$P);
t('probable=1 streak1 → probable+insurance', [$d['telegrams'],$m['state']], [['probable'],'insurance']);
// probable=1,insurance=0 → сразу бан
$P=pol(['probable_negative_count'=>1,'insurance_negative_count'=>0]); $m=mon();
[$m,$d]=step($m,res(true,false,0),$T0,$P);
t('probable=1/ins=0 streak1 → banned + probable+confirmed', [$m['state'],$d['telegrams']], ['banned',['probable','confirmed']]);

echo "\n=== technical + recovery + динамические интервалы ===\n";
$P=pol(); $m=mon();
[$m,$d]=step($m,res(false,false,0),$T0,$P);
t('technical: streak=0', $m['negative_streak'], 0);
t('technical: next=+30 (tech retry)', $m['next_check_at'], '2026-07-31 12:30:00');
$P=pol(['technical_error_retry_minutes'=>7]); $m=mon();
[$m,$d]=step($m,res(false,false,0),$T0,$P);
t('technical retry=7 → +7', $m['next_check_at'], '2026-07-31 12:07:00');
// recovery
$P=pol(); $m=mon(); $m['state']='insurance'; $m['negative_streak']=3; $m['probable_notified_at']='2026-07-31 12:20:00';
[$m,$d]=step($m,res(true,true,1),$T0->modify('+30min'),$P);
t('recovery telegrams=[recovered]', $d['telegrams'], ['recovered']);
t('recovery state=monitoring streak=0', [$m['state'],$m['negative_streak']], ['monitoring',0]);
// dynamic regular interval
$P=pol(['regular_interval_minutes'=>45]); $m=mon();
[$m,$d]=step($m,res(true,true,2),$T0,$P);
t('regular=45 → next=+45', $m['next_check_at'], '2026-07-31 12:45:00');

echo "\n=== policy summary + валидация ===\n";
$sm=pol()->summary();
t('summary first_check через 12 ч', $sm['first_check'], 'через 12 ч');
t('summary ban_after 6', $sm['ban_after'], 'после 6 negative');
t('required_negative_total = 6', pol()->requiredNegativeTotal(), 6);

echo "\n============================================================\n";
echo "ИТОГО (state machine динамическая): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
