<?php
/** §10.2: миграция 038 — forward-only, идемпотентная, без изменения данных 036/037,
 *  без monitor/HTTP/enrollment; manual-разметка по strict-audit; down чистит только новые.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/ban_monitoring/test_migration_038.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
$name=getenv('RP_DB_NAME')?:'rp31t';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4","root","",[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$def=require $ROOT.'/app/Migrations/038_ssl_before_webmaster_and_xmlstock_ui.php';
$colExists=function($t,$c) use ($pdo){ $s=$pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?"); $s->execute([$t,$c]); return (int)$s->fetchColumn()===1; };

$snapM=$pdo->query("SELECT COUNT(*),COALESCE(SUM(id),0),COALESCE(GROUP_CONCAT(state ORDER BY id),'') FROM site_ban_monitors")->fetch(PDO::FETCH_NUM);
$snapL=$pdo->query("SELECT COUNT(*) FROM xmlstock_request_log")->fetchColumn();
$snapC=$pdo->query("SELECT COUNT(*) FROM site_ban_monitor_checks")->fetchColumn();
$snapS=$pdo->query("SELECT activation_generation,activation_min_job_id,policy_version FROM ban_monitoring_settings WHERE id=1")->fetch();
$snapJ=$pdo->query("SELECT COUNT(*),COALESCE(SUM(id),0) FROM refresh_jobs")->fetch(PDO::FETCH_NUM);

echo "=== идемпотентность: up дважды подряд ===\n";
foreach($def['up'] as $s) $s($pdo);
foreach($def['up'] as $s) $s($pdo);
t('up ×2 без ошибок', true, true);
t('refresh_jobs.pipeline_revision', $colExists('refresh_jobs','pipeline_revision'), true);
t('refresh_jobs.trusted_ssl_gate_required', $colExists('refresh_jobs','trusted_ssl_gate_required'), true);
t('refresh_jobs.trusted_ssl_gate_completed_at', $colExists('refresh_jobs','trusted_ssl_gate_completed_at'), true);
t('site_ban_monitors.enrollment_source', $colExists('site_ban_monitors','enrollment_source'), true);

echo "=== сохранность данных (§1.1, §11.2.1) ===\n";
$afterM=$pdo->query("SELECT COUNT(*),COALESCE(SUM(id),0),COALESCE(GROUP_CONCAT(state ORDER BY id),'') FROM site_ban_monitors")->fetch(PDO::FETCH_NUM);
t('monitors count/ids/states не изменились', $afterM, $snapM);
t('ledger count не изменился (0 HTTP)', $pdo->query("SELECT COUNT(*) FROM xmlstock_request_log")->fetchColumn(), $snapL);
t('checks count не изменился', $pdo->query("SELECT COUNT(*) FROM site_ban_monitor_checks")->fetchColumn(), $snapC);
t('generation/min_job/policy не изменились', $pdo->query("SELECT activation_generation,activation_min_job_id,policy_version FROM ban_monitoring_settings WHERE id=1")->fetch(), $snapS);
t('jobs count/ids не изменились', $pdo->query("SELECT COUNT(*),COALESCE(SUM(id),0) FROM refresh_jobs")->fetch(PDO::FETCH_NUM), $snapJ);
t('исторические джобы НЕ переведены на revision', (int)$pdo->query("SELECT COUNT(*) FROM refresh_jobs WHERE id<=191 AND (trusted_ssl_gate_required=1 OR pipeline_revision IS NOT NULL)")->fetchColumn(), 0);

echo "=== manual-разметка по strict-audit (Сценарий B) ===\n";
$src=$pdo->query("SELECT GROUP_CONCAT(enrollment_source ORDER BY id) FROM site_ban_monitors WHERE id IN (1,2)")->fetchColumn();
t('мониторы #1/#2 = manual_bootstrap', $src, 'manual_bootstrap,manual_bootstrap');

echo "=== down: чистит только новые поля ===\n";
foreach($def['down'] as $s) $s($pdo);
t('down: pipeline_revision удалена', $colExists('refresh_jobs','pipeline_revision'), false);
t('down: enrollment_source удалена', $colExists('site_ban_monitors','enrollment_source'), false);
t('down: monitors count/states целы', $pdo->query("SELECT COUNT(*),COALESCE(SUM(id),0),COALESCE(GROUP_CONCAT(state ORDER BY id),'') FROM site_ban_monitors")->fetch(PDO::FETCH_NUM), $snapM);
t('down: ledger цел', $pdo->query("SELECT COUNT(*) FROM xmlstock_request_log")->fetchColumn(), $snapL);
// восстановить состояние для последующих тестов
foreach($def['up'] as $s) $s($pdo);
t('re-up после down восстановил колонки', $colExists('site_ban_monitors','enrollment_source'), true);

echo "\n============================================================\n";
echo "ИТОГО (migration 038): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
