<?php
/** §21.1 no-backfill/eligibility e2e + §21.4 central routing.
 *  RP_DB_SOCKET=... php _tests/ban_monitoring/test_integration.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
$__mBefore=(int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors")->fetchColumn();
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
$pdo->exec("INSERT INTO xmlstock_settings (id,enabled) VALUES (1,1) ON DUPLICATE KEY UPDATE enabled=1");
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'int-%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 991000 AND 991099");
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0, activation_generation=0, initial_delay_minutes=1 WHERE id=1");
$set=new BanMonitoringSettingsRepository($pdo);
$T=new DateTimeImmutable('2026-07-31 09:00:00',new DateTimeZone('UTC'));
$svc=new BanMonitorService(new BanMonitorRepository($pdo),null,new XmlStockUsageRepository($pdo),null,fn()=>$T,
    fn($id)=>['id'=>$id,'mode'=>'refresh','old_domain'=>'o','new_domain'=>'int-a.casino'],$set,new BanMonitorNotificationRepository($pdo));
function mkjob($pdo,$id,$dom,$gen){ $pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,ban_monitor_generation,ban_monitor_eligible_at,created_at) VALUES (?,?,?,?,'refresh','done','ok',?,IF(? IS NULL,NULL,NOW()),NOW())")->execute([$id,800,'o',$dom,$gen,$gen]); }

echo "=== §21.1.2: миграция не создала monitor ===\n";
$mcount=(int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors")->fetchColumn()-$__mBefore;
t('0 новых monitor от миграции (count до/после up 038)', $mcount, 0);

echo "=== §21.1.3: старый completed job (gen NULL) → arm rejected, HTTP=0 ===\n";
mkjob($pdo,991000,'int-a.casino',null);
$r=$svc->armFromXmlStockIndexed(991000,800,'int-a.casino',$T,2);
t('arm rejected', $r['armed'], false);
t('0 monitor создано', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE source_job_id=991000")->fetchColumn(), 0);

echo "=== §21.1.6/7: enrollment ON→generation, OFF→NULL (через assignEligibility) ===\n";
$pdo->beginTransaction(); $set->activate(); $pdo->commit();
$gen=$set->activationGeneration();
$pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status) VALUES (?,?,?,?,'refresh','queued','pending')")->execute([991001,800,'o','int-b.casino']);
$set->assignEligibility(991001);
t('enrollment ON → generation присвоена', (int)$pdo->query("SELECT ban_monitor_generation FROM refresh_jobs WHERE id=991001")->fetchColumn(), $gen);
$set->deactivate();
$pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status) VALUES (?,?,?,?,'refresh','queued','pending')")->execute([991002,800,'o','int-c.casino']);
$set->assignEligibility(991002);
t('enrollment OFF → generation NULL', $pdo->query("SELECT ban_monitor_generation FROM refresh_jobs WHERE id=991002")->fetchColumn(), null);

echo "=== §21.1.8/9: OFF→ON generation+1, прошлая generation rejected ===\n";
$pdo->beginTransaction(); $set->activate(); $pdo->commit();
$gen2=$set->activationGeneration();
t('generation +1', $gen2, $gen+1);
mkjob($pdo,991003,'int-d.casino',$gen); // прошлая generation
$r3=$svc->armFromXmlStockIndexed(991003,800,'int-d.casino',$T,1);
t('прошлая generation → rejected (stale)', $r3['armed'], false);
t('reason stale_generation', $r3['reason'], 'stale_generation');

echo "=== eligible новой generation → arm OK ===\n";
mkjob($pdo,991004,'int-e.casino',$gen2);
$r4=$svc->armFromXmlStockIndexed(991004,800,'int-e.casino',$T,3);
t('eligible новой gen → armed', $r4['armed'], true);
t('monitor создан', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE source_job_id=991004")->fetchColumn(), 1);

echo "=== §21.4: central routing index_watching → reserve-before-HTTP ===\n";
$calls=0; $tr=function($c) use (&$calls){ $calls++; return ['ok'=>true,'indexed'=>false,'pages_indexed'=>0]; };
$svcReq=new XmlStockRequestService($tr,new XmlStockUsageRepository($pdo),fn()=>$T,fn()=>true);
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain='int-iw.casino'");
$ex=$svcReq->execute(new XmlStockRequestContext('index_watching','int-iw.casino',991004,800,null,null,null,'cron'));
$row=$pdo->query("SELECT execution_state,reserved_at,http_attempted FROM xmlstock_request_log WHERE domain='int-iw.casino'")->fetch();
t('index_watching reserved→completed', $row['execution_state'], 'completed');
t('reserved_at заполнен до HTTP', !empty($row['reserved_at']), true);
t('http_attempted=1', (int)$row['http_attempted'], 1);

echo "=== §21.1.11: миграция без backfill SQL (статически) ===\n";
$mig=file_get_contents($ROOT.'/app/Migrations/037_ban_monitoring_activation_policy.php');
t('нет INSERT...SELECT из истории', preg_match('~INSERT\s+INTO\s+site_ban_monitors[\s\S]{0,200}SELECT~i',$mig)===0, true);

$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 991000 AND 991099");
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'int-%'");
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'int-%'");
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0 WHERE id=1");
echo "\n============================================================\n";
echo "ИТОГО (integration): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
