<?php
/** ТЗ 045 (+ADDENDUM) — диагностические сообщения: severity/source/reason/impact/safety/
 *  auto_recovery/human_action/wait/technical_code; §16 acceptance (10 вопросов); blacklist;
 *  сохранность raw; паритет UI↔Telegram; §14 «не обещать неизвестное». */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
function hasru($s){ return (bool)preg_match('~[а-яё]~iu',$s); }
function contains($h,$sub){ return mb_stripos($h,$sub)!==false; }

// blacklist §10 — запрещено в НАРРАТИВНЫХ полях (не в technical_code/tech)
$BL=['prepared_target_invalid','domain_mismatch','replacement_plan','config_mutation','prepurchase_unsafe',
     'read_back','target_sha256','pipeline invariant','ambiguous_purchase','snapshot_not_written',
     'cas_update_failed','awaiting_user','getaddrinfo','php_network_getaddresses','ssl_le_polling',
     'ssl_reconciler','REFRESH-DISABLED'];
function assertClean($who,$text){ global $BL,$PASS,$FAIL;
  foreach($BL as $b){ if(mb_stripos($text,$b)!==false){ $FAIL++; echo "  [FAIL] $who содержит запрещённый токен «$b»\n"; return; } }
  $PASS++; }

// §16 acceptance: 10 вопросов должны иметь ответ (поля непусты/валидны) для WARN/ERROR/CRITICAL
function accept10($name,$d){ global $PASS,$FAIL;
  $ok=true; $miss=[];
  if(!in_array($d['severity']??'',['info','warning','error','critical'],true)){$ok=false;$miss[]='severity';}       // Q1
  if(($d['impact']??'')===''){$ok=false;$miss[]='impact';}                                                          // Q2
  if(!in_array($d['source']??'',['panel','site','external_service','network_dns','hosting','operator','unknown'],true)){$ok=false;$miss[]='source';} // Q3
  if(($d['reason']??'')===''||!hasru($d['reason'])){$ok=false;$miss[]='reason';}                                    // Q4
  if(($d['safety']??'')===''){$ok=false;$miss[]='safety';}                                                          // Q5
  if(!array_key_exists('auto_recovery',$d)){$ok=false;$miss[]='auto_recovery';}                                     // Q6
  if(!in_array($d['human_action']??'',['none','maybe','required'],true)){$ok=false;$miss[]='human_action';}         // Q7
  if(!array_key_exists('wait_state',$d)){$ok=false;$miss[]='wait_state';}                                           // Q8
  // Q9: что если авто не поможет — при auto_recovery должен быть human_action_text (эскалация) или human_action!=none где уместно
  // Q10: технический код
  if(($d['technical_code']??'')===''){$ok=false;$miss[]='technical_code';}                                          // Q10
  if($ok){$PASS++; echo "  [OK]   $name: §16 отвечает на все обязательные вопросы\n";}
  else {$FAIL++; echo "  [FAIL] $name: §16 не отвечает: ".implode(',',$miss)."\n";}
}

$NR='2026-08-11 12:48:00'; // → 15:48 МСК
// [name, stage, level, raw, payload, sev, source, tech_code]
$cases=[
 ['C01 no plan','config_replaced','error','config_replaced: no plan in artifacts',['next_run_at'=>$NR],'error','panel','replacement_plan_missing'],
 ['C02 no plan exhausted','config_replaced','error','config_replaced: no plan in artifacts, rebuilds exhausted',[],'critical','site','replacement_plan_missing'],
 ['C03 domain_mismatch','config_replaced','error',"prepared_target_invalid have='7k5274.casino' want='7k5278.casino'",[],'error','site','domain_mismatch'],
 ['C04 prepurchase_unsafe','domain_purchasing','error','prepurchase_unsafe: unrecognized_domain_field',[],'error','site','prepurchase_unsafe'],
 ['C05 read_back sha','config_replaced','error','read_back_target_sha_mismatch have=abc want=def',[],'critical','hosting','read_back_sha_mismatch'],
 ['C06 pipeline invariant','config_replaced','error','pipeline invariant violation (self-heal вернул на analyze)',[],'error','panel','pipeline_invariant_violation'],
 ['C07 ambiguous_purchase','domain_purchasing','warn','ambiguous_purchase: purchase_unknown',[],'critical','external_service','ambiguous_purchase'],
 ['C08 getaddrinfo','ssl_le_polling','warn','getaddrinfo failed: php_network_getaddresses',[],'info','network_dns','dns_not_resolving'],
 ['C09 ssl pending','ssl_le_polling','info','ssl issuance in progress',['next_run_at'=>$NR],'info','external_service','ssl_pending'],
 ['C10 self-signed','ssl_self_signed_first','info','installed self_signed cert',[],'info','external_service','ssl_self_signed'],
 ['C11 snapshot_not_written','config_replaced','error','recovery blocked: snapshot_not_written',[],'error','hosting','recovery_snapshot_not_written'],
 ['C12 cas_update_failed','config_replaced','error','recovery apply: cas_update_failed',[],'warning','panel','recovery_cas_conflict'],
 ['C13 ftp read','analyze_site','error','config_read_failed: ftp could not fetch config.php',[],'error','hosting','ftp_read_failed'],
 ['C14 unknown','config_replaced','error','weird_internal_glitch_xyz code=42',[],'error','unknown','unknown_stage_error'],
 ['C15 namecheap timeout','domain_purchasing','warn','namecheap check: operation timed out after 30002 ms',['next_run_at'=>$NR,'attempt'=>1,'max_attempts'=>3],'warning','external_service','namecheap_check_timeout'],
];

foreach($cases as $c){
  [$name,$stage,$level,$raw,$pl,$eSev,$eSrc,$eCode]=$c;
  $d=JobEventPresenter::diagnose($stage,$level,$raw,$pl);
  t("$name: severity", $d['severity'], $eSev);
  t("$name: source", $d['source'], $eSrc);
  t("$name: technical_code", $d['technical_code'], $eCode);
  tb("$name: reason на русском", hasru($d['reason']));
  accept10($name,$d);
  // blacklist только по нарративным полям
  foreach(['title','reason','impact','safety','auto_recovery_text','human_action_text','wait_text'] as $f){
    assertClean("$name.$f", (string)($d[$f]??''));
  }
  // raw сохранён
  $pr=JobEventPresenter::present(['stage'=>$stage,'level'=>$level,'message'=>$raw,'payload'=>$pl]);
  t("$name: tech.raw_message сохранён", $pr['tech']['raw_message'], $raw);
  tb("$name: tech.technical_code присутствует", ($pr['tech']['technical_code']??'')===$eCode);
  // UI human == reason; TG содержит reason (паритет смысла)
  t("$name: UI human == reason", $pr['human'], $d['reason']);
  $tg=JobEventPresenter::telegramText($stage,$level,$raw,$pl);
  tb("$name: Telegram содержит суть", contains($tg,mb_substr($d['reason'],0,20)));
}
echo "  -- итог blacklist по нарративу: без запрещённых токенов --\n";

// §14: unknown — источник не выдуман, «причина не установлена»
$u=JobEventPresenter::diagnose('config_replaced','error','totally_unknown_code',[]);
t('§14 unknown source=unknown', $u['source'], 'unknown');
tb('§14 unknown reason: «не установлен»', contains($u['reason'],'не установлен'));
tb('§14 unknown НЕ выдумывает «ошибка сайта»', !contains($u['reason'],'ошибка сайта') && !contains($u['reason'],'ошибка Namecheap'));

// §14: без next_run_at — не выдумываем время; с next_run_at — реальное МСК
$nc0=JobEventPresenter::diagnose('domain_purchasing','warn','namecheap check timed out',[]);
tb('§14 без next_run_at — нет выдуманной минуты', !preg_match('~\d{1,2} (минут|секунд)~u',(string)$nc0['wait_text']) || $nc0['wait_text']==='' || contains($nc0['wait_text'],'ближайшем запуске'));
$nc1=JobEventPresenter::diagnose('domain_purchasing','warn','namecheap check timed out',['next_run_at'=>$NR,'attempt'=>1,'max_attempts'=>3]);
tb('§14 с next_run_at — реальное время МСК в wait_text', contains($nc1['wait_text'],'15:48') && contains($nc1['wait_text'],'МСК'));
tb('§14 attempts: «ещё 2 автоматические попытки»', contains($nc1['wait_text'],'ещё 2'));

// §16 контент-проверки безопасности
$pu=JobEventPresenter::diagnose('domain_purchasing','error','prepurchase_unsafe',[]);
tb('prepurchase safety: деньги не списывались', contains($pu['safety'],'деньги') && contains($pu['safety'],'не списывал'));
$amb=JobEventPresenter::diagnose('domain_purchasing','warn','ambiguous_purchase',[]);
tb('ambiguous safety: повторная покупка не отправляется', contains($amb['safety'],'НЕ отправляется') || contains($amb['impact'],'заблокирована'));
$np=JobEventPresenter::diagnose('config_replaced','error','no plan in artifacts',[]);
tb('no plan safety: config.php НЕ изменялся', contains($np['safety'],'НЕ изменялся'));
$dm=JobEventPresenter::diagnose('config_replaced','error',"prepared_target_invalid have='7k5274.casino' want='7k5278.casino'",[]);
tb('domain_mismatch reason: have+want показаны', contains($dm['reason'],'7k5274.casino') && contains($dm['reason'],'7k5278.casino'));

// severity labels §2
t('label error', DiagnosticCatalog::SEVERITY_LABELS['error'], 'ОШИБКА — ЭТАП ОСТАНОВЛЕН');
t('label critical', DiagnosticCatalog::SEVERITY_LABELS['critical'], 'КРИТИЧЕСКАЯ ОШИБКА — ТРЕБУЕТСЯ ВМЕШАТЕЛЬСТВО');

// standaloneError отдаёт diag
$se=JobEventPresenter::standaloneError('config_replaced','no plan in artifacts');
tb('standaloneError содержит diag.severity', isset($se['diag']['severity']));
tb('standaloneError raw в tech', ($se['tech']['raw_message']??'')!=='' );

// tech.raw ДОЛЖЕН содержать технический токен
$pr=JobEventPresenter::present(['stage'=>'analyze_site','level'=>'error','message'=>'prepared_target_invalid xyz']);
tb('tech.raw_message СОХРАНЯЕТ технический токен', contains($pr['tech']['raw_message'],'prepared_target_invalid'));
tb('но human БЕЗ него', !contains($pr['human'],'prepared_target_invalid'));

echo "\n============================================================\n";
echo "ИТОГО (human readable errors): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
