<?php
/** Remediation: dry-run не меняет DB/files/FTP; conflict→exit2; not-found→exit3.
 *  C01–C03. Запуск: php _tests/test_remediation_cli.php */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

class RSync extends SiteConfigSyncService {
    public $bySite=[]; public $uploads=0; public $persists=0; private $parser;
    public function __construct($bySite){ $this->parser=new SiteConfigParser(); $this->bySite=$bySite; }
    public function fetchFromVpsReadOnly(int $s): array {
        $raw=$this->bySite[$s]??''; if(stripos($raw,'<?php')===false) return ['ok'=>false,'error'=>'empty'];
        try{$p=$this->parser->parse($raw);}catch(\Throwable $e){return ['ok'=>false,'error'=>'parser exception'];}
        return ['ok'=>true,'raw'=>$raw,'path'=>'config.php','sha256'=>hash('sha256',$raw),'parsed'=>$p,'kind'=>'flat']; }
    public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; $this->bySite[$s]=$c; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { $this->persists++; return ['ok'=>true]; }
}
$mask=new DomainMaskService([],true);
$mk=fn($sync)=>new SiteConfigMutationService($sync,new StaticSiteConfigScanner(),$mask);
$runner=new SubIdRemediationRunner();

// drift: current 7k5269.casino, live sub_id=7k5241 → new=7k5269
$drift="<?php\n\$domain='https://7k5269.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$internal_reg_url=\"https://p.com/b?sub_id=7k5241\";\n";

// C01 dry-run → changes=0
$s=new RSync([7=>$drift]); $svc=$mk($s);
$sum=$runner->run([['site_id'=>7,'domain'=>'7k5269.casino']], $svc, false);
t('C01 dry-run uploads=0', $s->uploads, 0);
t('C01 dry-run persists=0', $s->persists, 0);
t('C01 dry-run config не изменён', $s->bySite[7], $drift);
t('C01 dry-run decision WOULD_APPLY', $sum['rows'][0]['decision'], 'WOULD_APPLY');
t('C01 dry-run new_sub_id=7k5269', $sum['rows'][0]['new_sub_id'], '7k5269');
t('C01 dry-run exit 0', $sum['exit'], 0);

// apply → APPLIED, один upload, sub_id изменён
$s=new RSync([7=>$drift]); $svc=$mk($s);
$sum=$runner->run([['site_id'=>7,'domain'=>'7k5269.casino']], $svc, true);
t('APPLY applied=1', $sum['applied'], 1);
t('APPLY uploads=1', $s->uploads, 1);
t('APPLY persists=1', $s->persists, 1);
t('APPLY sub_id=7k5269 в конфиге', strpos($s->bySite[7],'sub_id=7k5269')!==false && strpos($s->bySite[7],'7k5241')===false, true);
t('APPLY exit 0', $sum['exit'], 0);

// ALREADY_CURRENT: sub_id уже актуален
$cur="<?php\n\$domain='https://7k5269.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5269\";\n";
$s=new RSync([8=>$cur]); $svc=$mk($s);
$sum=$runner->run([['site_id'=>8,'domain'=>'7k5269.casino']], $svc, true);
t('ALREADY_CURRENT already=1', $sum['already_current'], 1);
t('ALREADY_CURRENT uploads=0', $s->uploads, 0);
t('ALREADY_CURRENT exit 0', $sum['exit'], 0);

// C02 conflict → exit2
$conf="<?php\n\$base_new_url=\"https://p.com/a?sub_id=z1\";\n\$internal_reg_url=\"https://p.com/b?sub_id=z2\";\n";
$s=new RSync([9=>$conf]); $svc=$mk($s);
$sum=$runner->run([['site_id'=>9,'domain'=>'z.casino']], $svc, false);
t('C02 conflict blocked>=1', $sum['blocked']>=1, true);
t('C02 conflict exit 2', $sum['exit'], 2);
t('C02 conflict uploads=0', $s->uploads, 0);

// C03 target not found → exit3
$sum=$runner->run([], $mk(new RSync([])), false);
t('C03 not-found exit 3', $sum['exit'], 3);

echo "\n============================================================\n";
echo "ИТОГО (remediation cli): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
