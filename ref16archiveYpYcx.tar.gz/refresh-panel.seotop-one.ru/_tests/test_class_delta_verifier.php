<?php
/** ТЗ 046 §15 — ClassMappingDeltaVerifier: прямой before/after semantic proof. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
// reader из карты path=>content
function rdr(array $map){ return function($p) use($map){ return array_key_exists($p,$map)?$map[$p]:null; }; }

$P=['m.txt'];

// UC-DELTA-01 — реальная смена одного значения
$before=ClassMappingDeltaVerifier::snapshot(rdr(['m.txt'=>"button___A:button___11111\n"]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr(['m.txt'=>"button___A:button___22222\n"]));
$v=ClassMappingDeltaVerifier::verdict(true,$before,$diff);
t('UC-DELTA-01 changed_pairs=1',$diff['changed_pairs'],1);
tb('UC-DELTA-01 verified=true',$v['verified']===true);

// UC-DELTA-02 — HTTP success, классы те же
$before=ClassMappingDeltaVerifier::snapshot(rdr(['m.txt'=>"button___A:button___11111\n"]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr(['m.txt'=>"button___A:button___11111\n"]));
$v=ClassMappingDeltaVerifier::verdict(true,$before,$diff);
t('UC-DELTA-02 changed_pairs=0',$diff['changed_pairs'],0);
tb('UC-DELTA-02 verified=false',$v['verified']===false);
t('UC-DELTA-02 reason=no_class_change',$v['reason'],'no_class_change');

// UC-DELTA-03 — только whitespace (semantic == , SHA !=)
$b3="button___A:button___11111\n";
$a3="button___A:  button___11111  \n\n"; // пробелы + пустая строка
$before=ClassMappingDeltaVerifier::snapshot(rdr(['m.txt'=>$b3]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr(['m.txt'=>$a3]));
t('UC-DELTA-03 changed_pairs=0 (whitespace)',$diff['changed_pairs'],0);
tb('UC-DELTA-03 SHA различается',$diff['files']['m.txt']['sha_before']!==$diff['files']['m.txt']['sha_after']);
tb('UC-DELTA-03 verified=false',ClassMappingDeltaVerifier::verdict(true,$before,$diff)['verified']===false);

// UC-DELTA-04 — 1 из многих изменён
$lines=[]; for($i=0;$i<321;$i++)$lines[]="c$i:v$i";
$bMap=implode("\n",$lines)."\n";
$linesA=$lines; $linesA[0]="c0:CHANGED";
$aMap=implode("\n",$linesA)."\n";
$before=ClassMappingDeltaVerifier::snapshot(rdr(['m.txt'=>$bMap]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr(['m.txt'=>$aMap]));
t('UC-DELTA-04 changed_pairs=1 из 321',$diff['changed_pairs'],1);
tb('UC-DELTA-04 verified=true',ClassMappingDeltaVerifier::verdict(true,$before,$diff)['verified']===true);

// UC-DELTA-05 — mapping unreadable after
$before=ClassMappingDeltaVerifier::snapshot(rdr(['m.txt'=>"button___A:button___11111\n"]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr([])); // after не читается
tb('UC-DELTA-05 diff.ok=false',$diff['ok']===false);
tb('UC-DELTA-05 error=after_unreadable',strpos((string)$diff['error'],'after_unreadable')===0);
tb('UC-DELTA-05 verified=false',ClassMappingDeltaVerifier::verdict(true,$before,$diff)['verified']===false);

// UC-DELTA-06 — wrong FTP identity (даже при отличии пар)
$before=ClassMappingDeltaVerifier::snapshot(rdr(['m.txt'=>"button___A:button___11111\n"]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr(['m.txt'=>"button___A:button___22222\n"]));
$v=ClassMappingDeltaVerifier::verdict(false,$before,$diff); // identity НЕ verified
tb('UC-DELTA-06 verified=false при wrong identity',$v['verified']===false);
t('UC-DELTA-06 reason=ftp_identity_unverified',$v['reason'],'ftp_identity_unverified');

// UC-DELTA-07 — ambiguous HTTP, но реальная дельта есть → verified (без повтора HTTP на уровне verifier)
$before=ClassMappingDeltaVerifier::snapshot(rdr(['m.txt'=>"button___A:button___11111\n"]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr(['m.txt'=>"button___A:button___22222\n"]));
tb('UC-DELTA-07 changed>=1',$diff['changed_pairs']>=1);
tb('UC-DELTA-07 verified=true (HTTP не важен)',ClassMappingDeltaVerifier::verdict(true,$before,$diff)['verified']===true);

// UC-DELTA-08 — реальные фикстуры 7k2500/7k5001
$FX=__DIR__.'/fixtures/class_mapping';
$paths=['desktop','mobile'];
$readA=function($p) use($FX){ return @file_get_contents("$FX/7k2500_$p.txt"); };
$readB=function($p) use($FX){ return @file_get_contents("$FX/7k5001_$p.txt"); };
$before=ClassMappingDeltaVerifier::snapshot($readA,$paths);
$diff=ClassMappingDeltaVerifier::diff($before,$readB);
$v=ClassMappingDeltaVerifier::verdict(true,$before,$diff);
t('UC-DELTA-08 desktop changed>0',$diff['files']['desktop']['changed_pairs']>0,true);
t('UC-DELTA-08 mobile changed>0',$diff['files']['mobile']['changed_pairs']>0,true);
t('UC-DELTA-08 total changed=321',$diff['changed_pairs'],321);
tb('UC-DELTA-08 verified=true',$v['verified']===true);
tb('UC-DELTA-08 sample присутствует',is_array($v['sample']) && isset($v['sample']['before'],$v['sample']['after']));

// before-snapshot missing → verdict blocked
$vm=ClassMappingDeltaVerifier::verdict(true,['ok'=>false,'files'=>[]],['ok'=>false,'error'=>'before_snapshot_missing','changed_pairs'=>0]);
tb('before missing → verified=false',$vm['verified']===false);


// §17 — no common keys → verdict no_common_keys
$before=ClassMappingDeltaVerifier::snapshot(rdr(["m.txt"=>"a:1\nb:2\n"]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr(["m.txt"=>"x:9\ny:8\n"]));
t("§17 common=0",$diff["common"],0);
t("§17 verdict reason=no_common_keys",ClassMappingDeltaVerifier::verdict(true,$before,$diff)["reason"],"no_common_keys");
// examples присутствуют при изменениях
$before=ClassMappingDeltaVerifier::snapshot(rdr(["m.txt"=>"a:1\nb:2\n"]),$P);
$diff=ClassMappingDeltaVerifier::diff($before,rdr(["m.txt"=>"a:9\nb:8\n"]));
tb("examples заполнены",count($diff["examples"])>=1);
t("common=2 (оба ключа общие)",$diff["common"],2);

echo "\n============================================================\n";
echo "ИТОГО (class delta verifier): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
