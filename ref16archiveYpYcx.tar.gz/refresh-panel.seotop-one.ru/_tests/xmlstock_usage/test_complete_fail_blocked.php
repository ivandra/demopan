<?php
/** §2.4.2: complete() обязан подтвердить запись → иначе ambiguous без transition.
 *  §5.3: стоп-кран → due-мониторы blocked (серия не растёт), после включения продолжение.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/xmlstock_usage/test_complete_fail_blocked.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp31t'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$SNAP=$pdo->query("SELECT * FROM ban_monitoring_settings WHERE id=1")->fetch();
$XS=$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn();
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'cf-%'");
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'cf-%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 997000 AND 997099");
$T=new DateTimeImmutable('2026-08-01 12:00:00',new DateTimeZone('UTC'));

/** Обёртка репозитория с ломаемым complete(). */
class BreakableUsageRepo extends XmlStockUsageRepository {
    public $failComplete=false;
    public function complete(int $id, array $f, string $nowUtc): bool
    { if ($this->failComplete) return false; return parent::complete($id,$f,$nowUtc); }
}

echo "=== §2.4.2: HTTP выполнен, complete() не сохранил → ambiguous, transition нет ===\n";
$usage=new BreakableUsageRepo($pdo); $usage->failComplete=true;
$tr=function($c){ return ['ok'=>true,'indexed'=>true,'pages_indexed'=>4]; };
$svc=new XmlStockRequestService($tr,$usage,fn()=>$T,fn()=>true);
$ex=$svc->execute(new XmlStockRequestContext('ban_monitoring','cf-a.casino',null,null,777,'monitoring',1,'cron'));
t('ok=false', $ex['ok'], false);
t('ambiguous=true', !empty($ex['ambiguous']), true);
t('charged=true (потенциально списан)', $ex['charged'], true);
t('error=complete_write_unconfirmed', $ex['error'] ?? '', 'complete_write_unconfirmed');
$row=$pdo->query("SELECT execution_state,assumed_charged,http_attempted FROM xmlstock_request_log WHERE domain='cf-a.casino'")->fetch();
t('ledger: execution_state=ambiguous', $row['execution_state'], 'ambiguous');
t('ledger: assumed_charged=1', (int)$row['assumed_charged'], 1);
t('ledger: http_attempted=1', (int)$row['http_attempted'], 1);

echo "=== повторный вызов того же uuid → HTTP=0 (запрещён повторный платный) ===\n";
$calls=0; $tr2=function($c) use(&$calls){ $calls++; return ['ok'=>true,'indexed'=>true,'pages_indexed'=>4]; };
$uuid=$pdo->query("SELECT request_uuid FROM xmlstock_request_log WHERE domain='cf-a.casino'")->fetchColumn();
$svc2=new XmlStockRequestService($tr2,new XmlStockUsageRepository($pdo),fn()=>$T,fn()=>true);
$ex2=$svc2->execute(new XmlStockRequestContext('ban_monitoring','cf-a.casino',null,null,777,'monitoring',1,'cron'),$uuid);
t('duplicate ambiguous uuid → HTTP=0', [$calls,(int)$ex2['http']], [0,0]);
t('duplicate → ambiguous ответ', !empty($ex2['ambiguous']), true);

echo "=== монитор при ambiguous: transition НЕ применяется (серия не растёт) ===\n";
$pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,created_at) VALUES (997001,1,'o','cf-m.casino','refresh','done','ok',NOW())")->execute();
$snapJ=json_encode(['initial_delay_minutes'=>720,'regular_interval_minutes'=>30,'probable_negative_count'=>3,'confirm_interval_minutes'=>10,'insurance_negative_count'=>3,'insurance_interval_minutes'=>10,'technical_error_retry_minutes'=>30,'telegram_retry_minutes'=>10,'telegram_max_attempts'=>20]);
$pdo->prepare("INSERT INTO site_ban_monitors (site_id,source_job_id,domain,indexed_at,monitoring_starts_at,next_check_at,last_positive_at,state,negative_streak,activation_generation,policy_version,policy_snapshot_json) VALUES (1,997001,'cf-m.casino','2026-08-01 00:00:00','2026-08-01 00:00:00','2026-08-01 11:00:00','2026-08-01 00:00:00','monitoring',2,1,1,?)")->execute([$snapJ]);
$MID=(int)$pdo->lastInsertId();
$usage2=new BreakableUsageRepo($pdo); $usage2->failComplete=true;
$reqSvc=new XmlStockRequestService($tr,$usage2,fn()=>$T,fn()=>true);
$ban=new BanMonitorService(new BanMonitorRepository($pdo), $reqSvc, $usage2, null, fn()=>$T,
    fn($id)=>['id'=>$id,'mode'=>'refresh','old_domain'=>'o','new_domain'=>'cf-m.casino'],
    new BanMonitoringSettingsRepository($pdo), new BanMonitorNotificationRepository($pdo));
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=1, processing_enabled=1 WHERE id=1");
$pdo->exec("UPDATE xmlstock_settings SET enabled=1 WHERE id=1");
$r=$ban->processMonitor($MID);
$m=$pdo->query("SELECT negative_streak,state,next_check_at FROM site_ban_monitors WHERE id=$MID")->fetch();
t('ambiguous при обработке монитора', !empty($r['ambiguous']) || (($r['decision'] ?? '')===''), true);
t('серия НЕ изменилась (2)', (int)$m['negative_streak'], 2);
t('state=monitoring (без transition)', $m['state'], 'monitoring');
t('next_check_at сдвинут (retry)', $m['next_check_at']>'2026-08-01 11:00:00', true);

echo "=== СТРОГИЙ complete() НА РЕАЛЬНОМ РЕПОЗИТОРИИ (не mock): WHERE started + rowCount=1 ===\n";
$real=new XmlStockUsageRepository($pdo); $NOW=$T->format('Y-m-d H:i:s');
// (а) несуществующий id → false
t('real: complete(несуществующий id) → false', $real->complete(99999999,['result'=>'indexed','normalized_result_json'=>'{}'],$NOW), false);
// (б) reserved без claim (state != started) → false, строка осталась reserved
$rr=$real->reserve(new XmlStockRequestContext('manual_test','cf-r1.casino',null,null,null,null,null,'operator'),'cfr10001-0000-4000-8000-000000000001',$NOW);
t('real: complete(reserved, без claim) → false', $real->complete((int)$rr['id'],['result'=>'indexed','normalized_result_json'=>'{}'],$NOW), false);
t('real: строка осталась reserved', $pdo->query("SELECT execution_state FROM xmlstock_request_log WHERE id={$rr['id']}")->fetchColumn(), 'reserved');
// (в) штатный путь reserved→started→completed → true; повторный complete → false
t('real: claim → true', $real->claim((int)$rr['id'],$NOW), true);
t('real: complete(started) → true (rowCount=1)', $real->complete((int)$rr['id'],['result'=>'indexed','pages_indexed'=>1,'http_code'=>200,'normalized_result_json'=>'{}'],$NOW), true);
t('real: повторный complete(completed) → false', $real->complete((int)$rr['id'],['result'=>'indexed','normalized_result_json'=>'{}'],$NOW), false);
t('real: строка completed', $pdo->query("SELECT execution_state FROM xmlstock_request_log WHERE id={$rr['id']}")->fetchColumn(), 'completed');
// (г) конкурентная гонка БЕЗ mock: во время HTTP другой процесс перевёл строку в ambiguous →
//     реальный complete() увидит state!=started → rowCount=0 → false → сервис пометит ambiguous,
//     transition монитора не выполняется.
$raceTr=function($c) use (&$real,$pdo,$NOW){
    $uid=(int)$pdo->query("SELECT id FROM xmlstock_request_log WHERE domain='cf-race.casino' ORDER BY id DESC LIMIT 1")->fetchColumn();
    $pdo->prepare("UPDATE xmlstock_request_log SET execution_state='ambiguous', status='ambiguous', ambiguous_at=?, assumed_charged=1 WHERE id=?")->execute([$NOW,$uid]);
    return ['ok'=>true,'indexed'=>true,'pages_indexed'=>4];
};
$svcR=new XmlStockRequestService($raceTr,$real,fn()=>$T,fn()=>true);
$exR=$svcR->execute(new XmlStockRequestContext('ban_monitoring','cf-race.casino',null,null,777,'monitoring',1,'cron'));
t('гонка real repo: ok=false', $exR['ok'], false);
t('гонка real repo: ambiguous=true', !empty($exR['ambiguous']), true);
t('гонка real repo: error=complete_write_unconfirmed', $exR['error'] ?? '', 'complete_write_unconfirmed');
t('гонка real repo: ledger ambiguous (не completed)', $pdo->query("SELECT execution_state FROM xmlstock_request_log WHERE domain='cf-race.casino'")->fetchColumn(), 'ambiguous');

echo "=== §11.2.7 guard: markAmbiguous не перетирает подтверждённый completed ===\n";
$usage3=new XmlStockUsageRepository($pdo);
$r3=$usage3->reserve(new XmlStockRequestContext('manual_test','cf-c.casino',null,null,null,null,null,'operator'),'cfcccc01-0000-4000-8000-000000000000',$T->format('Y-m-d H:i:s'));
$usage3->claim((int)$r3['id'],$T->format('Y-m-d H:i:s'));
$usage3->complete((int)$r3['id'],['result'=>'indexed','pages_indexed'=>1,'http_code'=>200,'normalized_result_json'=>'{}'],$T->format('Y-m-d H:i:s'));
$usage3->markAmbiguous((int)$r3['id'],$T->format('Y-m-d H:i:s'),'late');
t('completed остался completed', $pdo->query("SELECT execution_state FROM xmlstock_request_log WHERE id={$r3['id']}")->fetchColumn(), 'completed');

echo "=== §5.3: global OFF → runDue блокирует due-монитор без роста серии ===\n";
$pdo->prepare("UPDATE site_ban_monitors SET next_check_at='2026-08-01 11:00:00', blocked_reason=NULL, negative_streak=2 WHERE id=$MID")->execute();
$pdo->exec("UPDATE xmlstock_settings SET enabled=0 WHERE id=1");
$calls3=0; $tr3=function($c) use(&$calls3){ $calls3++; return ['ok'=>true,'indexed'=>false,'pages_indexed'=>0]; };
$u2=new XmlStockUsageRepository($pdo);
$ban2=new BanMonitorService(new BanMonitorRepository($pdo), new XmlStockRequestService($tr3,$u2,fn()=>$T,fn()=>true), $u2, null, fn()=>$T,
    fn($id)=>['id'=>$id], new BanMonitoringSettingsRepository($pdo), new BanMonitorNotificationRepository($pdo));
$out=$ban2->runDue(50);
$m2=$pdo->query("SELECT blocked_reason,negative_streak,next_check_at,state FROM site_ban_monitors WHERE id=$MID")->fetch();
t('runDue skipped=processing_or_global_disabled', $out['skipped'] ?? '', 'processing_or_global_disabled');
t('blocked_reason=xmlstock_disabled', $m2['blocked_reason'], 'xmlstock_disabled');
t('HTTP=0 при стоп-кране', $calls3, 0);
t('серия не выросла', (int)$m2['negative_streak'], 2);
t('next_check_at сдвинут вперёд', $m2['next_check_at']>'2026-08-01 11:00:00', true);
t('state не изменился', $m2['state'], 'monitoring');

echo "=== после включения: продолжение со своей серии, blocked_reason сброшен ===\n";
$pdo->exec("UPDATE xmlstock_settings SET enabled=1 WHERE id=1");
$pdo->prepare("UPDATE site_ban_monitors SET next_check_at='2026-08-01 11:30:00' WHERE id=$MID")->execute();
$u3=new XmlStockUsageRepository($pdo);
$ban3=new BanMonitorService(new BanMonitorRepository($pdo), new XmlStockRequestService($tr3,$u3,fn()=>$T,fn()=>true), $u3, null, fn()=>$T,
    fn($id)=>['id'=>$id,'mode'=>'refresh','old_domain'=>'o','new_domain'=>'cf-m.casino'],
    new BanMonitoringSettingsRepository($pdo), new BanMonitorNotificationRepository($pdo));
$r=$ban3->processMonitor($MID);
$m3=$pdo->query("SELECT blocked_reason,negative_streak FROM site_ban_monitors WHERE id=$MID")->fetch();
t('после включения HTTP выполнен', $calls3, 1);
t('blocked_reason сброшен', $m3['blocked_reason'], null);
t('серия продолжилась со своей точки (2→3)', (int)$m3['negative_streak'], 3);

// восстановление
$pdo->prepare("UPDATE xmlstock_settings SET enabled=? WHERE id=1")->execute([(int)$XS]);
$pdo->prepare("UPDATE ban_monitoring_settings SET enrollment_enabled=?,processing_enabled=? WHERE id=1")->execute([$SNAP['enrollment_enabled'],$SNAP['processing_enabled']]);
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'cf-%'");
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'cf-%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 997000 AND 997099");
echo "\n============================================================\n";
echo "ИТОГО (complete-fail + blocked): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
