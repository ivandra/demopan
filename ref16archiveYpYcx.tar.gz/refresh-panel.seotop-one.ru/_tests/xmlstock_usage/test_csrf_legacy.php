<?php
/** §2.4.3/§11.2.11: все POST /xmlstock без CSRF отклоняются; стоп-кран требует
 *  комментарий и пишет strict-audit (old/new, IP, оператор).
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/xmlstock_usage/test_csrf_legacy.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp31t'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php'; require_once $ROOT.'/app/Controllers/XmlStockController.php';
@session_start(); $_SESSION['auth']=true; $_SESSION['csrf_token']='tok';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$XS=(int)$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn();
$pdo->exec("DELETE FROM ban_monitoring_audit WHERE action='xmlstock_toggle_enabled'");

/** requireCsrf в Controller кидает/exit? Проверим фактически: подкласс перехватывает. */
class RedirC extends \Exception{}
class DeniedC extends \Exception{}
class TXC extends XmlStockController { public $fl=[];
  protected function flash(string $t,string $m):void{ $this->fl[]=[$t,$m]; }
  protected function redirect(string $u):void{ throw new RedirC($u); }
  public function requireCsrf(): void { if (!$this->csrfValid()) throw new DeniedC('csrf'); }
  public function call(string $m){ $this->fl=[]; try{ $this->$m(); }catch(RedirC $e){} return $this->fl; }
  public function callDenied(string $m): bool { try{ $this->$m(); }catch(DeniedC $e){ return true; }catch(RedirC $e){} return false; } }
$ctl=new TXC();

echo "=== все 5 legacy-действий отклоняют запрос без CSRF ===\n";
foreach (['toggleEnabled','pauseJob','resumeJob','pauseAll','resumeAll'] as $m) {
    $_POST=['enable'=>1,'id'=>1]; // без csrf_token
    t("{$m}: без токена → denied", $ctl->callDenied($m), true);
    $_POST=['enable'=>1,'id'=>1,'csrf_token'=>'WRONG'];
    t("{$m}: неверный токен → denied", $ctl->callDenied($m), true);
}

echo "=== стоп-кран: с CSRF, но без комментария → отказ, состояние не меняется ===\n";
$before=(int)$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn();
$_POST=['enable'=>$before?0:1,'csrf_token'=>'tok','comment'=>''];
$fl=$ctl->call('toggleEnabled');
t('без комментария → error', ($fl[0][0] ?? ''), 'error');
t('enabled не изменился', (int)$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn(), $before);
t('audit не записан', (int)$pdo->query("SELECT COUNT(*) FROM ban_monitoring_audit WHERE action='xmlstock_toggle_enabled'")->fetchColumn(), 0);

echo "=== стоп-кран: валидный запрос → переключение + strict audit ===\n";
$_POST=['enable'=>$before?0:1,'csrf_token'=>'tok','comment'=>'аварийная остановка расхода'];
$_SERVER['REMOTE_ADDR']='10.0.0.5';
$fl=$ctl->call('toggleEnabled');
$after=(int)$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn();
t('enabled переключён', $after, $before?0:1);
$au=$pdo->query("SELECT * FROM ban_monitoring_audit WHERE action='xmlstock_toggle_enabled' ORDER BY id DESC LIMIT 1")->fetch();
t('audit записан', is_array($au), true);
t('audit old/new заполнены', !empty($au['old_values']) && !empty($au['new_values']), true);
t('audit old.enabled='.$before, json_decode((string)$au['old_values'],true)['enabled'] ?? -1, $before);
t('audit IP зафиксирован', $au['ip'], '10.0.0.5');
t('audit комментарий', strpos((string)$au['comment'],'аварийная')!==false, true);

echo "=== ban-действия по-прежнему под CSRF (регресс) ===\n";
foreach (['banActivateNewJobs','banToggleProcessing','banSavePolicy','banBootstrapJobs','banMonitorStop'] as $m) {
    $_POST=['csrf_token'=>'WRONG'];
    t("{$m}: неверный токен → denied", $ctl->callDenied($m), true);
}

// восстановление
$pdo->prepare("UPDATE xmlstock_settings SET enabled=? WHERE id=1")->execute([$XS]);
$pdo->exec("DELETE FROM ban_monitoring_audit WHERE action='xmlstock_toggle_enabled'");
echo "\n============================================================\n";
echo "ИТОГО (csrf legacy §2.4.3): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
