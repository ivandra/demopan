<?php
/** §16.3/§16.6 UI-данные: breakdown (charged/ambiguous/failed_before_http), динамич. estimate,
 *  recent с execution_state. RP_DB_SOCKET=... php _tests/xmlstock_usage/test_xmlstock_ui.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'ui-%'");
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'ui-%'");
$repo=new XmlStockUsageRepository($pdo);
$now=gmdate('Y-m-d H:i:s');
function mkctx($p,$dom,$mid=null){ return new XmlStockRequestContext($p,$dom,186,55,$mid,$mid?'monitoring':null,$mid?10:null,$p==='manual_test'?'operator':'cron'); }
// completed по одному на каждый purpose
$i=0;
foreach(['index_watching','final_monitoring','ban_monitoring','manual_test'] as $p){
  $r=$repo->reserve(mkctx($p,"ui-$p.casino",$p==='ban_monitoring'?701:null),sprintf('ui%06d-0000-4000-8000-000000000000',$i++),$now);
  $repo->claim((int)$r['id'],$now);
  $repo->complete((int)$r['id'],['result'=>'indexed','pages_indexed'=>2,'http_code'=>200,'normalized_result_json'=>'{"ok":true,"indexed":true,"pages_indexed":2}'],$now);
}
// ambiguous
$ra=$repo->reserve(mkctx('ban_monitoring','ui-amb.casino',701),'uiaaaa1-0000-4000-8000-000000000000',$now);
$repo->claim((int)$ra['id'],$now); $repo->markAmbiguous((int)$ra['id'],$now,'timeout');
// failed_before_http
$rf=$repo->reserve(mkctx('index_watching','ui-fbh.casino'),'uifff01-0000-4000-8000-000000000000',$now);
$repo->markFailedBeforeHttp((int)$rf['id'],$now,'reserve then fail');

echo "=== breakdown новые ключи (§16.3) ===\n";
$bd=$repo->breakdownToday();
t('index_watching >=1', $bd['index_watching']>=1, true);
t('final_monitoring >=1', $bd['final_monitoring']>=1, true);
t('ban_monitoring (completed+ambiguous) >=2', $bd['ban_monitoring']>=2, true);
t('manual_test >=1', $bd['manual_test']>=1, true);
t('charged_total считает completed+ambiguous', $bd['charged_total']>=5, true);
t('ambiguous отдельно >=1', $bd['ambiguous']>=1, true);
t('failed_before_http отдельно >=1', $bd['failed_before_http']>=1, true);
t('нет ключа assumed_charged как «тех.ошибки»', array_key_exists('assumed_charged',$bd), false);

echo "=== recent с execution_state фильтром (§16.5) ===\n";
$amb=$repo->recent(['execution_state'=>'ambiguous','domain'=>'ui-'],1,50);
t('фильтр execution_state=ambiguous', count($amb)>=1 && $amb[0]['execution_state']==='ambiguous', true);
$byPurpose=$repo->recent(['purpose'=>'manual_test','domain'=>'ui-'],1,50);
t('фильтр purpose=manual_test', count($byPurpose)>=1, true);

echo "=== динамическая оценка расхода (§16.6, не 48/144) ===\n";
$snap=json_encode(['regular_interval_minutes'=>30,'confirm_interval_minutes'=>10,'insurance_interval_minutes'=>10,'probable_negative_count'=>3,'insurance_negative_count'=>3,'initial_delay_minutes'=>720,'technical_error_retry_minutes'=>30,'telegram_retry_minutes'=>10,'telegram_max_attempts'=>20]);
$pdo->prepare("INSERT INTO site_ban_monitors (site_id,source_job_id,domain,indexed_at,monitoring_starts_at,next_check_at,last_positive_at,state,activation_generation,policy_version,policy_snapshot_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
    ->execute([701,186,'ui-est.casino',$now,$now,$now,$now,'monitoring',1,1,$snap]);
$banRepo=new BanMonitorRepository($pdo);
$est=$banRepo->estimateActiveDaily();
t('monitoring → 1440/30 = 48/сут вклад', $est['per_day_total']>=48, true);
// изменим snapshot на 15-мин интервал → 96/сут
$snap15=json_encode(array_merge(json_decode($snap,true),['regular_interval_minutes'=>15]));
$pdo->prepare("UPDATE site_ban_monitors SET policy_snapshot_json=? WHERE domain='ui-est.casino'")->execute([$snap15]);
$est2=$banRepo->estimateActiveDaily();
t('regular=15 → 1440/15=96/сут (динамич., не фикс.48)', $est2['per_day_total']>=96, true);

$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'ui-%'");
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'ui-%'");
echo "\n============================================================\n";
echo "ИТОГО (xmlstock ui): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
