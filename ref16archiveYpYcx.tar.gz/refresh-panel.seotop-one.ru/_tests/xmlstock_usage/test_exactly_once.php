<?php
/** §21.3 exactly-once + §21.4 central accounting: claim, duplicate, ambiguous, reserve/claim fail.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp30 RP_DB_USER=root php _tests/xmlstock_usage/test_exactly_once.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
$pdo->exec("INSERT INTO xmlstock_settings (id,enabled) VALUES (1,1) ON DUPLICATE KEY UPDATE enabled=1");
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$clock=fn()=>new DateTimeImmutable('now',new DateTimeZone('UTC'));
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'eo-%'");
$ctx=fn($p='ban_monitoring',$dom='eo-a.casino')=>new XmlStockRequestContext($p,$dom,186,null,10,'monitoring',null,'cron');
$calls=0; $nextResult=['ok'=>true,'indexed'=>true,'pages_indexed'=>1];
$mk=function() use (&$calls,&$nextResult,$pdo,$clock){ $tr=function($c) use (&$calls,&$nextResult){ $calls++; return $nextResult; };
  return new XmlStockRequestService($tr, new XmlStockUsageRepository($pdo), $clock, fn()=>true); };
function chargedStarts($pdo){ return (int)$pdo->query("SELECT COUNT(*) FROM xmlstock_request_log WHERE http_attempted=1 AND domain LIKE 'eo-%'")->fetchColumn(); }

echo "=== 1. Первый UUID → один transport call, completed ===\n";
$calls=0; $svc=$mk(); $u='11111111-1111-4111-8111-111111111111';
$r=$svc->execute($ctx(),$u);
t('transport вызван 1 раз', $calls, 1);
t('ok+charged+http=1', [$r['ok'],$r['charged'],$r['http']], [true,true,1]);
$row=$pdo->query("SELECT * FROM xmlstock_request_log WHERE request_uuid='$u'")->fetch();
t('execution_state=completed', $row['execution_state'], 'completed');
t('http_attempted=1', (int)$row['http_attempted'], 1);
t('normalized_result_json заполнен', !empty($row['normalized_result_json']), true);

echo "=== 2. Повтор completed UUID → transport delta 0, replay ===\n";
$calls=0; $r2=$svc->execute($ctx(),$u);
t('transport НЕ вызван (delta 0)', $calls, 0);
t('replayed=true, http=0', [$r2['replayed']??false,$r2['http']], [true,0]);
t('replay вернул result', !empty($r2['result']), true);

echo "=== 3. Повтор started/ambiguous UUID → HTTP=0 ===\n";
$u3='33333333-3333-4333-8333-333333333333';
$pdo->prepare("INSERT INTO xmlstock_request_log (request_uuid,requested_at,reserved_at,started_at,purpose,domain,status,execution_state,http_attempted) VALUES (?,?,?,?, 'ban_monitoring','eo-b.casino','started','started',1)")->execute([$u3,gmdate('Y-m-d H:i:s'),gmdate('Y-m-d H:i:s'),gmdate('Y-m-d H:i:s')]);
$calls=0; $r3=$svc->execute($ctx('ban_monitoring','eo-b.casino'),$u3);
t('started dup: transport НЕ вызван', $calls, 0);
t('started dup: ambiguous+http=0', [$r3['ambiguous']??false,$r3['http']], [true,0]);

echo "=== 4. Claim race: reserved занят другим → claim_lost, HTTP=0 ===\n";
$u4='44444444-4444-4444-8444-444444444444';
$repo=new XmlStockUsageRepository($pdo);
$res=$repo->reserve($ctx('ban_monitoring','eo-c.casino'),$u4,gmdate('Y-m-d H:i:s'));
$repo->claim((int)$res['id'],gmdate('Y-m-d H:i:s')); // «другой worker» уже забрал (reserved→started)
$calls=0; $r4=$svc->execute($ctx('ban_monitoring','eo-c.casino'),$u4);
t('claim race: transport НЕ вызван', $calls, 0);
t('claim race: http=0 + no-HTTP исход', [$r4['http'], in_array($r4['error']??'',['claim_lost','in_flight_started'],true)], [0,true]);

echo "=== 5. §11.5 claim rowCount=1 (второй claim = false) ===\n";
$u5='55555555-5555-4555-8555-555555555555';
$res5=$repo->reserve($ctx('ban_monitoring','eo-d.casino'),$u5,gmdate('Y-m-d H:i:s'));
t('первый claim=true', $repo->claim((int)$res5['id'],gmdate('Y-m-d H:i:s')), true);
t('второй claim=false', $repo->claim((int)$res5['id'],gmdate('Y-m-d H:i:s')), false);

echo "=== 6. Reserve fail → HTTP=0 ===\n";
$calls=0;
$failRepo=new class($pdo) extends XmlStockUsageRepository { public function reserve(XmlStockRequestContext $c,string $u,string $n):array{ return ['created_new'=>false,'id'=>0,'row'=>null]; } };
$svcFail=new XmlStockRequestService(function($c) use (&$calls){ $calls++; return ['ok'=>true,'indexed'=>true,'pages_indexed'=>1]; }, $failRepo, $clock, fn()=>true);
$rf=$svcFail->execute($ctx(),'66666666-6666-4666-8666-666666666666');
t('reserve fail: transport НЕ вызван', $calls, 0);
t('reserve fail: error=usage_reserve_failed', $rf['error']??'', 'usage_reserve_failed');

echo "=== 7. Transport exception → ambiguous, отдельно ===\n";
$u7='77777777-7777-4777-8777-777777777777';
$svcEx=new XmlStockRequestService(function($c){ throw new RuntimeException('boom'); }, new XmlStockUsageRepository($pdo), $clock, fn()=>true);
$re=$svcEx->execute($ctx('ban_monitoring','eo-e.casino'),$u7);
$row7=$pdo->query("SELECT execution_state FROM xmlstock_request_log WHERE request_uuid='$u7'")->fetch();
t('exception → ambiguous', $row7['execution_state'], 'ambiguous');
t('exception → http=1, ambiguous flag', [$re['http'],$re['ambiguous']??false], [1,true]);

echo "=== 8. §21.4 central accounting: все purposes reserve-before-HTTP ===\n";
foreach(['index_watching','final_monitoring','ban_monitoring','manual_test'] as $i=>$pp){
    $svc=$mk(); $svc->execute(new XmlStockRequestContext($pp,'eo-p'.$i.'.casino',186,null,($pp==='ban_monitoring'?10:null),'monitoring',null,$pp==='manual_test'?'operator':'cron'),sprintf('%08d-0000-4000-8000-000000000000',$i));
    $row=$pdo->query("SELECT execution_state,reserved_at FROM xmlstock_request_log WHERE purpose='$pp' AND domain='eo-p$i.casino'")->fetch();
    t("$pp: reserved_at до completed", [!empty($row['reserved_at']),$row['execution_state']], [true,'completed']);
}

echo "=== 9. Инвариант: нет completed без charge; нет charge без http_attempted ===\n";
$completedNoCharge=(int)$pdo->query("SELECT COUNT(*) FROM xmlstock_request_log WHERE execution_state='completed' AND (http_attempted=0 OR assumed_charged=0) AND domain LIKE 'eo-%'")->fetchColumn();
t('нет completed без http_attempted+charged', $completedNoCharge, 0);
$chargedNoHttp=(int)$pdo->query("SELECT COUNT(*) FROM xmlstock_request_log WHERE assumed_charged=1 AND http_attempted=0 AND domain LIKE 'eo-%'")->fetchColumn();
t('нет charged без http_attempted', $chargedNoHttp, 0);
$ambiguousShown=(int)$pdo->query("SELECT COUNT(*) FROM xmlstock_request_log WHERE execution_state='ambiguous' AND domain LIKE 'eo-%'")->fetchColumn();
t('ambiguous показывается отдельно (>=1)', $ambiguousShown>=1, true);

$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'eo-%'");
echo "\n============================================================\n";
echo "ИТОГО (exactly-once): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
