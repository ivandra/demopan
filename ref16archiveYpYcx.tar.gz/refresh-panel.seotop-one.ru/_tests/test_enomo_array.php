<?php
/** End-to-end на РЕАЛЬНОМ формате Enomo ($site=[...]): fenix51→fenix52,
 *  DFenix51→DFenix52, new sub_id=3 occ, old=0, upload=1, read-back SHA=target SHA.
 *  Запуск: php _tests/test_enomo_array.php */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

$raw=file_get_contents(dirname(__DIR__).'/_tests/fixtures/configs/enomo-array.php');
class ESync extends SiteConfigSyncService {
  public $raw; private $p; public $uploads=0; public $persists=0; public $corruptOnUpload=null;
  public function __construct($r){ $this->p=new SiteConfigParser(); $this->raw=$r; }
  public function fetchFromVpsReadOnly(int $s):array{ try{$pp=$this->p->parse($this->raw);}catch(\Throwable $e){$pp=[];}
    return ["ok"=>true,"raw"=>$this->raw,"path"=>"config.php","sha256"=>hash("sha256",$this->raw),"parsed"=>$pp,"kind"=>"array"]; }
  public function uploadRaw(int $s,string $p,string $c):array{ $this->uploads++; $this->raw=$this->corruptOnUpload??$c; return ["ok"=>true]; }
  public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd):array{ $this->persists++; return ["ok"=>true]; }
}
$mask=new DomainMaskService([],true);

// PREPARE
$sync=new ESync($raw);
$svc=new SiteConfigMutationService($sync,new StaticSiteConfigScanner(),$mask);
$prep=$svc->prepare(14,940014,'fenix51.casino','fenix52.casino');
tb('prepare ok (не false NO_SUB_ID)', $prep['ok']??false);
$plan=$prep['plan'];
t('old_sub_id=DFenix51', $plan['old_sub_id'], 'DFenix51');
t('new_sub_id=DFenix52', $plan['new_sub_id'], 'DFenix52');
t('expected: 3 поля', count($plan['expected']['fields']), 3);
$tgt=file_get_contents(Paths::storage($plan['target_storage_path']));
t('target: домен fenix52 (fenix51=0)', substr_count($tgt,'fenix52.casino')===1 && substr_count($tgt,'fenix51.casino')===0, true);
t('target: new sub_id = 3 occurrences', substr_count($tgt,'sub_id=DFenix52'), 3);
t('target: old sub_id = 0', substr_count($tgt,'DFenix51'), 0);

// APPLY
$res=$svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
tb('apply ok', $res['ok']??false);
t('upload = 1', $sync->uploads, 1);
t('persist = 1', $sync->persists, 1);
t('final: new sub_id = 3', substr_count($sync->raw,'sub_id=DFenix52'), 3);
t('final: old sub_id = 0', substr_count($sync->raw,'DFenix51'), 0);
t('read-back SHA = target SHA', hash('sha256',$sync->raw)===$plan['target_sha256'], true);

// защита: испорченный read-back Enomo → mismatch (не подтверждает неверный target)
$sync2=new ESync($raw);
$svc2=new SiteConfigMutationService($sync2,new StaticSiteConfigScanner(),$mask);
$prep2=$svc2->prepare(14,940015,'fenix51.casino','fenix52.casino');
$sync2->corruptOnUpload=str_replace('DFenix52','DFenix51',file_get_contents(Paths::storage($prep2['plan']['target_storage_path']))); // вернём старый
$res2=$svc2->applyPrepared(ConfigMutationPlan::fromArray($prep2['plan']));
t('испорченный read-back → read_back_sha_mismatch', $res2['reason'], 'read_back_sha_mismatch');

echo "\n============================================================\n";
echo "ИТОГО (enomo array e2e): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
