<?php
/** ТЗ 048 — постоянная привязка сайта→Webmaster: persistence, job snapshot precedence, delete-guard,
 *  инвариант «binding не трогает site_webmaster_links / уже созданные джобы». */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
require_once dirname(__DIR__).'/app/Core/Controller.php';
require_once dirname(__DIR__).'/app/Controllers/SitesController.php';
require_once dirname(__DIR__).'/app/Controllers/WebmasterTokenController.php';
require_once dirname(__DIR__).'/app/Controllers/RefreshJobController.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (no pdo_mysql)\n"; exit(0); }
$sock=getenv('RP_DB_SOCKET'); $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{
  $pdo=$sock?new PDO("mysql:unix_socket={$sock};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC])
           :new PDO('mysql:host=127.0.0.1;port=3306;charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $pdo->exec("CREATE DATABASE IF NOT EXISTS rpsw"); $pdo->exec("USE rpsw");
}catch(\Throwable $e){ echo "SKIPPED (DB unavailable)\n"; exit(0); }
$rp=new ReflectionClass('DB'); $p=$rp->getProperty('pdo'); $p->setAccessible(true); $p->setValue(null,$pdo);

// schema
$pdo->exec("DROP TABLE IF EXISTS sites_managed");
$pdo->exec("CREATE TABLE sites_managed(id INT PRIMARY KEY, current_domain VARCHAR(255), webmaster_account_id INT NULL)");
$pdo->exec("DROP TABLE IF EXISTS yandex_webmaster_accounts");
$pdo->exec("CREATE TABLE yandex_webmaster_accounts(id INT PRIMARY KEY, email VARCHAR(255), access_token_enc TEXT NULL)");
$pdo->exec("DROP TABLE IF EXISTS refresh_jobs");
$pdo->exec("CREATE TABLE refresh_jobs(id INT AUTO_INCREMENT PRIMARY KEY, site_id INT, webmaster_account_override_id INT NULL, stage VARCHAR(64), stage_status VARCHAR(32))");
$pdo->exec("DROP TABLE IF EXISTS site_webmaster_links");
$pdo->exec("CREATE TABLE site_webmaster_links(id INT AUTO_INCREMENT PRIMARY KEY, site_id INT, domain VARCHAR(255))");
$pdo->exec("CREATE TABLE IF NOT EXISTS site_webmaster_assignment_log(id BIGINT AUTO_INCREMENT PRIMARY KEY, site_id INT, old_webmaster_account_id INT NULL, new_webmaster_account_id INT NULL, source VARCHAR(32), created_at DATETIME DEFAULT NOW())");
$pdo->exec("INSERT INTO sites_managed(id,current_domain,webmaster_account_id) VALUES(63,'kazik13.casino',NULL)");
$pdo->exec("INSERT INTO yandex_webmaster_accounts(id,email,access_token_enc) VALUES(6,'livancov@yandex.ru','enc'),(3,'tdi@yandex.ru','enc'),(9,'notoken@x.ru','')");
$pdo->exec("INSERT INTO site_webmaster_links(site_id,domain) VALUES(63,'kazik12.casino')"); // history — не должно меняться

class RedirectStop extends \Exception {}
class TestSites extends SitesController {
  public $flashes=[];
  protected function requireAuth(): void {}
  protected function requireCsrf(): void {}
  protected function flash(string $t,string $m): void { $this->flashes[]=[$t,$m]; }
  protected function redirect(string $u): void { throw new RedirectStop($u); }
}
function save($ctrl,$siteId,$accId){ $_POST=['site_id'=>$siteId,'webmaster_account_id'=>$accId,'csrf_token'=>'x'];
  try{ $ctrl->saveWebmasterAccount(); }catch(RedirectStop $e){} }
function bindingOf($pdo){ return $pdo->query("SELECT webmaster_account_id FROM sites_managed WHERE id=63")->fetchColumn(); }
function linksCount($pdo){ return (int)$pdo->query("SELECT COUNT(*) FROM site_webmaster_links WHERE site_id=63")->fetchColumn(); }

$c=new TestSites();

// ── SITE-WM-01: NULL → #6 ──
$linksBefore=linksCount($pdo);
save($c,63,6);
t('SITE-WM-01 binding NULL→#6', (int)bindingOf($pdo), 6);
$log1=(int)$pdo->query("SELECT COUNT(*) FROM site_webmaster_assignment_log WHERE site_id=63 AND new_webmaster_account_id=6")->fetchColumn();
tb('SITE-WM-01 запись в assignment_log', $log1>=1);

// ── SITE-WM-02: reload не теряет binding (повторное чтение) ──
t('SITE-WM-02 reload сохраняет #6', (int)$pdo->query("SELECT webmaster_account_id FROM sites_managed WHERE id=63")->fetchColumn(), 6);

// ── SAFE-04: site_webmaster_links не тронут ──
t('SAFE-04 site_webmaster_links не изменён', linksCount($pdo), $linksBefore);

// ── SITE-WM-03: снять привязку (0 → NULL) ──
save($c,63,0);
t('SITE-WM-03 account_id=0 → NULL', bindingOf($pdo), null);

// ── SITE-WM-04: несуществующий аккаунт → отклонено, старое не меняется ──
save($c,63,6); // сначала привяжем к 6
save($c,63,999); // затем пытаемся на несуществующий
t('SITE-WM-04 nonexistent отклонён, binding остался #6', (int)bindingOf($pdo), 6);
// аккаунт без токена → тоже отклонён
save($c,63,9);
t('SITE-WM-04b аккаунт без токена отклонён, binding остался #6', (int)bindingOf($pdo), 6);

// ── JOB-WM snapshot precedence (resolveWebmasterSnapshot) ──
$job=new RefreshJobController();
$m=new ReflectionMethod('RefreshJobController','resolveWebmasterSnapshot'); $m->setAccessible(true);
$r1=$m->invoke($job,null,6);  t('JOB-WM-01 (no override, binding 6) → 6/site_binding', [$r1['account_id'],$r1['source']], [6,'site_binding']);
$r2=$m->invoke($job,3,6);     t('JOB-WM-02 (override 3, binding 6) → 3/job_override', [$r2['account_id'],$r2['source']], [3,'job_override']);
$r3=$m->invoke($job,null,0);  t('JOB-WM-03 (no override, no binding) → null/auto', [$r3['account_id'],$r3['source']], [null,'auto']);

// ── JOB-WM-04: изменение site binding не меняет уже созданную job ──
$pdo->exec("INSERT INTO refresh_jobs(site_id,webmaster_account_override_id,stage,stage_status) VALUES(63,6,'wm_added','running')");
$jid=(int)$pdo->lastInsertId();
save($c,63,3); // сменили привязку сайта на #3
t('JOB-WM-04 существующая job.override осталась 6', (int)$pdo->query("SELECT webmaster_account_override_id FROM refresh_jobs WHERE id=$jid")->fetchColumn(), 6);
t('JOB-WM-04 site binding теперь 3', (int)bindingOf($pdo), 3);
$r4=$m->invoke($job,null,3); t('JOB-WM-04 новая job взяла бы 3', $r4['account_id'], 3);

// ── SAFE-01: аккаунт привязан к сайтам → delete запрещён ──
class TestWtc extends WebmasterTokenController {
  public $flashes=[];
  protected function requireAuth(): void {}
  protected function flash(string $t,string $m): void { $this->flashes[]=[$t,$m]; }
  protected function redirect(string $u): void { throw new RedirectStop($u); }
}
// site 63 сейчас привязан к #3 → удаление #3 запрещено
$wtc=new TestWtc();
$mb=new ReflectionMethod('WebmasterTokenController','accountDeleteBlockReason'); $mb->setAccessible(true);
$reason3=$mb->invoke($wtc,3);
tb('SAFE-01 delete #3 запрещён (привязан сайт)', $reason3!==null && strpos($reason3,'сайтов')!==false);
// #6 больше не привязан, но есть активная job с override=6 → запрещено
$reason6=$mb->invoke($wtc,6);
tb('SAFE-02 delete #6 запрещён (активная job)', $reason6!==null && strpos($reason6,'джоб')!==false);
// #9 никуда не привязан и не в джобах → можно
$reason9=$mb->invoke($wtc,9);
t('SAFE delete #9 разрешён (нет привязок/джоб)', $reason9, null);

// реальный delete() #3 не должен удалить
$_POST=['id'=>3]; try{ $wtc->delete(); }catch(RedirectStop $e){}
t('SAFE-01 #3 не удалён из БД', (int)$pdo->query("SELECT COUNT(*) FROM yandex_webmaster_accounts WHERE id=3")->fetchColumn(), 1);

echo "\n============================================================\n";
echo "ИТОГО (site webmaster binding): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
