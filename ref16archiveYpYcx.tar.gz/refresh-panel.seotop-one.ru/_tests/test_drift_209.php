<?php
/** ТЗ044 §16.1 — DRIFT-209: точная репродукция инцидента #209 (config domain drift). */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

class DSync extends SiteConfigSyncService {
    public $raw; private $parser; public $uploads=0;
    public function __construct($raw){ $this->parser=new SiteConfigParser(); $this->raw=$raw; }
    public function fetchFromVpsReadOnly(int $s): array {
        try{$p=$this->parser->parse($this->raw);}catch(\Throwable $e){return ['ok'=>false,'error'=>'parser exception'];}
        return ['ok'=>true,'raw'=>$this->raw,'path'=>'config.php','sha256'=>hash('sha256',$this->raw),'parsed'=>$p,'kind'=>'flat'];
    }
    public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; $this->raw=$c; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { return ['ok'=>true]; }
}
$mask=new DomainMaskService([],true);
$mk=fn($raw)=>[$s=new DSync($raw), new SiteConfigMutationService($s, new StaticSiteConfigScanner(), $mask)];

// ── DRIFT-209-01: дословный production source (#209): live $domain=7k5274, job old=7k5275
$P='partners7k-promo.com';
$RAW=
"<?php\n".
"\$domain = 'https://7k5274.casino';\n".
"\$internal_reg_url = \"https://$P/l/1?sub_id=7k5275\";\n".
"\$redirect_enabled = 0; // REFRESH-DISABLED // REFRESH-DISABLED\n".
"\$base_new_url = \"https://$P/l/2?sub_id=7k5275\";\n".
"\$base_second_url = \"https://$P/l/3?sub_id=7k5275\";\n";
[$sync,$svc]=$mk($RAW);
$r=$svc->prepare(7,209,'7k5275.casino','7k5278.casino');
tb('DRIFT-209-01 prepare ok (нет prepared_target_invalid)', $r['ok']);
if($r['ok']){
  $plan=$r['plan']; $tgt=file_get_contents(Paths::storage($plan['target_storage_path']));
  tb('  drift detected', $plan['config_domain_drift']['detected']===true);
  t ('  live_config_domain=7k5274.casino', $plan['config_domain_drift']['live_config_domain'], '7k5274.casino');
  t ('  target_domain=7k5278.casino', $plan['config_domain_drift']['target_domain'], '7k5278.casino');
  tb('  $domain стал https://7k5278.casino', strpos($tgt,"\$domain = 'https://7k5278.casino'")!==false);
  tb('  старый live-домен 7k5274 отсутствует', strpos($tgt,'7k5274')===false);
  tb('  sub_id=7k5278 во всех 3 полях', substr_count($tgt,'sub_id=7k5278')===3 && strpos($tgt,'7k5275')===false);
  tb('  partner host не изменён', substr_count($tgt,$P)===3);
  t ('  new_sub_id=7k5278', $plan['new_sub_id'], '7k5278');
  t ('  FTP uploads во время prepare = 0', $sync->uploads, 0);
  @unlink(Paths::storage($plan['target_storage_path']));
}

// ── DRIFT-209-02: partial state — $domain уже target 7k5278, sub_id ещё 7k5275
$RAW2=
"<?php\n".
"\$domain = 'https://7k5278.casino';\n".
"\$base_new_url = \"https://$P/l/2?sub_id=7k5275\";\n";
[$s2,$svc2]=$mk($RAW2);
$r2=$svc2->prepare(7,209,'7k5275.casino','7k5278.casino');
tb('DRIFT-209-02 prepare ok (idempotent domain)', $r2['ok']);
if($r2['ok']){
  $t2=file_get_contents(Paths::storage($r2['plan']['target_storage_path']));
  tb('  domain остаётся 7k5278', strpos($t2,'https://7k5278.casino')!==false);
  tb('  sub_id -> 7k5278', strpos($t2,'sub_id=7k5278')!==false && strpos($t2,'7k5275')===false);
  @unlink(Paths::storage($r2['plan']['target_storage_path']));
}

// ── DRIFT-03: динамический domain → blocked unrecognized_domain_field, uploads=0
[$s3,$svc3]=$mk("<?php\n\$domain = buildDomain();\n\$base_new_url=\"https://$P/x?sub_id=7k5275\";\n");
$r3=$svc3->prepare(7,209,'7k5275.casino','7k5278.casino');
t('DRIFT-03 dynamic domain blocked', $r3['reason'] ?? 'ok', 'unrecognized_domain_field');
t('DRIFT-03 FTP uploads=0', $s3->uploads, 0);

// ── DRIFT-04: несколько статических domain assignment → domain_conflict
[$s4,$svc4]=$mk("<?php\n\$domain='https://a.casino';\n\$domain='https://b.casino';\n");
$r4=$svc4->prepare(7,209,'a.casino','c.casino');
// scanner может первым поймать duplicate_config_field (тот же path) — оба являются fail-closed блоком записи
tb('DRIFT-04 несколько domain → blocked (нет записи)', $r4['ok']===false && in_array($r4['reason'],['domain_conflict','duplicate_config_field'],true));
t('DRIFT-04 FTP uploads=0', $s4->uploads, 0);

echo "\n============================================================\n";
echo "ИТОГО (drift 209): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
