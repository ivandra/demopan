<?php
/** Prepare: полный target в памяти (домен+sub_id), semantic verify до FTP, storage 0600.
 *  Включает P01 (domain+sub_id в одной строке). Запуск: php _tests/test_prepare_target.php */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

class PSync extends SiteConfigSyncService {
    public $raw; private $parser; public $uploads=0; public $persists=0;
    public function __construct($raw){ $this->parser=new SiteConfigParser(); $this->raw=$raw; }
    public function fetchFromVpsReadOnly(int $s): array {
        try{$p=$this->parser->parse($this->raw);}catch(\Throwable $e){return ['ok'=>false,'error'=>'parser exception'];}
        return ['ok'=>true,'raw'=>$this->raw,'path'=>'config.php','sha256'=>hash('sha256',$this->raw),'parsed'=>$p,'kind'=>'flat'];
    }
    public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; $this->raw=$c; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { $this->persists++; return ['ok'=>true]; }
}
$mask=new DomainMaskService([],true);
$mk=fn($raw)=>new SiteConfigMutationService(new PSync($raw), new StaticSiteConfigScanner(), $mask);

// 7k flat: domain + 3 URL fields, drift 7k5241, домен 7k5268→7k5269
$RAW="<?php\n\$domain='https://7k5268.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$base_second_url=\"https://p.com/b?sub_id=7k5241\";\n\$internal_reg_url=\"https://p.com/c?sub_id=7k5241\";\n";
$svc=$mk($RAW);
$r=$svc->prepare(7,183,'7k5268.casino','7k5269.casino');
tb('prepare ok', $r['ok']);
$plan=$r['plan'];
t('old_sub_id=7k5241', $plan['old_sub_id'], '7k5241');
t('new_sub_id=7k5269', $plan['new_sub_id'], '7k5269');
tb('source_sha256 64hex', preg_match('~^[0-9a-f]{64}$~',$plan['source_sha256']));
tb('target_sha256 64hex', preg_match('~^[0-9a-f]{64}$~',$plan['target_sha256']));
tb('target != source sha', $plan['target_sha256']!==$plan['source_sha256']);
t('target_storage_path относительный (без /home)', strpos($plan['target_storage_path'],'/home')===false, true);
$abs=Paths::storage($plan['target_storage_path']);
tb('target-файл существует', is_file($abs));
t('target-файл права 0600', substr(sprintf('%o',fileperms($abs)),-4), '0600');
$target=file_get_contents($abs);
tb('target: новый домен', strpos($target,'7k5269.casino')!==false && strpos($target,'7k5268.casino')===false);
tb('target: новый sub_id x3', substr_count($target,'sub_id=7k5269')===3 && strpos($target,'7k5241')===false);
t('expected.domain', $plan['expected']['domain'], 'https://7k5269.casino');
t('expected 3 полей', count($plan['expected']['fields']), 3);
@unlink($abs);

// P01: domain и sub_id в ОДНОЙ строке
$RAW2="<?php\n\$redirect_url=\"https://7k5268.casino/go?sub_id=7k5241\";\n";
$svc2=$mk($RAW2);
$r2=$svc2->prepare(7,184,'7k5268.casino','7k5269.casino');
tb('P01 prepare ok', $r2['ok']);
$t2=file_get_contents(Paths::storage($r2['plan']['target_storage_path']));
tb('P01 оба новых в одной строке', strpos($t2,'7k5269.casino/go?sub_id=7k5269')!==false);
@unlink(Paths::storage($r2['plan']['target_storage_path']));

// P02: target semantic invalid → но prepare сам верифицирует; смоделируем через unknown источник
$r3=$mk("<?php\n\$redirect_url='https://x?sub_id=' . \$sid;\n")->prepare(7,185,'a.casino','b.casino');
t('unsafe источник → blocked (write=0)', $r3['ok'], false);
t('reason unrecognized', $r3['reason'], 'unrecognized_sub_id_field');

// no-subid: домен меняется, sub_id нет
$r4=$mk("<?php\n\$domain='https://a.casino';\n\$base_new_url=\"https://p.com/x\";\n")->prepare(7,186,'a.casino','b.casino');
tb('no-subid prepare ok', $r4['ok']);
t('no-subid new_sub_id=null', $r4['plan']['new_sub_id'], null);
@unlink(Paths::storage($r4['plan']['target_storage_path']));

echo "\n============================================================\n";
echo "ИТОГО (prepare target): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
