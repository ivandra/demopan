<?php
/** §9 QueryService: достоверные KPI (мониторы ≠ 0 в прогнозе), счётчики §5.2,
 *  история с total, ошибки не «молча 0».
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/xmlstock_ui2/test_query_service.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp31t';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4","root","",[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'qs-%'");
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'qs-%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 998001 AND 998009");
foreach([998001,998002,998003] as $jid){ $pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,created_at) VALUES (?,?,?,?,'refresh','done','ok',NOW())")->execute([$jid,1,'o','qs-'.$jid.'.casino']); }
$q=new XmlStockDashboardQueryService($pdo);
$snapJ=json_encode(['initial_delay_minutes'=>720,'regular_interval_minutes'=>30,'probable_negative_count'=>3,'confirm_interval_minutes'=>10,'insurance_negative_count'=>3,'insurance_interval_minutes'=>10,'technical_error_retry_minutes'=>30,'telegram_retry_minutes'=>10,'telegram_max_attempts'=>20]);

echo "=== §2.3.2/§11.3: активные мониторы дают НЕнулевой прогноз ===\n";
// 3 монитора: due сейчас (monitoring), в горизонте (waiting), за горизонтом (waiting +30ч)
$mk=function($jid,$dom,$state,$next) use ($pdo,$snapJ){ $pdo->prepare("INSERT INTO site_ban_monitors (site_id,source_job_id,domain,indexed_at,monitoring_starts_at,next_check_at,last_positive_at,state,activation_generation,policy_version,policy_snapshot_json) VALUES (NULL,?,?, '2026-08-01 00:00:00',?,?,'2026-08-01 00:00:00',?,1,1,?)")->execute([$jid,$dom,$next,$next,$state,$snapJ]); };
$mk(998001,'qs-a.casino','monitoring',gmdate('Y-m-d H:i:s', time()+600));
$mk(998002,'qs-b.casino','waiting_initial_delay',gmdate('Y-m-d H:i:s', time()+3600*5));
$mk(998003,'qs-c.casino','waiting_initial_delay',gmdate('Y-m-d H:i:s', time()+3600*30));
$f=$q->forecast([],0);
t('forecast ok', $f['ok'], true);
t('active_monitors >= 3', $f['active_monitors']>=3, true);
t('next24h > 0 (мониторы учтены)', $f['next24h']>0, true);
t('steady >= 3*48 (штатная оценка)', $f['steady']>=144, true);
t('nearest_at установлен', !empty($f['nearest_at']), true);
$fOnly24=$q->forecast([],0);
// монитор за горизонтом не должен добавлять в next24h больше, чем в горизонте:
// проверка косвенная — next24h < steady (за-горизонтный вклад отсутствует в 24ч)
t('next24h < steady (за-горизонтный монитор не в 24ч)', $fOnly24['next24h'] < $fOnly24['steady'], true);

echo "=== polling-джобы входят в обе оценки ===\n";
$f2=$q->forecast([['id'=>1,'new_domain'=>'p.casino','stage'=>'index_watching','paused'=>false,'stopped'=>false,'est_per_day'=>48,'next_run_at'=>gmdate('Y-m-d H:i:s',time()+300)]],48);
t('poller добавил в next24h', $f2['next24h']>=$f['next24h']+48, true);
t('poller добавил в steady', $f2['steady'], $f['steady']+48);

echo "=== §5.2 activation counters ===\n";
$a=$q->banActivationSummary();
t('activation ok', $a['ok'], true);
t('manual >= 2 (боевые #189/#190)', $a['monitors_manual']>=2, true);
t('auto_eligible считает только после cutoff', is_int($a['auto_eligible_jobs']), true);

echo "=== история: total + пагинация ===\n";
for($i=0;$i<3;$i++){
  $u=new XmlStockUsageRepository($pdo);
  $r=$u->reserve(new XmlStockRequestContext('manual_test','qs-h.casino',null,null,null,null,null,'operator'), sprintf('qsh%05d-0000-4000-8000-00000000000%d',$i,$i), gmdate('Y-m-d H:i:s'));
  $u->claim((int)$r['id'],gmdate('Y-m-d H:i:s'));
  $u->complete((int)$r['id'],['result'=>'indexed','pages_indexed'=>1,'http_code'=>200,'normalized_result_json'=>'{}'],gmdate('Y-m-d H:i:s'));
}
$h=$q->requestHistory(['domain'=>'qs-h'],1,2);
t('history ok', $h['ok'], true);
t('total=3', $h['total'], 3);
t('pages=2 (perPage=2)', $h['pages'], 2);
t('первая страница 2 строки', count($h['rows']), 2);
$h2=$q->requestHistory(['domain'=>'qs-h'],2,2);
t('вторая страница 1 строка', count($h2['rows']), 1);

echo "=== ошибки не «молча 0»: сломанный PDO → ok=false ===\n";
$bad=new PDO("mysql:unix_socket={$sock};dbname={$name}","root","",[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
// детерминированная поломка: схема без таблиц панели → каждый SELECT кидает exception
$bad->exec("USE information_schema");
$qb=new XmlStockDashboardQueryService($bad);
$sb=$qb->summary();
t('summary при ошибке → ok=false (не нули)', $sb['ok'], false);
$hb=$qb->requestHistory([],1);
t('history при ошибке → ok=false', $hb['ok'], false);

$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'qs-%'");
$pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'qs-%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 998001 AND 998009");
echo "\n============================================================\n";
echo "ИТОГО (query service §9): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
