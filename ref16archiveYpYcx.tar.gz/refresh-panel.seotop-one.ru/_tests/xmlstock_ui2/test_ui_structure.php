<?php
/** §6/§11.3 (тестовый эквивалент): структура нового UI — классы дизайн-системы,
 *  отсутствие светлых подложек и btn small, CSRF+tab во всех POST-формах,
 *  русские labels через XmlStockLabels, рендер всех 4 вкладок без ошибок.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/xmlstock_ui2/test_ui_structure.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp31t';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4","root","",[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php'; require_once $ROOT.'/app/Controllers/XmlStockController.php';
@session_start(); $_SESSION['auth']=true; $_SESSION['csrf_token']='ui-tok';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

$view=file_get_contents($ROOT.'/app/Views/xmlstock/index.php');
$card=file_get_contents($ROOT.'/app/Views/jobs/_ban_monitor_card.php');
$css=file_get_contents($ROOT.'/public/assets/admin.css');

echo "=== §6.1: запреты вёрстки ===\n";
t('view: нет #f6f6f6', strpos($view,'#f6f6f6'), false);
t('карточка джобы: нет #f6f6f6', strpos($card,'#f6f6f6'), false);
t('view: нет class="btn small"', strpos($view,'"btn small"'), false);
t('карточка: нет class="btn small"', strpos($card,'"btn small"'), false);

echo "=== §6.3: CSS-компоненты присутствуют ===\n";
foreach (['xmlstock-page','xmlstock-kpi-grid','xmlstock-kpi','xmlstock-tabs','xmlstock-summary-grid',
          'xmlstock-status-card','xmlstock-policy-summary','xmlstock-table-wrap','xmlstock-monitor-table',
          'xmlstock-monitor-state','xmlstock-series-progress','xmlstock-actions','xmlstock-filter-grid',
          'xmlstock-history-table','xmlstock-alerts','xmlstock-empty'] as $cls) {
    t(".{$cls} в admin.css", strpos($css,'.'.$cls)!==false, true);
}
t('.kv-table (универсальный) в admin.css', strpos($css,'.kv-table')!==false, true);
t('responsive @720px в admin.css', strpos($css,'@media (max-width: 720px)')!==false, true);
t('фильтры переопределяют глобальный input-width', strpos($css,'.xmlstock-filter-grid input[type="text"]')!==false, true);

echo "=== §2.4.3: каждая POST-форма view несёт csrf_token и tab ===\n";
preg_match_all('~<form method="post"[^>]*>(.*?)</form>~si',$view,$mm);
$forms=$mm[1]; $noCsrf=0; $noTab=0;
foreach($forms as $f){ if(strpos($f,'csrf_token')===false)$noCsrf++; if(strpos($f,'name="tab"')===false)$noTab++; }
t('POST-форм найдено >= 12', count($forms)>=12, true);
t('форм без csrf_token: 0', $noCsrf, 0);
t('форм без hidden tab: 0', $noTab, 0);
t('GET-форма истории сохраняет tab', preg_match('~<form method="get"[^>]*>.*?name="tab" value="history"~s',$view)===1, true);

echo "=== §9: labels централизованы (view без самодельных словарей) ===\n";
t('view использует XmlStockLabels', substr_count($view,'XmlStockLabels::')>=10, true);
t('карточка использует XmlStockLabels', substr_count($card,'XmlStockLabels::')>=4, true);
t("view: нет локального словаря состояний ('waiting_initial_delay' =>)", strpos($view,"'waiting_initial_delay' =>"), false);
t("карточка: нет локального словаря состояний", strpos($card,"'waiting_initial_delay' =>"), false);

echo "=== рендер всех 4 вкладок (боевые данные) без ошибок ===\n";
class UiRedir extends \Exception{}
class TUI extends XmlStockController {
    protected function flash(string $t,string $m):void{}
    protected function redirect(string $u):void{ throw new UiRedir($u); }
}
$render=function(string $tab) {
    $_GET=['tab'=>$tab]; if($tab==='history') $_GET['period']='all';
    $ctl=new TUI(); ob_start();
    try{ $ctl->index(); }catch(UiRedir $e){}
    catch(\Throwable $e){ ob_end_clean(); return 'RENDER_FAIL: '.$e->getMessage(); }
    return ob_get_clean();
};
$hOv=$render('overview'); $hMon=$render('monitors'); $hHist=$render('history'); $hSet=$render('settings');
t('overview рендерится', strpos($hOv,'RENDER_FAIL')===false && strlen($hOv)>5000, true);
t('monitors рендерится', strpos($hMon,'RENDER_FAIL')===false && strlen($hMon)>5000, true);
t('history рендерится', strpos($hHist,'RENDER_FAIL')===false && strlen($hHist)>5000, true);
t('settings рендерится', strpos($hSet,'RENDER_FAIL')===false && strlen($hSet)>5000, true);

echo "=== содержимое рендера: KPI/вкладки/русские статусы/пагинация ===\n";
t('KPI: 5 карточек', substr_count($hOv,'xmlstock-kpi__label'), 5);
t('нет дублированной метки «МСК МСК» (все вкладки)', strpos($hOv.$hMon.$hHist.$hSet,'МСК МСК'), false);
t('заголовок и новое пояснение', strpos($hOv,'мониторинга выпадения из индекса')!==false, true);
t('нет старого утверждения «только index_watching/final_monitoring»',
  strpos($hOv,'только при проверке индексации в стадиях')===false, true);
t('вкладки есть', substr_count($hOv,'xmlstock-tabs')>=1, true);
t('обзор: расход по purpose (4 карточки)', substr_count($hOv,'xmlstock-consumer__name'), 4);
t('monitors: таблица с русским статусом', strpos($hMon,'Ожидает первой проверки')!==false, true);
t('monitors: raw state доступен в title', preg_match('~xmlstock-monitor-state[^>]+title="(waiting_initial_delay|monitoring|confirming|insurance|paused)"~',$hMon)===1, true);
t('monitors: прогресс серии', strpos($hMon,'xmlstock-series-progress')!==false, true);
t('monitors: «Подключён вручную» ×2 (боевые)', substr_count($hMon,'Подключён вручную')>=2, true);
t('monitors: модал остановки', strpos($hMon,'xmlstock-stop-modal')!==false, true);
t('history: «Найдено N записей»', preg_match('~Найдено \d+ записей~u',$hHist)===1, true);
t('history: селекты для enum-фильтров (5 select)', substr_count($hHist,'<select name='), 5);
t('history: поле job_id в форме', strpos($hHist,'name="job_id"')!==false, true);
t('settings: status-card активации', strpos($hSet,'Мониторинг новых джоб')!==false, true);
t('settings: policy резюме', strpos($hSet,'Первая проверка через')!==false, true);
t('settings: «применяются только к новым monitor»', strpos($hSet,'только к новым monitor')!==false, true);
t('settings: cutoff в человеческом виде', preg_match('~джоба #\d+ и новее~u',$hSet)===1, true);

echo "\n============================================================\n";
echo "ИТОГО (ui structure §6): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
