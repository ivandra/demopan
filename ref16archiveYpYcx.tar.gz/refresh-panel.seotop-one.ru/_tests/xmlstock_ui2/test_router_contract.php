<?php
/** P0 контракт UI → Router → Controller: каждый action формы зарегистрирован в
 *  public/index.php; поля форм совпадают с $_POST-ожиданиями контроллера; сквозные
 *  POST-вызовы с полями, взятыми ИЗ ФОРМ, реально меняют состояние в БД.
 *  RP_DB_SOCKET=... RP_DB_NAME=rp31t RP_DB_USER=root php _tests/xmlstock_ui2/test_router_contract.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp31t';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4","root","",[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php'; require_once $ROOT.'/app/Controllers/XmlStockController.php';
@session_start(); $_SESSION['auth']=true; $_SESSION['csrf_token']='rc-tok';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

// ---------- 1. Зарегистрированные роуты и маппинг route → метод контроллера ----------
$routerSrc=file_get_contents($ROOT.'/public/index.php');
preg_match_all("~\\\$router->post\\('(/xmlstock[^']*)'\\s*,\\s*function\\s*\\(\\)\\s*\\{\\s*\\(new XmlStockController\\(\\)\\)->(\\w+)\\(\\);~",$routerSrc,$mm,PREG_SET_ORDER);
$postRoutes=[]; foreach($mm as $m){ $postRoutes[$m[1]]=$m[2]; }
preg_match_all("~\\\$router->post\\('([^']+)'~",$routerSrc,$allP); $allPost=array_flip($allP[1]);
$expectedRoutes=['/xmlstock/toggle-enabled','/xmlstock/pause-job','/xmlstock/resume-job','/xmlstock/pause-all','/xmlstock/resume-all',
 '/xmlstock/monitor/check-now','/xmlstock/monitor/pause','/xmlstock/monitor/resume','/xmlstock/monitor/stop',
 '/xmlstock/ban-monitoring/activate-new-jobs','/xmlstock/ban-monitoring/deactivate-new-jobs',
 '/xmlstock/ban-monitoring/toggle-processing','/xmlstock/ban-monitoring/save-policy','/xmlstock/ban-monitoring/bootstrap-jobs'];
sort($expectedRoutes); $gotRoutes=array_keys($postRoutes); sort($gotRoutes);
t('роутер: точный набор 14 POST-маршрутов /xmlstock', $gotRoutes, $expectedRoutes);

// ---------- 2. Рендер всех вкладок реальным контроллером ----------
class RcRedir extends \Exception{}
class TRC extends XmlStockController { public $fl=[];
    protected function flash(string $t,string $m):void{ $this->fl[]=[$t,$m]; }
    protected function redirect(string $u):void{ throw new RcRedir($u); } }
$render=function(string $tab){ $_GET=['tab'=>$tab]; if($tab==='history')$_GET['period']='all';
    $c=new TRC(); ob_start(); try{ $c->index(); }catch(RcRedir $e){} return ob_get_clean(); };
$html=''; foreach(['overview','monitors','history','settings'] as $tb) $html.=$render($tb);
t('нет дублированной метки «МСК МСК»', strpos($html,'МСК МСК'), false);

// ---------- 3. Все action форм существуют в роутере ----------
preg_match_all('~<form method="post" action="([^"]+)"[^>]*>(.*?)</form>~si',$html,$fm,PREG_SET_ORDER);
t('POST-форм в рендере >= 12', count($fm)>=12, true);
$unknown=[];
foreach($fm as $f){ if(!isset($allPost[$f[1]])) $unknown[$f[1]]=true; }
t('все action зарегистрированы в public/index.php', array_keys($unknown), []);

// ---------- 4. Поля форм ⊇ обязательные $_POST-поля метода контроллера ----------
$ctlSrc=file_get_contents($ROOT.'/app/Controllers/XmlStockController.php');
$methodPost=function(string $method) use ($ctlSrc): array {
    if(!preg_match('~public function '.$method.'\(\): void.*?(?=\n    (?:public|private|protected) function |\n\}\s*$)~s',$ctlSrc,$m)) return [];
    preg_match_all("~\\\$_POST\\['([a-z_]+)'\\]~",$m[0],$pp);
    return array_values(array_unique($pp[1]));
};
$formFields=function(string $body): array {
    preg_match_all('~<(?:input|select|textarea|button)[^>]*name="([^"]+)"~i',$body,$ff);
    return array_values(array_unique($ff[1]));
};
$optional=['comment'=>1,'dry_run'=>1,'tab'=>1]; // необязательные в части методов
$mismatches=[];
foreach($fm as $f){
    $route=$f[1]; if(!isset($postRoutes[$route])) continue;
    $need=$methodPost($postRoutes[$route]); $have=array_flip($formFields($f[2]));
    foreach($need as $field){
        if(isset($optional[$field])) continue;
        if(!isset($have[$field])) $mismatches[]=$route.' → '.$postRoutes[$route].'(): форма не шлёт «'.$field.'»';
    }
}
t('каждое обязательное поле контроллера присутствует в его форме', $mismatches, []);
// прицельные ассерты фактического контракта
$byRoute=[]; foreach($fm as $f){ $byRoute[$f[1]][]=$formFields($f[2]); }
$hasField=function(string $route,string $field) use (&$byRoute): bool {
    foreach($byRoute[$route]??[] as $flds) if(in_array($field,$flds,true)) return true; return false; };
t('/xmlstock/toggle-enabled шлёт enable+comment', $hasField('/xmlstock/toggle-enabled','enable') && $hasField('/xmlstock/toggle-enabled','comment'), true);
// (ассерты monitor-форм перенесены ниже — после гарантии фикстуры)
t('/xmlstock/ban-monitoring/toggle-processing шлёт processing', $hasField('/xmlstock/ban-monitoring/toggle-processing','processing'), true);
t('монитор-формы НЕ шлют устаревшее поле id', $hasField('/xmlstock/monitor/check-now','id') || $hasField('/xmlstock/monitor/pause','id'), false);

// resume-форма рендерится только для paused-монитора — проверяем шаблон статически
$viewSrc=file_get_contents($ROOT.'/app/Views/xmlstock/index.php');
t('resume-форма: action /xmlstock/monitor/resume + monitor_id + resume_mode',
  preg_match('~action="/xmlstock/monitor/resume".*?name="monitor_id".*?name="resume_mode"~s',$viewSrc)===1, true);
t('во view нет несуществующих маршрутов ban-monitoring/(pause|resume|stop|check-now|activate"|deactivate")',
  preg_match('~/xmlstock/ban-monitoring/(pause|resume|stop|check-now|activate"|deactivate")~',$viewSrc), 0);

// ---------- 5. Сквозные вызовы: поля берём ИЗ ФОРМ рендера ----------
$LAST_REDIRECT='';
$callRoute=function(string $route,array $extra=[]) use ($postRoutes,&$LAST_REDIRECT){
    $c=new TRC(); $_POST=array_merge(['csrf_token'=>'rc-tok'],$extra); $LAST_REDIRECT='';
    $m=$postRoutes[$route]; try{ $c->$m(); }catch(RcRedir $e){ $LAST_REDIRECT=$e->getMessage(); } return $c->fl; };
$fieldsOf=function(string $route,string $needle='') use (&$fm,$formFields){
    foreach($fm as $f){ if($f[1]!==$route) continue; if($needle!=='' && strpos($f[2],$needle)===false) continue;
        preg_match_all('~<(?:input|textarea)[^>]*name="([^"]+)"[^>]*value="([^"]*)"~i',$f[2],$kv,PREG_SET_ORDER);
        $out=[]; foreach($kv as $p) $out[$p[1]]=html_entity_decode($p[2]); return $out; }
    return []; };
// самодостаточность: тест не зависит от состояния тестовой БД — при отсутствии
// активных мониторов создаёт собственную фикстуру rc-*.casino
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'rc-%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id=997901");
$MID=0; $OWN=false;
if(true){ // всегда собственная фикстура: сквозной блок не трогает существующие строки БД
    $pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,created_at) VALUES (997901,1,'o','rc-m.casino','refresh','done','ok',NOW())")->execute();
    $snapJ=json_encode(['initial_delay_minutes'=>720,'regular_interval_minutes'=>30,'probable_negative_count'=>3,'confirm_interval_minutes'=>10,'insurance_negative_count'=>3,'insurance_interval_minutes'=>10,'technical_error_retry_minutes'=>30,'telegram_retry_minutes'=>10,'telegram_max_attempts'=>20]);
    $pdo->prepare("INSERT INTO site_ban_monitors (site_id,source_job_id,domain,indexed_at,monitoring_starts_at,next_check_at,last_positive_at,state,activation_generation,policy_version,policy_snapshot_json) VALUES (NULL,997901,'rc-m.casino',NOW(),NOW(),DATE_ADD(NOW(),INTERVAL 1 HOUR),NOW(),'monitoring',1,1,?)")->execute([$snapJ]);
    $MID=(int)$pdo->lastInsertId(); $OWN=true;
    // перечитать рендер, чтобы формы содержали фикстуру
    $html=''; foreach(['overview','monitors','history','settings'] as $tb) $html.=$render($tb);
    preg_match_all('~<form method="post" action="([^"]+)"[^>]*>(.*?)</form>~si',$html,$fm2,PREG_SET_ORDER); $fm=$fm2;
    $byRoute=[]; foreach($fm as $f){ $byRoute[$f[1]][]=$formFields($f[2]); }
}
if($MID>0){
    t('/xmlstock/monitor/check-now шлёт monitor_id', $hasField('/xmlstock/monitor/check-now','monitor_id'), true);
    t('/xmlstock/monitor/stop шлёт monitor_id+comment', $hasField('/xmlstock/monitor/stop','monitor_id') && $hasField('/xmlstock/monitor/stop','comment'), true);
    $snap=$pdo->query("SELECT state,next_check_at,negative_streak FROM site_ban_monitors WHERE id=$MID")->fetch();
    // check-now: форма → POST → next_check_at ≈ NOW
    $fields=$fieldsOf('/xmlstock/monitor/check-now','value="'.$MID.'"');
    t('check-now: форма содержит monitor_id='.$MID, (int)($fields['monitor_id']??0), $MID);
    $ledger0=(int)$pdo->query("SELECT COUNT(*) FROM xmlstock_request_log WHERE monitor_id=$MID")->fetchColumn();
    $callRoute('/xmlstock/monitor/check-now',$fields);
    // check-now = немедленный реальный запуск processMonitor('operator'): сквозной эффект —
    // строка в ledger (в песочнице без сети исход failed/ambiguous — сам факт записи важен)
    $lrow=$pdo->query("SELECT COUNT(*) c, MAX(initiated_by) ib FROM xmlstock_request_log WHERE monitor_id=$MID")->fetch();
    t('check-now: ledger-строка создана (форма→роут→контроллер→сервис→БД)', (int)$lrow['c'], $ledger0+1);
    t('check-now: initiated_by=operator', $lrow['ib'], 'operator');
    $nca=$pdo->query("SELECT next_check_at FROM site_ban_monitors WHERE id=$MID")->fetchColumn();
    t('check-now: next_check_at пересчитан (не исходный)', $nca!==$snap['next_check_at'], true);
    t('P1: check-now редиректит на tab=monitors', strpos($LAST_REDIRECT,'tab=monitors')!==false && strpos($LAST_REDIRECT,'monitor_id='.$MID)!==false, true);
    // pause по полям формы → paused
    $fp=$fieldsOf('/xmlstock/monitor/pause','value="'.$MID.'"');
    $callRoute('/xmlstock/monitor/pause',$fp);
    t('pause: state=paused', $pdo->query("SELECT state FROM site_ban_monitors WHERE id=$MID")->fetchColumn(), 'paused');
    t('P1: pause редиректит на tab=monitors', strpos($LAST_REDIRECT,'tab=monitors')!==false, true);
    // resume (continue) — форма рендерится для paused: перечитываем рендер
    $html2=$render('monitors');
    preg_match('~<form method="post" action="/xmlstock/monitor/resume">(.*?)</form>~s',$html2,$rf);
    t('resume-форма отрисована для paused', isset($rf[1]), true);
    $callRoute('/xmlstock/monitor/resume',['monitor_id'=>$MID,'resume_mode'=>'continue']);
    $after=$pdo->query("SELECT state,negative_streak FROM site_ban_monitors WHERE id=$MID")->fetch();
    t('resume(continue): state восстановлен', $after['state'], $snap['state']);
    t('resume(continue): серия сохранена', (int)$after['negative_streak'], (int)$snap['negative_streak']);
    t('P1: resume редиректит на tab=monitors', strpos($LAST_REDIRECT,'tab=monitors')!==false, true);
    // вернуть исходный next_check_at
    $pdo->prepare("UPDATE site_ban_monitors SET next_check_at=? WHERE id=?")->execute([$snap['next_check_at'],$MID]);
}else{ echo "  [--]  активных мониторов нет — сквозной блок monitor-действий пропущен (данные)\n"; }

// toggle-enabled по полям KPI-формы (enable инвертирован) → включение обратно
$XS=(int)$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn();
$ft=$fieldsOf('/xmlstock/toggle-enabled');
$ft['comment']='router-contract test';
$callRoute('/xmlstock/toggle-enabled',$ft);
t('toggle-enabled: enabled переключён по форме', (int)$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn(), $XS?0:1);
$callRoute('/xmlstock/toggle-enabled',['enable'=>$XS,'comment'=>'откат router-contract']);
t('toggle-enabled: возвращён исходный', (int)$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn(), $XS);
$pdo->exec("DELETE FROM ban_monitoring_audit WHERE comment LIKE '%router-contract%'");

if(!empty($OWN)){
    $pdo->exec("DELETE FROM xmlstock_request_log WHERE domain LIKE 'rc-%'");
    $pdo->exec("DELETE FROM site_ban_monitor_checks WHERE monitor_id IN (SELECT id FROM site_ban_monitors WHERE domain LIKE 'rc-%')");
    $pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE 'rc-%'"); $pdo->exec("DELETE FROM refresh_jobs WHERE id=997901"); }
echo "\n============================================================\n";
echo "ИТОГО (router contract UI→Router→Controller): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
