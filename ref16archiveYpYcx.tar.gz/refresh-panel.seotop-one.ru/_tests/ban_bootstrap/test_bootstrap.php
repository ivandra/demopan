<?php
/** Bootstrap ban-monitor по явному списку job_id (no-backfill exception).
 *  RP_DB_SOCKET=... RP_DB_NAME=rp30 RP_DB_USER=root php _tests/ban_bootstrap/test_bootstrap.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE '7k%test%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 993000 AND 993099");
$pdo->exec("DELETE FROM ban_monitoring_audit WHERE action='ban_bootstrap_job'");
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0, activation_generation=0 WHERE id=1");
$set=new BanMonitoringSettingsRepository($pdo);
// две джобы как #189/#190: на финале, generation NULL
function mkjob($pdo,$id,$dom){ $pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status,ban_monitor_generation,created_at) VALUES (?,?,?,?,'refresh','old_delurl_notify','awaiting_user',NULL,NOW())")->execute([$id,700+$id%10,'old.casino',$dom]); }
mkjob($pdo,993001,'7k5272test.casino'); // будет positive → armed
mkjob($pdo,993002,'7k2598test.casino'); // будет negative → не armed
$checks=['7k5272test.casino'=>['classification'=>'positive','pages'=>5,'completed_at'=>'2026-08-01 01:50:00'],
         '7k2598test.casino'=>['classification'=>'valid_negative','pages'=>0,'completed_at'=>'2026-08-01 01:50:00']];
$runner=function($d) use ($checks){ return $checks[$d] ?? ['classification'=>'technical_error','pages'=>0,'completed_at'=>null]; };

echo "=== гард: enrollment выключен → block ===\n";
$svc=new BanMonitorBootstrapService($pdo,$set,new BanMonitorRepository($pdo),$runner);
$r=$svc->bootstrap([993001],'op','причина');
t('enrollment off → block', $r[0]['error']??'', 'enrollment_disabled');

echo "=== гард: пустой комментарий → block ===\n";
$pdo->beginTransaction(); $set->activate(); $pdo->commit();
$gen=$set->activationGeneration();
$r=$svc->bootstrap([993001],'op','');
t('пустой comment → block', $r[0]['error']??'', 'comment_required');

echo "=== positive → монитор поставлен + generation + audit ===\n";
$r=$svc->bootstrap([993001],'operator1','ручное подключение сайта');
t('job 993001 armed', !empty($r[0]['armed']), true);
$mid=(int)($r[0]['monitor_id']??0);
t('monitor создан', $mid>0, true);
$j=$pdo->query("SELECT ban_monitor_generation FROM refresh_jobs WHERE id=993001")->fetch();
t('generation присвоена джобе', (int)$j['ban_monitor_generation'], $gen);
$m=$pdo->query("SELECT state,policy_snapshot_json,indexed_at FROM site_ban_monitors WHERE id={$mid}")->fetch();
t('state=waiting_initial_delay', $m['state'], 'waiting_initial_delay');
t('snapshot заполнен', !empty($m['policy_snapshot_json']), true);
t('indexed_at из completed-чека', $m['indexed_at'], '2026-08-01 01:50:00');
$au=(int)$pdo->query("SELECT COUNT(*) FROM ban_monitoring_audit WHERE action='ban_bootstrap_job' AND object_id=993001")->fetchColumn();
t('audit ban_bootstrap_job записан', $au, 1);

echo "=== negative → НЕ ставим (один negative ≠ бан), generation не трогаем ===\n";
$r=$svc->bootstrap([993002],'operator1','подключение сайта 2');
t('job 993002 не armed', empty($r[0]['armed']), true);
t('skipped=not_indexed_now', $r[0]['skipped']??'', 'not_indexed_now');
t('generation НЕ присвоена (нет baseline)', $pdo->query("SELECT ban_monitor_generation FROM refresh_jobs WHERE id=993002")->fetchColumn(), null);
t('монитор НЕ создан', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE source_job_id=993002")->fetchColumn(), 0);

echo "=== идемпотентность: повтор positive-джобы → не дублирует ===\n";
$r=$svc->bootstrap([993001],'operator1','повтор');
t('повтор → already_monitored', $r[0]['skipped']??'', 'already_monitored');
t('тот же monitor_id', (int)($r[0]['monitor_id']??0), $mid);
t('монитор один', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE source_job_id=993001")->fetchColumn(), 1);

echo "=== technical → не ставим ===\n";
mkjob($pdo,993003,'7ktechtest.casino');
$r=$svc->bootstrap([993003],'op','tech');
t('technical → skipped', $r[0]['skipped']??'', 'technical_error');

echo "=== несуществующая джоба / без домена → skip ===\n";
$r=$svc->bootstrap([999999],'op','x');
t('job_not_found → skip', $r[0]['skipped']??'', 'job_not_found');

echo "=== dry-run: без записи и без XMLStock ===\n";
mkjob($pdo,993004,'7kdrytest.casino');
$called=0; $runner2=function($d) use (&$called,$checks){ $called++; return $checks[$d]??['classification'=>'positive','pages'=>1,'completed_at'=>null]; };
$svc2=new BanMonitorBootstrapService($pdo,$set,new BanMonitorRepository($pdo),$runner2);
$r=$svc2->bootstrap([993004],'op','dry',true);
t('dry-run → dry_run flag', !empty($r[0]['dry_run']), true);
t('dry-run НЕ звал XMLStock', $called, 0);
t('dry-run НЕ создал монитор', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE source_job_id=993004")->fetchColumn(), 0);
t('dry-run НЕ трогал generation', $pdo->query("SELECT ban_monitor_generation FROM refresh_jobs WHERE id=993004")->fetchColumn(), null);

$pdo->exec("DELETE FROM site_ban_monitors WHERE domain LIKE '7k%test%'");
$pdo->exec("DELETE FROM refresh_jobs WHERE id BETWEEN 993000 AND 993099");
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0 WHERE id=1");
echo "\n============================================================\n";
echo "ИТОГО (bootstrap): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
