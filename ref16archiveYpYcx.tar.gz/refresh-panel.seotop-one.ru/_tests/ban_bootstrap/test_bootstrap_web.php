<?php
/** Web-endpoint banBootstrapJobs: CSRF/enrollment/args/dry-run (controller wrapper).
 *  RP_DB_SOCKET=... php _tests/ban_bootstrap/test_bootstrap_web.php */
$ROOT=dirname(__DIR__,2);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test) → BLOCK\n"; exit(3); }
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php'; require_once $ROOT.'/app/Controllers/XmlStockController.php';
// схему гарантируем ТОЛЬКО идемпотентной 038: повторный up 036/037 запрещён ТЗ
// (шаг 8 миграции 037 — разовый v2-cutover, стопит active-мониторы).
foreach(['038_ssl_before_webmaster_and_xmlstock_ui'] as $mg){ $d=require $ROOT."/app/Migrations/$mg.php"; foreach($d['up'] as $s) $s($pdo); }
@session_start(); $_SESSION['auth']=true; $_SESSION['csrf_token']='tok';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
class RedirW extends \Exception{}
class TXW extends XmlStockController { public $fl=[];
  protected function flash(string $t,string $m):void{ $this->fl[]=[$t,$m]; }
  protected function redirect(string $u):void{ throw new RedirW($u); }
  public function call(string $m){ $this->fl=[]; try{ $this->$m(); }catch(RedirW $e){} return $this->fl; } }
$ctl=new TXW();
$pdo->exec("DELETE FROM refresh_jobs WHERE id=994001");
$pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,mode,stage,stage_status) VALUES (994001,701,'o','7kweb.casino','refresh','old_delurl_notify','awaiting_user')")->execute();
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0, activation_generation=0 WHERE id=1");
function lastMsg($fl){ return $fl ? $fl[count($fl)-1][1] : ''; }

echo "=== CSRF ===\n";
$_POST=['csrf_token'=>'WRONG']; t('csrf wrong → false', $ctl->csrfValid(), false);

echo "=== нет job_ids → ошибка ===\n";
$_POST=['csrf_token'=>'tok','comment'=>'x']; $fl=$ctl->call('banBootstrapJobs');
t('пустой job_ids → error', strpos(lastMsg($fl),'job id')!==false, true);

echo "=== enrollment выключен → block ===\n";
$_POST=['csrf_token'=>'tok','job_ids'=>'994001','comment'=>'подключение']; $fl=$ctl->call('banBootstrapJobs');
t('enrollment off → сообщение о включении', strpos(lastMsg($fl),'ключите')!==false || strpos(lastMsg($fl),'Enrollment')!==false, true);

echo "=== боевой без комментария → ошибка ===\n";
(new BanMonitoringSettingsRepository($pdo))->activate();
$_POST=['csrf_token'=>'tok','job_ids'=>'994001','comment'=>'']; $fl=$ctl->call('banBootstrapJobs');
t('пустой comment (боевой) → error', strpos(lastMsg($fl),'комментарий')!==false, true);

echo "=== dry-run → сухой прогон, без монитора ===\n";
$_POST=['csrf_token'=>'tok','job_ids'=>'994001','comment'=>'','dry_run'=>'1']; $fl=$ctl->call('banBootstrapJobs');
t('dry-run → «сухой прогон» в сообщении', strpos(lastMsg($fl),'сухой прогон')!==false, true);
t('dry-run НЕ создал монитор', (int)$pdo->query("SELECT COUNT(*) FROM site_ban_monitors WHERE source_job_id=994001")->fetchColumn(), 0);

echo "=== >20 джоб → отказ ===\n";
$many=implode(',',range(1,25));
$_POST=['csrf_token'=>'tok','job_ids'=>$many,'comment'=>'x']; $fl=$ctl->call('banBootstrapJobs');
t('>20 → ошибка', strpos(lastMsg($fl),'20')!==false, true);

$pdo->exec("DELETE FROM refresh_jobs WHERE id=994001");
$pdo->exec("UPDATE ban_monitoring_settings SET enrollment_enabled=0 WHERE id=1");
echo "\n============================================================\n";
echo "ИТОГО (bootstrap web): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
