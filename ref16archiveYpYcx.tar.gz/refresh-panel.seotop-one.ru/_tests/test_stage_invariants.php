<?php
/** ТЗ044 §5/§6/§16.2 — StageInvariantGuard + OperatorContinuationPolicy (INV-01..05). */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

$sha=str_repeat('a',64);
$goodPlan=['replacement_plan'=>['config_mutation'=>[
  'source_sha256'=>$sha,'target_sha256'=>str_repeat('b',64),
  'target_storage_path'=>'builds/job_209/config.target.php','expected'=>['domain'=>'https://7k5278.casino']]]];

// INV-01: analyze ok, plan отсутствует → переход запрещён
$r=StageInvariantGuard::checkAdvance('analyze_site',[],[]);
tb('INV-01 analyze без plan → advance blocked', $r['ok']===false && $r['violation']==='missing_replacement_plan');

// analyze с валидным planом → advance разрешён
$r=StageInvariantGuard::checkAdvance('analyze_site',[],$goodPlan);
tb('INV-01b analyze с valid plan → advance ok', $r['ok']===true);

// plan есть, но config_mutation нет
tb('INV-01c plan без config_mutation → blocked',
   StageInvariantGuard::checkAdvance('analyze_site',[],['replacement_plan'=>['x'=>1]])['violation']==='missing_config_mutation');

// невалидный sha
$bad=$goodPlan; $bad['replacement_plan']['config_mutation']['source_sha256']='zzz';
tb('INV-01d невалидный source_sha256 → blocked',
   StageInvariantGuard::checkAdvance('analyze_site',[],$bad)['violation']==='invalid_source_sha256');

// INV-03: policy для analyze_site awaiting → RETRY_SAME_STAGE (НЕ advance)
t('INV-03 analyze_site policy = RETRY_SAME_STAGE',
  OperatorContinuationPolicy::actionFor('analyze_site',[],[]), OperatorContinuationPolicy::RETRY_SAME_STAGE);

// allowlist advance
t('INV-03b move_submit_request policy = ADVANCE_CONFIRMED',
  OperatorContinuationPolicy::actionFor('move_submit_request',[],[]), OperatorContinuationPolicy::ADVANCE_CONFIRMED);
t('INV-03c update_classes_call policy = DEDICATED',
  OperatorContinuationPolicy::actionFor('update_classes_call',[],[]), OperatorContinuationPolicy::DEDICATED_ACTION_REQUIRED);

// INV-05: config_replaced без plan → policy BLOCK_INVALID_STATE
t('INV-05 config_replaced без plan policy = BLOCK_INVALID_STATE',
  OperatorContinuationPolicy::actionFor('config_replaced',[],[]), OperatorContinuationPolicy::BLOCK_INVALID_STATE);
// config_replaced с valid plan → RETRY_SAME_STAGE
t('INV-05b config_replaced с plan policy = RETRY_SAME_STAGE',
  OperatorContinuationPolicy::actionFor('config_replaced',[],$goodPlan), OperatorContinuationPolicy::RETRY_SAME_STAGE);

// INV-04: config_replaced → verify требует read_back.ok
tb('INV-04 config_replaced read_back.ok!=true → blocked',
   StageInvariantGuard::checkAdvance('config_replaced',[],['config_replaced_stage'=>['read_back'=>['ok'=>false]]])['ok']===false);
// BLOCKER B: config_replaced read_back.ok=true, но replacement_plan ОТСУТСТВУЕТ → BLOCK (было fail-open)
t('INV-04b config_replaced read_back.ok=true БЕЗ plan → BLOCK',
   StageInvariantGuard::checkAdvance('config_replaced',[],['config_replaced_stage'=>['read_back'=>['ok'=>true]]])['violation'], 'missing_config_mutation_plan');

// redirect_enable invariant: remaining markers → blocked
tb('INV-06 redirect remaining_markers → blocked',
   StageInvariantGuard::checkAdvance('redirect_enable',[],['redirect_enabled_stage'=>['ok'=>true,'remaining_markers'=>['x']]])['ok']===false);
// BLOCKER A: redirect ok + NO read_back + not skipped → BLOCK (было fail-open)
t('INV-06b redirect ok, НЕТ read_back, не skipped → BLOCK',
   StageInvariantGuard::checkAdvance('redirect_enable',[],['redirect_enabled_stage'=>['ok'=>true]])['violation'], 'redirect_read_back_missing_or_failed');
t('BLOCKER A redirect_enable без artifact → BLOCK',
   StageInvariantGuard::checkAdvance('redirect_enable',[],[])['violation'], 'redirect_enable_artifact_missing');
tb('BLOCKER A redirect not_required → ok',
   StageInvariantGuard::checkAdvance('redirect_enable',[],['redirect_enabled_stage'=>['ok'=>true,'not_required'=>true,'action'=>'not_required']])['ok']===true);


// BLOCKER 4: config_replaced guard проверяет target SHA + new_domain безусловно
$planCM=['replacement_plan'=>['config_mutation'=>['target_sha256'=>str_repeat('c',64),'expected'=>['domain_required'=>true,'sub_id'=>'7k5278']]]];
$job209=['new_domain'=>'7k5278.casino'];
$okRB=$planCM+['config_replaced_stage'=>['read_back'=>['ok'=>true,'target_sha256'=>str_repeat('c',64),'domain'=>'7k5278.casino','sub_id'=>'7k5278']]];
tb('BLOCKER4 read-back верный SHA+domain+sub → ok', StageInvariantGuard::checkAdvance('config_replaced',$job209,$okRB)['ok']===true);
$badSha=$planCM+['config_replaced_stage'=>['read_back'=>['ok'=>true,'target_sha256'=>str_repeat('d',64),'domain'=>'7k5278.casino']]];
t('BLOCKER4 неверный target SHA → blocked', StageInvariantGuard::checkAdvance('config_replaced',$job209,$badSha)['violation'], 'read_back_target_sha_mismatch');
$badDom=$planCM+['config_replaced_stage'=>['read_back'=>['ok'=>true,'target_sha256'=>str_repeat('c',64),'domain'=>'7k9999.casino']]];
t('BLOCKER4 неверный домен → blocked', StageInvariantGuard::checkAdvance('config_replaced',$job209,$badDom)['violation'], 'read_back_domain_mismatch');

// BLOCKER 3: redirect_enable guard требует read-back semantic value=1 & markers=0 (fail-closed)
tb('BLOCKER3 read-back value=1 markers=0 → ok', StageInvariantGuard::checkAdvance('redirect_enable',[],['redirect_enabled_stage'=>['ok'=>true,'read_back'=>['ok'=>true,'value'=>1,'marker_count'=>0]]])['ok']===true);
t('BLOCKER3 stale value=0 → blocked', StageInvariantGuard::checkAdvance('redirect_enable',[],['redirect_enabled_stage'=>['ok'=>true,'read_back'=>['ok'=>true,'value'=>0,'marker_count'=>1]]])['violation'], 'redirect_read_back_not_enabled');
t('BLOCKER3 read-back failed → blocked', StageInvariantGuard::checkAdvance('redirect_enable',[],['redirect_enabled_stage'=>['ok'=>true,'read_back'=>['ok'=>false]]])['violation'], 'redirect_read_back_missing_or_failed');
tb('BLOCKER3 skipped by site toggle → ok', StageInvariantGuard::checkAdvance('redirect_enable',[],['redirect_enabled_stage'=>['ok'=>true,'action'=>'skipped_by_site_toggle']])['ok']===true);

echo "\n============================================================\n";
echo "ИТОГО (stage invariants): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
