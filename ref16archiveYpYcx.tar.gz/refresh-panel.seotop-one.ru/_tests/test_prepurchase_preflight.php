<?php
/** ТЗ044 §11/§16.5 — pre-purchase preflight (PREBUY-01..03). FTP write=0, без Namecheap create. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

class PfSync extends SiteConfigSyncService {
    public $raw; private $parser; public $uploads=0;
    public function __construct($raw){ $this->parser=new SiteConfigParser(); $this->raw=$raw; }
    public function fetchFromVpsReadOnly(int $s): array {
        try{$p=$this->parser->parse($this->raw);}catch(\Throwable $e){return ['ok'=>false,'error'=>'parser exception'];}
        return ['ok'=>true,'raw'=>$this->raw,'path'=>'config.php','sha256'=>hash('sha256',$this->raw),'parsed'=>$p,'kind'=>'flat'];
    }
    public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { return ['ok'=>true]; }
}
$mask=new DomainMaskService([],true);
$mk=fn($raw)=>[$s=new PfSync($raw), new SiteConfigMutationService($s, new StaticSiteConfigScanner(), $mask)];
$P='partners7k-promo.com';

// PREBUY-01: unsafe config (dynamic sub_id) → preflight fail, ftp=0, createDomain НЕ вызывается
[$s1,$svc1]=$mk("<?php\n\$redirect_url='https://x?sub_id=' . \$sid;\n");
$r1=$svc1->preflight(7,'7k5278.casino','7k5275.casino');
tb('PREBUY-01 unsafe → preflight NOT ok', $r1['ok']===false);
t ('PREBUY-01 ftp_writes=0', $r1['prepurchase_preflight']['ftp_writes'], 0);
t ('PREBUY-01 FTP uploads=0 (реально)', $s1->uploads, 0);

// PREBUY-02: safe drift как #209 → preflight passes, createDomain разрешён
[$s2,$svc2]=$mk("<?php\n\$domain = 'https://7k5274.casino';\n\$base_new_url=\"https://$P/l?sub_id=7k5275\";\n");
$r2=$svc2->preflight(7,'7k5278.casino','7k5275.casino');
tb('PREBUY-02 safe drift → preflight ok', $r2['ok']===true);
$pf=$r2['prepurchase_preflight'];
tb('PREBUY-02 ok=true', $pf['ok']===true);
t ('PREBUY-02 domain_drift=true', $pf['domain_drift'], true);
t ('PREBUY-02 effective_config_domain=7k5274.casino', $pf['effective_config_domain'], '7k5274.casino');
t ('PREBUY-02 target_domain=7k5278.casino', $pf['target_domain'], '7k5278.casino');
t ('PREBUY-02 target_sub_id=7k5278', $pf['target_sub_id'], '7k5278');
t ('PREBUY-02 ftp_writes=0', $pf['ftp_writes'], 0);
t ('PREBUY-02 FTP uploads=0 (реально)', $s2->uploads, 0);
tb('PREBUY-02 source_sha256 64hex', preg_match('~^[0-9a-f]{64}$~',$pf['source_sha256']));

// PREBUY-03: preflight source SHA записан; после «покупки» source изменился → analyze делает fresh scan.
// Моделируем: prepare() на ИЗМЕНЁННОМ source даёт свой source_sha256 (не равный preflight).
$before=$pf['source_sha256'];
$s2->raw="<?php\n\$domain = 'https://7k5274.casino';\n\$base_new_url=\"https://$P/l?sub_id=7k5275\";\n// changed\n";
$rp=$svc2->prepare(7,209,'7k5275.casino','7k5278.casino');
tb('PREBUY-03 prepare ok на изменённом source', $rp['ok']);
tb('PREBUY-03 fresh source_sha256 != preflight sha (TOCTOU не обходится)', $rp['plan']['source_sha256']!==$before);
@unlink(Paths::storage($rp['plan']['target_storage_path']));

echo "\n============================================================\n";
echo "ИТОГО (prepurchase preflight): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
