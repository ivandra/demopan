<?php
/** ТЗ044 §12–§14/§16.6 — recovery classification (REC-209-01/02, REC-208-01) + concurrency. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
function job($id,$site,$stage,$new='',$art=[]){ return ['id'=>$id,'site_id'=>$site,'stage'=>$stage,'stage_status'=>'failed','new_domain'=>$new,'artifacts_json'=>json_encode($art)]; }
$svc=new JobRecoveryService(null);

// REC-209-01: purchased_domain==new_domain, downstream failed → confirmed_purchased, create=0, return analyze_site
$j209=job(209,7,'config_replaced','7k5278.casino',['purchased_domain'=>'7k5278.casino']);
$c=$svc->classify($j209,[$j209]);
t('REC-209-01 class=confirmed_purchased', $c['class'], JobRecoveryService::CONFIRMED_PURCHASED);
t('REC-209-01 create_domain_allowed=false', $c['create_domain_allowed'], false);
t('REC-209-01 return_stage=analyze_site', $c['return_stage'], 'analyze_site');
$rec=$svc->recover($j209,[$j209],false);
tb('REC-209-01 recovery createDomain count=0 (never)', $rec['create_domain_allowed']===false);
tb('REC-209-01 actions: no_domains_create', in_array('no_domains_create',$rec['actions'],true));

// REC-208-01: старая #208 без покупки, есть новее #209 с подтверждённой покупкой → superseded, create=0
$j208=job(208,7,'analyze_site','',[]);
$sibs=[$j208,$j209];
$c208=$svc->classify($j208,$sibs);
t('REC-208-01 class=superseded', $c208['class'], JobRecoveryService::SUPERSEDED);
t('REC-208-01 newer_job_id=209', $c208['newer_job_id'], 209);
$rec208=$svc->recover($j208,$sibs,false);
tb('REC-208-01 blocked', !empty($rec208['blocked']));
t('REC-208-01 block_reason', $rec208['block_reason'], 'superseded_by_newer_job');
tb('REC-208-01 createDomain count=0', $rec208['create_domain_allowed']===false);

// #208 без новее authoritative → no_purchase (можно перезапустить покупку)
$c208b=$svc->classify($j208,[$j208]);
t('#208 lone → no_purchase', $c208b['class'], JobRecoveryService::NO_PURCHASE);

// ambiguous: незакрытый purchase_confirmation → только read-only
$jamb=job(210,7,'domain_purchasing','',['purchase_confirmation'=>['resolved'=>false]]);
t('ambiguous → AMBIGUOUS_PURCHASE', $svc->classify($jamb,[$jamb])['class'], JobRecoveryService::AMBIGUOUS_PURCHASE);
tb('ambiguous recover blocked', !empty($svc->recover($jamb,[$jamb],false)['blocked']));

// §14 concurrency: вторая активная mutation-job того же site → конфликт
$act1=job(209,7,'analyze_site','7k5278.casino',['purchased_domain'=>'7k5278.casino']);
$act2=job(211,7,'redirect_disable','7k5290.casino',['purchased_domain'=>'7k5290.casino']);
t('§14 concurrencyConflict видит вторую активную', $svc->concurrencyConflict($act1,[$act1,$act2]), 211);
tb('§14 recover confirmed но есть конфликт → blocked', !empty($svc->recover($act1,[$act1,$act2],false)['blocked']));
// терминальная вторая — не конфликт
$term=job(211,7,'done','7k5290.casino'); 
tb('§14 терминальная вторая — не конфликт', $svc->concurrencyConflict($act1,[$act1,$term])===null);


// BLOCKER 5: confirmed #209 recovery делает live read-only inspection + snapshot (create=0)
$svc2=new JobRecoveryService(null);
$svc2->inspectFn=function($job){ return ['ok'=>true,'ftp_writes'=>0,'current_config_domain'=>'https://7k5278.casino','current_sub_id'=>'7k5275','redirect_value'=>0,'redirect_marker_count'=>2,'config_snapshot_sha256'=>str_repeat('a',64)]; };
$rec5=$svc2->recover($j209,[$j209],false);
tb('BLOCKER5 live_inspection присутствует', isset($rec5['live_inspection']) && $rec5['live_inspection']['ok']===true);
t ('BLOCKER5 inspection ftp_writes=0', $rec5['live_inspection']['ftp_writes'], 0);
tb('BLOCKER5 snapshot sha записан', !empty($rec5['live_inspection']['config_snapshot_sha256']));
tb('BLOCKER5 actions включают live_readonly_inspection+config_snapshot', in_array('live_readonly_inspection',$rec5['actions'],true) && in_array('config_snapshot',$rec5['actions'],true));
tb('BLOCKER5 create по-прежнему запрещён', $rec5['create_domain_allowed']===false);
// ambiguous → read-only getInfo резолвер вызывается, create запрещён
$jamb2=job(210,7,'domain_purchasing','',['purchase_confirmation'=>['resolved'=>false]]);
$svc3=new JobRecoveryService(null);
$svc3->ambiguityResolverFn=function($job){ return ['ok'=>true,'getinfo'=>'read_only','domain_in_account'=>false]; };
$ra=$svc3->recover($jamb2,[$jamb2],false);
tb('BLOCKER5 ambiguous read-only getInfo вызван', isset($ra['ambiguity_readonly_getinfo']) && $ra['ambiguity_readonly_getinfo']['ok']===true);
tb('BLOCKER5 ambiguous всё ещё blocked (create=0)', !empty($ra['blocked']) && $ra['create_domain_allowed']===false);


// BLOCKER C 4.3: провал live inspection блокирует APPLY (fail-closed)
$svcF=new JobRecoveryService(null);
$svcF->inspectFn=function($job){ return ['ok'=>false,'error'=>'ftp down','ftp_writes'=>0]; };
$rf=$svcF->recover($j209,[$j209],true);
tb('BLOCKER C4.3 inspection fail → blocked', !empty($rf['blocked']));
t ('BLOCKER C4.3 block_reason=live_inspection_failed', $rf['block_reason'] ?? '', 'live_inspection_failed');
tb('BLOCKER C4.3 applied=false (не тронул БД)', empty($rf['applied']));
// BLOCKER C 4.4: production-default ambiguity резолвер вызывается БЕЗ seam
$jamb3=job(211,7,'domain_purchasing','',['purchase_confirmation'=>['resolved'=>false]]);
$svcW=new JobRecoveryService(null); // seam НЕ задан → должен вызвать production-default
$rw=$svcW->recover($jamb3,[$jamb3],false);
tb('BLOCKER C4.4 ambiguity_readonly_getinfo присутствует без seam (production wiring)', array_key_exists('ambiguity_readonly_getinfo',$rw));
tb('BLOCKER C4.4 ambiguous всё ещё blocked, create=0', !empty($rw['blocked']) && $rw['create_domain_allowed']===false);

echo "\n============================================================\n";
echo "ИТОГО (recovery 209/208): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
