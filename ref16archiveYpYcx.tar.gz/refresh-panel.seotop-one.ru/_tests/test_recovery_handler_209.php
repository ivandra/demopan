<?php
/** ТЗ044 §18 / BLOCKER D — handler-level регресс: реальная recovery #209 (apply) в БД →
 *  джоба доходит до analyze_site и реальный config-planning путь оркестратора строит
 *  корректный план БЕЗ повторной покупки. Требует локальный MariaDB. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (no pdo_mysql)\n"; exit(0); }
$sock=getenv('RP_DB_SOCKET'); $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try {
  if ($sock) { $pdo=new PDO("mysql:unix_socket={$sock};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
  else { $pdo=new PDO('mysql:host=127.0.0.1;port=3306;charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
  $pdo->exec("CREATE DATABASE IF NOT EXISTS rphdl"); $pdo->exec("USE rphdl");
} catch(\Throwable $e){ echo "SKIPPED (DB unavailable)\n"; exit(0); }
$rp=new ReflectionClass('DB'); $p=$rp->getProperty('pdo'); $p->setAccessible(true); $p->setValue(null,$pdo);

$FX=__DIR__.'/fixtures/real';
$realConfig=file_get_contents("$FX/real_209_config.php");
$a209=file_get_contents("$FX/real_209_artifacts.json"); // содержит purchased_domain + mask_options_snapshot

$pdo->exec("DROP TABLE IF EXISTS refresh_jobs");
$pdo->exec("CREATE TABLE refresh_jobs(
  id INT PRIMARY KEY, site_id INT, old_domain VARCHAR(255), new_domain VARCHAR(255) NULL,
  old_sub_id VARCHAR(64) NULL, new_sub_id VARCHAR(64) NULL, mask_settings_json LONGTEXT NULL,
  stage VARCHAR(64), stage_status VARCHAR(32), stage_error TEXT NULL,
  stage_started_at DATETIME NULL, stage_finished_at DATETIME NULL, next_run_at DATETIME NULL,
  artifacts_json LONGTEXT NULL)");
$pdo->exec("DROP TABLE IF EXISTS sites_managed");
$pdo->exec("CREATE TABLE sites_managed(id INT PRIMARY KEY, current_domain VARCHAR(255) NULL, mask_settings_json LONGTEXT NULL, fastpanel_server_id INT NULL)");
$pdo->exec("INSERT INTO sites_managed(id,current_domain) VALUES(7,'7k5278.casino')");
$ins=$pdo->prepare("INSERT INTO refresh_jobs(id,site_id,old_domain,new_domain,old_sub_id,new_sub_id,stage,stage_status,artifacts_json)
  VALUES(209,7,'7k5275.casino','7k5278.casino','7k5275','7k5278','config_replaced','failed',?)");
$ins->execute([$a209]);

// 1) РЕАЛЬНАЯ recovery apply на реальной строке #209
$rec=new JobRecoveryService($pdo);
$rec->inspectFn=function($j){ return ['ok'=>true,'ftp_writes'=>0,'current_config_domain'=>'https://7k5278.casino','current_sub_id'=>'7k5275','redirect_value'=>0,'redirect_marker_count'=>2,'config_snapshot_sha256'=>str_repeat('a',64),'config_snapshot_path'=>'/tmp/snap.php','config_snapshot_written'=>true]; };
$job=$pdo->query("SELECT * FROM refresh_jobs WHERE id=209")->fetch();
$out=$rec->recover($job,[$job],true);
tb('recovery applied', !empty($out['applied']));
t ('recovery create_domain_allowed=false', $out['create_domain_allowed'], false);
$row=$pdo->query("SELECT * FROM refresh_jobs WHERE id=209")->fetch();
t ('после apply stage=analyze_site', $row['stage'], 'analyze_site');
t ('после apply stage_status=pending', $row['stage_status'], 'pending');
tb('stage НЕ вернулся в domain_purchasing (нет повторной покупки)', $row['stage']!=='domain_purchasing');
$art=json_decode($row['artifacts_json'],true);
t ('purchased_domain СОХРАНЁН (не перекупаем)', $art['purchased_domain'] ?? '', '7k5278.casino');
tb('replacement_plan очищен (downstream stale)', !isset($art['replacement_plan']));
tb('config_replaced_stage очищен', !isset($art['config_replaced_stage']));
tb('mask_options_snapshot сохранён (нужен для analyze)', isset($art['mask_options_snapshot']));

// 2) Реальный config-planning путь оркестратора на РЕКАВЕРНУТОЙ джобе (тот же вызов, что в analyze):
//    makeConfigMutationService(MaskSnapshot::forJob)->prepare(...). Fake sync = РЕАЛЬНЫЙ config.
class RSyncH extends SiteConfigSyncService {
  public static $raw; public $uploads=0;
  public function fetchFromVpsReadOnly(int $s): array { $pp=(new SiteConfigParser())->parse(self::$raw); return ['ok'=>true,'raw'=>self::$raw,'path'=>'config.php','sha256'=>hash('sha256',self::$raw),'parsed'=>$pp,'kind'=>'flat']; }
  public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; return ['ok'=>true]; }
  public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { return ['ok'=>true]; }
}
RSyncH::$raw=$realConfig;
class FakePurchaseH { public $createCalls=0; public function tryPurchase($job,$log){ $this->createCalls++; return ['ok'=>false,'reason'=>'should_not_be_called']; } }

class TestOrch extends RefreshOrchestrator {
  public $fakePurchase;
  protected function makeConfigSync(): SiteConfigSyncService { return new RSyncH(); }
  protected function makePurchaseService() { return $this->fakePurchase; }
  // тот же вызов, что делает runAnalyzeStage для config.php-планирования:
  public function exposedConfigPlan(array $job, $log): array {
    $mask = MaskSnapshot::forJob((int)$job['id'], $log);
    return $this->makeConfigMutationService($mask)->prepare(
      (int)$job['site_id'], (int)$job['id'], (string)$job['old_domain'], (string)$job['new_domain']);
  }
}
$log=new JobEventLogger(209);
$orch=new TestOrch(); $orch->fakePurchase=new FakePurchaseH();
$recovered=$pdo->query("SELECT * FROM refresh_jobs WHERE id=209")->fetch();
$plan=$orch->exposedConfigPlan($recovered,$log);
tb('post-recovery config prepare ok (нет prepared_target_invalid)', !empty($plan['ok']));
$cm=$plan['plan']['config_mutation'] ?? ($plan['plan'] ?? []);
$tgt=file_exists(Paths::storage($plan['plan']['target_storage_path']??'')) ? file_get_contents(Paths::storage($plan['plan']['target_storage_path'])) : '';
tb('target config: domain=7k5278', $tgt!=='' && strpos($tgt,'https://7k5278.casino')!==false && strpos($tgt,'7k5274')===false);
tb('target config: sub_id 7k5275→7k5278 во всех 3 полях', substr_count($tgt,'sub_id=7k5278')===3 && strpos($tgt,'7k5275')===false);
t ('config prepare FTP uploads = 0 (write=0 до записи)', $orch->fakePurchase->createCalls, 0);
tb('purchase service НЕ вызывался (createCalls=0)', $orch->fakePurchase->createCalls===0);
if(!empty($plan['plan']['target_storage_path'])) @unlink(Paths::storage($plan['plan']['target_storage_path']));

echo "\n============================================================\n";
echo "ИТОГО (recovery handler 209): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
