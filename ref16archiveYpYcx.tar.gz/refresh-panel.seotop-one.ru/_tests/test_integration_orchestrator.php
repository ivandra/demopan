<?php
/**
 * ИНТЕГРАЦИЯ оркестратора на НОВОЙ модели (реальные стадии runAnalyzeStage/
 * runReplaceStage через seam-зависимости; production-код, не копия).
 * analyze → prepare (config_mutation в плане, config.php вне replacements);
 * config_replaced → applyPrepared (SHA guard, один upload, байтовый read-back,
 * persistVerified). Поведенческие AC01/AC03/AC04/AC05/AC07.
 *
 *   RP_DB_SOCKET=/tmp/mysqlrun/my.sock RP_DB_NAME=rp30 RP_DB_USER=root \
 *     php _tests/test_integration_orchestrator.php
 */
$ROOT = dirname(__DIR__);
if (!extension_loaded('pdo_mysql')) { echo "SKIPPED (no pdo_mysql)\n"; exit(0); }
require_once $ROOT.'/bin/_bootstrap.php';

$sock=getenv('RP_DB_SOCKET'); $name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
if(!$sock){ echo "SKIPPED (no RP_DB_SOCKET)\n"; exit(0); }
$dsn="mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4";
try { $pdo=new PDO($dsn,$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable)\n"; exit(0); }
$pdo->exec("SET time_zone='+00:00'");
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);

class NullLog extends JobEventLogger {
    public function __construct() {}
    public function info(string $s,string $m,array $p=[]):void{} public function warn(string $s,string $m,array $p=[]):void{}
    public function ok(string $s,string $m,array $p=[]):void{} public function error(string $s,string $m,array $p=[]):void{}
    public function done(string $o,string $n):void{}
}
class FakeSync extends SiteConfigSyncService {
    public $raw=''; public $failFetch=false; public $corruptOnUpload=null; public $persistOk=true;
    public $uploads=0; public $persists=0; private $parser;
    public function __construct(){ $this->parser=new SiteConfigParser(); }
    public function fetchFromVpsReadOnly(int $s): array {
        if($this->failFetch) return ['ok'=>false,'error'=>'FTP read failed'];
        if(stripos($this->raw,'<?php')===false) return ['ok'=>false,'error'=>'empty or not PHP'];
        try{$p=$this->parser->parse($this->raw);}catch(\Throwable $e){return ['ok'=>false,'error'=>'parser exception'];}
        return ['ok'=>true,'raw'=>$this->raw,'path'=>'config.php','sha256'=>hash('sha256',$this->raw),'parsed'=>$p,'kind'=>'flat'];
    }
    public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; $this->raw=$this->corruptOnUpload??$c; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array {
        $this->persists++;
        if(!$this->persistOk) return ['ok'=>false,'reason'=>'snapshot_persist_failed'];
        DB::pdo()->prepare("UPDATE sites_managed SET config_parsed_json=?, current_domain=?, config_last_synced_at=NOW() WHERE id=?")
            ->execute([json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$nd,$s]);
        return ['ok'=>true];
    }
}
class FakeApplier extends ReplacementApplier {
    public $calls=0; public $sawConfig=false;
    public function __construct(){}
    public function applyPlan(int $s,int $j,array $plan,JobEventLogger $log):array {
        $this->calls++;
        foreach(($plan['replacements']??[]) as $r) if(basename((string)($r['file']??''))==='config.php') $this->sawConfig=true;
        return ['ok'=>true,'files_changed'=>0,'replacements_applied'=>count($plan['replacements']??[]),'errors'=>[]];
    }
}
class FakeScanner extends SiteFileScanner { public $ret; public function __construct(){} public function scanSite(int $s,int $j,$log):array{return $this->ret;} }
class TestOrchestrator extends RefreshOrchestrator {
    public $fakeSync; public $fakeApplier; public $fakeScanner;
    protected function makeConfigSync(): SiteConfigSyncService { return $this->fakeSync; }
    protected function makeApplier(): ReplacementApplier { return $this->fakeApplier; }
    protected function makeScanner(): SiteFileScanner { return $this->fakeScanner; }
    public function callAnalyze(array $job): void { $m=new ReflectionMethod(RefreshOrchestrator::class,'runAnalyzeStage'); $m->setAccessible(true); $m->invoke($this,$job,new NullLog()); }
    public function callReplace(array $job): void { $m=new ReflectionMethod(RefreshOrchestrator::class,'runReplaceStage'); $m->setAccessible(true); $m->invoke($this,$job,new NullLog()); }
}

$SITE=900011; $JOB=900011;
function reset_rows(PDO $p,int $s,int $j){ $p->prepare("DELETE FROM refresh_jobs WHERE id=?")->execute([$j]); $p->prepare("DELETE FROM sites_managed WHERE id=?")->execute([$s]); }
function seed_site(PDO $p,int $id,string $d){ $p->prepare("INSERT INTO sites_managed (id,current_domain,status) VALUES (?,?, 'imported')")->execute([$id,$d]); }
function seed_job(PDO $p,int $id,int $s,string $od,string $nd,string $stage,array $art){ $p->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,old_sub_id,new_sub_id,stage,stage_status,artifacts_json) VALUES (?,?,?,?,?,?,?, 'running', ?)")->execute([$id,$s,$od,$nd,'','',$stage,json_encode($art,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]); }
function job_row(PDO $p,int $id){ $s=$p->prepare("SELECT * FROM refresh_jobs WHERE id=?"); $s->execute([$id]); return $s->fetch()?:[]; }
function jstatus(PDO $p,int $id){ $s=$p->prepare("SELECT stage_status FROM refresh_jobs WHERE id=?"); $s->execute([$id]); return (string)$s->fetchColumn(); }
function cur_domain(PDO $p,int $id){ $s=$p->prepare("SELECT current_domain FROM sites_managed WHERE id=?"); $s->execute([$id]); return (string)$s->fetchColumn(); }
function plan_of(PDO $p,int $id){ $a=json_decode((string)job_row($p,$id)['artifacts_json'],true)?:[]; return $a['replacement_plan']??[]; }
$MASK=['mask_options_snapshot'=>['strategy'=>'number','step'=>1,'pad_zeros'=>true,'no_digit_start'=>2,'letter_alphabet'=>'abcdefghijklmnopqrstuvwxyz','letter_wrap'=>true,'sync_with_domain'=>true,'prefix_enabled'=>false,'prefix'=>'']];
$PASS=0;$FAIL=0;
function eq($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function ok($n,$c){eq($n,(bool)$c,true);}
function make_scan_dir(string $src){ $d=sys_get_temp_dir().'/scan_'.getmypid().'_'.mt_rand(); @mkdir($d,0777,true); file_put_contents($d.'/config.php',$src);
    return ['ok'=>true,'scan_dir'=>$d,'site_root'=>'/','base_path'=>'/','site_id'=>0,'files'=>['config.php'=>['size'=>strlen($src),'kind'=>'php','local_path'=>$d.'/config.php']]]; }

$PINCO="<?php\n\$redirect_url=\"https://p.com/a?sub_id=pinco4002\";\n\$internal_reg_url=\"https://p.com/b?sub_id=pinco4002\";\n";

function A(PDO $pdo,int $SITE,int $JOB,array $MASK,string $raw,string $od='pinco4002.casino',string $nd='pinco4003.casino'){
    reset_rows($pdo,$SITE,$JOB); seed_site($pdo,$SITE,$od); seed_job($pdo,$JOB,$SITE,$od,$nd,'analyze_site',$MASK);
    $o=new TestOrchestrator(); $o->fakeSync=new FakeSync(); $o->fakeSync->raw=$raw;
    $o->fakeApplier=new FakeApplier(); $o->fakeScanner=new FakeScanner(); $o->fakeScanner->ret=make_scan_dir($raw);
    $o->callAnalyze(job_row($pdo,$JOB)); return $o;
}

echo "=== ANALYZE → prepare (config_mutation в плане; config.php вне replacements) ===\n";
A($pdo,$SITE,$JOB,$MASK,$PINCO);
$plan=plan_of($pdo,$JOB); $cm=$plan['config_mutation']??null;
ok('A1 config_mutation присутствует', is_array($cm));
ok('A1 source_sha256 64hex', (bool)preg_match('~^[0-9a-f]{64}$~',(string)($cm['source_sha256']??'')));
ok('A1 target_sha256 64hex', (bool)preg_match('~^[0-9a-f]{64}$~',(string)($cm['target_sha256']??'')));
eq('A1 old_sub_id=pinco4002', (string)($cm['old_sub_id']??''), 'pinco4002');
eq('A1 new_sub_id=pinco4003', (string)($cm['new_sub_id']??''), 'pinco4003');
ok('A1 target_storage_path без /home', strpos((string)($cm['target_storage_path']??'/home'),'/home')===false);
$hasCfg=false; foreach(($plan['replacements']??[]) as $r) if(basename((string)($r['file']??''))==='config.php') $hasCfg=true;
eq('A1 config.php ИСКЛЮЧЁН из replacements (AC01)', $hasCfg, false);
eq('A1 стадия не awaiting', jstatus($pdo,$JOB)!=='awaiting_user', true);

// unsafe стопы
A($pdo,$SITE,$JOB,$MASK,"<?php\n\$base_new_url=\"https://p.com/a?sub_id=syka4\";\n\$internal_reg_url=\"https://p.com/b?sub_id=syka9\";\n");
eq('A2 CONFLICT → awaiting', jstatus($pdo,$JOB), 'awaiting_user');
A($pdo,$SITE,$JOB,$MASK,"<?php\n\$tracking=\"https://p.com/a?sub_id=unk1\";\n");
eq('A3 UNKNOWN → awaiting', jstatus($pdo,$JOB), 'awaiting_user');
A($pdo,$SITE,$JOB,$MASK,"<?php\n\$redirect_url=\"https://p.com/a?sub_id=pinco4002\";\n\$redirect_url=\"https://p.com/a?sub_id=pinco4002\";\n");
eq('A4 DUPLICATE (даже одинаковое) → awaiting', jstatus($pdo,$JOB), 'awaiting_user');
A($pdo,$SITE,$JOB,$MASK,"<?php \$x = = = ;;;");
eq('A5 PARSE → awaiting', jstatus($pdo,$JOB), 'awaiting_user');
A($pdo,$SITE,$JOB,$MASK,"<?php\n\$redirect_url='https://p.com/a?sub_id=' . \$sid;\n");
eq('A6 DYNAMIC → awaiting', jstatus($pdo,$JOB), 'awaiting_user');
// read-fail
reset_rows($pdo,$SITE,$JOB); seed_site($pdo,$SITE,'pinco4002.casino'); seed_job($pdo,$JOB,$SITE,'pinco4002.casino','pinco4003.casino','analyze_site',$MASK);
$o=new TestOrchestrator(); $o->fakeSync=new FakeSync(); $o->fakeSync->failFetch=true; $o->fakeApplier=new FakeApplier(); $o->fakeScanner=new FakeScanner(); $o->fakeScanner->ret=make_scan_dir($PINCO);
$o->callAnalyze(job_row($pdo,$JOB));
eq('A7 READ-FAIL → awaiting', jstatus($pdo,$JOB), 'awaiting_user');

echo "\n=== REPLACE → applyPrepared (SHA guard, один upload, байтовый read-back, persist) ===\n";
$o=A($pdo,$SITE,$JOB,$MASK,$PINCO);
$o->callReplace(job_row($pdo,$JOB));
eq('R-OK stage ok', jstatus($pdo,$JOB), 'ok');
eq('R-OK current_domain=pinco4003.casino (persistVerified)', cur_domain($pdo,$SITE), 'pinco4003.casino');
eq('R-OK ровно один upload config.php (AC04)', $o->fakeSync->uploads, 1);
ok('R-OK persist после verify (AC07)', $o->fakeSync->persists>=1);
ok('R-OK в config новый sub_id, старого нет', strpos($o->fakeSync->raw,'pinco4003')!==false && strpos($o->fakeSync->raw,'pinco4002')===false);
eq('R-OK applier НЕ видел config.php (AC01)', $o->fakeApplier->sawConfig, false);

// TOCTOU
$o=A($pdo,$SITE,$JOB,$MASK,$PINCO);
$o->fakeSync->raw="<?php\n\$redirect_url=\"https://p.com/a?sub_id=pinco4002\";\n\$internal_reg_url=\"https://p.com/b?sub_id=pinco4002\";\n// подмена\n";
$o->callReplace(job_row($pdo,$JOB));
eq('R-TOCTOU awaiting (config_changed_after_analyze)', jstatus($pdo,$JOB), 'awaiting_user');
eq('R-TOCTOU write=0 (AC03)', $o->fakeSync->uploads, 0);
eq('R-TOCTOU current_domain не изменён', cur_domain($pdo,$SITE), 'pinco4002.casino');

// READ-BACK mismatch (байты != target)
$o=A($pdo,$SITE,$JOB,$MASK,$PINCO);
$o->fakeSync->corruptOnUpload="<?php\n\$redirect_url=\"https://p.com/a?sub_id=pinco4002\";\n\$internal_reg_url=\"https://p.com/b?sub_id=pinco4003\";\n";
$o->callReplace(job_row($pdo,$JOB));
eq('R-READBACK awaiting (AC05)', jstatus($pdo,$JOB), 'awaiting_user');
eq('R-READBACK persist НЕ вызван', $o->fakeSync->persists, 0);
eq('R-READBACK current_domain не изменён', cur_domain($pdo,$SITE), 'pinco4002.casino');

// PERSIST fail
$o=A($pdo,$SITE,$JOB,$MASK,$PINCO); $o->fakeSync->persistOk=false;
$o->callReplace(job_row($pdo,$JOB));
eq('R-PERSIST snapshot_persist_failed → awaiting', jstatus($pdo,$JOB), 'awaiting_user');

reset_rows($pdo,$SITE,$JOB);
echo "\n============================================================\n";
echo "ИТОГО (orchestrator integration): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
