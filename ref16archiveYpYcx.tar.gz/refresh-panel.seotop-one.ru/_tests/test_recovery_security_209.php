<?php
/** ТЗ044 Revision 3 — безопасность/атомарность recovery:
 *  REC-SEC-01 CSRF, REC-LIVE-01/02/03 fail-closed inspection, REC-NC-01 getInfo контракт,
 *  REC-STATE-01 eligibility, REC-LOCK-01 per-job lock + CAS (DB). */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

// ---- REC-SEC-01: CSRF обязателен ----
require_once __DIR__.'/../app/Core/Controller.php';
$_POST=[]; unset($_POST['csrf_token']);
$ctrl=new class extends Controller {}; // базовое ядро csrfValid
tb('REC-SEC-01 csrfValid()=false без токена', $ctrl->csrfValid()===false);
$src=file_get_contents(__DIR__.'/../app/Controllers/RefreshJobController.php');
$rec=substr($src, strpos($src,'function recoverJob'), 400);
tb('REC-SEC-01 recoverJob вызывает requireCsrf() до мутации', strpos($rec,'requireCsrf()')!==false);

// ---- REC-LIVE-01/02/03: fail-closed inspection ----
$base=['config_read_ok'=>true,'config_snapshot_written'=>true,'redirect_read_ok'=>true,'alias_present'=>true,'cert_present'=>true];
tb('REC-LIVE-00 все prerequisites → ok', JobRecoveryService::evaluateInspection($base)['ok']===true);
$s1=$base; $s1['config_snapshot_written']=false;
$r1=JobRecoveryService::evaluateInspection($s1);
tb('REC-LIVE-01 snapshot_written=false → blocked', $r1['ok']===false && in_array('snapshot_not_written',$r1['blocking_reasons'],true));
$s2=$base; $s2['alias_present']=null;
$r2=JobRecoveryService::evaluateInspection($s2);
tb('REC-LIVE-02 alias null → blocked', $r2['ok']===false && in_array('alias_absent_or_unknown',$r2['blocking_reasons'],true));
$s2b=$base; $s2b['alias_present']=false;
tb('REC-LIVE-02b alias false → blocked', JobRecoveryService::evaluateInspection($s2b)['ok']===false);
$s3=$base; $s3['cert_present']=false;
$r3=JobRecoveryService::evaluateInspection($s3);
tb('REC-LIVE-03 cert false → blocked', $r3['ok']===false && in_array('cert_absent_or_unknown',$r3['blocking_reasons'],true));

// ---- REC-NC-01: реальный nested DomainGetInfoResult → domain_in_account=true ----
$nested=['DomainGetInfoResult'=>['@DomainName'=>'7k5278.casino','@Status'=>'Ok']];
t('REC-NC-01 nested getInfo → domain_in_account=true', JobRecoveryService::classifyAmbiguityInfo('7k5278.casino',$nested)['domain_in_account'], true);
t('REC-NC-01b empty getInfo → domain_in_account=false', JobRecoveryService::classifyAmbiguityInfo('7k5278.casino',[])['domain_in_account'], false);
t('REC-NC-01c чужой домен → domain_in_account=false', JobRecoveryService::classifyAmbiguityInfo('7k5278.casino',['DomainGetInfoResult'=>['@DomainName'=>'other.casino','@Status'=>'Ok']])['domain_in_account'], false);

// ---- DB-backed: REC-STATE-01 + REC-LOCK-01 (CAS) ----
if(!extension_loaded('pdo_mysql')){ echo "  [skip] DB-тесты (no pdo_mysql)\n"; }
else {
  $sock=getenv('RP_DB_SOCKET'); $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
  $pdo=null;
  try {
    if ($sock) { $pdo=new PDO("mysql:unix_socket={$sock};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
    else { $pdo=new PDO('mysql:host=127.0.0.1;port=3306;charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
    $pdo->exec("CREATE DATABASE IF NOT EXISTS rpsec"); $pdo->exec("USE rpsec");
  } catch(\Throwable $e){ echo "  [skip] DB unavailable\n"; $pdo=null; }
  if ($pdo) {
    $rp=new ReflectionClass('DB'); $p=$rp->getProperty('pdo'); $p->setAccessible(true); $p->setValue(null,$pdo);
    $a209=file_get_contents(__DIR__.'/fixtures/real/real_209_artifacts.json');
    $mk=function($stage,$status) use($pdo,$a209){
      $pdo->exec("DROP TABLE IF EXISTS refresh_jobs");
      $pdo->exec("CREATE TABLE refresh_jobs(id INT PRIMARY KEY,site_id INT,old_domain VARCHAR(255),new_domain VARCHAR(255) NULL,stage VARCHAR(64),stage_status VARCHAR(32),stage_error TEXT NULL,next_run_at DATETIME NULL,artifacts_json LONGTEXT NULL)");
      $st=$pdo->prepare("INSERT INTO refresh_jobs(id,site_id,old_domain,new_domain,stage,stage_status,artifacts_json) VALUES(209,7,'7k5275.casino','7k5278.casino',?,?,?)");
      $st->execute([$stage,$status,$a209]);
      return $pdo->query("SELECT * FROM refresh_jobs WHERE id=209")->fetch();
    };
    $svc=new JobRecoveryService($pdo);
    $svc->inspectFn=function($j){ return ['ok'=>true,'ftp_writes'=>0]; }; // inspection ok, чтобы дойти до apply

    // REC-STATE-01: running job → apply denied, БД не изменена
    $job=$mk('config_replaced','running');
    $r=$svc->recover($job,[$job],true);
    t('REC-STATE-01 running → blocked not_eligible_status', $r['block_reason'] ?? '', 'not_eligible_status');
    t('REC-STATE-01 БД не изменена (stage/status)', $pdo->query("SELECT CONCAT(stage,'/',stage_status) FROM refresh_jobs WHERE id=209")->fetchColumn(), 'config_replaced/running');

    // REC-STATE pending → denied
    $job=$mk('config_replaced','pending');
    t('REC-STATE-01b pending → blocked', $svc->recover($job,[$job],true)['block_reason'] ?? '', 'not_eligible_status');

    // REC-LOCK-01/CAS: состояние изменилось между чтением и apply → CAS отклоняет, БД не тронута
    $job=$mk('config_replaced','failed');           // читаем как failed
    $pdo->exec("UPDATE refresh_jobs SET stage_status='running' WHERE id=209"); // кто-то перевёл в running
    $rc=$svc->recover($job,[$job],true);
    tb('REC-LOCK-01 CAS: конкурентное изменение → blocked', !empty($rc['blocked']) && in_array($rc['block_reason'],['state_changed_concurrently','not_eligible_status','cas_update_failed'],true));
    t('REC-LOCK-01 apply НЕ произошёл (stage не analyze_site)', $pdo->query("SELECT stage FROM refresh_jobs WHERE id=209")->fetchColumn(), 'config_replaced');

    // happy path под eligibility: failed → apply успешен, CAS rowCount==1
    $job=$mk('config_replaced','failed');
    $ok=$svc->recover($job,[$job],true);
    tb('REC-APPLY-OK failed → applied', !empty($ok['applied']));
    t('REC-APPLY-OK stage=analyze_site', $pdo->query("SELECT stage FROM refresh_jobs WHERE id=209")->fetchColumn(), 'analyze_site');
    t('REC-APPLY-OK purchased_domain сохранён', json_decode($pdo->query("SELECT artifacts_json FROM refresh_jobs WHERE id=209")->fetchColumn(),true)['purchased_domain'] ?? '', '7k5278.casino');

    // REC-LOCK per-job GET_LOCK занят другим соединением → acquireJobLock=false
    try {
      $pdo2=$sock ? new PDO("mysql:unix_socket={$sock};charset=utf8mb4",$user,$pass) : new PDO('mysql:host=127.0.0.1;port=3306;charset=utf8mb4',$user,$pass);
      $pdo2->query("SELECT GET_LOCK('rfp_job_209',0)")->fetchColumn();
      $g=CronGuard::forJob(209);
      tb('REC-LOCK-01b занятый per-job lock → acquireJobLock=false', $g->acquireJobLock()===false);
      $pdo2->query("SELECT RELEASE_LOCK('rfp_job_209')")->fetchColumn();
    } catch(\Throwable $e){ echo "  [skip] GET_LOCK sub-test: ".$e->getMessage()."\n"; }
  }
}

echo "\n============================================================\n";
echo "ИТОГО (recovery security 209): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
