<?php
/**
 * Regression corpus: боевые snapshot'ы config.php. Независимый детектор находит
 * активный sub_id; если scanner при этом классифицирует NO_SUB_ID (false-safe) → FAIL.
 * Источник: storage/configs_snapshots/*.php.txt (+ _tests/fixtures/configs/*.php).
 * Ожидаемо: false-safe NO_SUB_ID = 0.
 *   Запуск: php _tests/test_snapshot_corpus.php
 */
$ROOT=dirname(__DIR__);
require_once $ROOT.'/app/Services/ConfigScanResult.php';
require_once $ROOT.'/app/Services/StaticSiteConfigScanner.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

/** Независимый (не через scanner) детектор активного sub_id: убрать комментарии,
 *  искать sub_id=/subid= в URL-строке ИЛИ $sub_id/$subid-присваивание. */
function hasActiveSubId(string $raw): bool {
    try { $toks=token_get_all($raw, TOKEN_PARSE); } catch (\Throwable $e) { return false; }
    $active='';
    foreach($toks as $tk){
        if(is_array($tk)){ if(in_array($tk[0],[T_COMMENT,T_DOC_COMMENT],true)) continue; $active.=$tk[1]; }
        else $active.=$tk;
    }
    if(preg_match('~[?&](?:sub_id|subid)=[^\s&#"\'\\\\]+~i',$active)) return true;      // URL-параметр
    if(preg_match('~\$sub_?id\s*=\s*[\'"][^\'"]+[\'"]~i',$active)) return true;         // голая переменная
    return false;
}

$files=[];
foreach([$ROOT.'/storage/configs_snapshots', $ROOT.'/_tests/fixtures/configs'] as $dir){
    if(is_dir($dir)) foreach(glob($dir.'/*.php*') as $f) $files[]=$f;
}
if(!$files){ echo "SKIPPED (нет snapshot-корпуса)\n"; exit(0); }

$scanner=new StaticSiteConfigScanner();
$total=0;$withSub=0;$recognized=0;$blocked=0;$noSub=0;$falseSafe=0;$falseList=[];
foreach($files as $f){
    $raw=file_get_contents($f); if($raw===false||trim($raw)==='') continue;
    $total++;
    $active=hasActiveSubId($raw);
    if($active) $withSub++;
    $scan=$scanner->scan($raw);
    if(!$scan->isSafe()){ $blocked++; continue; }        // корректно помечен (conflict/unknown/parse) — не false-safe
    $sub=$scan->uniqueSubIdOrNull();
    if($sub!==null){ $recognized++; continue; }
    $noSub++;
    if($active){ $falseSafe++; $falseList[]=basename($f); }  // raw имеет sub_id, а scanner NO_SUB_ID → FALSE-SAFE
}
echo "  корпус: {$total} файлов; c активным sub_id: {$withSub}; распознано SAFE+sub_id: {$recognized}; blocked: {$blocked}; NO_SUB_ID: {$noSub}\n";
if($falseSafe>0){ echo "  false-safe файлы: ".implode(', ',array_slice($falseList,0,20))."\n"; }
t('false-safe NO_SUB_ID = 0', $falseSafe, 0);
t('распознано минимум 1 Enomo array (sub_id найден)', $recognized>=1, true);

echo "\n============================================================\n";
echo "ИТОГО (snapshot corpus): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
