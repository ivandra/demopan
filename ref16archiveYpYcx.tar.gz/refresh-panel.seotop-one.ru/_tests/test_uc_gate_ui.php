<?php
/**
 * UI/state gate рандомизации (update_classes). Проверяет предикаты, управляющие
 * показом recovery-блока и кнопок Verify/Skip:
 *   execution_state=NULL (нейтральное ожидание) → recovery-кнопок нет;
 *   ambiguous → есть Verify и Skip;
 *   verified   → блока нет (gate satisfied);
 *   operator_skipped → gate проходит;
 *   generic stage_status=ok → НЕ считается пропуском.
 * Запуск: php _tests/test_uc_gate_ui.php
 */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

function mkJob(array $o): array {
    $uc = [];
    if (array_key_exists('outcome',$o) && $o['outcome']!==null) $uc['outcome']=$o['outcome'];
    if (!empty($o['skipped_by_operator'])) $uc['skipped_by_operator']=true;
    return [
        'stage'=>$o['stage']??'update_classes_call',
        'stage_status'=>$o['status']??'waiting',
        'uc_execution_state'=>$o['exec']??null,
        'php_uniquification_verified_at'=>$o['verified_at']??null,
        'artifacts_json'=>json_encode(['update_classes_stage'=>$uc]),
    ];
}
function ui(array $job): array {
    return [
        'verify'=>RefreshOrchestrator::manualVerificationPolicy($job)['allowed'],
        'skip'  =>RefreshOrchestrator::manualSkipPolicy($job)['allowed'],
        'intervention'=>RefreshOrchestrator::updateClassesInterventionActive($job),
        'gate'  =>RefreshOrchestrator::updateClassesGateSatisfied($job),
        'attempted'=>RefreshOrchestrator::updateClassesExecutionAttempted($job),
    ];
}

echo "=== execution_state=NULL, outcome=NULL, ожидание доступности → recovery-кнопок нет ===\n";
$u = ui(mkJob(['exec'=>null,'outcome'=>null,'status'=>'waiting']));
t('attempted=false', $u['attempted'], false);
t('intervention=false (нейтральное состояние)', $u['intervention'], false);
t('verify НЕ показан', $u['verify'], false);
t('skip НЕ показан', $u['skip'], false);
t('gate НЕ пройден (ждёт, но не skip)', $u['gate'], false);

echo "\n=== ambiguous (execution_state) → есть Verify и Skip ===\n";
$u = ui(mkJob(['exec'=>'ambiguous']));
t('intervention=true', $u['intervention'], true);
t('verify показан', $u['verify'], true);
t('skip показан', $u['skip'], true);

echo "\n=== ambiguous (outcome) → есть Verify и Skip ===\n";
$u = ui(mkJob(['outcome'=>'ambiguous']));
t('verify показан', $u['verify'], true);
t('skip показан', $u['skip'], true);

echo "\n=== verification_pending → есть Verify и Skip ===\n";
$u = ui(mkJob(['exec'=>'verification_pending']));
t('intervention=true', $u['intervention'], true);
t('verify показан', $u['verify'], true);
t('skip показан', $u['skip'], true);

echo "\n=== verified (php_uniquification_verified_at) → блока нет ===\n";
$u = ui(mkJob(['verified_at'=>'2026-07-30 10:00:00','status'=>'ok']));
t('gate пройден', $u['gate'], true);
t('intervention=false (блок скрыт)', $u['intervention'], false);
t('verify НЕ показан', $u['verify'], false);
t('skip НЕ показан', $u['skip'], false);

echo "\n=== operator_skipped → gate проходит, блока нет ===\n";
$u = ui(mkJob(['stage'=>'wm_added','status'=>'ok','exec'=>'operator_skipped','outcome'=>'operator_skipped','skipped_by_operator'=>true]));
t('gate пройден', $u['gate'], true);
t('intervention=false', $u['intervention'], false);
t('skip НЕ показан (уже пропущено)', $u['skip'], false);

echo "\n=== generic stage_status=ok (без verify/skip) → НЕ считается пропуском ===\n";
$u = ui(mkJob(['status'=>'ok','exec'=>null,'outcome'=>null]));
t('gate НЕ пройден (ok != skip)', $u['gate'], false);
t('нейтральное: intervention=false', $u['intervention'], false);
t('verify НЕ показан', $u['verify'], false);
t('skip НЕ показан', $u['skip'], false);

echo "\n=== awaiting_user на update_classes_call → intervention + Skip ===\n";
$u = ui(mkJob(['status'=>'awaiting_user','outcome'=>'ambiguous']));
t('intervention=true', $u['intervention'], true);
t('skip показан', $u['skip'], true);

echo "\n============================================================\n";
echo "ИТОГО (uc gate UI): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
