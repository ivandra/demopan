<?php
/** ТЗ044 §18 — offline integration: реальные компоненты на сценарии #209, сквозные инварианты. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

class ISync extends SiteConfigSyncService {
    public $raw; private $parser; public $uploads=0;
    public function __construct($raw){ $this->parser=new SiteConfigParser(); $this->raw=$raw; }
    public function fetchFromVpsReadOnly(int $s): array {
        try{$p=$this->parser->parse($this->raw);}catch(\Throwable $e){return ['ok'=>false,'error'=>'parser exception'];}
        return ['ok'=>true,'raw'=>$this->raw,'path'=>'config.php','sha256'=>hash('sha256',$this->raw),'parsed'=>$p,'kind'=>'flat'];
    }
    public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; $this->raw=$c; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { return ['ok'=>true]; }
}
$mask=new DomainMaskService([],true);
$P='partners7k-promo.com';
$RAW="<?php\n\$domain = 'https://7k5274.casino';\n\$base_new_url = \"https://$P/l?sub_id=7k5275\";\n\$redirect_enabled = 0; // REFRESH-DISABLED // REFRESH-DISABLED\n";

// ── queued → domain_purchasing + PREBUY (read-only, ftp=0, safe drift → покупка разрешена)
$sync=new ISync($RAW); $svc=new SiteConfigMutationService($sync, new StaticSiteConfigScanner(), $mask);
$pf=$svc->preflight(7,'7k5278.casino','7k5275.casino');
tb('§18 PREBUY ok (safe drift) → покупка разрешена', $pf['ok']===true);
t ('§18 PREBUY ftp write=0', $sync->uploads, 0);

// ── analyze_site: prepare строит replacement_plan.config_mutation ДО config_replaced
$prep=$svc->prepare(7,209,'7k5275.casino','7k5278.casino');
tb('§18 analyze: prepare ok', $prep['ok']);
$plan=$prep['plan'];
$artifacts=['replacement_plan'=>['config_mutation'=>$plan]]; // как кладёт оркестратор
$inv=StageInvariantGuard::checkAdvance('analyze_site',[],$artifacts);
tb('§18 replacement_plan существует ДО config_replaced (invariant ok)', $inv['ok']===true);
t ('§18 analyze ftp write=0 (target в storage, не FTP)', $sync->uploads, 0);
@unlink(Paths::storage($plan['target_storage_path']));

// ── config_replaced read-back: домен/sub корректны → переход на verify разрешён
$__sha=str_repeat('e',64);
$rbArtifacts=['replacement_plan'=>['config_mutation'=>['target_sha256'=>$__sha,'expected'=>['domain_required'=>true,'sub_id'=>'7k5278']]],
              'config_replaced_stage'=>['read_back'=>['ok'=>true,'target_sha256'=>$__sha,'domain'=>'7k5278.casino','sub_id'=>'7k5278']]];
tb('§18 config read-back ok (+plan/SHA/domain) → advance verify', StageInvariantGuard::checkAdvance('config_replaced',['new_domain'=>'7k5278.casino'],$rbArtifacts)['ok']===true);
tb('§18 config read-back БЕЗ plan → BLOCK (fail-closed)', StageInvariantGuard::checkAdvance('config_replaced',['new_domain'=>'7k5278.casino'],['config_replaced_stage'=>['read_back'=>['ok'=>true,'domain'=>'7k5278.casino']]])['ok']===false);
// целевой raw действительно содержит новый домен/sub и НЕ содержит дубля маркера redirect
$target=$svc->mutateDomain($RAW,(new StaticSiteConfigScanner())->scan($RAW),'7k5278.casino','7k5275.casino')['raw'];
tb('§18 target: домен 7k5278', strpos($target,'https://7k5278.casino')!==false && strpos($target,'7k5274')===false);

// ── no duplicate redirect marker (disable идемпотентно из дублированного состояния)
$rt=new RedirectToggler();
$dis=$rt->canonicalizeRedirectVar($RAW,0);
t ('§18 no duplicate redirect marker', (int)preg_match_all('~REFRESH-DISABLED~',$dis['content']), 1);
$en=$rt->canonicalizeRedirectVar($dis['content'],1);
[$val,$mk]=$rt->redirectVarState($en['content']);
tb('§18 redirect enable read-back: enabled==1 & markers==0', $val===1 && $mk===0);

// ── no invariant breach + no repeat purchase (recovery #209 confirmed → create=0)
$rec=new JobRecoveryService(null);
$j209=['id'=>209,'site_id'=>7,'stage'=>'config_replaced','stage_status'=>'failed','new_domain'=>'7k5278.casino','artifacts_json'=>json_encode(['purchased_domain'=>'7k5278.casino'])];
tb('§18 recovery #209 не покупает домен', $rec->recover($j209,[$j209],false)['create_domain_allowed']===false);

// ── operator retry: analyze упал безопасно (dynamic) → policy RETRY_SAME_STAGE, illegal advance невозможен
$sync2=new ISync("<?php\n\$domain = buildDomain();\n"); $svc2=new SiteConfigMutationService($sync2, new StaticSiteConfigScanner(), $mask);
$fail=$svc2->prepare(7,209,'7k5275.casino','7k5278.casino');
tb('§18 analyze fails safely (dynamic domain, ftp=0)', $fail['ok']===false && $sync2->uploads===0);
t ('§18 operator action = RETRY_SAME_STAGE (не advance)', OperatorContinuationPolicy::actionFor('analyze_site',[],[]), OperatorContinuationPolicy::RETRY_SAME_STAGE);
tb('§18 illegal advance невозможен (guard блокирует analyze без plan)', StageInvariantGuard::checkAdvance('analyze_site',[],[])['ok']===false);

echo "\n============================================================\n";
echo "ИТОГО (integration 209): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
