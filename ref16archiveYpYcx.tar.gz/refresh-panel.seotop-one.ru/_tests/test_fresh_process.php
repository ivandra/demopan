<?php
/** P08/AC08: config_replaced в НОВОМ php-процессе — все классы autoload.
 *  Запуск: php _tests/test_fresh_process.php */
$ROOT=dirname(__DIR__);
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
$worker=$ROOT.'/_tests/_fresh_process_worker.php';
$php=PHP_BINARY;
$out=[]; $code=0;
exec(escapeshellarg($php).' '.escapeshellarg($worker).' 2>&1', $out, $code);
$outStr=implode("\n",$out);
echo "  worker exit={$code}\n  worker out: ".trim($outStr)."\n";
t('P08 fresh-process exit 0 (autoload+prepare+apply)', $code, 0);
t('P08 маркер FRESH_PROCESS_OK', strpos($outStr,'FRESH_PROCESS_OK')!==false, true);
t('P08 нет AUTOLOAD_FAIL', strpos($outStr,'AUTOLOAD_FAIL')===false, true);
t('P08 new_sub_id=pinco4003 в свежем процессе', strpos($outStr,'pinco4003')!==false, true);
echo "\n============================================================\n";
echo "ИТОГО (fresh process): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
