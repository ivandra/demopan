#!/usr/bin/env bash
# run_uc_tests.sh — раннер UI/state-gate рандомизации.
# ОБЯЗАТЕЛЬНЫЕ DB-тесты: их SKIP (exit 3 / "SKIPPED") = BLOCK, НЕ pass и НЕ exit 0.
#   RP_DB_SOCKET=/tmp/mysqlrun/my.sock RP_DB_NAME=rp30 RP_DB_USER=root bash _tests/run_uc_tests.sh
set -uo pipefail
cd "$(dirname "$0")/.."
PASS=0; FAIL=0; BLOCK=0
run(){ local name="$1" mandatory="$2"; shift 2; echo "── ${name}"; local out rc
  out="$("$@" 2>&1)"; rc=$?; echo "$out" | tail -1
  if [ $rc -eq 3 ] || echo "$out" | grep -q 'SKIPPED'; then
    if [ "$mandatory" = "1" ]; then BLOCK=$((BLOCK+1)); echo "  → BLOCK (обязательный тест пропущен, не PASS)"; else echo "  → skip (не обязательный)"; fi
  elif [ $rc -eq 0 ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); echo "  → FAIL (exit $rc)"; fi
  echo; }
run "uc gate UI (policy)"          0 php _tests/test_uc_gate_ui.php
run "uc skip controller (DB)"      1 php _tests/test_uc_skip_controller.php
run "uc skip audit rollback (DB)"  1 php _tests/test_uc_skip_audit_rollback.php
echo "════════════════════════════════════════════"
echo "PASS=${PASS}  FAIL=${FAIL}  BLOCKED=${BLOCK}"
if [ "$FAIL" -eq 0 ] && [ "$BLOCK" -eq 0 ]; then echo "READY_TO_INSTALL=YES"; exit 0; fi
echo "READY_TO_INSTALL=NO"
[ "$FAIL" -ne 0 ] && exit 1
exit 2
