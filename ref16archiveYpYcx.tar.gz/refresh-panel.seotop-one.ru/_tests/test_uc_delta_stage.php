<?php
/** ТЗ046 §14/§18 — оркестраторный gate: settleClassMappingByDelta ставит verified ТОЛЬКО при
 *  changed_pairs>=1; delta=0 → awaiting_user; ambiguous HTTP + delta>=1 → verified без повтора. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (no pdo_mysql)\n"; exit(0); }
$sock=getenv('RP_DB_SOCKET'); $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{
  $pdo = $sock ? new PDO("mysql:unix_socket={$sock};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC])
              : new PDO('mysql:host=127.0.0.1;port=3306;charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $pdo->exec("CREATE DATABASE IF NOT EXISTS rpuc"); $pdo->exec("USE rpuc");
}catch(\Throwable $e){ echo "SKIPPED (DB unavailable)\n"; exit(0); }
$rp=new ReflectionClass('DB'); $p=$rp->getProperty('pdo'); $p->setAccessible(true); $p->setValue(null,$pdo);
$pdo->exec("CREATE TABLE IF NOT EXISTS refresh_job_events(id INT AUTO_INCREMENT PRIMARY KEY, job_id INT, level VARCHAR(16), stage VARCHAR(64), message TEXT, payload_json LONGTEXT NULL, created_at DATETIME DEFAULT NOW())");
$pdo->exec("CREATE TABLE IF NOT EXISTS telegram_settings(id INT PRIMARY KEY)");
$pdo->exec("CREATE TABLE IF NOT EXISTS sites_managed(id INT PRIMARY KEY, update_last_called_at DATETIME NULL)");
$pdo->exec("INSERT IGNORE INTO sites_managed(id) VALUES(7)");

// Fake FTP: возвращает контент по карте
class FakeFtpUC { public $map=[]; public function tryGetContent($p){ return array_key_exists($p,$this->map)?$this->map[$p]:null; } public function connect(){} public function disconnect(){} }

class TestOrchUC extends RefreshOrchestrator {
  public $ftpObj; public $identity='identity_verified';
  protected function makeSiteFtp(int $siteId): ?object { return $this->ftpObj; }
  protected function verifyFtpSiteIdentity($ftp, string $trustedRoot, array $job): array { return ['status'=>$this->identity,'via'=>'test']; }
  protected function normalizePhysicalRoot(string $path): ?string { return $path; }
  protected function verifyUniquificationByFtp(array $job, JobEventLogger $log, string $trustedRoot, array $opts = []): array { return ['status'=>'verified']; }
  public function runSettle(array $job,$log,$root,$profile,$ev,$execId,$execAt,$http): void {
    $this->settleClassMappingByDelta($job,$log,$root,$profile,$ev,$execId,$execAt,$http,[]);
  }
}

function mkJob($pdo,$execId){
  $pdo->exec("DROP TABLE IF EXISTS refresh_jobs");
  $pdo->exec("CREATE TABLE refresh_jobs(id INT PRIMARY KEY, site_id INT, new_domain VARCHAR(255) NULL, stage VARCHAR(64), stage_status VARCHAR(32), stage_error TEXT NULL, stage_finished_at DATETIME NULL, next_run_at DATETIME NULL, php_uniquification_verified_at DATETIME NULL, uc_execution_state VARCHAR(32) NULL, uc_execution_id VARCHAR(64) NULL, artifacts_json LONGTEXT NULL)");
  $pdo->prepare("INSERT INTO refresh_jobs(id,site_id,new_domain,stage,stage_status,uc_execution_id,artifacts_json) VALUES(500,7,'7k5001.casino','update_classes_call','running',?, '{}')")->execute([$execId]);
  return $pdo->query("SELECT * FROM refresh_jobs WHERE id=500")->fetch();
}
$MP='templates/2/source/desktop/class_name_mapping_desktop.txt';
$profile=['strategy'=>'class_mapping','site_base'=>'','units'=>[['id'=>'desktop','mapping'=>$MP,'outputs'=>[]]]];
$beforePairs=['button___A'=>'button___11111','listItem___B'=>'listItem___aaaaa'];
$ev=['class_mapping'=>[$MP=>['exists'=>true,'sha256'=>hash('sha256','x'),'pairs'=>$beforePairs,'pairs_count'=>2]]];
$log=new JobEventLogger(500);

// 1) VERIFIED: delta>=1, identity ok, HTTP ok
$job=mkJob($pdo,'ex1');
$o=new TestOrchUC(); $o->ftpObj=new FakeFtpUC(); $o->ftpObj->map=[$MP=>"button___A:button___22222\nlistItem___B:listItem___aaaaa\n"];
$o->runSettle($job,$log,'/root',$profile,$ev,'ex1','2026-08-12 12:00:00',['ok'=>true,'http_code'=>200]);
$r=$pdo->query("SELECT * FROM refresh_jobs WHERE id=500")->fetch();
tb('VERIFIED: php_uniquification_verified_at установлен', !empty($r['php_uniquification_verified_at']));
t ('VERIFIED: stage_status=ok', $r['stage_status'], 'ok');
$art=json_decode($r['artifacts_json'],true);
t ('VERIFIED: class_delta_after.changed_pairs=1', $art['class_delta_after']['changed_pairs'], 1);

// 2) NOT VERIFIED: delta=0, HTTP ok (маркер не важен)
$job=mkJob($pdo,'ex2');
$o=new TestOrchUC(); $o->ftpObj=new FakeFtpUC(); $o->ftpObj->map=[$MP=>"button___A:button___11111\nlistItem___B:listItem___aaaaa\n"];
$o->runSettle($job,$log,'/root',$profile,$ev,'ex2','2026-08-12 12:00:00',['ok'=>true,'http_code'=>200]);
$r=$pdo->query("SELECT * FROM refresh_jobs WHERE id=500")->fetch();
tb('NOT VERIFIED: verified_at IS NULL', empty($r['php_uniquification_verified_at']));
t ('NOT VERIFIED: stage_status=awaiting_user', $r['stage_status'], 'awaiting_user');

// 3) AMBIGUOUS HTTP + delta>=1 → VERIFIED (без повтора)
$job=mkJob($pdo,'ex3');
$o=new TestOrchUC(); $o->ftpObj=new FakeFtpUC(); $o->ftpObj->map=[$MP=>"button___A:button___99999\nlistItem___B:listItem___aaaaa\n"];
$o->runSettle($job,$log,'/root',$profile,$ev,'ex3','2026-08-12 12:00:00',['ok'=>false,'http_code'=>0,'message'=>'timeout']);
$r=$pdo->query("SELECT * FROM refresh_jobs WHERE id=500")->fetch();
tb('AMBIGUOUS+delta: verified установлен', !empty($r['php_uniquification_verified_at']));
t ('AMBIGUOUS+delta: stage=ok', $r['stage_status'], 'ok');
t ('AMBIGUOUS+delta: http_ambiguous зафиксирован', json_decode($r['artifacts_json'],true)['class_delta_after']['http_ambiguous'], true);

// 4) WRONG IDENTITY → not verified даже при delta
$job=mkJob($pdo,'ex4');
$o=new TestOrchUC(); $o->identity='identity_mismatch'; $o->ftpObj=new FakeFtpUC(); $o->ftpObj->map=[$MP=>"button___A:button___22222\nlistItem___B:listItem___aaaaa\n"];
$o->runSettle($job,$log,'/root',$profile,$ev,'ex4','2026-08-12 12:00:00',['ok'=>true,'http_code'=>200]);
$r=$pdo->query("SELECT * FROM refresh_jobs WHERE id=500")->fetch();
tb('WRONG IDENTITY: verified_at IS NULL', empty($r['php_uniquification_verified_at']));
t ('WRONG IDENTITY: awaiting_user', $r['stage_status'], 'awaiting_user');

echo "\n============================================================\n";
echo "ИТОГО (uc delta stage): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
