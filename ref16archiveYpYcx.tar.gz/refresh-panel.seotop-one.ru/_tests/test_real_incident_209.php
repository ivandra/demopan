<?php
/** ТЗ044 — валидация патча на РЕАЛЬНЫХ данных инцидента:
 *  реальный config.php сломавшегося сайта (7k5001.casino) + реальные artifacts #208/#209 из дампа. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

$FX=__DIR__.'/fixtures/real';
$raw=file_get_contents("$FX/real_209_config.php");

class RSync extends SiteConfigSyncService {
  public $raw; private $p; public $uploads=0;
  public function __construct($r){ $this->p=new SiteConfigParser(); $this->raw=$r; }
  public function fetchFromVpsReadOnly(int $s): array { $pp=$this->p->parse($this->raw); return ["ok"=>true,"raw"=>$this->raw,"path"=>"config.php","sha256"=>hash("sha256",$this->raw),"parsed"=>$pp,"kind"=>"flat"]; }
  public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; $this->raw=$c; return ["ok"=>true]; }
  public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { return ["ok"=>true]; }
}
$sync=new RSync($raw);
$svc=new SiteConfigMutationService($sync,new StaticSiteConfigScanner(),new DomainMaskService([],true));

// scanner на реальном config — safe
tb('REAL scanner isSafe', (new StaticSiteConfigScanner())->scan($raw)->isSafe());

// preflight read-only, ftp=0
$pf=$svc->preflight(7,'7k5278.casino','7k5275.casino');
tb('REAL preflight ok', $pf['ok']);
t ('REAL preflight ftp_writes=0', $pf['prepurchase_preflight']['ftp_writes'], 0);

// prepare на реальном config — НЕТ prepared_target_invalid, 0 FTP
$r=$svc->prepare(7,209,'7k5275.casino','7k5278.casino');
tb('REAL prepare ok (нет prepared_target_invalid)', $r['ok']);
t ('REAL prepare FTP uploads=0', $sync->uploads, 0);
$t2=file_get_contents(Paths::storage($r['plan']['target_storage_path']));
tb('REAL target: domain=7k5278 (idempotent), 7k5274 отсутствует', strpos($t2,'https://7k5278.casino')!==false && strpos($t2,'7k5274')===false);
tb('REAL target: sub_id 7k5275→7k5278 во всех 3 полях', substr_count($t2,'sub_id=7k5278')===3 && strpos($t2,'7k5275')===false);
tb('REAL target: партнёрский host сохранён', substr_count($t2,'partners7k-promo.com')>=3);
tb('REAL drift detected', $r['plan']['config_domain_drift']['detected']===true);
@unlink(Paths::storage($r['plan']['target_storage_path']));

// РЕАЛЬНЫЙ дубль маркера redirect → канонизация
$rt=new RedirectToggler();
$dis=$rt->canonicalizeRedirectVar($raw,0);
t('REAL redirect markers_before=2 (реальный дубль)', $dis['markers_before'], 2);
t('REAL redirect после disable=1 маркер', (int)preg_match_all('~REFRESH-DISABLED~',$dis['content']), 1);
$en=$rt->canonicalizeRedirectVar($dis['content'],1);
[$v,$m]=$rt->redirectVarState($en['content']);
tb('REAL redirect enable read-back enabled==1 & markers==0', $v===1 && $m===0);

// РЕАЛЬНЫЕ artifacts из дампа: recovery #209 → confirmed (без покупки), #208 → superseded
$a209=file_get_contents("$FX/real_209_artifacts.json");
$a208=file_get_contents("$FX/real_208_artifacts.json");
tb('REAL #209 artifacts json валиден', json_decode($a209,true)!==null);
$rec=new JobRecoveryService(null);
$j209=['id'=>209,'site_id'=>7,'stage'=>'config_replaced','stage_status'=>'failed','new_domain'=>'7k5278.casino','artifacts_json'=>$a209];
$j208=['id'=>208,'site_id'=>7,'stage'=>'analyze_site','stage_status'=>'failed','new_domain'=>'','artifacts_json'=>$a208];
$c209=$rec->classify($j209,[$j208,$j209]);
t('REAL recovery #209 = confirmed_purchased', $c209['class'], JobRecoveryService::CONFIRMED_PURCHASED);
t('REAL recovery #209 create_domain_allowed=false', $c209['create_domain_allowed'], false);
t('REAL recovery #209 return=analyze_site', $c209['return_stage'], 'analyze_site');
$c208=$rec->classify($j208,[$j208,$j209]);
t('REAL recovery #208 = superseded (newer #209)', $c208['class'], JobRecoveryService::SUPERSEDED);
t('REAL recovery #208 newer_job_id=209', $c208['newer_job_id'], 209);

// РЕАЛЬНАЯ transient-ошибка 7k5276 из дампа (tried[0].error) → transient
$art=json_decode($a209,true);
$firstErr=$art['tried'][0]['error'] ?? '';
tb('REAL 7k5276 timeout классифицирован transient', NamecheapErrorClassifier::isTransientTransport($firstErr));

echo "\n============================================================\n";
echo "ИТОГО (REAL incident 209): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
