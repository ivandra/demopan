<?php
/** ТЗ044 §18 / BLOCKER 1/2/6 — РЕАЛЬНЫЙ DomainPurchaseService::run() через seams + fake client.
 *  Требует локальный MariaDB (127.0.0.1). Считает createDomainCalls. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (no pdo_mysql)\n"; exit(0); }
$sock=getenv('RP_DB_SOCKET'); $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try {
  if ($sock) { $pdo=new PDO("mysql:unix_socket={$sock};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
  else { $pdo=new PDO('mysql:host=127.0.0.1;port=3306;charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
  $pdo->exec("CREATE DATABASE IF NOT EXISTS rpe2e"); $pdo->exec("USE rpe2e");
} catch(\Throwable $e){ echo "SKIPPED (DB unavailable)\n"; exit(0); }
$ref=new ReflectionClass('DB'); $p=$ref->getProperty('pdo'); $p->setAccessible(true); $p->setValue(null,$pdo);

function resetJob($pdo){
  $pdo->exec("DROP TABLE IF EXISTS refresh_jobs");
  $pdo->exec("CREATE TABLE refresh_jobs(
    id INT PRIMARY KEY, site_id INT, old_domain VARCHAR(255), new_domain VARCHAR(255) NULL,
    stage VARCHAR(64), stage_status VARCHAR(32), stage_error TEXT NULL,
    stage_started_at DATETIME NULL, stage_finished_at DATETIME NULL, next_run_at DATETIME NULL,
    artifacts_json LONGTEXT NULL)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS refresh_job_events(id INT AUTO_INCREMENT PRIMARY KEY, job_id INT, level VARCHAR(16), stage VARCHAR(64), message TEXT, created_at DATETIME DEFAULT NOW())");
  $pdo->exec("CREATE TABLE IF NOT EXISTS telegram_settings(id INT PRIMARY KEY)");
  $pdo->exec("INSERT INTO refresh_jobs(id,site_id,old_domain,new_domain,stage,stage_status,artifacts_json)
    VALUES(999,7,'7k5275.casino','','domain_purchasing','running','{}')");
}
function jobRow($pdo){ $s=$pdo->query("SELECT * FROM refresh_jobs WHERE id=999"); return $s->fetch(); }

// fake NamecheapClient
class FakeNC {
  public $checkCalls=0,$pricingCalls=0,$createCalls=0; public $checkBehavior='ok';
  public function checkDomain($c){ $this->checkCalls++;
    if($this->checkBehavior==='timeout') throw new \RuntimeException('Namecheap curl error: Operation timed out after 30002 milliseconds');
    return ['available'=>true,'premium'=>false]; }
  public function getPricingRegister1Y($tld){ $this->pricingCalls++;
    if($this->checkBehavior==='pricing_timeout') throw new \RuntimeException('cURL error 28: Operation timed out');
    return 5.0; }
  public function createDomain($sld,$tld,$y,$contact){ $this->createCalls++; throw new \RuntimeException('controlled-stop-after-create'); }
}
function mkFakes(&$fake,$preflightOk){
  $svc=new DomainPurchaseService();
  $fake=new FakeNC();
  $svc->clientFactory=function($e,$a,$k) use ($fake){ return $fake; };
  $svc->accountResolver=function($job){ return [['is_sandbox'=>1,'api_user'=>'u','api_key_enc'=>'','username'=>'u','client_ip'=>'1.2.3.4'],['label'=>'c','email'=>'e@e.co','first_name'=>'A','last_name'=>'B','address1'=>'x','city'=>'y','postal_code'=>'1','country'=>'US','phone'=>'+1.1','id'=>1],'https://fake']; };
  $svc->maskFactory=function($jobId,$log){ return new class {
     public function nextDomains($from,$n){ return ['7k5278.casino']; }
     public function extractHost($c){ return $c; }
     public function splitSldTld($h){ return ['7k5278','casino']; }
  }; };
  $svc->ipResolverFn=function($siteId){ return "10.0.0.9"; };
  $svc->preflightFn=function($site,$cand,$old) use ($preflightOk){
     return $preflightOk
       ? ['ok'=>true,'prepurchase_preflight'=>['candidate'=>$cand,'ok'=>true,'ftp_writes'=>0]]
       : ['ok'=>false,'reason'=>'unrecognized_domain_field','prepurchase_preflight'=>['candidate'=>$cand,'ok'=>false,'ftp_writes'=>0]]; };
  return $svc;
}
$log=new JobEventLogger(999);

// PREBUY-E2E-01: unsafe preflight → createDomainCalls=0, awaiting_user
resetJob($pdo);
$svc=mkFakes($f1,false);
$r=$svc->tryPurchase(jobRow($pdo),$log);
t('E2E-01 createDomainCalls=0 при unsafe preflight', $f1->createCalls, 0);
t('E2E-01 reason=prepurchase_unsafe', $r['reason'] ?? '', 'prepurchase_unsafe');
t('E2E-01 job.stage_status=awaiting_user', jobRow($pdo)['stage_status'], 'awaiting_user');
$art=json_decode(jobRow($pdo)['artifacts_json'],true);
tb('E2E-01 prepurchase_preflight сохранён (ok=false)', isset($art['prepurchase_preflight']) && $art['prepurchase_preflight']['ok']===false);

// PREBUY-E2E-02: safe preflight → createDomain вызван ровно 1 раз
resetJob($pdo);
$svc=mkFakes($f2,true);
$r2=$svc->tryPurchase(jobRow($pdo),$log);
t('E2E-02 createDomainCalls=1 при safe preflight', $f2->createCalls, 1);
tb('E2E-02 preflight пройден до покупки (checkCalls>=1, pricingCalls>=1)', $f2->checkCalls>=1 && $f2->pricingCalls>=1);

// PREBUY-E2E-03: pricing timeout → тот же кандидат, backoff, createDomain НЕ вызван
resetJob($pdo);
$svc=mkFakes($f3,true); $f3->checkBehavior='pricing_timeout';
$r3=$svc->tryPurchase(jobRow($pdo),$log);
t('E2E-03 pricing transient: createDomainCalls=0', $f3->createCalls, 0);
t('E2E-03 reason=transient_retry', $r3['reason'] ?? '', 'transient_retry');
$row3=jobRow($pdo); $art3=json_decode($row3['artifacts_json'],true);
t('E2E-03 stage_status=pending (backoff)', $row3['stage_status'], 'pending');
t('E2E-03 transient_retry.candidate сохранён', $art3['domain_purchasing_stage']['transient_retry']['candidate'] ?? '', '7k5278.casino');
t('E2E-03 operation=pricing', $art3['domain_purchasing_stage']['transient_retry']['operation'] ?? '', 'pricing');

echo "\n============================================================\n";
echo "ИТОГО (prebuy e2e): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
