<?php
/** S01–S12: StaticSiteConfigScanner. Запуск: php _tests/test_scanner.php */
$ROOT=dirname(__DIR__);
require_once $ROOT.'/app/Services/ConfigScanResult.php';
require_once $ROOT.'/app/Services/StaticSiteConfigScanner.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
$s=new StaticSiteConfigScanner(); $P="<?php\n";

// S01 7k flat
$r=$s->scan($P."\$domain='https://7k5268.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$base_second_url=\"https://p.com/b?sub_id=7k5241\";\n\$internal_reg_url=\"https://p.com/c?sub_id=7k5241\";\n");
t('S01 safe', $r->isSafe(), true);
t('S01 unique sub=7k5241', $r->uniqueSubIdOrNull(), '7k5241');
tb('S01 domain_required', $r->domainRequired());

// S02 Pinco без domain
$r=$s->scan($P."\$redirect_url=\"https://p.com/a?sub_id=pinco4002\";\n\$internal_reg_url=\"https://p.com/b?sub_id=pinco4002\";\n");
t('S02 safe', $r->isSafe(), true);
t('S02 domain_required=false', $r->domainRequired(), false);

// S03 enomo array literal (РЕАЛЬНЫЙ формат $site=[...] из фикстура)
$enomo=file_get_contents(dirname(__DIR__).'/_tests/fixtures/configs/enomo-array.php');
$r=$s->scan($enomo);
t('S03 array-literal safe', $r->isSafe(), true);
t('S03 unique=DFenix51', $r->uniqueSubIdOrNull(), 'DFenix51');
tb('S03 domain_required', $r->domainRequired());
$urlFields=0; foreach($r->assignments() as $a) if($a['kind']==='url_field') $urlFields++;
t('S03 3 url-поля (array:site.redirect.*)', $urlFields, 3);
$paths=array_map(fn($a)=>$a['path'],$r->assignments());
tb('S03 путь array:site.redirect.base_new_url', in_array('array:site.redirect.base_new_url',$paths,true));
tb('S03 путь array:site.domain', in_array('array:site.domain',$paths,true));

// S04 sub_id только в комментарии
$r=$s->scan($P."// \$base_new_url=\"?sub_id=x\";\n\$domain='https://c.casino';\n");
t('S04 safe (NO_SUB_ID)', $r->isSafe(), true);
t('S04 sub=null', $r->uniqueSubIdOrNull(), null);

// S05 $note содержит текст "$sub_id = ..." — не occurrence
$r=$s->scan($P."\$note = \"Example: \\\$sub_id = 'foo';\";\n\$domain='https://c.casino';\n");
t('S05 safe (строковый текст не occurrence)', $r->isSafe(), true);
t('S05 sub=null', $r->uniqueSubIdOrNull(), null);

// S06 $sub_id = getSubId()
$r=$s->scan($P."\$sub_id = getSubId();\n");
t('S06 blocked unknown', $r->reason(), 'unrecognized_sub_id_field');

// S07 $config['sub_id']='x'
$r=$s->scan($P."\$config['sub_id']='x';\n");
t('S07 blocked unknown', $r->reason(), 'unrecognized_sub_id_field');

// S08 конкатенация / интерполяция
t('S08a concat blocked', $s->scan($P."\$redirect_url='https://x?sub_id=' . \$sid;\n")->reason(), 'unrecognized_sub_id_field');
t('S08b interp blocked', $s->scan($P.'$redirect_url="https://x?sub_id={$sid}";'."\n")->reason(), 'unrecognized_sub_id_field');

// S09 duplicate field
$r=$s->scan($P."\$base_new_url=\"https://p.com/a?sub_id=7k1\";\n\$base_new_url=\"https://p.com/a?sub_id=7k1\";\n");
t('S09 duplicate blocked', $r->reason(), 'duplicate_config_field');

// S10 sykaaa два значения
$r=$s->scan($P."\$base_new_url=\"https://p.com/a?sub_id=s4\";\n\$internal_reg_url=\"https://p.com/b?sub_id=s9\";\n");
t('S10 conflict blocked', $r->reason(), 'sub_id_conflict');

// S11 malformed
$r=$s->scan($P."\$x = = = ;;;");
t('S11 parse_error', $r->reason(), 'php_parse_error');

// S12 no-subid
$r=$s->scan($P."\$domain='https://c.casino';\n\$base_new_url=\"https://p.com/x\";\n");
t('S12 safe domain-only', $r->isSafe(), true);
t('S12 sub=null', $r->uniqueSubIdOrNull(), null);
tb('S12 domain_required', $r->domainRequired());

// доп: unknown tracking-поле
t('EX tracking-поле blocked', $s->scan($P."\$tracking=\"https://p.com/a?sub_id=unk\";\n")->reason(), 'unrecognized_sub_id_field');
// доп: $redirect_url=$var
t('EX $redirect_url=$var blocked', $s->scan($P."\$redirect_url=\$u;\n")->reason(), 'unrecognized_sub_id_field');

echo "\n============================================================\n";
echo "ИТОГО (scanner): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
