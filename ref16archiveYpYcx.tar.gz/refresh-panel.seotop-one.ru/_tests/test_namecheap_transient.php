<?php
/** ТЗ044 §10/§16.4 — Namecheap transient classification + bounded backoff (NC-01..04). */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
$C='NamecheapErrorClassifier';

// NC-01: transient timeout классифицируется как transient (не taken/next)
tb('NC-01 curl timeout → transient', $C::isTransientTransport('cURL error 28: Operation timed out after 30000 ms'));
tb('NC-01b connection refused → transient', $C::isTransientTransport('Failed to connect to api.namecheap.com: Connection refused'));
tb('NC-01c HTTP 503 → transient', $C::isTransientTransport('HTTP 503 Service Unavailable'));
tb('NC-01d empty reply → transient', $C::isTransientTransport('Empty reply from server'));
tb('NC-01e обычная «taken» НЕ transient', $C::isTransientTransport('Domain is not available')===false);

// NC-02: bounded backoff 30/60/120, max 3
t('NC-02 backoff #1=30', $C::backoffSeconds(1), 30);
t('NC-02 backoff #2=60', $C::backoffSeconds(2), 60);
t('NC-02 backoff #3=120', $C::backoffSeconds(3), 120);
t('NC-02 MAX_TRANSIENT_ATTEMPTS=3', $C::MAX_TRANSIENT_ATTEMPTS, 3);

// NC-03: account fatal (invalid API key / ClientIp) → account_fatal (awaiting_user), НЕ transient
$cls=$C::classify(1011102,'namecheap.domains.check','API key invalid'); // 1011102 = auth fatal (в таблице)
tb('NC-03 invalid key → account_fatal', !empty($cls['account_fatal']));
tb('NC-03 не transient (это фатально, а не сеть)', $C::isTransientTransport('Invalid request IP: 1.2.3.4')===false);

// NC-04: create-unknown safety — transient detector НЕ трогает create-семантику (осталась как есть).
// Проверяем что transient-детектор не относит «Order creation failed» к transient (иначе бы повторили create).
tb('NC-04 order creation failed НЕ transient', $C::isTransientTransport('Order creation failed 2528166')===false);

echo "\n============================================================\n";
echo "ИТОГО (namecheap transient): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
