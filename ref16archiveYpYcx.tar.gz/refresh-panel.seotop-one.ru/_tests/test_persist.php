<?php
/** persistVerified: транзакция + re-select. Реальный rp30. AC07.
 *   RP_DB_SOCKET=/tmp/mysqlrun/my.sock RP_DB_NAME=rp30 RP_DB_USER=root php _tests/test_persist.php */
$ROOT=dirname(__DIR__);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (no pdo_mysql)\n"; exit(0); }
require_once $ROOT.'/bin/_bootstrap.php';
$sock=getenv('RP_DB_SOCKET'); $name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
if(!$sock){ echo "SKIPPED (no RP_DB_SOCKET)\n"; exit(0); }
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); }
catch(\Throwable $e){ echo "SKIPPED (DB unavailable)\n"; exit(0); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}

$SITE=900021;
$pdo->prepare("DELETE FROM sites_managed WHERE id=?")->execute([$SITE]);
$pdo->prepare("INSERT INTO sites_managed (id,current_domain,status) VALUES (?, 'old.casino','imported')")->execute([$SITE]);
$sync=new SiteConfigSyncService();
$parsed=['domain'=>'https://new.casino','sub_id'=>'7k5269'];

// success
$r=$sync->persistVerified($SITE,'config.php',$parsed,'flat',"<?php // raw\n",'new.casino');
t('persist ok', $r['ok']??false, true);
$row=$pdo->query("SELECT current_domain,config_parsed_json FROM sites_managed WHERE id={$SITE}")->fetch();
t('current_domain=new.casino', $row['current_domain'], 'new.casino');
t('config_parsed_json содержит sub_id', strpos((string)$row['config_parsed_json'],'7k5269')!==false, true);

// re-select mismatch (несуществующий сайт → UPDATE 0 строк, re-select пуст → throw → rollback)
$r2=$sync->persistVerified(99999999,'config.php',$parsed,'flat',"<?php\n",'x.casino');
t('mismatch → ok=false', $r2['ok']??true, false);
t('mismatch → reason snapshot_persist_failed', $r2['reason']??'', 'snapshot_persist_failed');
// исходный сайт не тронут вторым вызовом
$row=$pdo->query("SELECT current_domain FROM sites_managed WHERE id={$SITE}")->fetch();
t('первый сайт не изменился mismatch-вызовом', $row['current_domain'], 'new.casino');

$pdo->prepare("DELETE FROM sites_managed WHERE id=?")->execute([$SITE]);
echo "\n============================================================\n";
echo "ИТОГО (persist): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
