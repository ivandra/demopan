<?php
/** ТЗ046 ADDENDUM §21–§23 — recovery routing: class_mapping recovery ТОЛЬКО через delta-verifier.
 *  Никакого повторного HTTP; старый verifier не authoritative; verified iff changed_pairs>=1. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (no pdo_mysql)\n"; exit(0); }
$sock=getenv('RP_DB_SOCKET'); $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{
  $pdo=$sock?new PDO("mysql:unix_socket={$sock};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC])
           :new PDO('mysql:host=127.0.0.1;port=3306;charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $pdo->exec("CREATE DATABASE IF NOT EXISTS rprec2"); $pdo->exec("USE rprec2");
}catch(\Throwable $e){ echo "SKIPPED (DB unavailable)\n"; exit(0); }
$rp=new ReflectionClass('DB'); $p=$rp->getProperty('pdo'); $p->setAccessible(true); $p->setValue(null,$pdo);
$pdo->exec("CREATE TABLE IF NOT EXISTS refresh_job_events(id INT AUTO_INCREMENT PRIMARY KEY, job_id INT, level VARCHAR(16), stage VARCHAR(64), message TEXT, payload_json LONGTEXT NULL, created_at DATETIME DEFAULT NOW())");
$pdo->exec("CREATE TABLE IF NOT EXISTS telegram_settings(id INT PRIMARY KEY)");
$pdo->exec("CREATE TABLE IF NOT EXISTS sites_managed(id INT PRIMARY KEY, update_last_called_at DATETIME NULL)");
$pdo->exec("INSERT IGNORE INTO sites_managed(id) VALUES(7)");

class FakeFtpR { public $map=[]; public function tryGetContent($p){ return $this->map[$p]??null; } public function connect(){} public function disconnect(){} }
class TestOrchR extends RefreshOrchestrator {
  public $ftpObj; public $identity='identity_verified'; public $httpCalls=0; public $oldVerifierCalls=0;
  protected function makeSiteFtp(int $s): ?object { return $this->ftpObj; }
  protected function verifyFtpSiteIdentity($ftp,string $r,array $j): array { return ['status'=>$this->identity,'via'=>'test']; }
  protected function normalizePhysicalRoot(string $p): ?string { return $p; }
  protected function callUpdateClassesUrl(string $url, JobEventLogger $log, ?string $domainForResolve = null, ?string $vpsIp = null): array { $this->httpCalls++; return ["ok"=>true,"http_code"=>200,"body"=>"Update process completed"]; }
  protected function verifyUniquificationByFtp(array $j,JobEventLogger $l,string $r,array $o=[]): array { $this->oldVerifierCalls++; return ['status'=>'verified']; }
  public function runRecover(array $job,$log,$root,$profile,$ev,$state): bool { return $this->recoverClassMappingByDelta($job,$log,$root,$profile,$ev,$state); }
}
$MP='templates/2/source/desktop/class_name_mapping_desktop.txt';
function mkJob($pdo,$state){
  $pdo->exec("DROP TABLE IF EXISTS refresh_jobs");
  $pdo->exec("CREATE TABLE refresh_jobs(id INT PRIMARY KEY, site_id INT, new_domain VARCHAR(255) NULL, stage VARCHAR(64), stage_status VARCHAR(32), stage_error TEXT NULL, stage_finished_at DATETIME NULL, next_run_at DATETIME NULL, php_uniquification_verified_at DATETIME NULL, uc_execution_state VARCHAR(32) NULL, uc_execution_id VARCHAR(64) NULL, artifacts_json LONGTEXT NULL)");
  $pdo->prepare("INSERT INTO refresh_jobs(id,site_id,new_domain,stage,stage_status,uc_execution_state,uc_execution_id,artifacts_json) VALUES(600,7,'7k5001.casino','update_classes_call','running',?, 'ex','{}')")->execute([$state]);
  return $pdo->query("SELECT * FROM refresh_jobs WHERE id=600")->fetch();
}
$profile=['strategy'=>'class_mapping','site_base'=>'','units'=>[['id'=>'desktop','mapping'=>$MP,'outputs'=>[]]]];
$beforePairs=[]; for($i=0;$i<321;$i++)$beforePairs["c$i"]="v$i";
$ev=['class_mapping'=>[$MP=>['exists'=>true,'sha256'=>hash('sha256','b'),'pairs'=>$beforePairs,'pairs_count'=>321]]];
function afterMap($pairs){ $s=''; foreach($pairs as $k=>$v)$s.="$k:$v\n"; return $s; }
$log=new JobEventLogger(600);
function run($pdo,$state,$identity,$afterContent,$evidence,$profile,$log,$MP){
  $job=mkJob($pdo,$state); $o=new TestOrchR(); $o->identity=$identity; $o->ftpObj=new FakeFtpR(); $o->ftpObj->map=[$MP=>$afterContent];
  $o->runRecover($job,$log,'/root',$profile,$evidence,$state);
  $r=$pdo->query("SELECT * FROM refresh_jobs WHERE id=600")->fetch();
  return [$r,$o];
}
// helpers to make after variants
$afterSame=afterMap($beforePairs);
$aftChanged=$beforePairs; $aftChanged['c0']='CHANGED_ALL'; foreach($aftChanged as $k=>&$v){$v.='_x';} unset($v); $afterAllChanged=afterMap($aftChanged);
$aft1=$beforePairs; $aft1['c0']='ONLYONE'; $after1changed=afterMap($aft1);

// 01 started + AFTER changed → verified, HTTP=0
[$r,$o]=run($pdo,'started','identity_verified',$afterAllChanged,$ev,$profile,$log,$MP);
tb('UC-REC-01 verified_at != NULL',!empty($r['php_uniquification_verified_at'])); t('UC-REC-01 stage=ok',$r['stage_status'],'ok'); t('UC-REC-01 HTTP calls=0',$o->httpCalls,0);

// 02 started + AFTER identical → awaiting_user, verified NULL, HTTP=0
[$r,$o]=run($pdo,'started','identity_verified',$afterSame,$ev,$profile,$log,$MP);
tb('UC-REC-02 verified_at NULL',empty($r['php_uniquification_verified_at'])); t('UC-REC-02 awaiting_user',$r['stage_status'],'awaiting_user'); t('UC-REC-02 HTTP=0',$o->httpCalls,0);

// 03 ambiguous + AFTER changed → verified, no retry
[$r,$o]=run($pdo,'ambiguous','identity_verified',$after1changed,$ev,$profile,$log,$MP);
tb('UC-REC-03 verified',!empty($r['php_uniquification_verified_at'])); t('UC-REC-03 no HTTP retry',$o->httpCalls,0);

// 04 ambiguous + AFTER unchanged → awaiting_user, no retry
[$r,$o]=run($pdo,'ambiguous','identity_verified',$afterSame,$ev,$profile,$log,$MP);
t('UC-REC-04 awaiting_user',$r['stage_status'],'awaiting_user'); t('UC-REC-04 no retry',$o->httpCalls,0);

// 05 completed + verified_at NULL + AFTER changed → verified by delta
[$r,$o]=run($pdo,'completed','identity_verified',$after1changed,$ev,$profile,$log,$MP);
tb('UC-REC-05 verified by delta',!empty($r['php_uniquification_verified_at']));

// 06 started + BEFORE missing → awaiting_user, HTTP=0
$evEmpty=['class_mapping'=>[]];
[$r,$o]=run($pdo,'started','identity_verified',$afterAllChanged,$evEmpty,$profile,$log,$MP);
tb('UC-REC-06 BEFORE missing → verified NULL',empty($r['php_uniquification_verified_at'])); t('UC-REC-06 awaiting_user',$r['stage_status'],'awaiting_user'); t('UC-REC-06 HTTP=0',$o->httpCalls,0);

// 07 started + AFTER changed + identity mismatch → not verified
[$r,$o]=run($pdo,'started','identity_mismatch',$afterAllChanged,$ev,$profile,$log,$MP);
tb('UC-REC-07 identity mismatch → not verified',empty($r['php_uniquification_verified_at']));

// 08 started + SHA != but semantic identical → changed=0 not verified
$afterWs=''; foreach($beforePairs as $k=>$v)$afterWs.="$k:  $v  \n"; $afterWs.="\n";
[$r,$o]=run($pdo,'started','identity_verified',$afterWs,$ev,$profile,$log,$MP);
tb('UC-REC-08 whitespace-only → not verified',empty($r['php_uniquification_verified_at'])); t('UC-REC-08 awaiting_user',$r['stage_status'],'awaiting_user');

// 09 started + 1/321 changed → verified
[$r,$o]=run($pdo,'started','identity_verified',$after1changed,$ev,$profile,$log,$MP);
tb('UC-REC-09 1/321 → verified',!empty($r['php_uniquification_verified_at']));

// 10 real fixtures 7k2500→7k5001
$FX=__DIR__.'/fixtures/class_mapping';
$b2500=ClassMappingDeltaVerifier::parsePairs(file_get_contents("$FX/7k2500_desktop.txt"));
$evReal=['class_mapping'=>[$MP=>['exists'=>true,'sha256'=>'x','pairs'=>$b2500,'pairs_count'=>count($b2500)]]];
[$r,$o]=run($pdo,'started','identity_verified',file_get_contents("$FX/7k5001_desktop.txt"),$evReal,$profile,$log,$MP);
tb('UC-REC-10 реальные фикстуры → verified',!empty($r['php_uniquification_verified_at']));
t ('UC-REC-10 changed=182 в артефакте', json_decode($r['artifacts_json'],true)['class_delta_after']['changed_pairs'],182);

// §22 негативный: changed=0, старый verifier НЕ вызывался (не authoritative)
[$r,$o]=run($pdo,'started','identity_verified',$afterSame,$ev,$profile,$log,$MP);
tb('§22 changed=0 → verified NULL (старый verifier не переопределяет)',empty($r['php_uniquification_verified_at']));
t ('§22 старый verifyUniquificationByFtp НЕ вызван',$o->oldVerifierCalls,0);

// §23 позитивный: changed>=1 → verified (delta authoritative)
[$r,$o]=run($pdo,'started','identity_verified',$after1changed,$ev,$profile,$log,$MP);
tb('§23 changed>=1 → verified',!empty($r['php_uniquification_verified_at']));

echo "\n============================================================\n";
echo "ИТОГО (uc recovery delta): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
