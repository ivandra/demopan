<?php
/** ТЗ046 §16 — sitemap НИКОГДА не в переобход; страницы — да; completion не требует sitemap. */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

// WM-REC-01/02: план не содержит sitemap; sitemap-URL из $pages фильтруется
$home='https://7k5001.casino/';
$pages=['https://7k5001.casino/','https://7k5001.casino/games','https://7k5001.casino/sitemap.xml','https://7k5001.casino/sitemap_index.xml','https://7k5001.casino/promo'];
$plan=[]; $plan[]=['url'=>$home,'role'=>'home','required'=>true];
foreach($pages as $u){ if(rtrim($u,'/')===rtrim($home,'/'))continue; if(RecrawlUrlRepository::isSitemapUrl($u))continue; $plan[]=['url'=>$u,'role'=>'page','required'=>true]; }
$roles=array_column($plan,'role');
t('WM-REC-01 первая роль home', $roles[0], 'home');
tb('WM-REC-01/02 НЕТ роли sitemap в плане', !in_array('sitemap',$roles,true));
tb('WM-REC-02 sitemap.xml отфильтрован', !in_array('https://7k5001.casino/sitemap.xml',array_column($plan,'url'),true));
tb('WM-REC-02 sitemap_index.xml отфильтрован', !in_array('https://7k5001.casino/sitemap_index.xml',array_column($plan,'url'),true));
t('WM-REC-01 обычные страницы остались (2 page)', count(array_filter($roles,fn($r)=>$r==='page')), 2);

// WM-REC-04: wm_sitemap/addSitemap не тронут (проверка исходника)
$src=file_get_contents(__DIR__.'/../app/Services/RefreshOrchestrator.php');
tb('WM-REC-04 addSitemap по-прежнему вызывается', strpos($src,'$client->addSitemap(')!==false);
tb('WM-REC-04 runWmSitemapStage существует', strpos($src,"case 'wm_sitemap':")!==false);

// DB-backed: WM-REC-03 (exclude) + WM-REC-05 (completion не требует sitemap)
if(!extension_loaded('pdo_mysql')){ echo "  [skip] DB тесты (no pdo_mysql)\n"; }
else {
  $sock=getenv('RP_DB_SOCKET'); $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
  try{
    $pdo=$sock?new PDO("mysql:unix_socket={$sock};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC])
             :new PDO('mysql:host=127.0.0.1;port=3306;charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS rprec"); $pdo->exec("USE rprec");
  }catch(\Throwable $e){ echo "  [skip] DB unavailable\n"; $pdo=null; }
  if($pdo){
    $rp=new ReflectionClass('DB'); $p=$rp->getProperty('pdo'); $p->setAccessible(true); $p->setValue(null,$pdo);
    $pdo->exec("DROP TABLE IF EXISTS refresh_job_recrawl_urls");
    $pdo->exec("CREATE TABLE refresh_job_recrawl_urls(
      id INT AUTO_INCREMENT PRIMARY KEY, job_id INT, url VARCHAR(500), url_hash VARCHAR(64), is_required TINYINT, role VARCHAR(16),
      status VARCHAR(20), attempts INT DEFAULT 0, last_error TEXT NULL, page_http_code INT NULL, api_http_code INT NULL,
      api_error_code VARCHAR(40) NULL, task_id VARCHAR(64) NULL, next_retry_at DATETIME NULL, claimed_at DATETIME NULL,
      created_at DATETIME DEFAULT NOW(), updated_at DATETIME DEFAULT NOW(), UNIQUE KEY(job_id,url_hash))");
    $ins=function($job,$url,$role,$status,$req=1) use($pdo){ $pdo->prepare("INSERT INTO refresh_job_recrawl_urls(job_id,url,url_hash,is_required,role,status) VALUES(?,?,?,?,?,?)")->execute([$job,$url,sha1($url.$status),$req,$role,$status]); };

    // WM-REC-03: старая sitemap pending → excluded, sitemap accepted не трогаем
    $ins(700,'https://x.casino/sitemap.xml','sitemap','pending');
    $ins(700,'https://x.casino/sitemap.xml','sitemap','accepted'); // историческая — не трогать
    $ins(700,'https://x.casino/','home','pending');
    $n=RecrawlUrlRepository::excludeSitemapRows(700);
    t('WM-REC-03 исключена 1 pending sitemap', $n, 1);
    t('WM-REC-03 pending sitemap → excluded', $pdo->query("SELECT status FROM refresh_job_recrawl_urls WHERE job_id=700 AND role='sitemap' AND url_hash='".sha1('https://x.casino/sitemap.xml'.'pending')."'")->fetchColumn(), 'excluded');
    t('WM-REC-03 last_error=sitemap_not_for_recrawl', $pdo->query("SELECT last_error FROM refresh_job_recrawl_urls WHERE job_id=700 AND status='excluded'")->fetchColumn(), 'sitemap_not_for_recrawl');
    t('WM-REC-03 accepted sitemap НЕ тронут', (int)$pdo->query("SELECT COUNT(*) FROM refresh_job_recrawl_urls WHERE job_id=700 AND role='sitemap' AND status='accepted'")->fetchColumn(), 1);

    // WM-REC-05: completion не требует sitemap. home accepted + page accepted → complete
    $ins(701,'https://y.casino/','home','accepted');
    $ins(701,'https://y.casino/games','page','accepted',0);
    tb('WM-REC-05 complete без sitemap-роли', RecrawlUrlRepository::isComplete(701)===true);
    // с excluded sitemap тоже complete
    $ins(702,'https://z.casino/','home','accepted');
    $ins(702,'https://z.casino/p','page','accepted',0);
    $ins(702,'https://z.casino/sitemap.xml','sitemap','excluded');
    tb('WM-REC-05b complete при excluded sitemap', RecrawlUrlRepository::isComplete(702)===true);
    // home ещё pending → НЕ complete (home всё ещё required)
    $ins(703,'https://w.casino/','home','pending');
    tb('WM-REC-05c home pending → НЕ complete', RecrawlUrlRepository::isComplete(703)===false);
  }
}

echo "\n============================================================\n";
echo "ИТОГО (sitemap recrawl): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
