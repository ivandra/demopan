<?php
/**
 * ОБЯЗАТЕЛЬНЫЙ DB-тест: audit failure → rollback. Если запись в refresh_job_events
 * не удалась, UPDATE (operator_skipped) ДОЛЖЕН откатиться. operator_skipped не
 * существует без audit. Симуляция сбоя: временно переименовываем таблицу событий.
 * При недоступной БД → exit 3 (SKIP=BLOCK).
 *   RP_DB_SOCKET=/tmp/mysqlrun/my.sock RP_DB_NAME=rp30 RP_DB_USER=root php _tests/test_uc_skip_audit_rollback.php
 */
$ROOT=dirname(__DIR__);
if(!extension_loaded('pdo_mysql')){ echo "SKIPPED (mandatory DB test, no pdo_mysql) → BLOCK\n"; exit(3); }
require_once $ROOT.'/bin/_bootstrap.php';
$sock=getenv('RP_DB_SOCKET'); if(!$sock){ echo "SKIPPED (mandatory DB test, no RP_DB_SOCKET) → BLOCK\n"; exit(3); }
$name=getenv('RP_DB_NAME')?:'rp30'; $user=getenv('RP_DB_USER')?:'root'; $pass=getenv('RP_DB_PASS')?:'';
try{ $pdo=new PDO("mysql:unix_socket={$sock};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); }
catch(\Throwable $e){ echo "SKIPPED (mandatory DB test, DB unavailable) → BLOCK\n"; exit(3); }
$rp=new ReflectionProperty('DB','pdo'); $rp->setAccessible(true); $rp->setValue(null,$pdo);
require_once $ROOT.'/app/Core/Controller.php';
require_once $ROOT.'/app/Controllers/RefreshJobController.php';
@session_start(); $_SESSION['auth']=true; $_SESSION['csrf_token']='testtok';

$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
class Redirected extends \Exception {}
class TCtl extends RefreshJobController {
    public $flashes=[];
    protected function flash(string $t,string $m): void { $this->flashes[]=[$t,$m]; }
    protected function redirect(string $u): void { throw new Redirected($u); }
    public function doSkip(){ try{ $this->skipUpdateClasses(); }catch(Redirected $e){} }
}
$JOB=900041;
$pdo->prepare("DELETE FROM refresh_jobs WHERE id=?")->execute([$JOB]);
$pdo->prepare("INSERT INTO refresh_jobs (id,site_id,old_domain,new_domain,stage,stage_status,uc_execution_state,artifacts_json) VALUES (?,?,?,?,?,?,?,?)")
    ->execute([$JOB,1,'old.casino','new.casino','update_classes_call','awaiting_user','ambiguous',json_encode(['update_classes_stage'=>[]])]);

$renamed=false;
try {
    // Симулируем сбой audit: убираем таблицу событий → INSERT внутри транзакции упадёт.
    $pdo->exec("RENAME TABLE refresh_job_events TO refresh_job_events_uctmp");
    $renamed=true;

    $_POST=['id'=>$JOB,'confirm'=>'yes','comment'=>'проверка отката audit','csrf_token'=>'testtok'];
    $ctl=new TCtl(); $ctl->doSkip();

    // вернуть таблицу ДО проверок (чтобы читать события)
    $pdo->exec("RENAME TABLE refresh_job_events_uctmp TO refresh_job_events");
    $renamed=false;

    $s=$pdo->prepare("SELECT * FROM refresh_jobs WHERE id=?"); $s->execute([$JOB]); $r=$s->fetch()?:[];
    $uc=(json_decode((string)$r['artifacts_json'],true)?:[])['update_classes_stage']??[];
    t('audit упал → outcome НЕ operator_skipped (rollback)', ($uc['outcome']??'')!=='operator_skipped', true);
    t('audit упал → uc_execution_state НЕ operator_skipped', (string)$r['uc_execution_state']!=='operator_skipped', true);
    t('audit упал → stage_status НЕ ok (осталось awaiting_user)', (string)$r['stage_status'], 'awaiting_user');
    t('audit упал → gate НЕ проходит', RefreshOrchestrator::updateClassesGateSatisfied($r), false);
    t('audit упал → flash error', count(array_filter($ctl->flashes,fn($f)=>$f[0]==='error'))>=1, true);
    $ac=$pdo->prepare("SELECT COUNT(*) FROM refresh_job_events WHERE job_id=?"); $ac->execute([$JOB]);
    t('audit упал → ни одной записи о пропуске', (int)$ac->fetchColumn(), 0);
} finally {
    if ($renamed) { try { $pdo->exec("RENAME TABLE refresh_job_events_uctmp TO refresh_job_events"); } catch (\Throwable $e) {} }
    $pdo->prepare("DELETE FROM refresh_jobs WHERE id=?")->execute([$JOB]);
    $pdo->prepare("DELETE FROM refresh_job_events WHERE job_id=?")->execute([$JOB]);
}
echo "\n============================================================\n";
echo "ИТОГО (uc skip audit rollback): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
