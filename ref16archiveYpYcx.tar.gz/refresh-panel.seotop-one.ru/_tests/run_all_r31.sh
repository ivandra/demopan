#!/bin/sh
# run_all_r31.sh — полный прогон поставки «SSL до Webmaster + XMLStock UI» (§11).
# DB-тесты обязательны: отсутствие pdo_mysql/сокета = BLOCKED (exit 3), НЕ pass.
#   RP_DB_SOCKET=/tmp/mysqlrun/my.sock RP_DB_NAME=rp31t RP_DB_USER=root sh _tests/run_all_r31.sh
# ВАЖНО: test_migration (036 down/up) разрушает данные тестовой БД — идёт ПОСЛЕДНИМ.
# После него пересоздайте тестовую БД из эталонного дампа, если планируете повторные прогоны.
set -u
cd "$(dirname "$0")/.." || exit 2
FAILED=0; BLOCKED=0

echo "=== ЛИНТ изменённых production-файлов ==="
LINT_FAIL=0
for f in \
  app/Migrations/038_ssl_before_webmaster_and_xmlstock_ui.php \
  app/Services/TrustedSslGate.php \
  app/Services/RefreshOrchestrator.php \
  app/Services/JobLifecycleService.php \
  app/Services/JobEventLogger.php \
  app/Controllers/RefreshJobController.php \
  app/Controllers/XmlStockController.php \
  app/Services/BanMonitoring/BanMonitoringSettingsRepository.php \
  app/Services/BanMonitoring/BanMonitorEnrollmentService.php \
  app/Services/BanMonitoring/BanMonitorRepository.php \
  app/Services/BanMonitoring/BanMonitorBootstrapService.php \
  app/Services/BanMonitoring/BanMonitorService.php \
  app/Services/BanMonitoring/BanMonitorTelegramFormatter.php \
  app/Services/IndexCheck/XmlStockRequestService.php \
  app/Services/IndexCheck/XmlStockUsageRepository.php \
  app/Services/IndexCheck/XmlStockLabels.php \
  app/Services/IndexCheck/XmlStockDashboardQueryService.php \
  app/Views/xmlstock/index.php \
  app/Views/jobs/_ban_monitor_card.php \
  app/Views/jobs/show.php
do
  php -l "$f" >/dev/null 2>&1 || { echo "LINT FAIL: $f"; LINT_FAIL=1; }
done
[ "$LINT_FAIL" = "0" ] && echo "Все файлы: синтаксис OK" || FAILED=1

run() { # run <label> <path>
  echo ""
  echo "=== $1 ==="
  if [ ! -f "$2" ]; then
    echo ">>> ОТСУТСТВУЕТ ФАЙЛ ТЕСТА: $2 — FAIL (неполная поставка)"
    FAILED=1
    return
  fi
  php "$2"
  rc=$?
  if [ $rc -eq 3 ]; then echo ">>> BLOCKED (окружение БД недоступно — НЕ pass)"; BLOCKED=1
  elif [ $rc -ne 0 ]; then FAILED=1; fi
}

echo ""
echo "########## OFFLINE ##########"
run "P0 unit: TrustedSslGate.verify()" _tests/trusted_ssl/test_trusted_ssl_gate.php
run "P0 статика: порядок стадий (§11.1.16)" _tests/trusted_ssl/test_stage_order.php
run "Ban state machine (§11.4)" _tests/ban_monitoring/test_state_machine.php
run "Telegram formatter (§8)" _tests/ban_monitoring/test_telegram_format.php
run "Карточка джобы (§7)" _tests/ban_monitoring/test_job_card.php

echo ""
echo "########## DB (обязательные; порядок: недеструктивные → migration-тесты последними) ##########"
run "UI structure (§6, рендер 4 вкладок)" _tests/xmlstock_ui2/test_ui_structure.php
run "Контракт UI→Router→Controller (P0)" _tests/xmlstock_ui2/test_router_contract.php
run "Query service (§9)" _tests/xmlstock_ui2/test_query_service.php
run "Settings/eligibility (§11.4)" _tests/ban_monitoring/test_settings_eligibility.php
run "Cutoff automatic enrollment (§2.4.1)" _tests/ban_monitoring/test_cutoff.php
run "Exactly-once XMLStock (§11.2.6)" _tests/xmlstock_usage/test_exactly_once.php
run "complete()-fail → ambiguous + стоп-кран blocked (§2.4.2/§5.3)" _tests/xmlstock_usage/test_complete_fail_blocked.php
run "CSRF все POST /xmlstock (§2.4.3)" _tests/xmlstock_usage/test_csrf_legacy.php
run "XMLStock controller/breakdown (§11.4)" _tests/xmlstock_usage/test_xmlstock_ui.php
run "Ban service (§11.4)" _tests/ban_monitoring/test_service.php
run "Ban integration (§11.4)" _tests/ban_monitoring/test_integration.php
run "Monitor actions (§11.4)" _tests/ban_monitoring/test_monitor_actions.php
run "Security/audit (§11.4)" _tests/ban_monitoring/test_security.php
run "P0 pipeline: gate/guard/adopt/timeout (§11.1)" _tests/trusted_ssl/test_trusted_ssl_pipeline.php
run "P0 controller: skip/override/check-now (§4.6/§4.8)" _tests/trusted_ssl/test_gate_actions.php
run "Bootstrap CLI (§11.2.5)" _tests/ban_bootstrap/test_bootstrap.php
run "Bootstrap web (§11.2.5)" _tests/ban_bootstrap/test_bootstrap_web.php
run "Migration 038 (§10.2)" _tests/ban_monitoring/test_migration_038.php
echo ""
echo "--- ВНИМАНИЕ: тесты миграций 037/036 гоняют down/up и РАЗРУШАЮТ данные тестовой БД ---"
echo "--- (после них тестовую БД нужно пересоздать из эталонного дампа) ---"
run "Migration 037 up/down/cutover" _tests/ban_monitoring/test_migration_037.php
run "Migration 036 up/down/idempotent" _tests/ban_monitoring/test_migration.php

echo ""
echo "============================================================"
# Приоритет статусов: упавший/отсутствующий тест = FAIL даже при наличии BLOCKED,
# иначе недоступное обязательное окружение = BLOCKED, иначе PASS.
if [ "$FAILED" = "1" ]; then
  echo "РЕЗУЛЬТАТ: ЕСТЬ ПАДЕНИЯ ИЛИ ОТСУТСТВУЮЩИЕ ТЕСТЫ. READY_TO_INSTALL=NO"
  exit 1
elif [ "$BLOCKED" = "1" ]; then
  echo "РЕЗУЛЬТАТ: BLOCKED — обязательные DB-тесты не выполнены (нет окружения)."
  exit 3
else
  echo "РЕЗУЛЬТАТ: ВСЕ ТЕСТЫ ЗЕЛЁНЫЕ. READY_TO_INSTALL=YES"
  exit 0
fi
