<?php
/** Apply: TOCTOU, ровно один upload, байтовый read-back, semantic, persist, idempotent.
 *  P03–P07, P09. Запуск: php _tests/test_apply_toctou.php */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}

class ASync extends SiteConfigSyncService {
    public $raw; private $parser; public $uploads=0; public $persists=0;
    public $corruptOnUpload=null; public $persistOk=true; public $failReadBack=false;
    public function __construct($raw){ $this->parser=new SiteConfigParser(); $this->raw=$raw; }
    public function fetchFromVpsReadOnly(int $s): array {
        if ($this->failReadBack && $this->uploads>0) return ['ok'=>false,'error'=>'FTP read failed'];
        try{$p=$this->parser->parse($this->raw);}catch(\Throwable $e){return ['ok'=>false,'error'=>'parser exception'];}
        return ['ok'=>true,'raw'=>$this->raw,'path'=>'config.php','sha256'=>hash('sha256',$this->raw),'parsed'=>$p,'kind'=>'flat'];
    }
    public function uploadRaw(int $s,string $p,string $c): array { $this->uploads++; $this->raw=$this->corruptOnUpload??$c; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array {
        $this->persists++; return $this->persistOk?['ok'=>true]:['ok'=>false,'reason'=>'snapshot_persist_failed']; }
}
$mask=new DomainMaskService([],true);
$RAW="<?php\n\$domain='https://7k5268.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$internal_reg_url=\"https://p.com/b?sub_id=7k5241\";\n";
function mkPlan($sync,$mask,$job){ $svc=new SiteConfigMutationService($sync,new StaticSiteConfigScanner(),$mask);
    $r=$svc->prepare(7,$job,'7k5268.casino','7k5269.casino'); return [$svc,$r['plan']]; }

// P06 (success): read-back SHA==target → semantic → persist
$s=new ASync($RAW); [$svc,$plan]=mkPlan($s,$mask,301);
$res=$svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
tb('P06 apply ok', $res['ok']);
t('P06 ровно один upload', $s->uploads, 1);
t('P06 persist вызван 1', $s->persists, 1);
tb('P06 на FTP новый sub_id+домен', strpos($s->raw,'7k5269.casino')!==false && strpos($s->raw,'sub_id=7k5269')!==false && strpos($s->raw,'7k5241')===false);
tb('P06 target-файл удалён после success', !is_file(Paths::storage($plan['target_storage_path'])));

// P03 source изменён после analyze → config_changed_after_analyze, upload=0
$s=new ASync($RAW); [$svc,$plan]=mkPlan($s,$mask,302);
$s->raw="<?php\n\$domain='https://7k5268.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n// changed\n";
$res=$svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
t('P03 reason', $res['reason'], 'config_changed_after_analyze');
t('P03 upload=0', $s->uploads, 0);
@unlink(Paths::storage($plan['target_storage_path']));

// P04 target-файл повреждён → stored_target_corrupted, upload=0
$s=new ASync($RAW); [$svc,$plan]=mkPlan($s,$mask,303);
file_put_contents(Paths::storage($plan['target_storage_path']),"<?php // CORRUPT\n");
$res=$svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
t('P04 reason', $res['reason'], 'stored_target_corrupted');
t('P04 upload=0', $s->uploads, 0);
@unlink(Paths::storage($plan['target_storage_path']));

// P05 read-back байты != target → read_back_sha_mismatch, upload=1
$s=new ASync($RAW); [$svc,$plan]=mkPlan($s,$mask,304);
$s->corruptOnUpload="<?php\n\$domain='https://7k5269.casino';\n\$base_new_url=\"https://p.com/a?sub_id=7k5241\";\n\$internal_reg_url=\"https://p.com/b?sub_id=7k5269\";\n";
$res=$svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
t('P05 reason read_back_sha_mismatch', $res['reason'], 'read_back_sha_mismatch');
t('P05 upload=1', $s->uploads, 1);
@unlink(Paths::storage($plan['target_storage_path']));

// P07 persist не подтвердился → snapshot_persist_failed
$s=new ASync($RAW); $s->persistOk=false; [$svc,$plan]=mkPlan($s,$mask,305);
$res=$svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
t('P07 reason snapshot_persist_failed', $res['reason'], 'snapshot_persist_failed');
@unlink(Paths::storage($plan['target_storage_path']));

// read_back_ftp_failed
$s=new ASync($RAW); $s->failReadBack=true; [$svc,$plan]=mkPlan($s,$mask,306);
$res=$svc->applyPrepared(ConfigMutationPlan::fromArray($plan));
t('read_back_ftp_failed', $res['reason'], 'read_back_ftp_failed');
@unlink(Paths::storage($plan['target_storage_path']));

// P09 повторный apply после success → idempotent (source==target≠plan.source) → upload=0
$s=new ASync($RAW); [$svc,$plan]=mkPlan($s,$mask,307);
$svc->applyPrepared(ConfigMutationPlan::fromArray($plan)); // success (target удалён)
$s->uploads=0;
// восстановим target-файл, чтобы дойти до SHA guard
$svc2=new SiteConfigMutationService($s,new StaticSiteConfigScanner(),$mask);
$res=$svc2->applyPrepared(ConfigMutationPlan::fromArray($plan));
t('P09 повтор → config_changed_after_analyze', $res['reason'], 'config_changed_after_analyze');
t('P09 второй upload=0', $s->uploads, 0);

echo "\n============================================================\n";
echo "ИТОГО (apply/TOCTOU): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
