<?php
/** P08 worker: запускается в НОВОМ php-процессе. Требует ТОЛЬКО _bootstrap.php;
 *  все production-классы должны автозагрузиться (каждый в своём файле). */
require __DIR__ . '/../bin/_bootstrap.php';

// Все 4 класса должны быть доступны через autoload (не предзагружены вручную).
foreach (['ConfigScanResult','StaticSiteConfigScanner','ConfigMutationPlan','SiteConfigMutationService','SubIdFleetScanner','SubIdRemediationRunner'] as $c) {
    if (!class_exists($c)) { fwrite(STDERR, "AUTOLOAD_FAIL: {$c}\n"); exit(2); }
}

// In-memory fake sync (без FTP/БД) — полный prepare + applyPrepared в свежем процессе.
$fake = new class extends SiteConfigSyncService {
    public $raw; private $parser; public $uploads=0;
    public function __construct(){ $this->parser=new SiteConfigParser();
        $this->raw="<?php\n\$redirect_url=\"https://p.com/a?sub_id=pinco4002\";\n"; }
    public function fetchFromVpsReadOnly(int $s): array { $p=$this->parser->parse($this->raw);
        return ['ok'=>true,'raw'=>$this->raw,'path'=>'config.php','sha256'=>hash('sha256',$this->raw),'parsed'=>$p,'kind'=>'flat']; }
    public function uploadRaw(int $s,string $pth,string $c): array { $this->uploads++; $this->raw=$c; return ['ok'=>true]; }
    public function persistVerified(int $s,string $rp,array $d,string $k,string $r,string $nd): array { return ['ok'=>true]; }
};
$svc = new SiteConfigMutationService($fake, new StaticSiteConfigScanner(), new DomainMaskService([], true));
$prep = $svc->prepare(7, 970001, 'pinco4002.casino', 'pinco4003.casino');
if (empty($prep['ok'])) { fwrite(STDERR, "PREPARE_FAIL: ".($prep['reason']??'')."\n"); exit(3); }
$res = $svc->applyPrepared(ConfigMutationPlan::fromArray($prep['plan']));
if (empty($res['ok'])) { fwrite(STDERR, "APPLY_FAIL: ".($res['reason']??'')."\n"); exit(4); }
if (strpos($fake->raw,'pinco4003')===false || strpos($fake->raw,'pinco4002')!==false) { fwrite(STDERR,"SUBID_NOT_APPLIED\n"); exit(5); }
echo "FRESH_PROCESS_OK uploads={$fake->uploads} new_sub_id={$prep['plan']['new_sub_id']}\n";
exit(0);
