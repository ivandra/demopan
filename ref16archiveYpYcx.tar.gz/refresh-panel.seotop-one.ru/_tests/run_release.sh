#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# run_release.sh — release-runner единого mutation-pipeline config.php.
# Раздельный учёт PASS / FAIL / SKIP-BLOCKED. Пропуск ОБЯЗАТЕЛЬНОГО теста = блокер.
# Host fleet по живым FTP всех sites_managed здесь НЕ выполняется → BLOCKED всегда
# до запуска на хосте (MASS_ROLLOUT_BLOCKED_BY_HOST_FLEET).
#
#   RP_DB_SOCKET=/tmp/mysqlrun/my.sock RP_DB_NAME=rp30 RP_DB_USER=root bash _tests/run_release.sh
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
cd "$(dirname "$0")/.."   # public_html
PASS=0; FAIL=0; BLOCK=0
declare -a RESULTS
run() { local name="$1"; shift; echo "── ${name}"; local out rc
  out="$("$@" 2>&1)"; rc=$?; echo "$out" | tail -2
  if echo "$out" | grep -q 'SKIPPED'; then BLOCK=$((BLOCK+1)); RESULTS+=("BLOCK  ${name} (SKIPPED — обязательный)")
  elif [ $rc -eq 0 ]; then PASS=$((PASS+1)); RESULTS+=("PASS   ${name}")
  else FAIL=$((FAIL+1)); RESULTS+=("FAIL   ${name} (exit ${rc})"); fi; echo; }

echo "=== C09: LINT всего дерева (malformed-fixture исключён явно) ==="
LINT_ERR=0; NFILES=0
while IFS= read -r f; do NFILES=$((NFILES+1)); php -l "$f" >/dev/null 2>&1 || { echo "  LINT FAIL: $f"; LINT_ERR=$((LINT_ERR+1)); }; done \
  < <(find . -name '*.php' -not -path '*/fixtures/*' -not -name 'malformed*')
echo "  проверено файлов: ${NFILES}, ошибок: ${LINT_ERR}"
if [ "$LINT_ERR" -ne 0 ]; then FAIL=$((FAIL+1)); RESULTS+=("FAIL   lint tree (${LINT_ERR} err)"); else RESULTS+=("PASS   lint tree (${NFILES} файлов)"); PASS=$((PASS+1)); fi
echo

echo "=== C07/AC11: абсолютные /home пути и placeholder в app/bin (ожидается 0) ==="
HOMEHITS=$(grep -rIn "/home/claude\|/mnt/user-data\|__PLACEHOLDER__\|TODO_PLACEHOLDER" app bin 2>/dev/null | wc -l | tr -d ' ')
echo "  совпадений: ${HOMEHITS}"
if [ "$HOMEHITS" -ne 0 ]; then FAIL=$((FAIL+1)); RESULTS+=("FAIL   /home paths (${HOMEHITS})"); else RESULTS+=("PASS   no /home paths in app/bin"); PASS=$((PASS+1)); fi
echo

# offline-слои (БД/FTP не нужны)
run "S01-S12 scanner"                 php _tests/test_scanner.php
run "Enomo array e2e (fenix51→52)"    php _tests/test_enomo_array.php
run "snapshot corpus (false-safe=0)"  php _tests/test_snapshot_corpus.php
run "P01-P02 prepare target"          php _tests/test_prepare_target.php
run "P03-P09 apply/TOCTOU"            php _tests/test_apply_toctou.php
run "P08 fresh-process autoload"      php _tests/test_fresh_process.php
run "C04-C06 fleet (exit 0/2/3)"      php _tests/test_fleet.php
run "C01-C03 remediation CLI"         php _tests/test_remediation_cli.php
run "mutation battery"                php _tests/test_mutations.php
run "DRIFT-209 (real drift)"          php _tests/test_drift_209.php
run "stage invariants (B3/B4)"        php _tests/test_stage_invariants.php
run "redirect idempotency (B3)"       php _tests/test_redirect_idempotency.php
run "prepurchase preflight (B1)"      php _tests/test_prepurchase_preflight.php
run "namecheap transient (B2)"        php _tests/test_namecheap_transient.php
run "recovery 209/208 (B5)"           php _tests/test_recovery_209.php
run "integration 209"                 php _tests/test_integration_209.php
run "REAL incident 209 (dump+config)" php _tests/test_real_incident_209.php
run "PREBUY E2E (real tryPurchase,B1/B2/B6)" php _tests/test_prebuy_e2e.php
run "recovery handler 209 (BLOCKER D)"       php _tests/test_recovery_handler_209.php
run "recovery security (Rev3 CSRF/lock/CAS)" php _tests/test_recovery_security_209.php

# ОБЯЗАТЕЛЬНЫЕ DB-тесты (C08): SKIP → BLOCK
run "persist (транзакция+re-select)"  php _tests/test_persist.php
run "integration orchestrator + AC01" php _tests/test_integration_orchestrator.php

# host fleet — обязательный gate, здесь не выполним
BLOCK=$((BLOCK+1)); RESULTS+=("BLOCK  live host fleet (--source=ftp по всем sites_managed — на хосте, AC13)")

echo "════════════════════════════════════════════════════════════"
printf '%s\n' "${RESULTS[@]}"
echo "────────────────────────────────────────────────────────────"
echo "PASS=${PASS}  FAIL=${FAIL}  SKIP/BLOCKED=${BLOCK}"

# Была ли пропущена ОБЯЗАТЕЛЬНАЯ интеграция БД? (C08)
DB_SKIPPED="NO"; printf '%s\n' "${RESULTS[@]}" | grep -q 'BLOCK  integration orchestrator' && DB_SKIPPED="YES"
printf '%s\n' "${RESULTS[@]}" | grep -q 'BLOCK  persist' && DB_SKIPPED="YES"

CODE_REVIEW="NO"; CANARY="NO"
if [ "$FAIL" -eq 0 ] && [ "$DB_SKIPPED" = "NO" ]; then CODE_REVIEW="READY"; CANARY="READY"; fi
echo "STATUS: CODE_REVIEW_READY=${CODE_REVIEW}  CANARY_READY=${CANARY}  MASS_ROLLOUT=BLOCKED_BY_HOST_FLEET"

# exit: fail или пропуск обязательного DB-теста → 1; иначе host-fleet BLOCK → 2.
if [ "$FAIL" -ne 0 ] || [ "$DB_SKIPPED" = "YES" ]; then exit 1; fi
exit 2
