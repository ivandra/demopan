<?php
/** ТЗ044 §9/§16.3 — redirect marker idempotency (REDIR-01..04). */
require_once dirname(__DIR__).'/bin/_bootstrap.php';
$PASS=0;$FAIL=0;
function t($n,$g,$e){global $PASS,$FAIL; if($g===$e){$PASS++;echo "  [OK]   $n\n";}else{$FAIL++;echo "  [FAIL] $n exp=".var_export($e,true)." got=".var_export($g,true)."\n";}}
function tb($n,$c){t($n,(bool)$c,true);}
$rt = new RedirectToggler();
function mcount($s){ return (int)preg_match_all('~REFRESH-DISABLED~',$s); }

// REDIR-01: `= 1; // REFRESH-DISABLED` --disable--> ровно один маркер, значение 0
$in="<?php\n\$redirect_enabled = 1; // REFRESH-DISABLED\n";
$r=$rt->canonicalizeRedirectVar($in,0);
tb('REDIR-01 disable found', $r['found']);
t ('REDIR-01 semantic_after=0', $r['semantic_after'], 0);
t ('REDIR-01 ровно один маркер', mcount($r['content']), 1);
tb('REDIR-01 строка канонична', strpos($r['content'],'$redirect_enabled = 0; // REFRESH-DISABLED')!==false);

// REDIR-02: дубль маркеров --disable--> идемпотентно, ровно один маркер
$in2="<?php\n\$redirect_enabled = 0; // REFRESH-DISABLED // REFRESH-DISABLED\n";
$r2=$rt->canonicalizeRedirectVar($in2,0);
t ('REDIR-02 markers_before=2', $r2['markers_before'], 2);
t ('REDIR-02 после=1 маркер', mcount($r2['content']), 1);
t ('REDIR-02 normalized_duplicates=1', $r2['normalized_duplicates'], 1);
// повторный вызов — ничего не меняет (идемпотентность)
$r2b=$rt->canonicalizeRedirectVar($r2['content'],0);
tb('REDIR-02 идемпотентно (повтор не меняет)', $r2b['changed']===false && mcount($r2b['content'])===1);

// REDIR-03: enable из любого состояния → значение 1, маркеров 0
foreach ([
  "<?php\n\$redirect_enabled = 0; // REFRESH-DISABLED\n",
  "<?php\n\$redirect_enabled = 0; // REFRESH-DISABLED // REFRESH-DISABLED\n",
  "<?php\n\$redirect_enabled = 1;\n",
] as $i=>$src){
  $re=$rt->canonicalizeRedirectVar($src,1);
  t("REDIR-03[$i] semantic_after=1", $re['semantic_after'], 1);
  t("REDIR-03[$i] markers=0", mcount($re['content']), 0);
}

// REDIR-04: read-back state helper — enable результат enabled==1 & markers==0
$en=$rt->canonicalizeRedirectVar("<?php\n\$redirect_enabled = 0; // REFRESH-DISABLED\n",1);
[$val,$mk]=$rt->redirectVarState($en['content']);
tb('REDIR-04 read-back enabled==1 && markers==0 → ok', $val===1 && $mk===0);
// а если бы маркер остался/значение 0 — read-back не ok
[$v2,$m2]=$rt->redirectVarState("<?php\n\$redirect_enabled = 0; // REFRESH-DISABLED\n");
tb('REDIR-04 stale state (0 + marker) → not-ok detectable', !($v2===1 && $m2===0));

echo "\n============================================================\n";
echo "ИТОГО (redirect idempotency): PASS={$PASS} FAIL={$FAIL}\n";
exit($FAIL===0?0:1);
