<?php
/**
 * casino-api.php — STANDALONE точка входа для casino-endpoints.
 * Залей в public/ по FTP — не нужно редактировать index.php.
 *
 * Маршруты (через ?__route=):
 *   ?__route=domain/check&domain=X&account_id=Y&max_price=Z&vps_ip=W   (GET)
 *   ?__route=buy/start            (POST JSON)
 *   ?__route=runs/show&run_id=X   (GET)
 *   ?__route=projects/register    (POST JSON)
 *   ?__route=projects/list        (GET)
 *   ?__route=projects/show&id=X   (GET)
 */

define('APP_ROOT', dirname(__DIR__));
define('STORAGE_ROOT', APP_ROOT . '/storage');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', STORAGE_ROOT . '/logs/php_errors.log');
error_reporting(E_ALL);
mb_internal_encoding('UTF-8');
date_default_timezone_set('UTC');

require APP_ROOT . '/app/Core/Paths.php';
Paths::ensureStorageTree();

$__APP_CONFIG = require APP_ROOT . '/config/app.php';
if (!function_exists('config')) {
    function config(string $path, $default = null) {
        global $__APP_CONFIG;
        $cur = $__APP_CONFIG;
        foreach (explode('.', $path) as $p) {
            if (is_array($cur) && array_key_exists($p, $cur)) $cur = $cur[$p];
            else return $default;
        }
        return $cur;
    }
}

spl_autoload_register(function ($class) {
    foreach ([
        APP_ROOT . '/app/Core/' . $class . '.php',
        APP_ROOT . '/app/Services/' . $class . '.php',
        APP_ROOT . '/app/Services/IndexCheck/' . $class . '.php',
        APP_ROOT . '/app/Controllers/' . $class . '.php',
    ] as $f) {
        if (is_file($f)) { require $f; return; }
    }
});

header('Content-Type: application/json; charset=utf-8');

set_exception_handler(function (Throwable $e) {
    @error_log('[casino-api uncaught] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'uncaught', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
});

$route = (string)($_GET['__route'] ?? '');
$ctrl  = new CasinoApiController();

switch ($route) {
    case 'version':
        // Самопроверка: открой в браузере без авторизации —
        // ?__route=version → увидишь что патч v0.5-fix7 реально залит.
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'ok' => true,
            'patch_version' => 'b2b4-v0.5-fix16-buyfix2',
            'has_update_ip' => method_exists('CasinoApiController', 'updateIp'),
            'subdomains_service_dns_wildcard_filter' =>
                is_file(__DIR__ . '/../app/Services/CasinoSubdomainsService.php')
                && strpos((string)file_get_contents(__DIR__ . '/../app/Services/CasinoSubdomainsService.php'), "label === '*'") !== false,
            'fp_aliases_concrete' =>
                is_file(__DIR__ . '/../app/Services/CasinoSubdomainsService.php')
                && strpos((string)file_get_contents(__DIR__ . '/../app/Services/CasinoSubdomainsService.php'), 'КОНКРЕТНЫЕ зеркала') !== false,
            'has_webmaster' => method_exists('CasinoApiController', 'webmasterVerify')
                && is_file(__DIR__ . '/../app/Services/CasinoWebmasterService.php'),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    case 'domain/check':      $ctrl->domainCheck(); break;
    case 'buy/start':         $ctrl->buyStart();    break;
    case 'subdomains/start':  $ctrl->subdomainsStart(); break;
    case 'runs/show':         $ctrl->runsShow();    break;
    case 'runs/tick':         $ctrl->runsTick();    break;
    case 'server/vps-ip':     $ctrl->vpsIp();       break;
    case 'server/resolve-site': $ctrl->resolveSite(); break;
    case 'server/update-ip':  $ctrl->updateIp();    break;
    case 'cron/setup':        $ctrl->cronSetup();   break;
    case 'projects/register': $ctrl->register();    break;
    case 'projects/list':     $ctrl->list();        break;
    case 'projects/show':     $ctrl->show();        break;
    case 'webmaster/add-host':      $ctrl->webmasterAddHost();      break;
    case 'webmaster/prepare':       $ctrl->webmasterPrepare();      break;
    case 'webmaster/verify':        $ctrl->webmasterVerify();       break;
    case 'webmaster/verify-status': $ctrl->webmasterVerifyStatus(); break;
    case 'webmaster/recrawl':       $ctrl->webmasterRecrawl();      break;
    case 'webmaster/sitemap':       $ctrl->webmasterSitemap();      break;
    case 'webmaster/robots':        $ctrl->webmasterRobots();       break;
    default:
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'unknown_route', 'message' => "Route '$route' not handled"], JSON_UNESCAPED_UNICODE);
}
