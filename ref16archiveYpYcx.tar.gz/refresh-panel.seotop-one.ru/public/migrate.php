<?php
/**
 * CLI запуск миграций.
 * Использование:
 *   php public/migrate.php
 */

if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    echo 'CLI only';
    exit;
}

define('APP_ROOT', dirname(__DIR__));
define('STORAGE_ROOT', APP_ROOT . '/storage');

require APP_ROOT . '/app/Core/Paths.php';
Paths::ensureStorageTree();

$__APP_CONFIG = require APP_ROOT . '/config/app.php';
function config(string $path, $default = null) {
    global $__APP_CONFIG;
    $cur = $__APP_CONFIG;
    foreach (explode('.', $path) as $p) {
        if (is_array($cur) && array_key_exists($p, $cur)) $cur = $cur[$p];
        else return $default;
    }
    return $cur;
}

spl_autoload_register(function ($class) {
    $candidates = [
        APP_ROOT . '/app/Core/' . $class . '.php',
        APP_ROOT . '/app/Services/' . $class . '.php',
    ];
    foreach ($candidates as $f) {
        if (is_file($f)) { require $f; return; }
    }
});

try {
    $migrator = new Migrator();
    $report = $migrator->migrate();

    echo "=== Migration report ===\n";
    if (empty($report['ran'])) {
        echo "Nothing to apply (all up-to-date).\n";
    } else {
        echo "Applied:\n";
        foreach ($report['ran'] as $name) echo "  + {$name}\n";
    }
    if (!empty($report['errors'])) {
        echo "\nErrors:\n";
        foreach ($report['errors'] as $err) echo "  ! {$err}\n";
        exit(1);
    }
    echo "\nDone.\n";
} catch (Throwable $e) {
    echo "FATAL: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
