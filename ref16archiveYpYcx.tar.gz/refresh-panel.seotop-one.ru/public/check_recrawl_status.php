#!/usr/bin/env php
<?php

/**
 * Read-only checker for Refresh Panel recrawl state.
 *
 * Sources:
 *   1) refresh_job_recrawl_urls in the panel DB;
 *   2) Yandex Webmaster GET recrawl/queue and GET recrawl/queue/{task-id}.
 *
 * The script never sends a URL, never updates DB and never changes site files.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$jobId = 223;
$panelRoot = '';
$jsonOutput = false;
$maxPages = 10;

foreach (array_slice($argv, 1) as $arg) {
    if (preg_match('~^--job=(\d+)$~', $arg, $m)) {
        $jobId = (int)$m[1];
    } elseif (strpos($arg, '--panel-root=') === 0) {
        $panelRoot = rtrim(substr($arg, strlen('--panel-root=')), '/');
    } elseif (preg_match('~^--max-pages=(\d+)$~', $arg, $m)) {
        $maxPages = max(1, min(100, (int)$m[1]));
    } elseif ($arg === '--json') {
        $jsonOutput = true;
    } elseif ($arg === '--help' || $arg === '-h') {
        echo "usage:\n";
        echo "  php check_recrawl_status.php --panel-root=/path/to/public_html [--job=223] [--json]\n";
        echo "  php public_html/bin/check_recrawl_status.php [--job=223] [--json]\n";
        echo "\nRead-only: DB SELECT + Yandex API GET only.\n";
        exit(0);
    } else {
        fwrite(STDERR, "unknown argument: {$arg}\n");
        exit(2);
    }
}

// If copied into <panel>/bin, no --panel-root is required.
if ($panelRoot === '') {
    $candidate = dirname(__DIR__);
    if (is_file($candidate . '/bin/_bootstrap.php')) $panelRoot = $candidate;
}
if ($panelRoot === '' || $panelRoot[0] !== '/' || !is_file($panelRoot . '/bin/_bootstrap.php')) {
    fwrite(STDERR, "panel root not found; pass --panel-root=/absolute/path/to/public_html\n");
    exit(2);
}

require_once $panelRoot . '/bin/_bootstrap.php';

function crsTasksFromResponse(array $response): array
{
    $tasks = $response['tasks'] ?? ($response['data']['tasks'] ?? []);
    return is_array($tasks) ? array_values(array_filter($tasks, 'is_array')) : [];
}

function crsNormalizeUrl(string $url): string
{
    $url = trim($url);
    $parts = parse_url($url);
    if (!is_array($parts)) return $url;
    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    $host = rtrim(strtolower((string)($parts['host'] ?? '')), '.');
    $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
    $path = (string)($parts['path'] ?? '/');
    if ($path === '') $path = '/';
    $query = isset($parts['query']) ? '?' . $parts['query'] : '';
    return $scheme . '://' . $host . $port . $path . $query;
}

function crsSelectTask(array $tasks, string $url, string $taskId): ?array
{
    if ($taskId !== '') {
        foreach ($tasks as $task) {
            if ((string)($task['task_id'] ?? '') === $taskId) return $task;
        }
    }
    $needle = crsNormalizeUrl($url);
    $matches = [];
    foreach ($tasks as $task) {
        if (crsNormalizeUrl((string)($task['url'] ?? '')) === $needle) $matches[] = $task;
    }
    if (!$matches) return null;
    usort($matches, static function (array $a, array $b): int {
        return strcmp((string)($b['added_time'] ?? ''), (string)($a['added_time'] ?? ''));
    });
    return $matches[0];
}

try {
    $pdo = DB::pdo();

    $st = $pdo->prepare('SELECT * FROM refresh_jobs WHERE id=?');
    $st->execute([$jobId]);
    $job = $st->fetch(PDO::FETCH_ASSOC);
    if (!is_array($job)) throw new RuntimeException("job #{$jobId} not found");

    $st = $pdo->prepare(
        'SELECT id, url, role, is_required, status, attempts, api_accepted, '
        . 'last_page_http_code, last_api_http_code, last_api_error_code, task_id, '
        . 'accepted_at, last_error, created_at, updated_at '
        . 'FROM refresh_job_recrawl_urls WHERE job_id=? ORDER BY is_required DESC, id ASC'
    );
    $st->execute([$jobId]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);

    $artifacts = json_decode((string)($job['artifacts_json'] ?? ''), true);
    if (!is_array($artifacts)) $artifacts = [];
    $wm = (array)($artifacts['wm_added_stage'] ?? []);
    $accountId = (int)($wm['account_id'] ?? 0);
    $userId = trim((string)($wm['user_id'] ?? ''));
    $hostId = trim((string)($wm['host_id'] ?? ''));

    if ($accountId <= 0) {
        $accountId = (int)($job['webmaster_account_override_id'] ?? 0);
    }
    if ($accountId <= 0) throw new RuntimeException('Webmaster account_id is absent in job artifacts');

    if ($userId === '') {
        $st = $pdo->prepare('SELECT yandex_user_id FROM yandex_webmaster_accounts WHERE id=?');
        $st->execute([$accountId]);
        $userId = trim((string)$st->fetchColumn());
    }
    if ($userId === '') throw new RuntimeException('Yandex user_id is absent');
    if ($hostId === '') throw new RuntimeException('Yandex host_id is absent in wm_added_stage');

    $client = new YandexWebmasterClient($accountId);
    $path = '/v4/user/' . rawurlencode($userId)
        . '/hosts/' . rawurlencode($hostId) . '/recrawl/queue';

    // Read the recent queue. This is especially important for rows accepted via
    // HTTP 409, where the panel legitimately has no new task_id.
    $tasks = [];
    for ($page = 0; $page < $maxPages; $page++) {
        $batchResponse = $client->rawRequest('GET', $path, [
            'offset' => $page * 50,
            'limit' => 50,
        ]);
        $batch = crsTasksFromResponse($batchResponse);
        foreach ($batch as $task) $tasks[] = $task;
        if (count($batch) < 50) break;
    }

    // Direct task lookup guarantees a check even if a known task is older than
    // the paginated recent window.
    $directErrors = [];
    foreach ($rows as $row) {
        $taskId = trim((string)($row['task_id'] ?? ''));
        if ($taskId === '') continue;
        $alreadyLoaded = false;
        foreach ($tasks as $task) {
            if ((string)($task['task_id'] ?? '') === $taskId) {
                $alreadyLoaded = true;
                break;
            }
        }
        if ($alreadyLoaded) continue;
        try {
            $task = $client->rawRequest('GET', $path . '/' . rawurlencode($taskId));
            if (!empty($task['task_id'])) $tasks[] = $task;
        } catch (Throwable $e) {
            $directErrors[$taskId] = $e->getMessage();
        }
    }

    $results = [];
    $counts = [
        'planned' => count($rows),
        'panel_accepted' => 0,
        'yandex_found' => 0,
        'in_progress' => 0,
        'done' => 0,
        'failed' => 0,
        'not_found' => 0,
    ];

    foreach ($rows as $row) {
        $url = (string)$row['url'];
        $taskId = trim((string)($row['task_id'] ?? ''));
        $task = crsSelectTask($tasks, $url, $taskId);
        $panelAccepted = (int)$row['api_accepted'] === 1
            && (((int)$row['last_api_http_code'] === 202 && $taskId !== '')
                || (int)$row['last_api_http_code'] === 409);
        if ($panelAccepted) $counts['panel_accepted']++;

        $yandexFound = is_array($task);
        $state = $yandexFound ? strtoupper((string)($task['state'] ?? 'UNKNOWN')) : 'NOT_FOUND';
        if ($yandexFound) $counts['yandex_found']++;
        if ($state === 'IN_PROGRESS') $counts['in_progress']++;
        elseif ($state === 'DONE') $counts['done']++;
        elseif ($state === 'FAILED') $counts['failed']++;
        elseif ($state === 'NOT_FOUND') $counts['not_found']++;

        $results[] = [
            'row_id' => (int)$row['id'],
            'url' => $url,
            'role' => (string)$row['role'],
            'required' => (int)$row['is_required'] === 1,
            'panel_status' => (string)$row['status'],
            'panel_api_accepted' => (int)$row['api_accepted'] === 1,
            'panel_evidence_valid' => $panelAccepted,
            'panel_api_http' => $row['last_api_http_code'] !== null ? (int)$row['last_api_http_code'] : null,
            'panel_task_id' => $taskId !== '' ? $taskId : null,
            'panel_error' => $row['last_error'],
            'yandex_found' => $yandexFound,
            'yandex_task_id' => $yandexFound ? (string)($task['task_id'] ?? '') : null,
            'yandex_state' => $state,
            'yandex_added_time' => $yandexFound ? ($task['added_time'] ?? null) : null,
            'direct_lookup_error' => $taskId !== '' ? ($directErrors[$taskId] ?? null) : null,
        ];
    }

    if ($counts['planned'] === 0) {
        $verdict = 'NO_PANEL_ROWS';
        $exitCode = 10;
    } elseif ($counts['failed'] > 0) {
        $verdict = 'YANDEX_CRAWL_FAILED';
        $exitCode = 11;
    } elseif ($counts['yandex_found'] === 0) {
        $verdict = 'NOT_FOUND_IN_YANDEX_QUEUE';
        $exitCode = 10;
    } elseif ($counts['yandex_found'] !== $counts['planned']
        || $counts['panel_accepted'] !== $counts['planned']) {
        $verdict = 'PARTIAL_OR_PANEL_MISMATCH';
        $exitCode = 12;
    } elseif ($counts['done'] === $counts['planned']) {
        $verdict = 'ALL_CRAWLED_DONE';
        $exitCode = 0;
    } else {
        $verdict = 'ALL_CONFIRMED_IN_YANDEX';
        $exitCode = 0;
    }

    $report = [
        'read_only' => true,
        'checked_at_utc' => gmdate('c'),
        'job' => [
            'id' => (int)$job['id'],
            'site_id' => (int)$job['site_id'],
            'old_domain' => (string)$job['old_domain'],
            'new_domain' => (string)$job['new_domain'],
            'stage' => (string)$job['stage'],
            'stage_status' => (string)$job['stage_status'],
        ],
        'webmaster' => [
            'account_id' => $accountId,
            'user_id' => $userId,
            'host_id' => $hostId,
            'queue_tasks_loaded' => count($tasks),
        ],
        'counts' => $counts,
        'verdict' => $verdict,
        'urls' => $results,
    ];

    if ($jsonOutput) {
        echo json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
        exit($exitCode);
    }

    echo "RECrawl CHECK — READ ONLY\n";
    echo "Job #{$jobId}: {$job['old_domain']} -> {$job['new_domain']}";
    echo " | {$job['stage']}/{$job['stage_status']}\n";
    echo "Webmaster: account #{$accountId}, user {$userId}, host {$hostId}\n";
    echo str_repeat('-', 118) . "\n";
    printf("%-5s %-9s %-12s %-6s %-13s %-36s %s\n",
        'ROW', 'ROLE', 'PANEL', 'HTTP', 'YANDEX', 'TASK_ID', 'URL');
    echo str_repeat('-', 118) . "\n";
    foreach ($results as $item) {
        $http = $item['panel_api_http'] !== null ? (string)$item['panel_api_http'] : '-';
        $task = (string)($item['yandex_task_id'] ?? $item['panel_task_id'] ?? '-');
        if (strlen($task) > 36) $task = substr($task, 0, 36);
        printf("%-5d %-9s %-12s %-6s %-13s %-36s %s\n",
            $item['row_id'], $item['role'], $item['panel_status'], $http,
            $item['yandex_state'], $task, $item['url']);
        if ($item['panel_error']) echo "      panel_error: {$item['panel_error']}\n";
        if ($item['direct_lookup_error']) echo "      task_lookup: {$item['direct_lookup_error']}\n";
    }
    echo str_repeat('-', 118) . "\n";
    echo "planned={$counts['planned']}; panel_accepted={$counts['panel_accepted']}; ";
    echo "yandex_found={$counts['yandex_found']}; in_progress={$counts['in_progress']}; ";
    echo "done={$counts['done']}; failed={$counts['failed']}; not_found={$counts['not_found']}\n";
    echo "VERDICT: {$verdict}\n";
    echo "No POST/UPDATE was executed.\n";
    exit($exitCode);
} catch (Throwable $e) {
    $error = [
        'read_only' => true,
        'job_id' => $jobId,
        'verdict' => 'CHECK_ERROR',
        'error' => $e->getMessage(),
    ];
    if ($jsonOutput) {
        echo json_encode($error, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    } else {
        fwrite(STDERR, "CHECK ERROR: {$e->getMessage()}\n");
        fwrite(STDERR, "No POST/UPDATE was executed.\n");
    }
    exit(20);
}

