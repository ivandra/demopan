<?php
/**
 * Временный одноразовый запуск backfill переездов через браузер — v2.
 *
 * Загрузить как:
 *   public/backfill_relocations_once.php
 *
 * После успешного выполнения удалить файл с хостинга.
 */

declare(strict_types=1);

const BACKFILL_ACCESS_KEY = 'nGB9t7V9ZqQfWq1nzc6k3C6urOsJSNqz';
const BACKFILL_RUN_CONFIRM = 'pBqA3BkUcH-5F8U0JVT7JAEKEFY';

header('Content-Type: text/html; charset=UTF-8');
header('X-Robots-Tag: noindex, nofollow, noarchive', true);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function bfFinish(string $title, string $body, int $status = 200): void
{
    http_response_code($status);
    $safeTitle = htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

    echo '<!doctype html><html lang="ru"><head><meta charset="utf-8">';
    echo '<meta name="robots" content="noindex,nofollow,noarchive">';
    echo '<title>' . $safeTitle . '</title>';
    echo '<style>
        body{font-family:Arial,sans-serif;max-width:1100px;margin:30px auto;padding:0 20px;background:#f6f7f9;color:#20242a}
        .box{background:#fff;border:1px solid #d9dde3;border-radius:10px;padding:22px;box-shadow:0 2px 10px rgba(0,0,0,.04)}
        pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#111827;color:#e5e7eb;padding:18px;border-radius:8px;line-height:1.45}
        .warn{background:#fff4d6;border:1px solid #e5b94f;padding:12px 14px;border-radius:7px;margin-bottom:16px}
        .ok{background:#e8f7e8;border:1px solid #71b971;padding:12px 14px;border-radius:7px;margin-bottom:16px}
        .error{background:#fde8e8;border:1px solid #d66;padding:12px 14px;border-radius:7px;margin-bottom:16px}
        code{background:#eef1f5;padding:2px 5px;border-radius:4px}
    </style></head><body><div class="box">';
    echo '<h1>' . $safeTitle . '</h1>' . $body;
    echo '</div></body></html>';
    exit;
}

/**
 * Подключаем CLI-скрипт внутри функции, чтобы его локальные переменные
 * не могли перезаписать переменные браузерной оболочки.
 */
function bfRunScript(string $scriptPath, bool $dryRun): string
{
    $args = [$scriptPath];
    if ($dryRun) {
        $args[] = '--dry-run';
    }

    $GLOBALS['argv'] = $args;
    $_SERVER['argv'] = $args;

    ob_start();
    try {
        require $scriptPath;
        return (string)ob_get_clean();
    } catch (Throwable $e) {
        $partial = ob_get_level() > 0 ? (string)ob_get_clean() : '';
        if ($partial !== '') {
            error_log('[backfill_once_v2 partial] ' . $partial);
        }
        throw $e;
    }
}

$accessKey = (string)($_GET['key'] ?? '');
if ($accessKey === '' || !hash_equals(BACKFILL_ACCESS_KEY, $accessKey)) {
    bfFinish('Доступ запрещён', '<p>Неверный или отсутствующий секретный ключ.</p>', 403);
}

$requestedMode = (string)($_GET['mode'] ?? 'dry-run');
if (!in_array($requestedMode, ['dry-run', 'run'], true)) {
    bfFinish('Некорректный режим', '<p>Допустимы только <code>dry-run</code> и <code>run</code>.</p>', 400);
}

$isDryRun = $requestedMode === 'dry-run';

if (!$isDryRun) {
    $confirmation = (string)($_GET['confirm'] ?? '');
    if ($confirmation === '' || !hash_equals(BACKFILL_RUN_CONFIRM, $confirmation)) {
        bfFinish(
            'Требуется подтверждение',
            '<div class="warn">Боевой запуск не выполнен: неверный код подтверждения.</div>',
            403
        );
    }
}

$panelRoot = dirname(__DIR__);
$backfillScript = $panelRoot . '/bin/backfill_relocations.php';

if (!is_file($backfillScript)) {
    bfFinish(
        'Файл backfill не найден',
        '<p>Не найден <code>' . htmlspecialchars($backfillScript, ENT_QUOTES, 'UTF-8') . '</code>. '
        . 'Сначала установите основной патч v22.3.</p>',
        500
    );
}

$doneMarker = $panelRoot . '/storage/backfill_relocations_once.done';

if (!$isDryRun && is_file($doneMarker) && (string)($_GET['force'] ?? '') !== '1') {
    $doneText = htmlspecialchars((string)@file_get_contents($doneMarker), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    bfFinish(
        'Backfill уже выполнялся',
        '<div class="warn">Найден маркер предыдущего боевого запуска:</div>'
        . '<pre>' . $doneText . '</pre>'
        . '<p>Повторный запуск обычно не нужен. Для осознанного повтора используется '
        . '<code>&amp;force=1</code>.</p>'
    );
}

try {
    $output = bfRunScript($backfillScript, $isDryRun);

    // Не доверяем только параметру URL: сверяем фактический режим по выводу CLI-скрипта.
    $actualDryRun = strpos($output, 'РЕЖИМ: --dry-run') !== false
        && strpos($output, 'Записи в БД не создавались') !== false;
    $actualRun = strpos($output, 'РЕЖИМ: боевой') !== false
        && strpos($output, 'Готово. Записи созданы') !== false;

    if ($isDryRun && !$actualDryRun) {
        bfFinish(
            'Ошибка контроля режима',
            '<div class="error"><strong>Запрошен dry-run, но вывод скрипта не подтверждает dry-run.</strong></div>'
            . '<pre>' . htmlspecialchars($output, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</pre>',
            500
        );
    }

    if (!$isDryRun && !$actualRun) {
        bfFinish(
            'Боевой backfill не подтверждён',
            '<div class="error"><strong>Скрипт не подтвердил запись в БД. Маркер выполнения не создан.</strong></div>'
            . '<pre>' . htmlspecialchars($output, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</pre>',
            500
        );
    }

    if (!$isDryRun) {
        $marker = "Выполнено: " . gmdate('Y-m-d H:i:s') . " UTC\n"
            . "IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . "\n";
        if (@file_put_contents($doneMarker, $marker, LOCK_EX) === false) {
            bfFinish(
                'Backfill выполнен, но маркер не создан',
                '<div class="warn"><strong>Записи созданы, однако не удалось записать защитный маркер.</strong></div>'
                . '<pre>' . htmlspecialchars($output, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</pre>'
                . '<p>Не запускайте URL повторно и сразу удалите временный PHP-файл.</p>',
                500
            );
        }
    }

    $notice = $isDryRun
        ? '<div class="ok"><strong>Dry-run завершён.</strong> Записи в БД не создавались.</div>'
        : '<div class="ok"><strong>Боевой backfill действительно выполнен.</strong></div>';

    bfFinish(
        $isDryRun ? 'Backfill переездов — dry-run' : 'Backfill переездов — выполнение',
        $notice
        . '<pre>' . htmlspecialchars($output, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</pre>'
        . '<div class="warn"><strong>После завершения удалите '
        . '<code>public/backfill_relocations_once.php</code> с хостинга.</strong></div>'
    );
} catch (Throwable $e) {
    error_log('[backfill_once_v2] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());

    bfFinish(
        'Ошибка backfill',
        '<div class="error"><strong>Backfill завершился ошибкой.</strong></div>'
        . '<pre>' . htmlspecialchars($e->getMessage(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</pre>',
        500
    );
}
