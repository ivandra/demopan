(function () {
    'use strict';

    // §3.11 client-side: строгая проверка IPv4 (каждый октет 0-255).
    window.__rpIsIpv4 = function (ip) {
        if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ip)) return false;
        return ip.split('.').every(function (o) { var n = parseInt(o, 10); return o === String(n) && n >= 0 && n <= 255; });
    };

    // Кнопка "Тест" на странице серверов FastPanel (ТЗ 040 §4.5: POST + CSRF)
    document.addEventListener('click', function (ev) {
        var btn = ev.target.closest('[data-test-server]');
        if (!btn) return;
        ev.preventDefault();

        var id = btn.getAttribute('data-test-server');
        var csrf = btn.getAttribute('data-csrf') || '';
        var out = document.querySelector('[data-test-result="' + id + '"]');
        var orig = btn.textContent;
        btn.textContent = '\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430\u2026'; // «Проверка…»
        btn.disabled = true;
        if (out) { out.textContent = ''; out.className = 'test-result'; }

        var body = new URLSearchParams({ id: id, csrf_token: csrf });
        // ТЗ 042 §6.1: не вызывать r.json() вслепую. Читаем текст, проверяем
        // content-type и redirect; при не-JSON показываем реальную причину ошибки, а не общую заглушку.
        fetch('/servers/test-connection', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body
        })
            .then(function (response) {
                return response.text().then(function (text) {
                    var contentType = (response.headers.get('content-type') || '').toLowerCase();
                    if (response.redirected || /\/login(?:\?|$)/.test(response.url || '')) {
                        throw new Error('\u0421\u0435\u0441\u0441\u0438\u044f \u0438\u0441\u0442\u0435\u043a\u043b\u0430. \u041e\u0431\u043d\u043e\u0432\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043d\u0438\u0446\u0443 \u0438 \u0432\u043e\u0439\u0434\u0438\u0442\u0435 \u0441\u043d\u043e\u0432\u0430.');
                    }
                    var data = null;
                    if (contentType.indexOf('application/json') !== -1) {
                        try { data = JSON.parse(text); }
                        catch (e) { throw new Error('HTTP ' + response.status + ': \u0441\u0435\u0440\u0432\u0435\u0440 \u0432\u0435\u0440\u043d\u0443\u043b \u043f\u043e\u0432\u0440\u0435\u0436\u0434\u0451\u043d\u043d\u044b\u0439 JSON.'); }
                    } else {
                        throw new Error('HTTP ' + response.status + ': \u0441\u0435\u0440\u0432\u0435\u0440 \u0432\u0435\u0440\u043d\u0443\u043b \u043e\u0442\u0432\u0435\u0442 \u043d\u0435 \u0432 \u0444\u043e\u0440\u043c\u0430\u0442\u0435 JSON. \u041f\u043e\u0434\u0440\u043e\u0431\u043d\u043e\u0441\u0442\u0438 \u0437\u0430\u043f\u0438\u0441\u0430\u043d\u044b \u0432 \u0436\u0443\u0440\u043d\u0430\u043b.');
                    }
                    if (!response.ok || !data || data.ok !== true) {
                        throw new Error(data && data.error ? data.error : ('HTTP ' + response.status));
                    }
                    return data;
                });
            })
            .then(function (j) {
                var msg = 'OK \u00b7 ' + (j.authenticated_user || '?') + ' \u00b7 sites: ' + (j.sites_count != null ? j.sites_count : '?')
                        + ' \u00b7 ' + (j.duration_ms != null ? j.duration_ms + 'ms' : '');
                if (out) { out.textContent = '\u2705 ' + msg; out.classList.add('test-ok'); }
                else alert('\u2705 ' + msg);
            })
            .catch(function (e) { if (out) { out.textContent = '\u274c ' + e.message; out.classList.add('test-fail'); } else alert('\u274c ' + e.message); })
            .finally(function () { btn.textContent = orig; btn.disabled = false; });
    });

    // ТЗ 040: live-preview бейджа + allowlist-подсказка
    function relLum(hex) {
        hex = (hex || '').replace('#', '');
        if (hex.length !== 6) return 1;
        var r = parseInt(hex.slice(0,2),16), g = parseInt(hex.slice(2,4),16), b = parseInt(hex.slice(4,6),16);
        return (0.2126*r + 0.7152*g + 0.0722*b) / 255;
    }
    function isHex(v) { return /^#[0-9A-Fa-f]{6}$/.test(v || ''); }
    function updateBadgePreview() {
        var prev = document.querySelector('[data-badge-preview]');
        if (!prev) return;
        // ТЗ 042 §7.2: пустой код → «не задан», без ложного «F».
        var codeInput = document.getElementById('ui_badge_code');
        var code = codeInput ? String(codeInput.value || '').trim() : '';
        if (code === '') {
            prev.textContent = '\u043d\u0435 \u0437\u0430\u0434\u0430\u043d'; // «не задан»
            prev.removeAttribute('style');
            prev.classList.add('server-badge--empty');
            return;
        }
        prev.classList.remove('server-badge--empty');
        var color = (document.getElementById('ui_badge_color') || {}).value || '#A855F7';
        if (!isHex(color)) color = '#6B7280';
        prev.textContent = code;
        prev.style.background = color;
        prev.style.color = relLum(color) > 0.6 ? '#000000' : '#ffffff';
    }
    function updateAllowlist() {
        var box = document.querySelector('[data-allowlist-preview]');
        if (!box) return;
        var hostEl = document.querySelector('input[name="host"]');
        var extraEl = document.getElementById('extra_ips');
        var ips = [];
                var host = (hostEl && hostEl.value || '').replace(/^https?:\/\//i, '').replace(/\/.*$/, '').replace(/:\d+$/, '');
        if (window.__rpIsIpv4(host)) ips.push(host);
        ((extraEl && extraEl.value || '').split(/[,;\s]+/)).forEach(function (v) { v = v.trim(); if (window.__rpIsIpv4(v) && ips.indexOf(v) < 0) ips.push(v); });
        box.textContent = 'Allowlist: ' + (ips.length ? ips.join(', ') : '(\u043f\u0443\u0441\u0442\u043e)');
    }
    document.addEventListener('input', function (e) {
        if (e.target.closest('#server-form')) { updateBadgePreview(); updateAllowlist(); }
    });
    document.addEventListener('DOMContentLoaded', function () { updateBadgePreview(); updateAllowlist(); });
})();

/* ==================== v25.1-b: SSL-вкладка ==================== */
(function () {
    function post(url, data) {
        var body = new URLSearchParams(data || {});
        body.append('ajax', '1');
        return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body })
            .then(function (r) { return r.json().then(function (j) { if (!r.ok || j.ok === false) throw new Error(j.error || ('HTTP ' + r.status)); return j; }); });
    }

    // Проверить один домен
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.ssl-check-one');
        if (!btn) return;
        e.preventDefault();
        var domain = btn.getAttribute('data-domain');
        var orig = btn.textContent;
        btn.textContent = 'Проверка…'; btn.disabled = true;
        post('/ssl/check', { domain: domain })
            .then(function () {
                if (btn.getAttribute('data-reload')) { location.reload(); return; }
                location.reload();
            })
            .catch(function (err) { alert('❌ ' + err.message); btn.textContent = orig; btn.disabled = false; });
    });

    // Проверить все → batch + polling
    var checkAllBtn = document.getElementById('ssl-check-all');
    var stopBtn = document.getElementById('ssl-stop-batch');
    var progWrap = document.getElementById('ssl-batch-progress');
    var progFill = document.getElementById('ssl-progress-fill');
    var progStats = document.getElementById('ssl-progress-stats');
    var pollTimer = null;

    function renderBatch(b) {
        if (!b) { if (progWrap) progWrap.style.display = 'none'; if (stopBtn) stopBtn.style.display = 'none'; return; }
        if (progWrap) { progWrap.style.display = ''; progWrap.setAttribute('data-batch-id', b.id); }
        var pct = b.total > 0 ? Math.round((b.done / b.total) * 100) : 0;
        if (progFill) progFill.style.width = pct + '%';
        if (progStats) progStats.textContent =
            'Всего ' + b.total + ' · В очереди ' + b.queued + ' · Проверяется ' + b.checking +
            ' · Проверено ' + b.done + ' · Успешно ' + b.ok_count + ' · Предупреждение ' + b.warn_count + ' · Ошибок ' + b.error_count;
        var active = (b.status === 'running');
        if (stopBtn) stopBtn.style.display = active ? '' : 'none';
        if (!active && pollTimer) { clearInterval(pollTimer); pollTimer = null; setTimeout(function () { location.reload(); }, 1200); }
    }

    function startPolling(batchId) {
        if (pollTimer) clearInterval(pollTimer);
        pollTimer = setInterval(function () {
            post('/ssl/batch-progress', { batch_id: batchId || '' })
                .then(function (j) { renderBatch(j.batch); })
                .catch(function () {});
        }, 2500);
    }

    if (checkAllBtn) {
        checkAllBtn.addEventListener('click', function () {
            checkAllBtn.disabled = true;
            post('/ssl/check-all', {})
                .then(function (j) { renderBatch(j.batch); startPolling(j.batch ? j.batch.id : ''); })
                .catch(function (err) { alert('❌ ' + err.message); })
                .finally(function () { checkAllBtn.disabled = false; });
        });
    }
    if (stopBtn) {
        stopBtn.addEventListener('click', function () {
            var bid = progWrap ? progWrap.getAttribute('data-batch-id') : '';
            post('/ssl/batch-stop', { batch_id: bid })
                .then(function () { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } location.reload(); })
                .catch(function (err) { alert('❌ ' + err.message); });
        });
    }
    // авто-возобновление polling, если batch уже идёт при загрузке
    if (progWrap && progWrap.style.display !== 'none') {
        var bid = progWrap.getAttribute('data-batch-id');
        if (bid) startPolling(bid);
    }
})();

/* ==================== v25.1-b1: SSL архив/добавление ==================== */
(function () {
    function postForm(url, data) {
        var body = new URLSearchParams(data || {}); body.append('ajax', '1');
        return fetch(url, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:body })
            .then(function(r){ return r.json().then(function(j){ if(!r.ok||j.ok===false) throw new Error(j.error||('HTTP '+r.status)); return j; }); });
    }
    document.addEventListener('click', function (e) {
        var arch = e.target.closest('.ssl-archive');
        var unarch = e.target.closest('.ssl-unarchive');
        var rem = e.target.closest('.ssl-remove');
        if (arch) { e.preventDefault(); postForm('/ssl/archive', { domain: arch.getAttribute('data-domain') }).then(function(){ location.reload(); }).catch(function(err){ alert('❌ '+err.message); }); }
        if (unarch) { e.preventDefault(); postForm('/ssl/unarchive', { domain: unarch.getAttribute('data-domain') }).then(function(){ location.reload(); }).catch(function(err){ alert('❌ '+err.message); }); }
        if (rem) {
            e.preventDefault();
            var dom = rem.getAttribute('data-domain');
            if (!confirm('Удалить домен ' + dom + ' из списка?\n\nЗапись мониторинга будет удалена. История проверок сохранится.')) return;
            var withHist = confirm('Удалить также ИСТОРИЮ проверок этого домена?\n\nОК — удалить историю. Отмена — сохранить историю.');
            postForm('/ssl/remove', { domain: dom, with_history: withHist ? '1' : '' }).then(function(){ location.reload(); }).catch(function(err){ alert('❌ '+err.message); });
        }
    });
    var addBtn = document.getElementById('ssl-add-domain-btn');
    var addForm = document.getElementById('ssl-add-domain-form');
    if (addBtn && addForm) {
        addBtn.addEventListener('click', function () {
            addForm.style.display = (addForm.style.display === 'none' || !addForm.style.display) ? 'block' : 'none';
        });
    }
})();
