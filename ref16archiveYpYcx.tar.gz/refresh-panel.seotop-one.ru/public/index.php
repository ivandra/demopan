<?php
/**
 * Refresh Panel - точка входа.
 *
 * Все запросы веб-сервер должен направлять сюда (см. .htaccess).
 */

// ==== Bootstrap ====
define('APP_ROOT', dirname(__DIR__));
define('STORAGE_ROOT', APP_ROOT . '/storage');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', STORAGE_ROOT . '/logs/php_errors.log');
error_reporting(E_ALL);

mb_internal_encoding('UTF-8');
date_default_timezone_set('UTC');

// ==== Loader ====
require APP_ROOT . '/app/Core/Paths.php';

Paths::ensureStorageTree();

// Сессии в storage/sessions
@ini_set('session.save_path', Paths::storage('sessions'));
@ini_set('session.cookie_httponly', '1');
@ini_set('session.use_strict_mode', '1');
@ini_set('session.gc_maxlifetime', '86400');

// ==== Config helper ====
$__APP_CONFIG = require APP_ROOT . '/config/app.php';

if (!function_exists('config')) {
    function config(string $path, $default = null)
    {
        global $__APP_CONFIG;
        $parts = explode('.', $path);
        $cur = $__APP_CONFIG;
        foreach ($parts as $p) {
            if (is_array($cur) && array_key_exists($p, $cur)) {
                $cur = $cur[$p];
            } else {
                return $default;
            }
        }
        return $cur;
    }
}

// ==== Class autoload (manual) ====
spl_autoload_register(function ($class) {
    $candidates = [
        APP_ROOT . '/app/Core/' . $class . '.php',
        APP_ROOT . '/app/Services/' . $class . '.php',
        APP_ROOT . '/app/Services/IndexCheck/' . $class . '.php',  // v17.2
        APP_ROOT . '/app/Services/BanMonitoring/' . $class . '.php',
        APP_ROOT . '/app/Services/Readiness/' . $class . '.php',  // v25.0-a
        APP_ROOT . '/app/Controllers/' . $class . '.php',
    ];
    foreach ($candidates as $f) {
        if (is_file($f)) { require $f; return; }
    }
});

// ==== Error / exception handlers ====
set_exception_handler(function (Throwable $e) {
    @error_log('[uncaught] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine() . "\n" . $e->getTraceAsString());

    if (php_sapi_name() === 'cli') {
        echo "FATAL: " . $e->getMessage() . "\n";
        echo $e->getTraceAsString() . "\n";
        exit(1);
    }

    http_response_code(500);
    if (config('env') === 'dev') {
        echo '<pre style="background:#1c2030;color:#f08585;padding:20px;border-radius:8px;font-family:monospace;">';
        echo htmlspecialchars($e->getMessage()) . "\n\n";
        echo htmlspecialchars($e->getFile() . ':' . $e->getLine()) . "\n\n";
        echo htmlspecialchars($e->getTraceAsString());
        echo '</pre>';
    } else {
        echo '<h1>500</h1><p>Внутренняя ошибка. Подробности в storage/logs/php_errors.log</p>';
    }
});

// ==== Install detection ====
// Если БД недоступна или основные таблицы ещё не созданы — все запросы
// (кроме /install и статики) перенаправляем на страницу установки.
$__needsInstall = false;
try {
    DB::pdo()->query("SELECT 1 FROM sites_managed LIMIT 1");
} catch (Throwable $e) {
    $msg = $e->getMessage();
    // Таблица не существует
    if (stripos($msg, "doesn't exist") !== false ||
        stripos($msg, "Base table or view not found") !== false ||
        stripos($msg, "1146") !== false) {
        $__needsInstall = true;
    }
    // Нет соединения с БД — тоже показываем install (там будет видно ошибку)
    elseif (stripos($msg, 'SQLSTATE') !== false ||
            stripos($msg, 'Access denied') !== false ||
            stripos($msg, 'Unknown database') !== false ||
            stripos($msg, 'Connection refused') !== false ||
            stripos($msg, 'No such file or directory') !== false ||
            stripos($msg, 'getaddrinfo') !== false ||
            stripos($msg, 'DB config missing') !== false) {
        $__needsInstall = true;
    }
}

$__currentUri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$__allowedDuringInstall = ['/install', '/install/run', '/login', '/logout', '/assets'];
$__isAllowed = false;
foreach ($__allowedDuringInstall as $p) {
    if ($__currentUri === $p || strpos($__currentUri, $p . '/') === 0) {
        $__isAllowed = true; break;
    }
}
if ($__needsInstall && !$__isAllowed) {
    header('Location: /install', true, 302);
    exit;
}

// ==== Router ====
$router = new Router();

// Install
$router->get('/install',     function () { (new InstallController())->show(); });
$router->post('/install/run', function () { (new InstallController())->run(); });

// Auth
$router->get('/login',  function () { (new AuthController())->loginForm(); });
$router->post('/login', function () { (new AuthController())->login(); });
$router->get('/logout', function () { (new AuthController())->logout(); });

// Sites (главная)
$router->get('/',                         function () { (new SitesController())->index(); });
$router->get('/sites',                    function () { (new SitesController())->index(); });
$router->get('/sites/import',             function () { (new SitesController())->importForm(); });
$router->post('/sites/import/refresh-cache', function () { (new SitesController())->importRefreshCache(); });
$router->post('/sites/mask',           function () { (new SitesController())->saveMask(); });
$router->post('/sites/save-webmaster-account', function () { (new SitesController())->saveWebmasterAccount(); });
$router->get('/sites/import/preview',     function () { (new SitesController())->importPreview(); });
$router->post('/sites/import/do',         function () { (new SitesController())->importDo(); });
$router->get('/sites/show',               function () { (new SitesController())->show(); });
$router->get('/sites/edit',               function () { (new SitesController())->editForm(); });
$router->post('/sites/update',            function () { (new SitesController())->update(); });
$router->post('/sites/toggle-redirect-enabled', function () { (new SitesController())->toggleRedirectEnabled(); });
$router->post('/sites/toggle-ssl-le-enabled',    function () { (new SitesController())->toggleSslLeEnabled(); });
$router->post('/sites/toggle-autopatch-robots',  function () { (new SitesController())->toggleAutopatchRobots(); });
$router->post('/sites/save-update-classes-url', function () { (new SitesController())->saveUpdateClassesUrl(); });
$router->post('/sites/check-randomization',    function () { (new SitesController())->checkRandomization(); });
$router->post('/sites/set-uc-mode',            function () { (new SitesController())->setUcMode(); });
$router->post('/sites/save-multisite-subroot', function () { (new SitesController())->saveMultisiteSubroot(); });
$router->post('/sites/delete',            function () { (new SitesController())->delete(); });
$router->post('/sites/sync-config',       function () { (new SitesController())->syncConfig(); });
$router->post('/sites/create-ftp',        function () { (new SitesController())->createFtp(); });
$router->post('/sites/clear-import-log',  function () { (new SitesController())->clearImportLog(); });
$router->post('/sites/refresh-from-fp',   function () { (new SitesController())->refreshFromFastpanel(); });
$router->get('/sites/diagnose',           function () { (new SitesController())->diagnose(); });
$router->get('/sites/create-manual',      function () { (new SitesController())->createManualForm(); });
$router->post('/sites/create-manual',     function () { (new SitesController())->createManualDo(); });

// --- Джобы перевыставления (Этап 2+) ---
$router->get('/jobs',                  function () { (new RefreshJobController())->index(); });

// v25.1-b: раздел «SSL» — мониторинг доступности и сертификатов
$router->get('/ssl',                   function () { (new SslController())->index(); });
$router->get('/ssl/show',              function () { (new SslController())->show(); });
$router->post('/ssl/check',            function () { (new SslController())->check(); });
$router->post('/ssl/check-all',        function () { (new SslController())->checkAll(); });
$router->post('/ssl/batch-progress',   function () { (new SslController())->batchProgress(); });
$router->post('/ssl/batch-stop',       function () { (new SslController())->batchStop(); });
$router->post('/ssl/add-domain',       function () { (new SslController())->addDomain(); });
$router->post('/ssl/archive',          function () { (new SslController())->archive(); });
$router->post('/ssl/unarchive',        function () { (new SslController())->unarchive(); });
$router->post('/ssl/remove',           function () { (new SslController())->remove(); });

// v22: раздел «Переезды» (только move_indexed / move_simple)
$router->get('/relocations',            function () { (new RelocationController())->index(); });
$router->get('/relocations/show',       function () { (new RelocationController())->show(); });
$router->post('/relocations/planned-at',function () { (new RelocationController())->savePlannedAt(); });
$router->post('/relocations/check-now', function () { (new RelocationController())->checkNow(); });
$router->post('/relocations/cancel',    function () { (new RelocationController())->cancel(); });
$router->get('/jobs/show',             function () { (new RefreshJobController())->show(); });

// v24: терминальные состояния джоб — конфликт, замена, отмена
$router->get('/jobs/conflict',         function () { (new RefreshJobController())->conflict(); });
$router->post('/jobs/supersede',       function () { (new RefreshJobController())->supersede(); });
$router->post('/jobs/close',           function () { (new RefreshJobController())->cancelJob(); });
$router->post('/jobs/start',           function () { (new RefreshJobController())->start(); });
$router->post('/jobs/cancel',          function () { (new RefreshJobController())->cancel(); });
$router->post('/jobs/retry',           function () { (new RefreshJobController())->retry(); });
$router->post('/jobs/readiness-check-now',        function () { (new RefreshJobController())->readinessCheckNow(); });
$router->post('/jobs/readiness-continue-waiting', function () { (new RefreshJobController())->readinessContinueWaiting(); });
$router->post('/jobs/wm-host-check-now',        function () { (new RefreshJobController())->wmHostCheckNow(); });
$router->post('/jobs/wm-host-continue-waiting', function () { (new RefreshJobController())->wmHostContinueWaiting(); });
$router->post('/jobs/wm-host-manual-confirm',   function () { (new RefreshJobController())->wmHostManualConfirm(); });
$router->post('/jobs/run-step',        function () { (new RefreshJobController())->runStep(); });
$router->post('/jobs/delete',          function () { (new RefreshJobController())->delete(); });
$router->post('/jobs/approve-continue',function () { (new RefreshJobController())->approveContinue(); });
$router->post('/jobs/recover',          function () { (new RefreshJobController())->recoverJob(); });
$router->post('/jobs/uc-verify-manual', function () { (new RefreshJobController())->verifyUniquificationManual(); });
$router->post('/jobs/uc-skip',          function () { (new RefreshJobController())->skipUpdateClasses(); });
$router->post('/jobs/uc-disable-site',  function () { (new RefreshJobController())->disableRandomizationForSite(); });
$router->post('/jobs/skip-stage',      function () { (new RefreshJobController())->skipStage(); });
$router->post('/jobs/rebuild-plan',     function () { (new RefreshJobController())->rebuildPlan(); });
$router->post('/jobs/retry-self-signed',function () { (new RefreshJobController())->retrySelfSigned(); });
$router->post('/jobs/retry-verify',     function () { (new RefreshJobController())->retryVerify(); });
$router->post('/jobs/retry-ssl',        function () { (new RefreshJobController())->retrySsl(); });
$router->post('/jobs/retry-index',      function () { (new RefreshJobController())->retryIndexWatching(); });
// v18.1.21: перезапуск мониторинга переезда (move_poll_status) — deprecated, проксируется
$router->post('/jobs/retry-move-polling', function () { (new RefreshJobController())->retryMovePolling(); });
// v18.1.23: перезапуск финального мониторинга (final_monitoring) — основная кнопка для move-джоб
$router->post('/jobs/retry-final-monitoring', function () { (new RefreshJobController())->retryFinalMonitoring(); });
$router->post('/jobs/rollback',        function () { (new RefreshJobController())->rollback(); });
// v18.1.17: ручное завершение move-джобы (когда move_poll_status не может проверить статус)
$router->post('/jobs/mark-done',       function () { (new RefreshJobController())->markDone(); });
$router->post('/jobs/manual-complete', function () { (new RefreshJobController())->manualComplete(); }); // HOTFIX manual completion
// v18.1.19: ручное подтверждение редиректа (когда smoke с панели не доходит, но оператор проверил в браузере)
$router->post('/jobs/confirm-redirect-manually', function () { (new RefreshJobController())->confirmRedirectManually(); });
$router->get('/jobs/download-snapshots', function () { (new RefreshJobController())->downloadSnapshots(); });
$router->post('/jobs/set-webmaster-override', function () { (new RefreshJobController())->setWebmasterOverride(); });
// v25.2-a1.3: гибридный ручной контур SSL / Webmaster (фон не отключается)
$router->post('/jobs/ssl-verify-installed', function () { (new RefreshJobController())->sslVerifyInstalled(); });
$router->post('/jobs/ssl-resume-auto',      function () { (new RefreshJobController())->sslResumeAuto(); });
$router->post('/jobs/ssl-check-now',        function () { (new RefreshJobController())->sslCheckNow(); });
$router->post('/jobs/ssl-skip',             function () { (new RefreshJobController())->sslSkip(); });
$router->post('/jobs/wm-verify-manual',     function () { (new RefreshJobController())->wmVerifyManual(); });
$router->post('/jobs/wm-verified-check-now',function () { (new RefreshJobController())->wmVerifiedCheckNow(); });
$router->post('/jobs/wm-verified-skip',     function () { (new RefreshJobController())->wmVerifiedSkip(); });
// v18: подтверждения для новых awaiting_user стадий
$router->post('/jobs/acknowledge-move',   function () { (new RefreshJobController())->acknowledgeMove(); });
$router->post('/jobs/acknowledge-delurl', function () { (new RefreshJobController())->acknowledgeDelurl(); });

// --- Cron-эндпоинт ---
$router->get('/cron',                  function () { (new CronController())->run(); });
$router->get('/cron/ssl',              function () { (new CronController())->runSsl(); });

// FastPanel servers
$router->get('/servers',          function () { (new FastpanelServerController())->index(); });
$router->get('/servers/create',   function () { (new FastpanelServerController())->createForm(); });
$router->post('/servers/create',  function () { (new FastpanelServerController())->store(); });
$router->get('/servers/edit',     function () { (new FastpanelServerController())->editForm(); });
$router->post('/servers/edit',    function () { (new FastpanelServerController())->update(); });
$router->post('/servers/delete',  function () { (new FastpanelServerController())->delete(); });
$router->post('/servers/test-connection', function () { (new FastpanelServerController())->testConnection(); });

// Registrar
$router->get('/registrar/accounts',         function () { (new RegistrarAccountsController())->index(); });
$router->get('/registrar/accounts/create',  function () { (new RegistrarAccountsController())->createForm(); });
$router->post('/registrar/accounts/create', function () { (new RegistrarAccountsController())->store(); });
$router->post('/registrar/accounts/delete', function () { (new RegistrarAccountsController())->delete(); });

$router->get('/registrar/contacts',         function () { (new RegistrarContactsController())->index(); });
$router->get('/registrar/contacts/create',  function () { (new RegistrarContactsController())->createForm(); });
$router->post('/registrar/contacts/create', function () { (new RegistrarContactsController())->store(); });
$router->post('/registrar/contacts/delete', function () { (new RegistrarContactsController())->delete(); });

// Settings
$router->get('/settings',                function () { (new SettingsController())->index(); });
$router->post('/settings/migrate',       function () { (new SettingsController())->migrate(); });
$router->post('/settings/telegram',      function () { (new SettingsController())->saveTelegram(); });
$router->get('/settings/telegram-test',  function () { (new SettingsController())->testTelegram(); });
$router->post('/settings/sandbox-mode',  function () { (new SettingsController())->saveSandboxMode(); });
$router->post('/settings/xmlstock',      function () { (new SettingsController())->saveXmlstock(); });
$router->post('/settings/xmlstock-test', function () { (new SettingsController())->testXmlstock(); });
// v18.1.28: пороги балансов для алертов
$router->post('/settings/balance-thresholds', function () { (new SettingsController())->saveBalanceThresholds(); });
// v18.1.29: настройки cron (max_jobs_per_tick)
$router->post('/settings/cron', function () { (new SettingsController())->saveCronSettings(); });
$router->post('/settings/ssl', function () { (new SettingsController())->saveSslSettings(); });
$router->post('/settings/jobs', function () { (new SettingsController())->saveJobsSettings(); });
// v18.1.31: настройки поиска доменов
$router->post('/settings/domain-search', function () { (new SettingsController())->saveDomainSearchSettings(); });
$router->post('/settings/mask',          function () { (new SettingsController())->saveMaskSettings(); });

// v18.1.37: XMLStock — страница контроля расхода lim + пауза/стоп-кран
$router->get( '/xmlstock',                function () { (new XmlStockController())->index(); });
$router->post('/xmlstock/toggle-enabled', function () { (new XmlStockController())->toggleEnabled(); });
$router->post('/xmlstock/pause-job',      function () { (new XmlStockController())->pauseJob(); });
$router->post('/xmlstock/resume-job',     function () { (new XmlStockController())->resumeJob(); });
$router->post('/xmlstock/pause-all',      function () { (new XmlStockController())->pauseAll(); });
$router->post('/xmlstock/resume-all',     function () { (new XmlStockController())->resumeAll(); });
$router->post('/xmlstock/monitor/check-now', function () { (new XmlStockController())->banMonitorCheckNow(); });
$router->post('/xmlstock/monitor/pause',     function () { (new XmlStockController())->banMonitorPause(); });
$router->post('/xmlstock/monitor/resume',    function () { (new XmlStockController())->banMonitorResume(); });
$router->post('/xmlstock/monitor/stop',      function () { (new XmlStockController())->banMonitorStop(); });
$router->post('/xmlstock/ban-monitoring/activate-new-jobs',   function () { (new XmlStockController())->banActivateNewJobs(); });
$router->post('/xmlstock/ban-monitoring/deactivate-new-jobs', function () { (new XmlStockController())->banDeactivateNewJobs(); });
$router->post('/xmlstock/ban-monitoring/toggle-processing',   function () { (new XmlStockController())->banToggleProcessing(); });
$router->post('/xmlstock/ban-monitoring/save-policy',         function () { (new XmlStockController())->banSavePolicy(); });
$router->post('/xmlstock/ban-monitoring/bootstrap-jobs',      function () { (new XmlStockController())->banBootstrapJobs(); });

// System diagnose
$router->get('/system/diagnose',         function () { (new SystemDiagnoseController())->index(); });
// v18.1.20: ручной запуск cron из UI диагностики
$router->post('/system/run-cron',        function () { (new SystemDiagnoseController())->runCron(); });
// v18.1.28: ручное обновление балансов Namecheap + XMLStock
$router->post('/system/balance/refresh', function () { (new SystemDiagnoseController())->refreshBalances(); });

// Yandex Webmaster tokens (v14e — подготовка к v15)
$router->get( '/system/webmaster-tokens',         function () { (new WebmasterTokenController())->index(); });
$router->post('/system/webmaster-tokens/check',   function () { (new WebmasterTokenController())->check(); });
$router->post('/system/webmaster-tokens/save',    function () { (new WebmasterTokenController())->save(); });
$router->post('/system/webmaster-tokens/delete',  function () { (new WebmasterTokenController())->delete(); });
$router->post('/system/webmaster-tokens/recheck', function () { (new WebmasterTokenController())->recheck(); });
// PATCH 047 — управление исходящими IP + маршрутизация Webmaster.
$router->post('/system/webmaster-tokens/ip-add',        function () { (new WebmasterTokenController())->ipAdd(); });
$router->post('/system/webmaster-tokens/ip-toggle',     function () { (new WebmasterTokenController())->ipToggle(); });
$router->post('/system/webmaster-tokens/ip-set-default',function () { (new WebmasterTokenController())->ipSetDefault(); });
$router->post('/system/webmaster-tokens/ip-delete',     function () { (new WebmasterTokenController())->ipDelete(); });
$router->post('/system/webmaster-tokens/ip-probe',      function () { (new WebmasterTokenController())->ipProbe(); });
$router->post('/system/webmaster-tokens/assign-ip',     function () { (new WebmasterTokenController())->assignIp(); });
$router->post('/system/webmaster-tokens/bulk-assign',   function () { (new WebmasterTokenController())->bulkAssign(); });
$router->post('/system/webmaster-tokens/account-check', function () { (new WebmasterTokenController())->accountCheck(); });
$router->post('/system/webmaster-tokens/check-all',     function () { (new WebmasterTokenController())->checkAllAccounts(); });
$router->post('/system/webmaster-tokens/routing-check', function () { (new WebmasterTokenController())->routingCheck(); });
$router->get( '/system/webmaster-tokens/audit',         function () { (new WebmasterTokenController())->auditLog(); });



// ========== API v1 (для внешних потребителей — Casino Panel и т.п.) ==========
// Эти routes НЕ требуют сессии — Bearer-токен в заголовке Authorization.

$router->get( '/api/v1/me',                       function () { (new ApiV1Controller())->me(); });
$router->get( '/api/v1/webmaster/accounts',       function () { (new ApiV1Controller())->webmasterAccounts(); });
$router->get( '/api/v1/registrar/accounts',       function () { (new ApiV1Controller())->registrarAccounts(); });
$router->get( '/api/v1/registrar/contacts',       function () { (new ApiV1Controller())->registrarContacts(); });
$router->get( '/api/v1/fastpanel/servers',        function () { (new ApiV1Controller())->fastpanelServers(); });
$router->get( '/api/v1/server/site-ip',           function () { (new ApiV1Controller())->serverSiteIp(); });
$router->get( '/api/v1/app-settings/domain',      function () { (new ApiV1Controller())->appSettingsDomain(); });

// Параметризованные routes — Router в refresh-panel не парсит {id} из path,
// поэтому id передаём через query (?id=...) или через свой dispatcher.
// Альтернатива: добавить простой regex-роутер. См. ниже два варианта:

// ВАРИАНТ A: через query-параметр (проще, но менее RESTful)
$router->get( '/api/v1/webmaster/credentials',    function () {
    $id = (int)($_GET['id'] ?? 0);
    (new ApiV1Controller())->webmasterCredentials($id);
});
$router->post('/api/v1/webmaster/test-token',     function () {
    $id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
    (new ApiV1Controller())->webmasterTestToken($id);
});
$router->get( '/api/v1/registrar/credentials',    function () {
    $id = (int)($_GET['id'] ?? 0);
    (new ApiV1Controller())->registrarCredentials($id);
});
$router->post('/api/v1/fastpanel/jwt',            function () {
    $id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
    (new ApiV1Controller())->fastpanelJwt($id);
});
$router->get( '/api/v1/fastpanel/find-vhost',     function () { (new ApiV1Controller())->fastpanelFindVhost(); });    // ← НОВАЯ СТРОКА
$router->get( '/api/v1/server/site-ip',           function () { (new ApiV1Controller())->serverSiteIp(); });

// ========== Admin UI для API-ключей ==========
$router->get( '/api-clients',          function () { (new ApiClientController())->index(); });
$router->post('/api-clients/create',   function () { (new ApiClientController())->create(); });
$router->post('/api-clients/revoke',   function () { (new ApiClientController())->revoke(); });
$router->post('/api-clients/unrevoke', function () { (new ApiClientController())->unrevoke(); });
$router->get( '/api-clients/test',     function () { (new ApiClientController())->test(); });

// ========== API v1 — Casino projects (B1) ==========
$router->post('/api/v1/casino/projects/register', function () { (new CasinoApiController())->register(); });
$router->get( '/api/v1/casino/projects',          function () { (new CasinoApiController())->list(); });
$router->get( '/api/v1/casino/projects/show',     function () { (new CasinoApiController())->show(); });

// ========== Admin UI — Casino (B1) ==========
$router->get( '/casino',          function () { (new CasinoController())->index(); });
$router->get( '/casino/show',     function () { (new CasinoController())->show(); });
$router->post('/casino/delete',   function () { (new CasinoController())->delete(); });

$router->dispatch();
