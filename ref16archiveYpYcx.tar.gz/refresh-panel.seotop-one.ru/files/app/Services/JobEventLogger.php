<?php

/**
 * Логгер событий refresh-джоб.
 *
 * Пишет в refresh_job_events для отображения в UI.
 * При level='ok'/'error' — отправляет уведомление в Telegram (если настроено).
 *
 * Использование:
 *   $log = new JobEventLogger($jobId);
 *   $log->info('domain_purchasing', 'Запрашиваю checkDomain у Namecheap');
 *   $log->ok('domain_purchasing', 'Куплен volna-203.casino за $9.18');
 *   $log->error('domain_purchasing', 'Все 5 доменов заняты');
 */
class JobEventLogger
{
    private int $jobId;
    private ?TelegramService $tg = null;

    public function __construct(int $jobId)
    {
        $this->jobId = $jobId;
    }

    public function info(string $stage, string $message, array $payload = []): void
    {
        $this->write($stage, 'info', $message, $payload);
    }

    public function warn(string $stage, string $message, array $payload = []): void
    {
        $this->write($stage, 'warn', $message, $payload);
    }

    public function ok(string $stage, string $message, array $payload = []): void
    {
        $this->write($stage, 'ok', $message, $payload);
        $this->notifyTg('ok', $stage, $message);
    }

    public function error(string $stage, string $message, array $payload = []): void
    {
        $this->write($stage, 'error', $message, $payload);
        $this->notifyTg('error', $stage, $message);
    }

    /**
     * Особое уведомление: «джоба полностью завершена успешно».
     * v14h: если job_summary_enabled — шлём сводку с разбивкой по стадиям.
     */
    public function done(string $oldDomain, string $newDomain): void
    {
        // v18 fix: write() принимает 4 аргумента, передаём пустой payload
        $this->write('done', 'ok', "Готово: {$oldDomain} → {$newDomain}", []);
        try {
            $tg = $this->tg();
            $settings = $tg->getSettings();
            if (empty($settings['enabled'])) return;

            // Если включена сводка — шлём её вместо обычного notifyDone
            if (!empty($settings['job_summary_enabled'])) {
                $stages = $this->buildStagesSummary();
                $tg->notifyJobSummary($this->jobId, $oldDomain, $newDomain, $stages, null);
            } else {
                $tg->notifyDone($this->jobId, $oldDomain, $newDomain);
            }
        } catch (\Throwable $e) {
            // Telegram ошибки не должны мешать главному потоку
        }
    }

    /**
     * Собирает сводку результатов всех стадий джобы из artifacts_json + events.
     * Каждая стадия описывается человеко-читаемой строкой с конкретикой
     * (что куплено, сколько алиасов, какой issuer SSL и т.д.).
     *
     * @return array { stage => ['status' => 'ok'|'fail'|'skip', 'human' => 'строка'] }
     */
    private function buildStagesSummary(): array
    {
        try {
            // 1) Загружаем саму джобу + artifacts
            $job = $this->loadJobForSummary();
            $artifacts = [];
            if (!empty($job['artifacts_json'])) {
                $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
            }

            // 2) Загружаем agg per-stage status из events (для определения failed)
            $stageStatusFromEvents = $this->loadStageStatusesFromEvents();

            // 3) Для каждой стадии — генерируем human-readable строку
            $result = [];
            foreach (self::STAGE_ORDER_FOR_SUMMARY as $stage) {
                $status = $stageStatusFromEvents[$stage] ?? null;
                if ($status === null) continue; // стадия не запускалась

                $human = $this->humanizeStage($stage, $status, $artifacts, $job);
                $result[$stage] = [
                    'status' => $status,
                    'human' => $human,
                ];
            }
            return $result;
        } catch (\Throwable $e) {
            error_log("buildStagesSummary failed: " . $e->getMessage());
            return [];
        }
    }

    /** Порядок стадий в сводке (соответствует STAGES_ORDER в RefreshOrchestrator) */
    private const STAGE_ORDER_FOR_SUMMARY = [
        'domain_purchasing',
        'aliases_added',
        'ssl_self_signed_first',
        'redirect_disable',
        'analyze_site',
        'config_replaced',
        'verify_replacement',
        'ssl_le_polling',
        'update_classes_call',  // v16
        'trusted_ssl_gate',     // P0: публичный trusted-SSL gate перед Webmaster
        'wm_account_resolve',   // v17
        'wm_added',
        'wm_verified',
        'wm_robots_check',      // v18 — диагностика robots через Webmaster API (между wm_verified и wm_sitemap)
        'wm_sitemap',
        'wm_recrawl',
        'index_watching',
        'redirect_enable',      // v17 — перенесено в конец
        // v18:
        'move_htaccess_redirect',
        'move_submit_request',
        'move_poll_status',
        'old_delurl_notify',
    ];

    /**
     * Берёт стадии из refresh_job_events и возвращает {stage => 'ok'|'fail'|'skip'}.
     */
    private function loadStageStatusesFromEvents(): array
    {
        $st = DB::pdo()->prepare(
            "SELECT stage, level, message
             FROM refresh_job_events
             WHERE job_id = ? AND stage <> 'done'
             ORDER BY id ASC"
        );
        $st->execute([$this->jobId]);
        $rows = $st->fetchAll();

        $statuses = [];
        foreach ($rows as $row) {
            $stage = (string)$row['stage'];
            $level = (string)$row['level'];
            $msg = (string)($row['message'] ?? '');

            if (!isset($statuses[$stage])) {
                $statuses[$stage] = 'ok';
            }
            if ($level === 'error') {
                $statuses[$stage] = 'fail';
            } elseif (stripos($msg, 'skipped') !== false || stripos($msg, 'пропущен') !== false) {
                if ($statuses[$stage] !== 'fail') $statuses[$stage] = 'skip';
            }
        }
        return $statuses;
    }

    private function loadJobForSummary(): array
    {
        $st = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE id = ?");
        $st->execute([$this->jobId]);
        $row = $st->fetch();
        return $row ?: [];
    }

    /**
     * Главный метод — генерирует человеческое описание стадии на основе artifacts.
     *
     * Принципы:
     *   - Конкретные цифры и названия из artifacts (домен, цена, кол-во файлов)
     *   - Прошедшее время для done, настоящее для in-progress
     *   - Если ошибка — указываем что именно
     */
    private function humanizeStage(string $stage, string $status, array $a, array $job): string
    {
        switch ($stage) {
            case 'domain_purchasing':
                return $this->humanizeDomainPurchasing($status, $a, $job);

            case 'aliases_added':
                return $this->humanizeAliases($status, $a);

            case 'ssl_self_signed_first':
                return $this->humanizeSelfSigned($status, $a);

            case 'redirect_disable':
                return $this->humanizeRedirectDisable($status, $a);

            case 'analyze_site':
                return $this->humanizeAnalyze($status, $a);

            case 'config_replaced':
                return $this->humanizeConfigReplaced($status, $a);

            case 'verify_replacement':
                return $this->humanizeVerify($status, $a);

            case 'redirect_enable':
                return $this->humanizeRedirectEnable($status, $a);

            case 'ssl_le_polling':
                return $this->humanizeSslLe($status, $a);

            case 'wm_account_resolve':
                $stage = $a['wm_account_resolve_stage'] ?? [];
                $oldAcc = (int)($stage['old_account_id'] ?? 0);
                $newAcc = (int)($stage['new_account_id'] ?? 0);
                if ($oldAcc === $newAcc) {
                    return "Найден аккаунт Webmaster #{$newAcc} (по старому домену)";
                }
                return "Старый домен в аккаунте #{$oldAcc}, новый отправится в #{$newAcc} (override)";

            case 'wm_added':
                $stage = $a['wm_added_stage'] ?? [];
                $accId = (int)($stage['account_id'] ?? 0);
                $hostId = (string)($stage['host_id'] ?? '');
                if ($status === 'fail') return 'Не удалось добавить новый домен в Webmaster';
                return "Новый домен добавлен в Webmaster #{$accId} (host_id={$hostId})";

            case 'wm_verified':
                $stage = $a['wm_verified_stage'] ?? [];
                $vState = (string)($stage['verification_state'] ?? '');
                if ($status === 'fail') return 'HTML_FILE верификация не прошла';
                if ($vState === 'verification_in_progress') {
                    return 'HTML_FILE верификация запущена (Yandex проверяет файл)';
                }
                return 'Права на сайт подтверждены в Webmaster';

            case 'wm_sitemap':
                $stage = $a['wm_sitemap_stage'] ?? [];
                $url = (string)($stage['sitemap_url'] ?? '');
                if (empty($stage['ok'])) return "Sitemap не загрузился: " . (string)($stage['error'] ?? '');
                return "Загружен sitemap: {$url}";

            case 'wm_recrawl':
                $stage = $a['wm_recrawl_stage'] ?? [];
                $sent = (int)($stage['urls_sent'] ?? 0);
                if (($stage['action'] ?? '') === 'skipped_quota_zero') {
                    return 'Recrawl пропущен (quota исчерпана, Yandex и сам обнаружит)';
                }
                return "Запрошен переобход {$sent} URL";

            case 'index_watching':
                $stage = $a['index_watching_stage'] ?? [];
                $pages = (int)($stage['pages_indexed'] ?? 0);
                $tickCount = (int)($stage['tick_count'] ?? 0);
                if ($pages > 0) {
                    return "Сайт в индексе: {$pages} страниц";
                }
                if ($status === 'fail') return 'Сайт не появился в индексе за 7 дней';
                return "Жду индексации (tick #{$tickCount}, страниц: 0)";

            case 'wm_old_removed':
                $stage = $a['wm_old_removed_stage'] ?? [];
                if (empty($stage['ok'])) {
                    return 'Старый домен НЕ удалён из Webmaster: ' . (string)($stage['error'] ?? '?');
                }
                return 'Старый домен удалён из Webmaster';

            case 'update_classes_call':
                return $this->humanizeUpdateClasses($status, $a);
        }

        // Fallback — если стадия неизвестна, пишем по статусу
        $label = self::STAGE_LABELS_RU[$stage] ?? $stage;
        if ($status === 'fail') return "{$label}: ошибка";
        if ($status === 'skip') return "{$label}: пропущено";
        return $label;
    }

    /** Человеческие лейблы стадий (для fallback и отдельных уведомлений) */
    public const STAGE_LABELS_RU = [
        'queued'                => 'В очереди',
        'domain_purchasing'     => 'Покупка домена',
        'aliases_added'         => 'Добавление алиасов',
        'ssl_self_signed_first' => 'Временный SSL',
        'redirect_disable'      => 'Отключение редиректа',
        'analyze_site'          => 'Сканирование сайта',
        'config_replaced'       => 'Замена в config.php',
        'verify_replacement'    => 'Проверка после замены',
        'redirect_enable'       => 'Включение редиректа',
        'ssl_le_polling'        => "Выпуск SSL (Let's Encrypt)",
        'update_classes_call'   => 'Рандомизация классов',
        'trusted_ssl_gate'      => 'Webmaster: ожидает подтверждения доверенного SSL',
        'wm_account_resolve'    => 'Поиск аккаунта Webmaster',
        'wm_added'              => 'Добавление в Webmaster',
        'wm_verified'           => 'Подтверждение прав в Webmaster',
        'wm_robots_check'       => 'Проверка robots.txt в Webmaster',
        'wm_sitemap'            => 'Загрузка sitemap в Webmaster',
        'wm_robots'             => 'Подтверждение robots.txt', // legacy, не используется в v18
        'wm_recrawl'            => 'Запрос переобхода в Webmaster',
        'index_watching'        => 'Мониторинг индексации',
        'wm_old_removed'         => 'Удаление старого из Webmaster',
        // === v18 ===
        'move_htaccess_redirect' => 'Редирект в .htaccess',
        'move_submit_request'    => 'Подача заявки на переезд',
        'move_poll_status'       => 'Мониторинг переезда',
        // v18.1.23: объединённый финальный мониторинг для move-режимов
        'final_monitoring'       => 'Финальный мониторинг',
        'old_delurl_notify'      => 'Удаление старого из поиска',
        'done'                   => 'Готово',
        'failed'                 => 'Провалено',
    ];

    /** v17.5: человекочитаемые лейблы для stage_status. */
    public const STAGE_STATUS_LABELS_RU = [
        'pending'        => 'Ожидает старта',
        'running'        => 'Выполняется',
        'ok'             => 'Успешно',
        'failed'         => 'Ошибка',
        'awaiting_user'  => 'Ждёт решения',
        'skipped'        => 'Пропущено',
    ];

    /** v17.5: человекочитаемое название стадии. */
    public static function stageLabel(string $stage): string
    {
        return self::STAGE_LABELS_RU[$stage] ?? $stage;
    }

    /** v17.5: человекочитаемое название статуса. */
    public static function statusLabel(string $status): string
    {
        return self::STAGE_STATUS_LABELS_RU[$status] ?? $status;
    }

    /**
     * v18.1.20: человекочитаемое название режима джобы.
     */
    public const MODE_LABELS_RU = [
        'refresh'      => 'Перевыставление',
        'move_indexed' => 'Переезд (с инд.)',
        'move_simple'  => 'Переезд (без инд.)',
    ];

    public static function modeLabel(string $mode): string
    {
        return self::MODE_LABELS_RU[$mode] ?? $mode;
    }

    /**
     * v18.1.20: переводит технические термины внутри текстовых сообщений в русские.
     *
     * Используется в UI и Telegram-уведомлениях. Работает консервативно — заменяет
     * только однозначные термины которые непонятны не-разработчику.
     *
     * Не трогает:
     *   - идентификаторы стадий в логах ([redirect_enable]) — это технический tag
     *   - имена правил (sub_id_pattern, htaccess_redirect_play) — это id для аудита
     *   - URL'ы и хост'ы
     */
    public static function humanizeMessage(string $msg): string
    {
        // Порядок важен — длинные/составные сначала
        $replacements = [
            // smoke-test
            'smoke-test /play редиректа' => 'проверка редиректа /play',
            'Smoke-test /play редиректа' => 'Проверка редиректа /play',
            'smoke-test /play'           => 'проверка редиректа /play',
            'Smoke-test /play'           => 'Проверка редиректа /play',
            'smoke-test retry'           => 'повтор проверки редиректа',
            'smoke-test'                 => 'проверка редиректа',
            'Smoke-test'                 => 'Проверка редиректа',
            'Smoke test'                 => 'Проверка редиректа',

            // статусы (только в текстах сообщений, не в БД-значениях)
            'awaiting_user'              => 'ждёт оператора',
            'awaiting user'              => 'ждёт оператора',

            // прочие
            'post-validation'            => 'пост-проверка',
            'Post-validation'            => 'Пост-проверка',
            'auto-retry'                 => 'авто-повтор',
            'Auto-retry'                 => 'Авто-повтор',
        ];
        return strtr($msg, $replacements);
    }


    private function humanizeUpdateClasses(string $status, array $a): string
    {
        $stage = $a['update_classes_stage'] ?? [];
        $action = (string)($stage['action'] ?? '');
        $httpCode = (int)($stage['http_code'] ?? 0);

        if ($action === 'skipped') {
            return 'Рандом классов пропущен (нет update_classes.php и кастомного URL)';
        }
        if (!empty($stage['ok'])) {
            $src = $action === 'custom_url' ? 'кастомного URL' : 'update_classes.php';
            return "Рандом классов применён через {$src} (HTTP {$httpCode})";
        }
        return 'Рандом классов: вызов не удался (но pipeline продолжен)';
    }

    private function humanizeDomainPurchasing(string $status, array $a, array $job): string
    {
        if ($status === 'fail') {
            $tried = $a['tried'] ?? [];
            $count = count($tried);
            return "Покупка домена не удалась" . ($count > 0 ? " (пробовали {$count} вариант(ов))" : '');
        }

        $newDomain = (string)($job['new_domain'] ?? $a['purchased_domain'] ?? '');
        $price = null;
        // Цена — последний элемент tried где price_usd задан и result успешный/registered
        foreach (array_reverse($a['tried'] ?? []) as $t) {
            if (isset($t['price_usd']) && $t['price_usd'] !== null) {
                $price = (float)$t['price_usd'];
                break;
            }
        }
        if ($newDomain !== '') {
            $priceStr = $price !== null ? ' за $' . number_format($price, 2) : '';
            return "Куплен домен {$newDomain}{$priceStr}";
        }
        return 'Домен куплен';
    }

    private function humanizeAliases(string $status, array $a): string
    {
        $stage = $a['aliases_stage'] ?? [];
        if ($status === 'fail') {
            return 'Не удалось добавить алиасы в FastPanel';
        }
        $added = $stage['added'] ?? [];
        $existed = $stage['already_existed'] ?? [];
        $after = $stage['after'] ?? [];
        $addedCount = count($added);
        $totalCount = count($after);
        if ($addedCount === 0 && count($existed) > 0) {
            return "Алиасы уже были в FastPanel (" . count($existed) . ")";
        }
        if ($addedCount === 0) {
            return 'Алиасы добавлены';
        }
        $tail = $totalCount > 0 ? " (всего теперь {$totalCount})" : '';
        return "Добавлено {$addedCount} алиас(ов) в FastPanel{$tail}";
    }

    private function humanizeSelfSigned(string $status, array $a): string
    {
        $stage = $a['ssl_self_signed_stage'] ?? [];
        $action = (string)($stage['action'] ?? '');

        if ($status === 'fail' || (!empty($stage) && empty($stage['ok']))) {
            $msg = trim((string)($stage['message'] ?? ''));
            return 'Self-signed не установлен' . ($msg !== '' ? ": {$msg}" : '');
        }

        if ($action === 'skipped' || $status === 'skip') {
            return 'Self-signed пропущен (на :443 уже валидный cert)';
        }
        if ($action === 'reused') {
            return 'Self-signed: переиспользован существующий';
        }
        if ($action === 'created') {
            return 'Создан и применён новый self-signed';
        }
        return 'Self-signed установлен';
    }

    private function humanizeRedirectDisable(string $status, array $a): string
    {
        $stage = $a['redirect_disabled_stage'] ?? [];
        if ($status === 'fail') {
            return 'Отключение редиректов: ошибка';
        }
        $rules = $stage['applied_rules'] ?? [];
        $count = count($rules);
        if ($count === 0) {
            return 'Редиректов на сайте не нашлось — нечего отключать';
        }

        // Краткий список файлов
        $files = [];
        foreach ($rules as $r) {
            $f = (string)($r['file'] ?? '');
            if ($f !== '' && !in_array($f, $files, true)) $files[] = $f;
        }
        $filesStr = empty($files) ? '' : ' (' . implode(', ', $files) . ')';
        return "Отключено {$count} правил редиректа{$filesStr}";
    }

    private function humanizeAnalyze(string $status, array $a): string
    {
        if ($status === 'fail') {
            return 'Сканирование не удалось — не найден рабочий FTP base_path?';
        }
        $plan = $a['replacement_plan'] ?? [];
        $scanned = (int)($plan['files_scanned'] ?? 0);
        $count = (int)($plan['replacements_count'] ?? 0);
        if ($scanned === 0 && $count === 0) {
            return 'Файлы сайта просканированы';
        }
        return "Сканер: {$scanned} файлов, найдено {$count} мест замены";
    }

    private function humanizeConfigReplaced(string $status, array $a): string
    {
        $stage = $a['config_replaced_stage'] ?? [];
        if ($status === 'fail' || (isset($stage['ok']) && empty($stage['ok']))) {
            $errs = $stage['errors'] ?? [];
            $errStr = !empty($errs) ? ': ' . implode('; ', array_slice($errs, 0, 2)) : '';
            return "Замена в файлах не удалась{$errStr}";
        }
        $applied = (int)($stage['replacements_applied'] ?? 0);
        $files = (int)($stage['files_changed'] ?? 0);
        if ($applied === 0 && $files === 0) {
            return 'Замены в конфигах применены';
        }
        return "Применено {$applied} замен в {$files} файл(ах)";
    }

    private function humanizeVerify(string $status, array $a): string
    {
        $stage = $a['verify_stage'] ?? [];
        $checks = $stage['checks'] ?? [];
        $failed = $stage['failed_checks'] ?? [];
        $total = count($checks);
        $okCount = $total - count($failed);

        // v18.1.27: ПРИОРИТЕТ artifacts над event-status.
        // verify_replacement делает adaptive infinite retry (v18.1.25) —
        // event-log накапливает старые fail-события, но финальный artifacts
        // показывает реальное состояние. Доверяем artifacts.
        if ($total > 0 && empty($failed)) {
            // Финальный успех — игнорируем event-status='fail' от старых retry-fail'ов
            return "Verify: все {$total} проверок прошли";
        }

        if (!empty($failed)) {
            $names = array_slice(array_map(fn($f) => (string)($f['name'] ?? '?'), $failed), 0, 3);
            return "Verify: {$okCount}/{$total} проверок прошли, упали: " . implode(', ', $names);
        }
        // Нет ни checks ни failed — стадия ещё не закончилась или редкий случай
        if ($status === 'fail') {
            return "Verify: проверка не завершилась";
        }
        return 'Verify: проверки прошли';
    }

    private function humanizeRedirectEnable(string $status, array $a): string
    {
        $stage = $a['redirect_enabled_stage'] ?? [];

        // v18.1.27: ПРИОРИТЕТ artifacts над event-status.
        // Раньше: если в event-логе была ХОТЬ ОДНА запись с level=error
        // (например smoke-test fail который потом сам прошёл на retry),
        // status стадии становился 'fail' → summary врал «Редиректы НЕ включены».
        // Теперь: если artifacts.redirect_enabled_stage.ok === true и есть
        // restored_rules — это финальный успех, игнорируем старые error-события.

        // Сначала проверяем явные fail-маркеры в artifacts — они победят всегда.
        $postValFailed = !empty($stage['remaining_markers']) || !empty($stage['post_validation_failed']);
        if ($postValFailed) {
            $markers = $stage['remaining_markers'] ?? [];
            $markersStr = !empty($markers) ? ': остались маркеры ' . implode(', ', array_slice($markers, 0, 2)) : '';
            return "⚠ Редиректы НЕ включены обратно{$markersStr} — проверь сайт!";
        }

        $artifactsOk = isset($stage['ok']) && !empty($stage['ok']);
        $hasRestoredRules = !empty($stage['restored_rules']);

        if ($artifactsOk && $hasRestoredRules) {
            $count = count($stage['restored_rules']);
            return "Редиректы включены обратно ({$count} правил)";
        }

        // Иначе старая логика — fail если artifacts.ok=false ИЛИ event-status='fail'
        if ($status === 'fail' || (isset($stage['ok']) && empty($stage['ok']))) {
            $errs = $stage['errors'] ?? [];
            $errStr = !empty($errs) ? ': ' . implode('; ', array_slice($errs, 0, 2)) : '';
            return "⚠ Редиректы НЕ включены обратно{$errStr} — проверь сайт!";
        }
        $rules = $stage['restored_rules'] ?? [];
        $count = count($rules);
        if ($count === 0) {
            return 'Редиректы включены (нечего было восстанавливать)';
        }
        return "Редиректы включены обратно ({$count} правил)";
    }

    private function humanizeSslLe(string $status, array $a): string
    {
        $stage = $a['ssl_le_stage'] ?? [];
        $st = (string)($stage['status'] ?? '');
        $tick = (int)($stage['tick_count'] ?? 0);
        $msg = (string)($stage['message'] ?? '');

        // Достаём issuer/expires из live_check если есть
        $live = $stage['live_check'] ?? [];
        $issuer = trim((string)($live['issuer'] ?? ''));
        $expires = trim((string)($live['expires_at'] ?? ''));
        $issuerShort = '';
        if ($issuer !== '') {
            // Из "C=US, O=Let's Encrypt, CN=R12" вытащить "Let's Encrypt R12"
            if (preg_match("~O=([^,]+).*?CN=([^,]+)~", $issuer, $m)) {
                $issuerShort = trim($m[1]) . ' ' . trim($m[2]);
            } else {
                $issuerShort = $issuer;
            }
        }

        if ($st === 'issued' || $status === 'ok') {
            if ($issuerShort !== '' && $expires !== '') {
                return "Let's Encrypt выпущен ({$issuerShort}, до {$expires})";
            }
            if ($issuerShort !== '') {
                return "SSL выпущен и применён: {$issuerShort}";
            }
            return 'Let\'s Encrypt выпущен и применён';
        }
        if ($st === 'failed_with_self_signed') {
            return "LE не выпустился за {$tick} тиков, остался self-signed";
        }
        if ($status === 'fail') {
            return "LE: ошибка" . ($msg !== '' ? " — {$msg}" : '');
        }
        return 'SSL Let\'s Encrypt: ' . ($msg !== '' ? $msg : 'в процессе');
    }

    private function write(string $stage, string $level, string $message, array $payload = []): void
    {
        try {
            $st = DB::pdo()->prepare(
                "INSERT INTO refresh_job_events (job_id, stage, level, message, payload_json)
                 VALUES (?, ?, ?, ?, ?)"
            );
            $st->execute([
                $this->jobId,
                $stage,
                $level,
                $message,
                empty($payload) ? null : json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
        } catch (\Throwable $e) {
            // Если БД недоступна — пишем в php_errors.log хотя бы
            error_log("JobEventLogger: cannot write event: " . $e->getMessage());
        }
    }

    private function notifyTg(string $level, string $stage, string $message): void
    {
        try {
            $tg = $this->tg();
            $settings = $tg->getSettings();
            if (empty($settings['enabled'])) return;

            // === v14h: Фильтр по min_level ===
            $minLevel = (string)($settings['min_level'] ?? 'milestones');
            if ($minLevel === 'off') return;

            // errors_only: только error пропускаем
            if ($minLevel === 'errors_only' && $level !== 'error') {
                return;
            }

            // milestones: ok разрешаем только для важных стадий-вех:
            //   - aliases_added, ssl_le_polling (issued), redirect_enable, done
            // Всё остальное ok (внутренние шаги стадии) — режем
            if ($minLevel === 'milestones' && $level === 'ok') {
                $milestoneStages = [
                    'aliases_added',
                    'ssl_le_polling',
                    'redirect_enable',
                    'verify_replacement',
                    'rollback',
                    'done',
                ];
                if (!in_array($stage, $milestoneStages, true)) {
                    return;
                }
            }
            // 'all' — всё пропускаем дальше

            // === v14h: Per-stage дедуп для ok ===
            // Сколько ok-сообщений на стадию максимум (по умолчанию 1).
            // Это защищает от спама когда одна стадия логирует много ok'ов внутри
            // (например verify проверяет 4 разных URL — каждый ok).
            if ($level === 'ok') {
                $okLimit = max(0, (int)($settings['ok_per_stage_limit'] ?? 1));
                if ($okLimit === 0) return; // вообще не шлём ok
                if ($this->countOkSentForStage($stage) > $okLimit) {
                    return;
                }
            }

            // Антиспам для error: если уже был error на этой стадии в эту джобу
            // за последние 10 минут — не отправляем повторный алерт.
            if ($level === 'error') {
                if ($this->wasRecentlyAlerted($stage, $level)) {
                    return;
                }
            }

            // Если job_summary_enabled — шлём только итог при done, отдельные ok режем
            // (кроме verify_replacement и done — это полезные milestone'ы)
            if ($level === 'ok'
                && !empty($settings['job_summary_enabled'])
                && !in_array($stage, ['verify_replacement', 'done'], true)) {
                return;
            }

            if ($level === 'ok' && !empty($settings['notify_on_stage_ok'])) {
                $tg->notifyStageOk($this->jobId, $stage, $message);
            } elseif ($level === 'error' && !empty($settings['notify_on_stage_fail'])) {
                $tg->notifyStageFail($this->jobId, $stage, $message);
            }
        } catch (\Throwable $e) {
            error_log("JobEventLogger: Telegram notify failed: " . $e->getMessage());
        }
    }

    /**
     * Считает сколько раз уже был ok-event для stage в этой джобе.
     * Используется для ok_per_stage_limit.
     */
    private function countOkSentForStage(string $stage): int
    {
        try {
            $st = DB::pdo()->prepare(
                "SELECT COUNT(*) FROM refresh_job_events
                 WHERE job_id = ? AND stage = ? AND level = 'ok'"
            );
            $st->execute([$this->jobId, $stage]);
            return (int)$st->fetchColumn();
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * Проверяет, был ли уже event с таким же stage+level в этой джобе
     * за последние 10 минут. Используется для антиспам Telegram-алертов.
     *
     * Важно: вызывается ПОСЛЕ записи в refresh_job_events текущего event-а,
     * поэтому проверяем что count > 1 (исключая только что вставленный).
     */
    private function wasRecentlyAlerted(string $stage, string $level): bool
    {
        try {
            $st = DB::pdo()->prepare(
                "SELECT COUNT(*) FROM refresh_job_events
                 WHERE job_id = ?
                   AND stage = ?
                   AND level = ?
                   AND created_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)"
            );
            $st->execute([$this->jobId, $stage, $level]);
            $count = (int)$st->fetchColumn();
            // count >= 2 означает: только что вставили + был ещё хотя бы один раньше
            return $count >= 2;
        } catch (\Throwable $e) {
            // Если БД глюкнула — лучше отправить алерт чем пропустить
            return false;
        }
    }

    private function tg(): TelegramService
    {
        if ($this->tg === null) {
            $this->tg = new TelegramService();
        }
        return $this->tg;
    }
}
