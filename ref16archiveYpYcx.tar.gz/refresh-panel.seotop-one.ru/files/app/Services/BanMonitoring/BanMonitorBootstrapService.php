<?php

/**
 * BanMonitorBootstrapService — УЗКИЙ, осознанный no-backfill exception (§3.3: bootstrap
 * по отдельному ТЗ). Ставит ban-monitor на УЖЕ существующие refresh-джобы СТРОГО по
 * явному списку job_id (без сканера sites_managed / прошлых джоб / current_domain).
 *
 * Жёсткие гарды:
 *   - enrollment_enabled = 1 (иначе нет активной generation — отказ);
 *   - обязательный комментарий оператора + strict audit (ban_monitoring_audit);
 *   - один РЕАЛЬНЫЙ XMLStock-запрос через central service (reserve-before-HTTP);
 *   - монитор ставится ТОЛЬКО если новый домен СЕЙЧАС в индексе (baseline positive);
 *     один negative ≠ бан — при negative монитор НЕ ставится (нет базовой точки);
 *   - идемпотентно: активный монитор для (job, domain) не дублируется;
 *   - переиспользует атомарный BanMonitorEnrollmentService (snapshot+supersede+audit).
 *
 * Это единственное место, где generation присваивается существующей джобе задним
 * числом — по явному указанию оператора и только для перечисленных id.
 */
final class BanMonitorBootstrapService
{
    private PDO $pdo;
    private BanMonitoringSettingsRepository $settings;
    private BanMonitorRepository $repo;
    private $checkRunner; // fn(string $domain): array{classification,pages,completed_at}

    public function __construct(?PDO $pdo = null, ?BanMonitoringSettingsRepository $settings = null, ?BanMonitorRepository $repo = null, ?callable $checkRunner = null)
    {
        $this->pdo = $pdo ?? DB::pdo();
        $this->settings = $settings ?? new BanMonitoringSettingsRepository($this->pdo);
        $this->repo = $repo ?? new BanMonitorRepository($this->pdo);
        $this->checkRunner = $checkRunner ?? function (string $domain): array {
            $svc = new XmlStockRequestService(null, new XmlStockUsageRepository($this->pdo));
            $ctx = new XmlStockRequestContext('ban_monitoring', $domain, null, null, null, null, null, 'operator');
            $exec = $svc->execute($ctx);
            $cls = (string)($exec['classification'] ?? 'technical_error');
            $pages = (int)(($exec['result']['pages_indexed'] ?? 0));
            $completedAt = null;
            if (!empty($exec['usage_id'])) {
                try { $row = (new XmlStockUsageRepository($this->pdo))->byId((int)$exec['usage_id']); $completedAt = $row['completed_at'] ?? null; }
                catch (\Throwable $e) {}
            }
            return ['classification' => $cls, 'pages' => $pages, 'completed_at' => $completedAt];
        };
    }

    /**
     * @param int[] $jobIds строго явный список.
     * @return array[] по одному результату на job_id.
     */
    public function bootstrap(array $jobIds, string $operator, string $comment, bool $dryRun = false): array
    {
        $out = [];
        $comment = trim($comment);
        if ($comment === '') {
            return [['ok' => false, 'error' => 'comment_required', 'message' => 'Обязателен комментарий оператора (причина bootstrap).']];
        }
        if (!$this->settings->enrollmentEnabled()) {
            return [['ok' => false, 'error' => 'enrollment_disabled', 'message' => 'Enrollment выключен. Сначала включите мониторинг на /xmlstock (создастся generation).']];
        }
        $gen = $this->settings->activationGeneration();

        foreach ($jobIds as $jobId) {
            $jobId = (int)$jobId;
            $out[] = $this->bootstrapOne($jobId, $gen, $operator, $comment, $dryRun);
        }
        return $out;
    }

    private function bootstrapOne(int $jobId, int $gen, string $operator, string $comment, bool $dryRun): array
    {
        $res = ['job_id' => $jobId, 'ok' => false];
        $js = $this->pdo->prepare("SELECT id, site_id, new_domain, mode, ban_monitor_generation FROM refresh_jobs WHERE id=?");
        $js->execute([$jobId]);
        $job = $js->fetch(PDO::FETCH_ASSOC);
        if (!$job) return array_merge($res, ['skipped' => 'job_not_found']);

        $domain = $this->normDomain((string)($job['new_domain'] ?? ''));
        if ($domain === '') return array_merge($res, ['skipped' => 'no_new_domain']);
        $res['domain'] = $domain;
        $siteId = $job['site_id'] !== null ? (int)$job['site_id'] : null;

        // Идемпотентность: активный монитор для (job, domain) уже есть.
        $existing = $this->repo->findActiveByJobDomain($jobId, $domain);
        if ($existing && in_array((string)$existing['state'], BanMonitorRepository::ACTIVE, true)) {
            return array_merge($res, ['ok' => true, 'skipped' => 'already_monitored', 'monitor_id' => (int)$existing['id']]);
        }

        // Один реальный XMLStock-чек (или dry-run — без запроса).
        if ($dryRun) {
            return array_merge($res, ['ok' => true, 'dry_run' => true,
                'message' => "Будет выполнен 1 XMLStock-чек домена {$domain}; при positive — монитор с generation {$gen}."]);
        }

        $check = ($this->checkRunner)($domain);
        $cls = (string)($check['classification'] ?? 'technical_error');
        $pages = max(0, (int)($check['pages'] ?? 0));
        $res['check'] = $cls;

        if ($cls !== 'positive') {
            // Нет baseline «в индексе» → монитор не ставим (один negative ≠ бан).
            return array_merge($res, [
                'ok' => false, 'armed' => false, 'skipped' => $cls === 'valid_negative' ? 'not_indexed_now' : 'technical_error',
                'message' => $cls === 'valid_negative'
                    ? "Домен {$domain} сейчас НЕ в индексе — монитор не поставлен (нет базовой точки; один negative не считается баном)."
                    : "Технический результат проверки {$domain} — монитор не поставлен, повторите позже.",
            ]);
        }

        // positive → присваиваем generation этой джобе (осознанный exception) + strict audit,
        // затем атомарный arm с baseline indexed_at из completed-запроса.
        $indexedAt = $this->parseTs($check['completed_at']);
        try {
            $this->pdo->beginTransaction();
            $old = ['ban_monitor_generation' => $job['ban_monitor_generation']];
            $this->pdo->prepare("UPDATE refresh_jobs SET ban_monitor_generation=?, ban_monitor_eligible_at=NOW() WHERE id=?")
                ->execute([$gen, $jobId]);
            $this->audit('ban_bootstrap_job', $jobId, $operator, $old, ['ban_monitor_generation' => $gen], $comment);
            $this->pdo->commit();
        } catch (\Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            return array_merge($res, ['ok' => false, 'error' => 'audit_or_generation_failed', 'message' => $e->getMessage()]);
        }

        $arm = (new BanMonitorEnrollmentService($this->pdo, $this->repo, $this->settings))
            ->arm($jobId, $siteId, $domain, $indexedAt, max(1, $pages), 'manual_bootstrap');
        if (empty($arm['armed'])) {
            return array_merge($res, ['ok' => false, 'armed' => false, 'skipped' => 'arm_rejected:' . ($arm['reason'] ?? '?')]);
        }
        return array_merge($res, ['ok' => true, 'armed' => true, 'monitor_id' => (int)$arm['monitor_id'], 'generation' => $gen,
            'message' => "Монитор #{$arm['monitor_id']} поставлен на {$domain} (generation {$gen}, baseline в индексе, {$pages} стр.)."]);
    }

    private function audit(string $action, int $jobId, string $operator, array $old, array $new, string $comment): void
    {
        $st = $this->pdo->prepare(
            "INSERT INTO ban_monitoring_audit (action, object_type, object_id, operator, ip, user_agent, old_values, new_values, comment)
             VALUES (?, 'refresh_job', ?, ?, ?, ?, ?, ?, ?)"
        );
        $ok = $st->execute([
            $action, $jobId, mb_substr($operator, 0, 128), mb_substr((string)($_SERVER['REMOTE_ADDR'] ?? 'cli'), 0, 64),
            mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? 'cli'), 0, 255),
            json_encode($old, JSON_UNESCAPED_UNICODE), json_encode($new, JSON_UNESCAPED_UNICODE), mb_substr($comment, 0, 1000),
        ]);
        if (!$ok || $st->rowCount() !== 1) throw new \RuntimeException('bootstrap_audit_failed');
    }

    private function parseTs($ts): \DateTimeImmutable
    {
        if (is_string($ts) && $ts !== '') {
            try { return new \DateTimeImmutable($ts, new \DateTimeZone('UTC')); } catch (\Throwable $e) {}
        }
        return new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
    }

    private function normDomain(string $d): string
    {
        $d = strtolower(trim($d));
        $d = preg_replace('~^https?://~', '', $d);
        $d = preg_replace('~^www\.~', '', $d);
        return explode('/', $d)[0];
    }
}
