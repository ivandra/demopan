<?php

/**
 * BanMonitorTelegramFormatter — тексты Telegram (§14). Все числа ДИНАМИЧЕСКИ из
 * policy snapshot конкретного monitor (никаких hardcoded 3/6/10). HTML-escape,
 * время UTC→МСК через Time::msk, ссылки из app.base_url.
 */
final class BanMonitorTelegramFormatter
{
    private string $baseUrl;

    public function __construct(?string $baseUrl = null)
    {
        if ($baseUrl === null) $baseUrl = function_exists('config') ? (string)(config('app.base_url', '') ?? '') : '';
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    private function esc(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
    private function msk(?string $u): string { return $u ? Time::msk($u, 'd.m.Y H:i') : '—'; }
    private function policy(array $m): BanMonitoringPolicy { return BanMonitoringPolicy::fromJson($m['policy_snapshot_json'] ?? null); }

    private function jobLine(array $m, ?array $job): string
    {
        $id = (int)$m['source_job_id'];
        $mode = $job['mode'] ?? ($job['stage_mode'] ?? 'refresh');
        $line = "Джоба: #{$id} · " . $this->esc((string)$mode);
        if ($job && !empty($job['old_domain']) && !empty($job['new_domain'])) {
            $line .= "\nПереход: " . $this->esc((string)$job['old_domain']) . ' → ' . $this->esc((string)$job['new_domain']);
        }
        return $line;
    }

    private function links(array $m): string
    {
        $jobId = (int)$m['source_job_id']; $mid = (int)$m['id'];
        $base = $this->baseUrl !== '' ? $this->baseUrl : '';
        return "Джоба: " . $this->esc("{$base}/jobs/show?id={$jobId}") . "\nМонитор и расход: " . $this->esc("{$base}/xmlstock?tab=monitors&monitor_id={$mid}#monitor-{$mid}");
    }

    /** §14.1 probable. */
    public function probable(array $m, ?array $job, array $counts, ?array $balance = null): string
    {
        $p = $this->policy($m);
        $total = $p->requiredNegativeTotal();
        $streak = (int)($m['negative_streak'] ?? $p->probableNegativeCount());
        $remainingIns = max(0, $total - $streak);
        $msg = "⚠️ Скорее всего сайт в бане\n\n"
            . "Домен: " . $this->esc((string)$m['domain']) . "\n"
            . $this->jobLine($m, $job) . "\n"
            . "Monitor ID: #" . (int)$m['id'] . "\n"
            . "Первое подтверждение в индексе: " . $this->msk($m['indexed_at'] ?? null) . "\n"
            . "Последний раз обнаружен: " . $this->msk($m['last_positive_at'] ?? null) . "\n"
            . "Страниц при последнем positive: " . (int)($m['last_positive_pages'] ?? 0) . "\n"
            . "Первая пропажа: " . $this->msk($m['first_negative_at'] ?? null) . "\n"
            . "Отрицательная серия: {$streak} из {$total}\n"
            . "Подтверждающая часть: " . min($streak, $p->probableNegativeCount()) . " из " . $p->probableNegativeCount() . "\n"
            . "Осталось страховочных: {$remainingIns}\n"
            . "Следующая проверка: " . $this->msk($m['next_check_at'] ?? null) . "\n"
            . "Интервал: " . $p->insuranceIntervalMinutes() . " мин\n"
            . "XMLStock-запросов monitor: сегодня " . (int)($counts['today'] ?? 0) . " / всего " . (int)($counts['total'] ?? 0) . "\n";
        if ($balance && isset($balance['value'])) {
            $msg .= "Баланс XMLStock: " . $this->esc((string)$balance['value']) . " ₽ · проверен " . $this->msk($balance['checked_at'] ?? null) . "\n";
        }
        $msg .= "\n" . $this->links($m);
        return $msg;
    }

    /** §14.2 confirmed. */
    public function confirmed(array $m, ?array $job, array $counts, ?array $balance = null): string
    {
        $p = $this->policy($m);
        $total = $p->requiredNegativeTotal();
        $bannedAt = $m['banned_at'] ?? $m['stopped_at'] ?? null;
        $period = (!empty($m['first_negative_at']) && $bannedAt) ? $this->diffHuman($m['first_negative_at'], $bannedAt) : '—';
        $msg = "🚫 Бан подтверждён\n\n"
            . "Домен: " . $this->esc((string)$m['domain']) . "\n"
            . $this->jobLine($m, $job) . "\n"
            . "Monitor ID: #" . (int)$m['id'] . "\n"
            . "Последний valid positive: " . $this->msk($m['last_positive_at'] ?? null) . "\n"
            . "Страниц при последнем positive: " . (int)($m['last_positive_pages'] ?? 0) . "\n"
            . "Первая пропажа: " . $this->msk($m['first_negative_at'] ?? null) . "\n"
            . "Бан подтверждён: " . $this->msk($bannedAt) . "\n"
            . "Всего последовательных negative: {$total}\n"
            . "Период от первой пропажи до подтверждения: " . $this->esc($period) . "\n"
            . "XMLStock-запросов monitor: сегодня " . (int)($counts['today'] ?? 0) . " / всего " . (int)($counts['total'] ?? 0) . "\n";
        if ($balance && isset($balance['value'])) {
            $msg .= "Баланс XMLStock: " . $this->esc((string)$balance['value']) . " ₽ · проверен " . $this->msk($balance['checked_at'] ?? null) . "\n";
        }
        $msg .= "\nМониторинг XMLStock остановлен (state=banned, next_check_at=NULL).\n" . $this->links($m);
        return $msg;
    }

    /** §14.3 recovered. */
    public function recovered(array $m, ?array $job, array $counts): string
    {
        $p = $this->policy($m);
        $prevStreak = (int)($m['recovered_prev_streak'] ?? 0);
        $duration = (!empty($m['first_negative_at']) && !empty($m['last_positive_at'])) ? $this->diffHuman($m['first_negative_at'], $m['last_positive_at']) : '—';
        return "✅ Подозрение на бан не подтвердилось\n\n"
            . "Домен: " . $this->esc((string)$m['domain']) . "\n"
            . $this->jobLine($m, $job) . "\n"
            . "Monitor ID: #" . (int)$m['id'] . "\n"
            . "Когда было предупреждение: " . $this->msk($m['probable_notified_at'] ?? null) . "\n"
            . "Снова найден в индексе: " . $this->msk($m['last_positive_at'] ?? null) . "\n"
            . "Страниц найдено: " . (int)($m['last_positive_pages'] ?? 0) . "\n"
            . "Длина сброшенной серии: {$prevStreak} из " . $p->requiredNegativeTotal() . "\n"
            . "Подозрение длилось: " . $this->esc($duration) . "\n"
            . "Следующая штатная проверка: " . $this->msk($m['next_check_at'] ?? null) . "\n\n"
            . "Отрицательная серия сброшена. Мониторинг продолжится каждые " . $p->regularIntervalMinutes() . " мин.\n"
            . $this->links($m);
    }

    private function diffHuman(string $a, string $b): string
    {
        try {
            $da = new DateTimeImmutable($a, new DateTimeZone('UTC'));
            $db = new DateTimeImmutable($b, new DateTimeZone('UTC'));
            return (int)round(abs($db->getTimestamp() - $da->getTimestamp()) / 60) . ' минут';
        } catch (\Throwable $e) { return '—'; }
    }
}
