<?php

/**
 * BanMonitorRepository — доступ к site_ban_monitors / site_ban_monitor_checks.
 * Вся SQL ban-monitor в одном месте. PATCH_2: snapshot/generation, waiting_initial_delay,
 * apply-once checks (UNIQUE request_log_id), динамическая оценка расхода по snapshot.
 */
class BanMonitorRepository
{
    public const ACTIVE = ['waiting_initial_delay', 'monitoring', 'confirming', 'insurance'];

    private PDO $pdo;

    public function __construct(?PDO $pdo = null) { $this->pdo = $pdo ?? DB::pdo(); }
    public function pdo(): PDO { return $this->pdo; }

    /** Вставить monitor с immutable policy snapshot (§4.5). Возвращает id. */
    public function insertWithSnapshot(array $m): int
    {
        $st = $this->pdo->prepare(
            "INSERT INTO site_ban_monitors
               (site_id, source_job_id, domain, indexed_at, monitoring_starts_at, next_check_at,
                last_positive_at, last_positive_pages, last_pages_indexed, state,
                activation_generation, policy_version, policy_snapshot_json, enrollment_source)
             VALUES (?,?,?,?,?,?,?,?,?, 'waiting_initial_delay', ?,?,?,?)"
        );
        $st->execute([
            $m['site_id'], $m['source_job_id'], $m['domain'], $m['indexed_at'], $m['monitoring_starts_at'],
            $m['next_check_at'], $m['last_positive_at'], max(1, (int)$m['last_positive_pages']),
            (int)$m['last_positive_pages'], (int)$m['activation_generation'], (int)$m['policy_version'],
            (string)$m['policy_snapshot_json'],
            in_array((string)($m['enrollment_source'] ?? 'automatic'), ['automatic', 'manual_bootstrap'], true)
                ? (string)($m['enrollment_source'] ?? 'automatic') : 'automatic',
        ]);
        return (int)$this->pdo->lastInsertId();
    }

    /** Активный monitor для пары source_job_id+domain (идемпотентность §8.4). */
    public function findActiveByJobDomain(int $sourceJobId, string $domain): ?array
    {
        $s = $this->pdo->prepare("SELECT * FROM site_ban_monitors WHERE source_job_id=? AND domain=? LIMIT 1");
        $s->execute([$sourceJobId, $domain]);
        return $s->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Supersede ВСЕХ прочих активных мониторов сайта (§8.3: даже тот же domain, иной job). */
    public function supersedeOtherActiveForSite(?int $siteId, int $exceptMonitorId): int
    {
        if ($siteId === null) return 0;
        $in = "'" . implode("','", self::ACTIVE) . "'";
        $st = $this->pdo->prepare(
            "UPDATE site_ban_monitors
                SET state='superseded', stopped_at=NOW(), stop_reason='new_refresh_started', next_check_at=NULL
              WHERE site_id=? AND id<>? AND state IN ($in)"
        );
        $st->execute([$siteId, $exceptMonitorId]);
        return $st->rowCount();
    }

    public function getById(int $id): ?array
    { $s = $this->pdo->prepare("SELECT * FROM site_ban_monitors WHERE id=?"); $s->execute([$id]); return $s->fetch(PDO::FETCH_ASSOC) ?: null; }

    public function getBySourceJob(int $sourceJobId): ?array
    { $s = $this->pdo->prepare("SELECT * FROM site_ban_monitors WHERE source_job_id=? ORDER BY id DESC LIMIT 1"); $s->execute([$sourceJobId]); return $s->fetch(PDO::FETCH_ASSOC) ?: null; }

    public function lockForUpdate(int $id): ?array
    { $s = $this->pdo->prepare("SELECT * FROM site_ban_monitors WHERE id=? FOR UPDATE"); $s->execute([$id]); return $s->fetch(PDO::FETCH_ASSOC) ?: null; }

    public function findDue(int $limit, ?string $nowUtc = null): array
    {
        $now = $nowUtc ?: gmdate('Y-m-d H:i:s'); $limit = max(1, min(200, $limit));
        $in = "'" . implode("','", self::ACTIVE) . "'";
        $s = $this->pdo->prepare(
            "SELECT id FROM site_ban_monitors
              WHERE state IN ($in) AND next_check_at IS NOT NULL AND next_check_at <= ?
              ORDER BY next_check_at, id LIMIT {$limit}"
        );
        $s->execute([$now]);
        return array_map('intval', array_column($s->fetchAll(PDO::FETCH_ASSOC), 'id'));
    }

    public function applyPatch(int $id, array $patch, string $nowUtc): void
    {
        $patch['last_check_at'] = $nowUtc;
        $cols = []; $args = [];
        foreach ($patch as $k => $v) { $cols[] = "`{$k}`=?"; $args[] = $v; }
        $args[] = $id;
        $this->pdo->prepare("UPDATE site_ban_monitors SET " . implode(', ', $cols) . " WHERE id=?")->execute($args);
    }

    /** Вставить check. Apply-once: UNIQUE(xmlstock_request_log_id) → дубль вернёт 0. */
    public function insertCheck(array $c): int
    {
        try {
            $st = $this->pdo->prepare(
                "INSERT INTO site_ban_monitor_checks
                   (monitor_id, xmlstock_request_log_id, checked_at, phase, sequence_no, series_no,
                    result, pages_indexed, xmlstock_ok, message, error_code, response_json)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $st->execute([
                $c['monitor_id'], $c['xmlstock_request_log_id'] ?? null, $c['checked_at'], $c['phase'],
                $c['sequence_no'] ?? null, $c['series_no'] ?? 0, $c['result'], $c['pages_indexed'] ?? null,
                (int)($c['xmlstock_ok'] ?? 0), $c['message'] ?? null, $c['error_code'] ?? null,
                isset($c['response_json']) ? mb_substr((string)$c['response_json'], 0, 60000) : null,
            ]);
            return (int)$this->pdo->lastInsertId();
        } catch (\PDOException $e) {
            if ((int)($e->errorInfo[1] ?? 0) === 1062) return 0; // check для этого request уже применён
            throw $e;
        }
    }

    /** Есть ли уже check для этого request-log (apply-once, §11.7). */
    public function checkExistsForRequest(int $requestLogId): bool
    {
        if ($requestLogId <= 0) return false;
        $s = $this->pdo->prepare("SELECT 1 FROM site_ban_monitor_checks WHERE xmlstock_request_log_id=? LIMIT 1");
        $s->execute([$requestLogId]);
        return (bool)$s->fetchColumn();
    }

    public function recentChecks(int $monitorId, int $limit = 10): array
    {
        $limit = max(1, min(200, $limit));
        $s = $this->pdo->prepare("SELECT * FROM site_ban_monitor_checks WHERE monitor_id=? ORDER BY id DESC LIMIT {$limit}");
        $s->execute([$monitorId]);
        return $s->fetchAll(PDO::FETCH_ASSOC);
    }

    public function setNotified(int $id, string $field, string $nowUtc): void
    {
        if (!in_array($field, ['probable_notified_at', 'recovered_notified_at', 'confirmed_notified_at'], true)) return;
        $this->pdo->prepare("UPDATE site_ban_monitors SET `{$field}`=? WHERE id=?")->execute([$nowUtc, $id]);
    }

    public function setBlocked(int $id, string $reason, string $nowUtc, ?string $nextCheckAt): void
    {
        $this->pdo->prepare("UPDATE site_ban_monitors SET blocked_reason=?, blocked_notified_at=?, next_check_at=?, last_error=? WHERE id=?")
            ->execute([$reason, $nowUtc, $nextCheckAt, $reason, $id]);
    }

    public function listForXmlstock(): array
    {
        return $this->pdo->query("SELECT * FROM site_ban_monitors ORDER BY (state IN ('banned','stopped','superseded')) ASC, next_check_at IS NULL, next_check_at, id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function activeMonitors(): array
    {
        $in = "'" . implode("','", self::ACTIVE) . "'";
        return $this->pdo->query("SELECT * FROM site_ban_monitors WHERE state IN ($in) ORDER BY next_check_at, id")->fetchAll(PDO::FETCH_ASSOC);
    }

    /** §16.6: оценка расхода/сутки ДИНАМИЧЕСКИ по snapshot каждого активного monitor. */
    public function estimateActiveDaily(): array
    {
        $total = 0; $byState = [];
        foreach ($this->activeMonitors() as $m) {
            $st = (string)$m['state'];
            $byState[$st] = ($byState[$st] ?? 0) + 1;
            $pol = BanMonitoringPolicy::fromJson($m['policy_snapshot_json'] ?? null);
            if ($st === 'monitoring') $total += intdiv(1440, max(1, $pol->regularIntervalMinutes()));
            elseif ($st === 'confirming') $total += intdiv(1440, max(1, $pol->confirmIntervalMinutes()));
            elseif ($st === 'insurance') $total += intdiv(1440, max(1, $pol->insuranceIntervalMinutes()));
            // waiting_initial_delay/paused/banned/stopped/superseded → 0
        }
        return ['per_day_total' => $total, 'by_state' => $byState];
    }
}
