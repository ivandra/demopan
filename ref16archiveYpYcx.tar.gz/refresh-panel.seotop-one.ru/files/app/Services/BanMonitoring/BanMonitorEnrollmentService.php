<?php

/**
 * BanMonitorEnrollmentService (§8, §19.1) — единая точка постановки monitor из обоих
 * arming-hook'ов. Проверяет generation-eligibility gate и АТОМАРНО ставит monitor с
 * immutable policy snapshot, superseding прочие активные мониторы того же сайта.
 * Никакого backfill: historical/ineligible джобы отклоняются.
 */
final class BanMonitorEnrollmentService
{
    private PDO $pdo;
    private BanMonitorRepository $repo;
    private BanMonitoringSettingsRepository $settings;

    public function __construct(?PDO $pdo = null, ?BanMonitorRepository $repo = null, ?BanMonitoringSettingsRepository $settings = null)
    {
        $this->pdo = $pdo ?? DB::pdo();
        $this->repo = $repo ?? new BanMonitorRepository($this->pdo);
        $this->settings = $settings ?? new BanMonitoringSettingsRepository($this->pdo);
    }

    /**
     * @return array {armed:bool, monitor_id:?int, reason:string, idempotent?:bool}
     */
    public function arm(int $sourceJobId, ?int $siteId, string $domain, \DateTimeImmutable $indexedAt, int $pages, string $source = 'automatic'): array
    {
        $source = $source === 'manual_bootstrap' ? 'manual_bootstrap' : 'automatic';
        $domain = $this->normDomain($domain);
        if ($domain === '' || $pages < 1) {
            return ['armed' => false, 'monitor_id' => null, 'reason' => 'invalid_positive'];
        }

        $lockName = 'rfp_ban_arm_' . ($siteId !== null ? ('s' . $siteId) : ('d' . substr(md5($domain), 0, 16)));
        $got = (int)$this->pdo->query("SELECT GET_LOCK(" . $this->pdo->quote($lockName) . ", 3)")->fetchColumn();
        if ($got !== 1) return ['armed' => false, 'monitor_id' => null, 'reason' => 'lock_not_acquired'];

        try {
            $this->pdo->beginTransaction();
            try {
                // job + settings FOR UPDATE
                $js = $this->pdo->prepare("SELECT id, site_id, new_domain, mode, ban_monitor_generation, ban_monitor_eligible_at, created_at FROM refresh_jobs WHERE id=? FOR UPDATE");
                $js->execute([$sourceJobId]);
                $job = $js->fetch(PDO::FETCH_ASSOC);

                $ss = $this->pdo->prepare("SELECT * FROM ban_monitoring_settings WHERE id=1 FOR UPDATE");
                $ss->execute();
                $set = $ss->fetch(PDO::FETCH_ASSOC) ?: [];

                // eligibility gate (§8.1)
                $reason = $this->gateReason($job, $set, $domain, $source);
                if ($reason !== '') {
                    $this->jobEvent($sourceJobId, 'ban_monitor_not_eligible', 'info', $domain . ': ' . $reason, ['reason' => $reason]);
                    $this->pdo->commit();
                    return ['armed' => false, 'monitor_id' => null, 'reason' => $reason];
                }

                // идемпотентность (§8.4): уже есть monitor для source_job_id+domain
                $existing = $this->repo->findActiveByJobDomain($sourceJobId, $domain);
                if ($existing) {
                    $this->pdo->commit();
                    return ['armed' => true, 'monitor_id' => (int)$existing['id'], 'reason' => 'already_exists', 'idempotent' => true];
                }

                // snapshot действующей policy
                $policy = BanMonitoringPolicy::fromSettings($set);
                $indexedS = $indexedAt->format('Y-m-d H:i:s');
                $startsS = $indexedAt->modify('+' . $policy->initialDelayMinutes() . ' minutes')->format('Y-m-d H:i:s');

                $newId = $this->repo->insertWithSnapshot([
                    'site_id' => $siteId, 'source_job_id' => $sourceJobId, 'domain' => $domain,
                    'indexed_at' => $indexedS, 'monitoring_starts_at' => $startsS, 'next_check_at' => $startsS,
                    'last_positive_at' => $indexedS, 'last_positive_pages' => $pages,
                    'activation_generation' => (int)$set['activation_generation'],
                    'policy_version' => (int)$set['policy_version'],
                    'policy_snapshot_json' => $policy->toJson(),
                    'enrollment_source' => $source,
                ]);
                if ($newId <= 0) throw new \RuntimeException('monitor_insert_failed');

                // supersede прочие active того же сайта (§8.3)
                $this->repo->supersedeOtherActiveForSite($siteId, $newId);

                // обязательный audit/job-event в той же транзакции (§8.2)
                $this->jobEvent($sourceJobId, 'ban_monitor_armed', 'info',
                    $domain . ': monitor #' . $newId . ' armed (' . $source . '), generation ' . (int)$set['activation_generation'] . ', policy v' . (int)$set['policy_version'],
                    ['monitor_id' => $newId, 'generation' => (int)$set['activation_generation'], 'policy_version' => (int)$set['policy_version'], 'enrollment_source' => $source],
                    true);

                $this->pdo->commit();
                return ['armed' => true, 'monitor_id' => $newId, 'reason' => 'armed'];
            } catch (\Throwable $e) {
                if ($this->pdo->inTransaction()) $this->pdo->rollBack();
                error_log('[ban-monitor arm] ' . $e->getMessage());
                return ['armed' => false, 'monitor_id' => null, 'reason' => 'arm_error:' . $e->getMessage()];
            }
        } finally {
            $this->pdo->query("SELECT RELEASE_LOCK(" . $this->pdo->quote($lockName) . ")");
        }
    }

    /**
     * §2.4.1: gate под FOR UPDATE. Для automatic одновременно обязательны:
     * enrollment ON, generation = activation_generation, job.id >= activation_min_job_id,
     * job.created_at >= activation_started_at, job.ban_monitor_eligible_at >= activation_started_at.
     * Для manual_bootstrap (осознанное исключение по явному job_id) id/time-cutoff
     * не применяются, но enrollment и актуальная generation обязательны.
     */
    private function gateReason(?array $job, array $set, string $domain, string $source = 'automatic'): string
    {
        if (!$job) return 'job_not_found';
        if ((int)($set['enrollment_enabled'] ?? 0) !== 1) return 'enrollment_disabled';
        $gen = $job['ban_monitor_generation'];
        if ($gen === null) return 'no_generation';
        if ((int)$gen !== (int)($set['activation_generation'] ?? -1)) return 'stale_generation';
        $jobDomain = $this->normDomain((string)($job['new_domain'] ?? ''));
        if ($jobDomain !== '' && $jobDomain !== $domain) return 'domain_mismatch';
        if ($source !== 'manual_bootstrap') {
            $minId = $set['activation_min_job_id'] !== null ? (int)$set['activation_min_job_id'] : null;
            if ($minId !== null && (int)$job['id'] < $minId) return 'before_cutoff_id';
            $startedAt = (string)($set['activation_started_at'] ?? '');
            if ($startedAt !== '') {
                $createdAt = (string)($job['created_at'] ?? '');
                if ($createdAt !== '' && strtotime($createdAt) < strtotime($startedAt)) return 'before_cutoff_created';
                $eligAt = (string)($job['ban_monitor_eligible_at'] ?? '');
                if ($eligAt === '' || strtotime($eligAt) < strtotime($startedAt)) return 'before_cutoff_eligible';
            }
        }
        return '';
    }

    private function jobEvent(int $jobId, string $event, string $level, string $msg, array $payload, bool $mustSucceed = false): void
    {
        if ($jobId <= 0) return;
        try {
            $st = $this->pdo->prepare(
                "INSERT INTO refresh_job_events (job_id, stage, level, message, payload_json) VALUES (?, 'ban_monitoring', ?, ?, ?)"
            );
            $ok = $st->execute([$jobId, $level, mb_substr($msg, 0, 1000), json_encode(array_merge(['event' => $event], $payload), JSON_UNESCAPED_UNICODE)]);
            if ($mustSucceed && (!$ok || $st->rowCount() !== 1)) throw new \RuntimeException('audit_insert_failed');
        } catch (\Throwable $e) {
            if ($mustSucceed) throw $e; // audit-fail → rollback (§8.2)
        }
    }

    private function normDomain(string $d): string
    {
        $d = strtolower(trim($d));
        $d = preg_replace('~^https?://~', '', $d);
        $d = preg_replace('~^www\.~', '', $d);
        return explode('/', $d)[0];
    }
}
