<?php

/**
 * BanMonitoringSettingsRepository — singleton ban_monitoring_settings: чтение, валидация,
 * сохранение policy (с версионированием), активация/деактивация enrollment (generation),
 * processing toggle, присвоение eligibility новым джобам.
 */
final class BanMonitoringSettingsRepository
{
    // §4.3 диапазоны серверной валидации.
    private const RANGES = [
        'initial_delay_minutes' => [1, 10080],
        'regular_interval_minutes' => [5, 1440],
        'probable_negative_count' => [1, 20],
        'confirm_interval_minutes' => [1, 1440],
        'insurance_negative_count' => [0, 20],
        'insurance_interval_minutes' => [1, 1440],
        'technical_error_retry_minutes' => [5, 1440],
        'cron_batch_limit' => [1, 100],
        'telegram_retry_minutes' => [1, 1440],
        'telegram_max_attempts' => [1, 100],
    ];

    private PDO $pdo;

    public function __construct(?PDO $pdo = null) { $this->pdo = $pdo ?? DB::pdo(); }

    public function get(): array
    {
        $r = $this->pdo->query("SELECT * FROM ban_monitoring_settings WHERE id=1")->fetch(PDO::FETCH_ASSOC);
        if (!$r) {
            $this->pdo->exec("INSERT IGNORE INTO ban_monitoring_settings (id, enrollment_enabled, processing_enabled) VALUES (1,0,1)");
            $r = $this->pdo->query("SELECT * FROM ban_monitoring_settings WHERE id=1")->fetch(PDO::FETCH_ASSOC) ?: [];
        }
        return $r;
    }

    public function policy(): BanMonitoringPolicy { return BanMonitoringPolicy::fromSettings($this->get()); }
    public function enrollmentEnabled(): bool { return (int)($this->get()['enrollment_enabled'] ?? 0) === 1; }
    public function processingEnabled(): bool { return (int)($this->get()['processing_enabled'] ?? 1) === 1; }
    public function activationGeneration(): int { return (int)($this->get()['activation_generation'] ?? 0); }
    public function cronBatchLimit(): int { $v = (int)($this->get()['cron_batch_limit'] ?? 5); return $v >= 1 ? $v : 5; }

    /** @return array список ошибок валидации (пусто = ок). */
    public function validate(array $in): array
    {
        $errors = [];
        foreach (self::RANGES as $f => [$min, $max]) {
            if (!array_key_exists($f, $in)) continue;
            $v = (int)$in[$f];
            if ($v < $min || $v > $max) $errors[$f] = "{$f}: допустимо {$min}..{$max}, получено {$v}";
        }
        return $errors;
    }

    /** Сохранить policy: валидировать + policy_version+1 (§4.4). @return array errors. */
    public function savePolicy(array $in): array
    {
        $errors = $this->validate($in);
        if ($errors) return $errors;
        $cols = []; $args = [];
        foreach (array_merge(array_keys(self::RANGES), []) as $f) {
            if (array_key_exists($f, $in)) { $cols[] = "`{$f}`=?"; $args[] = (int)$in[$f]; }
        }
        if (!$cols) return [];
        $sql = "UPDATE ban_monitoring_settings SET " . implode(',', $cols) . ", policy_version=policy_version+1 WHERE id=1";
        $this->pdo->prepare($sql)->execute($args);
        return [];
    }

    /**
     * OFF→ON: generation+1, activation_started_at, activation_min_job_id=MAX(id)+1 (§6.1).
     * Идемпотентно: повторный вызов при уже включённом enrollment ничего не меняет.
     * @return array old/new значения для audit.
     */
    public function activate(): array
    {
        $s = $this->pdo->prepare("SELECT * FROM ban_monitoring_settings WHERE id=1 FOR UPDATE");
        $s->execute();
        $cur = $s->fetch(PDO::FETCH_ASSOC) ?: [];
        $old = ['enrollment_enabled' => (int)($cur['enrollment_enabled'] ?? 0), 'activation_generation' => (int)($cur['activation_generation'] ?? 0)];
        if ((int)($cur['enrollment_enabled'] ?? 0) === 1) {
            return ['changed' => false, 'old' => $old, 'new' => $old];
        }
        $minJobId = (int)$this->pdo->query("SELECT COALESCE(MAX(id),0)+1 FROM refresh_jobs")->fetchColumn();
        $newGen = (int)($cur['activation_generation'] ?? 0) + 1;
        $this->pdo->prepare(
            "UPDATE ban_monitoring_settings
                SET enrollment_enabled=1, activation_generation=?, activation_started_at=NOW(), activation_min_job_id=?
              WHERE id=1"
        )->execute([$newGen, $minJobId]);
        return ['changed' => true, 'old' => $old, 'new' => ['enrollment_enabled' => 1, 'activation_generation' => $newGen, 'activation_min_job_id' => $minJobId]];
    }

    public function deactivate(): array
    {
        $s = $this->pdo->prepare("SELECT enrollment_enabled FROM ban_monitoring_settings WHERE id=1 FOR UPDATE"); $s->execute();
        $old = (int)$s->fetchColumn();
        $this->pdo->prepare("UPDATE ban_monitoring_settings SET enrollment_enabled=0 WHERE id=1")->execute();
        return ['changed' => $old === 1, 'old' => ['enrollment_enabled' => $old], 'new' => ['enrollment_enabled' => 0]];
    }

    public function setProcessing(bool $on): array
    {
        $s = $this->pdo->prepare("SELECT processing_enabled FROM ban_monitoring_settings WHERE id=1 FOR UPDATE"); $s->execute();
        $old = (int)$s->fetchColumn();
        $this->pdo->prepare("UPDATE ban_monitoring_settings SET processing_enabled=? WHERE id=1")->execute([$on ? 1 : 0]);
        return ['changed' => $old !== ($on ? 1 : 0), 'old' => ['processing_enabled' => $old], 'new' => ['processing_enabled' => $on ? 1 : 0]];
    }

    /**
     * Присвоить eligibility свежесозданной джобе (§7). ТЗ 2.4.1: для АВТОМАТИЧЕСКОГО
     * enrollment одновременно обязательны: enrollment ON, job.id >= activation_min_job_id
     * и job.created_at >= activation_started_at. Только тогда джоба получает текущую
     * generation + eligible_at=NOW; иначе NULL (никогда не поставит monitor автоматически).
     * Ручной bootstrap — отдельное осознанное исключение (enrollment_source=manual_bootstrap).
     */
    public function assignEligibility(int $jobId): void
    {
        if ($jobId <= 0) return;
        $s = $this->pdo->query("SELECT enrollment_enabled, activation_generation, activation_min_job_id, activation_started_at FROM ban_monitoring_settings WHERE id=1");
        $cur = $s ? $s->fetch(PDO::FETCH_ASSOC) : null;
        if (!$cur || (int)$cur['enrollment_enabled'] !== 1) return;
        $minId = $cur['activation_min_job_id'] !== null ? (int)$cur['activation_min_job_id'] : null;
        $startedAt = $cur['activation_started_at'] ?? null;
        if ($minId !== null && $jobId < $minId) return; // до cutoff — не автоматическая
        $js = $this->pdo->prepare("SELECT created_at FROM refresh_jobs WHERE id=?");
        $js->execute([$jobId]);
        $createdAt = (string)($js->fetchColumn() ?: '');
        if ($startedAt !== null && $createdAt !== '' && strtotime($createdAt) < strtotime((string)$startedAt)) return;
        $this->pdo->prepare("UPDATE refresh_jobs SET ban_monitor_generation=?, ban_monitor_eligible_at=NOW() WHERE id=?")
            ->execute([(int)$cur['activation_generation'], $jobId]);
    }

    /** Eligible ли джоба поставить monitor (§3.2/§8.1). */
    public function isEligible(array $job): bool
    {
        $s = $this->get();
        if ((int)($s['enrollment_enabled'] ?? 0) !== 1) return false;
        $gen = $job['ban_monitor_generation'] ?? null;
        if ($gen === null) return false;
        return (int)$gen === (int)($s['activation_generation'] ?? -1);
    }
}
