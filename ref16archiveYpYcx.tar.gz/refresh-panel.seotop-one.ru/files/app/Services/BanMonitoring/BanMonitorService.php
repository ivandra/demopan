<?php

/**
 * BanMonitorService — оркестрация ban-monitor (PATCH_2).
 *  - arming делегируется BanMonitorEnrollmentService (eligibility gate + atomic);
 *  - policy берётся из immutable snapshot конкретного monitor;
 *  - exactly-once XMLStock через XmlStockRequestService (claim reserved→started);
 *  - check применяется ровно один раз (UNIQUE request_log_id);
 *  - Telegram-события ставятся в outbox АТОМАРНО с transition (worker шлёт после commit);
 *  - gate: processing_enabled && global XMLStock enabled.
 */
final class BanMonitorService
{
    private PDO $pdo;
    private BanMonitorRepository $repo;
    private XmlStockRequestService $requests;
    private XmlStockUsageRepository $usage;
    private BanMonitorTelegramFormatter $fmt;
    private BanMonitoringSettingsRepository $settings;
    private BanMonitorNotificationRepository $notifications;
    private $clock;
    private $jobLoader;

    public function __construct(
        ?BanMonitorRepository $repo = null, ?XmlStockRequestService $requests = null, ?XmlStockUsageRepository $usage = null,
        ?BanMonitorTelegramFormatter $fmt = null, ?callable $clock = null, ?callable $jobLoader = null,
        ?BanMonitoringSettingsRepository $settings = null, ?BanMonitorNotificationRepository $notifications = null
    ) {
        $this->pdo = DB::pdo();
        $this->repo = $repo ?? new BanMonitorRepository($this->pdo);
        $this->usage = $usage ?? new XmlStockUsageRepository($this->pdo);
        $this->requests = $requests ?? new XmlStockRequestService(null, $this->usage);
        $this->fmt = $fmt ?? new BanMonitorTelegramFormatter();
        $this->settings = $settings ?? new BanMonitoringSettingsRepository($this->pdo);
        $this->notifications = $notifications ?? new BanMonitorNotificationRepository($this->pdo);
        $this->clock = $clock ?? static fn() => new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $this->jobLoader = $jobLoader ?? static function (int $jobId): ?array {
            try { $s = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE id=?"); $s->execute([$jobId]); return $s->fetch(PDO::FETCH_ASSOC) ?: null; }
            catch (\Throwable $e) { return null; }
        };
    }

    /** §19.1: делегирование enrollment-сервису (eligibility gate + atomic arm). */
    public function armFromXmlStockIndexed(int $sourceJobId, ?int $siteId, string $domain, \DateTimeImmutable $indexedAt, int $pagesIndexed): array
    {
        return (new BanMonitorEnrollmentService($this->pdo, $this->repo, $this->settings))
            ->arm($sourceJobId, $siteId, $domain, $indexedAt, $pagesIndexed);
    }

    /** §15.1: due-обработка. Gate: processing_enabled && global XMLStock enabled. */
    public function runDue(int $limit = 0): array
    {
        $out = ['ban_due' => 0, 'processed' => 0, 'http_started' => 0, 'replayed' => 0, 'blocked_ambiguous' => 0, 'technical_errors' => 0, 'errors' => []];
        if (!$this->settings->processingEnabled() || !$this->globalXmlstockEnabled()) {
            // §5.3: стоп-кран НЕ значит «молча забыть мониторы». Due-мониторы получают
            // понятный blocked_reason + новый next_check_at (без HTTP, без роста серии,
            // без спама — setBlocked логирует только смену причины). После включения
            // мониторинг продолжается со своей серии.
            $reason = !$this->globalXmlstockEnabled() ? 'xmlstock_disabled' : 'processing_disabled';
            $limitB = $limit > 0 ? $limit : $this->settings->cronBatchLimit();
            $now = ($this->clock)();
            $ids = $this->repo->findDue($limitB, $now->format('Y-m-d H:i:s'));
            $out['ban_due'] = count($ids);
            foreach ($ids as $id) {
                try {
                    $m = $this->repo->getById($id);
                    if ($m) { $this->handleBlocked($m, $reason, $now); $out['blocked'] = ($out['blocked'] ?? 0) + 1; }
                } catch (\Throwable $e) { $out['errors'][] = "monitor {$id}: " . $e->getMessage(); }
            }
            $out['skipped'] = 'processing_or_global_disabled';
            return $out;
        }
        $limit = $limit > 0 ? $limit : $this->settings->cronBatchLimit();
        $ids = $this->repo->findDue($limit, ($this->clock)()->format('Y-m-d H:i:s'));
        $out['ban_due'] = count($ids);
        foreach ($ids as $id) {
            try {
                $r = $this->processMonitor($id);
                $out['processed']++;
                $out['http_started'] += (int)($r['http'] ?? 0);
                if (!empty($r['replayed'])) $out['replayed']++;
                if (!empty($r['ambiguous'])) $out['blocked_ambiguous']++;
                if (($r['decision'] ?? '') === 'ban_monitor_technical_error') $out['technical_errors']++;
            } catch (\Throwable $e) {
                $out['errors'][] = "monitor {$id}: " . $e->getMessage();
                error_log('[ban-monitor] ' . $e->getMessage());
            }
        }
        return $out;
    }

    /** §8/§11/§13 processMonitor. */
    public function processMonitor(int $monitorId, string $initiatedBy = 'cron'): array
    {
        $lockName = "rfp_ban_monitor_{$monitorId}";
        $got = (int)$this->pdo->query("SELECT GET_LOCK(" . $this->pdo->quote($lockName) . ", 0)")->fetchColumn();
        if ($got !== 1) return ['skipped' => 'lock_not_acquired', 'http' => 0];

        try {
            $now = ($this->clock)(); $nowS = $now->format('Y-m-d H:i:s');
            $m = $this->repo->getById($monitorId);
            if (!$m) return ['skipped' => 'not_found', 'http' => 0];
            if (!in_array((string)$m['state'], BanMonitorRepository::ACTIVE, true)) return ['skipped' => 'inactive', 'http' => 0];
            if ($m['next_check_at'] === null || $m['next_check_at'] > $nowS) return ['skipped' => 'not_due', 'http' => 0];

            // gate global enabled (processing проверяется в runDue; для check-now — тоже)
            if (!$this->globalXmlstockEnabled()) {
                return $this->handleBlocked($m, 'xmlstock_disabled', $now);
            }
            if (!$this->settings->processingEnabled()) {
                return $this->handleBlocked($m, 'processing_disabled', $now);
            }

            $policy = BanMonitoringPolicy::fromJson($m['policy_snapshot_json'] ?? null);
            $state = (string)$m['state']; $streak = (int)$m['negative_streak']; $seriesNo = (int)$m['series_no'];
            $phase = BanMonitorDecision::predictPhase($state, $streak, $policy);
            $sequence = BanMonitorDecision::predictSequence($state, $streak);

            $ctx = new XmlStockRequestContext('ban_monitoring', (string)$m['domain'], (int)$m['source_job_id'],
                $m['site_id'] !== null ? (int)$m['site_id'] : null, $monitorId, $phase, $sequence,
                $initiatedBy === 'operator' ? 'operator' : ($initiatedBy === 'system_test' ? 'system_test' : 'cron'));
            $uuid = $initiatedBy === 'cron'
                ? XmlStockRequestContext::scheduledUuid($monitorId, $seriesNo, $phase, $sequence, (string)$m['next_check_at'])
                : null;

            $exec = $this->requests->execute($ctx, $uuid);

            if (!empty($exec['disabled'])) return $this->handleBlocked($m, 'xmlstock_disabled', $now);
            if (!empty($exec['ambiguous']) && empty($exec['result'])) {
                // §11.4 in-flight/ambiguous без результата — HTTP не повторяем, состояние не двигаем.
                $this->repo->applyPatch($monitorId, ['next_check_at' => $now->modify('+' . $policy->technicalErrorRetryMinutes() . ' minutes')->format('Y-m-d H:i:s'), 'last_error' => (string)($exec['error'] ?? 'ambiguous')], $nowS);
                return ['skipped' => 'ambiguous', 'http' => (int)($exec['http'] ?? 0), 'ambiguous' => true];
            }
            if (empty($exec['ok']) && empty($exec['replayed'])) {
                // reserve/claim fail → HTTP=0, состояние не двигаем, +tech retry (§12.4).
                $this->repo->applyPatch($monitorId, ['next_check_at' => $now->modify('+' . $policy->technicalErrorRetryMinutes() . ' minutes')->format('Y-m-d H:i:s'), 'last_error' => (string)($exec['error'] ?? 'reserve_failed')], $nowS);
                return ['skipped' => (string)($exec['error'] ?? 'reserve_failed'), 'http' => 0];
            }

            $result = (array)($exec['result'] ?? []);
            $usageId = (int)($exec['usage_id'] ?? 0);
            $classification = (string)($exec['classification'] ?? BanMonitorDecision::classify($result));

            return $this->applyTransition($monitorId, $seriesNo, $usageId, $result, $classification, $policy, $now, (int)($exec['http'] ?? 0), !empty($exec['replayed']));
        } finally {
            $this->pdo->query("SELECT RELEASE_LOCK(" . $this->pdo->quote($lockName) . ")");
        }
    }

    /** Транзакция: check apply-once + один переход + outbox события атомарно. */
    private function applyTransition(int $monitorId, int $seriesNo, int $usageId, array $result, string $classification, BanMonitoringPolicy $policy, \DateTimeImmutable $now, int $http, bool $replayed): array
    {
        $nowS = $now->format('Y-m-d H:i:s');
        $this->pdo->beginTransaction();
        try {
            $mLock = $this->repo->lockForUpdate($monitorId);
            if (!$mLock || !in_array((string)$mLock['state'], BanMonitorRepository::ACTIVE, true) || (int)$mLock['series_no'] !== $seriesNo) {
                $this->pdo->rollBack();
                return ['skipped' => 'state_changed', 'http' => $http, 'replayed' => $replayed];
            }
            // apply-once (§11.7): если для этого request уже есть check — не повторяем transition.
            if ($usageId > 0 && $this->repo->checkExistsForRequest($usageId)) {
                $this->pdo->rollBack();
                return ['skipped' => 'already_applied', 'http' => $http, 'replayed' => $replayed];
            }

            $decision = BanMonitorDecision::decide($mLock, $classification, (int)($result['pages_indexed'] ?? 0), $now, $policy);

            $checkId = $this->repo->insertCheck([
                'monitor_id' => $monitorId, 'xmlstock_request_log_id' => $usageId ?: null, 'checked_at' => $nowS,
                'phase' => $decision['phase'], 'sequence_no' => $decision['sequence_no'],
                'series_no' => ($classification === 'valid_negative' && (string)$mLock['state'] === 'monitoring') ? $seriesNo + 1 : $seriesNo,
                'result' => $decision['check_result'], 'pages_indexed' => (int)($result['pages_indexed'] ?? 0),
                'xmlstock_ok' => !empty($result['ok']) ? 1 : 0, 'message' => mb_substr((string)($result['message'] ?? ''), 0, 1000),
                'error_code' => $classification === 'technical_error' ? (string)($result['error'] ?? 'technical_error') : null,
                'response_json' => json_encode($this->sanitize($result), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
            if ($checkId === 0) { // UNIQUE конфликт (гонка) — применён другим worker
                $this->pdo->rollBack();
                return ['skipped' => 'check_duplicate', 'http' => $http, 'replayed' => $replayed];
            }

            $patch = $decision['patch'];
            $patch['last_result_json'] = json_encode($this->sanitize($result), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $patch['last_error'] = $classification === 'technical_error' ? (string)($result['error'] ?? '') : null;

            // *_notified_at выставляем оптимистично в этой же транзакции (событие ISSUED).
            $seriesForKey = $patch['series_no'] ?? $mLock['series_no'];
            foreach ($decision['telegrams'] as $kind) {
                if ($kind === 'probable') $patch['probable_notified_at'] = $nowS;
                if ($kind === 'confirmed') $patch['confirmed_notified_at'] = $nowS;
                if ($kind === 'recovered') $patch['recovered_notified_at'] = $nowS;
            }
            // §5.3: успешная обработка после снятия стоп-крана — монитор больше не
            // «заблокирован», серия продолжается со своей точки.
            $patch['blocked_reason'] = null;
            $this->repo->applyPatch($monitorId, $patch, $nowS);

            // Outbox события АТОМАРНО (§13.3): реальная ошибка INSERT → откат transition.
            if ($decision['telegrams']) {
                $mAfter = array_merge($mLock, $patch);
                if (isset($decision['recovered_prev_streak'])) $mAfter['recovered_prev_streak'] = $decision['recovered_prev_streak'];
                $job = ($this->jobLoader)((int)$mLock['source_job_id']);
                $counts = $this->usage->monitorCounts($monitorId);
                foreach ($decision['telegrams'] as $kind) {
                    $text = $kind === 'probable' ? $this->fmt->probable($mAfter, $job, $counts)
                          : ($kind === 'confirmed' ? $this->fmt->confirmed($mAfter, $job, $counts)
                          : $this->fmt->recovered($mAfter, $job, $counts));
                    $this->notifications->enqueue([
                        'monitor_id' => $monitorId, 'source_job_id' => (int)$mLock['source_job_id'], 'domain' => (string)$mLock['domain'],
                        'event_key' => 'ban-monitor:' . $monitorId . ':series:' . $seriesForKey . ':' . $kind,
                        'kind' => $kind, 'rendered_text' => $text,
                        'payload_json' => json_encode(['telegram_retry_minutes' => $policy->telegramRetryMinutes(), 'telegram_max_attempts' => $policy->telegramMaxAttempts()], JSON_UNESCAPED_UNICODE),
                        'next_attempt_at' => $nowS,
                    ]);
                }
            }

            $this->pdo->commit();
            $this->jobEvent($mLock, $decision['log']);
            return ['ok' => true, 'http' => $http, 'decision' => $decision['log'], 'telegrams' => $decision['telegrams'], 'replayed' => $replayed];
        } catch (\Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }

    /** §15.5: global off / низкий баланс — не плодить псевдо-check, anti-spam next. */
    private function handleBlocked(array $m, string $reason, \DateTimeImmutable $now): array
    {
        $policy = BanMonitoringPolicy::fromJson($m['policy_snapshot_json'] ?? null);
        $next = $now->modify('+' . $policy->regularIntervalMinutes() . ' minutes')->format('Y-m-d H:i:s');
        $this->repo->setBlocked((int)$m['id'], $reason, $now->format('Y-m-d H:i:s'), $next);
        return ['skipped' => $reason, 'http' => 0, 'blocked' => true];
    }

    private function globalXmlstockEnabled(): bool
    {
        try { return (int)$this->pdo->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn() === 1; }
        catch (\Throwable $e) { return false; }
    }

    private function jobEvent(array $m, string $event): void
    {
        if (empty($m['source_job_id'])) return;
        try {
            if (class_exists('JobEventLogger')) {
                (new JobEventLogger((int)$m['source_job_id']))->info('ban_monitoring', $event, ['monitor_id' => (int)$m['id'], 'domain' => (string)$m['domain']]);
            }
        } catch (\Throwable $e) {}
    }

    private function sanitize(array $r): array { unset($r['url'], $r['raw_excerpt']); return $r; }
}
