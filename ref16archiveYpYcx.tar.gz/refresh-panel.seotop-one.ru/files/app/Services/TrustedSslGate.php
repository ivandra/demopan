<?php

/**
 * TrustedSslGate (P0) — реальная ПУБЛИЧНАЯ TLS-проверка нового домена перед Webmaster.
 *
 * Gate закрыт (ok=true) ТОЛЬКО если публичный https://<domain>:443 одновременно:
 *   - TLS-соединение устанавливается;
 *   - цепочка доверенная (chain_verified);
 *   - hostname соответствует домену (hostname_verified);
 *   - сертификат не self-signed;
 *   - сертификат действует сейчас (not_before <= now <= not_after);
 *   - проверено публичным контуром без --insecure.
 *
 * Издатель НЕ важен (Let's Encrypt / DDoS-Guard / иной доверенный CA — всё валидно,
 * если публичная проверка цепочки и hostname проходит). Недостаточно: FastPanel
 * cert ready / cert_id=ready / issuer содержит ddos-guard / origin по прямому IP /
 * self-signed. Probe инъектируется (тесты), по умолчанию — реальный TLS-handshake.
 */
final class TrustedSslGate
{
    /** @var callable fn(string $domain): array — публичный TLS-probe. */
    private $probe;
    private $clock;

    public function __construct(?callable $probe = null, ?callable $clock = null)
    {
        $this->clock = $clock ?? static fn() => new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $this->probe = $probe ?? [self::class, 'liveProbe'];
    }

    /**
     * @return array артефакт trusted_ssl_gate (ok + метаданные + reason при неуспехе).
     */
    public function verify(string $domain): array
    {
        $domain = $this->norm($domain);
        $now = ($this->clock)();
        $base = [
            'ok' => false, 'domain' => $domain, 'checked_at' => $now->format('Y-m-d H:i:s'),
            'issuer' => null, 'subject' => null, 'valid_from' => null, 'valid_to' => null,
            'fingerprint_sha256' => null, 'hostname_verified' => false, 'chain_verified' => false,
            'source' => 'public_live_tls',
        ];
        if ($domain === '') return array_merge($base, ['reason' => 'empty_domain', 'fatal' => true]);

        try {
            $r = ($this->probe)($domain);
        } catch (\Throwable $e) {
            $msg = function_exists('mb_substr')
                ? mb_substr($e->getMessage(), 0, 200)
                : substr($e->getMessage(), 0, 200); // автономность: класс не требует mbstring
            return array_merge($base, ['reason' => 'probe_error:' . $msg]);
        }
        if (!is_array($r)) return array_merge($base, ['reason' => 'probe_invalid']);

        $out = array_merge($base, [
            'issuer' => $r['issuer'] ?? null, 'subject' => $r['subject'] ?? null,
            'valid_from' => $r['not_before'] ?? null, 'valid_to' => $r['not_after'] ?? null,
            'fingerprint_sha256' => $r['fingerprint'] ?? null,
            'hostname_verified' => !empty($r['hostname_verified']),
            'chain_verified' => !empty($r['chain_verified']),
        ]);

        if (empty($r['connected']))          return array_merge($out, ['reason' => 'tls_not_established']);
        if (empty($r['chain_verified']))     return array_merge($out, ['reason' => 'chain_untrusted']);
        if (empty($r['hostname_verified']))  return array_merge($out, ['reason' => 'hostname_mismatch']);
        if (!empty($r['self_signed']))       return array_merge($out, ['reason' => 'self_signed']);

        $nowTs = $now->getTimestamp();
        $nb = isset($r['not_before']) ? strtotime((string)$r['not_before']) : false;
        $na = isset($r['not_after']) ? strtotime((string)$r['not_after']) : false;
        if ($nb !== false && $nb > $nowTs)   return array_merge($out, ['reason' => 'not_yet_valid']);
        if ($na !== false && $na < $nowTs)   return array_merge($out, ['reason' => 'expired']);

        $out['ok'] = true;
        return $out;
    }

    private function norm(string $d): string
    {
        $d = strtolower(trim($d));
        $d = preg_replace('~^https?://~', '', $d);
        $d = preg_replace('~^www\.~', '', $d);
        return explode('/', $d)[0];
    }

    /**
     * Реальный публичный TLS-handshake (verify_peer + verify_peer_name = проверка без --insecure).
     * @return array{connected,chain_verified,hostname_verified,self_signed,not_before,not_after,issuer,subject,fingerprint}
     */
    public static function liveProbe(string $domain): array
    {
        $out = ['connected' => false, 'chain_verified' => false, 'hostname_verified' => false, 'self_signed' => true];
        $ctx = stream_context_create(['ssl' => [
            'verify_peer' => true, 'verify_peer_name' => true, 'allow_self_signed' => false,
            'SNI_enabled' => true, 'peer_name' => $domain, 'capture_peer_cert' => true,
        ]]);
        $errno = 0; $errstr = '';
        $sock = @stream_socket_client('ssl://' . $domain . ':443', $errno, $errstr, 12,
            STREAM_CLIENT_CONNECT, $ctx);
        if ($sock === false) {
            // verify_peer/verify_peer_name провал → цепочка/hostname недоверенные.
            return array_merge($out, ['error' => $errstr]);
        }
        // Соединение установлено при verify_peer=true → цепочка и hostname доверенные.
        $out['connected'] = true; $out['chain_verified'] = true; $out['hostname_verified'] = true;
        $params = stream_context_get_params($sock);
        $cert = $params['options']['ssl']['peer_certificate'] ?? null;
        if ($cert) {
            $p = openssl_x509_parse($cert) ?: [];
            $out['issuer'] = self::dn($p['issuer'] ?? []);
            $out['subject'] = self::dn($p['subject'] ?? []);
            $out['self_signed'] = ($out['issuer'] !== null && $out['issuer'] === $out['subject']);
            $out['not_before'] = isset($p['validFrom_time_t']) ? date('Y-m-d H:i:s', (int)$p['validFrom_time_t']) : null;
            $out['not_after'] = isset($p['validTo_time_t']) ? date('Y-m-d H:i:s', (int)$p['validTo_time_t']) : null;
            if (openssl_x509_export($cert, $pem)) $out['fingerprint'] = hash('sha256', $pem);
        }
        @fclose($sock);
        return $out;
    }

    private static function dn(array $dn): ?string
    {
        if (!$dn) return null;
        $parts = [];
        foreach ($dn as $k => $v) { $v = is_array($v) ? implode('/', $v) : $v; $parts[] = $k . '=' . $v; }
        return implode(', ', $parts);
    }
}
