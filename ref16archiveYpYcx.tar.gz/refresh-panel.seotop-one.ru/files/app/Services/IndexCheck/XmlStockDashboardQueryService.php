<?php

/**
 * XmlStockDashboardQueryService (§9) — read-model для нового UI /xmlstock.
 * Агрегация вынесена из контроллера. Ошибки запроса НЕ превращают показатель
 * молча в 0: каждый блок возвращает ['ok'=>bool, ...] и при ok=false UI обязан
 * показать «Не удалось получить показатель». Все даты — UTC (отображение МСК во view).
 */
final class XmlStockDashboardQueryService
{
    private PDO $pdo;

    public function __construct(?PDO $pdo = null)
    {
        $this->pdo = $pdo ?? DB::pdo();
    }

    /** Верхние KPI: сервис/баланс/расход сегодня/лимит. */
    public function summary(): array
    {
        $out = ['ok' => true];
        try {
            $out['settings'] = $this->pdo->query("SELECT * FROM xmlstock_settings WHERE id=1")->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch (\Throwable $e) { return ['ok' => false, 'error' => 'settings: ' . $e->getMessage()]; }
        try {
            $st = $this->pdo->prepare("SELECT * FROM balance_current WHERE service='xmlstock' ORDER BY last_checked_at DESC LIMIT 1");
            $st->execute();
            $out['balance'] = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (\Throwable $e) { $out['balance'] = null; $out['balance_error'] = true; }
        try {
            $r = $this->pdo->query(
                "SELECT
                    SUM(execution_state='completed') c_completed,
                    SUM(execution_state='ambiguous') c_ambiguous,
                    SUM(execution_state='failed_before_http') c_failed
                 FROM xmlstock_request_log WHERE requested_at >= UTC_DATE()"
            )->fetch(PDO::FETCH_ASSOC) ?: [];
            $out['today'] = [
                'completed' => (int)($r['c_completed'] ?? 0),
                'ambiguous' => (int)($r['c_ambiguous'] ?? 0),
                'failed_before_http' => (int)($r['c_failed'] ?? 0),
                'charged' => (int)($r['c_completed'] ?? 0) + (int)($r['c_ambiguous'] ?? 0),
            ];
        } catch (\Throwable $e) { return ['ok' => false, 'error' => 'today: ' . $e->getMessage()]; }
        return $out;
    }

    /** Расход сегодня по каждому purpose (completed+ambiguous = потенциально списанные). */
    public function consumersToday(): array
    {
        try {
            $rows = $this->pdo->query(
                "SELECT purpose,
                        SUM(execution_state='completed') c_completed,
                        SUM(execution_state='ambiguous') c_ambiguous,
                        SUM(execution_state='failed_before_http') c_failed
                 FROM xmlstock_request_log WHERE requested_at >= UTC_DATE() GROUP BY purpose"
            )->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $by = [];
            foreach (XmlStockRequestContext::PURPOSES as $p) $by[$p] = ['completed' => 0, 'ambiguous' => 0, 'failed_before_http' => 0, 'charged' => 0];
            foreach ($rows as $r) {
                $p = (string)$r['purpose'];
                if (!isset($by[$p])) $by[$p] = ['completed' => 0, 'ambiguous' => 0, 'failed_before_http' => 0, 'charged' => 0];
                $by[$p]['completed'] = (int)$r['c_completed'];
                $by[$p]['ambiguous'] = (int)$r['c_ambiguous'];
                $by[$p]['failed_before_http'] = (int)$r['c_failed'];
                $by[$p]['charged'] = (int)$r['c_completed'] + (int)$r['c_ambiguous'];
            }
            return ['ok' => true, 'by_purpose' => $by];
        } catch (\Throwable $e) { return ['ok' => false, 'error' => $e->getMessage()]; }
    }

    /**
     * §5.1: две оценки. next24h — по фактическим next_run_at/next_check_at и state
     * (сколько платных запросов реально ожидается в ближайшие 24 часа, включая
     * waiting_initial_delay мониторы, чьё окно уже начнётся). steady — потенциальный
     * штатный расход активных monitor после выхода в regular (1440/interval по snapshot)
     * + расход polling-джоб.
     */
    public function forecast(array $pollers, int $pollersPerDay): array
    {
        try {
            $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            $horizon = $now->modify('+24 hours');
            $next24 = 0; $steady = (int)$pollersPerDay; $activeMonitors = 0; $nearest = null;

            // polling-джобы: next_run_at в горизонте → считаем их суточную оценку как есть
            foreach ($pollers as $p) {
                if (!empty($p['paused']) || !empty($p['stopped'])) continue;
                $next24 += (int)($p['est_per_day'] ?? 0);
                $nr = (string)($p['next_run_at'] ?? '');
                if ($nr !== '' && ($nearest === null || $nr < $nearest)) $nearest = $nr;
            }

            $rows = $this->pdo->query(
                "SELECT id, state, next_check_at, monitoring_starts_at, policy_snapshot_json
                 FROM site_ban_monitors
                 WHERE state IN ('waiting_initial_delay','monitoring','confirming','insurance')"
            )->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as $m) {
                $activeMonitors++;
                $pol = BanMonitoringPolicy::fromJson($m['policy_snapshot_json'] ?? null);
                $interval = max(1, (string)$m['state'] === 'confirming' ? $pol->confirmIntervalMinutes()
                    : ((string)$m['state'] === 'insurance' ? $pol->insuranceIntervalMinutes() : $pol->regularIntervalMinutes()));
                $perDay = intdiv(1440, $interval);
                $steady += $perDay;
                $startS = (string)($m['next_check_at'] ?? '');
                if ($startS === '') continue;
                if ($startS !== '' && ($nearest === null || $startS < $nearest)) $nearest = $startS;
                try { $start = new DateTimeImmutable($startS, new DateTimeZone('UTC')); } catch (\Throwable $e) { continue; }
                if ($start >= $horizon) continue; // начнётся позже горизонта
                $from = $start > $now ? $start : $now;
                $minutesLeft = max(0, (int)(($horizon->getTimestamp() - $from->getTimestamp()) / 60));
                $next24 += min($perDay, intdiv($minutesLeft, $interval) + 1);
            }
            return ['ok' => true, 'next24h' => $next24, 'steady' => $steady,
                    'active_monitors' => $activeMonitors, 'nearest_at' => $nearest];
        } catch (\Throwable $e) { return ['ok' => false, 'error' => $e->getMessage()]; }
    }

    /** §5.2: достоверные счётчики активации/eligibility. */
    public function banActivationSummary(): array
    {
        try {
            $set = $this->pdo->query("SELECT * FROM ban_monitoring_settings WHERE id=1")->fetch(PDO::FETCH_ASSOC) ?: [];
            $gen = (int)($set['activation_generation'] ?? 0);
            $minId = $set['activation_min_job_id'] !== null ? (int)$set['activation_min_job_id'] : null;
            $startedAt = (string)($set['activation_started_at'] ?? '');

            // автоматически eligible: строго после cutoff
            $autoEligible = 0;
            if ($minId !== null) {
                $st = $this->pdo->prepare(
                    "SELECT COUNT(*) FROM refresh_jobs
                      WHERE ban_monitor_generation = ? AND id >= ?
                        AND (?='' OR created_at IS NULL OR created_at >= ?)"
                );
                $st->execute([$gen, $minId, $startedAt, $startedAt !== '' ? $startedAt : '1970-01-01']);
                $autoEligible = (int)$st->fetchColumn();
            }
            $m = $this->pdo->query(
                "SELECT
                    SUM(enrollment_source='automatic') c_auto,
                    SUM(enrollment_source='manual_bootstrap') c_manual,
                    SUM(state IN ('waiting_initial_delay','monitoring','confirming','insurance')) c_active,
                    SUM(state IN ('banned','stopped','superseded')) c_done,
                    SUM(blocked_reason IS NOT NULL AND state IN ('waiting_initial_delay','monitoring','confirming','insurance')) c_blocked
                 FROM site_ban_monitors"
            )->fetch(PDO::FETCH_ASSOC) ?: [];
            return ['ok' => true, 'settings' => $set,
                'auto_eligible_jobs' => $autoEligible,
                'monitors_automatic' => (int)($m['c_auto'] ?? 0),
                'monitors_manual' => (int)($m['c_manual'] ?? 0),
                'monitors_active' => (int)($m['c_active'] ?? 0),
                'monitors_finished' => (int)($m['c_done'] ?? 0),
                'monitors_blocked' => (int)($m['c_blocked'] ?? 0)];
        } catch (\Throwable $e) { return ['ok' => false, 'error' => $e->getMessage()]; }
    }

    /** Активные monitor (+счётчики запросов), терминальные отдельно (§6.2.G). */
    public function monitors(bool $terminal = false): array
    {
        try {
            $cond = $terminal ? "state IN ('banned','stopped','superseded')"
                              : "state IN ('waiting_initial_delay','monitoring','confirming','insurance','paused')";
            $rows = $this->pdo->query(
                "SELECT * FROM site_ban_monitors WHERE {$cond}
                 ORDER BY next_check_at IS NULL, next_check_at, id DESC LIMIT 200"
            )->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $counts = [];
            if ($rows) {
                $ids = implode(',', array_map('intval', array_column($rows, 'id')));
                $c = $this->pdo->query(
                    "SELECT monitor_id,
                            SUM(requested_at >= UTC_DATE() AND execution_state IN ('completed','ambiguous')) today,
                            SUM(execution_state IN ('completed','ambiguous')) total
                     FROM xmlstock_request_log WHERE monitor_id IN ({$ids}) GROUP BY monitor_id"
                )->fetchAll(PDO::FETCH_ASSOC) ?: [];
                foreach ($c as $r) $counts[(int)$r['monitor_id']] = ['today' => (int)$r['today'], 'total' => (int)$r['total']];
            }
            return ['ok' => true, 'rows' => $rows, 'counts' => $counts];
        } catch (\Throwable $e) { return ['ok' => false, 'error' => $e->getMessage(), 'rows' => [], 'counts' => []]; }
    }

    /** Последние проверки одного монитора (для раскрытия строки). */
    public function monitorChecks(int $monitorId, int $limit = 10): array
    {
        try {
            $st = $this->pdo->prepare("SELECT * FROM site_ban_monitor_checks WHERE monitor_id=? ORDER BY id DESC LIMIT " . (int)$limit);
            $st->execute([$monitorId]);
            return ['ok' => true, 'rows' => $st->fetchAll(PDO::FETCH_ASSOC) ?: []];
        } catch (\Throwable $e) { return ['ok' => false, 'rows' => []]; }
    }

    /** §6.2.H: история запросов с total count для пагинации. */
    public function requestHistory(array $f, int $page, int $perPage = 50): array
    {
        try {
            $where = []; $args = [];
            if (!empty($f['purpose'])) { $where[] = 'purpose = ?'; $args[] = $f['purpose']; }
            if (!empty($f['domain'])) { $where[] = 'domain LIKE ?'; $args[] = '%' . $f['domain'] . '%'; }
            if (!empty($f['job_id'])) { $where[] = 'source_job_id = ?'; $args[] = (int)$f['job_id']; }
            if (!empty($f['monitor_id'])) { $where[] = 'monitor_id = ?'; $args[] = (int)$f['monitor_id']; }
            if (!empty($f['result'])) { $where[] = 'result = ?'; $args[] = $f['result']; }
            if (!empty($f['execution_state'])) { $where[] = 'execution_state = ?'; $args[] = $f['execution_state']; }
            if (!empty($f['initiated_by'])) { $where[] = 'initiated_by = ?'; $args[] = $f['initiated_by']; }
            if (!empty($f['since'])) { $where[] = 'requested_at >= ?'; $args[] = $f['since']; }
            $w = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

            $cnt = $this->pdo->prepare("SELECT COUNT(*) FROM xmlstock_request_log {$w}");
            $cnt->execute($args);
            $total = (int)$cnt->fetchColumn();

            $page = max(1, $page);
            $off = ($page - 1) * $perPage;
            $st = $this->pdo->prepare("SELECT * FROM xmlstock_request_log {$w} ORDER BY id DESC LIMIT {$perPage} OFFSET {$off}");
            $st->execute($args);
            return ['ok' => true, 'rows' => $st->fetchAll(PDO::FETCH_ASSOC) ?: [],
                    'total' => $total, 'page' => $page, 'per_page' => $perPage,
                    'pages' => max(1, (int)ceil($total / $perPage))];
        } catch (\Throwable $e) { return ['ok' => false, 'error' => $e->getMessage(), 'rows' => [], 'total' => 0, 'page' => 1, 'per_page' => $perPage, 'pages' => 1]; }
    }

    /** §6.2.D: ближайшие запланированные платные запросы (polling + monitors). */
    public function nextScheduledRequests(array $pollers, int $limit = 5): array
    {
        try {
            $items = [];
            foreach ($pollers as $p) {
                if (!empty($p['paused']) || !empty($p['stopped'])) continue;
                if (empty($p['next_run_at'])) continue;
                $items[] = ['at' => (string)$p['next_run_at'], 'who' => 'Джоба #' . (int)$p['id'] . ' · ' . (string)$p['new_domain'],
                            'what' => XmlStockLabels::purpose((string)$p['stage'] === 'final_monitoring' ? 'final_monitoring' : 'index_watching')];
            }
            $rows = $this->pdo->query(
                "SELECT id, domain, state, next_check_at FROM site_ban_monitors
                  WHERE state IN ('waiting_initial_delay','monitoring','confirming','insurance') AND next_check_at IS NOT NULL"
            )->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as $m) {
                $items[] = ['at' => (string)$m['next_check_at'], 'who' => 'Monitor #' . (int)$m['id'] . ' · ' . (string)$m['domain'],
                            'what' => XmlStockLabels::purpose('ban_monitoring')];
            }
            usort($items, fn($a, $b) => strcmp($a['at'], $b['at']));
            return ['ok' => true, 'rows' => array_slice($items, 0, $limit)];
        } catch (\Throwable $e) { return ['ok' => false, 'rows' => []]; }
    }

    /** §6.2.D: предупреждения. */
    public function alerts(array $summary, array $activation): array
    {
        $alerts = [];
        try {
            if (!empty($summary['ok'])) {
                $bal = $summary['balance'] ?? null;
                if (is_array($bal) && ((string)($bal['status'] ?? '') === 'low'
                        || (isset($bal['balance']) && (float)$bal['balance'] < 100))) {
                    $alerts[] = ['level' => 'warn', 'text' => 'Низкий баланс XMLStock: '
                        . number_format((float)($bal['balance'] ?? 0), 0, '.', ' ') . ' ' . (string)($bal['currency'] ?? '₽') . '.'];
                }
                if ((int)($summary['today']['ambiguous'] ?? 0) > 0) {
                    $alerts[] = ['level' => 'warn', 'text' => 'Неопределённых (возможно списанных) запросов сегодня: '
                        . (int)$summary['today']['ambiguous'] . '. Ledger не подтвердил запись — проверьте историю (execution state «ambiguous»).'];
                }
                if ((int)($summary['settings']['enabled'] ?? 1) !== 1) {
                    $alerts[] = ['level' => 'warn', 'text' => 'XMLStock выключен: платные запросы остановлены; index/final-мониторинг на бесплатном fallback, мониторы бана заблокированы и не накапливают серию.'];
                }
            } else {
                $alerts[] = ['level' => 'error', 'text' => 'Не удалось получить сводку расхода.'];
            }
            $failedTg = (new BanMonitorNotificationRepository($this->pdo))->failedCount();
            if ($failedTg > 0) {
                $alerts[] = ['level' => 'error', 'text' => 'Telegram-уведомлений в статусе failed: ' . $failedTg . ' — требуется вмешательство.'];
            }
            if (!empty($activation['ok']) && (int)($activation['monitors_blocked'] ?? 0) > 0) {
                $alerts[] = ['level' => 'warn', 'text' => 'Заблокированных мониторов: ' . (int)$activation['monitors_blocked'] . '.'];
            }
        } catch (\Throwable $e) {
            $alerts[] = ['level' => 'error', 'text' => 'Не удалось собрать предупреждения.'];
        }
        return $alerts;
    }
}
