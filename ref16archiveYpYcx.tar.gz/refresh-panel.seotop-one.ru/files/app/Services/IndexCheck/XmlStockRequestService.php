<?php

/**
 * XmlStockRequestService — ЕДИНСТВЕННЫЙ путь выполнения и учёта XMLStock (§11, §12).
 *
 * Exactly-once: reserve → claim(reserved→started, rowCount=1) → один HTTP → complete.
 * Duplicate uuid: completed→replay без HTTP; started/ambiguous→HTTP=0; claim проигран→HTTP=0.
 * SQL-транзакция НЕ держится во время HTTP. Transport инъектируется (seam).
 */
final class XmlStockRequestService
{
    /** @var callable fn(XmlStockRequestContext): array */
    private $transport;
    private XmlStockUsageRepository $usage;
    private $clock;
    private $enabledCheck;

    public function __construct(?callable $transport = null, ?XmlStockUsageRepository $usage = null, ?callable $clock = null, ?callable $enabledCheck = null)
    {
        $this->usage = $usage ?? new XmlStockUsageRepository();
        $this->clock = $clock ?? static fn() => new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $this->enabledCheck = $enabledCheck ?? static function (): bool {
            try { return (int)DB::pdo()->query("SELECT enabled FROM xmlstock_settings WHERE id=1")->fetchColumn() === 1; }
            catch (\Throwable $e) { return false; }
        };
        $this->transport = $transport ?? static function (XmlStockRequestContext $ctx): array {
            return (new XmlStockIndexCheck())->checkIndexed('https://' . $ctx->domain(), null, null, true);
        };
    }

    /**
     * @return array {ok, disabled?, charged, usage_id, http, result?, classification?, replayed?, ambiguous?, error?}
     */
    public function execute(XmlStockRequestContext $ctx, ?string $uuid = null): array
    {
        $now = ($this->clock)();
        $nowS = $now->format('Y-m-d H:i:s');

        if (!($this->enabledCheck)()) {
            return ['ok' => false, 'disabled' => true, 'charged' => false, 'usage_id' => null, 'http' => 0, 'error' => 'xmlstock_disabled'];
        }

        $uuid = $uuid ?: $this->genUuid();

        // 1. reserve (идемпотентно по uuid).
        $res = $this->usage->reserve($ctx, $uuid, $nowS);
        $usageId = (int)($res['id'] ?? 0);
        if ($usageId <= 0) {
            return ['ok' => false, 'charged' => false, 'usage_id' => null, 'http' => 0, 'error' => 'usage_reserve_failed'];
        }

        // 2. duplicate uuid → обработка по execution_state (§11.4).
        if (empty($res['created_new'])) {
            $st = (string)($res['row']['execution_state'] ?? 'reserved');
            if ($st === 'completed') {
                $normalized = json_decode((string)($res['row']['normalized_result_json'] ?? ''), true) ?: [];
                return ['ok' => true, 'charged' => (int)($res['row']['assumed_charged'] ?? 1) === 1, 'usage_id' => $usageId,
                        'http' => 0, 'replayed' => true, 'result' => $normalized,
                        'classification' => BanMonitorDecision::classify($normalized)];
            }
            if ($st === 'started' || $st === 'ambiguous') {
                return ['ok' => false, 'charged' => true, 'usage_id' => $usageId, 'http' => 0, 'ambiguous' => true, 'error' => 'in_flight_' . $st];
            }
            // reserved / failed_before_http → пробуем claim ниже
        }

        // 3. claim reserved→started (только один worker).
        if (!$this->usage->claim($usageId, $nowS)) {
            return ['ok' => false, 'charged' => false, 'usage_id' => $usageId, 'http' => 0, 'error' => 'claim_lost'];
        }

        // 4. один HTTP.
        $t0 = microtime(true);
        try {
            $result = ($this->transport)($ctx);
        } catch (\Throwable $e) {
            // HTTP мог начаться (http_attempted=1) — исход неизвестен.
            $this->usage->markAmbiguous($usageId, $nowS, $e->getMessage());
            $this->usage->incrementQueriesToday();
            return ['ok' => false, 'charged' => true, 'usage_id' => $usageId, 'http' => 1, 'ambiguous' => true, 'error' => 'transport_exception'];
        }
        $durationMs = (int)round((microtime(true) - $t0) * 1000);

        // 5. классификация + complete + queries_today.
        // §2.4.2: HTTP выполнен → complete() ОБЯЗАН подтвердить запись completed в
        // ledger; только после этого результат применяется к monitor/pipeline.
        $cls = BanMonitorDecision::classify($result);
        $ledgerResult = ['positive' => 'indexed', 'valid_negative' => 'not_indexed', 'technical_error' => 'technical_error'][$cls];
        $err = (string)($result['error'] ?? '');
        $httpCode = preg_match('~http_(\d+)~', $err, $mm) ? (int)$mm[1] : (!empty($result['ok']) ? 200 : null);

        $completed = $this->usage->complete($usageId, [
            'result' => $ledgerResult, 'pages_indexed' => (int)($result['pages_indexed'] ?? 0),
            'http_code' => $httpCode, 'provider_code' => mb_substr($err !== '' ? $err : 'ok', 0, 64),
            'duration_ms' => $durationMs, 'message' => (string)($result['message'] ?? ''),
            'response_excerpt' => $this->safeExcerpt($result),
            'normalized_result_json' => json_encode($this->sanitize($result), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ], $nowS);
        $this->usage->incrementQueriesToday();
        if (!$completed) {
            // Ledger не сохранился: запрос ПОТЕНЦИАЛЬНО списан, но подтверждения нет.
            // → ambiguous; normal transition monitor НЕ выполняется; повторный платный
            // HTTP по тому же request_uuid запрещён (duplicate-ветка выше).
            $this->usage->markAmbiguous($usageId, $nowS, 'complete_write_unconfirmed');
            return ['ok' => false, 'charged' => true, 'usage_id' => $usageId, 'http' => 1,
                    'ambiguous' => true, 'error' => 'complete_write_unconfirmed'];
        }

        return ['ok' => true, 'charged' => true, 'usage_id' => $usageId, 'http' => 1, 'result' => $result, 'classification' => $cls, 'replayed' => false];
    }

    private function sanitize(array $r): array { unset($r['url'], $r['raw_excerpt']); return $r; }

    private function safeExcerpt(array $r): string
    {
        $s = (string)($r['message'] ?? '');
        $s = preg_replace('~(key|user|api[_-]?key)=[^\s&]+~i', '$1=***', $s);
        return mb_substr($s, 0, 1000);
    }

    private function genUuid(): string
    {
        $d = random_bytes(16);
        $d[6] = chr((ord($d[6]) & 0x0f) | 0x40);
        $d[8] = chr((ord($d[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4));
    }
}
