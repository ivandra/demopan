<?php

/**
 * XmlStockUsageRepository — единый журнал расхода XMLStock (xmlstock_request_log) с
 * exactly-once execution-state (reserved→started→completed/ambiguous/failed_before_http)
 * + совместимый инкремент queries_today (compatibility cache).
 */
class XmlStockUsageRepository
{
    private PDO $pdo;

    public function __construct(?PDO $pdo = null) { $this->pdo = $pdo ?? DB::pdo(); }

    /**
     * Резервирование строки ДО HTTP. Идемпотентно по request_uuid.
     * @return array ['created_new'=>bool, 'id'=>int, 'row'=>array|null]
     */
    public function reserve(XmlStockRequestContext $ctx, string $uuid, string $nowUtc): array
    {
        try {
            $st = $this->pdo->prepare(
                "INSERT INTO xmlstock_request_log
                   (request_uuid, requested_at, reserved_at, purpose, phase, initiated_by,
                    source_job_id, site_id, monitor_id, domain, sequence_no, status, execution_state)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?, 'reserved', 'reserved')"
            );
            $st->execute([
                $uuid, $nowUtc, $nowUtc, $ctx->purpose(), $ctx->phase(), $ctx->initiatedBy(),
                $ctx->sourceJobId(), $ctx->siteId(), $ctx->monitorId(), $ctx->domain(), $ctx->sequenceNo(),
            ]);
            $id = (int)$this->pdo->lastInsertId();
            return ['created_new' => true, 'id' => $id, 'row' => $this->byId($id)];
        } catch (\PDOException $e) {
            if ((int)($e->errorInfo[1] ?? 0) === 1062) {
                $row = $this->byUuid($uuid);
                return ['created_new' => false, 'id' => (int)($row['id'] ?? 0), 'row' => $row];
            }
            return ['created_new' => false, 'id' => 0, 'row' => null];
        } catch (\Throwable $e) {
            return ['created_new' => false, 'id' => 0, 'row' => null];
        }
    }

    /**
     * Claim перед HTTP (§11.5): reserved→started атомарно. rowCount()===1 обязателен —
     * только один worker получает право на HTTP. @return bool получен ли claim.
     */
    public function claim(int $id, string $nowUtc): bool
    {
        try {
            $st = $this->pdo->prepare(
                "UPDATE xmlstock_request_log
                    SET execution_state='started', status='started', started_at=?, http_attempted=1
                  WHERE id=? AND execution_state='reserved'"
            );
            $st->execute([$nowUtc, $id]);
            return $st->rowCount() === 1;
        } catch (\Throwable $e) { return false; }
    }

    /** Завершение после HTTP (§11.6): completed + normalized result + assumed_charged. */
    /**
     * §2.4.2: строгое подтверждение записи. UPDATE выполняется только из состояния
     * 'started' (тот же паттерн, что claim: reserved→started); true — ТОЛЬКО при
     * execute()=true И rowCount===1. rowCount=0 (строки нет / состояние уже не
     * started / конкурентное изменение) → false → вызывающий обязан пометить
     * запрос ambiguous и НЕ применять результат к monitor.
     */
    public function complete(int $id, array $f, string $nowUtc): bool
    {
        try {
            $st = $this->pdo->prepare(
                "UPDATE xmlstock_request_log SET
                    execution_state='completed', status='completed', completed_at=?,
                    result=?, pages_indexed=?, http_code=?, provider_code=?, duration_ms=?,
                    assumed_charged=1, message=?, response_excerpt=?, normalized_result_json=?
                 WHERE id=? AND execution_state='started'"
            );
            $ok = $st->execute([
                $nowUtc,
                $f['result'] ?? null, $f['pages_indexed'] ?? null, $f['http_code'] ?? null,
                $f['provider_code'] ?? null, $f['duration_ms'] ?? null,
                isset($f['message']) ? mb_substr((string)$f['message'], 0, 1000) : null,
                isset($f['response_excerpt']) ? mb_substr((string)$f['response_excerpt'], 0, 1000) : null,
                $f['normalized_result_json'] ?? null,
                $id,
            ]);
            return $ok && $st->rowCount() === 1;
        } catch (\Throwable $e) { return false; }
    }

    /** HTTP начался, но исход неизвестен (§11.6): ambiguous, без авто-повтора. */
    public function markAmbiguous(int $id, string $nowUtc, string $err): void
    {
        try {
            $this->pdo->prepare(
                "UPDATE xmlstock_request_log
                    SET execution_state='ambiguous', status='ambiguous', ambiguous_at=?, assumed_charged=1, transport_error=?
                  WHERE id=? AND execution_state <> 'completed'"
            )->execute([$nowUtc, mb_substr($err, 0, 1000), $id]);
        } catch (\Throwable $e) {}
    }

    /** HTTP не начинался — можно повторить claim позже (§11.4). */
    public function markFailedBeforeHttp(int $id, string $nowUtc, string $err): void
    {
        try {
            $this->pdo->prepare(
                "UPDATE xmlstock_request_log
                    SET execution_state='failed_before_http', status='failed_before_http', failed_before_http_at=?, transport_error=?
                  WHERE id=? AND http_attempted=0"
            )->execute([$nowUtc, mb_substr($err, 0, 1000), $id]);
        } catch (\Throwable $e) {}
    }

    public function byId(int $id): ?array
    {
        $s = $this->pdo->prepare("SELECT * FROM xmlstock_request_log WHERE id=?"); $s->execute([$id]);
        return $s->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    public function byUuid(string $uuid): ?array
    {
        $s = $this->pdo->prepare("SELECT * FROM xmlstock_request_log WHERE request_uuid=?"); $s->execute([$uuid]);
        return $s->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /** Совместимый инкремент верхнего дневного счётчика (только через central service). */
    public function incrementQueriesToday(): void
    {
        try {
            $this->pdo->prepare(
                "UPDATE xmlstock_settings
                    SET queries_today = IF(queries_today_date = CURDATE(), queries_today + 1, 1),
                        queries_today_date = CURDATE()
                  WHERE id = 1"
            )->execute();
        } catch (\Throwable $e) {}
    }

    public function queriesToday(): int
    {
        try {
            return (int)$this->pdo->query("SELECT IF(queries_today_date=CURDATE(), queries_today, 0) FROM xmlstock_settings WHERE id=1")->fetchColumn();
        } catch (\Throwable $e) { return 0; }
    }

    /**
     * Разбивка расхода за сегодня по purpose. «Всего фактически отправлено» =
     * только строки, где HTTP начинался (§16.3): completed + ambiguous.
     */
    public function breakdownToday(): array
    {
        $out = ['index_watching' => 0, 'final_monitoring' => 0, 'ban_monitoring' => 0, 'manual_test' => 0,
                'ambiguous' => 0, 'failed_before_http' => 0, 'charged_total' => 0];
        try {
            $st = $this->pdo->query(
                "SELECT purpose, execution_state, COUNT(*) c
                   FROM xmlstock_request_log
                  WHERE DATE(requested_at)=CURDATE()
                  GROUP BY purpose, execution_state"
            );
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $p = (string)$r['purpose']; $es = (string)$r['execution_state']; $c = (int)$r['c'];
                if (in_array($es, ['completed', 'ambiguous'], true)) {
                    if (isset($out[$p])) $out[$p] += $c;
                    $out['charged_total'] += $c;
                }
                if ($es === 'ambiguous') $out['ambiguous'] += $c;
                if ($es === 'failed_before_http') $out['failed_before_http'] += $c;
            }
        } catch (\Throwable $e) {}
        return $out;
    }

    public function monitorCounts(int $monitorId): array
    {
        try {
            $s = $this->pdo->prepare(
                "SELECT
                    SUM(CASE WHEN DATE(requested_at)=CURDATE() AND execution_state IN ('completed','ambiguous') THEN 1 ELSE 0 END) today,
                    SUM(CASE WHEN execution_state IN ('completed','ambiguous') THEN 1 ELSE 0 END) total
                 FROM xmlstock_request_log WHERE monitor_id=?"
            );
            $s->execute([$monitorId]);
            $r = $s->fetch(PDO::FETCH_ASSOC) ?: [];
            return ['today' => (int)($r['today'] ?? 0), 'total' => (int)($r['total'] ?? 0)];
        } catch (\Throwable $e) { return ['today' => 0, 'total' => 0]; }
    }

    public function recent(array $filters, int $page, int $pageSize): array
    {
        $page = max(1, $page); $pageSize = max(1, min(200, $pageSize));
        $where = []; $args = [];
        foreach (['purpose' => 'purpose=?', 'result' => 'result=?', 'execution_state' => 'execution_state=?', 'initiated_by' => 'initiated_by=?'] as $k => $cond) {
            if (!empty($filters[$k])) { $where[] = $cond; $args[] = $filters[$k]; }
        }
        if (!empty($filters['domain'])) { $where[] = 'domain LIKE ?'; $args[] = '%' . $filters['domain'] . '%'; }
        if (!empty($filters['job_id'])) { $where[] = 'source_job_id=?'; $args[] = (int)$filters['job_id']; }
        if (!empty($filters['monitor_id'])) { $where[] = 'monitor_id=?'; $args[] = (int)$filters['monitor_id']; }
        if (!empty($filters['since'])) { $where[] = 'requested_at>=?'; $args[] = $filters['since']; }
        $sql = 'SELECT * FROM xmlstock_request_log';
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $sql .= ' ORDER BY id DESC LIMIT ' . (int)$pageSize . ' OFFSET ' . (($page - 1) * $pageSize);
        try { $st = $this->pdo->prepare($sql); $st->execute($args); return $st->fetchAll(PDO::FETCH_ASSOC); }
        catch (\Throwable $e) { return []; }
    }
}
