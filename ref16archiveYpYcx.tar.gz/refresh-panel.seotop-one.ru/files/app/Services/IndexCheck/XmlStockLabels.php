<?php

/**
 * XmlStockLabels — единый источник русских подписей для enum-значений XMLStock и
 * ban-monitoring (§9). Views не должны дублировать словари; raw-код доступен
 * оператору через tooltip/details.
 */
final class XmlStockLabels
{
    public const MONITOR_STATE = [
        'waiting_initial_delay' => 'Ожидает первой проверки',
        'monitoring'            => 'В индексе, штатный контроль',
        'confirming'            => 'Подозрение, подтверждение',
        'insurance'             => 'Страховочные проверки',
        'paused'                => 'Пауза',
        'banned'                => 'Бан подтверждён',
        'stopped'               => 'Остановлен',
        'superseded'            => 'Заменён новым monitor',
    ];

    /** CSS-модификатор состояния монитора (для .xmlstock-monitor-state--*). */
    public const MONITOR_STATE_TONE = [
        'waiting_initial_delay' => 'info',
        'monitoring'            => 'ok',
        'confirming'            => 'warn',
        'insurance'             => 'warn',
        'paused'                => 'muted',
        'banned'                => 'danger',
        'stopped'               => 'muted',
        'superseded'            => 'muted',
    ];

    public const PURPOSE = [
        'index_watching'   => 'Ожидание первой индексации',
        'final_monitoring' => 'Финальный мониторинг переезда',
        'ban_monitoring'   => 'Мониторинг бана',
        'manual_test'      => 'Ручная проверка',
    ];

    public const RESULT = [
        'indexed'         => 'В индексе',
        'not_indexed'     => 'Не в индексе',
        'technical_error' => 'Техническая ошибка',
    ];

    public const EXECUTION_STATE = [
        'reserved'           => 'Зарезервирован',
        'started'            => 'Выполняется',
        'completed'          => 'Выполнен',
        'ambiguous'          => 'Неопределён (возможно списан)',
        'failed_before_http' => 'Сбой до запроса (не списан)',
    ];

    public const INITIATED_BY = [
        'cron'        => 'Автоматически',
        'operator'    => 'Оператор',
        'system_test' => 'Системный тест',
    ];

    public const PHASE = [
        'initial'    => 'Первая проверка',
        'monitoring' => 'Штатная',
        'confirming' => 'Подтверждающая',
        'insurance'  => 'Страховочная',
    ];

    public const ENROLLMENT_SOURCE = [
        'automatic'        => 'Автоматически (новая джоба)',
        'manual_bootstrap' => 'Подключён вручную',
    ];

    public const BLOCKED_REASON = [
        'xmlstock_disabled'   => 'XMLStock выключен',
        'processing_disabled' => 'Проверки приостановлены',
        'ambiguous'           => 'Неопределённый запрос — требуется внимание',
    ];

    public static function monitorState(?string $v): string { return self::MONITOR_STATE[(string)$v] ?? (string)$v; }
    public static function monitorTone(?string $v): string { return self::MONITOR_STATE_TONE[(string)$v] ?? 'muted'; }
    public static function purpose(?string $v): string { return self::PURPOSE[(string)$v] ?? (string)$v; }
    public static function result(?string $v): string { return $v === null || $v === '' ? '—' : (self::RESULT[(string)$v] ?? (string)$v); }
    public static function executionState(?string $v): string { return self::EXECUTION_STATE[(string)$v] ?? (string)$v; }
    public static function initiatedBy(?string $v): string { return $v === null || $v === '' ? '—' : (self::INITIATED_BY[(string)$v] ?? (string)$v); }
    public static function phase(?string $v): string { return $v === null || $v === '' ? '—' : (self::PHASE[(string)$v] ?? (string)$v); }
    public static function enrollmentSource(?string $v): string { return self::ENROLLMENT_SOURCE[(string)$v] ?? 'Автоматически (новая джоба)'; }
    public static function blockedReason(?string $v): string { return $v === null || $v === '' ? '' : (self::BLOCKED_REASON[(string)$v] ?? (string)$v); }
}
