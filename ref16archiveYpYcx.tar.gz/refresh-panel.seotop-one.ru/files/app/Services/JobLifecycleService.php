<?php

/**
 * JobLifecycleService — терминальные состояния джоб и атомарная замена.
 *
 * Решает исходную проблему: джоба в stage_status='awaiting_user' считалась
 * активной бессрочно и блокировала сайт для новых джоб. Обходить блокировку
 * в SQL нельзя — старая джоба остаётся исполняемой и может ожить параллельно
 * с новой. Поэтому вводится явное закрытие:
 *
 *   cancelled  — ручное закрытие без создания новой джобы (комментарий обязателен);
 *   superseded — старая закрыта и заменена новой (связь superseded_by_job_id).
 *
 * Ключевые гарантии:
 *
 *  - Заменять можно ТОЛЬКО джобу в stage_status='awaiting_user'. Работающую
 *    (running / pending / ok) закрывать нельзя: она может быть в середине
 *    записи по FTP, покупки домена или обращения к Вебмастеру.
 *  - Вся замена идёт в ОДНОЙ транзакции под блокировкой строки сайта
 *    (SELECT ... FOR UPDATE). Никаких внешних действий внутри транзакции:
 *    ни покупки домена, ни FTP, ни Вебмастера, ни XMLStock, ни Telegram.
 *  - При любой ошибке — полный откат: старая джоба не изменена, новая не создана,
 *    связь не записана.
 *  - Идемпотентность: повторный запрос по уже заменённой джобе возвращает
 *    ссылку на существующую новую джобу, а не создаёт ещё одну.
 *
 * Совместимо с PHP 7.4.
 */
class JobLifecycleService
{
    /** Терминальные значения stage — джоба закончена и возобновлению не подлежит. */
    const TERMINAL_STAGES = ['done', 'failed', 'cancelled', 'superseded'];

    /** Терминальные значения, введённые в v24. */
    const CLOSED_STAGES = ['cancelled', 'superseded'];

    /** Единственный статус, из которого разрешено закрытие оператором. */
    const CLOSABLE_STATUS = 'awaiting_user';

    /** v24.2 (H2): допустимые режимы новой джобы при замене. */
    const ALLOWED_MODES = ['refresh', 'move_indexed', 'move_simple'];

    /**
     * SQL-фрагмент со списком терминальных стадий.
     * Использовать во ВСЕХ выборках, способных возобновить джобу.
     */
    public static function terminalSqlList(): string
    {
        return "'" . implode("','", self::TERMINAL_STAGES) . "'";
    }

    public static function isTerminal(?string $stage): bool
    {
        return in_array((string)$stage, self::TERMINAL_STAGES, true);
    }

    public static function isClosed(?string $stage): bool
    {
        return in_array((string)$stage, self::CLOSED_STAGES, true);
    }

    /** Можно ли закрыть джобу оператором (вручную или с заменой). */
    public static function isClosable(array $job): bool
    {
        return !self::isTerminal((string)($job['stage'] ?? ''))
            && (string)($job['stage_status'] ?? '') === self::CLOSABLE_STATUS;
    }

    public static function stageLabel(string $stage): string
    {
        $map = ['cancelled' => 'Отменена', 'superseded' => 'Заменена новой'];
        return $map[$stage] ?? $stage;
    }

    /* ==================== РУЧНАЯ ОТМЕНА ==================== */

    /**
     * Закрыть джобу вручную, без создания новой.
     *
     * @return array ['ok'=>bool, 'error'=>string]
     */
    public static function cancel(int $jobId, string $comment, ?string $user): array
    {
        $comment = trim($comment);
        if ($comment === '') {
            return ['ok' => false, 'error' => 'Комментарий обязателен при отмене джобы'];
        }

        // v24.2 (B3): закрытие синхронизировано с cron через ТОТ ЖЕ advisory
        // lock `rfp_job_<id>`, который держат CronController и ручной runStep.
        // SELECT ... FOR UPDATE недостаточно: cron не держит row-lock на всём
        // протяжении внешних операций (FTP/Webmaster/XMLStock), поэтому без
        // job-lock'а закрытие могло вклиниться в середину обработки, а
        // последующий save cron'а — перезаписать терминальное состояние.
        $jobGuard = CronGuard::forJob($jobId);
        if (!$jobGuard->acquireJobLock()) {
            return ['ok' => false, 'error' =>
                'Джоба #' . $jobId . ' прямо сейчас обрабатывается (cron или ручной шаг). '
                . 'Подождите ~30 секунд и повторите.'];
        }

        $pdo = DB::pdo();
        $ownTx = !$pdo->inTransaction();
        if ($ownTx) $pdo->beginTransaction();

        try {
            // Перечитываем ПОСЛЕ получения lock'а — состояние могло измениться,
            // пока мы ждали (cron успел перевести стадию/статус).
            $job = self::lockJob($pdo, $jobId);
            if (!$job) {
                throw new \RuntimeException('Джоба не найдена');
            }
            if (self::isTerminal((string)$job['stage'])) {
                throw new \RuntimeException(
                    'Джоба уже завершена (стадия ' . $job['stage'] . ') — отменять нечего');
            }
            if ((string)$job['stage_status'] !== self::CLOSABLE_STATUS) {
                throw new \RuntimeException(
                    'Джоба ещё выполняется (статус ' . $job['stage_status'] . '). '
                    . 'Отмена доступна только для джоб, ожидающих действия оператора.');
            }

            $prevStage = (string)$job['stage'];
            // v24.2 (H5): терминальное состояние оформляем полностью —
            // stage_finished_at ставится, старый stage_error очищается, чтобы
            // карточка не показывала «ok» вместе с ошибкой прошлой попытки.
            $st = $pdo->prepare(
                "UPDATE refresh_jobs
                    SET stage = 'cancelled',
                        stage_status = 'ok',
                        stage_error = NULL,
                        stage_finished_at = NOW(),
                        closed_at = NOW(),
                        closed_by = ?,
                        closed_reason = ?,
                        next_run_at = NULL,
                        updated_at = NOW()
                  WHERE id = ?
                    AND stage NOT IN (" . self::terminalSqlList() . ")"
            );
            $st->execute([$user, mb_substr($comment, 0, 255), $jobId]);
            if ($st->rowCount() !== 1) {
                throw new \RuntimeException('Не удалось закрыть джобу (состояние изменилось)');
            }

            self::logEvent($pdo, $jobId, 'cancelled',
                'Джоба отменена оператором. Причина: ' . $comment,
                ['actor' => $user, 'old_stage' => $prevStage, 'new_stage' => 'cancelled',
                 'reason' => $comment, 'old_job_id' => $jobId]);

            // v24.2 (B5): закрытая move-джоба не должна оставлять «живой»
            // переезд — иначе он навсегда виснет в фоновом XMLStock-поллинге.
            self::closeLinkedRelocation($pdo, $jobId, $user,
                'Джоба #' . $jobId . ' отменена оператором: ' . $comment);

            if ($ownTx) $pdo->commit();

            // v25.0-a: probe-файл готовности удаляем ПОСЛЕ коммита (внешний FTP,
            // не под транзакцией). Отсутствие файла/ошибка FTP не влияют на закрытие.
            self::cleanupProbeFile($jobId);

            return ['ok' => true, 'error' => ''];

        } catch (\Throwable $e) {
            if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
            return ['ok' => false, 'error' => $e->getMessage()];
        } finally {
            $jobGuard->releaseJobLock();
        }
    }

    /* ==================== АТОМАРНАЯ ЗАМЕНА ==================== */

    /**
     * Закрыть старую джобу и создать новую — одной транзакцией.
     *
     * @param array $newJob параметры новой джобы:
     *        site_id, old_domain, old_sub_id, new_sub_id,
     *        webmaster_account_override_id, mode, next_run_at, artifacts_json
     * @return array ['ok'=>bool,'new_job_id'=>int,'already'=>bool,'error'=>string]
     */
    public static function supersedeAndCreate(
        int $oldJobId, array $newJob, ?string $user, string $comment = ''
    ): array {
        // v24.2 (H2): режим новой джобы валидируется в сервисе, а не только
        // в форме — прямой POST с произвольным mode не должен создать джобу,
        // которую оркестратор не умеет вести.
        $mode = (string)($newJob['mode'] ?? 'refresh');
        if (!in_array($mode, self::ALLOWED_MODES, true)) {
            return ['ok' => false, 'new_job_id' => 0, 'already' => false,
                    'error' => 'Недопустимый режим новой джобы: ' . $mode];
        }

        // v24.2 (B3): тот же advisory lock, что у cron/runStep — см. cancel().
        $jobGuard = CronGuard::forJob($oldJobId);
        if (!$jobGuard->acquireJobLock()) {
            return ['ok' => false, 'new_job_id' => 0, 'already' => false,
                    'error' => 'Джоба #' . $oldJobId
                        . ' прямо сейчас обрабатывается (cron или ручной шаг). '
                        . 'Подождите ~30 секунд и повторите.'];
        }

        $pdo = DB::pdo();
        $ownTx = !$pdo->inTransaction();
        if ($ownTx) $pdo->beginTransaction();

        try {
            // 1. Блокируем строку сайта — сериализует параллельные попытки.
            $siteId = (int)($newJob['site_id'] ?? 0);
            if ($siteId < 1) {
                throw new \RuntimeException('Не указан сайт');
            }
            $lockSite = $pdo->prepare("SELECT id FROM sites_managed WHERE id = ? FOR UPDATE");
            $lockSite->execute([$siteId]);
            if (!$lockSite->fetchColumn()) {
                throw new \RuntimeException('Сайт не найден');
            }

            // 2. Перечитываем старую джобу уже под блокировкой.
            $old = self::lockJob($pdo, $oldJobId);
            if (!$old) {
                throw new \RuntimeException('Старая джоба не найдена');
            }

            // 3. Идемпотентность: замена уже выполнена — возвращаем существующую.
            if ((string)$old['stage'] === 'superseded' && !empty($old['superseded_by_job_id'])) {
                if ($ownTx) $pdo->commit();
                return [
                    'ok' => true,
                    'new_job_id' => (int)$old['superseded_by_job_id'],
                    'already' => true,
                    'error' => '',
                ];
            }

            // 4. Состояние могло измениться, пока ждали блокировку.
            if (self::isTerminal((string)$old['stage'])) {
                throw new \RuntimeException(
                    'Старая джоба уже завершена (стадия ' . $old['stage'] . ')');
            }
            if ((string)$old['stage_status'] !== self::CLOSABLE_STATUS) {
                throw new \RuntimeException(
                    'Старая джоба ещё выполняется (статус ' . $old['stage_status'] . '). '
                    . 'Замена возможна только для джоб, ожидающих действия оператора.');
            }
            if ((int)$old['site_id'] !== $siteId) {
                throw new \RuntimeException('Старая джоба относится к другому сайту');
            }

            // 5. Нет ли ДРУГОЙ активной джобы этого сайта (кроме заменяемой).
            $others = $pdo->prepare(
                "SELECT id FROM refresh_jobs
                  WHERE site_id = ? AND id <> ?
                    AND stage NOT IN (" . self::terminalSqlList() . ")
                  LIMIT 1"
            );
            $others->execute([$siteId, $oldJobId]);
            $otherId = (int)$others->fetchColumn();
            if ($otherId > 0) {
                throw new \RuntimeException(
                    'У сайта есть ещё одна активная джоба #' . $otherId . ' — замена невозможна');
            }

            // 6. Создаём новую джобу. До COMMIT она невидима другим процессам.
            $ins = $pdo->prepare(
                "INSERT INTO refresh_jobs
                    (site_id, old_domain, new_domain, old_sub_id, new_sub_id,
                     webmaster_account_override_id, mode,
                     stage, stage_status, next_run_at, artifacts_json, created_at,
                     pipeline_revision, trusted_ssl_gate_required)
                 VALUES (?, ?, '', ?, ?, ?, ?, 'queued', 'pending', ?, ?, NOW(),
                         'ssl_before_webmaster_v1', 1)"
            );
            $ins->execute([
                $siteId,
                (string)($newJob['old_domain'] ?? ''),
                (string)($newJob['old_sub_id'] ?? ''),
                (string)($newJob['new_sub_id'] ?? ''),
                $newJob['webmaster_account_override_id'] ?? null,
                (string)($newJob['mode'] ?? 'refresh'),
                $newJob['next_run_at'] ?? null,
                $newJob['artifacts_json'] ?? null,
            ]);
            $newJobId = (int)$pdo->lastInsertId();
            if ($newJobId < 1) {
                throw new \RuntimeException('Не удалось создать новую джобу');
            }

            // §7: eligibility ban-monitoring в общем пути создания (тот же $pdo/транзакция).
            try { (new BanMonitoringSettingsRepository($pdo))->assignEligibility($newJobId); }
            catch (\Throwable $e) { error_log('[ban-monitor eligibility] ' . $e->getMessage()); }

            // 7. Закрываем старую и записываем связь.
            $reason = 'Заменена джобой #' . $newJobId;
            if (trim($comment) !== '') {
                $reason .= '. ' . trim($comment);
            }
            $prevStage = (string)$old['stage'];

            $upd = $pdo->prepare(
                "UPDATE refresh_jobs
                    SET stage = 'superseded',
                        stage_status = 'ok',
                        stage_error = NULL,
                        stage_finished_at = NOW(),
                        superseded_by_job_id = ?,
                        closed_at = NOW(),
                        closed_by = ?,
                        closed_reason = ?,
                        next_run_at = NULL,
                        updated_at = NOW()
                  WHERE id = ?
                    AND stage NOT IN (" . self::terminalSqlList() . ")"
            );
            $upd->execute([$newJobId, $user, mb_substr($reason, 0, 255), $oldJobId]);
            if ($upd->rowCount() !== 1) {
                // Кто-то успел закрыть джобу между шагами — откатываем всё.
                throw new \RuntimeException('Не удалось закрыть старую джобу (состояние изменилось)');
            }

            // 8. История в обеих джобах.
            self::logEvent($pdo, $oldJobId, 'superseded',
                'Джоба закрыта и заменена новой #' . $newJobId . '. ' . $reason,
                ['actor' => $user, 'old_stage' => $prevStage, 'new_stage' => 'superseded',
                 'reason' => $reason, 'old_job_id' => $oldJobId, 'new_job_id' => $newJobId]);

            self::logEvent($pdo, $newJobId, 'superseded',
                'Джоба создана взамен закрытой #' . $oldJobId,
                ['actor' => $user, 'reason' => $reason,
                 'old_job_id' => $oldJobId, 'new_job_id' => $newJobId]);

            // v24.2 (B5): переезд СТАРОЙ джобы закрывается вместе с ней.
            // Для новой move-джобы контроллер создаст СВОЮ запись после
            // коммита — одновременного поллинга старой и новой не будет.
            self::closeLinkedRelocation($pdo, $oldJobId, $user,
                'Джоба #' . $oldJobId . ' заменена джобой #' . $newJobId);

            if ($ownTx) $pdo->commit();

            // v25.0-a: probe-файл старой (закрытой) джобы больше не нужен.
            self::cleanupProbeFile($oldJobId);

            return ['ok' => true, 'new_job_id' => $newJobId, 'already' => false, 'error' => ''];

        } catch (\Throwable $e) {
            if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
            return ['ok' => false, 'new_job_id' => 0, 'already' => false, 'error' => $e->getMessage()];
        } finally {
            $jobGuard->releaseJobLock();
        }
    }

    /* ==================== ЗАЩИТА ОТ ВОЗОБНОВЛЕНИЯ ==================== */

    /**
     * Проверка перед любым действием, способным возобновить джобу
     * (retry, runStep, acknowledgeDelurl, ручное «Продолжить» и т. п.).
     *
     * @return string|null текст отказа либо null, если действие допустимо
     */
    public static function denyResumeReason(array $job): ?string
    {
        $stage = (string)($job['stage'] ?? '');
        if (!self::isClosed($stage)) {
            return null;
        }

        if ($stage === 'superseded') {
            $newId = (int)($job['superseded_by_job_id'] ?? 0);
            return 'Джоба закрыта и заменена новой'
                 . ($newId > 0 ? (' #' . $newId) : '')
                 . '. Возобновить её нельзя — работайте с новой джобой.';
        }

        return 'Джоба отменена оператором'
             . (!empty($job['closed_reason']) ? (': ' . $job['closed_reason']) : '')
             . '. Возобновить её нельзя.';
    }

    /**
     * v25.0-a: удалить probe-файл готовности домена при закрытии джобы.
     * Best-effort: класс может отсутствовать (патч readiness не установлен) —
     * тогда просто пропускаем. Ошибки FTP не влияют на lifecycle.
     */
    private static function cleanupProbeFile(int $jobId): void
    {
        try {
            if (class_exists('ProbeFileManager')) {
                (new ProbeFileManager())->removeForJob($jobId, null);
            }
        } catch (\Throwable $e) {
            error_log("cleanupProbeFile({$jobId}) failed: " . $e->getMessage());
        }
    }

    /* ==================== СЛУЖЕБНОЕ ==================== */

    /**
     * v24.2 (B5): отменить связанную запись переезда при закрытии джобы.
     *
     * Выполняется в ТОЙ ЖЕ транзакции (только UPDATE, без внешних вызовов).
     * Правила:
     *  - подтверждённый Яндексом переезд (move_completed_at) не трогаем —
     *    история завершена и остаётся как есть;
     *  - уже отменённый — не трогаем (идемпотентность);
     *  - остальные (включая ожидающие первую индексацию) получают
     *    cancelled_at и тем самым выпадают из фонового XMLStock-поллинга.
     *
     * Отсутствие таблицы (миграция 023 ещё не применена) не должно ломать
     * закрытие джобы — тогда и записей переезда быть не может.
     */
    private static function closeLinkedRelocation(PDO $pdo, int $jobId, ?string $user, string $reason): void
    {
        try {
            $st = $pdo->prepare(
                "UPDATE site_relocations
                    SET cancelled_at = NOW(),
                        cancelled_by = ?,
                        comment = CASE
                            WHEN comment IS NULL OR comment = '' THEN ?
                            ELSE CONCAT(comment, ' | ', ?)
                        END,
                        updated_by = ?,
                        updated_at = NOW()
                  WHERE job_id = ?
                    AND cancelled_at IS NULL
                    AND move_completed_at IS NULL"
            );
            $reason = mb_substr($reason, 0, 500);
            $st->execute([$user, $reason, $reason, $user, $jobId]);
            if ($st->rowCount() > 0) {
                self::logEvent($pdo, $jobId, 'relocation_autoclosed',
                    'Учёт переезда отменён вместе с закрытием джобы. ' . $reason,
                    ['actor' => $user, 'reason' => $reason, 'old_job_id' => $jobId]);
            }
        } catch (\Throwable $e) {
            $msg = $e->getMessage();
            $tableMissing = (stripos($msg, 'site_relocations') !== false)
                && (stripos($msg, "doesn't exist") !== false || stripos($msg, 'not exist') !== false);
            if (!$tableMissing) {
                // Ошибку НЕ глотаем: закрытие джобы без закрытия переезда
                // оставит платный поллинг — пусть транзакция откатится.
                throw $e;
            }
        }
    }

    /** Прочитать джобу с блокировкой строки. */
    private static function lockJob(PDO $pdo, int $jobId): ?array
    {
        $st = $pdo->prepare("SELECT * FROM refresh_jobs WHERE id = ? FOR UPDATE");
        $st->execute([$jobId]);
        $row = $st->fetch();
        return is_array($row) ? $row : null;
    }

    /**
     * Событие в журнал джобы. Пишется той же транзакцией — при откате
     * история тоже откатывается, «висячих» записей не остаётся.
     */
    private static function logEvent(PDO $pdo, int $jobId, string $action, string $message, array $payload): void
    {
        $st = $pdo->prepare(
            "INSERT INTO refresh_job_events (job_id, stage, level, message, payload_json, created_at)
             VALUES (?, 'lifecycle', 'info', ?, ?, NOW())"
        );
        $st->execute([
            $jobId,
            $message,
            json_encode(array_merge(['action' => $action], $payload),
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);
    }

    /* ==================== v25.2-a1.6.4: AWAITING_USER_SINCE ==================== */

    /**
     * Единый helper: пометить джобу как ожидающую оператора. Ставит
     * awaiting_user_since = COALESCE(awaiting_user_since, NOW()) — при повторных
     * технических проверках НЕ сбрасывает уже идущий период ожидания.
     * Вызывать в местах перехода в awaiting_user; но корректность гарантируется и
     * без этого — reconcileAwaitingSince() чинит поле централизованно.
     */
    public static function markAwaitingUser(PDO $pdo, int $jobId): void
    {
        try {
            if (!self::hasAwaitingSinceColumn($pdo)) return;
            $pdo->prepare(
                "UPDATE refresh_jobs
                    SET awaiting_user_since = COALESCE(awaiting_user_since, NOW())
                  WHERE id = ? AND stage_status = 'awaiting_user'
                    AND stage NOT IN (" . self::terminalSqlList() . ")"
            )->execute([$jobId]);
        } catch (\Throwable $e) { /* поле опционально */ }
    }

    /**
     * Самовосстанавливающееся сопровождение awaiting_user_since. Не полагается на
     * то, что каждый разбросанный UPDATE заполнил поле:
     *   - для строк, которые СЕЙЧАС awaiting_user (нетерминальные) и не имеют
     *     awaiting_user_since — ставит NOW() (начало непрерывного ожидания);
     *   - для строк, которые уже НЕ awaiting_user (возобновлены/терминальны) —
     *     очищает awaiting_user_since (следующий простой начнёт отсчёт заново).
     */
    public static function reconcileAwaitingSince(): void
    {
        $pdo = DB::pdo();
        try {
            if (!self::hasAwaitingSinceColumn($pdo)) return;
            $pdo->exec(
                "UPDATE refresh_jobs
                    SET awaiting_user_since = NOW()
                  WHERE stage_status = 'awaiting_user'
                    AND stage NOT IN (" . self::terminalSqlList() . ")
                    AND awaiting_user_since IS NULL"
            );
            $pdo->exec(
                "UPDATE refresh_jobs
                    SET awaiting_user_since = NULL
                  WHERE awaiting_user_since IS NOT NULL
                    AND (stage_status <> 'awaiting_user'
                         OR stage IN (" . self::terminalSqlList() . "))"
            );
        } catch (\Throwable $e) { /* поле опционально */ }
    }

    private static $awaitingCol = null;
    private static function hasAwaitingSinceColumn(PDO $pdo): bool
    {
        if (self::$awaitingCol !== null) return self::$awaitingCol;
        try {
            $st = $pdo->query("SHOW COLUMNS FROM refresh_jobs LIKE 'awaiting_user_since'");
            self::$awaitingCol = (bool)($st && $st->fetch());
        } catch (\Throwable $e) { self::$awaitingCol = false; }
        return self::$awaitingCol;
    }

    /**
     * v25.2-a1.6.4: авто-закрытие джоб после N дней непрерывного ожидания оператора.
     *
     *   old_delurl_notify → done/ok  (необязательное ручное удаление URL не сделано);
     *   остальные awaiting_user → cancelled/ok (месяц без действий оператора).
     *
     * Каждая джоба закрывается под настоящим rfp_job_<id> lock + транзакция +
     * SELECT ... FOR UPDATE + повторная проверка (защита от гонки с cron/оператором).
     * Move-джоба закрывает связанный незавершённый переезд. Возвращает список
     * закрытых: [['id','domain','idle_days','target']...].
     *
     * @return array{closed: array<int,array>, count: int, scanned: int}
     */
    public static function autoCloseInactiveJobs(int $days = 30, int $limit = 50): array
    {
        $days = max(1, min(365, $days));
        $limit = max(1, min(200, $limit));
        $closed = [];
        $scanned = 0;

        // Поддерживаем поле перед выборкой кандидатов.
        self::reconcileAwaitingSince();

        $pdo = DB::pdo();
        if (!self::hasAwaitingSinceColumn($pdo)) {
            return ['closed' => [], 'count' => 0, 'scanned' => 0];
        }

        $sel = $pdo->prepare(
            "SELECT id FROM refresh_jobs
              WHERE stage_status = 'awaiting_user'
                AND stage NOT IN (" . self::terminalSqlList() . ")
                AND awaiting_user_since IS NOT NULL
                AND awaiting_user_since <= DATE_SUB(NOW(), INTERVAL ? DAY)
              ORDER BY awaiting_user_since ASC
              LIMIT " . (int)$limit
        );
        $sel->bindValue(1, $days, PDO::PARAM_INT);
        $sel->execute();
        $ids = array_map('intval', array_column($sel->fetchAll(PDO::FETCH_ASSOC), 'id'));

        foreach ($ids as $jobId) {
            $scanned++;
            $guard = CronGuard::forJob($jobId);
            if (!$guard->acquireJobLock()) {
                // Гонка с cron/оператором — пропускаем, повторим в следующий час.
                continue;
            }
            $ownTx = !$pdo->inTransaction();
            try {
                if ($ownTx) $pdo->beginTransaction();
                $job = self::lockJob($pdo, $jobId); // SELECT ... FOR UPDATE
                if (!$job) { if ($ownTx && $pdo->inTransaction()) $pdo->rollBack(); continue; }

                // Повторная проверка ПОД локом (оператор мог возобновить).
                if (self::isTerminal((string)$job['stage'])
                    || (string)$job['stage_status'] !== self::CLOSABLE_STATUS
                    || empty($job['awaiting_user_since'])
                    || strtotime((string)$job['awaiting_user_since']) > time() - $days * 86400) {
                    if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
                    continue;
                }

                $prevStage = (string)$job['stage'];
                $prevStatus = (string)$job['stage_status'];
                $prevError = (string)($job['stage_error'] ?? '');
                $idleDays = (int)floor((time() - strtotime((string)$job['awaiting_user_since'])) / 86400);
                $isFinalOptional = ($prevStage === 'old_delurl_notify');

                if ($isFinalOptional) {
                    $targetStage = 'done';
                    $reason = "Автозавершение: оператор не подтвердил удаление старых URL за {$days} дней";
                } else {
                    $targetStage = 'cancelled';
                    $reason = "Автоотмена после {$days} дней непрерывного ожидания оператора"
                        . " (стадия: {$prevStage}"
                        . ($prevError !== '' ? "; ошибка: " . mb_substr($prevError, 0, 200) : '')
                        . ")";
                }

                $lifecycle = json_encode(['lifecycle' => [
                    'auto_closed' => true,
                    'auto_closed_at' => date('Y-m-d H:i:s'),
                    'auto_close_days' => $days,
                    'previous_stage' => $prevStage,
                    'previous_status' => $prevStatus,
                    'idle_days' => $idleDays,
                ]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

                $upd = $pdo->prepare(
                    "UPDATE refresh_jobs
                        SET stage = ?, stage_status = 'ok', stage_error = NULL,
                            stage_finished_at = NOW(), closed_at = NOW(),
                            closed_by = 'system:auto_close', closed_reason = ?,
                            awaiting_user_since = NULL, next_run_at = NULL, updated_at = NOW(),
                            artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                      WHERE id = ? AND stage NOT IN (" . self::terminalSqlList() . ")"
                );
                $upd->execute([$targetStage, mb_substr($reason, 0, 255), $lifecycle, $jobId]);
                if ($upd->rowCount() !== 1) {
                    if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
                    continue;
                }

                self::logEvent($pdo, $jobId, 'auto_closed',
                    ($isFinalOptional ? 'Джоба автозавершена' : 'Джоба автоотменена')
                        . " системой после {$idleDays} дней ожидания оператора. " . $reason,
                    ['actor' => 'system:auto_close', 'old_stage' => $prevStage,
                     'new_stage' => $targetStage, 'idle_days' => $idleDays, 'auto_close_days' => $days]);

                // Незавершённый переезд закрываем только для отменённых (для done —
                // переезд состоялся, move_completed_at выставлен и не трогается).
                if (!$isFinalOptional) {
                    self::closeLinkedRelocation($pdo, $jobId, 'system:auto_close',
                        "Джоба #{$jobId} автоотменена после {$idleDays} дней ожидания.");
                }

                if ($ownTx) $pdo->commit();

                self::cleanupProbeFile($jobId);

                $closed[] = [
                    'id' => $jobId,
                    'domain' => (string)($job['new_domain'] ?? ''),
                    'site_id' => $job['site_id'] !== null ? (int)$job['site_id'] : null,
                    'idle_days' => $idleDays,
                    'target' => $targetStage,
                ];
            } catch (\Throwable $e) {
                if ($ownTx && $pdo->inTransaction()) $pdo->rollBack();
                error_log("autoCloseInactiveJobs(#{$jobId}) failed: " . $e->getMessage());
            } finally {
                $guard->releaseJobLock();
            }
        }

        return ['closed' => $closed, 'count' => count($closed), 'scanned' => $scanned];
    }
}
