<?php
/**
 * 038_ssl_before_webmaster_and_xmlstock_ui — durable-состояние P0 «trusted SSL до
 * Webmaster» + источник подключения monitor для достоверного UI.
 *
 * Forward-only, идемпотентная. НЕ трогает: таблицы/данные 036/037, существующие
 * monitor (state/snapshot/generation), джобы и их стадии; не делает XMLStock HTTP,
 * не создаёт monitor, не выполняет Webmaster-вызовы, не переводит исторические
 * джобы на новую revision (это делает ленивая активация в оркестраторе — только
 * для нетерминальных джоб ДО wm_account_resolve, см. RefreshOrchestrator).
 *
 * Добавляет:
 *   refresh_jobs.pipeline_revision            VARCHAR(64) NULL
 *   refresh_jobs.trusted_ssl_gate_required    TINYINT(1) NOT NULL DEFAULT 0
 *   refresh_jobs.trusted_ssl_gate_completed_at DATETIME NULL
 *   site_ban_monitors.enrollment_source       VARCHAR(32) NOT NULL DEFAULT 'automatic'
 *
 * Разовая разметка данных (идемпотентно, без создания строк): мониторы, подключённые
 * ручным bootstrap (по strict-audit ban_bootstrap_job), получают
 * enrollment_source='manual_bootstrap'.
 */

$colMissing = function (PDO $pdo, string $table, string $col): bool {
    $st = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $st->execute([$table, $col]);
    return (int)$st->fetchColumn() === 0;
};

return [
    'up' => [
        // --- refresh_jobs: durable SSL-gate state ---
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'refresh_jobs', 'pipeline_revision')) {
                $pdo->exec("ALTER TABLE refresh_jobs ADD COLUMN pipeline_revision VARCHAR(64) NULL DEFAULT NULL");
            }
        },
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'refresh_jobs', 'trusted_ssl_gate_required')) {
                $pdo->exec("ALTER TABLE refresh_jobs ADD COLUMN trusted_ssl_gate_required TINYINT(1) NOT NULL DEFAULT 0");
            }
        },
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'refresh_jobs', 'trusted_ssl_gate_completed_at')) {
                $pdo->exec("ALTER TABLE refresh_jobs ADD COLUMN trusted_ssl_gate_completed_at DATETIME NULL DEFAULT NULL");
            }
        },
        // --- site_ban_monitors: источник подключения ---
        function (PDO $pdo) use ($colMissing) {
            if ($colMissing($pdo, 'site_ban_monitors', 'enrollment_source')) {
                $pdo->exec("ALTER TABLE site_ban_monitors ADD COLUMN enrollment_source VARCHAR(32) NOT NULL DEFAULT 'automatic'");
            }
        },
        // --- разметка ручных bootstrap-мониторов по strict-audit (идемпотентно) ---
        function (PDO $pdo) {
            $pdo->exec(
                "UPDATE site_ban_monitors m
                   JOIN ban_monitoring_audit a
                     ON a.action = 'ban_bootstrap_job'
                    AND a.object_type = 'refresh_job'
                    AND a.object_id = m.source_job_id
                    SET m.enrollment_source = 'manual_bootstrap'
                  WHERE m.enrollment_source <> 'manual_bootstrap'"
            );
        },
    ],
    'down' => [
        function (PDO $pdo) use ($colMissing) {
            if (!$colMissing($pdo, 'refresh_jobs', 'trusted_ssl_gate_completed_at')) {
                $pdo->exec("ALTER TABLE refresh_jobs DROP COLUMN trusted_ssl_gate_completed_at");
            }
            if (!$colMissing($pdo, 'refresh_jobs', 'trusted_ssl_gate_required')) {
                $pdo->exec("ALTER TABLE refresh_jobs DROP COLUMN trusted_ssl_gate_required");
            }
            if (!$colMissing($pdo, 'refresh_jobs', 'pipeline_revision')) {
                $pdo->exec("ALTER TABLE refresh_jobs DROP COLUMN pipeline_revision");
            }
            if (!$colMissing($pdo, 'site_ban_monitors', 'enrollment_source')) {
                $pdo->exec("ALTER TABLE site_ban_monitors DROP COLUMN enrollment_source");
            }
        },
    ],
];
