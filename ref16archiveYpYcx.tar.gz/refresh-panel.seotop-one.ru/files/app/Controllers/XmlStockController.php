<?php

/**
 * v18.1.37 — Страница контроля XMLStock.
 *
 * Отдельный экран для управления расходом lim на xmlstock.com:
 *   - статистика: баланс, запросы за сегодня / дневной лимит, последняя валидация;
 *   - список джоб, которые ПРЯМО СЕЙЧАС тратят xmlstock (стадии index_watching /
 *     final_monitoring) — с оценкой запросов в сутки на каждую;
 *   - глобальный стоп-кран: выключить xmlstock (enabled=0). Тогда проверка
 *     индексации уходит на бесплатный Webmaster-фолбэк (IndexCheckOrchestrator),
 *     пайплайн НЕ ломается, платные запросы прекращаются;
 *   - пауза/возобновление опроса по каждой джобе (и «пауза всех»).
 *
 * Механика паузы: НЕ требует новых столбцов и не трогает cron-логику.
 * CronGuard::pickJobs берёт джобу только если next_run_at <= NOW(). Ставим
 * next_run_at в далёкое будущее (PAUSE_UNTIL) — джоба перестаёт тикать и не
 * тратит xmlstock. Возобновление — next_run_at = NOW(). Пауза применяется
 * ТОЛЬКО к polling-стадиям, чтобы не заморозить обычный pipeline.
 */
class XmlStockController extends Controller
{
    /** Sentinel — next_run_at этого значения означает «на паузе». */
    private const PAUSE_UNTIL = '2999-01-01 00:00:00';
    /** Порог, выше которого считаем джобу поставленной на паузу (обычный backoff ≤ 24ч). */
    private const PAUSE_DETECT_AFTER = '2900-01-01 00:00:00';

    /** Стадии, которые реально расходуют xmlstock. */
    private const POLLING_STAGES = ['index_watching', 'final_monitoring'];

    public function index(): void
    {
        $this->requireAuth();

        // §6.2.C: активная вкладка (серверный параметр, сохраняется после POST-redirect).
        $tab = (string)($_GET['tab'] ?? 'overview');
        if (!in_array($tab, ['overview', 'monitors', 'history', 'settings'], true)) $tab = 'overview';

        $q = new XmlStockDashboardQueryService();

        // Legacy polling-джобы (index_watching/final_monitoring): существующая механика
        // decoratePoller сохранена — она знает паузу/оценку по артефактам.
        $pollers = [];
        try {
            $in = "'" . implode("','", self::POLLING_STAGES) . "'";
            $rows = DB::pdo()->query(
                "SELECT id, old_domain, new_domain, stage, stage_status, mode,
                        stage_started_at, next_run_at, artifacts_json
                 FROM refresh_jobs
                 WHERE stage IN ($in) AND stage NOT IN ('done','failed','cancelled','superseded')
                 ORDER BY id ASC"
            )->fetchAll() ?: [];
            foreach ($rows as $r) $pollers[] = $this->decoratePoller($r);
            $pollersOk = true;
        } catch (\Throwable $e) { $pollersOk = false; }
        $estPerDay = 0;
        foreach ($pollers as $p) { if (!$p['paused'] && !$p['stopped']) $estPerDay += $p['est_per_day']; }

        // §9: read-model блоки (каждый с ok-флагом; ошибки не превращаются в «0»).
        $summary    = $q->summary();
        $consumers  = $q->consumersToday();
        $forecast   = $q->forecast($pollers, (int)$estPerDay);
        $activation = $q->banActivationSummary();
        $monitorsActive   = $q->monitors(false);
        $monitorsTerminal = $q->monitors(true);
        $nextScheduled    = $q->nextScheduledRequests($pollers, 5);
        $alerts = $q->alerts($summary, $activation);
        if (!$pollersOk) $alerts[] = ['level' => 'error', 'text' => 'Не удалось получить список polling-джоб.'];

        // Последние проверки для раскрытия строк активных мониторов.
        $monitorChecks = [];
        foreach (($monitorsActive['rows'] ?? []) as $m) {
            $monitorChecks[(int)$m['id']] = $q->monitorChecks((int)$m['id'], 8)['rows'];
        }

        // §6.2.H: история с фильтрами + total.
        $histFilters = [
            'period'     => (string)($_GET['period'] ?? 'today'),
            'purpose'    => trim((string)($_GET['purpose'] ?? '')) ?: null,
            'domain'     => trim((string)($_GET['domain'] ?? '')) ?: null,
            'job_id'     => (int)($_GET['job_id'] ?? 0) ?: null,
            'monitor_id' => (int)($_GET['monitor_id'] ?? 0) ?: null,
            'result'     => trim((string)($_GET['result'] ?? '')) ?: null,
            'execution_state' => trim((string)($_GET['execution_state'] ?? '')) ?: null,
            'initiated_by'    => trim((string)($_GET['initiated_by'] ?? '')) ?: null,
        ];
        $histFilters['since'] = $this->periodSince($histFilters['period']);
        $histPage = max(1, (int)($_GET['page'] ?? 1));
        $history = $q->requestHistory($histFilters, $histPage, 50);

        // PATCH_2: активация / policy (для форм настроек).
        $setRepo = new BanMonitoringSettingsRepository();
        $settings = $setRepo->get();
        $policy = $setRepo->policy();
        $notifFailed = (new BanMonitorNotificationRepository())->failedCount();

        $this->view('xmlstock/index', [
            'tab'          => $tab,
            'xs'           => $summary['settings'] ?? [],
            'summary'      => $summary,
            'consumers'    => $consumers,
            'forecast'     => $forecast,
            'activation'   => $activation,
            'alerts'       => $alerts,
            'balance'      => $summary['balance'] ?? null,
            'pollers'      => $pollers,
            'estPerDay'    => $estPerDay,
            'pauseSentinel'=> self::PAUSE_UNTIL,
            'monitorsActive'   => $monitorsActive,
            'monitorsTerminal' => $monitorsTerminal,
            'monitorChecks'    => $monitorChecks,
            'nextScheduled'    => $nextScheduled,
            'history'      => $history,
            'histFilters'  => $histFilters,
            'histPage'     => $histPage,
            'highlightMonitorId' => (int)($_GET['monitor_id'] ?? 0),
            'banSettings'  => $settings,
            'banPolicy'    => $policy,
            'banNotifFailed'   => $notifFailed,
            'csrfToken'    => $this->csrfToken(),
        ]);
    }

    /** §6.2.C: после POST возвращаемся на ту же вкладку (hidden tab в формах). */
    private function redirectTab(string $default = 'overview'): void
    {
        $tab = (string)($_POST['tab'] ?? $default);
        if (!in_array($tab, ['overview', 'monitors', 'history', 'settings'], true)) $tab = $default;
        $this->redirect('/xmlstock?tab=' . $tab);
    }

    private function periodSince(string $period): ?string
    {
        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        switch ($period) {
            case '24h':  return $now->modify('-24 hours')->format('Y-m-d H:i:s');
            case '7d':   return $now->modify('-7 days')->format('Y-m-d H:i:s');
            case 'all':  return null;
            case 'today':
            default:     return $now->format('Y-m-d') . ' 00:00:00';
        }
    }

    // ───────────── ручные действия ban-monitor (§10.4, CSRF + audit) ─────────────

    /** Прямая atomic-audit запись (§13): critical state не коммитится без audit. */
    private function auditMonitor(PDO $pdo, array $m, string $event, string $comment): void
    {
        $sourceJob = (int)($m['source_job_id'] ?? 0);
        if ($sourceJob <= 0) return;
        $st = $pdo->prepare(
            "INSERT INTO refresh_job_events (job_id, stage, level, message, payload_json)
             VALUES (?, 'ban_monitoring', 'warn', ?, ?)"
        );
        $ok = $st->execute([
            $sourceJob,
            $event . '. monitor #' . (int)$m['id'] . ' ' . (string)$m['domain'] . ($comment !== '' ? ' — ' . $comment : ''),
            json_encode(['event' => $event, 'monitor_id' => (int)$m['id'], 'domain' => (string)$m['domain'], 'comment' => mb_substr($comment, 0, 500)], JSON_UNESCAPED_UNICODE),
        ]);
        if (!$ok || $st->rowCount() !== 1) {
            throw new \RuntimeException('ban_monitor_audit_failed');
        }
    }

    private function loadMonitorOr404(int $id): ?array
    {
        try {
            $s = DB::pdo()->prepare("SELECT * FROM site_ban_monitors WHERE id=?");
            $s->execute([$id]);
            return $s->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (\Throwable $e) { return null; }
    }

    private function changeMonitorState(int $id, string $event, array $set, array $allowedFrom, string $comment): void
    {
        $pdo = DB::pdo();
        $own = !$pdo->inTransaction();
        try {
            if ($own) $pdo->beginTransaction();
            $s = $pdo->prepare("SELECT * FROM site_ban_monitors WHERE id=? FOR UPDATE");
            $s->execute([$id]);
            $m = $s->fetch(PDO::FETCH_ASSOC);
            if (!$m) { if ($own) $pdo->rollBack(); $this->flash('error', 'Монитор не найден.'); return; }
            if ($allowedFrom && !in_array((string)$m['state'], $allowedFrom, true)) {
                if ($own) $pdo->rollBack();
                $this->flash('error', 'Действие недоступно из состояния «' . (string)$m['state'] . '».');
                return;
            }
            $cols = []; $args = [];
            foreach ($set as $k => $v) { $cols[] = "`{$k}`=?"; $args[] = $v; }
            $args[] = $id;
            $pdo->prepare("UPDATE site_ban_monitors SET " . implode(',', $cols) . " WHERE id=?")->execute($args);
            $this->auditMonitor($pdo, $m, $event, $comment); // atomic — в той же транзакции
            if ($own) $pdo->commit();
            $this->flash('success', 'Готово: ' . $event);
        } catch (\Throwable $e) {
            if ($own && $pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось выполнить действие: ' . $e->getMessage());
        }
    }

    public function banMonitorCheckNow(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['monitor_id'] ?? 0);
        $m = $this->loadMonitorOr404($id);
        if (!$m) { $this->flash('error', 'Монитор не найден.'); $this->redirectTab(); }
        try {
            // тот же per-monitor lock и тот же ledger; форс due, чтобы processMonitor выполнил проверку
            DB::pdo()->prepare("UPDATE site_ban_monitors SET next_check_at=NOW() WHERE id=? AND state IN ('waiting_initial_delay','monitoring','confirming','insurance')")->execute([$id]);
            $r = (new BanMonitorService())->processMonitor($id, 'operator');
            // audit ручной проверки
            $pdo = DB::pdo();
            $pdo->beginTransaction();
            try { $this->auditMonitor($pdo, $m, 'ban_monitor_manual_check', (string)($_POST['comment'] ?? '')); $pdo->commit(); }
            catch (\Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); }
            // §18.4: реальный outcome, не безусловный success
            $outcome = !empty($r['ok']) ? 'processed' : (string)($r['skipped'] ?? 'skipped');
            if (!empty($r['ambiguous'])) $outcome = 'technical_error';
            if (in_array($outcome, ['processed'], true)) $this->flash('success', 'Проверка выполнена: ' . (string)($r['decision'] ?? 'ok') . '.');
            elseif ($outcome === 'technical_error') $this->flash('warning', 'Проверка: техническая неопределённость (ambiguous), состояние не изменено.');
            else $this->flash('warning', 'Проверка не выполнена: ' . $outcome . '.');
        } catch (\Throwable $e) {
            $this->flash('error', 'Проверка не выполнена: ' . $e->getMessage());
        }
        $this->redirect($id ? '/xmlstock?tab=monitors&monitor_id=' . $id . '#monitor-' . $id : '/xmlstock?tab=monitors');
    }

    public function banMonitorPause(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['monitor_id'] ?? 0);
        $m = $this->loadMonitorOr404($id);
        if (!$m) { $this->flash('error', 'Монитор не найден.'); $this->redirectTab(); }
        // §18.5: сохраняем фазу и запланированную проверку для корректного resume.
        $this->changeMonitorState($id, 'ban_monitor_paused',
            ['state' => 'paused', 'paused_from_state' => (string)$m['state'], 'paused_next_check_at' => $m['next_check_at'], 'next_check_at' => null],
            ['waiting_initial_delay', 'monitoring', 'confirming', 'insurance'], (string)($_POST['comment'] ?? ''));
        $this->redirect('/xmlstock?tab=monitors&monitor_id=' . $id . '#monitor-' . $id);
    }

    /** §18.5: resume_mode=continue (восстановить фазу) | reset (сбросить подозрение). */
    public function banMonitorResume(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['monitor_id'] ?? 0);
        $mode = ($_POST['resume_mode'] ?? 'continue') === 'reset' ? 'reset' : 'continue';
        $m = $this->loadMonitorOr404($id);
        if (!$m) { $this->flash('error', 'Монитор не найден.'); $this->redirectTab(); }
        $policy = BanMonitoringPolicy::fromJson($m['policy_snapshot_json'] ?? null);
        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $nowS = $now->format('Y-m-d H:i:s');
        if ($mode === 'reset') {
            $next = $now->modify('+' . $policy->regularIntervalMinutes() . ' minutes')->format('Y-m-d H:i:s');
            $set = ['state' => 'monitoring', 'negative_streak' => 0, 'insurance_checks_done' => 0,
                    'first_negative_at' => null, 'probable_notified_at' => null, 'next_check_at' => $next,
                    'paused_from_state' => null, 'paused_next_check_at' => null, 'stop_reason' => null, 'stopped_at' => null];
            $event = 'ban_monitor_resumed_reset';
        } else {
            $restoreState = in_array((string)($m['paused_from_state'] ?? ''), BanMonitorRepository::ACTIVE, true) ? (string)$m['paused_from_state'] : 'monitoring';
            $restoreNext = (!empty($m['paused_next_check_at']) && $m['paused_next_check_at'] > $nowS) ? $m['paused_next_check_at'] : $nowS;
            $set = ['state' => $restoreState, 'next_check_at' => $restoreNext,
                    'paused_from_state' => null, 'paused_next_check_at' => null, 'stop_reason' => null, 'stopped_at' => null];
            $event = 'ban_monitor_resumed_continue';
        }
        $this->changeMonitorState($id, $event, $set, ['paused'], (string)($_POST['comment'] ?? ''));
        $this->redirect('/xmlstock?tab=monitors&monitor_id=' . $id . '#monitor-' . $id);
    }

    public function banMonitorStop(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $id = (int)($_POST['monitor_id'] ?? 0);
        $comment = trim((string)($_POST['comment'] ?? ''));
        if ($comment === '') { // §18.3: комментарий обязателен для stop
            $this->flash('error', 'Для остановки монитора обязателен комментарий (причина).');
            $this->redirect('/xmlstock?tab=monitors&monitor_id=' . $id . '#monitor-' . $id);
        }
        $this->changeMonitorState($id, 'ban_monitor_stopped',
            ['state' => 'stopped', 'next_check_at' => null, 'stopped_at' => gmdate('Y-m-d H:i:s'), 'stop_reason' => 'operator_stopped'],
            ['waiting_initial_delay', 'monitoring', 'confirming', 'insurance', 'paused'], $comment);
        $this->redirect('/xmlstock?tab=monitors&monitor_id=' . $id . '#monitor-' . $id);
    }

    // ───────────── активация / policy / processing (§6, §18) ─────────────

    /** Strict audit settings-действия (§18.2): в той же транзакции, old/new, IP/UA, comment. */
    private function auditSettings(PDO $pdo, string $action, array $old, array $new, string $comment): void
    {
        $st = $pdo->prepare(
            "INSERT INTO ban_monitoring_audit (action, object_type, object_id, operator, ip, user_agent, old_values, new_values, comment)
             VALUES (?, 'settings', 1, ?, ?, ?, ?, ?, ?)"
        );
        $ok = $st->execute([
            $action,
            (string)($_SESSION['user'] ?? $_SESSION['login'] ?? 'operator'),
            mb_substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64),
            mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
            json_encode($old, JSON_UNESCAPED_UNICODE), json_encode($new, JSON_UNESCAPED_UNICODE),
            mb_substr($comment, 0, 1000),
        ]);
        if (!$ok || $st->rowCount() !== 1) throw new \RuntimeException('settings_audit_failed');
    }

    public function banActivateNewJobs(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $comment = trim((string)($_POST['comment'] ?? ''));
        $pdo = DB::pdo();
        try {
            $pdo->beginTransaction();
            $r = (new BanMonitoringSettingsRepository($pdo))->activate();
            $this->auditSettings($pdo, 'ban_activate_new_jobs', $r['old'], $r['new'], $comment);
            $pdo->commit();
            $this->flash('success', $r['changed']
                ? 'Мониторинг включён для новых джоб. Generation: ' . (int)($r['new']['activation_generation'] ?? 0) . '. Исторические джобы не подключаются.'
                : 'Enrollment уже был включён — без изменений.');
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось активировать: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    public function banDeactivateNewJobs(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $comment = trim((string)($_POST['comment'] ?? ''));
        $pdo = DB::pdo();
        try {
            $pdo->beginTransaction();
            $r = (new BanMonitoringSettingsRepository($pdo))->deactivate();
            $this->auditSettings($pdo, 'ban_deactivate_new_jobs', $r['old'], $r['new'], $comment);
            $pdo->commit();
            $this->flash('success', 'Enrollment выключен. Новые джобы не подключаются; уже существующие мониторы продолжают работать.');
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось выключить: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    public function banToggleProcessing(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $comment = trim((string)($_POST['comment'] ?? ''));
        if ($comment === '') { // §18.3: комментарий обязателен для processing
            $this->flash('error', 'Для смены режима обработки обязателен комментарий.');
            $this->redirectTab();
        }
        $on = (string)($_POST['processing'] ?? '') === '1';
        $pdo = DB::pdo();
        try {
            $pdo->beginTransaction();
            $r = (new BanMonitoringSettingsRepository($pdo))->setProcessing($on);
            $this->auditSettings($pdo, 'ban_toggle_processing', $r['old'], $r['new'], $comment);
            $pdo->commit();
            $this->flash('success', $on ? 'Обработка активных мониторов включена.' : 'Обработка активных мониторов поставлена на паузу (общая пауза).');
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось изменить режим: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    public function banSavePolicy(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $comment = trim((string)($_POST['comment'] ?? ''));
        $fields = ['initial_delay_minutes', 'regular_interval_minutes', 'probable_negative_count',
                   'confirm_interval_minutes', 'insurance_negative_count', 'insurance_interval_minutes',
                   'technical_error_retry_minutes', 'cron_batch_limit', 'telegram_retry_minutes', 'telegram_max_attempts'];
        $in = [];
        foreach ($fields as $f) if (isset($_POST[$f]) && $_POST[$f] !== '') $in[$f] = (int)$_POST[$f];
        $pdo = DB::pdo();
        $repo = new BanMonitoringSettingsRepository($pdo);
        $errors = $repo->validate($in);
        if ($errors) { $this->flash('error', 'Ошибка валидации: ' . implode('; ', $errors)); $this->redirectTab(); }
        try {
            $pdo->beginTransaction();
            $old = $repo->get();
            $repo->savePolicy($in);
            $new = $repo->get();
            $this->auditSettings($pdo, 'ban_save_policy',
                array_intersect_key($old, array_flip($fields)), array_intersect_key($new, array_flip($fields)), $comment);
            $pdo->commit();
            $this->flash('success', 'Схема сохранена. Версия policy: ' . (int)($new['policy_version'] ?? 0) . '. Существующие мониторы работают по своему snapshot.');
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось сохранить схему: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    /**
     * Осознанный no-backfill exception (§3.3): подключить ban-monitor к УЖЕ существующим
     * refresh-джобам строго по явному списку job_id (веб-версия для shared-хостинга).
     * CSRF + обязательный комментарий + strict-audit внутри BanMonitorBootstrapService.
     * Монитор ставится только если новый домен СЕЙЧАС в индексе (один negative ≠ бан).
     */
    public function banBootstrapJobs(): void
    {
        $this->requireAuth();
        $this->requireCsrf();
        $comment = trim((string)($_POST['comment'] ?? ''));
        $dryRun = (string)($_POST['dry_run'] ?? '') === '1';
        $raw = (string)($_POST['job_ids'] ?? '');
        $jobIds = array_values(array_filter(array_map('intval', preg_split('~[,\s]+~', $raw, -1, PREG_SPLIT_NO_EMPTY))));
        if (!$jobIds) { $this->flash('error', 'Укажите один или несколько job id (через запятую).'); $this->redirectTab(); }
        if (!$dryRun && $comment === '') { $this->flash('error', 'Для подключения нужен комментарий (причина).'); $this->redirectTab(); }
        if (count($jobIds) > 20) { $this->flash('error', 'За один раз не более 20 джоб.'); $this->redirectTab(); }

        $operator = (string)($_SESSION['user'] ?? $_SESSION['login'] ?? 'operator');
        try {
            $results = (new BanMonitorBootstrapService())->bootstrap($jobIds, $operator, $comment !== '' ? $comment : 'dry-run', $dryRun);
        } catch (\Throwable $e) {
            $this->flash('error', 'Bootstrap не выполнен: ' . $e->getMessage());
            $this->redirectTab();
        }

        $lines = [];
        foreach ($results as $r) {
            if (isset($r['error']) && !isset($r['job_id'])) { $this->flash('error', (string)($r['message'] ?? $r['error'])); $this->redirectTab(); }
            $jid = $r['job_id'] ?? '?';
            if (!empty($r['armed'])) $lines[] = "#{$jid}: ✓ " . ($r['message'] ?? 'монитор поставлен');
            elseif (!empty($r['dry_run'])) $lines[] = "#{$jid}: (сухой прогон) " . ($r['message'] ?? '');
            elseif (!empty($r['skipped'])) $lines[] = "#{$jid}: пропуск (" . $r['skipped'] . ") " . ($r['message'] ?? '');
            else $lines[] = "#{$jid}: не выполнено — " . ($r['message'] ?? ($r['error'] ?? 'unknown'));
        }
        $this->flash(array_reduce($results, fn($c, $r) => $c || !empty($r['armed']) || !empty($r['dry_run']), false) ? 'success' : 'warning',
            'Bootstrap: ' . implode(' · ', $lines));
        $this->redirectTab();
    }

    /** Глобальный стоп-кран: включить/выключить xmlstock. */
    public function toggleEnabled(): void
    {
        $this->requireAuth();
        $this->requireCsrf(); // §2.4.3
        $enable = (int)($_POST['enable'] ?? 0) === 1 ? 1 : 0;
        $comment = trim((string)($_POST['comment'] ?? ''));
        if ($comment === '') {
            $this->flash('error', 'Для глобального стоп-крана XMLStock обязателен комментарий (причина).');
            $this->redirectTab();
        }
        $pdo = DB::pdo();
        try {
            $pdo->beginTransaction();
            $old = (int)$pdo->query("SELECT enabled FROM xmlstock_settings WHERE id = 1")->fetchColumn();
            $pdo->prepare("UPDATE xmlstock_settings SET enabled = ? WHERE id = 1")
                ->execute([$enable]);
            // §2.4.3: strict audit стоп-крана (оператор, время, IP, old/new, комментарий).
            $this->auditSettings($pdo, 'xmlstock_toggle_enabled',
                ['enabled' => $old], ['enabled' => $enable], $comment);
            $pdo->commit();
            if ($enable) {
                $this->flash('success',
                    'XMLStock включён. Проверка индексации снова идёт через xmlstock (платно).');
            } else {
                $this->flash('warning',
                    'XMLStock ВЫКЛЮЧЕН. Платные запросы остановлены — проверка индексации ' .
                    'автоматически идёт через бесплатный Yandex Webmaster API. Пайплайн продолжает работать.');
            }
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $this->flash('error', 'Не удалось переключить XMLStock: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    /** Пауза опроса конкретной джобы. */
    public function pauseJob(): void
    {
        $this->requireAuth();
        $this->requireCsrf(); // §2.4.3
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { $this->flash('error', 'Не указан id джобы'); $this->redirectTab(); }

        try {
            $job = $this->loadPollingJob($id);
            if ($job === null) {
                $this->flash('error', "Джоба #{$id} не найдена или не в polling-стадии — паузить нечего.");
                $this->redirectTab();
            }
            // v24.3 (H1): состояние могло измениться между SELECT и UPDATE —
            // повторный stage-guard в самом UPDATE, иначе закрытая/завершённая
            // джоба получила бы pending и новое next_run_at.
            $in = "'" . implode("','", self::POLLING_STAGES) . "'";
            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET next_run_at = ?, stage_status = 'pending'
                  WHERE id = ?
                    AND stage IN ($in)
                    AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $st->execute([self::PAUSE_UNTIL, $id]);
            if ($st->rowCount() !== 1) {
                $this->flash('warning',
                    "Джоба #{$id} успела сменить состояние — пауза не применена. Обновите страницу.");
                $this->redirectTab();
            }
            $this->flash('success',
                "Опрос джобы #{$id} ({$job['new_domain']}) поставлен на паузу — xmlstock по ней больше не тратится.");
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка паузы: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    /** Возобновление опроса конкретной джобы. */
    public function resumeJob(): void
    {
        $this->requireAuth();
        $this->requireCsrf(); // §2.4.3
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { $this->flash('error', 'Не указан id джобы'); $this->redirectTab(); }

        try {
            $job = $this->loadPollingJob($id);
            if ($job === null) {
                $this->flash('error', "Джоба #{$id} не найдена или не в polling-стадии.");
                $this->redirectTab();
            }
            // v24.3 (H1): тот же повторный stage-guard, что и в pauseJob().
            $in = "'" . implode("','", self::POLLING_STAGES) . "'";
            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET next_run_at = NOW(), stage_status = 'pending'
                  WHERE id = ?
                    AND stage IN ($in)
                    AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $st->execute([$id]);
            if ($st->rowCount() !== 1) {
                $this->flash('warning',
                    "Джоба #{$id} успела сменить состояние — возобновление не применено. Обновите страницу.");
                $this->redirectTab();
            }
            $this->flash('success',
                "Опрос джобы #{$id} ({$job['new_domain']}) возобновлён — проверка пойдёт на ближайшем cron-тике.");
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка возобновления: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    /** Пауза опроса ВСЕХ активных джоб. */
    public function pauseAll(): void
    {
        $this->requireAuth();
        $this->requireCsrf(); // §2.4.3
        try {
            $in = "'" . implode("','", self::POLLING_STAGES) . "'";
            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs
                 SET next_run_at = ?, stage_status = 'pending'
                 WHERE stage IN ($in) AND stage NOT IN ('done','failed','cancelled','superseded')
                   AND (next_run_at IS NULL OR next_run_at < ?)"
            );
            $st->execute([self::PAUSE_UNTIL, self::PAUSE_DETECT_AFTER]);
            $n = $st->rowCount();
            $this->flash('success', "Поставлено на паузу джоб: {$n}. xmlstock-опрос по ним остановлен.");
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка массовой паузы: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    /** Возобновление опроса ВСЕХ приостановленных джоб. */
    public function resumeAll(): void
    {
        $this->requireAuth();
        $this->requireCsrf(); // §2.4.3
        try {
            $in = "'" . implode("','", self::POLLING_STAGES) . "'";
            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs
                 SET next_run_at = NOW(), stage_status = 'pending'
                 WHERE stage IN ($in) AND stage NOT IN ('done','failed','cancelled','superseded')
                   AND next_run_at >= ?"
            );
            $st->execute([self::PAUSE_DETECT_AFTER]);
            $n = $st->rowCount();
            $this->flash('success', "Возобновлено джоб: {$n}.");
        } catch (\Throwable $e) {
            $this->flash('error', 'Ошибка массового возобновления: ' . $e->getMessage());
        }
        $this->redirectTab();
    }

    // ==================== helpers ====================

    /** Грузит джобу, только если она в polling-стадии (иначе null). */
    private function loadPollingJob(int $id): ?array
    {
        $st = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE id = ?");
        $st->execute([$id]);
        $job = $st->fetch();
        if (!$job) return null;
        if (!in_array((string)$job['stage'], self::POLLING_STAGES, true)) return null;
        if (in_array((string)$job['stage_status'], ['done', 'failed'], true)) return null;
        return $job;
    }

    /** Обогащает строку джобы данными для UI (tick_count, оценка расхода, пауза). */
    private function decoratePoller(array $r): array
    {
        $stage = (string)$r['stage'];
        $artifacts = [];
        if (!empty($r['artifacts_json'])) {
            $artifacts = json_decode((string)$r['artifacts_json'], true) ?: [];
        }
        $stageKey = $stage === 'final_monitoring' ? 'final_monitoring_stage' : 'index_watching_stage';
        $st = $artifacts[$stageKey] ?? [];

        $tickCount   = (int)($st['tick_count'] ?? 0);
        $lastCheckAt = (string)($st['last_check_at'] ?? '');
        $lastMsg     = (string)($st['last_message'] ?? ($st['last_index_message'] ?? ''));

        // started_at (unix) — в разных стадиях лежит по-разному
        $startedUnix = (int)($st['started_at_unix'] ?? $st['started_at'] ?? 0);
        if ($startedUnix === 0 && !empty($r['stage_started_at'])) {
            $startedUnix = strtotime((string)$r['stage_started_at']) ?: 0;
        }
        $elapsedSec = $startedUnix > 0 ? max(0, time() - $startedUnix) : 0;

        $nextRun = (string)($r['next_run_at'] ?? '');
        $paused  = ($nextRun !== '' && $nextRun >= self::PAUSE_DETECT_AFTER);

        // v18.1.38: авто-стоп из крона переводит джобу в awaiting_user (next_run_at=NULL).
        // Такую джобу опрос НЕ трогает — показываем отдельным статусом «остановлена».
        $stopped = ((string)($r['stage_status'] ?? '') === 'awaiting_user');
        $autoStoppedReason = (string)($st['auto_stopped_reason'] ?? '');

        $intervalSec = $this->intervalForElapsed($elapsedSec);
        $estPerDay = ($paused || $stopped) ? 0 : ($intervalSec > 0 ? (int)round(86400 / $intervalSec) : 0);

        $mode = (string)($r['mode'] ?? 'refresh');
        // В move-режимах index-check в final_monitoring на исход НЕ влияет (успех = только
        // подтверждение переезда Webmaster) — подсказываем оператору, что тут особенно
        // безопасно паузить / выключать xmlstock.
        $indexWasteful = ($stage === 'final_monitoring' && in_array($mode, ['move_indexed', 'move_simple'], true));

        return [
            'id'            => (int)$r['id'],
            'old_domain'    => (string)$r['old_domain'],
            'new_domain'    => (string)$r['new_domain'],
            'stage'         => $stage,
            'stage_status'  => (string)$r['stage_status'],
            'mode'          => $mode,
            'tick_count'    => $tickCount,
            'last_check_at' => $lastCheckAt,
            'last_message'  => $lastMsg,
            'next_run_at'   => $nextRun,
            'paused'        => $paused,
            'stopped'       => $stopped,
            'auto_stopped_reason' => $autoStoppedReason,
            'est_per_day'   => $estPerDay,
            'index_wasteful'=> $indexWasteful,
        ];
    }

    /**
     * Тот же adaptive-backoff, что в RefreshOrchestrator::computeIndexWatchingDelay.
     * Дублируется здесь только для ОЦЕНКИ расхода в UI (без изменения логики оркестратора).
     */
    private function intervalForElapsed(int $elapsedSec): int
    {
        if ($elapsedSec < 5 * 60)     return 30;
        if ($elapsedSec < 15 * 60)    return 2 * 60;
        if ($elapsedSec < 30 * 60)    return 5 * 60;
        if ($elapsedSec < 6 * 3600)   return 30 * 60;
        if ($elapsedSec < 3 * 86400)  return 3600;
        if ($elapsedSec < 7 * 86400)  return 6 * 3600;
        return 24 * 3600;
    }
}
