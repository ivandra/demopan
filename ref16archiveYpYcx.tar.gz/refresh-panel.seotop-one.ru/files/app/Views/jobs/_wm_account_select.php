<?php
/**
 * v25.2-a1.3 (§Пункт 1/2): переиспользуемый partial выбора Webmaster-аккаунта.
 * Показывается на wm_account_resolve И при awaiting_no_account в переезде.
 * Ожидает в области видимости: $job (array), $webmasterAccounts (array|null).
 * Использует существующий маршрут POST /jobs/set-webmaster-override.
 */
$waList = $webmasterAccounts ?? [];
$currentOverrideId = (int)($job['webmaster_account_override_id'] ?? 0);
?>
<?php if (!empty($waList)): ?>
<div style="background: rgba(38, 132, 255, 0.08); border: 1px solid rgba(38, 132, 255, 0.3);
            border-radius: 6px; padding: 12px 16px; margin-bottom: 12px;">
    <p style="margin: 0 0 8px 0;"><b>🎯 Указать Webmaster аккаунт (прямо в карточке):</b></p>
    <p class="muted small" style="margin: 0 0 10px 0;">
        Новый домен <code><?= htmlspecialchars((string)$job['new_domain']) ?></code> будет добавлен в выбранный аккаунт.
        Купленный домен и весь прогресс джобы сохраняются.
    </p>
    <form method="post" action="/jobs/set-webmaster-override"
          onsubmit="return confirm('Применить override и продолжить?\n\nНовый домен будет добавлен в выбранный Webmaster аккаунт. Джоба вернётся на wm_account_resolve и продолжит автоматически.');"
          style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
        <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
        <select name="account_id" required
                style="background: var(--bg-elevated); color: var(--text);
                       border: 1px solid var(--border); padding: 6px 10px;
                       border-radius: 4px; min-width: 280px;">
            <option value="">— выбери аккаунт —</option>
            <?php foreach ($waList as $a): ?>
                <?php
                $aId = (int)$a['id'];
                $aEmail = (string)($a['email'] ?? '');
                $aNote = trim((string)($a['note'] ?? ''));
                $aHostCount = (int)($a['host_count'] ?? 0);
                $hcMod10 = $aHostCount % 10; $hcMod100 = $aHostCount % 100;
                if ($hcMod100 >= 11 && $hcMod100 <= 14)      $hostWord = 'хостов';
                elseif ($hcMod10 === 1)                       $hostWord = 'хост';
                elseif ($hcMod10 >= 2 && $hcMod10 <= 4)       $hostWord = 'хоста';
                else                                          $hostWord = 'хостов';
                $selected = $currentOverrideId === $aId ? 'selected' : '';
                ?>
                <option value="<?= $aId ?>" <?= $selected ?>>
                    #<?= $aId ?> ·
                    <?php if ($aNote !== ''): ?>
                        <?= htmlspecialchars($aNote) ?> · <?= htmlspecialchars($aEmail) ?>
                    <?php else: ?>
                        <?= htmlspecialchars($aEmail) ?>
                    <?php endif; ?>
                    (<?= $aHostCount ?> <?= $hostWord ?>)
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">🚀 Применить и продолжить</button>
    </form>
</div>
<?php else: ?>
<div style="background: rgba(255,193,7,0.1); border:1px solid rgba(255,193,7,0.4);
            border-radius:6px; padding:12px 16px; margin-bottom:12px;">
    <p style="margin:0 0 6px 0;"><b>Webmaster-аккаунты не подключены</b></p>
    <p class="small muted" style="margin:0;">
        Чтобы выбрать аккаунт для переезда, сначала подключите токен в разделе
        <a href="/system/webmaster-tokens">Webmaster-токены</a>.
    </p>
</div>
<?php endif; ?>
