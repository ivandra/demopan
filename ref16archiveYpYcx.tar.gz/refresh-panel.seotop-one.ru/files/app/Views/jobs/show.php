<?php
/**
 * @var array $job
 * @var array|null $site
 * @var array $events
 * @var array $stages
 * @var int $currentIdx
 * @var int $progressPct
 * @var bool $autoRefresh
 * @var array|null $artifacts
 */

// v18-fix: helper для отображения серверных DATETIME в МСК.
// v18.1.28: делегирует на Time::msk() — единый helper для всего приложения.
$fmtMsk = function (?string $serverDatetime): string {
    return Time::msk($serverDatetime);
};

$stageStatusClass = [
    'pending'        => 'is-info',
    'running'        => 'is-warn',
    'ok'             => 'is-ok',
    'failed'         => 'is-bad',
    'awaiting_user'  => 'is-warn',
][$job['stage_status']] ?? 'is-info';

// v24.2 (B4): cancelled/superseded — тоже терминальные. Иначе для закрытой
// джобы показывались «Шаг сейчас», старое «Отменить» и «Откатить snapshot».
$isTerminal = in_array($job['stage'], ['done', 'failed', 'cancelled', 'superseded'], true);
$isClosed   = in_array($job['stage'], ['cancelled', 'superseded'], true);
$isAwaitingUser = !$isClosed && $job['stage_status'] === 'awaiting_user';
$canRetry   = !$isClosed && ($job['stage_status'] === 'failed' || $job['stage'] === 'failed');
$canCancel  = !$isTerminal && !$isAwaitingUser;

// v18-fix: можно откатиться когда есть snapshot'ы config_replaced и джоба не terminal.
// Раньше кнопка «Откатить snapshot» была только в блоке awaiting_user — но retry
// между попытками держит статус 'pending', и блок не показывался → не было способа
// прервать retry-цикл и откатиться. Теперь кнопка есть в свойствах джобы всегда
// когда логически имеет смысл (есть snapshot'ы для восстановления).
$artifactsForUi = !empty($job['artifacts_json'])
    ? (json_decode((string)$job['artifacts_json'], true) ?: [])
    : [];
$hasSnapshots = !empty($artifactsForUi['config_replaced_stage']['snapshots']);
$canRollback  = $hasSnapshots && !$isTerminal;

// v18.1.17: ручное завершение move-джобы доступно когда:
//   - режим move_indexed / move_simple
//   - стадия move_poll_status, move_submit_request ИЛИ final_monitoring (v18.1.23+)
//   - статус awaiting_user / failed / pending (между tick'ами polling'а)
$jobMode = (string)($job['mode'] ?? 'refresh');
$canMarkDone = in_array($jobMode, ['move_indexed', 'move_simple'], true)
    && in_array((string)$job['stage'], ['move_poll_status', 'move_submit_request', 'final_monitoring'], true)
    && in_array((string)$job['stage_status'], ['awaiting_user', 'failed', 'pending', 'ok'], true);

// v18-fix: различаем "реальный" awaiting_user (ждёт юзера навсегда) и
// "retry-awaiting" (между попытками, cron подхватит когда next_run_at <= NOW()).
// UI показывает разные тексты и поведение.
//
// v18.1.25: расширено на 'pending' — verify_replacement теперь использует pending+next_run_at
// для retry (раньше был awaiting_user). pending — естественный статус для "ждём cron".
$isPendingRetry = (string)$job['stage_status'] === 'pending'
    && !empty($job['next_run_at'])
    && strtotime((string)$job['next_run_at']) > time();
$isAutoRetry = ($isAwaitingUser || $isPendingRetry)
    && !empty($job['next_run_at'])
    && strtotime((string)$job['next_run_at']) > 0;
// Время до следующего retry (для UI countdown)
$nextRetryEta = null;
if ($isAutoRetry) {
    $secondsUntil = strtotime((string)$job['next_run_at']) - time();
    $nextRetryEta = $secondsUntil > 0 ? $secondsUntil : 0;
}

// Человеко-читаемые подписи стадий
$stageLabels = [
    // v17.5: устарело — используется JobEventLogger::stageLabel().
    // Оставляем массив пустым на случай если где-то ещё используется $stageLabels[...]
    // (всё равно есть fallback ?? $job['stage']).
];
?>

<?php
// v17.5: helpers для лейблов
$stageHuman = JobEventLogger::stageLabel((string)$job['stage']);
$statusHuman = JobEventLogger::statusLabel((string)$job['stage_status']);
?>

<?php if ($autoRefresh): ?>
<?php
// v18: вместо meta http-equiv=refresh используем JS, который перед перезагрузкой
// сохраняет scroll position в sessionStorage и восстанавливает его после загрузки.
// Это убирает «прыжки» страницы во время чтения лога/артефактов.
?>
<script>
(function() {
    var jobId = <?= (int)$job['id'] ?>;
    var key = 'rp_job_' + jobId + '_scroll';
    // Восстановить позицию сразу после загрузки
    try {
        var saved = sessionStorage.getItem(key);
        if (saved !== null) {
            var y = parseInt(saved, 10);
            if (!isNaN(y) && y > 0) {
                // Используем setTimeout чтобы DOM успел отрисоваться
                setTimeout(function() { window.scrollTo(0, y); }, 0);
            }
        }
    } catch (e) {}
    // Перезагрузка через 5 сек, перед этим сохраняем scroll
    setTimeout(function() {
        try { sessionStorage.setItem(key, String(window.scrollY || window.pageYOffset || 0)); } catch (e) {}
        window.location.reload();
    }, 5000);
})();
</script>
<?php endif; ?>

<h1 class="page-title">
    <a href="/jobs" class="back-link">← Все джобы</a>
    Джоба #<?= (int)$job['id'] ?>: <?= htmlspecialchars($job['old_domain']) ?>
    <?php if (!empty($job['new_domain'])): ?>
        → <span style="color: var(--success);"><?= htmlspecialchars($job['new_domain']) ?></span>
    <?php endif; ?>
</h1>

<?php
// v25.1-b (§8): блок «Доступность домена / SSL / Pipeline».
if (!empty($job['new_domain'])):
    $sslRepo = new DomainSslStatusRepository();
    $sslRow = $sslRepo->getByDomain((string)$job['new_domain']);
    $techReady = !empty($job['domain_technical_ready_at']);
    $rdReason = (string)($job['domain_readiness_reason'] ?? '');
    $ybCode = (int)($job['domain_yandexbot_http_code'] ?? 0);
    $sslState = (string)($job['domain_ssl_state'] ?? '');
?>
<div class="card ssl-job-block">
    <div class="ssl-job-col">
        <h3>Доступность домена</h3>
        <div>Техническая доступность: <b><?= $techReady ? 'ДА' : 'проверяется' ?></b></div>
        <?php if ($ybCode): ?><div>YandexBot: HTTP <?= $ybCode ?></div><?php endif; ?>
        <?php if (!empty($job['domain_http_location'])): ?><div>Redirect: <?= htmlspecialchars((string)$job['domain_http_location']) ?></div><?php endif; ?>
        <?php if (!empty($job['domain_readiness_last_checked_at'])): ?><div>Проверено: <?= htmlspecialchars((string)$job['domain_readiness_last_checked_at']) ?></div><?php endif; ?>
    </div>
    <div class="ssl-job-col">
        <h3>SSL</h3>
        <?php if ($sslRow): ?>
            <div>Статус: <b><?= htmlspecialchars((string)$sslRow['status']) ?></b></div>
            <?php if ($sslRow['issuer']): ?><div>Issuer: <?= htmlspecialchars(mb_substr((string)$sslRow['issuer'],0,40)) ?></div><?php endif; ?>
            <?php if ($sslRow['valid_to']): ?><div>Действует до: <?= htmlspecialchars((string)$sslRow['valid_to']) ?></div><?php endif; ?>
            <div>Доверенный: <b><?= (int)$sslRow['tls_trusted']===1 ? 'ДА' : 'НЕТ' ?></b></div>
            <?php if ($sslRow['next_check_at']): ?><div>Следующая проверка: <?= htmlspecialchars((string)$sslRow['next_check_at']) ?></div><?php endif; ?>
        <?php else: ?>
            <div>Статус: <b><?= $sslState !== '' ? htmlspecialchars($sslState) : 'не проверялся' ?></b></div>
        <?php endif; ?>
    </div>
    <div class="ssl-job-col">
        <h3>Pipeline</h3>
        <div>PHP-уникализация: <b><?= $techReady ? 'разрешена' : 'ожидает доступности' ?></b></div>
        <div>Яндекс verification: <?= !empty($job['domain_https_ready_at']) ? 'готово к проверке' : 'ждёт доверенный SSL / выполняется' ?></div>
        <div>Recrawl: <?= $job['stage']==='wm_recrawl' ? 'выполняется' : (in_array($job['stage'],['done'],true) ? 'завершён' : 'ещё не запущен') ?></div>
        <div class="ssl-job-actions">
            <button class="btn btn-sm btn-primary ssl-check-one" data-domain="<?= htmlspecialchars((string)$job['new_domain']) ?>" data-reload="1">Проверить домен сейчас</button>
            <a class="btn btn-sm btn-secondary" href="/ssl/show?domain=<?= urlencode((string)$job['new_domain']) ?>">Открыть вкладку SSL</a>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
// v25.2-a1.5 (§наблюдаемость): статус крона прямо на карточке джобы — видно, что
// cron жив, когда был последний тик и как часто цикл. Раньше это было только на /ssl.
if (!empty($cronHeartbeat)):
    $hbColorMap = ['green'=>'#28c76f','yellow'=>'#ff9f43','red'=>'#ea5455','gray'=>'#6c757d'];
?>
<div class="card" style="padding:10px 14px; margin-bottom:12px;">
    <div style="display:flex; gap:20px; flex-wrap:wrap; align-items:center;">
        <b style="font-size:0.9em;">⏱ Статус cron:</b>
        <?php foreach ($cronHeartbeat as $c): ?>
            <?php $dot = $hbColorMap[$c['color'] ?? 'gray'] ?? '#6c757d'; ?>
            <span style="display:inline-flex; align-items:center; gap:6px; font-size:0.88em;">
                <span style="width:9px;height:9px;border-radius:50%;background:<?= $dot ?>;display:inline-block;"></span>
                <b><?= htmlspecialchars($c['label'] ?? '') ?></b>
                <span class="muted"><?= htmlspecialchars($c['status_text'] ?? '') ?><?php
                    if (($c['ago_sec'] ?? null) !== null) echo ' · последний тик ' . (int)$c['ago_sec'] . 'с назад';
                    if (!empty($c['cadence'])) echo ' · ожид. ' . htmlspecialchars((string)$c['cadence']);
                    if (($c['duration'] ?? null) !== null) echo ' · тик ' . htmlspecialchars((string)$c['duration']) . 'с';
                ?></span>
            </span>
        <?php endforeach; ?>
    </div>
    <?php if (!empty($jobTimers)): ?>
    <div style="display:flex; gap:20px; flex-wrap:wrap; align-items:center; margin-top:8px; padding-top:8px; border-top:1px solid var(--border);">
        <b style="font-size:0.9em;">⏳ Таймеры джобы:</b>
        <?php foreach ($jobTimers as $tm): ?>
            <span style="font-size:0.88em;"><b><?= htmlspecialchars($tm['label']) ?>:</b>
                <span class="muted"><?= htmlspecialchars((string)($tm['value'] ?? '—')) ?></span></span>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>


<div class="page-toolbar">
    <div class="hub-statusline">
        <div class="hub-statusline__left">
            <span class="hub-mini-pill <?= $job['stage'] === 'done' ? 'is-ok'
                : ($job['stage'] === 'failed' ? 'is-bad'
                : ($isClosed ? 'is-warn' : 'is-info')) ?>">
                <span class="hub-mini-pill__dot"></span>
                <b>Стадия</b>
                <span><?= htmlspecialchars($stageHuman) ?></span>
            </span>
            <span class="hub-mini-pill <?= $stageStatusClass ?>">
                <span class="hub-mini-pill__dot"></span>
                <b>Статус</b>
                <span><?= htmlspecialchars($statusHuman) ?></span>
            </span>
            <?php
            // v18: pill с режимом джобы
            $jobMode = (string)($job['mode'] ?? 'refresh');
            $modeLabels = [
                'refresh'      => ['🔄 Перевыставление',     'is-info'],
                'move_indexed' => ['🚚 Переезд (с индекс.)', 'is-warn'],
                'move_simple'  => ['🚚 Переезд (без инд.)',  'is-warn'],
            ];
            [$modeLabel, $modeClass] = $modeLabels[$jobMode] ?? [$jobMode, 'is-info'];
            ?>
            <span class="hub-mini-pill <?= $modeClass ?>" title="Режим джобы">
                <span class="hub-mini-pill__dot"></span>
                <b>Режим</b>
                <span><?= htmlspecialchars($modeLabel) ?></span>
            </span>
            <?php
            // v18-fix: pill для отложенного старта (queued + pending + next_run_at в будущем)
            $isScheduledStart = ($job['stage'] === 'queued'
                && $job['stage_status'] === 'pending'
                && !empty($job['next_run_at'])
                && strtotime((string)$job['next_run_at']) > time());
            ?>
            <?php if ($isScheduledStart): ?>
                <?php
                $secondsUntilStart = strtotime((string)$job['next_run_at']) - time();
                if ($secondsUntilStart < 60)        $startEta = "{$secondsUntilStart} сек";
                elseif ($secondsUntilStart < 3600)  $startEta = (int)round($secondsUntilStart / 60) . " мин";
                elseif ($secondsUntilStart < 86400) $startEta = round($secondsUntilStart / 3600, 1) . " ч";
                else                                $startEta = round($secondsUntilStart / 86400, 1) . " дн";
                ?>
                <span class="hub-mini-pill" style="background: rgba(58, 123, 213, 0.2); color:#3a7bd5;"
                      title="Отложенный старт: <?= htmlspecialchars($fmtMsk((string)$job['next_run_at'])) ?>">
                    <span class="hub-mini-pill__dot"></span>
                    <b>⏰ Старт</b>
                    <span>через <?= htmlspecialchars($startEta) ?></span>
                </span>
            <?php endif; ?>
            <?php if ($site): ?>
                <span class="hub-mini-pill is-info">
                    <span class="hub-mini-pill__dot"></span>
                    <b>Сайт</b>
                    <span><a href="/sites/show?id=<?= (int)$site['id'] ?>"><?= htmlspecialchars($site['current_domain']) ?></a></span>
                </span>
            <?php endif; ?>
            <?php if ($autoRefresh): ?>
                <span class="hub-mini-pill is-warn" title="Это перезагрузка страницы в браузере (не cron). Cron-циклы см. в блоке «Статус cron» выше.">
                    <span class="hub-mini-pill__dot"></span>
                    <b>Обновление страницы браузера</b>
                    <span>5 сек</span>
                </span>
            <?php elseif ($isAwaitingUser): ?>
                <span class="hub-mini-pill" title="Обновление страницы браузера выключено пока джоба ждёт твоего решения — чтобы не мешать работе с формой. Если нужно — нажми F5 вручную.">
                    <span class="hub-mini-pill__dot"></span>
                    <b>Обновление страницы браузера</b>
                    <span>выкл.</span>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="page-actions">
        <?php if ($canCancel): ?>
            <form method="post" action="/jobs/run-step" style="display:inline;"
                  onsubmit="return confirm('Запустить следующий шаг прямо сейчас? (для отладки, если cron не работает)');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-secondary">⚡ Шаг сейчас</button>
            </form>
        <?php endif; ?>
        <?php if ($canRetry): ?>
            <form method="post" action="/jobs/retry" style="display:inline;">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-primary">🔄 Повторить</button>
            </form>
        <?php endif; ?>
        <?php if ($canCancel): ?>
            <form method="post" action="/jobs/cancel" style="display:inline;"
                  onsubmit="return confirm('Точно отменить джобу? Это переведёт её в failed.');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-danger">✖ Отменить</button>
            </form>
        <?php endif; ?>
        <?php if ($isAwaitingUser && !$isTerminal): ?>
            <?php
            // v24: закрыть зависшую джобу можно прямо отсюда. Раньше обычная
            // кнопка «Отменить» для awaiting_user была скрыта, и единственным
            // способом освободить сайт была попытка создать новую джобу.
            ?>
            <details style="display:inline-block; margin-left:6px">
                <summary class="btn btn-danger" style="display:inline-block; cursor:pointer">✖ Закрыть джобу</summary>
                <div style="margin-top:10px; padding:12px; background:rgba(255,255,255,.03); border-radius:6px; max-width:520px">
                    <p class="muted small" style="margin-top:0">
                        Джоба перейдёт в состояние <code>cancelled</code>, сайт освободится
                        для новых джоб. Возобновить её после этого нельзя.
                    </p>
                    <form method="post" action="/jobs/close">
                        <input type="hidden" name="job_id" value="<?= (int)$job['id'] ?>">
                        <label style="display:block; margin-bottom:8px">
                            <span class="muted small">Причина (обязательно)</span>
                            <input type="text" name="comment" required style="width:100%; padding:6px">
                        </label>
                        <button type="submit" class="btn btn-danger"
                                onclick="return confirm('Закрыть джобу #<?= (int)$job['id'] ?>?');">
                            Закрыть джобу
                        </button>
                    </form>
                    <p class="muted small" style="margin-bottom:0">
                        Нужно сразу запустить новую джобу вместо этой — используйте
                        «Закрыть старую и создать новую» при создании джобы для сайта.
                    </p>
                </div>
            </details>
        <?php endif; ?>
        <?php if ($canRollback): ?>
            <form method="post" action="/jobs/rollback" style="display:inline;"
                  onsubmit="return confirm('↩️ Откатить snapshot?\n\nФайлы на VPS (config.php, .htaccess и т.д.) будут восстановлены из snapshot\'ов.\nДомен в БД вернётся на старый.\nPipeline сбросится на ssl_self_signed_first и cron перезапустит замены через минуту.\n\nПродолжить?');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-warning"
                        title="Восстановить файлы из snapshot и перезапустить pipeline">↩️ Откатить snapshot</button>
            </form>
        <?php endif; ?>
        <?php if ($canMarkDone): ?>
            <!-- v18.1.17: ручное завершение move-джобы. v18.1.30: теперь работает и для final_monitoring/pending. -->
            <form method="post" action="/jobs/mark-done" style="display:inline;"
                  onsubmit="return confirm('✅ Завершить джобу вручную?\n\nДжоба будет помечена как done. Новый домен <?= htmlspecialchars((string)$job['new_domain']) ?> станет основным.\nАвтоматический мониторинг переезда отключится.\n\nИспользуй когда:\n• Новый домен уже в индексе, и ждать main_mirror от Webmaster нет смысла\n• Переезд уже подтверждён вне панели\n• Webmaster API недоступен или аккаунт не привязан\n• Хочешь оставить новый домен как есть\n\nВНИМАНИЕ: если Webmaster ещё не склеил зеркала (main_mirror=in_progress), polling прекратится. Но фактическая склейка на стороне Yandex продолжится — это твоё право решить когда завершить.\n\nПродолжить?');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-success"
                        title="Пометить как успешно завершённую, оставить новый домен">✅ Завершить джобу</button>
            </form>
        <?php endif; ?>

        <?php
        // v18.1.23: возможность перезапустить мониторинг
        // — refresh-режим: index_watching отдельная кнопка
        // — move-режимы: ОДНА кнопка final_monitoring (объединяет индекс + статус переезда)
        $artifactsForUi = $artifacts ?? [];
        $isMoveMode = in_array((string)($job['mode'] ?? 'refresh'), ['move_indexed', 'move_simple'], true);
        $isDone = (string)$job['stage'] === 'done';
        // Для refresh: показываем если index_watching была пройдена ИЛИ done
        $hasIndexHistory = !empty($artifactsForUi['index_watching_stage'])
            || !empty($artifactsForUi['index_watching_stage_history']);
        $showRetryIndex = !$isClosed && !$isMoveMode && ($hasIndexHistory || $isDone); // v24.2
        // Для move: показываем если pipeline дошёл до webmaster (хоть какие-то wm-стадии завершены)
        // ИЛИ если есть история финального мониторинга, ИЛИ если done.
        $hasFinalMonitoring = !empty($artifactsForUi['final_monitoring_stage'])
            || !empty($artifactsForUi['final_monitoring_stage_history']);
        $hasMoveLegacy = !empty($artifactsForUi['move_poll_status_stage'])
            || !empty($artifactsForUi['move_poll_status_stage_history']);
        $hasWmStages = !empty($artifactsForUi['wm_added_stage']);
        $showRetryFinalMonitoring = !$isClosed && $isMoveMode && ($hasWmStages || $hasFinalMonitoring || $hasMoveLegacy || $isDone); // v24.2
        ?>

        <?php if ($showRetryIndex): ?>
            <form method="post" action="/jobs/retry-index" style="display:inline;"
                  onsubmit="return confirm('🔁 Перезапустить мониторинг индексации?\n\nДжоба вернётся на стадию index_watching, начнётся новый polling через xmlstock (без таймаута — крутится до появления в индексе).\nПрежний state мониторинга сохранится в истории артефактов.\n\nПродолжить?');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-secondary"
                        title="Вернуть джобу на index_watching, перезапустить polling индексации">🔁 Мониторинг индексации</button>
            </form>
        <?php endif; ?>

        <?php if ($showRetryFinalMonitoring): ?>
            <form method="post" action="/jobs/retry-final-monitoring" style="display:inline;"
                  onsubmit="return confirm('🔁 Перезапустить финальный мониторинг?\n\nДжоба вернётся на стадию final_monitoring, начнётся новый polling.\nПроверяются ОБА сигнала параллельно:\n• появление нового домена в индексе\n• статус переезда в Яндекс Webmaster (main_mirror)\n\nПервый сработавший сигнал завершит джобу.\nПолинг без таймаута: 30 сек → 30 мин → 1 ч → 6 ч → раз в сутки.\n\nПродолжить?');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-secondary"
                        title="Перезапустить final_monitoring — параллельная проверка индекса и переезда">🔁 Финальный мониторинг</button>
            </form>
        <?php endif; ?>

        <form method="post" action="/jobs/delete" style="display:inline;"
              onsubmit="return confirm('Полностью удалить джобу #<?= (int)$job['id'] ?> со всеми событиями?\n\nЭто необратимо. Используется для очистки тестовых/упавших джоб.');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-danger" style="opacity: 0.85;">🗑 Удалить джобу</button>
        </form>
    </div>
</div>

<?php if ($isClosed): ?>
    <?php
    // v24.2: карточка закрытой джобы. Опасные действия скрыты выше
    // ($isTerminal), здесь — понятное объяснение, кем/когда/почему закрыта,
    // и ссылка на заменившую джобу.
    // a1.6.4: авто-close помечаем отдельно.
    $lc = $artifacts['lifecycle'] ?? [];
    $autoClosed = !empty($lc['auto_closed']);
    if ($autoClosed) {
        $closedStageRu = 'Автоматически отменена после месяца без действий оператора';
    } else {
        $closedStageRu = $job['stage'] === 'superseded' ? 'Заменена новой' : 'Отменена оператором';
    }
    $newJobId = (int)($job['superseded_by_job_id'] ?? 0);
    ?>
    <div class="card" style="border-left:3px solid #f0a020">
        <h3 style="margin-top:0"><?= $autoClosed ? '🤖' : '🔒' ?> Джоба закрыта: <?= htmlspecialchars($closedStageRu) ?></h3>
        <dl class="kv">
            <?php if ($autoClosed && !empty($lc['idle_days'])): ?>
                <dt>Период ожидания</dt><dd><?= (int)$lc['idle_days'] ?> дн.</dd>
            <?php endif; ?>
            <?php if ($autoClosed && !empty($lc['previous_stage'])): ?>
                <dt>Предыдущая стадия</dt><dd><code><?= htmlspecialchars((string)$lc['previous_stage']) ?></code></dd>
            <?php endif; ?>
            <?php if (!empty($job['closed_at'])): ?>
                <dt>Когда</dt>
                <dd><?= htmlspecialchars($fmtMsk((string)$job['closed_at'])) ?></dd>
            <?php endif; ?>
            <?php if (!empty($job['closed_by'])): ?>
                <dt>Кем</dt><dd><?= htmlspecialchars((string)$job['closed_by']) ?></dd>
            <?php endif; ?>
            <?php if (!empty($job['closed_reason'])): ?>
                <dt>Причина</dt><dd><?= htmlspecialchars((string)$job['closed_reason']) ?></dd>
            <?php endif; ?>
            <?php if ($newJobId > 0): ?>
                <dt>Новая джоба</dt>
                <dd><a class="btn btn-primary" href="/jobs/show?id=<?= $newJobId ?>">Открыть джобу #<?= $newJobId ?> →</a></dd>
            <?php endif; ?>
        </dl>
        <p class="muted small" style="margin-bottom:0">
            Возобновить закрытую джобу нельзя. Карточка сохранена для истории:
            журнал событий и артефакты ниже доступны только для чтения.
        </p>
    </div>
<?php endif; ?>

<?php /* a1.6.4: авто-завершённая (done) джоба — old_delurl_notify по истечении срока */ ?>
<?php $lcDone = $artifacts['lifecycle'] ?? []; if (!empty($lcDone['auto_closed']) && !$isClosed): ?>
<div class="card" style="border-left:3px solid #2e9e5b">
    <h3 style="margin-top:0">🤖 Завершена автоматически</h3>
    <dl class="kv">
        <?php if (!empty($job['closed_at'])): ?>
            <dt>Когда</dt><dd><?= htmlspecialchars($fmtMsk((string)$job['closed_at'])) ?></dd>
        <?php endif; ?>
        <?php if (!empty($lcDone['idle_days'])): ?>
            <dt>Период ожидания</dt><dd><?= (int)$lcDone['idle_days'] ?> дн.</dd>
        <?php endif; ?>
        <?php if (!empty($lcDone['previous_stage'])): ?>
            <dt>Предыдущая стадия</dt><dd><code><?= htmlspecialchars((string)$lcDone['previous_stage']) ?></code></dd>
        <?php endif; ?>
        <?php if (!empty($job['closed_reason'])): ?>
            <dt>Причина</dt><dd><?= htmlspecialchars((string)$job['closed_reason']) ?></dd>
        <?php endif; ?>
    </dl>
    <p class="muted small" style="margin-bottom:0">
        Завершена автоматически после истечения срока ручного удаления старых URL.
        Основная работа переезда уже была выполнена.
    </p>
</div>
<?php endif; ?>
<?php if ($isScheduledStart): ?>
<?php $nowMskStr = (new \DateTime('now', new \DateTimeZone('Europe/Moscow')))->format('Y-m-d H:i:s'); ?>
<div class="card" style="border: 2px solid #3a7bd5; background: rgba(58, 123, 213, 0.05);">
    <h3 style="margin-top:0;">⏰ Отложенный старт</h3>
    <p>
        Джоба создана, но cron <b>пока не подхватит</b> — старт запланирован на
        <code><?= htmlspecialchars($fmtMsk((string)$job['next_run_at'])) ?></code>
        (через <?= htmlspecialchars($startEta) ?>).
    </p>
    <p class="muted">
        Сейчас в Москве: <code><?= htmlspecialchars($nowMskStr) ?></code>.
        Когда наступит указанный момент, cron автоматически запустит pipeline.
    </p>
    <details style="margin-top: 8px;">
        <summary class="muted small" style="cursor:pointer;">Запустить раньше времени?</summary>
        <p class="muted small" style="margin-top: 6px;">
            Чтобы запустить сразу — нажми <b>«⚡ Шаг сейчас»</b> в верхней панели.
            Чтобы изменить время — отмени джобу и создай новую.
        </p>
    </details>
</div>
<?php endif; ?>

<?php
// v25.0-a1 (B3): панель readiness — когда джоба застряла на проверке
// готовности домена (update_classes_call + awaiting_user, ещё не ready).
$readinessStuck = $isAwaitingUser
    && (string)$job['stage'] === 'update_classes_call'
    && empty($job['domain_https_ready_at']);
if ($readinessStuck):
    $rd = json_decode((string)($job['artifacts_json'] ?? ''), true) ?: [];
    $rds = $rd['domain_readiness_stage'] ?? [];
    $rdStreak = (int)($job['domain_readiness_success_streak'] ?? ($rds['streak'] ?? 0));
    $rdChecks = (int)($rds['checks'] ?? 0);
    $rdReason = (string)($rds['last_reason'] ?? '');
    $rdHttp = $job['domain_http_initial_code'] ?? null;
    $rdHttps = $job['domain_https_final_code'] ?? null;
?>
<div class="card" style="border:2px solid var(--warning); background:rgba(230,162,60,0.05);">
    <h3 style="margin-top:0;">🌐 Готовность нового домена не подтверждена</h3>
    <p>
        Новый домен <b><?= htmlspecialchars((string)$job['new_domain']) ?></b>
        не подтвердил стабильный публичный <b>HTTPS 200</b> за отведённое время,
        поэтому смена классов (PHP-уникализация) не запускалась.
        Это ожидаемо, если DNS/SSL ещё прогреваются — панель ничего не сломала.
    </p>
    <table class="kv-table" style="width:100%; margin:8px 0;">
        <tr><td style="width:220px">Последний HTTP-код (http://)</td><td><code><?= $rdHttp === null ? '—' : (int)$rdHttp ?></code></td></tr>
        <tr><td>Последний HTTPS-код (https://)</td><td><code><?= $rdHttps === null ? '—' : (int)$rdHttps ?></code></td></tr>
        <tr><td>Успехов подряд</td><td><code><?= $rdStreak ?>/<?= (int)(class_exists('DomainReadinessService') ? DomainReadinessService::requiredSuccesses() : 2) ?></code></td></tr>
        <tr><td>Всего проверок</td><td><code><?= $rdChecks ?></code></td></tr>
        <?php if ($rdReason !== ''): ?>
        <tr><td>Причина</td><td><code><?= htmlspecialchars(class_exists('DomainReadinessService') ? DomainReadinessService::explainReason($rdReason) : $rdReason) ?></code></td></tr>
        <?php endif; ?>
    </table>
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
        <form method="post" action="/jobs/readiness-check-now" style="display:inline;">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-primary">🔄 Проверить сейчас</button>
        </form>
        <form method="post" action="/jobs/readiness-continue-waiting" style="display:inline;">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn">⏳ Продолжить ожидание</button>
        </form>
    </div>
    <p class="muted small" style="margin-bottom:0;">
        «Проверить сейчас» — немедленная проверка и новый отсчёт таймаута (streak
        обнуляется). «Продолжить ожидание» — вернуть в авто-цикл, сохранив
        накопленный прогресс. Если домен так и не поднимется — проверьте DNS
        (A-запись на VPS), SSL (Let's Encrypt выпущен) и что сайт открывается в браузере.
    </p>
</div>
<?php endif; ?>

<?php
// v25.2-a1.6.4.1 (§7/§9): восстановление рандомизации. Показываем, если стадия
// update_classes_call достигнута (или пройдена), но gate НЕ закрыт по данным
// (php_uniquification_verified_at пуст и нет not_applicable/operator_skipped) —
// в т.ч. для legacy-джоб, ошибочно продвинутых на wm_added при call_failed.
$ucUi = $artifactsForUi['update_classes_stage'] ?? [];
$ucGateOk = !empty($job['php_uniquification_verified_at'])
    || in_array((string)($ucUi['outcome'] ?? ''), ['not_applicable', 'operator_skipped'], true);
$ucIdx = array_search('update_classes_call', $stages, true);
$ucReached = ($ucIdx !== false) && ($currentIdx >= $ucIdx || $job['stage'] === 'update_classes_call');
$ucTerminal = in_array($job['stage'], ['done','failed','cancelled','superseded'], true);
if (!$ucGateOk && $ucReached && !$ucTerminal):
    $ucOutcome = (string)($ucUi['outcome'] ?? '');
    // §12: execution state из РЕАЛЬНОГО столбца, fallback на artifacts.
    $ucExecState = (string)($job['uc_execution_state'] ?? ($ucUi['execution_state'] ?? ''));
    // §gate-fix: intervention vs нейтральное ожидание доступности.
    $ucIntervention = class_exists('RefreshOrchestrator')
        ? RefreshOrchestrator::updateClassesInterventionActive($job)
        : ($ucOutcome !== '' || $ucExecState !== '');
    if (!$ucIntervention):
        // Нейтральное состояние: update_classes.php ещё не запускался (outcome=NULL,
        // execution_state=NULL) — рандомизация просто ждёт доступности домена.
        // Recovery/intervention-блок и кнопки НЕ показываем.
?>
<div class="card" style="border:1px solid var(--border); background:transparent;">
    <h3 style="margin-top:0;">🎲 Рандомизация ожидает доступности домена</h3>
    <p class="muted" style="margin-bottom:0;">
        Для домена <b><?= htmlspecialchars((string)$job['new_domain']) ?></b> смена классов
        (PHP-уникализация) ещё не запускалась: панель ждёт, пока новый домен подтвердит
        стабильный публичный HTTPS. Это штатное ожидание — вмешательство не требуется.
    </p>
    <table class="kv-table" style="width:100%; margin:8px 0 0;">
        <tr><td style="width:220px">Outcome</td><td><code>—</code></td></tr>
        <tr><td>Execution state</td><td><code>—</code></td></tr>
    </table>
</div>
<?php
    else:
    $ucFtpDetails = (string)($ucUi['ftp_details'] ?? '');
    // §12: показываем только реально разрешённые серверные действия.
    $verifyAllowed = !empty(($ucVerifyPolicy ?? ['allowed'=>false])['allowed']);
    $skipAllowed = !empty(($ucSkipPolicy ?? ['allowed'=>false])['allowed']);
?>
<div class="card" style="border:2px solid var(--warning); background:rgba(230,162,60,0.05);">
    <h3 style="margin-top:0;">🎲 Рандомизация классов не подтверждена</h3>
    <p>
        Для домена <b><?= htmlspecialchars((string)$job['new_domain']) ?></b> смена классов
        (PHP-уникализация) <b>не подтверждена по факту</b>: <code>php_uniquification_verified_at</code>
        пуст. Pipeline дальше <b>не пройдёт</b>, пока результат не проверен по FTP
        (mapping/CSS) или рандомизация не пропущена явно.
        <?php if ($job['stage'] !== 'update_classes_call'): ?>
            <br><b>Внимание:</b> джоба находится на стадии <code><?= htmlspecialchars((string)$job['stage']) ?></code>,
            но gate рандомизации не закрыт — сначала подтвердите рандом.
        <?php endif; ?>
    </p>
    <table class="kv-table" style="width:100%; margin:8px 0;">
        <tr><td style="width:220px">Outcome</td><td><code><?= htmlspecialchars($ucOutcome !== '' ? $ucOutcome : '—') ?></code></td></tr>
        <tr><td>Execution state</td><td><code><?= htmlspecialchars($ucExecState !== '' ? $ucExecState : '—') ?></code></td></tr>
        <?php if ($ucFtpDetails !== ''): ?>
        <tr><td>FTP-проверка</td><td><code><?= htmlspecialchars($ucFtpDetails) ?></code></td></tr>
        <?php endif; ?>
    </table>
    <?php if ($verifyAllowed || $skipAllowed): ?>
    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
        <?php if ($verifyAllowed): ?>
        <form method="post" action="/jobs/uc-verify-manual" style="display:inline;">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
            <button type="submit" class="btn btn-primary">✅ Проверить уже выполненный рандом и продолжить</button>
        </form>
        <?php endif; ?>
        <?php if ($skipAllowed): ?>
        <form method="post" action="/jobs/uc-skip" style="display:inline;"
              onsubmit="var c=(this.comment.value||'').trim(); if(!c){alert('Комментарий обязателен: укажите причину пропуска рандомизации.');this.comment.focus();return false;} return confirm('⏭ Пропустить рандомизацию классов?\n\nЭто откроет gate БЕЗ проверки применения классов. Используйте только если уверены, что рандом не нужен или уже применён вне панели.\n\nПродолжить?');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($csrfToken ?? ''), ENT_QUOTES) ?>">
            <input type="hidden" name="confirm" value="yes">
            <input type="text" name="comment" required placeholder="причина пропуска (обязательно, в audit)" style="padding:6px 8px; min-width:240px;">
            <button type="submit" class="btn">⏭ Пропустить рандомизацию</button>
        </form>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <p class="muted small">Для текущего состояния джобы ручные действия недоступны (обрабатывается автоматически либо уже решено).</p>
    <?php endif; ?>
    <p class="muted small" style="margin-bottom:0;">
        «Проверить уже выполненный рандом» — панель по FTP читает mapping desktop/mobile и
        generated CSS и подтверждает применение (новые классы присутствуют, старые отсутствуют).
        Скрипт <b>update_classes.php повторно НЕ запускается</b>. «Пропустить» — явный
        обход с записью в audit.
    </p>
</div>
<?php endif; ?>
<?php endif; ?>

<?php
// v25.0-b: панель host-подтверждения — джоба застряла на добавлении host в
// Вебмастер (wm_added + awaiting_user).
$wmHostStuck = $isAwaitingUser && (string)$job['stage'] === 'wm_added';
if ($wmHostStuck):
    $wd = json_decode((string)($job['artifacts_json'] ?? ''), true) ?: [];
    $wds = $wd['wm_added_stage'] ?? [];
    $wmChecks = (int)($wds['checks'] ?? 0);
?>
<div class="card" style="border:2px solid var(--warning); background:rgba(230,162,60,0.05);">
    <h3 style="margin-top:0;">🔗 Host не зарегистрирован Яндексом</h3>
    <p>
        Домен <b><?= htmlspecialchars((string)$job['new_domain']) ?></b> отправлен в
        Яндекс.Вебмастер, но host ещё не появился в аккаунте за отведённое время.
        Яндекс регистрирует host асинхронно — обычно это вопрос минут. Панель
        <b>не</b> отправляла addHost повторно (чтобы не задваивать заявку).
    </p>
    <table class="kv-table" style="width:100%; margin:8px 0;">
        <tr><td style="width:220px">Проверок выполнено</td><td><code><?= $wmChecks ?></code></td></tr>
        <tr><td>addHost отправлен</td><td><code><?= !empty($wds['add_sent']) ? 'да' : 'нет' ?></code></td></tr>
        <?php if (!empty($wds['account_id'])): ?>
        <tr><td>WM-аккаунт</td><td><code>#<?= (int)$wds['account_id'] ?></code></td></tr>
        <?php endif; ?>
    </table>
    <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:12px;">
        <form method="post" action="/jobs/wm-host-check-now" style="display:inline;">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-primary">🔄 Проверить сейчас</button>
        </form>
        <form method="post" action="/jobs/wm-host-continue-waiting" style="display:inline;">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn">⏳ Продолжить ожидание</button>
        </form>
    </div>
    <details style="margin-top:8px;">
        <summary style="cursor:pointer; color:var(--warning);">⚠ Подтвердить host_id вручную (аварийно)</summary>
        <form method="post" action="/jobs/wm-host-manual-confirm" style="margin-top:8px;"
              onsubmit="return confirm('Подтвердить host_id вручную?\n\nЭто аварийное действие: используйте, только если host уже виден в интерфейсе Вебмастера, но API его ещё не отдаёт. Действие записывается в историю.');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <div style="margin-bottom:6px;">
                <label>host_id из Вебмастера:<br>
                    <input type="text" name="host_id" required style="width:100%;max-width:400px;" placeholder="напр. https:new-domain.casino:443">
                </label>
            </div>
            <div style="margin-bottom:6px;">
                <label>Комментарий (обязательно):<br>
                    <input type="text" name="comment" required minlength="3" style="width:100%;max-width:400px;" placeholder="Почему подтверждаете вручную">
                </label>
            </div>
            <button type="submit" class="btn" style="border-color:var(--warning);">Подтвердить вручную</button>
        </form>
    </details>
    <p class="muted small" style="margin-bottom:0; margin-top:10px;">
        «Проверить сейчас» — немедленный опрос списка hosts. «Продолжить ожидание» —
        вернуть в авто-цикл. Ручное подтверждение — только когда host уже виден в
        Вебмастере, но API ещё не отдаёт его (заносится в историю с комментарием).
    </p>
</div>
<?php endif; ?>

<?php if ($isAwaitingUser): ?>
<!-- Блок awaiting_user — джоба ждёт пользователя -->
<div class="card" style="border: 2px solid var(--warning); background: rgba(230, 162, 60, 0.05);">
    <?php if ($isAutoRetry): ?>
        <h3 style="margin-top:0;">🔁 Auto-retry активен</h3>
        <p>
            Стадия <b><?= htmlspecialchars($stageHuman) ?></b>
            <small class="muted">(<code><?= htmlspecialchars($job['stage']) ?></code>)</small>
            не прошла, идёт авто-retry.
            <?php if ($nextRetryEta !== null): ?>
                <br>
                Cron подхватит и запустит следующую попытку
                <?php if ($nextRetryEta > 0): ?>
                    через <b><?= $nextRetryEta < 60 ? "{$nextRetryEta} сек" : (round($nextRetryEta / 60, 1) . ' мин') ?></b>
                    (<code><?= htmlspecialchars($fmtMsk((string)$job['next_run_at'])) ?></code>)
                <?php else: ?>
                    <b>уже сейчас</b> — ожидайте тика cron'а в течение минуты
                <?php endif; ?>
            <?php endif; ?>
        </p>
        <?php if (!empty($job['stage_error'])): ?>
            <p><b>Причина последнего фейла:</b><br><code style="color: var(--warning);"><?= htmlspecialchars(JobEventLogger::humanizeMessage($job['stage_error'])) ?></code></p>
        <?php endif; ?>
        <p style="margin-top: 12px; padding: 10px; background: var(--bg-elevated); border-radius: 4px;">
            <b>Если повтор не помогает:</b>
            <br>• <b>«↩️ Откатить snapshot»</b> в верхней панели — вернёт файлы и перезапустит pipeline с <code>redirect_disable</code>
            <br>• <b>«✖ Отменить»</b> — переведёт джобу в failed (без отката файлов)
            <br>• Или просто подожди — после 5 неудачных повторов джоба сама перейдёт в постоянное "ждёт оператора"
        </p>
    <?php else: ?>
        <h3 style="margin-top:0;">⏸ Джоба ждёт твоего вмешательства</h3>
        <p>
            Стадия <b><?= htmlspecialchars($stageHuman) ?></b>
            <small class="muted">(<code><?= htmlspecialchars($job['stage']) ?></code>)</small>
            остановлена.
            Cron <b>не</b> подхватит её автоматически — нужно решение от тебя.
        </p>
        <?php if (!empty($job['stage_error'])): ?>
            <p><b>Причина:</b> <code style="color: var(--warning);"><?= htmlspecialchars(JobEventLogger::humanizeMessage($job['stage_error'])) ?></code></p>
        <?php endif; ?>
    <?php endif; ?>

    <p style="margin-top: 16px;"><b>Что можно сделать:</b></p>
    <ul style="margin-bottom: 16px;">
        <li>Открой логи и артефакты ниже — увидишь что сканер нашёл и применил</li>
        <li>Если сайт работает корректно — нажми <b>«✅ Я поправил, продолжить»</b></li>
        <?php if ($job['stage'] === 'verify_replacement'): ?>
        <li>Если упал new_http (Could not resolve host) — нажми <b>«🔁 Повторить verify»</b> чтобы запустить проверку ещё раз (например если DNS уже пропагировался)</li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'ssl_le_polling'): ?>
        <li><b>SSL остановлен:</b> Pipeline не пойдёт дальше пока LE не выпустится (Webmaster без HTTPS не сработает). Варианты:</li>
        <li style="margin-left: 24px;">⏰ Если был rate-limit — подожди указанное время и нажми <b>«🔁 Повторить SSL polling»</b></li>
        <li style="margin-left: 24px;">🔧 Открой FastPanel UI → Сертификаты → попытайся выпустить вручную</li>
        <li style="margin-left: 24px;">🛡️ Возможно DDoS-Guard блокирует ACME-валидатор (whitelist IP в DDoS-Guard)</li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'wm_account_resolve'): ?>
        <li><b>Старый домен не найден в Webmaster (даже cascade):</b></li>
        <li style="margin-left: 24px;">🎯 <b>Лучшее решение</b> — выбери Webmaster аккаунт ниже и нажми <b>«🚀 Применить override и продолжить»</b>. Купленный домен и весь прогресс (DNS, SSL, замены) сохранятся, новый домен добавится в выбранный аккаунт и пройдёт полную индексацию. Старый домен НЕ будет удаляться (его нигде не нашли — это нормально).</li>
        <li style="margin-left: 24px;">⏭ Если хочешь вообще без Webmaster — нажми <b>«⏭ Пропустить шаг»</b>. Pipeline продолжит дальше — НО индексация не будет проверяться, редирект включится сразу.</li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'wm_added' || $job['stage'] === 'wm_verified' || $job['stage'] === 'wm_sitemap' || $job['stage'] === 'wm_recrawl'): ?>
        <li><b>Стадия Webmaster упала:</b></li>
        <li style="margin-left: 24px;">⏭ Если хочешь пропустить и идти дальше — нажми <b>«⏭ Пропустить шаг»</b></li>
        <li style="margin-left: 24px;">🔧 Если можешь поправить вручную (через webmaster.yandex.ru) — поправь и нажми <b>«✅ Я поправил, продолжить»</b></li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'index_watching'): ?>
        <li><b>Индексация не подтверждена за 30 минут:</b> Pipeline не пойдёт дальше пока сайт не в индексе (редирект не включится, старый домен не удалится). Варианты:</li>
        <li style="margin-left: 24px;">🔍 Проверь выдачу вручную: <code>site:новый-домен</code>, цитатный поиск <code>"новый-домен"</code>, или <code>erj:новый-домен</code></li>
        <li style="margin-left: 24px;">✅ Если в индексе уже виден руками — нажми <b>«✅ Я поправил, продолжить»</b> (Yandex API иногда лагает)</li>
        <li style="margin-left: 24px;">🔁 Если хочешь подождать ещё — нажми <b>«🔁 Перезапустить мониторинг»</b> (новый 30-мин цикл, тратит лимиты xmlstock)</li>
        <li style="margin-left: 24px;">⏭ Если хочешь не ждать индексации — нажми <b>«⏭ Пропустить шаг»</b> (редирект включится, старый домен удалится без подтверждения индекса)</li>
        <li style="margin-left: 24px;">📋 Загляни в логи сервера — приходил ли YandexBot/3.0, скачивал robots.txt + index.html + favicon.ico (флеш-рояль)</li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'wm_old_removed'): ?>
        <li><b>Не получилось удалить старый домен из Webmaster:</b></li>
        <li style="margin-left: 24px;">⏭ Не критично — нажми <b>«⏭ Пропустить шаг»</b> или <b>«✅ Я поправил, продолжить»</b>. Старый домен можно потом удалить руками через webmaster.yandex.ru</li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'move_htaccess_redirect'): ?>
        <li><b>Не удалось добавить редирект в .htaccess или verify провалился:</b></li>
        <li style="margin-left: 24px;">🔧 Проверь .htaccess сайта вручную — возможно мешают другие правила (например AllowOverride или другие RewriteCond выше)</li>
        <li style="margin-left: 24px;">🔁 Если поправил — нажми <b>«✅ Я поправил, продолжить»</b> (стадия скипнется)</li>
        <li style="margin-left: 24px;">🔍 Логи покажут что вернул curl: HTTP-код и Location</li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'move_submit_request'): ?>
        <li><b>Pipeline ждёт что ты подашь заявку на «Переезд сайта» через Webmaster:</b></li>
        <li style="margin-left: 24px;">📨 Используй блок «Подать заявку на переезд» ниже — там прямая ссылка и инструкция</li>
        <li style="margin-left: 24px;">✅ После подачи нажми <b>«✅ Я подал заявку»</b> — pipeline начнёт мониторить статус</li>
        <li style="margin-left: 24px;">⏭ Если хочешь обойтись без переезда (например уже подал руками и забыл) — <b>«⏭ Пропустить шаг»</b></li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'move_poll_status'): ?>
        <li><b>Yandex не обработал заявку или результат странный:</b></li>
        <li style="margin-left: 24px;">🔍 Зайди в Webmaster и проверь статус заявки руками</li>
        <li style="margin-left: 24px;">✅ Если переезд подтверждён руками — <b>«✅ Я поправил, продолжить»</b></li>
        <li style="margin-left: 24px;">⏭ Если переезд провалился и не хочешь его повторять — <b>«⏭ Пропустить шаг»</b> (джоба уйдёт в done)</li>
        <?php endif; ?>
        <?php if ($job['stage'] === 'old_delurl_notify'): ?>
        <li><b>Pipeline ждёт что ты отправишь URL'ы старого домена в «Удаление страниц из поиска»:</b></li>
        <li style="margin-left: 24px;">📋 Используй блок «Удалить старый домен из поиска» ниже — там готовый список URL'ов и прямая ссылка</li>
        <li style="margin-left: 24px;">✅ После отправки нажми <b>«✅ Я отправил на удаление»</b> — джоба завершится</li>
        <li style="margin-left: 24px;">⏭ Если не хочешь удалять — <b>«⏭ Пропустить шаг»</b> (тоже завершит джобу)</li>
        <?php endif; ?>
        <?php
        // v18.1.2: специальный hint если в verify_replacement провалилась проверка robots_php_logic
        $vsForHint = $artifacts['verify_stage'] ?? [];
        $robotsLogicFailed = ($job['stage'] === 'verify_replacement'
            && in_array('robots_php_logic', $vsForHint['failed_checks'] ?? [], true));
        ?>
        <?php if ($robotsLogicFailed): ?>
        <li><b>В файле robots.php нет правила закрывать неправильный домен:</b></li>
        <li style="margin-left: 24px;">🔧 На сайте несколько алиасов в FastPanel (старый и новый). robots.php должен проверять <code>$_SERVER['HTTP_HOST']</code> против <code>$domain</code> из config.php — иначе старые домены будут продолжать индексироваться поисковиком</li>
        <li style="margin-left: 24px;">📋 Скопируй правильный шаблон ниже (блок «🤖 robots.php требует правки») — там готовый код</li>
        <li style="margin-left: 24px;">✅ После правки файла — нажми <b>«✅ Я поправил, продолжить»</b></li>
        <li style="margin-left: 24px;">🤖 Или включи обратно <b>autopatch_robots_php</b> в настройках сайта (по дефолту включён) и нажми retry — система сама перепишет файл</li>
        <li style="margin-left: 24px;">⏭ Если уверен что не нужно — <b>«⏭ Пропустить шаг»</b> (на свой риск)</li>
        <?php endif; ?>
        <li>Если в коде панели появились новые правила сканирования (например апгрейд robots.php) — нажми <b>«🔁 Пересобрать план»</b> чтобы план перестроился и применился заново</li>
        <li>Если что-то пошло не так — нажми <b>«↩️ Откатить snapshot»</b> чтобы вернуть файлы как были</li>
    </ul>

    <?php
    // v17.7/v25.2-a1.3: выбор Webmaster-аккаунта (override). Вынесено в partial
    // _wm_account_select.php, чтобы показывать и на wm_account_resolve, и при
    // awaiting_no_account в переезде (§Пункт 1/2).
    ?>
    <?php if ($job['stage'] === 'wm_account_resolve'): ?>
        <?php include Paths::appRoot() . '/app/Views/jobs/_wm_account_select.php'; ?>
    <?php endif; ?>

    <?php
    // === v18: блок move_submit_request — подача заявки на переезд ===
    if ($job['stage'] === 'move_submit_request'):
        $msStage = $artifacts['move_submit_request_stage'] ?? [];
        $msEmail = (string)($msStage['new_account_email'] ?? '');
        $msUrl = (string)($msStage['webmaster_mirrors_url'] ?? '');
        $msNew = htmlspecialchars((string)($msStage['new_domain'] ?? $job['new_domain']), ENT_QUOTES);
    ?>
    <div style="background: rgba(58, 123, 213, 0.1); border: 1px solid rgba(58, 123, 213, 0.4);
                border-radius: 6px; padding: 14px 18px; margin-bottom: 12px;">
        <h4 style="margin-top: 0; margin-bottom: 12px;">🚚 Подать заявку на переезд через Webmaster</h4>
        <p style="margin: 0 0 10px 0;">Yandex не предоставляет API для этой операции — нужно сделать это руками за 4 шага:</p>
        <ol style="margin: 8px 0 14px 20px; line-height: 1.7;">
            <li>Войди в Webmaster под аккаунтом <code><?= htmlspecialchars($msEmail !== '' ? $msEmail : '— не определён —') ?></code></li>
            <li>Открой инструмент «Переезд сайта»:
                <?php if ($msUrl !== ''): ?>
                    <a href="<?= htmlspecialchars($msUrl) ?>" target="_blank" rel="noopener noreferrer">
                        🔗 прямая ссылка
                    </a>
                <?php else: ?>
                    <span class="muted">(host_id не определён — найди вручную в Webmaster)</span>
                <?php endif; ?>
            </li>
            <li>В поле «Новый адрес» введи:
                <code style="background: var(--bg-elevated); padding: 2px 6px; border-radius: 3px;
                             user-select: all; font-size: 14px;">https://<?= $msNew ?></code>
            </li>
            <li>Нажми «Сохранить» в Webmaster, потом вернись сюда</li>
        </ol>
        <form method="post" action="/jobs/acknowledge-move" style="display:inline;"
              onsubmit="return confirm('Подтверди что заявка на переезд подана через Webmaster.\n\nPipeline начнёт проверять статус (main_mirror) каждые 5-10 минут. Заявка обычно обрабатывается Yandex 30-40 минут.');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-success" style="font-size: 16px; padding: 10px 18px;">
                ✅ Я подал заявку — продолжить
            </button>
        </form>
        <p class="muted small" style="margin: 10px 0 0 0;">
            После подтверждения cron начнёт периодически проверять <code>main_mirror</code>
            старого домена через публичное API Webmaster.
            При обнаружении смены на новый домен — джоба завершится автоматически.
        </p>
    </div>
    <?php endif; ?>

    <?php
    // === v18.1.2: блок robots.php требует правки ===
    // Показывается когда verify_replacement в awaiting_user из-за провала robots_php_logic check
    $robotsCheck = $artifacts['verify_stage']['checks']['robots_php_logic'] ?? null;
    $showRobotsBlock = ($job['stage'] === 'verify_replacement'
        && is_array($robotsCheck)
        && empty($robotsCheck['ok']));
    if ($showRobotsBlock):
        $vrReason = (string)($robotsCheck['reason'] ?? '');
        $vrDetails = (array)($robotsCheck['details'] ?? []);
        $vrSnippet = (string)($robotsCheck['recommended_snippet'] ?? '');
        $vrExcerpt = (string)($robotsCheck['robots_excerpt'] ?? '');
        $vrHasHostCheck = (bool)($robotsCheck['has_host_check'] ?? false);
        $vrHasDisallow = (bool)($robotsCheck['has_disallow_branch'] ?? false);
        $vrAutopatchTried = (bool)($robotsCheck['autopatch_attempted'] ?? false);
        // v18.1.28: специально отмечаем сломанные шаблоны где Allow:/ вместо Disallow:/
        $vrBrokenTemplate = (bool)($robotsCheck['broken_template'] ?? false);
        $vrClosedBranch = (array)($robotsCheck['closed_branch'] ?? []);
    ?>
    <div style="background: rgba(220, 53, 69, 0.08); border: 1px solid rgba(220, 53, 69, 0.4);
                border-radius: 6px; padding: 14px 18px; margin-bottom: 12px;">
        <h4 style="margin-top: 0; margin-bottom: 12px;">🤖 robots.php требует правки</h4>
        <p style="margin: 0 0 10px 0;">
            <b>Причина:</b> <?= htmlspecialchars($vrReason) ?>
        </p>

        <?php if ($vrBrokenTemplate): ?>
            <!-- v18.1.28: сломанный шаблон — Allow:/ в "if (!sameHost)" branch -->
            <!-- Сюда попадаем только если autopatch не смог записать (FTP-проблема). -->
            <!-- При успешном autopatch результат становится ok=true и блок не показывается. -->
            <div style="background: rgba(220, 53, 69, 0.15); border: 1px solid rgba(220, 53, 69, 0.5);
                        border-radius: 4px; padding: 10px 12px; margin-bottom: 12px;">
                <p style="margin: 0 0 6px 0;">
                    🛑 <b>Сломанный шаблон robots.php.</b>
                    Внутри блока <code>if (!sameHost(...))</code> стоит
                    <code style="color:var(--danger);">echo "Allow: /"</code> вместо
                    <code style="color:var(--success);">echo "Disallow: /"</code>.
                </p>
                <p style="margin: 0 0 6px 0;">
                    Это значит что <b>СТАРЫЙ домен пускает поисковики в индекс</b>,
                    хотя должен от них закрываться.
                </p>
                <p style="margin: 0 0 6px 0;">
                    Система пыталась починить автоматически (autopatch обязателен для сломанных шаблонов
                    независимо от настройки сайта), но запись через FTP не удалась.
                </p>
                <?php if (!empty($vrClosedBranch['block_excerpt'])): ?>
                <details style="margin-top: 6px;">
                    <summary style="cursor:pointer; color: var(--text-muted);">
                        📄 Содержимое сломанного branch
                    </summary>
                    <pre style="margin: 8px 0 0 0; padding: 8px;
                                background: var(--bg-secondary, rgba(0,0,0,0.05));
                                border-radius: 4px; font-size: 0.85em;
                                white-space: pre-wrap;"><?= htmlspecialchars((string)$vrClosedBranch['block_excerpt']) ?></pre>
                </details>
                <?php endif; ?>
                <p style="margin: 8px 0 0 0; padding: 8px;
                          background: rgba(40, 167, 69, 0.1); border-radius: 4px;">
                    💡 <b>Как починить вручную (раз autopatch упал):</b>
                    открой robots.php через FTP/FastPanel и в блоке <code>if (!sameHost(...))</code>
                    замени <code>"Allow: /"</code> на <code>"Disallow: /"</code>.
                    Затем нажми <b>«🔄 Повторить verify»</b> выше. Или проверь FTP-доступ для сайта
                    и нажми retry — autopatch попробует снова.
                </p>
            </div>
        <?php endif; ?>

        <?php if ($vrAutopatchTried): ?>
            <p style="margin: 0 0 10px 0; padding: 8px; background: rgba(255, 193, 7, 0.15); border-radius: 4px;">
                ⚠️ <b>Autopatch включён, но запись не удалась.</b> Поправь файл руками или проверь FTP-доступ.
            </p>
        <?php elseif (!$vrBrokenTemplate): ?>
            <p style="margin: 0 0 10px 0; padding: 8px; background: rgba(58, 123, 213, 0.1); border-radius: 4px;">
                💡 <b>Совет:</b> autopatch для этого сайта <b>выключен</b>. По дефолту он включён —
                включи обратно (галка <code>autopatch_robots_php</code> в настройках сайта)
                и нажми retry, система сама перепишет файл рекомендуемым шаблоном.
            </p>
        <?php endif; ?>

        <p style="margin: 0 0 6px 0;"><b>Анализ файла robots.php:</b></p>
        <ul style="margin: 0 0 12px 18px; padding: 0;">
            <li>Проверка <code>HTTP_HOST</code> против <code>$domain</code>:
                <?= $vrHasHostCheck ? '<span style="color:var(--success);">✓ есть</span>' : '<span style="color:var(--danger);">✗ нет</span>' ?>
            </li>
            <li>Ветка с <code>Disallow: /</code> для неправильного домена:
                <?= $vrHasDisallow ? '<span style="color:var(--success);">✓ есть</span>' : '<span style="color:var(--danger);">✗ нет</span>' ?>
            </li>
            <?php foreach ($vrDetails as $d): ?>
                <li class="muted small"><?= htmlspecialchars((string)$d) ?></li>
            <?php endforeach; ?>
        </ul>

        <?php if ($vrExcerpt !== ''): ?>
        <details style="margin-bottom: 12px;">
            <summary style="cursor:pointer; color: var(--text-muted);">
                📄 Текущее содержимое robots.php (первые 500 символов)
            </summary>
            <pre style="margin-top: 8px; padding: 10px; background: var(--bg-elevated); border-radius: 4px; font-size: 0.85em; max-height: 200px; overflow:auto;"><code><?= htmlspecialchars($vrExcerpt) ?></code></pre>
        </details>
        <?php endif; ?>

        <?php if ($vrSnippet !== ''): ?>
        <p style="margin: 12px 0 6px 0;"><b>📋 Рекомендуемый robots.php (нажми чтобы скопировать):</b></p>
        <textarea readonly id="recommended_robots_snippet" rows="20"
                  onclick="this.select(); document.execCommand('copy'); this.parentNode.querySelector('.copy-feedback').textContent = '✓ Скопировано в буфер!'; setTimeout(() => this.parentNode.querySelector('.copy-feedback').textContent = '', 2000);"
                  style="width:100%; font-family: 'Courier New', monospace; font-size: 0.85em; padding: 10px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: 4px; color: var(--text); resize: vertical;"><?= htmlspecialchars($vrSnippet) ?></textarea>
        <p class="muted small copy-feedback" style="margin: 4px 0; min-height: 18px; color: var(--success);"></p>
        <?php endif; ?>

        <p style="margin: 12px 0 0 0;">
            <b>Как править:</b>
        </p>
        <ol style="margin: 8px 0 0 18px; padding: 0;">
            <li>Скопируй код выше (один клик в textarea)</li>
            <li>Зайди в FastPanel → файлы сайта → открой <code>robots.php</code></li>
            <li>Замени всё содержимое на скопированный код</li>
            <li>Сохрани файл</li>
            <li>Вернись сюда и нажми <b>«✅ Я поправил, продолжить»</b></li>
        </ol>
    </div>
    <?php endif; ?>

    <?php
    // === v18: блок old_delurl_notify — отправка URL в "Удаление страниц из поиска" ===
    if ($job['stage'] === 'old_delurl_notify'):
        $duStage = $artifacts['old_delurl_notify_stage'] ?? [];
        $duUrls = $duStage['urls'] ?? [];
        $duEmail = (string)($duStage['old_account_email'] ?? '');
        $duToolUrl = (string)($duStage['del_url_tool_url'] ?? '');
        $duUrlsCount = (int)($duStage['urls_count'] ?? count($duUrls));
        $duSource = (string)($duStage['urls_source'] ?? '?');
        $duUrlsText = is_array($duUrls) ? implode("\n", $duUrls) : '';
    ?>
    <div style="background: rgba(220, 53, 69, 0.08); border: 1px solid rgba(220, 53, 69, 0.4);
                border-radius: 6px; padding: 14px 18px; margin-bottom: 12px;">
        <h4 style="margin-top: 0; margin-bottom: 12px;">🗑 Удалить старый домен из поиска</h4>
        <p style="margin: 0 0 10px 0;">
            Yandex не предоставляет API для удаления страниц из выдачи —
            это делается руками через инструмент <i>Webmaster → Удаление страниц из поиска</i>.
            Лимит Yandex: 500 URL/сутки. У тебя <b><?= $duUrlsCount ?></b> URL.
        </p>
        <ol style="margin: 8px 0 14px 20px; line-height: 1.7;">
            <li>Войди в Webmaster под аккаунтом <code><?= htmlspecialchars($duEmail !== '' ? $duEmail : '— не определён —') ?></code></li>
            <li>Открой инструмент «Удаление страниц из поиска»:
                <?php if ($duToolUrl !== ''): ?>
                    <a href="<?= htmlspecialchars($duToolUrl) ?>" target="_blank" rel="noopener noreferrer">
                        🔗 прямая ссылка
                    </a>
                <?php else: ?>
                    <span class="muted">(host_id не определён — найди вручную)</span>
                <?php endif; ?>
            </li>
            <li>Скопируй список URL ниже (<code>Ctrl+A → Ctrl+C</code> в textarea), вставь в Webmaster</li>
            <li>Выбери причину «Страница удалена с сайта» (или подходящую) и нажми «Удалить»</li>
            <li>Вернись сюда и нажми «✅ Я отправил на удаление»</li>
        </ol>
        <p style="margin: 10px 0 6px 0;"><b>📋 Список URL для удаления</b>
            <span class="muted small">(источник: <?= htmlspecialchars($duSource) ?>)</span>:</p>
        <textarea readonly rows="10" onclick="this.select();"
                  style="width: 100%; box-sizing: border-box; font-family: monospace;
                         font-size: 12px; background: var(--bg-elevated); color: var(--text);
                         border: 1px solid var(--border); border-radius: 4px;
                         padding: 8px; resize: vertical;"><?= htmlspecialchars($duUrlsText) ?></textarea>
        <p class="muted small" style="margin: 4px 0 14px 0;">Кликни в поле — выделится весь текст. Скопируй и вставь в Webmaster.</p>
        <form method="post" action="/jobs/acknowledge-delurl" style="display:inline;"
              onsubmit="return confirm('Подтверди что URL отправлены в Webmaster на удаление.\n\nДжоба будет завершена (→ done).');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-success" style="font-size: 16px; padding: 10px 18px;">
                ✅ Я отправил на удаление — завершить джобу
            </button>
        </form>
    </div>
    <?php endif; ?>

    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
        <form method="post" action="/jobs/approve-continue" style="display:inline;"
              onsubmit="return confirm('Продолжить джобу? Стадия будет помечена ok и cron перейдёт на следующую.');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-success">✅ Я поправил, продолжить</button>
        </form>

        <?php
        // v18.1.19: «Подтвердить редирект вручную» — отдельная кнопка для случая когда
        // smoke timeout (http_code=0) из-за сетевой блокировки панель↔VPS, но оператор
        // лично проверил /play в браузере и видит 302 на партнёрку.
        // Отличие от «Я поправил, продолжить»: не сбрасывает smoke_attempt (что
        // привело бы к новой попытке smoke и снова timeout), а сразу пропускает дальше.
        $showManualConfirm = $job['stage'] === 'redirect_enable'
            && !empty($artifactsForUi['redirect_enabled_stage']['smoke_attempt'])
            && empty($artifactsForUi['redirect_enabled_stage']['smoke_test']['ok'])
            && ((int)($artifactsForUi['redirect_enabled_stage']['smoke_test']['http_code'] ?? 0)) === 0;
        ?>
        <?php if ($showManualConfirm): ?>
        <form method="post" action="/jobs/confirm-redirect-manually" style="display:inline;"
              onsubmit="return confirm('Подтвердить редирект ВРУЧНУЮ?\n\nИспользуй ТОЛЬКО если:\n• Ты лично открыл https://<?= htmlspecialchars((string)$job['new_domain']) ?>/play в браузере с Referer от google.com\n• И увидел 302 редирект на партнёрку\n• Проверка с сервера панели не доходит из-за сетевой проблемы (timeout, http_code=0)\n\nЭто запишет факт ручного подтверждения и сразу перейдёт к следующей стадии. Проверка редиректа НЕ будет переисполнена.\n\nЕсли хочешь чтобы проверка попробовала заново — используй «Я поправил, продолжить».');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-warning"
                    title="Пометить редирект как работающий, пропустить проверку редиректа (использовать только если проверил вручную в браузере)">
                🔧 Подтвердить редирект вручную
            </button>
        </form>
        <?php endif; ?>

        <?php
        // v17.5: «Пропустить шаг» доступна для большинства не-критичных стадий.
        // Запрещаем для critical-stages где skip не имеет смысла или опасен.
        $cantSkip = in_array($job['stage'], [
            'queued', 'domain_purchasing', 'aliases_added', 'ssl_self_signed_first',
            'redirect_disable', 'analyze_site', 'config_replaced', 'verify_replacement',
            'ssl_le_polling',
        ], true);
        ?>
        <?php if (!$cantSkip): ?>
        <form method="post" action="/jobs/skip-stage" style="display:inline;"
              onsubmit="return confirm('Пропустить стадию <?= htmlspecialchars($stageHuman) ?>?\n\nСтадия будет помечена как skipped, cron перейдёт на следующую. Pipeline продолжится с пропуском этой стадии.\n\nИспользуй когда стадия не критична или ты решил проблему руками.');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-warning">⏭ Пропустить шаг</button>
        </form>
        <?php endif; ?>

        <?php if ($job['stage'] === 'verify_replacement'): ?>
        <form method="post" action="/jobs/retry-verify" style="display:inline;"
              onsubmit="return confirm('Повторить verify? Стадия запустится заново. Если DNS уже пропагирован — пройдёт успешно. Лимит auto-retry будет сброшен (3 новых попытки).');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-primary">🔁 Повторить verify</button>
        </form>
        <?php endif; ?>
        <?php if ($job['stage'] === 'ssl_le_polling'): ?>
        <form method="post" action="/jobs/retry-ssl" style="display:inline;"
              onsubmit="return confirm('Повторить SSL polling с нуля?\n\nState polling сбросится, начнётся новый 6-часовой цикл. Если задача упёрлась в rate-limit — подожди указанное время в Telegram-алерте, иначе попадёшь в недельный бан.');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-primary">🔁 Повторить SSL polling</button>
        </form>
        <?php endif; ?>
        <?php if ($job['stage'] === 'index_watching'): ?>
        <form method="post" action="/jobs/retry-index" style="display:inline;"
              onsubmit="return confirm('Перезапустить мониторинг индексации с нуля?\n\nОбнулится state, начнётся новый 30-минутный polling.\n\nПолезно если: предыдущая попытка timeout, но ты ждёшь что Yandex скоро подхватит.\nКаждый запуск тратит лимиты xmlstock (если включён).');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-primary">🔁 Перезапустить мониторинг</button>
        </form>
        <?php endif; ?>
        <form method="post" action="/jobs/rebuild-plan" style="display:inline;"
              onsubmit="return confirm('Пересобрать план?\n\nДжоба вернётся на стадию analyze_site, скан и применение пройдут заново. Прежние snapshot\'ы сохраняются — можно откатить если новый план хуже.');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-primary">🔁 Пересобрать план</button>
        </form>
        <form method="post" action="/jobs/rollback" style="display:inline;"
              onsubmit="return confirm('↩️ Откатить snapshot?\n\nФайлы на VPS будут восстановлены, домен в БД вернётся на старый.\nPipeline сбросится на ssl_self_signed_first и cron перезапустит замены через минуту.\n\nПродолжить?');">
            <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
            <button type="submit" class="btn btn-danger">↩️ Откатить snapshot</button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/_ban_monitor_card.php'; ?>

<!-- Прогресс-бар -->
<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <h3 style="margin:0;">Прогресс <?= $progressPct ?>%</h3>
        <span style="color: var(--text-muted); font-size:0.9em;">
            Стадия <?= $currentIdx + 1 ?> из <?= count($stages) ?>
        </span>
    </div>
    <div style="background: var(--bg-elevated); border-radius: 8px; height: 12px; overflow: hidden;">
        <div style="background: <?= $job['stage'] === 'failed' ? 'var(--danger)' : 'var(--primary)' ?>;
                    width: <?= $progressPct ?>%; height: 100%;
                    transition: width 0.5s ease;"></div>
    </div>
    <div style="margin-top: 12px; display:flex; gap:6px; flex-wrap:wrap; font-size:0.8em;">
        <?php foreach ($stages as $i => $st): ?>
            <?php
            $isPast = $i < $currentIdx || $job['stage'] === 'done';
            $isCurrent = $i === $currentIdx && !in_array($job['stage'], ['done','failed','cancelled','superseded'], true); // v24.2
            $isFailed = $i === $currentIdx && $job['stage'] === 'failed';
            $cls = $isFailed ? 'is-bad' : ($isPast ? 'is-ok' : ($isCurrent ? 'is-warn' : ''));

            // v25.2-a1.6.4.1 (§10): стадия рандомизации красится ПО ДАННЫМ, а не по
            // положению в pipeline — иначе ложно-зелёная при call_failed/wrong_site.
            if ($st === 'update_classes_call') {
                $uc = $artifactsForUi['update_classes_stage'] ?? [];
                $ucOutcome = (string)($uc['outcome'] ?? '');
                $ucExec = (string)(($job['uc_execution_state'] ?? '') !== '' ? $job['uc_execution_state'] : ($uc['execution_state'] ?? ''));
                $verifiedAt = $job['php_uniquification_verified_at'] ?? null;
                $ucSkipped = !empty($uc['skipped_by_operator']) || $ucOutcome === 'operator_skipped';
                if ($ucSkipped) {
                    // §19: пропуск оператором — отдельно от зелёной FTP-верификации.
                    $cls = 'is-warn'; $ucSkipMark = true;
                } elseif (!empty($verifiedAt) || $ucOutcome === 'not_applicable') {
                    $cls = 'is-ok';
                } elseif (in_array($ucOutcome, ['call_failed','wrong_site','wrong_root','not_applied','verification_error'], true)) {
                    $cls = 'is-bad';
                } elseif (in_array($ucOutcome, ['verification_pending','ambiguous','applied_verification_pending'], true)
                          || in_array($ucExec, ['started','ambiguous'], true)) {
                    $cls = 'is-warn';
                }
                // иначе оставляем расчёт по индексу (стадия ещё не начиналась)
            }
            ?>
            <span class="hub-mini-pill <?= $cls ?>" style="font-size:0.85em;">
                <span class="hub-mini-pill__dot"></span>
                <span><?= htmlspecialchars(JobEventLogger::stageLabel($st)) ?><?= !empty($ucSkipMark) ? ' ⏭' : '' ?></span>
            </span>
            <?php $ucSkipMark = false; ?>
        <?php endforeach; ?>
    </div>
</div>

<!-- Свойства джобы -->
<div class="card">
    <h3>Свойства джобы</h3>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Создана</td><td><code><?= htmlspecialchars($fmtMsk((string)$job['created_at'])) ?></code></td></tr>
        <tr><td>Старый домен</td><td><code><?= htmlspecialchars($job['old_domain']) ?></code></td></tr>
        <tr><td>Новый домен</td><td><code><?= htmlspecialchars($job['new_domain'] ?: '— ещё не куплен —') ?></code></td></tr>
        <?php if ($job['old_sub_id'] !== ''): ?>
            <tr><td>Старый sub_id</td><td><code><?= htmlspecialchars($job['old_sub_id']) ?></code></td></tr>
            <tr><td>Новый sub_id</td><td><code style="color: var(--success);"><?= htmlspecialchars($job['new_sub_id']) ?></code></td></tr>
        <?php endif; ?>
        <tr><td>Stage started</td><td><code><?= htmlspecialchars(!empty($job['stage_started_at']) ? $fmtMsk((string)$job['stage_started_at']) : '—') ?></code></td></tr>
        <tr><td>Stage finished</td><td><code><?= htmlspecialchars(!empty($job['stage_finished_at']) ? $fmtMsk((string)$job['stage_finished_at']) : '—') ?></code></td></tr>
        <?php
        // v18-fix: подсказки про retry verify_replacement
        $verifyRetryCount = (int)($artifactsForUi['verify_stage']['auto_retry_count'] ?? 0);
        if ($verifyRetryCount > 0 && $job['stage'] === 'verify_replacement'):
        ?>
            <tr style="background: rgba(230, 162, 60, 0.08);">
                <td>🔁 Auto-retry verify</td>
                <td>
                    <b><?= $verifyRetryCount ?> / 5</b>
                    <?php if (!empty($job['next_run_at'])): ?>
                        <small class="muted">· следующая попытка не раньше <code><?= htmlspecialchars($fmtMsk((string)$job['next_run_at'])) ?></code></small>
                    <?php endif; ?>
                    <br>
                    <small class="muted">
                        Если хочешь прервать retry-цикл — нажми <b>«Отменить»</b> или <b>«Откатить snapshot»</b>
                        (после 5 неудачных попыток джоба перейдёт в <i>"ждёт оператора"</i> сама).
                    </small>
                </td>
            </tr>
        <?php endif; ?>
        <?php
        // v18-fix: rollback history (сохраняется в rollback'е)
        $rbHistory = $artifactsForUi['rollback_history'] ?? [];
        if (!empty($rbHistory)):
        ?>
            <tr>
                <td>↩️ Откаты</td>
                <td>
                    Было <b><?= count($rbHistory) ?></b> откат(ов).
                    Последний: <code><?= htmlspecialchars($fmtMsk((string)(end($rbHistory)['at'] ?? ''))) ?></code>
                </td>
            </tr>
        <?php endif; ?>
        <?php if ($job['stage_error']): ?>
            <tr><td>Ошибка</td><td><code style="color: var(--danger);"><?= htmlspecialchars(JobEventLogger::humanizeMessage($job['stage_error'])) ?></code></td></tr>
        <?php endif; ?>
    </table>
</div>

<!-- Лог событий -->
<div class="card">
    <h3>Лог событий (<?= count($events) ?>)</h3>
    <?php if (empty($events)): ?>
        <p style="color: var(--text-muted);">Пока нет событий. Cron подхватит джобу в течение минуты.</p>
    <?php else: ?>
        <div style="max-height: 600px; overflow-y: auto;">
        <?php foreach ($events as $ev): ?>
            <?php
            $lvl = $ev['level'] ?? 'info';
            $color = [
                'info'  => 'var(--text-muted)',
                'warn'  => 'var(--warning)',
                'error' => 'var(--danger)',
                'ok'    => 'var(--success)',
            ][$lvl] ?? 'var(--text-muted)';
            $icon = ['info'=>'·', 'warn'=>'⚠', 'error'=>'✖', 'ok'=>'✓'][$lvl] ?? '·';
            ?>
            <div style="padding:8px 0; border-bottom: 1px solid var(--border); display:flex; gap:12px;">
                <span style="color: <?= $color ?>; font-weight: bold; min-width: 20px;"><?= $icon ?></span>
                <span style="color: var(--text-muted); min-width: 140px; font-size: 0.85em;"
                      title="UTC: <?= htmlspecialchars((string)$ev['created_at']) ?>">
                    <?= htmlspecialchars(Time::msk((string)$ev['created_at'], 'Y-m-d H:i:s', false)) ?>
                </span>
                <span style="color: var(--text-muted); min-width: 130px; font-size: 0.85em;">
                    [<?= htmlspecialchars($ev['stage']) ?>]
                </span>
                <span style="flex:1;"><?= htmlspecialchars(JobEventLogger::humanizeMessage((string)$ev['message'])) ?></span>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php if ($artifacts): ?>
<?php if (!empty($artifacts['aliases_stage'])): ?>
<!-- Алиасы (стадия aliases_added) -->
<div class="card">
    <h3>🌐 Алиасы FastPanel</h3>
    <?php $as = $artifacts['aliases_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr>
            <td style="width:200px;">Было</td>
            <td>
                <?php if (empty($as['before'])): ?>
                    <span class="muted">— нет —</span>
                <?php else: ?>
                    <?php foreach ($as['before'] as $a): ?>
                        <code style="margin-right: 6px;"><?= htmlspecialchars($a) ?></code>
                    <?php endforeach; ?>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td>Добавлено</td>
            <td>
                <?php if (empty($as['added'])): ?>
                    <span class="muted">— ничего —</span>
                <?php else: ?>
                    <?php foreach ($as['added'] as $a): ?>
                        <code style="color: var(--success); margin-right: 6px;">+ <?= htmlspecialchars($a) ?></code>
                    <?php endforeach; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php if (!empty($as['already_existed'])): ?>
        <tr>
            <td>Уже было (пропуск)</td>
            <td>
                <?php foreach ($as['already_existed'] as $a): ?>
                    <code style="color: var(--text-muted); margin-right: 6px;"><?= htmlspecialchars($a) ?></code>
                <?php endforeach; ?>
            </td>
        </tr>
        <?php endif; ?>
        <tr>
            <td>Стало (всего <?= count($as['after'] ?? []) ?>)</td>
            <td>
                <?php foreach (($as['after'] ?? []) as $a): ?>
                    <code style="margin-right: 6px;"><?= htmlspecialchars($a) ?></code>
                <?php endforeach; ?>
            </td>
        </tr>
    </table>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['replacement_plan'])): ?>
<!-- План замен (стадия analyze_site) -->
<div class="card">
    <h3>📋 План замен</h3>
    <?php $plan = $artifacts['replacement_plan']; ?>
    <p>
        <span class="muted">Просканировано файлов:</span> <code><?= (int)($plan['files_scanned'] ?? 0) ?></code>
        ·
        <span class="muted">Найдено замен:</span> <code><?= (int)($plan['replacements_count'] ?? 0) ?></code>
    </p>
    <?php /* v18-fix: BackupFileCleaner результат */ ?>
    <?php $cu = $artifacts['analyze_stage']['backup_cleanup'] ?? null; ?>
    <?php if ($cu !== null && (int)($cu['candidates'] ?? 0) > 0): ?>
        <p style="font-size:0.9em; padding:6px 10px; background:var(--bg-elevated); border-radius:4px;">
            🧹 <b>Подчистка старых .bak:</b>
            <?php $delCount = (int)($cu['deleted'] ?? 0); ?>
            <?php if ($delCount > 0): ?>
                удалено <code><?= $delCount ?></code> файлов старше 7 дней
                <?php if (!empty($cu['deleted_names'])): ?>
                    <small class="muted">(<?= htmlspecialchars(implode(', ', array_slice($cu['deleted_names'], 0, 3))) ?><?= count($cu['deleted_names']) > 3 ? '...' : '' ?>)</small>
                <?php endif; ?>
            <?php else: ?>
                все <code><?= (int)($cu['candidates'] ?? 0) ?></code> .bak-файлов слишком свежие, не трогаем
            <?php endif; ?>
            <?php if ((int)($cu['skipped_recent'] ?? 0) > 0): ?>
                · оставлено свежих: <code><?= (int)$cu['skipped_recent'] ?></code>
            <?php endif; ?>
        </p>
    <?php endif; ?>
    <?php if (!empty($plan['replacements'])): ?>
        <table class="hub-table" style="width:100%; font-size:0.9em;">
            <thead>
                <tr>
                    <th style="width:100px;">Файл</th>
                    <th style="width:50px;">Стр.</th>
                    <th style="width:160px;">Правило</th>
                    <th>Замена</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($plan['replacements'] as $r): ?>
                <tr>
                    <td><code><?= htmlspecialchars($r['file']) ?></code></td>
                    <td><?= htmlspecialchars((string)($r['line'] ?? '?')) ?></td>
                    <td><code style="font-size:0.85em;"><?= htmlspecialchars($r['rule_id']) ?></code></td>
                    <td>
                        <?php if ($r['rule_id'] === 'whole_file_replace'): ?>
                            <div style="font-size:0.9em; line-height:1.5;">
                                <span style="color:var(--warning);">📄 Файл заменён целиком</span>:
                                <code><?= mb_strlen($r['before']) ?></code> байт →
                                <code><?= mb_strlen($r['after']) ?></code> байт
                            </div>
                            <small class="muted"><?= htmlspecialchars($r['reason'] ?? '') ?></small>
                        <?php else: ?>
                            <div style="font-size:0.85em; line-height:1.5;">
                                <span style="color:var(--danger);">- </span><code><?= htmlspecialchars(mb_substr($r['before'], 0, 200)) ?></code><br>
                                <span style="color:var(--success);">+ </span><code><?= htmlspecialchars(mb_substr($r['after'], 0, 200)) ?></code>
                            </div>
                            <small class="muted"><?= htmlspecialchars($r['reason'] ?? '') ?></small>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="muted">Замен не найдено. Возможно, домен уже актуален.</p>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['config_replaced_stage'])): ?>
<!-- Применение плана (стадия config_replaced) -->
<div class="card">
    <h3>📝 Применение замен</h3>
    <?php $cr = $artifacts['config_replaced_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr>
            <td style="width:200px;">Файлов изменено</td>
            <td><code><?= (int)($cr['files_changed'] ?? 0) ?></code></td>
        </tr>
        <tr>
            <td>Замен применено</td>
            <td><code style="color: var(--success);"><?= (int)($cr['replacements_applied'] ?? 0) ?></code></td>
        </tr>
        <?php if (!empty($cr['replacements_failed'])): ?>
        <tr>
            <td>Замен провалено</td>
            <td><code style="color: var(--danger);"><?= (int)$cr['replacements_failed'] ?></code></td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($cr['snapshots'])): ?>
        <tr>
            <td>Snapshot'ы</td>
            <td>
                <?php foreach ($cr['snapshots'] as $orig => $snap): ?>
                    <code style="margin-right:6px;"><?= htmlspecialchars($orig) ?> → <?= htmlspecialchars($snap) ?></code><br>
                <?php endforeach; ?>
                <?php if (!empty($cr['snapshot_dir'])): ?>
                    <details style="margin-top:8px;">
                        <summary style="cursor:pointer; color: var(--text-muted); font-size: 0.9em;">
                            📂 Где лежат файлы snapshot'ов
                        </summary>
                        <div style="margin-top:6px; padding:8px 12px; background: var(--bg-elevated); border-radius:4px; font-size:0.85em;">
                            <p style="margin:0 0 4px 0;">
                                <b>Путь на сервере панели:</b>
                            </p>
                            <p style="margin:0; word-break:break-all;">
                                <code><?= htmlspecialchars($cr['snapshot_dir']) ?></code>
                            </p>
                            <p style="margin:8px 0 0 0; color: var(--text-muted);">
                                Файлы хранятся <b>на сервере панели</b> (не в директории сайта).
                                Кнопка «↩️ Откатить snapshot» загружает их обратно по FTP в директорию сайта.
                            </p>
                            <p style="margin:8px 0 0 0;">
                                <a href="/jobs/download-snapshots?id=<?= (int)$job['id'] ?>"
                                   class="btn btn-secondary"
                                   style="font-size:0.9em; padding:4px 12px;">
                                    💾 Скачать все snapshot'ы как .tar.gz
                                </a>
                            </p>
                        </div>
                    </details>
                <?php endif; ?>
            </td>
        </tr>
        <?php endif; ?>
    </table>
    <?php if (!empty($cr['errors'])): ?>
        <div class="hub-flash hub-flash--warning" style="margin-top:12px;">
            <b>Ошибки:</b>
            <ul style="margin:6px 0;">
                <?php foreach ($cr['errors'] as $err): ?>
                    <li><?= htmlspecialchars($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['verify_stage'])): ?>
<!-- Результат верификации (стадия verify_replacement) -->
<div class="card">
    <h3>🔍 Верификация</h3>
    <?php $vs = $artifacts['verify_stage']; ?>
    <p>
        <?php if (!empty($vs['overall_ok'])): ?>
            <span style="color: var(--success);">✓ Все проверки прошли</span>
        <?php else: ?>
            <span style="color: var(--danger);">✗ Провалены проверки: <?= htmlspecialchars(implode(', ', $vs['failed_checks'] ?? [])) ?></span>
        <?php endif; ?>
    </p>
    <table class="hub-table" style="width:100%;">
        <thead>
            <tr><th style="width:200px;">Проверка</th><th style="width:60px;">OK</th><th>Детали</th></tr>
        </thead>
        <tbody>
        <?php foreach (($vs['checks'] ?? []) as $name => $check): ?>
            <tr>
                <td><code><?= htmlspecialchars($name) ?></code></td>
                <td>
                    <?php if (!empty($check['ok'])): ?>
                        <span style="color:var(--success);">✓</span>
                    <?php else: ?>
                        <span style="color:var(--danger);">✗</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (!empty($check['url'])): ?>
                        <code><?= htmlspecialchars($check['url']) ?></code>
                        <?php if (!empty($check['http_code'])): ?>
                            → HTTP <?= (int)$check['http_code'] ?>
                        <?php endif; ?>
                        <?php if (!empty($check['used_resolve'])): ?>
                            <span style="display:inline-block; margin-left:6px; padding:1px 6px;
                                  background:rgba(255,193,7,0.2); color:#ffc107; border-radius:3px;
                                  font-size:0.75em;" title="Запрос пошёл через --resolve, обходя DNS (DNS ещё пропагируется)">
                                via --resolve
                            </span>
                        <?php endif; ?>
                        <br>
                    <?php endif; ?>
                    <?php if (!empty($check['message'])): ?>
                        <small class="muted"><?= htmlspecialchars($check['message']) ?></small>
                    <?php endif; ?>
                    <?php if (!empty($check['body_excerpt'])): ?>
                        <details style="margin-top: 4px;">
                            <summary class="muted small" style="cursor:pointer; font-size:0.85em;">показать что вернул сервер</summary>
                            <pre style="background: var(--bg-elevated); padding: 8px; border-radius: 4px;
                                        font-size: 0.8em; max-height: 150px; overflow:auto; margin-top: 4px;
                                        white-space: pre-wrap; word-break: break-all;"><?= htmlspecialchars((string)$check['body_excerpt']) ?></pre>
                        </details>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <?php /* v18-fix: история auto-retry попыток */ ?>
    <?php if (!empty($vs['auto_retry_count'])): ?>
        <div style="margin-top: 12px; padding: 10px; background: var(--bg-elevated); border-radius: 4px;">
            <strong>🔁 Авто-retry попыток:</strong> <?= (int)$vs['auto_retry_count'] ?> / 5
            <?php if (!empty($vs['last_retry_at'])): ?>
                <small class="muted"> · последний: <?= htmlspecialchars($fmtMsk((string)$vs['last_retry_at'])) ?></small>
            <?php endif; ?>
            <?php if (!empty($vs['retry_history']) && is_array($vs['retry_history'])): ?>
                <details style="margin-top: 6px;">
                    <summary class="muted small" style="cursor:pointer;">История попыток</summary>
                    <table class="hub-table" style="width:100%; margin-top:6px; font-size:0.85em;">
                        <thead>
                            <tr><th style="width:60px;">#</th><th style="width:150px;">Время</th><th>Провалены</th><th style="width:100px;">След. retry</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($vs['retry_history'] as $rh): ?>
                            <tr>
                                <td><?= (int)($rh['attempt'] ?? 0) ?></td>
                                <td><small><?= htmlspecialchars($fmtMsk((string)($rh['failed_at'] ?? ''))) ?></small></td>
                                <td><small><?= htmlspecialchars(implode(', ', (array)($rh['failed_checks'] ?? []))) ?></small></td>
                                <td><small>через <?= (int)($rh['next_delay_sec'] ?? 0) ?> сек</small></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </details>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>


<?php
// v18.1.28: блок «🚫 Redirect отключён» показывать только если редирект ДЕЙСТВИТЕЛЬНО
// сейчас отключён. После того как pipeline прошёл через redirect_enable стадию и
// записал redirect_enabled_stage.ok = true (без post_validation_failed), редирект
// уже включён обратно — этот блок становится stale, скрываем.
//
// Также при verify Method 3 (temp-disable trick) artifacts.redirect_disabled_stage
// остаётся от первого pipeline-disable, но реальное состояние = включён.
$_rd = $artifacts['redirect_disabled_stage'] ?? null;
$_re = $artifacts['redirect_enabled_stage'] ?? null;
$_currentlyDisabled = !empty($_rd)
    && (!empty($_rd['applied_rules']) || !empty($_rd['stale_markers_cleaned']))
    && !( // НЕ показываем если успешно включён обратно
        !empty($_re['ok'])
        && empty($_re['remaining_markers'])
        && empty($_re['post_validation_failed'])
    );
?>
<?php if ($_currentlyDisabled): ?>
<!-- Redirect отключён (стадия redirect_disable) — показываем только когда сейчас реально отключён -->
<div class="card">
    <h3>🚫 Redirect отключён</h3>
    <?php $rd = $artifacts['redirect_disabled_stage']; ?>

    <?php if (!empty($rd['stale_markers_cleaned'])): ?>
    <!-- v18.1.9: показываем что система нашла застрявшие маркеры от предыдущих джоб -->
    <div style="background: rgba(255, 193, 7, 0.12); border: 1px solid rgba(255, 193, 7, 0.4);
                border-radius: 6px; padding: 10px 14px; margin-bottom: 12px;">
        <p style="margin: 0;">
            ⚠️ <b>Обнаружены и сняты застрявшие REFRESH-DISABLED маркеры</b>
            от предыдущей джобы в файлах:
            <?php foreach ($rd['stale_markers_cleaned'] as $f): ?>
                <code><?= htmlspecialchars($f) ?></code>
            <?php endforeach; ?>
        </p>
        <p class="muted small" style="margin: 6px 0 0 0;">
            Это значит что предыдущая джоба для этого сайта оставила маркеры в файлах
            (что-то упало или джоба была удалена до redirect_enable). Партнёрский редирект
            был выключен и партнёрка не работала. Система автоматически вернула редирект
            в рабочее состояние перед началом новой джобы.
        </p>
    </div>
    <?php endif; ?>

    <p>
        <span class="muted">Применено правил:</span> <code><?= count($rd['applied_rules']) ?></code>
        ·
        <span class="muted">Файлов изменено:</span> <code><?= count($rd['snapshots'] ?? []) ?></code>
    </p>
    <?php if (!empty($rd['applied_rules'])): ?>
        <table class="hub-table" style="width:100%; font-size:0.9em;">
            <thead>
                <tr>
                    <th style="width:160px;">Правило</th>
                    <th style="width:120px;">Файл</th>
                    <th style="width:60px;">Строк</th>
                    <th>Описание</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rd['applied_rules'] as $r): ?>
                <tr>
                    <td><code><?= htmlspecialchars($r['rule_id'] ?? '') ?></code></td>
                    <td><code><?= htmlspecialchars($r['file'] ?? '') ?></code></td>
                    <td><?= (int)($r['count'] ?? 0) ?></td>
                    <td><?= htmlspecialchars($r['description'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    <?php if (!empty($rd['snapshots'])): ?>
        <p style="margin-top:8px;"><span class="muted">Snapshots:</span></p>
        <ul style="font-family:monospace; font-size:0.85em;">
            <?php foreach ($rd['snapshots'] as $file => $snap): ?>
                <li><?= htmlspecialchars($file) ?> → <?= htmlspecialchars($snap) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <small class="muted">
        На время перевыставления редиректы отключены — пользователи не уйдут на партнёрку
        пока сайт в неполноценном состоянии. После verify_replacement редиректы будут включены обратно.
    </small>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['redirect_enabled_stage'])): ?>
<!-- Redirect включён (стадия redirect_enable) -->
<?php $re = $artifacts['redirect_enabled_stage']; ?>
<?php $hasErrors = !empty($re['errors']); ?>
<div class="card" <?= $hasErrors ? 'style="border:2px solid var(--danger);"' : '' ?>>
    <h3>✅ Redirect включён обратно</h3>
    <?php if ($hasErrors): ?>
        <div style="background:var(--danger); color:white; padding:12px; border-radius:4px; margin-bottom:12px;">
            <strong>⚠️ ВНИМАНИЕ: РЕДИРЕКТ НА САЙТЕ ВКЛЮЧЁН НЕ ПОЛНОСТЬЮ!</strong><br>
            Возможно сайт не возвращает пользователей на партнёрку. Проверь вручную через FP UI.
            Snapshot'ы лежат в <code>storage/snapshots/job_<?= (int)$job['id'] ?>/</code> — можно восстановить.
        </div>
    <?php endif; ?>
    <p>
        <span class="muted">Восстановлено правил:</span> <code><?= count($re['restored_rules'] ?? []) ?></code>
    </p>
    <?php if (!empty($re['restored_rules'])): ?>
        <table class="hub-table" style="width:100%; font-size:0.9em;">
            <thead>
                <tr>
                    <th style="width:160px;">Правило</th>
                    <th style="width:120px;">Файл</th>
                    <th style="width:60px;">Строк</th>
                    <th>Описание</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($re['restored_rules'] as $r): ?>
                <tr>
                    <td><code><?= htmlspecialchars($r['rule_id'] ?? '') ?></code></td>
                    <td><code><?= htmlspecialchars($r['file'] ?? '') ?></code></td>
                    <td><?= (int)($r['count'] ?? 0) ?></td>
                    <td><?= htmlspecialchars($r['description'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    <?php if ($hasErrors): ?>
        <h4 style="color:var(--danger); margin-top:16px;">Ошибки</h4>
        <ul style="color:var(--danger);">
            <?php foreach ($re['errors'] as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (!empty($re['smoke_test'])): ?>
    <!-- v18.1.9: проверка редиректа /play — физическая проверка через curl -->
    <!-- v18.1.11: показываем attempts если был retry loop -->
    <?php $st = $re['smoke_test']; ?>
    <div style="margin-top: 12px; padding: 10px 14px; border-radius: 6px;
                background: <?= !empty($st['ok']) ? 'rgba(40, 167, 69, 0.1)' : 'rgba(220, 53, 69, 0.12)' ?>;
                border: 1px solid <?= !empty($st['ok']) ? 'rgba(40, 167, 69, 0.4)' : 'rgba(220, 53, 69, 0.4)' ?>;">
        <p style="margin: 0;">
            <?= !empty($st['ok']) ? '✓' : '⚠️' ?>
            <b>Проверка редиректа /play:</b>
            <?= htmlspecialchars(JobEventLogger::humanizeMessage((string)($st['reason'] ?? ''))) ?>
        </p>
        <p class="muted small" style="margin: 4px 0 0 0;">
            <?php if (!empty($st['http_code'])): ?>
                HTTP <?= (int)$st['http_code'] ?>
            <?php endif; ?>
            <?php if (!empty($st['location'])): ?>
                → Location: <code><?= htmlspecialchars($st['location']) ?></code>
            <?php endif; ?>
            <?php if (!empty($st['attempts']) && (int)$st['attempts'] > 1): ?>
                · попыток: <?= (int)$st['attempts'] ?>
                <?php if (!empty($st['ok'])): ?>
                    (успех на финальной — DNS/vhost успели пропагироваться)
                <?php endif; ?>
            <?php endif; ?>
            <?php if (!empty($st['manual_confirm'])): ?>
                · <i>подтверждено оператором вручную</i>
            <?php endif; ?>
            <?php if (!empty($st['methods_tried']) && is_array($st['methods_tried'])): ?>
                <br>Методы проверки: <?= htmlspecialchars(implode(', ', $st['methods_tried'])) ?>
            <?php endif; ?>
        </p>
    </div>
    <?php endif; ?>

    <?php if (!empty($re['remaining_markers'])): ?>
    <!-- v18.1.8: пост-проверка поймала оставшиеся REFRESH-DISABLED маркеры -->
    <div style="margin-top: 12px; padding: 10px 14px; border-radius: 6px;
                background: rgba(220, 53, 69, 0.12);
                border: 1px solid rgba(220, 53, 69, 0.4);">
        <p style="margin: 0;">
            ⚠️ <b>Пост-проверка: REFRESH-DISABLED маркеры остались в файлах:</b>
            <?php foreach ($re['remaining_markers'] as $f): ?>
                <code><?= htmlspecialchars($f) ?></code>
            <?php endforeach; ?>
        </p>
        <p class="muted small" style="margin: 6px 0 0 0;">
            Файлы выглядят правильно по UI, но маркеры не сняты. Возможные причины:
            (1) detect-regex в правилах не подходит к шаблону этого сайта,
            (2) файлы изменены извне,
            (3) FTP-доступ упал на середине.
            Открой <code>.htaccess</code> и <code>index.php</code> через FastPanel и убери префиксы вручную.
        </p>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['ssl_self_signed_stage'])): ?>
<!-- SSL Self-signed (стадия ssl_self_signed_first) -->
<div class="card">
    <h3>🔐 SSL Self-signed</h3>
    <?php $sss = $artifacts['ssl_self_signed_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr>
            <td style="width:200px;">Статус</td>
            <td>
                <?php if (!empty($sss['ok'])): ?>
                    <?php if (($sss['action'] ?? '') === 'skipped'): ?>
                        <span style="color:var(--success);">✓ Пропущен (уже есть live cert)</span>
                    <?php else: ?>
                        <span style="color:var(--success);">✓ Установлен</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span style="color:var(--danger);">✗ Не удалось</span>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td>Действие</td>
            <td><code><?= htmlspecialchars($sss['action'] ?? '') ?></code></td>
        </tr>
        <?php if (!empty($sss['certificate_id'])): ?>
        <tr>
            <td>Cert ID в FastPanel</td>
            <td><code><?= (int)$sss['certificate_id'] ?></code></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td>Сообщение</td>
            <td><?= htmlspecialchars($sss['message'] ?? '') ?></td>
        </tr>
    </table>
    <small class="muted">Self-signed cert обеспечивает HTTPS пока Let's Encrypt выпускается. Браузер ругается на «не доверенный» — это нормально, нужно для DDoS-Guard origin и наших внутренних проверок.</small>

    <?php
    // Кнопка retry self-signed — для случаев когда первая попытка упала
    $sssFailed = empty($sss['ok']);
    ?>
    <?php if ($sssFailed): ?>
        <div style="margin-top:16px; padding:12px; background:var(--bg-elevated); border-radius:4px;">
            <p style="margin:0 0 8px 0;">
                <strong>Self-signed не установился?</strong>
                Можно повторить попытку — например если ранее были credentials-проблемы (FP API 401)
                которые уже исправлены, или если сейчас на :443 уже есть валидный live cert
                (тогда стадия пропустится автоматически).
            </p>
            <form method="post" action="/jobs/retry-self-signed" style="display:inline;"
                  onsubmit="return confirm('Повторить self-signed? Стадия ssl_self_signed_first запустится заново. Если на :443 уже есть live cert — будет skipped без действий.');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-primary">🔁 Повторить self-signed</button>
            </form>
        </div>
    <?php endif; ?>

    <?php if (!empty($artifacts['ssl_self_signed_stage_history'])): ?>
        <h4 style="margin-top:16px;">📜 История попыток (предыдущие)</h4>
        <table class="hub-table" style="width:100%; font-size:0.85em;">
            <thead>
                <tr><th>#</th><th>Status</th><th>Action</th><th>Cert ID</th><th>Сообщение</th></tr>
            </thead>
            <tbody>
            <?php foreach (array_reverse($artifacts['ssl_self_signed_stage_history']) as $i => $h): ?>
                <tr>
                    <td><?= count($artifacts['ssl_self_signed_stage_history']) - $i ?></td>
                    <td>
                        <?php if (!empty($h['ok'])): ?>
                            <span style="color:var(--success);">✓ ok</span>
                        <?php else: ?>
                            <span style="color:var(--danger);">✗ failed</span>
                        <?php endif; ?>
                    </td>
                    <td><code><?= htmlspecialchars($h['action'] ?? '') ?></code></td>
                    <td><?= !empty($h['certificate_id']) ? '<code>' . (int)$h['certificate_id'] . '</code>' : '—' ?></td>
                    <td><small><?= htmlspecialchars($h['message'] ?? '') ?></small></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['ssl_le_stage'])): ?>
<!-- SSL Let's Encrypt polling (стадия ssl_le_polling) -->
<div class="card">
    <h3>🔒 Let's Encrypt</h3>
    <?php $sle = $artifacts['ssl_le_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr>
            <td style="width:200px;">Статус</td>
            <td>
                <?php
                $statusColors = [
                    'pending' => 'var(--warning)',
                    'issued' => 'var(--success)',
                    'awaiting_user' => 'var(--danger)',
                    'failed_with_self_signed' => 'var(--warning)',
                    'failed' => 'var(--danger)',
                ];
                $statusLabels = [
                    'pending' => '⏳ В процессе (polling)',
                    'issued' => '✓ Выпущен и применён',
                    'awaiting_user' => '🚨 Ждёт ручного решения',
                    'failed_with_self_signed' => '⚠ LE не выпустился — self-signed остался',
                    'failed' => '✗ Системная ошибка',
                ];
                $st = (string)($sle['status'] ?? '');
                $color = $statusColors[$st] ?? 'var(--text-muted)';
                $label = $statusLabels[$st] ?? $st;
                ?>
                <span style="color: <?= $color ?>;"><?= htmlspecialchars($label) ?></span>
            </td>
        </tr>
        <?php
        // v15: показываем elapsed time вместо tick/MAX_TICKS
        $startedAt = (int)($sle['polling_started_at'] ?? 0);
        if ($startedAt > 0):
            $elapsed = time() - $startedAt;
            $elapsedMin = round($elapsed / 60, 1);
            $totalMin = 360; // 6 часов
        ?>
        <tr>
            <td>Время polling</td>
            <td><code><?= $elapsedMin ?> мин из <?= $totalMin ?></code> &nbsp;
                <span style="color: var(--text-muted);">(tick #<?= (int)($sle['tick_count'] ?? 0) ?>)</span>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($sle['cert_id'])): ?>
        <tr>
            <td>Cert ID в FastPanel</td>
            <td><code><?= (int)$sle['cert_id'] ?></code></td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($sle['auto_restart_count'])): ?>
        <tr>
            <td>Auto-restart счётчик</td>
            <td><code><?= (int)$sle['auto_restart_count'] ?> / 3</code>
                <?php if (!empty($sle['auto_restart_last_at'])): ?>
                    <span style="color: var(--text-muted);">(последний: <?= htmlspecialchars($fmtMsk((string)$sle['auto_restart_last_at'])) ?>)</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($sle['rate_limit_resume_at'])): ?>
        <tr>
            <td>Rate-limit до</td>
            <td><code style="color: var(--danger);"><?= htmlspecialchars($fmtMsk((string)$sle['rate_limit_resume_at'])) ?></code> ⏰</td>
        </tr>
        <?php endif; ?>
        <?php if (!empty($sle['guard_reason'])): ?>
        <tr>
            <td>Guard причина</td>
            <td><small><?= htmlspecialchars($sle['guard_reason']) ?></small></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td>Сообщение</td>
            <td><?= htmlspecialchars($sle['message'] ?? '') ?></td>
        </tr>
    </table>

    <?php if (!empty($sle['live_check'])): ?>
        <?php $lc = $sle['live_check']; ?>
        <h4 style="margin-top:16px;">🌐 Live check сертификата на :443</h4>
        <table class="kv-table" style="width:100%; font-size:0.9em;">
            <tr>
                <td style="width:200px;">Результат</td>
                <td>
                    <?php if (!empty($lc['ok'])): ?>
                        <span style="color:var(--success);">✓ Валидный cert</span>
                    <?php elseif (!empty($lc['is_self_signed'])): ?>
                        <span style="color:var(--warning);">⚠ Self-signed</span>
                    <?php else: ?>
                        <span style="color:var(--text-muted)">— <?= htmlspecialchars($lc['reason'] ?? '?') ?></span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php if (!empty($lc['issuer'])): ?>
            <tr>
                <td>Issuer</td>
                <td><code style="font-size:0.85em;"><?= htmlspecialchars($lc['issuer']) ?></code></td>
            </tr>
            <?php endif; ?>
            <?php if (!empty($lc['expires_at'])): ?>
            <tr>
                <td>Действителен до</td>
                <td><code><?= htmlspecialchars($fmtMsk((string)$lc['expires_at'])) ?></code></td>
            </tr>
            <?php endif; ?>
            <?php if (!empty($lc['is_letsencrypt']) || !empty($lc['is_ddos_guard']) || !empty($lc['is_cloudflare'])): ?>
            <tr>
                <td>Тип</td>
                <td>
                    <?php if (!empty($lc['is_letsencrypt'])): ?>🔒 Let's Encrypt<?php endif; ?>
                    <?php if (!empty($lc['is_ddos_guard'])): ?>🛡️ DDoS-Guard<?php endif; ?>
                    <?php if (!empty($lc['is_cloudflare'])): ?>☁️ Cloudflare<?php endif; ?>
                </td>
            </tr>
            <?php endif; ?>
            <?php if (!empty($lc['error'])): ?>
            <tr>
                <td>Ошибка</td>
                <td><small style="color:var(--danger);"><?= htmlspecialchars($lc['error']) ?></small></td>
            </tr>
            <?php endif; ?>
        </table>
    <?php endif; ?>

    <?php if (!empty($sle['challenges'])): ?>
        <h4 style="margin-top:16px;">DNS-Challenges (TXT-записи)</h4>
        <table class="hub-table" style="width:100%; font-size:0.9em;">
            <thead>
                <tr><th>Имя</th><th>Тип</th><th>Значение (фрагмент)</th></tr>
            </thead>
            <tbody>
            <?php foreach ($sle['challenges'] as $ch): ?>
                <tr>
                    <td><code><?= htmlspecialchars($ch['name'] ?? '') ?></code></td>
                    <td><code><?= htmlspecialchars($ch['type'] ?? 'TXT') ?></code></td>
                    <td><code style="font-size:0.85em;"><?= htmlspecialchars($ch['value'] ?? '') ?></code></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <small class="muted">Эти TXT-записи синхронизированы в Namecheap. LE проверяет их через DNS-01 challenge. Полная пропагация может занять до 30 минут.</small>
    <?php endif; ?>

    <?php
    // Кнопка повтора SSL — для джоб где LE не выпустился
    $showRetrySsl = in_array($st, ['failed_with_self_signed', 'failed'], true)
        || (string)$job['stage_status'] === 'failed';
    ?>
    <?php
    // v25.2-a1.3/a1.4: гибридный ручной контур SSL. Показываем, пока джоба ждёт
    // SSL (ssl_le_polling или wm_verified). Фон НЕ отключается — это помощь.
    $sslWaitStages = ['ssl_le_polling', 'wm_verified', 'trusted_ssl_gate']; // P0 §4.6: gate тоже ждёт SSL
    $sslSkipped = !empty($sle['skipped_by_operator']);
    $sslFatal = !empty($sle['fatal']);
    if (in_array((string)$job['stage'], $sslWaitStages, true) && !$sslSkipped):
    ?>
    <div style="margin-top:16px; padding:12px 14px;
                background:<?= $sslFatal ? 'rgba(220,53,69,0.07)' : 'rgba(38,132,255,0.06)' ?>;
                border:1px solid <?= $sslFatal ? 'rgba(220,53,69,0.35)' : 'rgba(38,132,255,0.3)' ?>; border-radius:6px;">
        <?php if ($sslFatal): ?>
        <p style="margin:0 0 8px 0;"><b style="color:var(--danger);">🛑 Автоматический выпуск SSL остановлен (fatal)</b>
            <span class="muted small">— исправьте проблему и нажмите «Возобновить».</span></p>
        <?php else: ?>
        <p style="margin:0 0 8px 0;"><b>🤝 Автоматический выпуск SSL продолжается в фоне</b>
            <span class="muted small">— можно помочь вручную, фон не отключается.</span></p>
        <?php endif; ?>
        <table class="kv-table" style="width:100%; font-size:0.9em; margin-bottom:10px;">
            <tr><td style="width:200px;">Текущая фаза ACME</td><td><code><?= htmlspecialchars((string)($sle['phase'] ?? '—')) ?></code></td></tr>
            <?php if ($sslFatal && !empty($sle['fatal_message'])): ?>
            <tr><td>Причина остановки</td><td><small style="color:var(--danger);"><?= htmlspecialchars((string)$sle['fatal_message']) ?></small></td></tr>
            <?php endif; ?>
            <?php if (!empty($sle['dns_last_checked_at'])): ?>
            <tr><td>Последняя проверка DNS</td><td><?= htmlspecialchars($fmtMsk((string)$sle['dns_last_checked_at'])) ?></td></tr>
            <?php endif; ?>
            <?php if (!empty($job['ssl_issue_next_poll_at'])): ?>
            <tr><td>Следующая проверка</td><td><?= htmlspecialchars($fmtMsk((string)$job['ssl_issue_next_poll_at'])) ?></td></tr>
            <?php endif; ?>
            <?php if (!empty($sle['last_error'])): ?>
            <tr><td>Последняя причина</td><td><small><?= htmlspecialchars((string)$sle['last_error']) ?></small></td></tr>
            <?php endif; ?>
        </table>
        <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
            <?php if ($sslFatal): ?>
            <form method="post" action="/jobs/ssl-resume-auto" style="display:inline;"
                  onsubmit="return confirm('Возобновить автоматический выпуск SSL? Reconciler снова начнёт выпуск.');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-primary">✅ Я исправил проблему — возобновить автоматический выпуск</button>
            </form>
            <?php endif; ?>
            <form method="post" action="/jobs/ssl-verify-installed" style="display:inline;"
                  onsubmit="return confirm('Проверить SSL строгой TLS-проверкой? Если trusted — джоба продолжит.');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn <?= $sslFatal ? '' : 'btn-primary' ?>">✅ Я установил сертификат вручную — проверить</button>
            </form>
            <form method="post" action="/jobs/ssl-check-now" style="display:inline;">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn">🔄 Проверить SSL сейчас</button>
            </form>
        </div>
        <details style="margin-top:10px;">
            <summary style="cursor:pointer; color:var(--warning);">⏭ Пропустить SSL (на свой риск)</summary>
            <div style="margin-top:8px; padding:10px; background:rgba(255,193,7,0.08); border-radius:4px;">
                <p class="small" style="margin:0 0 8px 0; color:var(--warning);">
                    ⚠ Закрывает <b>только SSL-этап</b> (ssl_gate). Webmaster-верификация продолжится независимо.
                    Сайт может остаться с недоверенным сертификатом. Стадия завершится, когда закроется и Webmaster (подтверждение или его пропуск).
                </p>
                <form method="post" action="/jobs/ssl-skip"
                      onsubmit="return confirm('Пропустить только SSL? Webmaster-верификация продолжится; стадия завершится после её подтверждения (или пропуска Webmaster).');"
                      style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                    <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                    <input type="text" name="comment" required minlength="3" placeholder="Причина пропуска"
                           style="flex:1; min-width:220px; padding:6px;">
                    <button type="submit" class="btn" style="border-color:var(--warning); color:var(--warning);">⏭ Пропустить SSL</button>
                </form>
            </div>
        </details>
    </div>
    <?php elseif ($sslSkipped): ?>
    <div style="margin-top:16px; padding:10px 14px; background:rgba(255,193,7,0.08);
                border:1px solid rgba(255,193,7,0.3); border-radius:6px;">
        <p style="margin:0;" class="small">⏭ <b>SSL пропущен оператором</b>
            <?php if (!empty($sle['skipped_by'])): ?>(<?= htmlspecialchars((string)$sle['skipped_by']) ?>)<?php endif; ?>
            <?php if (!empty($sle['skip_comment'])): ?> — <?= htmlspecialchars((string)$sle['skip_comment']) ?><?php endif; ?>.
            Мониторинг SSL домена продолжается отдельно.</p>
    </div>
    <?php endif; ?>

    <?php if ($showRetrySsl): ?>
        <div style="margin-top:16px; padding:12px; background:var(--bg-elevated); border-radius:4px;">
            <p style="margin:0 0 8px 0;">
                <strong>LE не выпустился?</strong>
                Можно повторить попытку — возможно DNS уже пропагировался, или DDoS-Guard выпустил cert сам.
                Live-check проверит наличие валидного cert на сайте, и если есть — стадия завершится успешно сразу.
            </p>
            <form method="post" action="/jobs/retry-ssl" style="display:inline;"
                  onsubmit="return confirm('Повторить SSL polling? Стадия ssl_le_polling запустится заново. Может занять до 30 минут.');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-primary">🔁 Повторить SSL polling</button>
            </form>
        </div>
    <?php endif; ?>

    <?php if (!empty($artifacts['ssl_le_stage_history'])): ?>
        <h4 style="margin-top:16px;">📜 История попыток (предыдущие)</h4>
        <table class="hub-table" style="width:100%; font-size:0.85em;">
            <thead>
                <tr><th>#</th><th>Status</th><th>Tick</th><th>Cert ID</th><th>Сообщение</th></tr>
            </thead>
            <tbody>
            <?php foreach (array_reverse($artifacts['ssl_le_stage_history']) as $i => $h): ?>
                <tr>
                    <td><?= count($artifacts['ssl_le_stage_history']) - $i ?></td>
                    <td><code><?= htmlspecialchars($h['status'] ?? '') ?></code></td>
                    <td><?= (int)($h['tick_count'] ?? 0) ?></td>
                    <td><?= !empty($h['cert_id']) ? '<code>' . (int)$h['cert_id'] . '</code>' : '—' ?></td>
                    <td><small><?= htmlspecialchars($h['message'] ?? '') ?></small></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['update_classes_stage'])): ?>
<!-- v16: Update classes call -->
<div class="card">
    <h3>🎲 Update classes call (рандом)</h3>
    <?php $uc = $artifacts['update_classes_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr>
            <td style="width: 200px;">Статус</td>
            <td>
                <?php if (!empty($uc['ok'])): ?>
                    <?php if (($uc['action'] ?? '') === 'skipped'): ?>
                        <span style="color: var(--text-muted);">⏭ Пропущен (нет ни URL ни файла)</span>
                    <?php else: ?>
                        <span style="color: var(--success);">✓ Вызван успешно</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span style="color: var(--warning);">⚠ Не удалось вызвать (pipeline продолжен)</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php if (!empty($uc['url'])): ?>
        <tr><td>URL</td><td><code><?= htmlspecialchars($uc['url']) ?></code></td></tr>
        <?php endif; ?>
        <?php if (!empty($uc['action'])): ?>
        <tr><td>Способ</td><td>
            <?php
            $actionLabels = [
                'custom_url' => 'Кастомный URL из настроек сайта',
                'auto_from_ftp' => 'Автоопределение через FTP (есть update_classes.php)',
                'skipped' => 'Пропущена',
            ];
            echo htmlspecialchars($actionLabels[$uc['action']] ?? $uc['action']);
            ?>
        </td></tr>
        <?php endif; ?>
        <?php if (!empty($uc['http_code'])): ?>
        <tr><td>HTTP код</td><td><code><?= (int)$uc['http_code'] ?></code></td></tr>
        <?php endif; ?>
        <tr><td>Сообщение</td><td><?= htmlspecialchars($uc['message'] ?? '') ?></td></tr>
        <?php if (!empty($uc['response_excerpt'])): ?>
        <tr><td>Фрагмент ответа</td><td><pre style="margin:0; max-height:80px; overflow:auto; font-size:0.8em;"><?= htmlspecialchars($uc['response_excerpt']) ?></pre></td></tr>
        <?php endif; ?>
    </table>
</div>
<?php endif; ?>

<!-- === v17 Webmaster карточки === -->
<?php if (!empty($artifacts['wm_account_resolve_stage'])): ?>
<div class="card">
    <h3>🔍 Webmaster: поиск аккаунта</h3>
    <?php $war = $artifacts['wm_account_resolve_stage']; ?>
    <?php $cascadeUsed = !empty($war['cascade_used']); ?>
    <?php $matchedDomain = (string)($war['matched_domain'] ?? $war['old_domain'] ?? ''); ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Запрашиваемый старый домен</td><td><code><?= htmlspecialchars($war['old_domain'] ?? '') ?></code></td></tr>
        <?php if ($cascadeUsed && $matchedDomain !== ($war['old_domain'] ?? '')): ?>
        <tr style="background: rgba(255, 200, 0, 0.05);">
            <td><strong>🔁 Cascade fallback</strong></td>
            <td>
                Запрашиваемый домен не найден, но через aliases нашли:
                <code style="color: var(--success);"><?= htmlspecialchars($matchedDomain) ?></code>
                <br><small class="muted">v18: ничего не удаляется. После индексации нового домена оператору будет отправлен список URL'ов <code><?= htmlspecialchars($war['old_domain'] ?? '') ?></code> для ручной отправки в «Удаление страниц из поиска».</small>
            </td>
        </tr>
        <?php endif; ?>
        <tr><td>Найден в аккаунте</td><td>#<?= (int)($war['old_account_id'] ?? 0) ?></td></tr>
        <tr><td>Старый user_id</td><td><code><?= htmlspecialchars($war['old_user_id'] ?? '') ?></code></td></tr>
        <tr><td>Старый host_id</td><td><code><?= htmlspecialchars($war['old_host_id'] ?? '') ?></code></td></tr>
        <tr><td>Источник</td><td>
            <?php if (($war['source'] ?? '') === 'cache'): ?>
                💾 Кеш в БД (мгновенно)
            <?php elseif (($war['source'] ?? '') === 'api'): ?>
                🌐 API-запрос (закеширован для следующего раза)
            <?php elseif (($war['source'] ?? '') === 'cascade'): ?>
                🔁 Cascade fallback по aliases (закеширован для следующего раза)
            <?php elseif (($war['source'] ?? '') === 'override'): ?>
                ✋ Override через форму джобы
            <?php else: ?>
                <?= htmlspecialchars($war['source'] ?? '?') ?>
            <?php endif; ?>
        </td></tr>
        <tr><td>Новый домен → аккаунт</td><td>
            #<?= (int)($war['new_account_id'] ?? 0) ?>
            <?php if (!empty($war['override_used'])): ?>
                <span style="color: var(--warning);">(override)</span>
            <?php endif; ?>
        </td></tr>
    </table>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['wm_added_stage'])): ?>
<div class="card">
    <h3>📥 Webmaster: добавление</h3>
    <?php $wa = $artifacts['wm_added_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Аккаунт</td><td>#<?= (int)($wa['account_id'] ?? 0) ?></td></tr>
        <tr><td>user_id</td><td><code><?= htmlspecialchars($wa['user_id'] ?? '') ?></code></td></tr>
        <tr><td>host_id</td><td><code><?= htmlspecialchars($wa['host_id'] ?? '') ?></code></td></tr>
        <tr><td>host_url</td><td><code><?= htmlspecialchars($wa['host_url'] ?? '') ?></code></td></tr>
    </table>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['wm_verified_stage'])): ?>
<div class="card">
    <h3>✅ Webmaster: верификация HTML_FILE</h3>
    <?php $wv = $artifacts['wm_verified_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">verification_state</td><td>
            <?php $vs = (string)($wv['verification_state'] ?? ''); ?>
            <?php if ($vs === 'verified' || $vs === 'success'): ?>
                <span style="color:var(--success);">✓ verified</span>
            <?php elseif (in_array($vs, ['verification_in_progress','in_progress','processing','pending','started'], true)): ?>
                <span style="color:var(--warning);">⏳ in progress</span>
            <?php elseif ($vs === 'verification_failed' || $vs === 'failed'): ?>
                <span style="color:var(--danger);">✗ failed</span>
            <?php else: ?>
                <?= htmlspecialchars($vs !== '' ? $vs : '—') ?>
            <?php endif; ?>
        </td></tr>
        <tr><td>Verifier</td><td><?= !empty($wv['uin']) ? 'получен' : '—' ?></td></tr>
        <tr><td>FTP</td><td><?= !empty($wv['uploaded_at']) ? 'загружен' : '—' ?></td></tr>
        <tr><td>Публичный файл</td><td><?= !empty($wv['public_at']) ? 'доступен (' . htmlspecialchars((string)($wv['public_method'] ?? 'ok')) . ')' : 'ещё нет' ?></td></tr>
        <tr><td>Submit в Яндекс</td><td><?= !empty($wv['submitted_at']) ? 'отправлен · ' . htmlspecialchars($fmtMsk((string)$wv['submitted_at'])) : 'ещё не отправлен' ?></td></tr>
        <?php if (!empty($wv['confirmed_at'])): ?>
        <tr><td>Подтверждено (Яндекс)</td><td><?= htmlspecialchars($fmtMsk((string)$wv['confirmed_at'])) ?></td></tr>
        <?php endif; ?>
        <tr><td>uin</td><td><code><?= htmlspecialchars($wv['uin'] ?? '') ?></code></td></tr>
        <tr><td>file</td><td><code><?= htmlspecialchars($wv['file'] ?? '') ?></code></td></tr>
        <?php if (!empty($wv['file_url'])): ?>
        <tr><td>URL файла</td><td><a href="<?= htmlspecialchars($wv['file_url']) ?>" target="_blank"><?= htmlspecialchars($wv['file_url']) ?></a></td></tr>
        <?php endif; ?>
    </table>

    <?php
    // v25.2-a1.3 (§Пункт 4): гибридный ручной контур Webmaster. Показываем, пока
    // джоба на wm_verified и не пропущена оператором. Фон НЕ отключается.
    $wvSkipped = !empty($wv['skipped_by_operator']);
    if ((string)$job['stage'] === 'wm_verified' && !$wvSkipped):
        $submitSent = !empty($wv['submitted_at']) || !empty($wv['verifier_submitted_at']) || !empty($wv['submit_requested_at']) || ($vs !== '');
    ?>
    <div style="margin-top:16px; padding:12px 14px; background:rgba(38,132,255,0.06);
                border:1px solid rgba(38,132,255,0.3); border-radius:6px;">
        <p style="margin:0 0 8px 0;"><b>🤝 Фоновая проверка подтверждения продолжается</b>
            <span class="muted small">— можно помочь вручную, фон не отключается.</span></p>
        <table class="kv-table" style="width:100%; font-size:0.9em; margin-bottom:10px;">
            <tr><td style="width:200px;">Запрос подтверждения</td><td><?= $submitSent ? 'отправлен' : 'ещё не отправлен' ?></td></tr>
            <tr><td>Последний статус Yandex</td><td><code><?= htmlspecialchars($vs !== '' ? $vs : '—') ?></code></td></tr>
            <?php if (!empty($job['next_run_at'])): ?>
            <tr><td>Следующая проверка</td><td><?= htmlspecialchars($fmtMsk((string)$job['next_run_at'])) ?></td></tr>
            <?php endif; ?>
        </table>
        <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
            <form method="post" action="/jobs/wm-verify-manual" style="display:inline;"
                  onsubmit="return confirm('Проверить статус подтверждения сейчас? Повторный submit не выполняется — только poll.');">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn btn-primary">✅ Я подтвердил права вручную — проверить</button>
            </form>
            <form method="post" action="/jobs/wm-verified-check-now" style="display:inline;">
                <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                <button type="submit" class="btn">🔄 Проверить статус сейчас</button>
            </form>
        </div>
        <details style="margin-top:10px;">
            <summary style="cursor:pointer; color:var(--warning);">⏭ Пропустить подтверждение Webmaster</summary>
            <div style="margin-top:8px; padding:10px; background:rgba(255,193,7,0.08); border-radius:4px;">
                <p class="small" style="margin:0 0 8px 0; color:var(--warning);">
                    ⚠ Стадия будет помечена пройденной без подтверждения прав в Яндекс.Вебмастере.
                </p>
                <form method="post" action="/jobs/wm-verified-skip"
                      onsubmit="return confirm('Точно пропустить подтверждение Webmaster? Джоба перейдёт на следующую стадию.');"
                      style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                    <input type="hidden" name="id" value="<?= (int)$job['id'] ?>">
                    <input type="text" name="comment" required minlength="3" placeholder="Причина пропуска"
                           style="flex:1; min-width:220px; padding:6px;">
                    <button type="submit" class="btn" style="border-color:var(--warning); color:var(--warning);">⏭ Пропустить</button>
                </form>
            </div>
        </details>
    </div>
    <?php elseif ($wvSkipped): ?>
    <div style="margin-top:16px; padding:10px 14px; background:rgba(255,193,7,0.08);
                border:1px solid rgba(255,193,7,0.3); border-radius:6px;">
        <p style="margin:0;" class="small">⏭ <b>Подтверждение Webmaster пропущено оператором</b>
            <?php if (!empty($wv['skipped_by'])): ?>(<?= htmlspecialchars((string)$wv['skipped_by']) ?>)<?php endif; ?>
            <?php if (!empty($wv['skip_comment'])): ?> — <?= htmlspecialchars((string)$wv['skip_comment']) ?><?php endif; ?>.</p>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php /* === v18: wm_robots — Hub-style HEAD-проверка + опциональная диагностика API === */ ?>
<?php if (!empty($artifacts['wm_robots_stage'])): ?>
<div class="card">
    <h3>🤖 Webmaster: проверка robots.txt</h3>
    <?php $wr = $artifacts['wm_robots_stage']; ?>
    <?php $hc = $wr['http_check'] ?? []; ?>
    <?php $api = $wr['api_check'] ?? ['attempted' => false]; ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">HTTP HEAD robots.txt</td><td>
            <?php $code = (int)($hc['http_code'] ?? 0); ?>
            <?php if ($code >= 200 && $code < 400): ?>
                <span style="color:var(--success);">✓ HTTP <?= $code ?> — файл доступен</span>
            <?php else: ?>
                <span style="color:var(--warning);">⚠ HTTP <?= $code ?> — файл не отдаётся 2xx/3xx</span>
            <?php endif; ?>
            <?php if (!empty($hc['url'])): ?>
                <br><small class="muted">URL: <code><?= htmlspecialchars((string)$hc['url']) ?></code></small>
            <?php endif; ?>
            <?php if (!empty($hc['final_url']) && $hc['final_url'] !== ($hc['url'] ?? '')): ?>
                <br><small class="muted">Final: <code><?= htmlspecialchars((string)$hc['final_url']) ?></code></small>
            <?php endif; ?>
            <?php if (!empty($hc['curl_err'])): ?>
                <br><small style="color:var(--danger);">curl error: <?= htmlspecialchars((string)$hc['curl_err']) ?></small>
            <?php endif; ?>
        </td></tr>
        <tr><td>Диагностика через API</td><td>
            <?php if (empty($api['attempted'])): ?>
                <span class="muted">— (не вызывалась, не было wm_added артефактов)</span>
            <?php elseif (!empty($api['ok'])): ?>
                <span style="color:var(--success);">✓ Yandex API ответил по
                    <code><?= htmlspecialchars((string)($api['endpoint'] ?? '?')) ?></code>
                </span>
                <?php if (isset($api['directives_count'])): ?>
                    · директив: <b><?= (int)$api['directives_count'] ?></b>
                <?php endif; ?>
                <?php if (!empty($api['sitemaps']) && is_array($api['sitemaps'])): ?>
                    · sitemaps: <b><?= count($api['sitemaps']) ?></b>
                <?php endif; ?>
                <?php if (!empty($api['access_status'])): ?>
                    · access_status: <code><?= htmlspecialchars((string)$api['access_status']) ?></code>
                <?php endif; ?>
            <?php else: ?>
                <?php $ahc = (int)($api['http_code'] ?? 0); ?>
                <span class="muted">— API не вернул данные (HTTP <?= $ahc ?>)</span>
                <br><small class="muted">
                    Эндпоинт <code>/v4/.../hosts/{hid}/robots</code> не задокументирован
                    в публичном API. Yandex прочитает robots.txt автоматически при
                    следующем обходе сайта.
                </small>
                <?php if (!empty($api['error'])): ?>
                    <br><small style="color:var(--muted); font-size:0.85em;"><?= htmlspecialchars((string)$api['error']) ?></small>
                <?php endif; ?>
            <?php endif; ?>
        </td></tr>
        <?php if (!empty($api['ok']) && !empty($api['sitemaps']) && is_array($api['sitemaps'])): ?>
        <tr><td>Sitemap'ы (по версии Yandex)</td><td>
            <?php foreach ($api['sitemaps'] as $sm): ?>
                <code style="display: block; margin-bottom: 2px;"><?= htmlspecialchars((string)$sm) ?></code>
            <?php endforeach; ?>
        </td></tr>
        <?php endif; ?>
        <tr><td>Итог</td><td>
            <?php if (!empty($wr['overall_ok'])): ?>
                <span style="color:var(--success);">✅ Проверка пройдена</span>
            <?php else: ?>
                <span style="color:var(--warning);">⚠ Не критично, pipeline идёт дальше</span>
                <br><small class="muted">Yandex увидит robots.txt при обходе сайта в любом случае.</small>
            <?php endif; ?>
        </td></tr>
    </table>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['wm_sitemap_stage'])): ?>
<div class="card">
    <h3>🗺 Webmaster: sitemap</h3>
    <?php $ws = $artifacts['wm_sitemap_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Статус</td><td>
            <?php if (!empty($ws['ok'])): ?>
                <span style="color:var(--success);">✓ Загружен</span>
            <?php else: ?>
                <span style="color:var(--warning);">⚠ Не загрузился (но pipeline продолжен)</span>
            <?php endif; ?>
        </td></tr>
        <tr><td>URL</td><td><code><?= htmlspecialchars($ws['sitemap_url'] ?? '') ?></code></td></tr>
        <?php if (!empty($ws['error'])): ?>
        <tr><td>Ошибка</td><td><small style="color:var(--danger);"><?= htmlspecialchars($ws['error']) ?></small></td></tr>
        <?php endif; ?>
    </table>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['wm_recrawl_stage'])): ?>
<div class="card">
    <h3>🔄 Webmaster: переобход</h3>
    <?php $wr = $artifacts['wm_recrawl_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">URL отправлено</td><td><?= (int)($wr['urls_sent'] ?? 0) ?></td></tr>
        <?php if (!empty($wr['quota_before'])): ?>
        <tr><td>Quota до</td><td>
            <?= (int)($wr['quota_before']['quota_remainder'] ?? 0) ?> /
            <?= (int)($wr['quota_before']['daily_quota'] ?? 0) ?>
        </td></tr>
        <?php endif; ?>
        <?php if (!empty($wr['action'])): ?>
        <tr><td>Особое действие</td><td><?= htmlspecialchars($wr['action']) ?></td></tr>
        <?php endif; ?>
    </table>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['index_watching_stage'])): ?>
<div class="card">
    <h3>👁 Мониторинг индексации</h3>
    <?php $iw = $artifacts['index_watching_stage']; ?>
    <?php $startTs = (int)($iw['started_at'] ?? time()); ?>
    <?php $elapsedMin = round((time() - $startTs) / 60, 1); ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Tick #</td><td><code><?= (int)($iw['tick_count'] ?? 0) ?></code></td></tr>
        <tr><td>Started</td><td><code><?= htmlspecialchars(Time::msk(date('Y-m-d H:i:s', $startTs), 'Y-m-d H:i:s')) ?></code></td></tr>
        <tr><td>Время polling</td><td><code><?= $elapsedMin ?> / 30 мин</code></td></tr>
        <tr><td>Last check</td><td><code><?= htmlspecialchars($fmtMsk((string)($iw['last_check_at'] ?? ''))) ?></code></td></tr>
        <tr><td>Страниц в индексе</td><td>
            <?php $pages = (int)($iw['pages_indexed'] ?? 0); ?>
            <?php if ($pages > 0): ?>
                <span style="color:var(--success); font-weight:bold;"><?= $pages ?> страниц</span>
                <?php if (!empty($iw['primary_method'])): ?>
                    <small class="muted">(метод: <?= htmlspecialchars($iw['primary_method']) ?>)</small>
                <?php endif; ?>
            <?php else: ?>
                <span style="color:var(--warning);">0 — ещё не появился в индексе</span>
            <?php endif; ?>
        </td></tr>
        <?php if (!empty($iw['stop_reason'])): ?>
        <tr><td>Причина остановки</td><td>
            <span style="color:var(--danger);"><?= htmlspecialchars($iw['stop_reason']) ?></span>
            (<?= htmlspecialchars(!empty($iw['stopped_at']) ? $fmtMsk((string)$iw['stopped_at']) : '') ?>)
        </td></tr>
        <?php endif; ?>
        <?php if (!empty($iw['last_message'])): ?>
        <tr><td>Последнее сообщение</td><td><small><?= htmlspecialchars($iw['last_message']) ?></small></td></tr>
        <?php endif; ?>
    </table>

    <?php if (!empty($iw['methods_tried']) && is_array($iw['methods_tried'])): ?>
        <h4 style="margin-top:16px;">Попытки методов проверки:</h4>
        <table class="hub-table" style="width:100%; font-size:0.85em;">
            <thead>
                <tr><th>Метод</th><th>Доступен</th><th>OK</th><th>Indexed</th><th>Pages</th><th>Сообщение</th></tr>
            </thead>
            <tbody>
            <?php foreach ($iw['methods_tried'] as $mt): ?>
                <tr>
                    <td><code><?= htmlspecialchars($mt['method'] ?? '') ?></code></td>
                    <td><?= !empty($mt['available']) ? '✓' : '—' ?></td>
                    <td>
                        <?php if (!empty($mt['skipped'])): ?>
                            <small class="muted">skip: <?= htmlspecialchars($mt['skipped']) ?></small>
                        <?php elseif (!empty($mt['ok'])): ?>
                            ✓
                        <?php else: ?>
                            ✗
                        <?php endif; ?>
                    </td>
                    <td><?= !empty($mt['indexed']) ? '<span style="color:var(--success);">✓</span>' : '—' ?></td>
                    <td><?= (int)($mt['pages_indexed'] ?? 0) ?></td>
                    <td><small><?= htmlspecialchars($mt['message'] ?? $mt['error'] ?? '') ?></small></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['index_watching_stage_history'])): ?>
<div class="card">
    <h4 style="margin-top:0;">📜 История попыток index_watching</h4>
    <table class="hub-table" style="width:100%; font-size:0.85em;">
        <thead>
            <tr><th>#</th><th>Started</th><th>Stopped</th><th>Ticks</th><th>Pages</th><th>Reason</th></tr>
        </thead>
        <tbody>
        <?php foreach ((array)$artifacts['index_watching_stage_history'] as $i => $h): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><?= htmlspecialchars(Time::msk(date('Y-m-d H:i:s', (int)($h['started_at'] ?? 0)), 'Y-m-d H:i:s')) ?></td>
                <td><?= htmlspecialchars(!empty($h['stopped_at']) ? $fmtMsk((string)$h['stopped_at']) : '—') ?></td>
                <td><?= (int)($h['tick_count'] ?? 0) ?></td>
                <td><?= (int)($h['final_pages_indexed'] ?? $h['pages_indexed'] ?? 0) ?></td>
                <td><small><?= htmlspecialchars($h['stop_reason'] ?? '') ?></small></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php /* === v18: move_htaccess_redirect === */ ?>
<?php if (!empty($artifacts['move_htaccess_redirect_stage'])): ?>
<div class="card">
    <h3>🔁 Move: 301 в .htaccess</h3>
    <?php $mhr = $artifacts['move_htaccess_redirect_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Статус</td><td>
            <?php if (!empty($mhr['ok'])): ?>
                <?php if (!empty($mhr['was_present_before'])): ?>
                    <span style="color:var(--success);">✓ Блок уже был (idempotent skip)</span>
                <?php else: ?>
                    <span style="color:var(--success);">✓ Блок добавлен</span>
                <?php endif; ?>
            <?php else: ?>
                <span style="color:var(--warning);">⚠ Не удалось: <?= htmlspecialchars($mhr['error'] ?? '?') ?></span>
            <?php endif; ?>
        </td></tr>
        <?php if (!empty($mhr['htaccess_path'])): ?>
        <tr><td>Файл</td><td><code><?= htmlspecialchars($mhr['htaccess_path']) ?></code></td></tr>
        <?php endif; ?>
        <?php if (isset($mhr['bytes_before'], $mhr['bytes_after'])): ?>
        <tr><td>Размер</td><td>
            <?= (int)$mhr['bytes_before'] ?> → <?= (int)$mhr['bytes_after'] ?> байт
            <?php $delta = (int)$mhr['bytes_after'] - (int)$mhr['bytes_before']; ?>
            <?php if ($delta > 0): ?><small class="muted">(+<?= $delta ?>)</small><?php endif; ?>
        </td></tr>
        <?php endif; ?>
        <?php if (!empty($mhr['snapshot_path'])): ?>
        <tr><td>Snapshot</td><td><code style="font-size:0.85em;"><?= htmlspecialchars($mhr['snapshot_path']) ?></code></td></tr>
        <?php endif; ?>
        <?php if (!empty($mhr['verify'])): ?>
        <tr><td>Verify</td><td>
            <?php $v = $mhr['verify']; ?>
            <?php if (!empty($v['ok'])): ?>
                <span style="color:var(--success);">✓ HTTP <?= (int)$v['http_code'] ?></span>
                → <code><?= htmlspecialchars($v['location'] ?? '') ?></code>
            <?php else: ?>
                <span style="color:var(--warning);">⚠ HTTP <?= (int)$v['http_code'] ?></span>
                <?php if (!empty($v['location'])): ?>
                    → <code><?= htmlspecialchars($v['location']) ?></code>
                <?php endif; ?>
                <?php if (!empty($v['curl_error'])): ?>
                    <br><small class="muted"><?= htmlspecialchars($v['curl_error']) ?></small>
                <?php endif; ?>
            <?php endif; ?>
        </td></tr>
        <?php endif; ?>
    </table>
    <?php if (!empty($mhr['block_added'])): ?>
        <details style="margin-top: 8px;">
            <summary class="muted small" style="cursor: pointer;">Добавленный блок</summary>
            <pre style="background: var(--bg-elevated); padding: 10px; border-radius: 4px;
                        overflow-x: auto; font-size: 0.85em; margin-top: 4px;"><?= htmlspecialchars($mhr['block_added']) ?></pre>
        </details>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php /* === v18: move_submit_request === */ ?>
<?php if (!empty($artifacts['move_submit_request_stage'])): ?>
<div class="card">
    <h3>📨 Move: подача заявки на переезд</h3>
    <?php $msr = $artifacts['move_submit_request_stage']; ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Аккаунт WM</td><td>
            <?php if (!empty($msr['new_account_email'])): ?>
                <code><?= htmlspecialchars($msr['new_account_email']) ?></code>
                <small class="muted">(#<?= (int)($msr['new_account_id'] ?? 0) ?>)</small>
            <?php else: ?>
                <span class="muted">не определён</span>
            <?php endif; ?>
        </td></tr>
        <?php if (!empty($msr['new_host_id'])): ?>
        <tr><td>host_id</td><td><code><?= htmlspecialchars($msr['new_host_id']) ?></code></td></tr>
        <?php endif; ?>
        <?php if (!empty($msr['webmaster_mirrors_url'])): ?>
        <tr><td>Прямая ссылка</td><td>
            <a href="<?= htmlspecialchars($msr['webmaster_mirrors_url']) ?>"
               target="_blank" rel="noopener noreferrer">
                🔗 Webmaster → Переезд сайта
            </a>
        </td></tr>
        <?php endif; ?>
        <?php if (!empty($msr['awaiting_since'])): ?>
        <tr><td>Awaiting с</td><td><?= htmlspecialchars($fmtMsk((string)$msr['awaiting_since'])) ?></td></tr>
        <?php endif; ?>
        <?php if (!empty($msr['ack_at'])): ?>
        <tr><td>Подтверждено</td><td>
            <span style="color:var(--success);">✓ <?= htmlspecialchars($fmtMsk((string)$msr['ack_at'])) ?></span>
        </td></tr>
        <?php else: ?>
        <tr><td>Подтверждено</td><td>
            <span class="muted">— (ждём нажатия «Я подал заявку»)</span>
        </td></tr>
        <?php endif; ?>
    </table>
</div>
<?php endif; ?>

<?php /* === v18: move_poll_status === */ ?>
<?php if (!empty($artifacts['move_poll_status_stage'])): ?>
<div class="card">
    <h3>📊 Move: мониторинг статуса переезда</h3>
    <?php $mps = $artifacts['move_poll_status_stage']; ?>

    <?php if (!empty($mps['manual_done'])): ?>
    <!-- v18.1.17: джоба завершена вручную через "Завершить джобу" -->
    <div style="padding: 10px 14px; border-radius: 6px; margin-bottom: 12px;
                background: rgba(40, 167, 69, 0.1);
                border: 1px solid rgba(40, 167, 69, 0.4);">
        <p style="margin: 0;">
            ✅ <b>Джоба завершена вручную</b>
            <?php if (!empty($mps['manual_done_at'])): ?>
                — <small><?= htmlspecialchars($fmtMsk((string)$mps['manual_done_at'])) ?></small>
            <?php endif; ?>
        </p>
        <p class="muted small" style="margin: 4px 0 0 0;">
            Новый домен оставлен активным.
            <?php if (!empty($mps['manual_done_from_stage'])): ?>
                Финализация со стадии <code><?= htmlspecialchars($mps['manual_done_from_stage']) ?></code>.
            <?php endif; ?>
        </p>
    </div>
    <?php endif; ?>

    <?php if (!empty($mps['awaiting_no_account'])): ?>
    <!-- v18.1.17: ожидаем оператора — нет webmaster аккаунта для проверки -->
    <div style="padding: 10px 14px; border-radius: 6px; margin-bottom: 12px;
                background: rgba(255, 193, 7, 0.1);
                border: 1px solid rgba(255, 193, 7, 0.4);">
        <p style="margin: 0;">
            ⚠️ <b>Не могу автоматически проверить статус переезда</b>
        </p>
        <?php if (!empty($mps['awaiting_reason'])): ?>
        <p class="muted small" style="margin: 4px 0 0 0;">
            Причина: <?= htmlspecialchars($mps['awaiting_reason']) ?>
        </p>
        <?php endif; ?>
        <p class="small" style="margin: 8px 0 0 0;">
            <b>Что можно сделать:</b>
            <br>• Нажми <b>«✅ Завершить джобу»</b> вверху — пометить как done, новый домен оставить активным
            <br>• Или выбери Webmaster-аккаунт прямо здесь ↓ и джоба продолжит автоматически
            <br>• Нажми <b>«↩️ Откатить snapshot»</b> — отменить переезд и вернуть старый домен
        </p>
    </div>
    <?php // v25.2-a1.3 (§Пункт 2): выбор аккаунта прямо в карточке переезда ?>
    <?php include Paths::appRoot() . '/app/Views/jobs/_wm_account_select.php'; ?>
    <?php endif; ?>

    <?php $lastStatus = (string)($mps['last_status'] ?? '?'); ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Последний статус</td><td>
            <?php if ($lastStatus === 'success'): ?>
                <span style="color:var(--success);">✅ success</span>
            <?php elseif ($lastStatus === 'in_progress'): ?>
                <span style="color:var(--info);">⏳ in_progress</span>
            <?php elseif ($lastStatus === 'wrong_mirror'): ?>
                <span style="color:var(--warning);">⚠ wrong_mirror</span>
            <?php elseif ($lastStatus === 'old_not_found'): ?>
                <span style="color:var(--warning);">⚠ old_not_found</span>
            <?php elseif ($lastStatus === '?'): ?>
                <span style="color:var(--text-muted);">— (проверка не запускалась)</span>
            <?php else: ?>
                <span style="color:var(--danger);">✖ <?= htmlspecialchars($lastStatus) ?></span>
            <?php endif; ?>
        </td></tr>
        <?php if (!empty($mps['last_reason'])): ?>
        <tr><td>Причина</td><td><small><?= htmlspecialchars($mps['last_reason']) ?></small></td></tr>
        <?php endif; ?>
        <?php if (!empty($mps['last_main_mirror'])): ?>
        <tr><td>main_mirror</td><td><code><?= htmlspecialchars($mps['last_main_mirror']) ?></code></td></tr>
        <?php endif; ?>
        <tr><td>Тиков</td><td><?= (int)($mps['tick_count'] ?? 0) ?></td></tr>
        <?php if (!empty($mps['started_at'])): ?>
        <tr><td>Начато</td><td><?= htmlspecialchars($fmtMsk((string)$mps['started_at'])) ?></td></tr>
        <?php endif; ?>
        <?php if (!empty($mps['last_check_at'])): ?>
        <tr><td>Последняя проверка</td><td><?= htmlspecialchars($fmtMsk((string)$mps['last_check_at'])) ?></td></tr>
        <?php endif; ?>
        <?php if (!empty($mps['success_at'])): ?>
        <tr><td>Успех в</td><td>
            <span style="color:var(--success);">✅ <?= htmlspecialchars($fmtMsk((string)$mps['success_at'])) ?></span>
        </td></tr>
        <?php endif; ?>
        <?php if (!empty($mps['consecutive_api_errors'])): ?>
        <tr><td>API errors подряд</td><td>
            <span style="color:var(--warning);"><?= (int)$mps['consecutive_api_errors'] ?>/5</span>
        </td></tr>
        <?php endif; ?>
    </table>
</div>
<?php endif; ?>

<?php /* === v18: old_delurl_notify === */ ?>
<?php if (!empty($artifacts['old_delurl_notify_stage'])): ?>
<div class="card">
    <h3>🗑 Удаление старого из поиска (delurl)</h3>
    <?php $odn = $artifacts['old_delurl_notify_stage']; ?>
    <?php $odnUrls = $odn['urls'] ?? []; ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Старый домен</td><td><code><?= htmlspecialchars($odn['old_domain'] ?? '') ?></code></td></tr>
        <tr><td>Аккаунт WM</td><td>
            <?php if (!empty($odn['old_account_email'])): ?>
                <code><?= htmlspecialchars($odn['old_account_email']) ?></code>
                <small class="muted">(#<?= (int)($odn['old_account_id'] ?? 0) ?>)</small>
            <?php else: ?>
                <span class="muted">не определён</span>
            <?php endif; ?>
        </td></tr>
        <tr><td>URL'ов в списке</td><td>
            <b><?= (int)($odn['urls_count'] ?? count((array)$odnUrls)) ?></b>
            <small class="muted">(источник: <?= htmlspecialchars($odn['urls_source'] ?? '?') ?>)</small>
        </td></tr>
        <?php if (!empty($odn['del_url_tool_url'])): ?>
        <tr><td>Прямая ссылка</td><td>
            <a href="<?= htmlspecialchars($odn['del_url_tool_url']) ?>"
               target="_blank" rel="noopener noreferrer">
                🔗 Webmaster → Удаление страниц из поиска
            </a>
        </td></tr>
        <?php endif; ?>
        <tr><td>TG отправлен</td><td>
            <?= !empty($odn['tg_sent']) ? '<span style="color:var(--success);">✓ да</span>'
                : '<span class="muted">нет (TG не настроен)</span>' ?>
        </td></tr>
        <?php if (!empty($odn['ack_at'])): ?>
        <tr><td>Подтверждено</td><td>
            <span style="color:var(--success);">✓ <?= htmlspecialchars($fmtMsk((string)$odn['ack_at'])) ?></span>
        </td></tr>
        <?php elseif (!empty($odn['awaiting_since'])): ?>
        <tr><td>Awaiting с</td><td>
            <?= htmlspecialchars($fmtMsk((string)$odn['awaiting_since'])) ?>
            <small class="muted">(ждём нажатия «Я отправил на удаление»)</small>
        </td></tr>
        <?php endif; ?>
    </table>
    <?php if (!empty($odnUrls) && is_array($odnUrls)): ?>
        <details style="margin-top: 8px;">
            <summary class="muted small" style="cursor: pointer;">
                Список URL'ов (<?= count($odnUrls) ?>) — клик для разворота
            </summary>
            <pre style="background: var(--bg-elevated); padding: 10px; border-radius: 4px;
                        overflow-x: auto; font-size: 0.82em; max-height: 300px; margin-top: 4px;"><?= htmlspecialchars(implode("\n", $odnUrls)) ?></pre>
        </details>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($artifacts['wm_old_removed_stage'])): ?>
<div class="card">
    <h3>🗑 Webmaster: удаление старого</h3>
    <?php $wor = $artifacts['wm_old_removed_stage']; ?>
    <?php $worMatched = (string)($wor['matched_domain'] ?? $wor['old_domain'] ?? ''); ?>
    <table class="kv-table" style="width:100%;">
        <tr><td style="width:200px;">Статус</td><td>
            <?php if (!empty($wor['ok'])): ?>
                <span style="color:var(--success);">✓ Старый домен удалён</span>
            <?php else: ?>
                <span style="color:var(--warning);">⚠ Не удалился: <?= htmlspecialchars($wor['error'] ?? '?') ?></span>
            <?php endif; ?>
        </td></tr>
        <?php if (!empty($worMatched)): ?>
        <tr><td>Удалённый домен</td><td>
            <code><?= htmlspecialchars($worMatched) ?></code>
            <?php if (!empty($wor['cascade_used']) && $worMatched !== ($wor['old_domain'] ?? '')): ?>
                <br><small class="muted">(найден через cascade fallback по aliases — запрашивали '<?= htmlspecialchars($wor['old_domain'] ?? '') ?>')</small>
            <?php endif; ?>
        </td></tr>
        <tr><td>Из аккаунта</td><td>#<?= (int)($wor['old_account_id'] ?? 0) ?></td></tr>
        <?php endif; ?>
    </table>
</div>
<?php endif; ?>

<!-- Артефакты JSON (для отладки) -->
<div class="card">
    <h3>Артефакты (raw JSON)</h3>
    <pre style="background: var(--bg-elevated); padding: 12px; border-radius: 4px;
                overflow-x: auto; font-size: 0.85em; max-height: 300px;"><?=
        htmlspecialchars(json_encode($artifacts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))
    ?></pre>
</div>
<?php endif; ?>
