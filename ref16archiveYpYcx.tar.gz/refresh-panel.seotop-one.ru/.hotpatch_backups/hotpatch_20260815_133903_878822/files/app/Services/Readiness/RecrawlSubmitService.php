<?php

/**
 * v25.0-b1 (B4): отправка одного URL в переобход с полной валидацией.
 *
 * Прежний код считал любой не-throw «accepted» и жёстко писал http=200.
 * Теперь на каждый URL:
 *   1) preflight: страница реально отвечает HTTPS 200 на новом (не чужом) домене;
 *   2) вызов recrawl API;
 *   3) классификация ответа/ошибки по официальной семантике:
 *      202 + task_id → accepted; 409 URL_ALREADY_ADDED → accepted;
 *      429 QUOTA_EXCEEDED → pending_quota; 400 INVALID_URL → failed сразу;
 *      404 HOST_NOT_VERIFIED → awaiting (возврат к verification);
 *      401/403 → account (awaiting сразу); 5xx/сеть → retry.
 *
 * HTTP-проба и WM-клиент внедряемы — для поведенческих тестов без сети.
 */
class RecrawlSubmitService
{
    /** @var callable|null (url)→['http_code'=>int,'final_host'=>string,'ok'=>bool] */
    private $pageProbe = null;

    public function setPageProbe(callable $f): void { $this->pageProbe = $f; }

    /**
     * @param object $client WM-клиент (recrawlUrl(userId,hostId,url)→array)
     * @return array{outcome:string, ...} outcome ∈
     *   accepted | pending_quota | retry | failed | awaiting_host | awaiting_account
     */
    public function submit($client, string $userId, string $hostId, string $url, string $newDomain): array
    {
        // 1) Preflight: страница должна отвечать 200 на нужном домене по HTTPS.
        $probe = $this->probePage($url);
        $pageCode = (int)($probe['http_code'] ?? 0);
        $finalHost = strtolower((string)($probe['final_host'] ?? ''));
        $finalScheme = strtolower((string)($probe['final_scheme'] ?? ''));
        $expHost = strtolower($newDomain);

        if ($pageCode !== 200) {
            return ['outcome' => 'retry', 'reason' => "page_http_{$pageCode}",
                    'page_http_code' => $pageCode,
                    'error' => "Страница вернула HTTP {$pageCode} (ожидался 200) — в API не отправляем"];
        }
        // v25.0-b1.1 (Блокер 4): финальная схема должна остаться https.
        // HTTPS→HTTP downgrade (даже 200 с верным телом) — нарушение gate
        // публичного HTTPS, URL в переобход не отправляем.
        if ($finalScheme !== '' && $finalScheme !== 'https') {
            return ['outcome' => 'retry', 'reason' => 'downgraded_to_http',
                    'page_http_code' => $pageCode,
                    'error' => "Страница уводит с https на {$finalScheme} — в API не отправляем"];
        }
        if ($finalHost !== '' && $finalHost !== $expHost && $finalHost !== 'www.' . $expHost) {
            return ['outcome' => 'failed', 'reason' => 'wrong_final_host',
                    'page_http_code' => $pageCode,
                    'error' => "Страница редиректит на чужой host {$finalHost} (ожидался {$expHost})"];
        }

        // 2) Вызов API.
        try {
            $resp = $client->recrawlUrl($userId, $hostId, $url);
        } catch (\Throwable $e) {
            // PATCH 047 revision (recrawl blocker): critical routing failure (source_ip_mismatch/
            // bind_failed/resolve_failed/unexpected_redirect) НЕ маскируем под обычный recrawl
            // outcome — пробрасываем наружу, чтобы runWmRecrawlStage применил единую политику
            // (awaiting_user + next_run_at=NULL + critical event + Telegram + releaseClaims, без
            // fallback). network_timeout и прочие API/network ошибки — прежняя classify/retry.
            if (class_exists('WebmasterRoutingFailurePolicy')
                && WebmasterRoutingFailurePolicy::isCritical($e)) {
                throw $e;
            }
            return $this->classifyException($e, $pageCode);
        }

        // 3) Классификация ответа.
        return $this->classifyResponse($resp, $pageCode);
    }

    private function probePage(string $url): array
    {
        if ($this->pageProbe !== null) return ($this->pageProbe)($url);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'refresh-panel-recrawl-preflight',
        ]);
        curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        return [
            'http_code'   => $code,
            'final_host'  => strtolower((string)parse_url($finalUrl, PHP_URL_HOST)),
            'final_scheme'=> strtolower((string)parse_url($finalUrl, PHP_URL_SCHEME)),
            'ok'          => $code === 200,
        ];
    }

    /**
     * Ответ recrawlUrl. Ожидаем HTTP 202 + непустой task_id.
     * Поддерживаем разные формы (task_id / data.task_id / id).
     */


    /**
     * Ответ recrawlUrl. Требуем HTTP 202 + непустой task_id (Блокер 3).
     * Боевой клиент кладёт _http_code; fake-тесты — http_code.
     */
    private function classifyResponse($resp, int $pageCode): array
    {
        $arr = is_array($resp) ? $resp : [];
        $hasCode = array_key_exists('http_code', $arr) || array_key_exists('_http_code', $arr);
        $httpCode = (int)($arr['http_code'] ?? $arr['_http_code'] ?? 0);
        $taskId = (string)($arr['task_id'] ?? $arr['data']['task_id'] ?? $arr['id'] ?? '');

        // Приём recrawl — ТОЛЬКО при 202 + непустой task_id.
        if ($httpCode === 202) {
            if ($taskId === '') {
                return ['outcome' => 'retry', 'reason' => 'accepted_without_task_id',
                        'api_http_code' => 202, 'page_http_code' => $pageCode,
                        'error' => 'API вернул 202 без task_id - не подтверждено'];
            }
            return ['outcome' => 'accepted', 'api_http_code' => 202,
                    'task_id' => $taskId, 'page_http_code' => $pageCode];
        }

        // Код есть, но не 202 (напр. 200 без постановки в очередь) - не приняли.
        if ($hasCode && $httpCode !== 0) {
            return $this->classifyHttpCode($httpCode, (string)($arr['error_code'] ?? ''), $pageCode,
                (string)($arr['message'] ?? "recrawl API вернул HTTP {$httpCode} (ожидался 202)"));
        }

        // Кода нет вовсе - ретрай (повторный POST даст 409 если приняли ранее).
        if (!$hasCode) {
            return ['outcome' => 'retry', 'reason' => 'no_http_code',
                    'page_http_code' => $pageCode,
                    'error' => 'recrawl API не вернул HTTP-код - не подтверждено'];
        }

        // http_code === 0 при наличии ключа - аномалия, не принимаем.
        return $this->classifyHttpCode($httpCode, (string)($arr['error_code'] ?? ''), $pageCode,
            (string)($arr['message'] ?? 'unexpected recrawl response'));
    }

    private function classifyException(\Throwable $e, int $pageCode): array
    {
        $msg = $e->getMessage();
        $code = $this->extractHttpCode($msg);
        $errCode = $this->extractApiErrorCode($msg);
        return $this->classifyHttpCode($code, $errCode, $pageCode, $msg);
    }

    private function classifyHttpCode(int $httpCode, string $errCode, int $pageCode, string $msg): array
    {
        $ec = strtoupper($errCode);
        $mUp = strtoupper($msg);

        // 409 / URL_ALREADY_ADDED → уже в очереди, считаем принятым.
        if ($httpCode === 409 || strpos($mUp, 'ALREADY') !== false) {
            return ['outcome' => 'accepted', 'api_http_code' => ($httpCode ?: 409),
                    'task_id' => null, 'api_error_code' => ($ec ?: 'URL_ALREADY_ADDED'),
                    'page_http_code' => $pageCode];
        }
        // 429 / QUOTA → pending_quota, попытку не расходуем.
        if ($httpCode === 429 || strpos($mUp, 'QUOTA') !== false) {
            return ['outcome' => 'pending_quota', 'api_http_code' => ($httpCode ?: 429),
                    'api_error_code' => ($ec ?: 'QUOTA_EXCEEDED'), 'page_http_code' => $pageCode];
        }
        // 400 / INVALID_URL → failed сразу.
        if ($httpCode === 400 || strpos($mUp, 'INVALID_URL') !== false || strpos($mUp, 'INVALID URL') !== false) {
            return ['outcome' => 'failed', 'api_http_code' => ($httpCode ?: 400),
                    'api_error_code' => ($ec ?: 'INVALID_URL'), 'page_http_code' => $pageCode,
                    'error' => $msg];
        }
        // 404 / HOST_NOT_VERIFIED → возврат к верификации (awaiting).
        if ($httpCode === 404 || strpos($mUp, 'HOST_NOT_VERIFIED') !== false || strpos($mUp, 'NOT VERIFIED') !== false) {
            return ['outcome' => 'awaiting_host', 'api_http_code' => ($httpCode ?: 404),
                    'api_error_code' => ($ec ?: 'HOST_NOT_VERIFIED'), 'page_http_code' => $pageCode,
                    'error' => $msg];
        }
        // 401/403 → аккаунт, awaiting сразу.
        if ($httpCode === 401 || $httpCode === 403
            || strpos($mUp, 'UNAUTHORIZED') !== false || strpos($mUp, 'FORBIDDEN') !== false) {
            return ['outcome' => 'awaiting_account', 'api_http_code' => $httpCode,
                    'api_error_code' => ($ec ?: 'ACCOUNT_ERROR'), 'page_http_code' => $pageCode,
                    'error' => $msg];
        }
        // 5xx / сеть / неизвестное → retry.
        return ['outcome' => 'retry', 'api_http_code' => $httpCode,
                'api_error_code' => ($ec ?: ''), 'page_http_code' => $pageCode, 'error' => $msg];
    }

    private function extractHttpCode(string $msg): int
    {
        // Приоритет — код сразу после "HTTP" (формат apiRequest:
        // "Yandex API HTTP 429: ..."), чтобы случайные 3-значные числа в
        // пути/тексте не сбивали классификацию.
        if (preg_match('~HTTP\s+(\d{3})~i', $msg, $m)) return (int)$m[1];
        if (preg_match('~\b(4\d\d|5\d\d|2\d\d)\b~', $msg, $m)) return (int)$m[1];
        return 0;
    }

    private function extractApiErrorCode(string $msg): string
    {
        if (preg_match('~\b([A-Z][A-Z0-9_]{3,})\b~', $msg, $m)) return $m[1];
        return '';
    }
}
