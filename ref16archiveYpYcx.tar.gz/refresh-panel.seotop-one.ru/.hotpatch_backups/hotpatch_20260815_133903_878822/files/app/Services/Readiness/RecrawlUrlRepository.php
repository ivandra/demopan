<?php

/**
 * v25.0-b: репозиторий per-URL учёта recrawl (таблица refresh_job_recrawl_urls).
 *
 * Инкапсулирует весь lifecycle URL: планирование, атомарный «захват» перед
 * отправкой (защита от двойной отправки двумя cron), пометки accepted/retry/
 * pending_quota/failed/excluded, выборку готовых к следующей попытке и сводку
 * planned/attempted/accepted/retry/pending_quota/failed для gate завершения.
 */
class RecrawlUrlRepository
{
    const ST_PENDING       = 'pending';
    const ST_PENDING_QUOTA = 'pending_quota';
    const ST_RETRY         = 'retry';
    const ST_ACCEPTED      = 'accepted';
    const ST_FAILED        = 'failed';
    const ST_EXCLUDED      = 'excluded';

    /** Максимум попыток на один URL до перевода в failed. */
    public static function maxAttempts(): int
    {
        return max(1, AppSettings::getInt('recrawl.max_attempts_per_url', 5));
    }

    /**
     * ТЗ 046 §1/§2: является ли URL sitemap'ом (не для переобхода).
     * Проверяем basename пути: sitemap.xml / sitemap_index.xml / sitemap*.xml.
     */
    public static function isSitemapUrl(string $url): bool
    {
        $path = (string)parse_url($url, PHP_URL_PATH);
        if ($path === '') $path = $url;
        $base = strtolower(basename($path));
        return (bool)preg_match('~^sitemap[a-z0-9_\-]*\.xml$~', $base);
    }

    /**
     * ТЗ 046 §2: безопасно финализировать старые sitemap-строки перед claimBatch, чтобы
     * они НЕ были отправлены в переобход. Исторические accepted/excluded не трогаем.
     * @return int число исключённых строк
     */
    public static function excludeSitemapRows(int $jobId): int
    {
        $st = DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status='excluded', last_error='sitemap_not_for_recrawl',
                    next_retry_at=NULL, claimed_at=NULL, updated_at=NOW()
              WHERE job_id=? AND role='sitemap' AND status NOT IN ('accepted','excluded')"
        );
        $st->execute([$jobId]);
        return $st->rowCount();
    }

    /**
     * Запланировать набор URL для джобы (идемпотентно по UNIQUE(job_id,url_hash)).
     * Уже существующие записи НЕ трогаем — их статус/попытки сохраняются.
     *
     * @param array $urls список ['url'=>..., 'role'=>'home|sitemap|page', 'required'=>bool]
     * @return int сколько НОВЫХ записей добавлено
     */
    public static function planUrls(int $jobId, array $urls): int
    {
        $added = 0;
        $st = DB::pdo()->prepare(
            "INSERT INTO refresh_job_recrawl_urls
                (job_id, url, url_hash, is_required, role, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, 'pending', NOW(), NOW())
             ON DUPLICATE KEY UPDATE id = id"  // no-op при повторе
        );
        foreach ($urls as $u) {
            $url = trim((string)($u['url'] ?? ''));
            if ($url === '') continue;
            $role = (string)($u['role'] ?? 'page');
            $required = !empty($u['required']) ? 1 : 0;
            $st->execute([$jobId, $url, sha1($url), $required, $role]);
            if ($st->rowCount() === 1) $added++; // 1 = вставка, 0/2 = дубль/update
        }
        return $added;
    }

    /**
     * Атомарно «захватить» до $limit URL, готовых к отправке СЕЙЧАС
     * (pending / pending_quota / retry с наступившим next_retry_at).
     * Захват = пометка status='__claimed' на время отправки, чтобы параллельный
     * cron не взял те же URL. Возвращает захваченные строки.
     *
     * accepted/failed/excluded НЕ выбираются никогда (accepted не досылаем).
     */
    public static function claimBatch(int $jobId, int $limit): array
    {
        $limit = max(1, $limit);
        $pdo = DB::pdo();
        $pdo->beginTransaction();
        try {
            // Выбираем кандидатов с блокировкой строк.
            $sel = $pdo->prepare(
                "SELECT id FROM refresh_job_recrawl_urls
                  WHERE job_id = ?
                    AND status IN ('pending','pending_quota','retry')
                    AND (next_retry_at IS NULL OR next_retry_at <= NOW())
                  ORDER BY is_required DESC, id ASC
                  LIMIT {$limit}
                  FOR UPDATE"
            );
            $sel->execute([$jobId]);
            $ids = array_map('intval', array_column($sel->fetchAll(), 'id'));
            if (empty($ids)) { $pdo->commit(); return []; }

            $in = implode(',', array_fill(0, count($ids), '?'));
            $pdo->prepare(
                "UPDATE refresh_job_recrawl_urls
                    SET status = '__claimed', claimed_at = NOW(), updated_at = NOW()
                  WHERE id IN ($in)"
            )->execute($ids);

            $rows = $pdo->prepare(
                "SELECT * FROM refresh_job_recrawl_urls WHERE id IN ($in)"
            );
            $rows->execute($ids);
            $out = $rows->fetchAll();
            $pdo->commit();
            return $out;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /** Освободить «зависшие» claimed-строки обратно (например при исключении в цикле). */
    public static function releaseClaims(int $jobId): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status = 'retry', next_retry_at = NOW(), claimed_at = NULL, updated_at = NOW()
              WHERE job_id = ? AND status = '__claimed'"
        )->execute([$jobId]);
    }

    /**
     * v25.0-b1 (B4): восстановить «залипшие» __claimed-строки, чьи процессы
     * упали (kill/hard-timeout/рестарт) и claimed_at старше порога. Возвращаем в
     * retry, чтобы их снова выбрал claimBatch. Повторный POST для реально
     * принятого URL вернёт URL_ALREADY_ADDED → accepted.
     */
    public static function recoverStaleClaims(int $jobId, int $claimTimeoutSec = 300): int
    {
        $st = DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status='retry', next_retry_at=NOW(), claimed_at=NULL, updated_at=NOW()
              WHERE job_id=? AND status='__claimed'
                AND claimed_at IS NOT NULL
                AND claimed_at < DATE_SUB(NOW(), INTERVAL ? SECOND)"
        );
        $st->execute([$jobId, max(30, $claimTimeoutSec)]);
        return $st->rowCount();
    }

    /** URL принят Яндексом (HTTP 202 + task_id, либо 409 URL_ALREADY_ADDED). */
    public static function markAccepted(int $id, ?int $apiHttpCode = null, ?string $taskId = null, ?int $pageHttpCode = null): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status='accepted', api_accepted=1, accepted_at=NOW(),
                    attempts=attempts+1, last_api_http_code=?, task_id=?,
                    last_page_http_code=?, last_error=NULL, last_api_error_code=NULL,
                    next_retry_at=NULL, claimed_at=NULL, updated_at=NOW()
              WHERE id=?"
        )->execute([$apiHttpCode, $taskId, $pageHttpCode, $id]);
    }

    /** Временная ошибка → retry с backoff, либо failed при исчерпании попыток. */
    public static function markRetryOrFailed(int $id, int $attemptsSoFar, string $error, ?int $apiHttpCode = null, ?string $apiErrorCode = null): string
    {
        $attempts = $attemptsSoFar + 1;
        if ($attempts >= self::maxAttempts()) {
            DB::pdo()->prepare(
                "UPDATE refresh_job_recrawl_urls
                    SET status='failed', attempts=?, last_api_http_code=?, last_api_error_code=?,
                        last_error=?, next_retry_at=NULL, claimed_at=NULL, updated_at=NOW()
                  WHERE id=?"
            )->execute([$attempts, $apiHttpCode, $apiErrorCode, mb_substr($error, 0, 1000), $id]);
            return self::ST_FAILED;
        }
        $delay = min(3600, 60 * (int)pow(2, min(5, $attempts - 1)));
        DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status='retry', attempts=?, last_api_http_code=?, last_api_error_code=?,
                    last_error=?, next_retry_at=DATE_ADD(NOW(), INTERVAL ? SECOND),
                    claimed_at=NULL, updated_at=NOW()
              WHERE id=?"
        )->execute([$attempts, $apiHttpCode, $apiErrorCode, mb_substr($error, 0, 1000), $delay, $id]);
        return self::ST_RETRY;
    }

    /** Немедленный failed (INVALID_URL и т.п. — ретраить бессмысленно). */
    public static function markFailedImmediate(int $id, string $error, ?int $apiHttpCode = null, ?string $apiErrorCode = null): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status='failed', attempts=attempts+1, last_api_http_code=?, last_api_error_code=?,
                    last_error=?, next_retry_at=NULL, claimed_at=NULL, updated_at=NOW()
              WHERE id=?"
        )->execute([$apiHttpCode, $apiErrorCode, mb_substr($error, 0, 1000), $id]);
    }

    /** Страница не прошла preflight (не 200 / чужой host) → retry без расхода API-попытки логики. */
    public static function markPageUnreachable(int $id, int $attemptsSoFar, string $error, ?int $pageHttpCode = null): string
    {
        $attempts = $attemptsSoFar + 1;
        if ($attempts >= self::maxAttempts()) {
            DB::pdo()->prepare(
                "UPDATE refresh_job_recrawl_urls
                    SET status='failed', attempts=?, last_page_http_code=?, last_error=?,
                        next_retry_at=NULL, claimed_at=NULL, updated_at=NOW()
                  WHERE id=?"
            )->execute([$attempts, $pageHttpCode, mb_substr($error, 0, 1000), $id]);
            return self::ST_FAILED;
        }
        $delay = min(3600, 60 * (int)pow(2, min(5, $attempts - 1)));
        DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status='retry', attempts=?, last_page_http_code=?, last_error=?,
                    next_retry_at=DATE_ADD(NOW(), INTERVAL ? SECOND), claimed_at=NULL, updated_at=NOW()
              WHERE id=?"
        )->execute([$attempts, $pageHttpCode, mb_substr($error, 0, 1000), $delay, $id]);
        return self::ST_RETRY;
    }

    /** Квота исчерпана → pending_quota, ждём следующего окна (без расхода попытки). */
    public static function markPendingQuota(int $id, int $retryAfterSec = 900): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status='pending_quota',
                    next_retry_at=DATE_ADD(NOW(), INTERVAL ? SECOND),
                    claimed_at=NULL, updated_at=NOW()
              WHERE id=?"
        )->execute([$retryAfterSec, $id]);
    }

    public static function markExcluded(int $id, string $reason): void
    {
        DB::pdo()->prepare(
            "UPDATE refresh_job_recrawl_urls
                SET status='excluded', last_error=?, next_retry_at=NULL, updated_at=NOW()
              WHERE id=?"
        )->execute([mb_substr($reason, 0, 1000), $id]);
    }

    /** Сводка по джобе: счётчики статусов + флаги обязательных. */
    public static function summary(int $jobId): array
    {
        $st = DB::pdo()->prepare(
            "SELECT status, COUNT(*) c FROM refresh_job_recrawl_urls
              WHERE job_id=? GROUP BY status"
        );
        $st->execute([$jobId]);
        $counts = [];
        foreach ($st->fetchAll() as $r) $counts[(string)$r['status']] = (int)$r['c'];

        $planned = 0; foreach ($counts as $c) $planned += $c;

        // Обязательные, ещё НЕ финализированные (accepted/excluded).
        $reqOpen = DB::pdo()->prepare(
            "SELECT COUNT(*) FROM refresh_job_recrawl_urls
              WHERE job_id=? AND is_required=1
                AND status NOT IN ('accepted','excluded')"
        );
        $reqOpen->execute([$jobId]);
        $requiredOpen = (int)$reqOpen->fetchColumn();

        // Обязательные в failed (нужно внимание оператора).
        $reqFailed = DB::pdo()->prepare(
            "SELECT id, url, last_error FROM refresh_job_recrawl_urls
              WHERE job_id=? AND is_required=1 AND status='failed'"
        );
        $reqFailed->execute([$jobId]);
        $requiredFailed = $reqFailed->fetchAll();

        // Роль-специфичные обязательные (home/sitemap). Роль считается
        // «закрытой», если запись accepted ЛИБО excluded (напр. sitemap.xml
        // физически отсутствует на сайте — это допустимый финальный исход,
        // а не вечная блокировка стадии).
        $roleAccepted = [];
        foreach (['home'] as $role) { // ТЗ046: sitemap больше не required-роль в completion gate
            $q = DB::pdo()->prepare(
                "SELECT
                    SUM(role=? AND status IN ('accepted','excluded')) acc,
                    SUM(role=?) total
                 FROM refresh_job_recrawl_urls WHERE job_id=?"
            );
            $q->execute([$role, $role, $jobId]);
            $row = $q->fetch();
            $roleAccepted[$role] = [
                'accepted' => (int)($row['acc'] ?? 0),
                'total'    => (int)($row['total'] ?? 0),
            ];
        }

        return [
            'planned'        => $planned,
            'accepted'       => $counts['accepted'] ?? 0,
            'retry'          => $counts['retry'] ?? 0,
            'pending'        => $counts['pending'] ?? 0,
            'pending_quota'  => $counts['pending_quota'] ?? 0,
            'failed'         => $counts['failed'] ?? 0,
            'excluded'       => $counts['excluded'] ?? 0,
            'claimed'        => $counts['__claimed'] ?? 0,
            'required_open'  => $requiredOpen,
            'required_failed'=> $requiredFailed,
            'role_accepted'  => $roleAccepted,
        ];
    }

    /**
     * Готова ли стадия к завершению (done):
     * все обязательные URL в accepted/excluded, и роли home+sitemap accepted
     * (если они запланированы). Дополнительные (не required) не блокируют.
     */
    public static function isComplete(int $jobId): bool
    {
        $s = self::summary($jobId);
        if ($s['planned'] === 0) return false; // нечего слать — решает вызыватель
        if ($s['required_open'] > 0) return false;
        if (!empty($s['required_failed'])) return false;
        // Защита от ложного полного успеха: должен быть принят хотя бы ОДИН
        // реальный URL. Ситуация «всё excluded, 0 accepted» — это не успех
        // переобхода (Яндексу ничего не отправлено), а повод к awaiting_user.
        if ($s['accepted'] < 1) return false;
        foreach (['home'] as $role) { // ТЗ046: только home
            $ra = $s['role_accepted'][$role] ?? ['total'=>0,'accepted'=>0];
            if ($ra['total'] > 0 && $ra['accepted'] < $ra['total']) return false;
        }
        return true;
    }

    /** Есть ли обязательные URL, ушедшие в failed (для awaiting_user). */
    public static function hasRequiredFailure(int $jobId): bool
    {
        $s = self::summary($jobId);
        return !empty($s['required_failed']);
    }

    /** Есть ли ещё «живые» (не финальные) URL для досылки. */
    public static function hasWorkLeft(int $jobId): bool
    {
        $st = DB::pdo()->prepare(
            "SELECT COUNT(*) FROM refresh_job_recrawl_urls
              WHERE job_id=? AND status IN ('pending','pending_quota','retry','__claimed')"
        );
        $st->execute([$jobId]);
        return (int)$st->fetchColumn() > 0;
    }

    /** Удалить записи джобы (для rollback/повторного планирования). */
    public static function clearForJob(int $jobId): void
    {
        DB::pdo()->prepare("DELETE FROM refresh_job_recrawl_urls WHERE job_id=?")->execute([$jobId]);
    }
}
