<?php

/**
 * DiagnosticCatalog (ТЗ 045 ADDENDUM §15) — единый каталог классификации событий/ошибок.
 *
 * Presentation/diagnostics-only: НЕ меняет state machine, покупку, FTP, SSL, redirect,
 * recovery, cron, retry. Только читает уже существующее состояние (next_run_at, attempt,
 * deadline) для корректного объяснения пользователю.
 *
 * Единственный источник семантической диагностики для UI, Telegram и stage_error —
 * classify() возвращает структурированный дескриптор (§1). JobEventPresenter лишь
 * рендерит его в человекочитаемый текст/бейджи; отдельных словарей во View нет (§15).
 */
final class DiagnosticCatalog
{
    /** Русские подписи критичности (§2). */
    public const SEVERITY_LABELS = [
        'info'     => 'ИНФОРМАЦИЯ',
        'warning'  => 'ПРЕДУПРЕЖДЕНИЕ',
        'error'    => 'ОШИБКА — ЭТАП ОСТАНОВЛЕН',
        'critical' => 'КРИТИЧЕСКАЯ ОШИБКА — ТРЕБУЕТСЯ ВМЕШАТЕЛЬСТВО',
    ];

    /** Русские подписи источника (§3). */
    public const SOURCE_LABELS = [
        'panel'            => 'Панель',
        'site'             => 'Конфигурация сайта',
        'external_service' => 'Внешний сервис',
        'network_dns'      => 'DNS / сеть',
        'hosting'          => 'Хостинг / сервер сайта',
        'operator'         => 'Действие пользователя',
        'registrar'        => 'Регистратор доменов',
        'selector'         => 'Подбор кандидата',
        'unknown'          => 'Источник не установлен',
    ];

    /** P0-3: коды с success-семантикой — только их запрещено презентовать как non-error при level=error. */
    public const SUCCESS_EVENT_CODES = [
        'config.readback_verified','config_readback_verified',
        'redirect.enabled','redirect_enabled','redirect.disabled','redirect_disabled',
        'ssl.trusted','ssl_trusted','ssl.pending','ssl_pending',
        'robots.verified','robots_verified',
        'webmaster.routing_verified','webmaster_routing_verified',
    ];

    public const CONFIDENCE_LABELS = [
        'confirmed' => 'высокая',
        'likely'    => 'средняя',
        'unknown'   => 'не установлена',
    ];

    /**
     * Классифицировать событие. Возвращает полный дескриптор (§1) с raw_message.
     * @return array
     */
    public static function classify(string $stage, string $level, string $message, array $payload = []): array
    {
        $low = mb_strtolower($message);
        $d = self::detect($stage, $level, $low, $message, $payload);
        if ($d === null) {
            $d = self::generic($stage, $level);
        }
        // Общие поля.
        $d['raw_message']   = $message;
        $d['stage_raw']     = $stage;
        $d['event_code']    = (string)($payload['event_code'] ?? '');
        $d['severity_label'] = self::SEVERITY_LABELS[$d['severity']] ?? 'СОБЫТИЕ';
        $d['source_label']   = self::SOURCE_LABELS[$d['source']] ?? 'Источник не установлен';
        $d['confidence_label'] = self::CONFIDENCE_LABELS[$d['source_confidence']] ?? 'не установлена';
        // wait: next_retry_at из уже существующего next_run_at (§14 — только реальные данные).
        [$d['next_retry_at'], $d['wait_text']] = self::resolveWait($d, $payload);
        // E2E-аудит §4/§19/§20: presentation-инвариант — семантика уровня события доминирует
        // над случайно совпавшим failure-branch. level=ok НИКОГДА не презентуется как blocking
        // error/«требуется вмешательство» из-за message/technical_code.
        $d = self::reconcileWithLevel($d, $level);
        return $d;
    }

    /**
     * E2E-аудит §4/§19/§20: единый контракт level ↔ severity ↔ requires_intervention.
     *  - level=ok  → не error/critical, human_action=none, requires_intervention=false;
     *                failure-образный technical_code (*_failed/_error/_failure) нейтрализуется
     *                (оригинал сохраняется в technical_code_original для тех. деталей §22).
     *  - level=warning → не critical; вмешательство только если ветка явно human_action=required.
     *  - level=error → остаётся error (реальные ошибки НЕ маскируются, §21).
     */
    private static function reconcileWithLevel(array $d, string $level): array
    {
        $lvl = mb_strtolower($level);
        if (in_array($lvl, ['ok', 'success'], true)) {
            if (in_array($d['severity'], ['error', 'critical'], true)) $d['severity'] = 'info';
            $d['human_action'] = 'none';
            $d['human_action_text'] = '';
            $d['auto_recovery'] = false;
            $tc = (string)($d['technical_code'] ?? '');
            if ($tc !== '' && preg_match('/(_failed|_error|_failure)$/', $tc)) {
                $d['technical_code_original'] = $tc;
                $d['technical_code'] = 'stage_success';
            }
            $d['requires_intervention'] = false;
        } elseif (in_array($lvl, ['warn', 'warning'], true)) {
            // §19: warning НЕ означает автоматически вмешательство, но ветка может явно его требовать
            // (напр. ambiguous_purchase — нужен выбор оператора). severity ветки не трогаем.
            $d['requires_intervention'] = ($d['human_action'] === 'required');
        } elseif (!in_array($lvl, ['error', 'critical', 'fatal'], true)) {
            // info / notice / прочие НЕ-ошибочные уровни: не повышаем severity, не блокируем.
            // requires_intervention только если ветка явно требует действия оператора.
            $d['requires_intervention'] = ($d['human_action'] === 'required');
        } else {
            // level = error / critical / fatal. §2 финального ТЗ: УРОВЕНЬ ДОМИНИРУЕТ над
            // текстовым/кодовым дескриптором — реальная ошибка НЕ отображается как info/warning.
            // Recoverable-события, которые должны остаться warning, эмиттер обязан писать level=warning.
            $ec = (string)($d['event_code'] ?? '');
            $isSuccessCode = in_array($ec, self::SUCCESS_EVENT_CODES, true);
            // Доп. диагностика нарушения контракта — ТОЛЬКО для success-кодов (флаг + оригинал кода).
            if ($isSuccessCode && !in_array($d['severity'], ['error', 'critical'], true)) {
                $d['success_code_at_error'] = true;
                $d['technical_code_original'] = (string)($d['technical_code'] ?? '');
                $d['technical_code'] = 'level_error_contract_violation';
            }
            // Повышение severity НЕ зависит от принадлежности к SUCCESS_EVENT_CODES.
            if (in_array($lvl, ['critical', 'fatal'], true)) {
                $d['severity'] = 'critical';                    // critical/fatal → critical
            } elseif (!in_array($d['severity'], ['error', 'critical'], true)) {
                $d['severity'] = 'error';                       // error → не ниже error
            }
            $d['requires_intervention'] = true;                 // ошибочный уровень всегда требует внимания
        }
        $d['severity_label'] = self::SEVERITY_LABELS[$d['severity']] ?? 'СОБЫТИЕ';
        return $d;
    }

    /** Базовый дескриптор с дефолтами — конкретные ветки переопределяют нужные поля. */
    private static function base(array $over): array
    {
        return array_merge([
            'severity'           => 'error',
            'source'             => 'unknown',
            'source_confidence'  => 'unknown',
            'title'              => 'Событие обработки джобы',
            'reason'             => '',
            'impact'             => '',
            'safety'             => '',
            'auto_recovery'      => false,
            'auto_recovery_text' => '',
            'human_action'       => 'none',
            'human_action_text'  => '',
            'requires_intervention' => false,
            'wait_state'         => 'no_wait',
            'wait_text'          => '',
            'technical_code'     => '',
        ], $over);
    }

    /** Detection (ordered — специфичные раньше общих). @return array|null */
    private static function detect(string $stage, string $level, string $low, string $message, array $payload): ?array
    {
        $code = (string)($payload['event_code'] ?? '');

        // ТЗ047 §37/§38: критические ошибки маршрутизации исходящего IP Webmaster.
        if ($code === 'webmaster.source_ip_mismatch') {
            return self::base([
                'severity' => 'critical', 'source' => 'network_dns', 'source_confidence' => 'likely',
                'title' => 'Критическая ошибка маршрутизации Webmaster',
                'reason' => 'Панель не смогла подтвердить, что запрос к Yandex.Webmaster выполняется с IP, закреплённого за этим аккаунтом (фактический исходящий IP не совпал с назначенным).',
                'impact' => 'Операция Yandex остановлена.',
                'safety' => 'Повтор с основного/другого IP НЕ выполнялся (fallback запрещён).',
                'auto_recovery' => false, 'human_action' => 'required',
                'human_action_text' => 'Проверьте исходящий IP аккаунта и состояние IP на VPS (ip addr).',
                'technical_code' => 'webmaster_source_ip_mismatch',
            ]);
        }
        if ($code === 'webmaster.bind_failed') {
            return self::base([
                'severity' => 'critical', 'source' => 'hosting', 'source_confidence' => 'likely',
                'title' => 'Yandex.Webmaster не вызван (bind)',
                'reason' => 'Панель не смогла привязать TCP-соединение к назначенному исходящему IP.',
                'impact' => 'Запрос к Yandex API не выполнен.',
                'safety' => 'Fallback на другой IP запрещён.',
                'auto_recovery' => false, 'human_action' => 'required',
                'human_action_text' => 'Вероятно, IP выключен/удалён/недоступен в сетевой конфигурации VPS. Проверьте ip addr.',
                'technical_code' => 'webmaster_source_ip_bind_failed',
            ]);
        }
        if ($code === 'webmaster.routing_selected') {
            return self::base([
                'severity' => 'info', 'source' => 'panel', 'source_confidence' => 'confirmed',
                'title' => 'Исходящий IP Webmaster выбран',
                'reason' => 'Для аккаунта выбран исходящий IP; следующий запрос будет жёстко привязан к этому адресу. Это выбор маршрута, а не подтверждение фактического соединения.',
                'impact' => 'Маршрут выбран.', 'safety' => 'Жёсткая привязка; fallback запрещён.',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'webmaster_routing_selected',
            ]);
        }
        if ($code === 'webmaster.routing_verified' || $code === 'webmaster.routing_ok') {
            return self::base([
                'severity' => 'info', 'source' => 'panel', 'source_confidence' => 'confirmed',
                'title' => 'Исходящий IP Webmaster подтверждён',
                'reason' => 'Фактический исходящий IP (CURLINFO_LOCAL_IP) совпал с назначенным — подтверждён реальным соединением.',
                'impact' => 'Запрос выполнен через закреплённый IP.', 'safety' => 'Жёсткая привязка соблюдена.',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'webmaster_routing_verified',
            ]);
        }

        // ═══ E2E-аудит: явные success/warning коды (устраняют ложные ERROR при success) ═══
        // §5: успешный exact read-back config.php — это УСПЕХ, не ftp_read_failed.
        if ($code === 'config.readback_verified' || $code === 'config_readback_verified') {
            return self::base([
                'severity' => 'info', 'source' => 'site', 'source_confidence' => 'confirmed',
                'title' => 'Конфигурация сайта обновлена',
                'reason' => 'Изменения подтверждены повторным чтением файла с сервера (exact read-back).',
                'impact' => 'Конфигурация применена и проверена.', 'safety' => '',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'config_readback_verified',
            ]);
        }
        // §6: успешное восстановление редиректов — enabled, а не disabled.
        if ($code === 'redirect.enabled' || $code === 'redirect_enabled') {
            return self::base([
                'severity' => 'info', 'source' => 'site', 'source_confidence' => 'confirmed',
                'title' => 'Редиректы восстановлены',
                'reason' => 'Стадия restore завершена, post-validation не нашла временных disable-маркеров.',
                'impact' => 'Редиректы снова активны.', 'safety' => '',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'redirect_enabled',
            ]);
        }
        // редирект действительно временно отключён — это штатное non-terminal состояние.
        if ($code === 'redirect.disabled' || $code === 'redirect_disabled') {
            return self::base([
                'severity' => 'info', 'source' => 'site', 'source_confidence' => 'confirmed',
                'title' => 'Редиректы временно отключены',
                'reason' => 'На время выполнения pipeline редиректы отключены и будут восстановлены автоматически.',
                'impact' => 'Временное состояние.', 'safety' => '',
                'auto_recovery' => true, 'human_action' => 'none',
                'technical_code' => 'redirect_disabled',
            ]);
        }
        // §7: доверенный SSL подтверждён live-проверкой — success, не ssl_pending.
        if ($code === 'ssl.trusted' || $code === 'ssl_trusted' || $code === 'ssl_verified') {
            return self::base([
                'severity' => 'info', 'source' => 'external_service', 'source_confidence' => 'confirmed',
                'title' => 'Доверенный SSL-сертификат подтверждён',
                'reason' => 'Live TLS-проверка подтвердила валидный trusted-сертификат (Let\'s Encrypt).',
                'impact' => 'SSL готов, pipeline продолжается.', 'safety' => '',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'ssl_trusted',
            ]);
        }
        // §8/§23: длительное ожидание trusted SSL — warning с известным источником SSL, НЕ unknown.
        if ($code === 'ssl.wait_long' || $code === 'ssl_wait_long') {
            return self::base([
                'severity' => 'warning', 'source' => 'external_service', 'source_confidence' => 'confirmed',
                'title' => 'Выпуск доверенного SSL занимает больше обычного',
                'reason' => 'Trusted-сертификат пока не получен, панель продолжает автоматически ожидать его появления.',
                'impact' => 'Ожидание; вмешательство пока не требуется.', 'safety' => 'Job не остановлена до hard timeout.',
                'auto_recovery' => true, 'human_action' => 'none',
                'technical_code' => 'ssl_wait_long',
            ]);
        }
        // ssl_pending — ожидание (не failure).
        if ($code === 'ssl.pending' || $code === 'ssl_pending') {
            return self::base([
                'severity' => 'info', 'source' => 'external_service', 'source_confidence' => 'confirmed',
                'title' => 'Ожидание доверенного SSL',
                'reason' => 'Trusted SSL пока не получен — панель ожидает выпуска сертификата.',
                'impact' => 'Ожидание.', 'safety' => '',
                'auto_recovery' => true, 'human_action' => 'none',
                'technical_code' => 'ssl_pending',
            ]);
        }
        // §11: robots.txt действительно подтверждён через API.
        if ($code === 'robots.verified' || $code === 'robots_verified') {
            return self::base([
                'severity' => 'info', 'source' => 'site', 'source_confidence' => 'confirmed',
                'title' => 'robots.txt проверен',
                'reason' => 'robots.txt получен прямым HTTP GET-запросом к сайту, TLS доверенный, '
                    . 'конечный host совпадает с доменом, содержимое распознано как директивы robots.',
                'impact' => '', 'safety' => '',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'robots_verified',
            ]);
        }
        // §11/§12: данные robots через API получить не удалось — best-effort, НЕ verified, НЕ блокирует.
        if ($code === 'robots.api_unavailable' || $code === 'robots_api_unavailable' || $code === 'robots_check_unavailable') {
            return self::base([
                'severity' => 'warning', 'source' => 'external_service', 'source_confidence' => 'confirmed',
                'title' => 'Дополнительная API-проверка robots недоступна',
                'reason' => 'Диагностический Webmaster API не отдал robots-инфо (best-effort). '
                    . 'Это относится ТОЛЬКО к дополнительному API и не описывает состояние robots.txt на сайте.',
                'impact' => 'Дополнительная проверка не выполнена; прямой HTTP-результат см. отдельным событием.',
                'safety' => 'Pipeline продолжает работу.',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'robots_api_unavailable',
            ]);
        }
        // P1-2: провал прямого HTTP robots.txt (транспорт) — отдельный код, НЕ api_unavailable.
        if ($code === 'robots.http_unavailable' || $code === 'robots_http_unavailable') {
            return self::base([
                'severity' => 'warning', 'source' => 'site', 'source_confidence' => 'confirmed',
                'title' => 'robots.txt недоступен по прямому HTTP',
                'reason' => 'Прямой HTTP-запрос к /robots.txt не вернул валидный ответ (транспорт/редирект/host). '
                    . 'Стадия best-effort — pipeline продолжается; Yandex прочитает robots при обходе.',
                'impact' => 'Прямая проверка robots.txt не подтверждена.', 'safety' => 'Pipeline продолжает работу.',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'robots_http_unavailable',
            ]);
        }
        // P1-2: robots.txt ответил, но содержимое не распознано как директивы (напр. HTML/редирект на главную).
        if ($code === 'robots.content_invalid' || $code === 'robots_content_invalid') {
            return self::base([
                'severity' => 'warning', 'source' => 'site', 'source_confidence' => 'confirmed',
                'title' => 'robots.txt отдаёт неожиданное содержимое',
                'reason' => 'HTTP-ответ получен, но тело не похоже на robots-директивы (возможно HTML/редирект на страницу).',
                'impact' => 'Содержимое robots.txt не подтверждено.', 'safety' => 'Pipeline продолжает работу.',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'robots_content_invalid',
            ]);
        }
        // §13-§15: отклонение candidate домена/sub_id с machine-readable причиной.
        if ($code === 'candidate.rejected' || $code === 'candidate_rejected') {
            $reason = (string)($payload['reason'] ?? 'unknown');
            $cand = (string)($payload['candidate'] ?? '');
            $next = (string)($payload['next_candidate'] ?? '');
            $reasonRu = [
                'domain_unavailable' => 'домен недоступен',
                'already_exists' => 'домен уже зарегистрирован',
                'registrar_rejected' => 'отклонён регистратором',
                'reserved' => 'домен зарезервирован',
                'validation_failed' => 'не прошёл проверку',
                'price_over_budget' => 'цена выше бюджета',
                'price_fetch_error' => 'не удалось получить цену',
                'unknown' => 'причина не установлена',
            ][$reason] ?? $reason;
            return self::base([
                'severity' => 'info', 'source' => 'registrar', 'source_confidence' => 'confirmed',
                'title' => 'Кандидат отклонён',
                'reason' => 'Кандидат ' . ($cand !== '' ? "«{$cand}» " : '') . 'отклонён: ' . $reasonRu . '.'
                    . ($next !== '' ? " Следующий кандидат: «{$next}»." : ''),
                'impact' => 'Панель переходит к следующему кандидату (штатно).', 'safety' => '',
                'auto_recovery' => true, 'human_action' => 'none',
                'technical_code' => 'candidate_rejected',
            ]);
        }
        // §28: ручное завершение job — не выдавать за естественный успешный полный pipeline.
        if ($code === 'job.manual_completed' || $code === 'job_manual_completed') {
            $skipped = $payload['skipped_stages'] ?? [];
            $skippedTxt = is_array($skipped) && $skipped ? (' Не выполнены стадии: ' . implode(', ', $skipped) . '.') : '';
            return self::base([
                'severity' => 'warning', 'source' => 'operator', 'source_confidence' => 'confirmed',
                'title' => 'Job завершена вручную',
                'reason' => 'Джоба была завершена оператором вручную.' . $skippedTxt,
                'impact' => 'Финальные стадии не выполнялись автоматически.', 'safety' => '',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'job_manual_completed',
            ]);
        }

        $has = function (array $needles) use ($low): bool {
            foreach ($needles as $n) if (mb_strpos($low, mb_strtolower($n)) !== false) return true;
            return false;
        };

        // ТЗ046: результаты proof рандомизации классов (по стабильному event_code).
        if ($code === 'uc.class_delta_verified' || $has(['рандомизация классов подтверждена'])) {
            return self::base([
                'severity' => 'info', 'source' => 'panel', 'source_confidence' => 'confirmed',
                'title' => 'Рандомизация классов подтверждена',
                'reason' => 'Факт смены классов подтверждён прямым сравнением значений до и после запуска: хотя бы одно значение класса реально изменилось.',
                'impact' => 'Этап смены классов засчитан.', 'safety' => 'Подтверждено фактическим состоянием файлов (FTP read-back), а не только ответом скрипта.',
                'auto_recovery' => false, 'human_action' => 'none',
                'technical_code' => 'class_delta_verified',
            ]);
        }
        if ($code === 'uc.class_delta_zero' || $has(['рандомизация классов не подтверждена', 'изменено классов: 0', 'изменено 0 классов'])) {
            return self::base([
                'severity' => 'critical', 'source' => 'site', 'source_confidence' => 'likely',
                'title' => 'Рандомизация классов НЕ подтверждена',
                'reason' => 'Скрипт update_classes.php сообщил об успехе, но контрольные значения классов до и после запуска совпадают — фактической смены классов не произошло.',
                'impact' => 'Этап не считается выполненным.',
                'safety' => 'Автоматический повторный вызов скрипта НЕ выполняется, чтобы исключить повторный mutating-запуск.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте работу update_classes.php на сайте (почему классы не меняются).',
                'technical_code' => 'class_delta_zero',
            ]);
        }
        if ($code === 'uc.class_delta_error') {
            return self::base([
                'severity' => 'error', 'source' => 'hosting', 'source_confidence' => 'likely',
                'title' => 'Не удалось подтвердить рандомизацию классов',
                'reason' => 'Панель не смогла достоверно сравнить значения классов до и после (проблема доступа/идентичности сайта или чтения mapping-файлов).',
                'impact' => 'Этап не считается выполненным.',
                'safety' => 'Скрипт повторно автоматически не вызывается.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте доступ к сайту по FTP и наличие mapping-файлов классов.',
                'technical_code' => 'class_delta_error',
            ]);
        }
        $exhausted = $has(['exhausted', 'исчерпан', 'final', 'окончательн', 'дважды', 'уже выполняла', 'rebuilds']);

        // have/want
        $have = $want = '';
        if (preg_match('~have=[\'"]?([^\'";,\s]+)~', $message, $mh)) $have = $mh[1];
        if (preg_match('~want=[\'"]?([^\'";,\s]+)~', $message, $mw)) $want = $mw[1];
        if ($have === '' && isset($payload['have'])) $have = (string)$payload['have'];
        if ($want === '' && isset($payload['want'])) $want = (string)$payload['want'];

        // ── RECOVERY ──────────────────────────────────────────────────────────
        if ($has(['snapshot_not_written']) || ($has(['live_inspection_failed']) && $has(['snapshot']))) {
            return self::base([
                'severity' => 'error', 'source' => 'hosting', 'source_confidence' => 'likely',
                'title' => 'Не удалось сохранить резервную копию config.php',
                'reason' => 'Перед восстановлением джобы панель пытается сохранить локальную резервную копию текущего config.php, чтобы можно было откатиться. Сделать копию не удалось.',
                'impact' => 'Восстановление джобы не запущено.',
                'safety' => 'Файлы сайта не изменялись.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте доступность сервера сайта, затем повторите восстановление.',
                'technical_code' => 'recovery_snapshot_not_written',
            ]);
        }
        if ($has(['alias_absent_or_unknown', 'cert_absent_or_unknown']) || ($has(['live_inspection_failed']) && $has(['alias', 'cert', 'сертификат']))) {
            return self::base([
                'severity' => 'error', 'source' => 'hosting', 'source_confidence' => 'likely',
                'title' => 'Не удалось подтвердить состояние алиаса/сертификата',
                'reason' => 'Панель не смогла безопасно прочитать текущее состояние доменного алиаса или сертификата на сервере.',
                'impact' => 'Автоматическое восстановление джобы не выполняется.',
                'safety' => 'Никакие действия не повторялись, файлы сайта не изменялись.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте состояние домена в FastPanel и повторите восстановление позже.',
                'technical_code' => 'recovery_live_inspection_failed',
            ]);
        }
        if ($has(['cas_update_failed', 'state_changed_concurrently'])) {
            return self::base([
                'severity' => 'warning', 'source' => 'panel', 'source_confidence' => 'confirmed',
                'title' => 'Состояние джобы изменилось во время восстановления',
                'reason' => 'Пока панель проверяла джобу, её состояние изменил другой процесс.',
                'impact' => 'Восстановление отменено, чтобы не перезаписать более новое состояние.',
                'safety' => 'Ничего не перезаписано.',
                'auto_recovery' => false,
                'human_action' => 'maybe',
                'human_action_text' => 'Обновите страницу и повторно проверьте текущее состояние джобы.',
                'technical_code' => 'recovery_cas_conflict',
            ]);
        }
        if ($has(['not_eligible_status', 'recovery_not_eligible'])) {
            return self::base([
                'severity' => 'warning', 'source' => 'panel', 'source_confidence' => 'confirmed',
                'title' => 'Джобу нельзя восстановить в текущем состоянии',
                'reason' => 'Восстановление доступно только для джоб в состоянии ошибки или ручного ожидания. Эта джоба ещё выполняется или находится в другом состоянии.',
                'impact' => 'Восстановление не выполнялось.',
                'safety' => 'Ничего не изменялось.',
                'auto_recovery' => false,
                'human_action' => 'maybe',
                'human_action_text' => 'Дождитесь завершения текущего этапа или перевода джобы в состояние ошибки, затем повторите.',
                'technical_code' => 'recovery_not_eligible',
            ]);
        }
        if ($has(['live_inspection_failed'])) {
            return self::base([
                'severity' => 'error', 'source' => 'hosting', 'source_confidence' => 'likely',
                'title' => 'Не удалось прочитать состояние сайта перед восстановлением',
                'reason' => 'Панель не смогла безопасно прочитать текущее состояние сайта, необходимое для восстановления джобы.',
                'impact' => 'Восстановление не выполнялось.',
                'safety' => 'Файлы сайта не изменялись.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте доступность сервера сайта и повторите позже.',
                'technical_code' => 'recovery_live_inspection_failed',
            ]);
        }

        // ── CONFIG / PLAN ─────────────────────────────────────────────────────
        if ($has(['prepared_target_invalid', 'domain drift / target', 'read_back_domain_mismatch', 'domain_mismatch'])) {
            $reason = 'Панель подготовила новую версию config.php, но перед записью перечитала её и обнаружила, что поле домена не содержит ожидаемый новый домен джобы.';
            if ($have !== '' && $want !== '') {
                $reason .= ' Обнаружено: ' . $have . '. Ожидалось: ' . $want . '.';
            }
            return self::base([
                'severity' => 'error', 'source' => 'site',
                'source_confidence' => ($have !== '' && $want !== '') ? 'confirmed' : 'likely',
                'title' => 'Новый config.php не прошёл проверку домена',
                'reason' => $reason,
                'impact' => 'Панель не будет записывать этот файл на сервер, пока не убедится, что он корректен.',
                'safety' => 'Непроверенный config.php на сервер НЕ записывался.',
                'auto_recovery' => true,
                'auto_recovery_text' => 'Панель выполняет предусмотренный безопасный повторный анализ конфигурации, если он ещё доступен.',
                'human_action' => 'maybe',
                'human_action_text' => 'Если повторный анализ снова завершится этой ошибкой — потребуется вручную проверить структуру config.php (поле домена).',
                'technical_code' => 'domain_mismatch',
            ]);
        }
        if ($has(['read_back_target_sha_mismatch']) || ($has(['sha', 'target_sha256']) && $has(['mismatch', 'read_back', 'read-back', 'не совпад']))) {
            return self::base([
                'severity' => 'critical', 'source' => 'hosting', 'source_confidence' => 'likely',
                'title' => 'Записанный config.php не совпал с подготовленным',
                'reason' => 'После записи config.php панель перечитала файл с сервера и обнаружила, что он отличается от подготовленной версии.',
                'impact' => 'Дальнейшее перевыставление остановлено, чтобы не продолжить с непроверенной конфигурацией.',
                'safety' => 'Этап не считается успешным; следующие этапы не запускаются.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте фактический config.php на сервере (и доступность/права FTP). Автоматически считать этап успешным нельзя.',
                'technical_code' => 'read_back_sha_mismatch',
            ]);
        }
        if ($has(['read_back_sub_id_mismatch', 'semantic verify', 'semantic_verify', 'semantic mismatch'])) {
            return self::base([
                'severity' => 'error', 'source' => 'site', 'source_confidence' => 'likely',
                'title' => 'Контрольная проверка нового config.php не прошла',
                'reason' => 'Новый config.php подготовлен, но проверка содержимого показала, что обязательные значения нового домена или идентификатора партнёрской ссылки (sub_id) не подтверждены.',
                'impact' => 'Джоба остановлена до проверки конфигурации; следующие этапы не запускаются.',
                'safety' => 'Непроверенная конфигурация дальше не применяется.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Откройте технические детали и проверьте поля домена и sub_id в config.php.',
                'technical_code' => 'semantic_verify_failed',
            ]);
        }
        if ($has(['missing_config_mutation_plan'])) {
            return self::base([
                'severity' => $exhausted ? 'critical' : 'error',
                'source' => $exhausted ? 'site' : 'panel',
                'source_confidence' => $exhausted ? 'likely' : 'confirmed',
                'title' => 'Нет подготовленной новой версии config.php',
                'reason' => 'В плане перевыставления отсутствует подготовленная новая версия config.php.',
                'impact' => 'Панель не будет записывать неполный план на сервер.',
                'safety' => 'config.php на этом шаге не изменялся.',
                'auto_recovery' => !$exhausted,
                'auto_recovery_text' => 'Выполняется повторный анализ сайта и подготовка нового config.php.',
                'human_action' => $exhausted ? 'required' : 'none',
                'human_action_text' => $exhausted ? 'Повторный анализ не смог подготовить новый config.php. Требуется ручная проверка конфигурации сайта.' : '',
                'technical_code' => 'config_mutation_missing',
            ]);
        }
        if ($has(['no plan in artifacts', 'missing_plan', 'нет плана', 'replacement_plan'])) {
            return self::base([
                'severity' => $exhausted ? 'critical' : 'error',
                'source' => $exhausted ? 'site' : 'panel',
                'source_confidence' => $exhausted ? 'likely' : 'confirmed',
                'title' => 'Не найден сохранённый план изменения config.php',
                'reason' => 'Перед изменением config.php панель должна сформировать и сохранить точный план изменений. Для этой джобы такого плана нет — предыдущий этап «Анализ сайта» не завершился корректно либо был прерван/пропущен. Это не означает, что сайт повреждён.',
                'impact' => 'Панель не будет изменять config.php, пока заново не проверит сайт и не построит корректный план.',
                'safety' => 'config.php на этом шаге НЕ изменялся.',
                'auto_recovery' => !$exhausted,
                'auto_recovery_text' => 'Джоба автоматически возвращена на этап «Анализ сайта» для одной безопасной повторной попытки.',
                'human_action' => $exhausted ? 'required' : 'none',
                'human_action_text' => $exhausted
                    ? 'Автоматические попытки исчерпаны. Откройте технические детали и проверьте поля config.php, затем нажмите «Продолжить».'
                    : 'Если повторный анализ снова не построит план — панель явно попросит проверить config.php вручную.',
                'technical_code' => 'replacement_plan_missing',
            ]);
        }
        if ($has(['prepurchase_unsafe', 'preflight'])) {
            return self::base([
                'severity' => 'error', 'source' => 'site', 'source_confidence' => 'likely',
                'title' => 'Проверка сайта перед покупкой домена не прошла',
                'reason' => 'Панель не смогла заранее подтвердить, что config.php можно безопасно перевести на новый домен.',
                'impact' => 'Новый домен не покупался.',
                'safety' => 'Домен НЕ покупался, деньги НЕ списывались, файлы сайта не изменялись.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Сначала проверьте и исправьте конфигурацию сайта; после этого можно повторить перевыставление.',
                'technical_code' => 'prepurchase_unsafe',
            ]);
        }
        if ($has(['pipeline invariant', 'stage_invariant', 'stageinvariant', 'invariant violation', 'enforcestageinvariant', 'нарушение инвариант'])) {
            $selfHeal = $has(['self-heal', 'self_heal', 'вернул', 'пересоб', 'recovery']);
            return self::base([
                'severity' => 'error', 'source' => 'panel', 'source_confidence' => 'confirmed',
                'title' => 'Нарушение порядка этапов',
                'reason' => 'Следующий этап получил неполные данные от предыдущего. Панель остановила опасную операцию, чтобы не изменить сайт по неполным данным.',
                'impact' => 'Небезопасный переход между этапами не выполнен.',
                'safety' => 'Опасная операция не выполнялась.',
                'auto_recovery' => $selfHeal,
                'auto_recovery_text' => 'Панель автоматически вернулась на предыдущий этап и пересобирает недостающие данные.',
                'human_action' => $selfHeal ? 'none' : 'maybe',
                'human_action_text' => $selfHeal ? '' : 'Если проблема повторяется — проверьте результат предыдущего этапа в технических деталях.',
                'technical_code' => 'pipeline_invariant_violation',
            ]);
        }

        // ── PURCHASE / NAMECHEAP ─────────────────────────────────────────────
        if ($has(['ambiguous_purchase', 'purchase_unknown', 'purchase_confirmation', 'неоднозначн'])) {
            return self::base([
                'severity' => 'critical', 'source' => 'external_service', 'source_confidence' => 'likely',
                'title' => 'Результат покупки домена не подтверждён',
                'reason' => 'Запрос на покупку был отправлен, но Namecheap не дал однозначного финального ответа — панель не знает, завершилась ли покупка.',
                'impact' => 'Повторная покупка заблокирована, чтобы исключить двойное списание.',
                'safety' => 'Повторный запрос на покупку НЕ отправляется; выполняется только безопасная проверка наличия домена в аккаунте Namecheap.',
                'auto_recovery' => true,
                'auto_recovery_text' => 'Панель выполняет только read-only проверку через Namecheap, появился ли домен в аккаунте.',
                'human_action' => 'maybe',
                'human_action_text' => 'Если проверка не установит результат в отведённое время — потребуется вручную проверить аккаунт Namecheap.',
                'wait_state' => 'deadline',
                'technical_code' => 'ambiguous_purchase',
            ]);
        }
        if ($has(['transient_exhausted'])) {
            return self::base([
                'severity' => 'error', 'source' => 'external_service', 'source_confidence' => 'likely',
                'title' => 'Namecheap не отвечает после нескольких попыток',
                'reason' => 'Несколько повторных запросов к Namecheap не получили ответа.',
                'impact' => 'Джоба приостановлена.',
                'safety' => 'Покупка не выполнялась, деньги не списывались.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте доступность Namecheap/API; при необходимости повторите позже.',
                'technical_code' => 'namecheap_unavailable',
            ]);
        }
        if ($has(['transient_retry']) || ($has(['namecheap']) && $has(['timed out', 'timeout', 'operation timed out', 'не ответ']))) {
            $op = $has(['pricing', 'цен']) ? 'цены' : 'доступности';
            return self::base([
                'severity' => 'warning', 'source' => 'external_service', 'source_confidence' => 'likely',
                'title' => 'Namecheap временно не ответил',
                'reason' => 'Панель отправила запрос проверки ' . $op . ' домена, но не получила ответ за установленное время. Причина может быть на стороне Namecheap или в сети между сервером и Namecheap.',
                'impact' => 'Проверка домена не завершена.',
                'safety' => 'Запрос на покупку НЕ выполнялся, деньги не списывались.',
                'auto_recovery' => true,
                'auto_recovery_text' => 'Панель повторит проверку того же домена автоматически (следующий номер не берётся).',
                'human_action' => 'none',
                'human_action_text' => 'Пока автоматические попытки не исчерпаны — вмешательство не требуется.',
                'wait_state' => 'deadline',
                'technical_code' => 'namecheap_check_timeout',
            ]);
        }

        // ── DRIFT (info/предупреждение, не авария) ────────────────────────────
        if ($has(['config_domain_drift', 'domain drift', 'domain_drift', 'другой старый домен'])) {
            return self::base([
                'severity' => 'info', 'source' => 'site', 'source_confidence' => 'confirmed',
                'title' => 'В config.php другой старый домен, чем ожидалось',
                'reason' => 'В config.php найден другой старый домен, чем был сохранён при запуске джобы. Панель использовала фактическое значение из файла и пересчитала изменения для нового домена.',
                'impact' => 'Ничего не заблокировано.',
                'safety' => 'Обработка продолжается по фактическому значению из файла.',
                'auto_recovery' => true,
                'auto_recovery_text' => 'Панель продолжает обработку с учётом фактического домена.',
                'human_action' => 'none',
                'human_action_text' => 'Дополнительных действий не требуется, если последующая проверка проходит успешно.',
                'technical_code' => 'config_domain_drift',
            ]);
        }
        if ($has(['sub_id_drift', 'sub_id drift', 'sub id drift'])) {
            $persistFail = $has(['persist', 'не удалось сохранить', 'sub_id failed']);
            return self::base([
                'severity' => $persistFail ? 'error' : 'info',
                'source' => $persistFail ? 'panel' : 'site',
                'source_confidence' => 'confirmed',
                'title' => 'Другой идентификатор партнёрской ссылки (sub_id) в config.php',
                'reason' => 'В config.php найден другой идентификатор партнёрской ссылки (sub_id), чем был сохранён при запуске. Панель взяла фактическое значение из файла и пересчитала новый sub_id.'
                    . ($persistFail ? ' Пересчитанное значение не удалось сохранить в базе.' : ''),
                'impact' => $persistFail ? 'Этап остановлен до ручной проверки; файлы сайта дальше не изменяются.' : 'Ничего не заблокировано.',
                'safety' => $persistFail ? 'Файлы сайта не изменялись.' : 'Обработка продолжается по фактическому значению.',
                'auto_recovery' => !$persistFail,
                'auto_recovery_text' => $persistFail ? '' : 'Панель продолжает обработку с пересчитанным sub_id.',
                'human_action' => $persistFail ? 'required' : 'none',
                'human_action_text' => $persistFail ? 'Проверьте доступность базы данных и состояние джобы.' : '',
                'technical_code' => 'sub_id_drift',
            ]);
        }

        // ── REDIRECT ─────────────────────────────────────────────────────────
        if ($stage === 'redirect_enable' || $stage === 'redirect_disable' || $has(['refresh-disabled', 'redirect_read_back', 'redirect_enabled_stage', 'редирект'])) {
            $isEnable = ($stage === 'redirect_enable') || $has(['включ', 'enable']);
            $isDisable = ($stage === 'redirect_disable') || $has(['отключ', 'disable']);
            $failed = $has(['read_back', 'read-back', 'не смогл', 'не подтверд', 'not enabled', 'failed', 'семантически']);
            if ($isEnable && $failed) {
                return self::base([
                    'severity' => 'error', 'source' => 'hosting', 'source_confidence' => 'likely',
                    'title' => 'Не удалось подтвердить включение редиректа',
                    'reason' => 'Панель попыталась включить редирект и перечитала config.php с сервера, но не смогла подтвердить, что настройка действительно включена.',
                    'impact' => 'Этап не считается успешным; следующие этапы не запускаются.',
                    'safety' => 'Успех по факту отправки файла не засчитывается.',
                    'auto_recovery' => false,
                    'human_action' => 'required',
                    'human_action_text' => 'Проверьте настройку редиректа в config.php на сервере (и доступность FTP).',
                    'technical_code' => 'redirect_readback_failed',
                ]);
            }
            if ($isDisable) {
                return self::base([
                    'severity' => 'info', 'source' => 'panel', 'source_confidence' => 'confirmed',
                    'title' => 'Редирект временно отключён',
                    'reason' => 'Редирект временно отключён на время перевыставления сайта.',
                    'impact' => 'Ничего не заблокировано.', 'safety' => 'Плановое действие.',
                    'auto_recovery' => false, 'human_action' => 'none',
                    'technical_code' => 'redirect_disabled',
                ]);
            }
            if ($isEnable) {
                return self::base([
                    'severity' => 'info', 'source' => 'panel', 'source_confidence' => 'confirmed',
                    'title' => 'Редирект снова включён',
                    'reason' => 'Редирект снова включён и подтверждён повторным чтением конфигурации.',
                    'impact' => 'Ничего не заблокировано.', 'safety' => 'Подтверждено read-back.',
                    'auto_recovery' => false, 'human_action' => 'none',
                    'technical_code' => 'redirect_enabled',
                ]);
            }
        }

        // ── DNS / SSL ────────────────────────────────────────────────────────
        if ($has(['getaddrinfo', 'php_network_getaddresses', 'name or service not known', 'could not resolve', 'temporary failure in name resolution', 'no_connection', 'не разрешается'])) {
            return self::base([
                'severity' => 'info', 'source' => 'network_dns', 'source_confidence' => 'likely',
                'title' => 'Домен ещё не разрешается через DNS',
                'reason' => 'Новый домен пока не определяется в DNS. Это нормально сразу после регистрации или изменения DNS.',
                'impact' => 'Ничего не сломано — идёт ожидание распространения DNS.',
                'safety' => 'Это не ошибка панели и не ошибка сайта.',
                'auto_recovery' => true,
                'auto_recovery_text' => 'Панель продолжает автоматические проверки.',
                'human_action' => 'none',
                'wait_state' => 'deadline',
                'technical_code' => 'dns_not_resolving',
            ]);
        }
        if ($has(['self-signed', 'self_signed', 'ssl_self_signed', 'самоподписан', 'временный сертификат'])) {
            return self::base([
                'severity' => 'info', 'source' => 'external_service', 'source_confidence' => 'confirmed',
                'title' => 'Установлен временный самоподписанный сертификат',
                'reason' => 'На новый домен временно установлен самоподписанный сертификат — промежуточный этап, пока выпускается доверенный SSL-сертификат.',
                'impact' => 'Ничего не заблокировано.',
                'safety' => 'Плановый промежуточный этап.',
                'auto_recovery' => true,
                'auto_recovery_text' => 'Панель продолжит выпуск доверенного сертификата автоматически.',
                'human_action' => 'none',
                'technical_code' => 'ssl_self_signed',
            ]);
        }
        if (($has(['ssl_le_polling', 'ssl_reconciler', "let's encrypt", 'le pending', 'сертификат ещё выпуск', 'ssl pending', 'issuance']) && !$has(['выпущен и применён', 'issued']))) {
            return self::base([
                'severity' => 'info', 'source' => 'external_service', 'source_confidence' => 'likely',
                'title' => 'Доверенный SSL-сертификат ещё выпускается',
                'reason' => 'На домене пока установлен временный сертификат; доверенный сертификат ещё не готов (выпуск через FastPanel / Let\'s Encrypt / DNS).',
                'impact' => 'Ничего не сломано — идёт контролируемое ожидание.',
                'safety' => 'Это не критично.',
                'auto_recovery' => true,
                'auto_recovery_text' => 'Панель автоматически проверяет готовность сертификата.',
                'human_action' => 'none',
                'wait_state' => 'deadline',
                'technical_code' => 'ssl_pending',
            ]);
        }

        // ── FTP ──────────────────────────────────────────────────────────────
        if ($has(['config_read_failed', 'ftp_connect_failed', 'config_read failed']) || ($has(['ftp', 'config.php']) && $has(['read', 'прочитать', 'fetch', 'download']))) {
            return self::base([
                'severity' => 'error', 'source' => 'hosting', 'source_confidence' => 'likely',
                'title' => 'Не удалось прочитать config.php с сервера',
                'reason' => 'Панель не смогла получить файл config.php с сервера сайта (FTP/сеть).',
                'impact' => 'Этап остановлен; последующие действия не выполняются.',
                'safety' => 'Без чтения файла изменение не считается подтверждённым.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте доступность FTP и права на файл или каталог.',
                'technical_code' => 'ftp_read_failed',
            ]);
        }
        if (($has(['ftp', 'upload', 'записать', 'write']) && $has(['config.php', 'config'])) && $has(['fail', 'не смог', 'ошибк', 'error'])) {
            return self::base([
                'severity' => 'error', 'source' => 'hosting', 'source_confidence' => 'likely',
                'title' => 'Не удалось записать config.php на сервер',
                'reason' => 'Панель не смогла записать подготовленный config.php на сервер сайта (FTP/сеть).',
                'impact' => 'Этап остановлен; последующие действия не выполняются.',
                'safety' => 'Изменение не подтверждено.',
                'auto_recovery' => false,
                'human_action' => 'required',
                'human_action_text' => 'Проверьте доступность FTP и права на файл или каталог.',
                'technical_code' => 'ftp_write_failed',
            ]);
        }

        return null;
    }

    /** Generic fallback (§6/§14): неизвестный код — по уровню, источник не установлен. */
    private static function generic(string $stage, string $level): array
    {
        $lvl = in_array($level, ['error', 'fail', 'failed'], true) ? 'error'
             : (in_array($level, ['warn', 'warning'], true) ? 'warning' : 'info');
        if ($lvl === 'error') {
            return self::base([
                'severity' => 'error', 'source' => 'unknown', 'source_confidence' => 'unknown',
                'title' => 'Техническая ошибка этапа',
                'reason' => 'На этом этапе произошла техническая ошибка. Точная причина пока не установлена — панель сохранила диагностические данные.',
                'impact' => 'Этап остановлен и не считается выполненным.',
                'safety' => 'Дальнейшие действия по этой джобе не выполняются автоматически.',
                'auto_recovery' => false,
                'human_action' => 'maybe',
                'human_action_text' => 'Откройте технические детали и проверьте исходное сообщение об ошибке.',
                'technical_code' => 'unknown_stage_error',
            ]);
        }
        if ($lvl === 'warning') {
            return self::base([
                'severity' => 'warning', 'source' => 'unknown', 'source_confidence' => 'unknown',
                'title' => 'Обнаружена проблема на этапе',
                'reason' => 'На этом этапе обнаружена проблема. Точная причина пока не установлена.',
                'impact' => 'Панель пока продолжает безопасную проверку.',
                'safety' => 'Опасные действия не выполнялись.',
                'auto_recovery' => true,
                'auto_recovery_text' => 'Панель продолжает безопасную проверку.',
                'human_action' => 'none',
                'technical_code' => 'unknown_stage_warning',
            ]);
        }
        return self::base([
            'severity' => 'info', 'source' => 'panel', 'source_confidence' => 'confirmed',
            'title' => 'Событие этапа',
            'reason' => 'Штатное событие обработки джобы.',
            'impact' => 'Ничего не заблокировано.', 'safety' => '',
            'auto_recovery' => false, 'human_action' => 'none',
            'technical_code' => 'stage_event',
        ]);
    }

    /**
     * §14: только реальные данные. next_run_at (UTC ISO) → «ДД.ММ.ГГГГ ЧЧ:ММ МСК».
     * @return array{0:?string,1:string} [next_retry_at_display, wait_text]
     */
    private static function resolveWait(array $d, array $payload): array
    {
        $state = (string)($d['wait_state'] ?? 'no_wait');
        $nextRaw = (string)($payload['next_run_at'] ?? '');
        $nextDisp = $nextRaw !== '' ? self::formatMsk($nextRaw) : null;

        // Автовосстановление с известным next_run_at — это тоже ожидание (§14: реальное время).
        if ($state === 'no_wait' && !empty($d['auto_recovery']) && $nextDisp !== null) {
            $state = 'waiting';
        }
        if ($state === 'no_wait') return [$nextDisp, ''];

        // attempts (если переданы) — честная формулировка «ещё N попыток»
        $attempt = isset($payload['attempt']) ? (int)$payload['attempt'] : null;
        $maxAtt  = isset($payload['max_attempts']) ? (int)$payload['max_attempts'] : null;
        $left = ($attempt !== null && $maxAtt !== null && $maxAtt >= $attempt) ? ($maxAtt - $attempt) : null;

        $parts = [];
        if ($nextDisp !== null) {
            $parts[] = 'Следующая автоматическая проверка запланирована на ' . $nextDisp . '.';
        } else {
            $parts[] = 'Следующая проверка — при ближайшем запуске обработчика.';
        }
        if ($left !== null && $left > 0) {
            $parts[] = 'Панель выполнит ещё ' . $left . ' ' . self::plural($left, 'автоматическую попытку', 'автоматические попытки', 'автоматических попыток') . '. После их исчерпания потребуется вмешательство.';
        }
        return [$nextDisp, implode(' ', $parts)];
    }

    /** UTC ISO/'Y-m-d H:i:s' → московское время для отображения. */
    private static function formatMsk(string $utc): ?string
    {
        try {
            $dt = new \DateTime($utc, new \DateTimeZone('UTC'));
            $dt->setTimezone(new \DateTimeZone('Europe/Moscow'));
            return $dt->format('d.m.Y H:i') . ' МСК';
        } catch (\Throwable $e) {
            return null;
        }
    }

    private static function plural(int $n, string $one, string $few, string $many): string
    {
        $n = abs($n) % 100; $n1 = $n % 10;
        if ($n > 10 && $n < 20) return $many;
        if ($n1 > 1 && $n1 < 5) return $few;
        if ($n1 === 1) return $one;
        return $many;
    }
}
