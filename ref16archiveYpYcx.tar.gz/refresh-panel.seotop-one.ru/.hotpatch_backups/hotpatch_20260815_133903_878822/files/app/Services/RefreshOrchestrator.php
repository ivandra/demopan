<?php

/**
 * Оркестратор стадий перевыставления.
 *
 * Главный конечный автомат. Принимает запись из refresh_jobs и
 * двигает её через стадии:
 *
 *   queued → domain_purchasing → done
 *
 * v13a поддерживает только эти стадии. Остальные стадии (Этапы 3-7)
 * добавим в следующих патчах.
 *
 * Как использовать:
 *   $orch = new RefreshOrchestrator();
 *   $orch->step($job); // проигрывает один шаг (вызывается из cron)
 *
 * Конвенции:
 *  - stage_status='pending' — стадия начата, но воркер ещё не подхватил
 *  - stage_status='running' — воркер сейчас выполняет
 *  - stage_status='ok' — стадия завершена успешно (cron подхватит и
 *    переведёт в следующую стадию)
 *  - stage_status='failed' — стадия упала, нужен retry или ручное вмешательство
 *
 * Список всех возможных стадий зафиксирован в комменте миграции 001.
 */
class RefreshOrchestrator
{
    /** Список стадий по порядку. queued — старт, done — финиш. */
    public const STAGES_ORDER = [
        'queued',
        'domain_purchasing',
        'aliases_added',
        'ssl_self_signed_first',
        'redirect_disable',         // v18-fix: отключаем партнёрский редирект во ВСЕХ режимах перед verify (refresh+move)
        'analyze_site',
        'config_replaced',
        'verify_replacement',
        // v18.1: ssl_le_polling — теперь ОПЦИОНАЛЬНАЯ стадия (зависит от sites_managed.ssl_le_enabled)
        // pipelineStagesFor() и nextStageFor() пропускают её если ssl_le_enabled = 0
        'ssl_le_polling',
        'update_classes_call',      // v16 — вызов рандома классов (если есть)
        // v18.1: redirect_enable теперь ДО wm_* секции
        // (раньше был после index_watching). Это позволяет sitemap.xml/robots.txt
        // отдаваться правильно когда Webmaster их запрашивает (с включённым редиректом
        // partner-link guard в guard.php их не перехватывает).
        'redirect_enable',
        // v18.1.10: move_htaccess_redirect перенесён ВПЕРЁД — сразу после redirect_enable.
        // Только для move-режимов. Это нужно чтобы 301 со старого на новый стоял
        // ДО того как мы заявляемся в Webmaster. Без этого Yandex отклоняет заявку
        // на склейку зеркал с "redirect not found".
        'move_htaccess_redirect',   // move only: 301 со старого на новый
        // === P0 (ssl_before_webmaster_v1): обязательный gate публичного доверенного SSL
        // ПЕРЕД любым Yandex Webmaster. Реальная публичная TLS-проверка
        // https://<new_domain>:443 (verify_peer + verify_peer_name, без insecure).
        // До ok=true запрещены addHost/verifier/verification/recrawl/sitemap/robots.
        'trusted_ssl_gate',
        // === v17 Yandex.Webmaster (порядок изменён в v18.1) ===
        'wm_account_resolve',       // определяем аккаунт по старому домену
        'wm_added',                 // добавляем новый домен в Webmaster
        'wm_verified',              // HTML_FILE верификация через FTP
        // v18.1: новый порядок Webmaster — recrawl ДО sitemap
        // (recrawl с $pages из config.php — приоритет; sitemap уже включает recrawl URL'ы)
        'wm_recrawl',               // v18.1: запрашиваем переобход URL (включая $pages для 7k шаблона)
        'wm_sitemap',               // загружаем sitemap (refresh, move_indexed)
        'wm_robots',                // v18: подтверждаем robots.txt в Webmaster (refresh, move_indexed)
        'index_watching',           // ждём появления в индексе (ТОЛЬКО refresh с v18.1.23)
        // === v18 Move-режимы (move_htaccess_redirect выше) ===
        'move_submit_request',      // v18: awaiting_user — юзер сам подаёт заявку в Webmaster
        'move_poll_status',         // v18: ждём main_mirror = новый (legacy с v18.1.23, заменён на final_monitoring)
        // === v18.1.23 объединённый финальный мониторинг для move ===
        // Проверяет ОДНОВРЕМЕННО (а) появление нового домена в индексе и
        // (б) main_mirror старого = новый. Завершается успехом при ЛЮБОМ из условий.
        // Используется вместо отдельных index_watching + move_poll_status для move-режимов.
        'final_monitoring',
        // === v18 Финальная стадия для refresh ===
        'old_delurl_notify',        // v18: TG-уведомление + awaiting_user (только refresh)
        'done',
    ];

    /**
     * Выполнить один шаг для джобы. Вызывается из cron-обработчика.
     */
    public function step(array $job): void
    {
        $jobId = (int)$job['id'];
        $log = new JobEventLogger($jobId);
        $stage = (string)$job['stage'];
        $status = (string)$job['stage_status'];

        // Терминальные стадии — пропускаем.
        // v24.2 (B2): единый источник правды — cancelled/superseded тоже
        // терминальны, иначе закрытая джоба, попавшая сюда по гонке
        // (выбрана до закрытия), продолжила бы внешние действия.
        if (JobLifecycleService::isTerminal($stage)) return;

        // v18.1: enrich job с ssl_le_enabled из sites_managed (для nextStage пропуска LE).
        // Если cron уже сджойнил sites_managed (CronController может) — не ходим в БД.
        if (!array_key_exists('_ssl_le_enabled', $job)) {
            $job['_ssl_le_enabled'] = $this->loadSslLeEnabledForJob($job);
        }

        // P0 (ssl_before_webmaster_v1, §4.3): ленивая активация новой revision для
        // существующих нетерминальных джоб, которые ещё НЕ вошли в Webmaster-контур
        // и не имеют Webmaster-артефактов. Джобы уже в wm_* (или дальше) — legacy,
        // назад не откатываются. Терминальные не изменяются (отсеяны выше).
        $job = $this->maybeAdoptSslRevision($job, $log);

        $this->stepInternal($job, $log);
    }

    /**
     * v18.1: внутренняя реализация step(), отделена от публичной чтобы из неё
     * можно было рекурсивно вызывать chain instant-stages в одном cron-тике.
     *
     * Не вызывайте напрямую — используйте step().
     */
    /**
     * ТЗ044 §5 — вернуть true, если переход со стадии разрешён. При нарушении инварианта
     * выполнить bounded self-heal (вернуть на analyze_site/pending, max 1 авто-пересборка),
     * либо остановить в awaiting_user. FTP write здесь не производится.
     */
    private function enforceStageInvariant(int $jobId, string $stage, array $job, JobEventLogger $log): bool
    {
        $artifacts = [];
        if (!empty($job['artifacts_json'])) $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];

        $res = StageInvariantGuard::checkAdvance($stage, $job, $artifacts);
        if (!empty($res['ok'])) return true;

        $violation = (string)($res['violation'] ?? 'invariant_violation');

        // analyze_site / config_replaced с отсутствующим/битым planом → bounded self-heal в analyze.
        if ($stage === 'analyze_site' || $stage === 'config_replaced') {
            $rec = $artifacts['pipeline_recovery'] ?? [];
            $attempts = (int)($rec['analyze_missing_plan_attempts'] ?? 0);
            $maxAttempts = 1; // ТЗ §5.1: максимум 1 авто-recovery
            if ($attempts < $maxAttempts) {
                $rec['analyze_missing_plan_attempts'] = $attempts + 1;
                $rec['last_violation'] = $violation;
                $rec['last_recovery_at'] = gmdate('c');
                $artifacts['pipeline_recovery'] = $rec;
                // очистить возможный неполный plan
                unset($artifacts['replacement_plan']);
                try {
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET stage='analyze_site', stage_status='pending',
                            stage_error=NULL, next_run_at=NULL, artifacts_json=?
                         WHERE id=? AND stage NOT IN ('cancelled','superseded')"
                    )->execute([json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
                } catch (\Throwable $e) { /* не блокируем */ }
                $log->warn('analyze_site',
                    "Pipeline invariant восстановлен: стадия '{$stage}' помечена ok, но контракт нарушен ({$violation}). "
                    . "Возвращаю на analyze_site для одной безопасной пересборки. FTP write=0. "
                    . "Попытка recovery #" . ($attempts + 1) . "/{$maxAttempts}.");
                return false;
            }
            // лимит исчерпан → awaiting_user (без loop, без fail-spam)
            $this->setStatusAwaitingUser($jobId,
                "Стадия остановлена: не удалось безопасно собрать replacement_plan (нарушение: {$violation}). "
                . "Автоматическая пересборка исчерпана. Нужно решение оператора. FTP write=0.");
            return false;
        }

        // прочие инварианты (config_replaced read-back / redirect) → awaiting_user, без перехода
        $this->setStatusAwaitingUser($jobId,
            "Переход со стадии '{$stage}' заблокирован инвариантом ({$violation}). Стадия не считается выполненной.");
        $log->warn($stage, "Invariant guard заблокировал переход: {$violation}.");
        return false;
    }

    private function stepInternal(array $job, JobEventLogger $log, int $chainDepth = 0): void
    {
        $jobId = (int)$job['id'];
        $stage = (string)$job['stage'];
        $status = (string)$job['stage_status'];

        // Терминальные стадии (v24.2/B2: включая cancelled/superseded)
        if (JobLifecycleService::isTerminal($stage)) return;

        // Если предыдущий шаг был ok — переводим на следующую стадию
        if ($status === 'ok') {
            // ТЗ044 §5: server-side invariant guard ПЕРЕД переходом ok → nextStage.
            // Даже если 'ok' выставлен контроллером/ручным SQL — при нарушенном
            // postcondition переход запрещён (bounded self-heal вместо перехода).
            if (!$this->enforceStageInvariant($jobId, $stage, $job, $log)) return;

            $next = $this->nextStage($stage, $job);
            if ($next === null) {
                // Последняя стадия выполнена ok → джоба завершена
                $this->markJobDone($jobId, $log, $job);
                return;
            }
            $this->setStage($jobId, $next, 'pending');
            $log->info($next, "Переход на стадию: {$next}" .
                ($chainDepth > 0 ? " [chain depth={$chainDepth}]" : ''));

            // v18.1: если новая стадия instant — продолжаем chain.
            // Иначе ждём следующий cron-тик.
            if (in_array($next, self::INSTANT_STAGES, true) && $chainDepth < 15) {
                $job['stage'] = $next;
                $job['stage_status'] = 'pending';
                $this->stepInternal($job, $log, $chainDepth + 1);
            }
            return;
        }

        // Если уже running → не трогаем, другой воркер этим занят
        // (защита через GET_LOCK в CronGuard, но на всякий случай)
        if ($status === 'running') {
            return;
        }

        // failed — ждём retry от пользователя
        if ($status === 'failed') return;

        // awaiting_user — стадия остановлена и ждёт ручного вмешательства.
        //
        // v18-fix: исключение — если у джобы установлен next_run_at в прошлом,
        // это retry-цикл (например verify_replacement делает 5 попыток
        // с прогрессивным backoff, между попытками статус 'awaiting_user'
        // чтобы UI показывал блок "Джоба ждёт" с возможностью оператора
        // прервать). Cron подхватил → значит время retry пришло.
        // Переводим в pending и запускаем stage заново.
        //
        // v18.1.6: ограничиваем retry pickup ТОЛЬКО verify_replacement
        // (единственная стадия которая использует этот механизм). Раньше
        // это работало для любого awaiting_user с next_run_at — и привело
        // к бесконечному циклу + спаму TG в случае index_watching, потому
        // что setStatusAwaitingUser не сбрасывал next_run_at от polling-тиков.
        if ($status === 'awaiting_user') {
            $nextRunAt = $job['next_run_at'] ?? null;
            $isRetry = ($nextRunAt !== null && $nextRunAt !== '' && strtotime($nextRunAt) <= time());
            if (!$isRetry) {
                return; // ждёт юзера навсегда
            }

            // v18.1.6: whitelist — только verify_replacement использует retry-pickup
            $retryPickupAllowed = ($stage === 'verify_replacement');
            if (!$retryPickupAllowed) {
                // Защита: если другая стадия попала сюда с next_run_at в прошлом
                // (значит баг — кто-то забыл сбросить next_run_at в setStatusAwaitingUser),
                // НЕ запускаем её повторно. Сбрасываем next_run_at чтобы cron больше
                // не подхватывал её, и логируем для диагностики.
                $log->warn($stage,
                    "Защита от retry-spam: стадия '{$stage}' в awaiting_user с next_run_at в прошлом, " .
                    "но эта стадия не должна retry-pickup'аться. Сбрасываю next_run_at, ждём оператора.");
                try {
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET next_run_at = NULL WHERE id = ?"
                    )->execute([$jobId]);
                } catch (\Throwable $e) {
                    // не блокируем
                }
                return;
            }

            // retry-time пришло, продолжаем как pending
            $log->info($stage,
                "Auto-retry pickup (был awaiting_user с next_run_at в прошлом)");
            $status = 'pending';
        }

        // pending → запускаем стадию
        if ($status === 'pending') {
            $this->setStatus($jobId, 'running', 'stage_started_at');
            try {
                $this->runStage($job, $stage, $log);
                // если runStage не выкинул исключение — статус поставит
                // соответствующий handler через setStatus(...,'ok')
            } catch (\Throwable $e) {
                $errMsg = $e->getMessage();
                $log->error($stage, "Исключение: {$errMsg}");
                $this->setStatusFailed($jobId, $errMsg);
                return;
            }

            // v18.1 chain: если стадия только что ушла в 'ok' и следующая стадия
            // ИНСТАНТНАЯ (быстрая, не требует ожидания) — сразу выполняем её в том же
            // cron-тике без ожидания следующего такта. Так за один тик пройдёт ~10
            // быстрых стадий (~1-2 минуты вместо 20+).
            //
            // Защита от бесконечного цикла: $chainDepth ≤ 15.
            // Не chain'им если после runStage статус стал НЕ 'ok' (failed,
            // awaiting_user, running — kто-то ещё работает).
            if ($chainDepth >= 15) {
                $log->info($stage, "Chain limit reached (15 stages in one tick) — ждём следующий cron");
                return;
            }

            // Перечитываем job из БД — runStage мог поменять stage/stage_status/artifacts
            $freshJob = $this->reloadJob($jobId);
            if ($freshJob === null) return;
            // Сохраняем enrich (ssl_le_enabled) — он не в БД refresh_jobs
            $freshJob['_ssl_le_enabled'] = $job['_ssl_le_enabled'] ?? false;

            if ($freshJob['stage_status'] !== 'ok') {
                // Стадия не успешна (running/failed/awaiting_user) — chain не нужен
                return;
            }

            // ТЗ044 §5: тот же invariant guard и на chain-переходе после runStage()
            if (!$this->enforceStageInvariant($jobId, (string)$freshJob['stage'], $freshJob, $log)) return;

            // Переходим на следующую стадию
            $next = $this->nextStage($freshJob['stage'], $freshJob);
            if ($next === null) {
                // Pipeline закончен
                $this->markJobDone($jobId, $log, $freshJob);
                return;
            }

            $this->setStage($jobId, $next, 'pending');
            $log->info($next, "Переход на стадию: {$next}" .
                ($chainDepth > 0 ? " [chain depth={$chainDepth}]" : ''));

            // Если следующая стадия INSTANT — продолжаем chain в этом же тике
            if (in_array($next, self::INSTANT_STAGES, true)) {
                $freshJob['stage'] = $next;
                $freshJob['stage_status'] = 'pending';
                // Recursive call — следующая итерация сама проверит ok→next и т.д.
                $this->stepInternal($freshJob, $log, $chainDepth + 1);
            }
            // Иначе — стадия "медленная" (polling/awaiting_user). Возвращаемся,
            // следующий cron-тик подхватит её обычным порядком.
        }
    }

    /**
     * v18.1: список стадий которые "instant" — выполняются за секунды и не
     * требуют ожидания внешнего события. Их можно chain'ить в одном cron-тике.
     *
     * НЕ instant (НЕ chain'им):
     *   - domain_purchasing      — внешний API Namecheap может тормозить (10-30 сек)
     *   - aliases_added          — FastPanel API
     *   - ssl_self_signed_first  — FastPanel API
     *   - ssl_le_polling         — намеренно poll'ит (~1-3 мин)
     *   - index_watching         — намеренно ждёт индексации
     *   - move_poll_status       — намеренно poll'ит (часами/днями)
     *   - move_submit_request    — awaiting_user (ждёт оператора)
     *   - old_delurl_notify      — awaiting_user
     *
     * v18.1.10: move_htaccess_redirect добавлен в INSTANT_STAGES — он перенесён
     * сразу после redirect_enable, до webmaster секции, и должен пройти быстро в chain'е.
     */
    private const INSTANT_STAGES = [
        'redirect_disable',
        'analyze_site',
        'config_replaced',
        'verify_replacement',
        'update_classes_call',
        'redirect_enable',
        'move_htaccess_redirect',  // v18.1.10: chain после redirect_enable
        'wm_account_resolve',
        'wm_added',
        'wm_verified',
        'wm_recrawl',
        'wm_sitemap',
        'wm_robots',
    ];

    /**
     * v18.1: перечитать джобу из БД (после runStage).
     * Нужно чтобы chain видел актуальное состояние.
     */
    private function reloadJob(int $jobId): ?array
    {
        try {
            $st = DB::pdo()->prepare("SELECT * FROM refresh_jobs WHERE id = ?");
            $st->execute([$jobId]);
            $row = $st->fetch();
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Диспетчер стадий. Каждая стадия — свой handler.
     */
    /** v25.0-b1: фабрики для тестов recrawl (WM-клиент + submit-сервис). */
    private $wmClientFactory = null;
    private $recrawlSubmitFactory = null;
    public function setWmClientFactory(callable $f): void { $this->wmClientFactory = $f; }
    public function setRecrawlSubmitFactory(callable $f): void { $this->recrawlSubmitFactory = $f; }
    private $fileVerifierFactory = null;
    public function setFileVerifierFactory(callable $f): void { $this->fileVerifierFactory = $f; }
    protected function makeFileVerifier()
    {
        if ($this->fileVerifierFactory !== null) return ($this->fileVerifierFactory)();
        return new WebmasterFileVerifier();
    }
    private $httpProbeFactory = null;
    public function setHttpProbeFactory(callable $f): void { $this->httpProbeFactory = $f; }
    protected function makeHttpProbe()
    {
        if ($this->httpProbeFactory !== null) return ($this->httpProbeFactory)();
        return new CurlHttpProbe();
    }
    /**
     * PATCH 047 revision §5(B): найти исходное WebmasterTransportException в цепочке
     * getPrevious() (клиенты оборачивают его в RuntimeException для совместимости).
     */
    protected function findWebmasterTransportException(\Throwable $e): ?WebmasterTransportException
    {
        return WebmasterRoutingFailurePolicy::extract($e);
    }

    /**
     * PATCH 047 revision §6: единая политика fail-closed на уровне pipeline.
     * Для reasons source_ip_mismatch/bind_failed/resolve_failed/unexpected_redirect:
     * НЕ ok, НЕ продолжать pipeline, НЕ temporary-retry, ERROR+Telegram, awaiting_user,
     * next_run_at=NULL, без fallback. Возвращает true, если стадия остановлена этим методом.
     * network_timeout и прочее → false (обычная транзиентная обработка, тот же IP).
     */
    protected function stopIfWmRoutingFatal(\Throwable $e, int $jobId, JobEventLogger $log, int $accountId, string $stage): bool
    {
        $te = $this->findWebmasterTransportException($e);
        if ($te === null) return false;
        $reason = $te->getReason();
        if (!in_array($reason, WebmasterRoutingFailurePolicy::CRITICAL_REASONS, true)) return false;

        $res = $te->getResult();
        $expected = (string)($res['expected_outbound_ip'] ?? '');
        $actual = (string)($res['actual_local_ip'] ?? '');
        $this->applyWmRoutingCriticalStop($jobId, $log, $stage, $accountId, $reason, $te->getMessage(), $expected, $actual);
        return true;
    }

    /**
     * PATCH 047 revision 2: единый критический стоп маршрутизации (awaiting_user + next_run_at
     * NULL + ERROR event + Telegram). Используется и из stopIfWmRoutingFatal (по исключению),
     * и из вложенных сервисов, вернувших structured 'routing_error' (напр. MoveStatusChecker).
     */
    protected function applyWmRoutingCriticalStop(int $jobId, JobEventLogger $log, string $stage,
        int $accountId, string $reason, string $message, string $expected = '', string $actual = ''): void
    {
        $this->notifyWmRoutingFailure($jobId, $log, $stage, $accountId, $reason, $message);
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error=?, next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                mb_substr("webmaster routing {$reason}"
                    . ($expected !== '' ? " expected={$expected}" : '')
                    . ($actual !== '' ? " actual={$actual}" : ''), 0, 500),
                $jobId,
            ]);
        } catch (\Throwable $ignore) { /* лог уже записан */ }
    }

    protected function makeWmClient(int $accountId)
    {
        if ($this->wmClientFactory !== null) return ($this->wmClientFactory)($accountId);
        return new YandexWebmasterClient($accountId);
    }

    /**
     * PATCH 047 §35/§36/§42: привязать контекст (job/stage) к клиенту для аудита и
     * записать в пользовательский лог, через какой исходящий IP пойдёт стадия
     * (жёсткая привязка). Best-effort: реальный fail-closed выполняет transport.
     * @return ?string ожидаемый IP (или null, если resolver уже сигналит проблему).
     */
    protected function emitWmRouting($client, JobEventLogger $log, int $accountId, int $jobId, string $stage): ?string
    {
        if (is_object($client) && method_exists($client, 'setRequestContext')) {
            // §10/§11: передаём логгер — клиент сам эмитит routing_verified ПОСЛЕ первого
            // реального успешного запроса (когда CURLINFO_LOCAL_IP===expected подтверждён).
            try { $client->setRequestContext($jobId, $stage, $log); } catch (\Throwable $e) {
                try { $client->setRequestContext($jobId, $stage); } catch (\Throwable $e2) { /* ignore */ }
            }
        }
        try {
            $resolved = (new WebmasterOutboundIpResolver())->resolveForAccount($accountId);
            $srcWord = $resolved['source'] === 'default' ? 'DEFAULT' : 'назначенный';
            // §10: это ВЫБОР маршрута (настройка), НЕ доказательство. Proof — только routing_verified.
            $log->info($stage,
                "Yandex.Webmaster · аккаунт #{$accountId} · исходящий IP {$resolved['ip_address']} ({$srcWord}) · "
                . "жёсткая привязка. Следующий запрос будет привязан к этому адресу.",
                ['event_code' => 'webmaster.routing_selected']);
            return $resolved['ip_address'];
        } catch (WebmasterTransportException $e) {
            $this->notifyWmRoutingFailure($jobId, $log, $stage, $accountId, $e->getReason(), $e->getMessage());
            return null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * PATCH 047 §37/§38/§41: критическая ошибка маршрутизации Webmaster — понятный лог
     * + Telegram (ТОЛЬКО для критического набора: mismatch/bind/assigned_disabled/default_missing/multiple_default).
     */
    protected function notifyWmRoutingFailure(int $jobId, JobEventLogger $log, string $stage, int $accountId, string $reason, string $message): void
    {
        $eventCode = ($reason === 'bind_failed') ? 'webmaster.bind_failed' : 'webmaster.source_ip_mismatch';
        // §41: error-уровень автоматически уходит в Telegram через JobEventLogger::notifyTg
        // (для критического набора причин: mismatch/bind/resolve_failed). Дополнительный
        // отдельный канал не нужен — это единый механизм алертинга панели.
        $log->error($stage,
            "🚨 Критическая ошибка маршрутизации Webmaster (аккаунт #{$accountId}): {$message}. "
            . "Операция Yandex остановлена. Fallback на другой IP НЕ выполнялся. Технический код: {$reason}.",
            ['event_code' => $eventCode, 'technical_reason' => $reason]);
    }

    protected function makeRecrawlSubmit()
    {
        if ($this->recrawlSubmitFactory !== null) return ($this->recrawlSubmitFactory)();
        return new RecrawlSubmitService();
    }

    /**
     * v25.0-a1: фабрика сервиса покупки — переопределяется в тестах, чтобы
     * подставить фейковый результат tryPurchase без реальных вызовов Namecheap.
     */
    protected function makePurchaseService()
    {
        return new DomainPurchaseService();
    }

    /* ═══ PATCH_6 (P0.1): фабрики ВСЕХ внешних сервисов — offline-харнесс подменяет
       адаптеры, но сами production stage-handler'ы выполняются реальным кодом.
       В production фабрики возвращают настоящие сервисы (поведение не меняется). ═══ */
    protected $extFactories = [];
    public function setExtFactory(string $key, callable $f): void { $this->extFactories[$key] = $f; }
    private function extMake(string $key, array $args, callable $default)
    {
        if (isset($this->extFactories[$key])) return ($this->extFactories[$key])(...$args);
        return $default();
    }
    protected function makeAliasService()            { return $this->extMake('alias', [],   fn() => new AliasService()); }
    protected function makeSslIssuerService()        { return $this->extMake('ssl', [],     fn() => new SslIssuerService()); }
    protected function makeTelegramService()         { return $this->extMake('telegram', [],fn() => new TelegramService()); }
    protected function makeWmHostPollingService()    { return $this->extMake('wmpoll', [],  fn() => new WmHostPollingService()); }
    protected function makeBalanceCheckService()     { return $this->extMake('balance', [], fn() => new BalanceCheckService()); }
    protected function makeDomainReadinessService()  { return $this->extMake('readiness', [],fn() => new DomainReadinessService()); }
    protected function makeSiteWebmasterMappingService() { return new SiteWebmasterMappingService(); /* DB-backed, реальный */ }
    protected function makeFtp(string $host, string $user, string $pass, array $opts = [])
    {
        return $this->extMake('ftp', [$host, $user, $pass, $opts], fn() => new FtpService($host, $user, $pass, $opts));
    }

    /** v25.0-a1: тест-обёртка для прямого прогона одной стадии. */
    public function runStageForTest(array $job, string $stage, JobEventLogger $log): void
    {
        $this->runStage($job, $stage, $log);
    }

    /** PATCH_5: protected — тест-наследник может фейкать внешние стадии (guarded seam, prod-путь без изменений). */
    protected function runStage(array $job, string $stage, JobEventLogger $log): void
    {
        switch ($stage) {
            case 'queued':
                // Стадия queued — это просто старт. Сразу ok.
                $log->ok('queued', 'Джоба в очереди, начинаем покупку домена');
                $this->setStatus((int)$job['id'], 'ok', 'stage_finished_at');
                break;

            case 'domain_purchasing':
                $svc = $this->makePurchaseService();
                $result = $svc->tryPurchase($job, $log);
                if (!empty($result['ok'])) {
                    $this->setStatus((int)$job['id'], 'ok', 'stage_finished_at');
                } elseif (($result['reason'] ?? '') === 'batch_exhausted') {
                    // v18.1.31: батч закончился, но общий лимит не превышен —
                    // сохраняем last_checked в artifacts и продолжаем в следующем tick.
                    $jobId = (int)$job['id'];
                    $patch = ['domain_purchasing_stage' => [
                        'last_checked_domain' => (string)($result['last_checked_domain'] ?? ''),
                        'checked_total' => (int)($result['checked_total'] ?? 0),
                        'max_total' => (int)($result['max_total'] ?? 0),
                        'last_batch_at' => date('Y-m-d H:i:s'),
                    ]];
                    try {
                        DB::pdo()->prepare(
                            "UPDATE refresh_jobs SET
                                artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?),
                                stage_status = 'pending',
                                next_run_at = DATE_ADD(NOW(), INTERVAL 30 SECOND)
                             WHERE id = ?"
                        )->execute([
                            json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                            $jobId,
                        ]);
                    } catch (\Throwable $e) {
                        $log->warn($stage, 'Не удалось сохранить batch-state: ' . $e->getMessage());
                    }
                } elseif (!empty($result['state_already_persisted'])) {
                    // v25.0-a1 (B1): DomainPurchaseService уже сам выставил
                    // финальное состояние стадии (например awaiting_user при
                    // purchase_unknown — ТЗ §5.2). Оркестратор НЕ должен его
                    // перезаписывать в failed, иначе safety-механизм Namecheap
                    // (ожидание ручной/read-only проверки) немедленно ломается.
                    $log->info($stage, 'Состояние стадии установлено сервисом покупки: '
                        . (string)($result['reason'] ?? '') . ' — не переопределяю.');
                } else {
                    $reason = $result['reason'] ?? 'unknown';
                    $log->error($stage, "Покупка не удалась: {$reason}");
                    $this->setStatusFailed((int)$job['id'], "domain_purchasing failed: {$reason}");
                }
                break;

            case 'aliases_added':
                // v14a: реальное добавление алиасов в FastPanel
                $this->runAliasesStage($job, $log);
                break;

            case 'ssl_self_signed_first':
                // v14b: мгновенный self-signed на новый домен
                $this->runSslSelfSignedStage($job, $log);
                break;

            case 'redirect_disable':
                // v14f: отключаем редиректы перед изменениями
                $this->runRedirectDisableStage($job, $log);
                break;

            case 'analyze_site':
                // v14c: сканирование файлов сайта + построение плана замен
                $this->runAnalyzeStage($job, $log);
                break;

            case 'config_replaced':
                // v14c: применение плана замен через FTP с snapshot'ами
                $this->runReplaceStage($job, $log);
                break;

            case 'verify_replacement':
                // v14c: HTTP-проверки. При провале → awaiting_user
                // v18.1.2: + 5-я проверка robots_php_logic (статический анализ файла)
                $this->runVerifyStage($job, $log);
                break;

            case 'redirect_enable':
                // v14f: включаем редиректы обратно
                $this->runRedirectEnableStage($job, $log);
                break;

            case 'ssl_le_polling':
                // v14b: multi-tick стадия — запрос и ожидание LE сертификата
                $this->runSslLeStage($job, $log);
                break;

            case 'update_classes_call':
                // v16: дёргаем update_classes.php (или кастомный URL) для рандома
                $this->runUpdateClassesCallStage($job, $log);
                break;

            // === v17 Yandex.Webmaster ===
            // === P0: обязательный публичный trusted-SSL gate перед Webmaster ===
            case 'trusted_ssl_gate':
                $this->runTrustedSslGateStage($job, $log);
                break;

            case 'wm_account_resolve':
                $this->runWmAccountResolveStage($job, $log);
                break;
            case 'wm_added':
                $this->runWmAddedStage($job, $log);
                break;
            case 'wm_verified':
                $this->runWmVerifiedStage($job, $log);
                break;
            case 'wm_sitemap':
                $this->runWmSitemapStage($job, $log);
                break;
            case 'wm_robots':
                $this->runWmRobotsStage($job, $log);
                break;
            case 'wm_recrawl':
                $this->runWmRecrawlStage($job, $log);
                break;
            case 'index_watching':
                $this->runIndexWatchingStage($job, $log);
                break;
            case 'wm_old_removed':
                $this->runWmOldRemovedStage($job, $log);
                break;

            // === v18 Move-режимы ===
            case 'move_htaccess_redirect':
                $this->runMoveHtaccessRedirectStage($job, $log);
                break;
            case 'move_submit_request':
                $this->runMoveSubmitRequestStage($job, $log);
                break;
            case 'move_poll_status':
                $this->runMovePollStatusStage($job, $log);
                break;

            // === v18.1.23 объединённый финальный мониторинг (move-режимы) ===
            case 'final_monitoring':
                $this->runFinalMonitoringStage($job, $log);
                break;

            // === v18 Финальная стадия refresh (заменяет wm_old_removed) ===
            case 'old_delurl_notify':
                $this->runOldDelurlNotifyStage($job, $log);
                break;

            // Старые placeholder'ы — на случай старых джоб
            case 'dns_configuring':
            case 'ssl_issuing':
            case 'update_called':
            case 'wm_robots_check':
                $log->warn($stage,
                    "Стадия '{$stage}' deprecated, пропускаю.");
                $this->setStatus((int)$job['id'], 'ok', 'stage_finished_at');
                break;

            default:
                throw new \RuntimeException("Unknown stage: {$stage}");
        }
    }

    /**
     * Handler стадии aliases_added (v14a).
     *
     * Берёт new_domain из job, добавляет в FP алиасы:
     *   - new_domain
     *   - www.new_domain
     *
     * Артефакты сохраняются в job.artifacts_json.aliases_stage.
     */
    private function runAliasesStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        if ($newDomain === '') {
            $log->error('aliases_added',
                'У джобы нет new_domain. Покупка домена не была завершена?');
            $this->setStatusFailed($jobId, 'aliases_added: new_domain is empty');
            return;
        }

        // v18.1.11: www-алиас больше НЕ создаётся (по запросу оператора).
        // Раньше добавляли в FastPanel оба имени: $newDomain и 'www.' . $newDomain.
        // Теперь только сам домен. Если нужен www-вариант — оператор добавит вручную
        // через UI FastPanel или через добавление алиаса в карточке сайта.
        $aliases = [
            $newDomain,
        ];

        $svc = $this->makeAliasService();
        try {
            $result = $svc->addAliases((int)$job['site_id'], $aliases, $log);
        } catch (\Throwable $e) {
            $log->error('aliases_added', 'Исключение: ' . $e->getMessage());
            $this->setStatusFailed($jobId, 'aliases_added exception: ' . $e->getMessage());
            return;
        }

        // Сохраняем результат в artifacts_json.aliases_stage
        try {
            $patch = ['aliases_stage' => [
                'before' => $result['aliases_before'] ?? [],
                'after' => $result['aliases_after'] ?? [],
                'added' => $result['aliases_added'] ?? [],
                'already_existed' => $result['aliases_already_existed'] ?? [],
                'ok' => !empty($result['ok']),
            ]];
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            // не критично — артефакты только для UI
            $log->warn('aliases_added', 'Не сохранил artifacts: ' . $e->getMessage());
        }

        if (empty($result['ok'])) {
            $reason = $result['reason'] ?? 'unknown';
            $log->error('aliases_added', "Не удалось добавить алиасы: {$reason}");
            $this->setStatusFailed($jobId, "aliases_added failed: {$reason}");
            return;
        }

        // v25.1-b1.2 (§2): автоматически добавить новый домен в SSL-мониторинг.
        // Домен куплен, alias/vhost создан, site_id/job_id известны — можно
        // отслеживать self-signed и выпуск trusted SSL, не дожидаясь readiness/WM.
        // Идемпотентно; не ломает pipeline при ошибке.
        try {
            $sslRepo = new DomainSslStatusRepository();
            $sslRepo->enrollDomain($newDomain, (int)$job['site_id'], $jobId, 'active_job', false);
            $log->info('aliases_added', "Домен добавлен в SSL-мониторинг: {$newDomain}");
        } catch (\Throwable $e) {
            $log->warn('aliases_added', 'SSL-enrolment не выполнен (не критично): ' . $e->getMessage());
        }

        // v25.2-a (§4): идемпотентно инициируем выпуск trusted SSL как фоновый
        // процесс. STAGES_ORDER не меняем — основной pipeline идёт дальше; SSL
        // Monitor отслеживает результат и разбудит джобу при переходе в trusted.
        // Не заказываем повторно, если уже запрошено/установлено.
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs
                    SET ssl_issue_requested_at = COALESCE(ssl_issue_requested_at, NOW())
                  WHERE id = ? AND ssl_issue_requested_at IS NULL"
            )->execute([$jobId]);
            $log->info('aliases_added', 'Инициирован фоновый выпуск trusted SSL (параллельно основному pipeline).');
        } catch (\Throwable $e) {
            // колонка 030 может отсутствовать до миграции — не критично
            $log->info('aliases_added', 'ssl_issue_requested_at не проставлен (миграция 030?): ' . $e->getMessage());
        }

        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    /**
     * Handler стадии analyze_site (v14c).
     *
     * 1. Сканирует корень сайта через FTP, скачивает файлы в /storage/scans/job_{N}/
     * 2. Строит план замен через ReplacementPlanBuilder
     * 3. Сохраняет план в artifacts_json.replacement_plan
     */
    private function runAnalyzeStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $oldDomain = (string)$job['old_domain'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        if ($newDomain === '') {
            $log->error('analyze_site', 'У джобы нет new_domain');
            $this->setStatusFailed($jobId, 'analyze_site: new_domain is empty');
            return;
        }

        // 1. Сканер
        $scanner = $this->makeScanner();
        try {
            $scanResult = $scanner->scanSite($siteId, $jobId, $log);
        } catch (\Throwable $e) {
            $log->error('analyze_site', 'Scanner exception: ' . $e->getMessage());
            $this->setStatusFailed($jobId, 'analyze_site scanner: ' . $e->getMessage());
            return;
        }

        if (empty($scanResult['ok'])) {
            $err = !empty($scanResult['errors']) ? implode('; ', $scanResult['errors']) : 'no files scanned';
            $log->error('analyze_site', "Не получилось проскать сайт: {$err}");
            $this->setStatusFailed($jobId, "analyze_site failed: {$err}");
            return;
        }

        // 1.5. v18-fix: Подчищаем старые .bak файлы (старше 7 дней) которые
        // оставались от прошлых джоб. До v18-fix applier'ы создавали:
        //   .htaccess.bak.refresh-panel_YYYYMMDD_HHMMSS
        //   .htaccess.bak_YYYYMMDD_HHMMSS
        // и они накапливались. Теперь applier'ы их не создают (backupExt=null),
        // но старые остаются — подчистим автоматически.
        $cleanupResult = $this->cleanupOldBackupFiles($scanResult, $jobId, $log);
        if (!empty($cleanupResult)) {
            // сохраняем сводку в артефактах analyze_stage для UI/диагностики
            $patchCleanup = ['analyze_stage' => ['backup_cleanup' => $cleanupResult]];
            try {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET
                        artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                     WHERE id = ?"
                )->execute([
                    json_encode($patchCleanup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $jobId,
                ]);
            } catch (\Throwable $e) {
                $log->warn('analyze_site', 'Cleanup-summary: не сохранил artifacts: ' . $e->getMessage());
            }
        }

        // 2. Builder
        // v4 (B5): параметры маски берём из НЕИЗМЕНЯЕМОГО snapshot'а джобы,
        // а не из текущего состояния БД — иначе смена настроек оператором
        // во время выполнения меняла бы поведение между стадиями.
        // v5 (P1): проверяем, что snapshot действительно есть и валиден.
        // Если нет — джоба останавливается, а не строит план по другим параметрам.
        try {
            MaskSnapshot::forJob($jobId, $log);
        } catch (\Throwable $e) {
            $log->error('analyze_site', 'Параметры маски недоступны: ' . $e->getMessage());
            $this->setStatusFailed($jobId, 'analyze_site mask: ' . $e->getMessage());
            return;
        }
        $maskSnapshotJson = (string)($job['artifacts_json'] ?? '');

        $snapshotOldSubId = (string)($job['old_sub_id'] ?? '');
        $snapshotNewSubId = (string)($job['new_sub_id'] ?? '');
        $maskSvc = MaskSnapshot::forJob($jobId, $log);

        // config.php обрабатывается ОТДЕЛЬНЫМ сервисом: prepare формирует полный
        // target-файл в памяти (домен, затем sub_id), проверяет его семантически ДО
        // FTP и сохраняет в закрытый storage (0600). Любое unsafe-решение scanner'а
        // останавливает джобу ДО любой записи (write=0).
        $prepared = $this->makeConfigMutationService($maskSvc)
            ->prepare($siteId, $jobId, $oldDomain, $newDomain);
        if (empty($prepared['ok'])) {
            $reason = (string)($prepared['reason'] ?? 'config_prepare_failed');
            $details = $prepared['details'] ?? null;
            // ТЗ044 §8: подробная диагностика (без секретов) в artifacts + понятная причина.
            $liveConfigDomain = '';
            if (is_array($details)) {
                foreach ($details as $d) {
                    if (is_string($d) && preg_match('~have=\'([^\']+)\'~', $d, $mm)) { $liveConfigDomain = $mm[1]; break; }
                }
            }
            $diag = [
                'reason' => $reason,
                'details' => is_array($details) ? array_slice($details, 0, 10) : ($details === null ? [] : [(string)$details]),
                'site_id' => $siteId,
                'job_old_domain' => $oldDomain,
                'live_config_domain' => $liveConfigDomain,
                'new_domain' => $newDomain,
                'old_sub_id' => (string)($job['old_sub_id'] ?? ''),
                'checked_at' => gmdate('c'),
            ];
            try {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id = ?"
                )->execute([json_encode(['analyze_stage' => ['config_prepare_failure' => $diag]],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
            } catch (\Throwable $e) { /* артефакт только для UI */ }

            $human = "Анализ config.php остановлен до записи.\n"
                . "В джобе старый домен: {$oldDomain}\n"
                . ($liveConfigDomain !== '' ? "В live config.php: {$liveConfigDomain}\n" : '')
                . "Target: {$newDomain}\n"
                . "Причина: " . ($reason === 'prepared_target_invalid' ? 'domain drift / target semantic mismatch' : $reason) . "\n"
                . "FTP write: 0";
            $log->warn('analyze_site', "config prepare: {$reason} → остановка до записи (write=0). " . str_replace("\n", ' ', $human));
            $this->setStatusAwaitingUser($jobId, $human);
            return;
        }
        $configMutation = $prepared['plan'];
        $oldSubId = (string)($configMutation['old_sub_id'] ?? '');
        $newSubId = (string)($configMutation['new_sub_id'] ?? '');
        $expectedConfigDomain = !empty($configMutation['expected']['domain_required']);

        if ($oldSubId !== '' && $oldSubId !== $snapshotOldSubId) {
            $log->warn('analyze_site',
                "sub_id_drift_detected: snapshot='{$snapshotOldSubId}' → live='{$oldSubId}'; new='{$newSubId}'.");
        }

        // Фиксируем пару в джобе (re-select-подтверждение внутри persistEffectiveSubId).
        if ($oldSubId !== $snapshotOldSubId || $newSubId !== $snapshotNewSubId) {
            if (!$this->persistEffectiveSubId($jobId, $oldSubId, $newSubId)) {
                $log->error('analyze_site', 'UPDATE old/new sub_id не подтверждён — стадия остановлена.');
                $this->setStatusAwaitingUser($jobId, 'analyze_site: persist sub_id failed');
                return;
            }
        }

        $builder = new ReplacementPlanBuilder($maskSnapshotJson);
        try {
            $plan = $builder->buildPlan(
                $scanResult['scan_dir'], $oldDomain, $newDomain, $log,
                $oldSubId, $newSubId
            );
        } catch (\Throwable $e) {
            $log->error('analyze_site', 'Builder exception: ' . $e->getMessage());
            $this->setStatusFailed($jobId, 'analyze_site builder: ' . $e->getMessage());
            return;
        }

        if (empty($plan['ok'])) {
            $err = !empty($plan['errors']) ? implode('; ', $plan['errors']) : 'no replacements';
            $log->error('analyze_site', "Не удалось построить план: {$err}");
            $this->setStatusFailed($jobId, "analyze_site builder failed: {$err}");
            return;
        }

        $repCount = count($plan['replacements']);
        if ($repCount === 0) {
            $log->warn('analyze_site',
                'План пуст — ни одной замены не найдено. Возможно, домен уже обновлён или шаблон сайта не распознан.');
            // Не ставим failed — может пользователь уже всё руками сделал.
            // Просто переходим дальше с пустым планом, applier ничего не сделает,
            // verifier проверит — и решит что делать.
        }

        // 3. Сохраняем артефакты. config.php обрабатывается ОТДЕЛЬНЫМ mutation
        //    pipeline (config_mutation: полный target-файл + source/target SHA +
        //    expected). Из generic replacements config.php ИСКЛЮЧАЕТСЯ (AC01).
        $genericReplacements = array_values(array_filter(
            $plan['replacements'],
            static fn(array $r): bool => basename((string)($r['file'] ?? '')) !== 'config.php'
        ));
        $patch = ['replacement_plan' => [
            'old_domain' => $plan['old_domain'],
            'new_domain' => $plan['new_domain'],
            'files_scanned' => $plan['files_scanned'] ?? 0,
            'replacements_count' => count($genericReplacements),
            'replacements' => $genericReplacements,
            'effective_old_sub_id'   => $oldSubId,
            'effective_new_sub_id'   => $newSubId,
            'expected_config_domain' => $expectedConfigDomain,
            'config_mutation' => $configMutation,
            'scan_dir' => $scanResult['scan_dir'],
            'site_root' => $scanResult['site_root'],
            'base_path' => $scanResult['base_path'] ?? null, // важно для applier-а на чрутнутых FTP
            'scan_files' => array_map(
                fn($info) => ['size' => $info['size'], 'kind' => $info['kind']],
                $scanResult['files']
            ),
        ]];

        // v18.1.24: детектим реальный redirect path из config.php/.htaccess/index.php/guard.php
        // и сохраняем результат в artifacts. Используется позже на стадии redirect_enable
        // для smoke-теста.
        // v18.1.35: добавлен config.php — самый достоверный источник ($promolink),
        // как в шаблонах 7k/olymp/mellstroy/fugu где path хранится явно.
        try {
            $detector = new RedirectPathDetector();
            $fileContents = [];
            $targetFiles = ['config.php', '.htaccess', 'index.php', 'guard.php'];
            foreach ($targetFiles as $fname) {
                if (isset($scanResult['files'][$fname]['local_path'])) {
                    $localPath = (string)$scanResult['files'][$fname]['local_path'];
                    if (is_file($localPath) && is_readable($localPath)) {
                        $content = @file_get_contents($localPath);
                        if ($content !== false) {
                            $fileContents[$fname] = $content;
                        }
                    }
                }
            }
            $detect = $detector->detect($fileContents);
            $patch['redirect_path_stage'] = [
                'path' => $detect['path'],
                'source' => $detect['source'],
                'detected_at' => date('Y-m-d H:i:s'),
                'files_examined' => array_keys($fileContents),
            ];
            if ($detect['path'] !== null) {
                $log->info('analyze_site',
                    "Redirect path детектирован: '{$detect['path']}' (источник: {$detect['source']}). " .
                    "Будет использован для smoke-теста.");
            } else {
                $log->warn('analyze_site',
                    'Redirect path не найден в config.php/.htaccess/index.php/guard.php. ' .
                    'Smoke-тест попробует fallback-кандидатов (/play, /reg, /go, /redirect).');
            }
        } catch (\Throwable $e) {
            $log->warn('analyze_site', 'RedirectPathDetector упал: ' . $e->getMessage() . ' (smoke использует fallback)');
        }

        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('analyze_site', 'Не сохранил artifacts: ' . $e->getMessage());
        }

        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    /**
     * Handler стадии config_replaced (v14c).
     *
     * Берёт план из artifacts.replacement_plan и применяет через ReplacementApplier.
     * Сохраняет snapshots в /storage/snapshots/job_{N}/.
     */
    private function runReplaceStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];

        // Берём план из artifacts
        $artifacts = [];
        if (!empty($job['artifacts_json'])) {
            $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
        }
        $plan = $artifacts['replacement_plan'] ?? null;
        if ($plan === null) {
            // ТЗ044 §7: отсутствие plan на config_replaced — это invariant breach, а НЕ бизнес-ошибка.
            // Никаких replacements/FTP write. Bounded self-heal: вернуть на analyze_site (max 1 раз),
            // иначе awaiting_user. Никакого слепого fail/loop.
            $rec = $artifacts['pipeline_recovery'] ?? [];
            $attempts = (int)($rec['missing_plan_rebuilds'] ?? 0);
            if ($attempts < 1) {
                $rec['missing_plan_rebuilds'] = $attempts + 1;
                $rec['last_recovery_at'] = gmdate('c');
                $artifacts['pipeline_recovery'] = $rec;
                try {
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET stage='analyze_site', stage_status='pending',
                            stage_error=NULL, next_run_at=NULL, artifacts_json=?
                         WHERE id=? AND stage NOT IN ('cancelled','superseded')"
                    )->execute([json_encode($artifacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
                } catch (\Throwable $e) { /* не блокируем */ }
                $log->warn('config_replaced',
                    'Pipeline invariant восстановлен: config_replaced получил job без replacement_plan. '
                    . 'Возвращаю на analyze_site для одной безопасной пересборки. FTP write=0.');
                return;
            }
            $log->error('config_replaced',
                'replacement_plan отсутствует и авто-пересборка исчерпана — нужно решение оператора. FTP write=0.');
            $this->setStatusAwaitingUser($jobId,
                'config_replaced: отсутствует replacement_plan после автоматической пересборки. FTP write=0.');
            return;
        }

        // AUTO-REBUILD: план без config_mutation (старый формат) — пересобрать через analyze.
        if (!is_array($plan['config_mutation'] ?? null)) {
            $log->warn('config_replaced', 'План без config_mutation — пересобираю через analyze_site...');
            $this->runAnalyzeStage($job, $log);
            $st = DB::pdo()->prepare("SELECT stage_status, artifacts_json FROM refresh_jobs WHERE id=?");
            $st->execute([$jobId]);
            $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            if ((string)($row['stage_status'] ?? '') === 'awaiting_user') {
                $log->warn('config_replaced', 'analyze_site при пересборке остановил джобу (awaiting_user).');
                return;
            }
            $newArtifacts = !empty($row['artifacts_json']) ? (json_decode((string)$row['artifacts_json'], true) ?: []) : [];
            $plan = $newArtifacts['replacement_plan'] ?? null;
            if (!is_array($plan) || !is_array($plan['config_mutation'] ?? null)) {
                $log->error('config_replaced', 'Auto-rebuild не помог — нет config_mutation.');
                $this->setStatusFailed($jobId, 'config_replaced: rebuild failed');
                return;
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // 1) config.php — DEDICATED exact-target pipeline (applyPrepared):
        //    re-fetch → SHA guard (TOCTOU) → один upload target → байтовый read-back
        //    (SHA == target_sha256) → semantic verify → persistVerified (транзакция +
        //    re-select). Порядок: остальные файлы применяются ДО config.php, а
        //    config.php — последний подтверждаемый шаг.
        // ─────────────────────────────────────────────────────────────────────
        $newDomain = trim((string)($plan['new_domain'] ?? $job['new_domain'] ?? ''));

        // (A) остальные файлы — существующим applier'ом (config.php уже исключён из replacements).
        $otherReps = array_values(array_filter((array)($plan['replacements'] ?? []),
            fn($r) => basename((string)($r['file'] ?? '')) !== 'config.php'));
        $filesChanged = 0; $repsApplied = 0;
        if (!empty($otherReps)) {
            $planOther = $plan; $planOther['replacements'] = $otherReps;
            try {
                $r2 = $this->makeApplier()->applyPlan($siteId, $jobId, $planOther, $log);
            } catch (\Throwable $e) {
                $log->error('config_replaced', 'Applier exception: ' . $e->getMessage());
                $this->setStatusFailed($jobId, 'config_replaced applier: ' . $e->getMessage());
                return;
            }
            if (empty($r2['ok'])) {
                $this->setStatusFailed($jobId, 'config_replaced failed: ' . implode('; ', (array)($r2['errors'] ?? [])));
                return;
            }
            $filesChanged += (int)($r2['files_changed'] ?? 0);
            $repsApplied  += (int)($r2['replacements_applied'] ?? 0);
        }

        // (B) config.php — mutation pipeline. applyPrepared сам делает upload/read-back/persist.
        try {
            $cfgPlan = ConfigMutationPlan::fromArray((array)$plan['config_mutation']);
        } catch (\Throwable $e) {
            $log->error('config_replaced', 'config_mutation план некорректен: ' . $e->getMessage());
            $this->setStatusFailed($jobId, 'config_replaced: invalid config_mutation plan');
            return;
        }
        $cfgRes = $this->makeConfigMutationService(new DomainMaskService([], true))->applyPrepared($cfgPlan);
        if (empty($cfgRes['ok'])) {
            $reason = (string)($cfgRes['reason'] ?? 'config_mutation_failed');
            $uploads = (int)($cfgRes['uploads'] ?? 0);
            $log->error('config_replaced', "config mutation: {$reason} (uploads={$uploads}). current_domain НЕ изменён.");
            $this->writeReadBackArtifact($jobId, array_merge(['ok' => false, 'reason' => $reason,
                'uploads' => $uploads, 'checked_at' => date('Y-m-d H:i:s')], (array)($cfgRes['errors'] ?? [])));
            $this->setStatusAwaitingUser($jobId, "config_replaced: {$reason}");
            return; // persist current_domain НЕ выполнялся
        }
        $filesChanged++; // config.php записан ровно один раз

        // current_domain + config_parsed_json уже сохранены внутри persistVerified (транзакция).
        $newDomainBare = $this->bareDomain($newDomain);
        $effNew = (string)($cfgPlan->newSubId ?? '');
        $this->writeReadBackArtifact($jobId, ['ok' => true, 'domain' => $newDomainBare, 'sub_id' => $effNew,
            'target_sha256' => $cfgPlan->targetSha256, 'files_changed' => $filesChanged, 'checked_at' => date('Y-m-d H:i:s')]);
        $log->ok('config_replaced', "config.php exact read-back подтверждён: домен='{$newDomainBare}'"
            . ($effNew !== '' ? ", sub_id='{$effNew}'" : '') . '.',
            ['event_code' => 'config.readback_verified', 'source' => 'site',
             'domain' => $newDomainBare, 'sub_id' => $effNew, 'files_changed' => $filesChanged]);
        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    // ═══════════════════ v30.1 SUB_ID DRIFT helpers ═══════════════════

    private function bareDomain(string $d): string
    {        $d = strtolower(trim($d));
        $d = preg_replace('~^https?://~i', '', $d);
        $d = preg_replace('~[/?#].*$~', '', (string)$d);
        $d = preg_replace('~:\d+$~', '', (string)$d);
        $d = preg_replace('~^www\.~i', '', (string)$d);
        return (string)$d;
    }

    /** Записать результат read-back в artifacts.config_replaced_stage.read_back. */
    private function writeReadBackArtifact(int $jobId, array $rb): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id = ?"
            )->execute([
                json_encode(['config_replaced_stage' => ['read_back' => $rb]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            // best-effort — на решение о переходе стадии не влияет
        }
    }

    /**
     * Зафиксировать исправленную пару old/new sub_id в джобе и ПОДТВЕРДИТЬ, что
     * запись применилась (re-select, т.к. rowCount ненадёжен при неизменных значениях).
     */
    protected function persistEffectiveSubId(int $jobId, string $old, string $new): bool
    {
        try {
            DB::pdo()->prepare("UPDATE refresh_jobs SET old_sub_id = ?, new_sub_id = ? WHERE id = ?")
                ->execute([$old, $new, $jobId]);
            $q = DB::pdo()->prepare("SELECT old_sub_id, new_sub_id FROM refresh_jobs WHERE id = ?");
            $q->execute([$jobId]);
            $r = $q->fetch(PDO::FETCH_ASSOC) ?: [];
            return ((string)($r['old_sub_id'] ?? '') === $old && (string)($r['new_sub_id'] ?? '') === $new);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Seam для тестов: сканер сайта (FTP). */
    protected function makeScanner(): SiteFileScanner
    {
        return new SiteFileScanner();
    }

    /** Seam для тестов: применятель плана. */
    protected function makeApplier(): ReplacementApplier
    {
        return new ReplacementApplier();
    }

    /**
     * v30.2: обновить sites_managed.current_domain и ПОДТВЕРДИТЬ re-select'ом.
     * Возвращает true только если в БД реально записалось ожидаемое значение.
     */
    protected function persistCurrentDomain(int $siteId, string $newDomain): bool
    {
        try {
            DB::pdo()->prepare("UPDATE sites_managed SET current_domain = ? WHERE id = ?")
                ->execute([$newDomain, $siteId]);
            $q = DB::pdo()->prepare("SELECT current_domain FROM sites_managed WHERE id = ?");
            $q->execute([$siteId]);
            return ((string)$q->fetchColumn() === $newDomain);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Seam для тестов: сервис синхронизации/чтения config.php с VPS. */
    protected function makeConfigSync(): SiteConfigSyncService
    {
        return new SiteConfigSyncService();
    }

    /** Seam: сервис мутации config.php (prepare/applyPrepared). */
    protected function makeConfigMutationService(DomainMaskService $mask): SiteConfigMutationService
    {
        return new SiteConfigMutationService($this->makeConfigSync(), new StaticSiteConfigScanner(), $mask);
    }

    /**
     * Handler стадии verify_replacement (v14c).
     *
     * HTTP-проверки старого и нового доменов. При провале — переводит
     * стадию в awaiting_user и шлёт Telegram-алерт.
     */
    private function runVerifyStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $oldDomain = (string)$job['old_domain'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        if ($newDomain === '') {
            $this->setStatusFailed($jobId, 'verify_replacement: new_domain is empty');
            return;
        }

        // Подождать чтобы opcache сбросился, файл записался итд
        sleep(3);

        // v18.1.28: ━━━ Defensive check для pipeline state ━━━
        // На стадии verify_replacement редирект ДОЛЖЕН быть отключён (стадия
        // redirect_disable выше уже отработала). Если файл config.php почему-то
        // содержит $redirect_enabled = 1 — значит redirect_disable тихо упал
        // (косяк скрипта). Восстанавливаем pipeline-инвариант: повторно отключаем.
        //
        // Принцип: «если редирект должен быть выключен, а он вдруг включён —
        // это косяк скрипта, надо детектировать и исправлять».
        $this->ensureRedirectDisabledForVerify($job, $log);

        $verifier = new SiteVerifier();

        // v18-fix: получить IP сервера для --resolve fallback.
        // Идея: если DNS на новый домен ещё не пропагирован у нашего VPS,
        // обычный curl падает с "Could not resolve". Тогда verifier
        // повторяет запрос через --resolve $domain:443:$vps_ip — это
        // обходит DNS и идёт прямо на наш сервер с правильным Host header.
        $vpsIp = $this->resolveVpsIpForJob($job, $log);
        if ($vpsIp !== null) {
            $verifier->setResolveIp($vpsIp);
            $log->info('verify_replacement',
                "VPS IP для --resolve fallback: {$vpsIp}");
        }

        // v18.1.2: 5-я проверка robots_php_logic (статический анализ + autopatch).
        // ВАЖНО: эта проверка идёт ПЕРЕД HTTP-проверками, потому что autopatch
        // может перезаписать robots.php — и тогда HTTP-проверка old_robots
        // увидит уже правильный файл (Disallow:/ для старого домена).
        // Иначе HTTP-проверка успевает прочитать СТАРЫЙ robots.txt до того,
        // как autopatch его исправит → ложный фейл.
        $robotsCheck = $this->checkAndMaybeAutopatchRobots($job, $log);
        if ($robotsCheck !== null && !empty($robotsCheck['autopatched'])) {
            // Если autopatch перезаписал файл — даём nginx/opcache время подхватить.
            // robots.php — это не PHP-кеш (он рендерится каждый раз через include
            // config.php), но всё равно паузу делаем для надёжности.
            sleep(2);
            $log->info('verify_replacement',
                'robots.php был перезаписан autopatch — пауза 2 сек перед HTTP-проверками');
        }

        try {
            // v18.1.26: передаём context для multi-method robots check.
            // Это позволяет verify использовать VPS-side и temp-disable fallback
            // если простой curl не получил валидный robots.txt (guard перехватил).
            $verifyContext = [
                'job_id'  => $jobId,
                'site_id' => (int)($job['site_id'] ?? 0),
                'job'     => $job,
            ];
            $result = $verifier->verifyAfterReplacement($oldDomain, $newDomain, $log, $verifyContext);
        } catch (\Throwable $e) {
            $log->error('verify_replacement', 'Verifier exception: ' . $e->getMessage());
            $this->setStatusFailed($jobId, 'verify_replacement: ' . $e->getMessage());
            return;
        }

        // Добавляем результат robots_php_logic в общий список checks
        if ($robotsCheck !== null) {
            $result['checks']['robots_php_logic'] = $robotsCheck;
            // Если check провалился — добавляем в failed_checks чтобы overall_ok стало false
            if (empty($robotsCheck['ok'])) {
                $result['failed_checks'][] = 'robots_php_logic';
                $result['overall_ok'] = false;
                $result['requires_user_action'] = true;
            }
        }

        // Сохраняем результаты
        $patch = ['verify_stage' => [
            'overall_ok' => $result['overall_ok'],
            'requires_user_action' => $result['requires_user_action'],
            'checks' => $result['checks'],
            'failed_checks' => $result['failed_checks'],
            'warnings' => $result['warnings'] ?? [],
        ]];
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('verify_replacement', 'Не сохранил artifacts: ' . $e->getMessage());
        }

        if (!empty($result['overall_ok'])) {
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // === v18-fix: РАСШИРЕННАЯ AUTO-RETRY логика ===
        //
        // Старая версия делала retry только при DNS-race (resolve host fail).
        // Но на проде часто бывают другие transient проблемы:
        //   - HTTP 200, но robots.txt отдаёт старое содержимое (CDN/nginx кеш)
        //   - HTTP 200, но config.php ещё в OPCache PHP с прошлым $domain
        //   - Промежуточные 5xx от downstream-сервисов
        //
        // Все эти проблемы рассасываются за 1-15 минут. Делаем 5 попыток
        // с прогрессивными интервалами (30s, 60s, 120s, 240s, 300s = ~12 мин),
        // только потом переходим в awaiting_user.
        //
        // Считаем что failure ретраимый, если он:
        //   (а) DNS race — 'Could not resolve host'
        //   (б) Сетевая транзиентная — timeout, 5xx, connection refused
        //   (в) Robots vs ожидание — HTTP 200, но контент не тот (кеш!)
        //   НЕ ретраим:
        //   (г) HTTP 4xx (сайт лежит, человеческое вмешательство нужно)
        //   (д) SSL cert errors (тоже нужно человеку посмотреть)
        $failed = $result['failed_checks'];
        $retryable = $this->isRetryableVerifyFailure($result);

        // Прогрессивные интервалы между попытками (всего 5)
        // v18.1.25: ARCHITECTURAL CHANGE — убран жёсткий лимит 5 попыток.
        // Раньше: $retryDelays = [30, 60, 120, 240, 300] = 5 попыток за 12.5 мин,
        // потом stop в awaiting_user навсегда.
        // Это противоречило "никаких остановок, только снижение частоты".
        //
        // Теперь: бесконечный polling с adaptive backoff (как в smoke v18.1.24 / index_watching v18.1.22).
        // Через 30 мин fails — одно TG-уведомление "ждём". Без awaiting_user.
        if ($retryable) {
            $artifacts = !empty($job['artifacts_json'])
                ? (json_decode((string)$job['artifacts_json'], true) ?: [])
                : [];
            $retryCount = (int)($artifacts['verify_stage']['auto_retry_count'] ?? 0);
            $startedAtUnix = (int)($artifacts['verify_stage']['retry_started_at_unix'] ?? 0);
            if ($startedAtUnix === 0) {
                $startedAtUnix = time();
            }
            $elapsedSec = time() - $startedAtUnix;

            $newRetryCount = $retryCount + 1;
            $delay = $this->computeVerifyRetryDelay($elapsedSec);

            // Понятное объяснение почему retry
            $reasonHint = $this->describeRetryReason($result);
            $delayLabel = $delay >= 3600
                ? round($delay / 3600, 1) . ' ч'
                : ($delay >= 60 ? round($delay / 60) . ' мин' : $delay . ' сек');
            $log->warn('verify_replacement',
                "Verify провален (не критично — попробуем снова). " .
                "Авто-повтор #{$newRetryCount} через {$delayLabel} (polling без лимита). " .
                "Причина: {$reasonHint}");

            // Сохраняем счётчик и историю попыток (для отладки)
            $retryHistory = $artifacts['verify_stage']['retry_history'] ?? [];
            $retryHistory[] = [
                'attempt'        => $newRetryCount,
                'failed_at'      => date('Y-m-d H:i:s'),
                'failed_checks'  => $failed,
                'next_delay_sec' => $delay,
            ];
            // Обрежем историю до последних 50 (чтобы artifacts не раздувался при долгом polling'е)
            if (count($retryHistory) > 50) {
                $retryHistory = array_slice($retryHistory, -50);
            }

            $patch2 = ['verify_stage' => [
                'auto_retry_count'       => $newRetryCount,
                'retry_history'          => $retryHistory,
                'last_retry_at'          => date('Y-m-d H:i:s'),
                'retry_started_at_unix'  => $startedAtUnix,
            ]];

            // Через 30 мин fail'ов — однократный TG-аларт "ждём" (не останавливая).
            $alertSent = !empty($artifacts['verify_stage']['waiting_alert_sent_at']);
            if ($elapsedSec >= 30 * 60 && !$alertSent) {
                $this->sendVerifyWaitingAlert($jobId, $job, $newRetryCount, $reasonHint, $log);
                $patch2['verify_stage']['waiting_alert_sent_at'] = date('Y-m-d H:i:s');
            }

            try {
                // v18.1.25: статус ставим 'pending' (а не 'awaiting_user') —
                // pending более естественно для retry без вмешательства оператора.
                // UI всё равно покажет блок "Авто-retry" через $isAutoRetry detect.
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET
                        artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?),
                        stage_status = 'pending',
                        stage_error = ?,
                        stage_started_at = NULL,
                        stage_finished_at = NULL,
                        next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
                     WHERE id = ?"
                )->execute([
                    json_encode($patch2, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    "verify_replacement: авто-повтор #{$newRetryCount} через {$delayLabel}",
                    $delay,
                    $jobId,
                ]);
            } catch (\Throwable $e) {
                $log->warn('verify_replacement', 'Не сохранил retry count: ' . $e->getMessage());
            }

            return; // cron подхватит когда next_run_at <= NOW()
        } else {
            // Нон-retryable failure — это HTTP 4xx или прочие проблемы которые
            // сами не починятся (сервер реально отдаёт неправильное содержимое).
            // Здесь awaiting_user обоснован — оператор должен проверить руками.
            $log->warn('verify_replacement',
                "Verify провален с не-retryable ошибкой (HTTP 4xx или другая " .
                "ошибка которая не пройдёт сама). Перевожу в awaiting_user.");
        }

        // Не ок — переводим в awaiting_user и шлём Telegram
        $msg = 'Верификация не прошла. Провалены: ' . implode(', ', $failed) .
            '. Зайди в панель и нажми "Продолжить" если всё ок, или "Откатить".';
        $log->warn('verify_replacement', $msg);
        $this->setStatusAwaitingUser($jobId, 'verify_replacement: ' . implode(', ', $failed));

        // Telegram-алерт
        try {
            $tg = $this->makeTelegramService();
            $jobUrl = $this->buildJobUrl($jobId);
            $tg->send(
                "⏸ <b>Джоба #{$jobId} ждёт вмешательства</b>\n" .
                "Сайт: {$oldDomain} → {$newDomain}\n" .
                "Провалены проверки: " . implode(', ', $failed) . "\n" .
                ($jobUrl !== '' ? "\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('verify_replacement', 'Telegram alert failed: ' . $e->getMessage());
        }
    }

    /**
     * v18.1.25: adaptive backoff для verify retry. Никогда не останавливается.
     *
     * Те же интервалы что у smoke (v18.1.24) и index_watching (v18.1.22):
     *   0-5 мин:    30 сек     (быстрая первичная проверка, DNS пропагация)
     *   5-15 мин:   60 сек
     *   15-30 мин:  2 мин
     *   30 мин-6 ч: 5 мин
     *   6 ч-3 дня:  30 мин
     *   3-7 дней:   1 час
     *   7+ дней:    6 часов
     */
    private function computeVerifyRetryDelay(int $elapsedSec): int
    {
        if ($elapsedSec < 5 * 60)        return 30;          // < 5 мин → 30 сек
        if ($elapsedSec < 15 * 60)       return 60;          // < 15 мин → 60 сек
        if ($elapsedSec < 30 * 60)       return 2 * 60;      // 15-30 мин → 2 мин
        if ($elapsedSec < 6 * 3600)      return 5 * 60;      // 30 мин - 6 ч → 5 мин
        if ($elapsedSec < 3 * 86400)     return 30 * 60;     // 6 ч - 3 дня → 30 мин
        if ($elapsedSec < 7 * 86400)     return 3600;        // 3-7 дней → 1 час
        return 6 * 3600;                                      // 7+ дней → 6 часов
    }

    /**
     * v18.1.25: однократный TG-аларт через 30 мин verify retry. НЕ останавливает джобу.
     */
    private function sendVerifyWaitingAlert(
        int $jobId,
        array $job,
        int $attemptCount,
        string $reasonHint,
        JobEventLogger $log
    ): void {
        try {
            $tg = $this->makeTelegramService();
            $oldSafe = htmlspecialchars((string)$job['old_domain'], ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars((string)$job['new_domain'], ENT_QUOTES, 'UTF-8');
            $reasonSafe = htmlspecialchars($reasonHint, ENT_QUOTES, 'UTF-8');
            $jobUrl = $this->buildJobUrl($jobId);

            $tg->send(
                "⏳ <b>refresh #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "Стадия: verify_replacement — прошло 30 минут, проверка ещё не прошла\n" .
                "Уже попыток: {$attemptCount}\n" .
                "Последняя причина: {$reasonSafe}\n\n" .
                "<b>Это нормально</b> — обычные причины: DNS пропагация, CDN-кеш " .
                "(Cloudflare/DDoS-Guard), opcache PHP.\n" .
                "Джоба <b>продолжает проверять</b> с разрядкой:\n" .
                "• следующие 6 часов — каждые 5 мин\n" .
                "• до 3 суток — каждые 30 мин\n" .
                "• до недели — каждый час\n" .
                "• потом каждые 6 часов\n\n" .
                "Действий <b>не требуется</b>. Когда verify пройдёт — pipeline пойдёт дальше." .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('verify_replacement', 'Telegram verify-waiting alert failed: ' . $e->getMessage());
        }
    }

    /**
     * Handler стадии ssl_self_signed_first (v14b).
     *
     * Мгновенно ставит self-signed cert на новый домен, чтобы HTTPS отвечал
     * (DDoS-Guard origin требует HTTPS, и verify_replacement тоже использует HTTPS).
     *
     * Не блокирует pipeline — даже если упадёт, продолжаем на analyze_site.
     */
    private function runSslSelfSignedStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        if ($newDomain === '') {
            $log->warn('ssl_self_signed_first', 'new_domain пуст, пропускаем стадию');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        $issuer = $this->makeSslIssuerService();
        try {
            $result = $issuer->attachSelfSigned($siteId, $newDomain, $log);
        } catch (\Throwable $e) {
            $log->error('ssl_self_signed_first', 'Exception: ' . $e->getMessage());
            // Не блокируем — переходим дальше с warning
            $log->warn('ssl_self_signed_first',
                'Self-signed не поставился. Переходим дальше — verify может упасть на HTTPS.');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // Сохраняем артефакты
        $patch = ['ssl_self_signed_stage' => [
            'ok' => $result['ok'],
            'action' => $result['action'] ?? '',
            'certificate_id' => $result['certificate_id'] ?? null,
            'message' => $result['message'] ?? '',
        ]];
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('ssl_self_signed_first', 'Не сохранил artifacts: ' . $e->getMessage());
        }

        // Стадия не блокирующая — даже при ошибке идём дальше.
        // Если LE или admin потом наверстает — фикс будет вручную.
        if (empty($result['ok'])) {
            $log->warn('ssl_self_signed_first',
                'Self-signed не поставился, но pipeline продолжается. ' .
                'Verify может упасть на HTTPS — поправь руками через FP UI.');
        }
        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    /**
     * Handler стадии redirect_disable (v14f).
     *
     * Отключает все редиректы на сайте (Redirect 302 в .htaccess,
     * $redirect_enabled в config.php и т.д.) перед началом замен. Это нужно
     * чтобы пользователи и боты не уходили на партнёрку пока сайт в
     * неполноценном состоянии (старый $domain, может неполный SSL и т.д.)
     *
     * Не блокирует pipeline даже при ошибке — переходим дальше.
     */
    private function runRedirectDisableStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];

        // v18.1.9: pre-validation — есть ли в файлах УЖЕ существующие REFRESH-DISABLED маркеры?
        // Это значит что предыдущая джоба для этого сайта не закончила работу корректно
        // (возможно была удалена, упала на середине, или редирект включался руками с ошибкой).
        // Если новая джоба сделает свой redirect_disable поверх — у нас будут вложенные
        // маркеры (или вообще ничего не сделает если detect-regex не сматчится с уже
        // закомментированной строкой), и это делает невозможным корректный redirect_enable.
        //
        // Поэтому: предупреждаем оператора и пытаемся снять старые маркеры ДО начала.
        $stalemMarkers = $this->detectStaleRefreshDisabledMarkers($job, $log);
        if (!empty($stalemMarkers)) {
            $log->warn('redirect_disable',
                "⚠️ Обнаружены ОСТАВШИЕСЯ REFRESH-DISABLED маркеры от предыдущей джобы " .
                "в файлах: " . implode(', ', $stalemMarkers) .
                ". Это значит редирект на партнёрку был выключен и не включён обратно — " .
                "возможно деньги от партнёрки не идут уже какое-то время.");
            $log->info('redirect_disable',
                "Снимаю старые маркеры через RedirectToggler::enable() перед тем как делать новый disable...");

            // Прогоняем enable() с пустым state — он в defense-in-depth режиме (v18.1.8)
            // прогонит все правила blindly и снимет маркеры.
            try {
                $cleanupToggler = new RedirectToggler();
                $cleanupResult = $cleanupToggler->enable($siteId, $jobId, [], $log);
                if (!empty($cleanupResult['ok']) && !empty($cleanupResult['restored_rules'])) {
                    $log->ok('redirect_disable',
                        "✓ Старые маркеры сняты (" . count($cleanupResult['restored_rules']) . " правил). " .
                        "Партнёрский редирект восстановлен. Теперь начинаю свой redirect_disable.");
                } else {
                    $log->warn('redirect_disable',
                        "Cleanup прогнал правила, но не нашёл маркеров для снятия — возможно " .
                        "regex правил не подходит к шаблону этого сайта. Продолжаю всё равно.");
                }
            } catch (\Throwable $e) {
                $log->warn('redirect_disable',
                    "Cleanup упал: " . $e->getMessage() . ". Продолжаю всё равно.");
            }
        }

        $toggler = new RedirectToggler();
        try {
            $result = $toggler->disable($siteId, $jobId, $log);
        } catch (\Throwable $e) {
            $log->error('redirect_disable', 'Exception: ' . $e->getMessage());
            $log->warn('redirect_disable',
                'Не удалось отключить редиректы. Pipeline продолжается, но пользователи могут уйти на партнёрку до окончания refresh.');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // Сохраняем state в artifacts — нужен для redirect_enable
        $patch = ['redirect_disabled_stage' => [
            'ok' => $result['ok'],
            'applied_rules' => $result['applied_rules'] ?? [],
            'snapshots' => $result['snapshots'] ?? [],
            'base_path' => $result['base_path'] ?? null,
            'errors' => $result['errors'] ?? [],
            'stale_markers_cleaned' => $stalemMarkers, // для UI: показать что мы починили
        ]];
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('redirect_disable', 'Не сохранил artifacts: ' . $e->getMessage());
        }

        // §3.2/§4: штатное временное отключение редиректа подтверждено.
        if (!empty($result['ok'])) {
            $log->info('redirect_disable',
                'Партнёрский редирект штатно временно отключён на время refresh.',
                ['event_code' => 'redirect.disabled', 'source' => 'site',
                 'applied_rules' => count($result['applied_rules'] ?? [])]);
        }
        // Стадия не блокирующая
        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    /**
     * v18.1.9: Pre-validation для redirect_disable.
     *
     * Скачивает ключевые файлы (.htaccess, index.php) через FTP и ищет в них
     * УЖЕ существующие REFRESH-DISABLED маркеры. Это признак того что предыдущая
     * джоба для этого сайта не завершила работу корректно — что-то прошло
     * `redirect_disable`, но `redirect_enable` не сработал или не запускался.
     *
     * Возвращает массив имён файлов с stale маркерами или [] если всё чисто.
     *
     * Использует тот же base_path что и RedirectToggler — на случай alias structures.
     */
    private function detectStaleRefreshDisabledMarkers(array $job, JobEventLogger $log): array
    {
        $siteId = (int)$job['site_id'];

        // Загружаем сайт для FTP creds + siteRoot
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
            $st->execute([$siteId]);
            $site = $st->fetch();
            if (!$site || empty($site['ftp_host'])) {
                return [];
            }
        } catch (\Throwable $e) {
            return [];
        }

        try {
            $ftpPass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            $ftp = $this->makeFtp((string)$site['ftp_host'], (string)$site['ftp_user'], $ftpPass);
            $ftp->connect();
        } catch (\Throwable $e) {
            return [];
        }

        // На раннем этапе redirect_disable у нас ещё нет base_path в artifacts.
        // Используем ту же логику что RedirectToggler: пробуем несколько вариантов.
        // Самый простой и надёжный для большинства случаев — пустой base_path
        // (FTP-аккаунт уже chrooted на корень сайта).
        $candidatePaths = ['', 'public_html', 'httpdocs'];

        // Дополнительно — путь из site.web_root_path если есть
        $siteRoot = trim((string)($site['web_root_path'] ?? ''));
        if ($siteRoot !== '' && !in_array($siteRoot, $candidatePaths, true)) {
            $candidatePaths[] = $siteRoot;
        }

        $remaining = [];
        $filesToCheck = ['.htaccess', 'index.php'];

        foreach ($filesToCheck as $fileName) {
            $foundContent = null;
            foreach ($candidatePaths as $bp) {
                $remoteAbs = $bp === '' ? $fileName : (rtrim($bp, '/') . '/' . $fileName);
                try {
                    $c = $ftp->tryGetContent($remoteAbs);
                    if (is_string($c) && $c !== '') {
                        $foundContent = $c;
                        break;
                    }
                } catch (\Throwable $e) {
                    continue;
                }
            }
            if ($foundContent === null) continue;

            if (preg_match('~^\s*(?:#|//)\s*REFRESH-DISABLED:~m', $foundContent)) {
                $remaining[] = $fileName;
            }
        }

        try { $ftp->disconnect(); } catch (\Throwable $e) {}
        return $remaining;
    }


    /**
     * Handler стадии redirect_enable (v14f).
     *
     * Включает редиректы обратно используя state из redirect_disabled_stage.
     * Это КРИТИЧЕСКАЯ стадия — если она упадёт, сайт останется без рабочего
     * редиректа и потеряет пользователей.
     *
     * При ошибке — НЕ переходим на ssl_le_polling, а оставляем стадию в failed.
     * Пользователь увидит явную ошибку и сможет вернуть редирект руками.
     */
    private function runRedirectEnableStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];

        // === v16: проверка посайтового toggle ===
        // Пользователь мог выключить редирект на сайте через UI (kill switch).
        // В этом случае пропускаем включение — оставляем редирект отключённым.
        try {
            $st = DB::pdo()->prepare("SELECT redirect_enabled FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $siteRedirectEnabled = (int)($st->fetchColumn() ?: 1);
            if ($siteRedirectEnabled === 0) {
                $log->warn('redirect_enable',
                    'Редирект для этого сайта отключён в настройках (kill switch). ' .
                    'Стадия пропущена — редирект остаётся выключенным.');

                // Сохраняем в artifacts что мы skip'нули
                $patch = ['redirect_enabled_stage' => [
                    'ok' => true,
                    'action' => 'skipped_by_site_toggle',
                    'message' => 'Site redirect_enabled=0, stage skipped',
                    'restored_rules' => [],
                ]];
                try {
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET
                            artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                         WHERE id = ?"
                    )->execute([
                        json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        $jobId,
                    ]);
                } catch (\Throwable $e) {}

                $this->setStatus($jobId, 'ok', 'stage_finished_at');
                return;
            }
        } catch (\Throwable $e) {
            // Не критично — продолжаем как обычно
            $log->info('redirect_enable',
                'Не удалось прочитать site.redirect_enabled (' . $e->getMessage() . '), продолжаю');
        }

        // Берём state из artifacts
        $artifacts = [];
        if (!empty($job['artifacts_json'])) {
            $artifacts = json_decode((string)$job['artifacts_json'], true) ?: [];
        }
        $disabledState = $artifacts['redirect_disabled_stage'] ?? null;

        // Если disable не делался / ничего не отключал — нечего включать
        if (empty($disabledState) || empty($disabledState['applied_rules'])) {
            $log->info('redirect_enable',
                'redirect_disable ничего не отключал — нечего включать. OK.');
            // BLOCKER A: явный not_required artifact, иначе guard fail-closed заблокирует переход.
            try {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id = ?"
                )->execute([
                    json_encode(['redirect_enabled_stage' => ['ok' => true, 'not_required' => true, 'action' => 'not_required',
                        'message' => 'redirect_disable applied_rules пуст — включать нечего', 'restored_rules' => []]],
                        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $jobId,
                ]);
            } catch (\Throwable $e) {}
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // v18.1.13: distributed retry для smoke-test.
        // Если RedirectToggler::enable уже отработал успешно в предыдущем тике
        // (артефакты есть, restored_rules > 0, post-validation прошла), мы НЕ
        // повторяем enable/post-val. Сразу идём к smoke-test (это retry-тик).
        //
        // BLOCKER A: skipEnable теперь ТРЕБУЕТ подтверждённый semantic read_back
        // (value=1, markers=0). Legacy-артефакт без read_back → делаем реальный read-only
        // semantic check config.php; если он не подтверждает — НЕ пропускаем enable.
        $alreadyEnabled = $artifacts['redirect_enabled_stage'] ?? null;
        $skipEnable = false;
        if ($alreadyEnabled !== null
            && !empty($alreadyEnabled['ok'])
            && isset($alreadyEnabled['restored_rules'])
            && empty($alreadyEnabled['remaining_markers'])
            && empty($alreadyEnabled['post_validation_failed'])
        ) {
            $rbPrev = $alreadyEnabled['read_back'] ?? null;
            $rbValid = is_array($rbPrev) && !empty($rbPrev['ok'])
                && (($rbPrev['value'] ?? null) === null
                    || ((int)$rbPrev['value'] === 1 && (int)($rbPrev['marker_count'] ?? 1) === 0));
            if (!$rbValid) {
                // legacy artifact без валидного read_back — делаем реальный read-only semantic check
                $chk = (new RedirectToggler())->readBackConfigState($siteId, $jobId, $log);
                $rbValid = !empty($chk['ok'])
                    && (empty($chk['found']) || ((int)($chk['value'] ?? -1) === 1 && (int)($chk['marker_count'] ?? 1) === 0));
                if ($rbValid) {
                    // дописываем подтверждённый read_back в артефакт, чтобы guard прошёл честно
                    try {
                        DB::pdo()->prepare(
                            "UPDATE refresh_jobs SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id = ?"
                        )->execute([
                            json_encode(['redirect_enabled_stage' => ['read_back' => [
                                'ok' => true, 'value' => $chk['value'] ?? null, 'marker_count' => $chk['marker_count'] ?? null,
                                'source' => 'legacy_skip_recheck']]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                            $jobId,
                        ]);
                    } catch (\Throwable $e) {}
                }
            }
            if ($rbValid) {
                $skipEnable = true;
                $log->info('redirect_enable',
                    'RedirectToggler уже отработал в предыдущем тике (read_back подтверждён). ' .
                    'Пропускаю enable/post-validation, иду сразу к smoke-test.');
            } else {
                $log->warn('redirect_enable',
                    'Прошлый redirect_enabled_stage без подтверждённого semantic read_back — ' .
                    'НЕ пропускаю enable, выполняю заново с реальным read-back.');
            }
        }

        if (!$skipEnable) {
            $toggler = new RedirectToggler();
            try {
                $result = $toggler->enable($siteId, $jobId, $disabledState, $log);
            } catch (\Throwable $e) {
                $log->error('redirect_enable',
                    'CRITICAL: Exception при включении редиректа: ' . $e->getMessage());
                $log->error('redirect_enable',
                    '⚠️ РЕДИРЕКТ НА САЙТЕ ОТКЛЮЧЁН — НЕОБХОДИМО ВКЛЮЧИТЬ ВРУЧНУЮ ИЛИ ПОВТОРИТЬ СТАДИЮ');
                $this->setStatusFailed($jobId,
                    'redirect_enable: ' . $e->getMessage() .
                    ' — ВНИМАНИЕ: редирект на сайте отключён, нужно вернуть');
                return;
            }

            // Сохраняем результат
            // ТЗ044 §9 (BLOCKER 3): реальный semantic read-back config.php + marker-диагностика.
            $md = $toggler->markerDiag['config.php'] ?? [];
            $rb = $toggler->readBackConfigState($siteId, $jobId, $log);
            // read-back ok, если: read-back удался И (в config нет $redirect_enabled ИЛИ value==1 & markers==0)
            $readBackOk = !empty($rb['ok'])
                && (empty($rb['found']) || ((int)($rb['value'] ?? -1) === 1 && (int)($rb['marker_count'] ?? 1) === 0));
            $patch = ['redirect_enabled_stage' => [
                'ok' => (!empty($result['ok']) && $readBackOk),
                'restored_rules' => $result['restored_rules'] ?? [],
                'errors' => $result['errors'] ?? [],
                'read_back' => [
                    'ok' => $readBackOk,
                    'value' => $rb['value'] ?? null,
                    'marker_count' => $rb['marker_count'] ?? null,
                    'reason' => $rb['reason'] ?? null,
                ],
                'markers_before' => $md['markers_before'] ?? null,
                'markers_after' => $md['markers_after'] ?? null,
                'normalized_duplicates' => $md['normalized_duplicates'] ?? null,
                'semantic_before' => $md['semantic_before'] ?? null,
                'semantic_after' => $md['semantic_after'] ?? null,
            ]];
            try {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET
                        artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                     WHERE id = ?"
                )->execute([
                    json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $jobId,
                ]);
            } catch (\Throwable $e) {
                $log->warn('redirect_enable', 'Не сохранил artifacts: ' . $e->getMessage());
            }

            if (empty($result['ok'])) {
                $errs = !empty($result['errors']) ? implode('; ', $result['errors']) : 'unknown';
                $log->error('redirect_enable',
                    "⚠️ РЕДИРЕКТ ВКЛЮЧЁН НЕ ПОЛНОСТЬЮ. Ошибки: {$errs}");
                $log->error('redirect_enable',
                    '⚠️ ПРОВЕРЬ САЙТ ВРУЧНУЮ через FP UI. Возможно нужно вернуть редирект.');
                $this->setStatusFailed($jobId,
                    'redirect_enable: ' . $errs . ' — ВНИМАНИЕ: проверь редирект на сайте');
                return;
            }

            // BLOCKER 3: read-back не подтвердил semantic enabled (value=1, markers=0) — НЕ success.
            if (!$readBackOk) {
                $rbReason = (string)($rb['reason'] ?? '');
                $sem = 'value=' . var_export($rb['value'] ?? null, true) . ', markers=' . var_export($rb['marker_count'] ?? null, true);
                $log->error('redirect_enable',
                    "⚠️ Semantic read-back config.php НЕ подтвердил включённый редирект ({$sem}"
                    . ($rbReason !== '' ? ", reason={$rbReason}" : '') . "). Стадия НЕ считается выполненной.");
                $this->setStatusAwaitingUser($jobId,
                    'redirect_enable: config.php read-back показал, что редирект не включён семантически '
                    . '(' . $sem . '). Проверьте сайт; стадия не завершена.');
                return;
            }
        } else {
            // skipEnable=true — reconstruct $result из артефактов
            $result = [
                'ok' => true,
                'restored_rules' => $alreadyEnabled['restored_rules'] ?? [],
                'errors' => $alreadyEnabled['errors'] ?? [],
            ];
        }

        // v18.1.8: post-validation — реально ли REFRESH-DISABLED маркеры исчезли из файлов?
        // RedirectToggler::enable() возвращает ok даже если ничего не нашёл в файлах
        // (warning в лог, count=0). Проверяем сами через FTP — если маркеры остались,
        // отмечаем stage как awaiting_user чтобы оператор знал и вмешался.
        //
        // v18.1.13: при retry (skipEnable=true) post-validation тоже пропускаем —
        // мы её уже сделали в первом тике, файлы с тех пор не трогали.
        if (!$skipEnable) {
            $remainingMarkers = $this->verifyNoRefreshDisabledMarkers($job, $log);
            if (!empty($remainingMarkers)) {
                $log->error('redirect_enable',
                    "⚠️ КРИТИЧНО: после enable() в файлах ОСТАЛИСЬ REFRESH-DISABLED маркеры: " .
                    implode(', ', $remainingMarkers));
                $log->error('redirect_enable',
                    "Это значит что редирект на партнёрку НЕ работает (даже если UI показывает ok). " .
                    "Возможные причины: (1) был rollback который очистил state, " .
                    "(2) файлы были изменены извне между disable и enable, " .
                    "(3) detect-regex в правилах не подходит к текущему шаблону сайта.");
                $log->error('redirect_enable',
                    "💡 Что делать: открой файл через FTP/FastPanel и удали '# REFRESH-DISABLED:' " .
                    "(в .htaccess) или '// REFRESH-DISABLED:' (в index.php) префиксы. " .
                    "Затем нажми «✅ Я поправил, продолжить» в UI.");

                // Сохраняем список проблемных файлов в artifacts для UI
                try {
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET
                            artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                         WHERE id = ?"
                    )->execute([
                        json_encode([
                            'redirect_enabled_stage' => [
                                'remaining_markers' => $remainingMarkers,
                                'post_validation_failed' => true,
                            ]
                        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        $jobId,
                    ]);
                } catch (\Throwable $e) {
                    $log->warn('redirect_enable', 'Не сохранил remaining_markers: ' . $e->getMessage());
                }

                $this->setStatusAwaitingUser($jobId,
                    'redirect_enable: post-validation failed — REFRESH-DISABLED маркеры остались в файлах: ' .
                    implode(', ', $remainingMarkers) .
                    '. Проверь .htaccess и index.php через FTP.');
                return;
            }

            $log->ok('redirect_enable',
                'Редиректы включены: ' . count($result['restored_rules']) . ' правил восстановлено. ' .
                'Post-validation ✓: REFRESH-DISABLED маркеров в файлах нет.');
        }

        // v18.1.9: ультимативная проверка — реально ли редирект работает на партнёрку?
        // Раньше мы доверяли что "файлы выглядят правильно" = "редирект работает". Это неправда:
        //  - .htaccess может игнорироваться Apache (AllowOverride None в server config)
        //  - opcache PHP может держать старый index.php
        //  - правила могли удалиться вручную и detect-regex не сматчился
        //
        // v18.1.13: distributed retry через next_run_at вместо sleep().
        // v18.1.24: убран жёсткий лимит attempts=3 → adaptive infinite backoff.
        // Pipeline никогда не останавливается на awaiting_user из-за smoke. Возможные
        // причины fail'а (DNS пропагация, opcache PHP-FPM, кеш CDN) — все временные,
        // решаются автоматически за минуты-часы. Старая логика "stop after 3 attempts"
        // вынуждала оператора руками щёлкать «Я поправил, продолжить» десятки раз.
        //
        // Adaptive интервалы: 30 сек / 2 мин / 5 мин / 30 мин / 1 ч (до 3 дней) / 6 ч / 24 ч.
        // Через 30 мин fail'ов — однократное TG-уведомление "ждём, не действуй".
        $smokeAttempt = (int)($alreadyEnabled['smoke_attempt'] ?? 0) + 1;
        $smokeStartedAtUnix = (int)($alreadyEnabled['smoke_started_at_unix'] ?? 0);
        if ($smokeStartedAtUnix === 0) {
            $smokeStartedAtUnix = time();
        }
        $smokeElapsedSec = time() - $smokeStartedAtUnix;
        $smokePathForLog = $this->resolveSmokePath($job, $log);

        $log->info('redirect_enable',
            "Проверка редиректа {$smokePathForLog} attempt #{$smokeAttempt}...");

        $smoke = $this->smokeTestRedirectPlay($job, $log);
        $smoke['attempts'] = $smokeAttempt;

        // Сохраняем результат smoke-test и счётчик попыток В ЛЮБОМ случае
        // (важно при ok тоже — чтобы UI показывал количество попыток)
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode([
                    'redirect_enabled_stage' => [
                        'smoke_test' => $smoke,
                        'smoke_attempt' => $smokeAttempt,
                        'smoke_started_at_unix' => $smokeStartedAtUnix,
                        'smoke_path' => $smokePathForLog,
                    ]
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('redirect_enable', 'Не сохранил smoke_test: ' . $e->getMessage());
        }

        // SUCCESS
        if (!empty($smoke['ok'])) {
            if ($smokeAttempt > 1) {
                $log->ok('redirect_enable',
                    "✓ Smoke-test {$smokePathForLog} прошёл на attempt #{$smokeAttempt} " .
                    "(первые попытки падали из-за DNS/vhost propagation — это нормально)");
            }
            $log->ok('redirect_enable',
                "✓ Smoke-test {$smokePathForLog} редиректа: " . $smoke['reason'],
                ['event_code' => 'redirect.enabled', 'source' => 'site']);
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // v18.1.24: FAIL — adaptive infinite retry, никаких awaiting_user.
        // Через 30 мин fail'ов — однократный TG-аларт «ждём» (тот же что у index_watching).
        $alertSentAt = (string)($alreadyEnabled['smoke_waiting_alert_sent_at'] ?? '');
        if ($smokeElapsedSec >= 30 * 60 && $alertSentAt === '') {
            // v18.1.31 fix: $newDomain не определялся в runRedirectEnableStage — Fatal
            // когда смотр-задержка 30+ мин и нужно отправить TG. Берём напрямую из джобы.
            $newDomain = trim((string)($job['new_domain'] ?? ''));
            if ($newDomain !== '') {
                $this->sendSmokeWaitingAlert($jobId, $job, $newDomain, $smokePathForLog, $smokeAttempt, $smoke, $log);
                try {
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET
                            artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                         WHERE id = ?"
                    )->execute([
                        json_encode([
                            'redirect_enabled_stage' => [
                                'smoke_waiting_alert_sent_at' => date('Y-m-d H:i:s'),
                            ]
                        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        $jobId,
                    ]);
                } catch (\Throwable $e) {}
            } else {
                $log->warn('redirect_enable',
                    'Пропустил отправку TG-алерта о долгом smoke: new_domain пуст в job-record.');
            }
        }

        $retryDelaySec = $this->computeSmokeRetryDelay($smokeElapsedSec);
        $delayLabel = $retryDelaySec >= 3600
            ? round($retryDelaySec / 3600, 1) . ' ч'
            : ($retryDelaySec >= 60 ? round($retryDelaySec / 60) . ' мин' : $retryDelaySec . ' сек');

        $log->warn('redirect_enable',
            "Smoke attempt #{$smokeAttempt} провалился: " . ($smoke['reason'] ?? '?') .
            ". Повтор через {$delayLabel} (polling без лимита, без остановок).");
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
                 WHERE id = ?"
            )->execute([$retryDelaySec, $jobId]);
        } catch (\Throwable $e) {
            $log->error('redirect_enable', 'Не смог поставить next_run_at: ' . $e->getMessage());
            $this->setStatusFailed($jobId, 'redirect_enable: не смог запланировать retry');
        }
        return;
    }

    /**
     * v18.1.24: adaptive backoff для smoke retry. Никогда не останавливается.
     */
    private function computeSmokeRetryDelay(int $elapsedSec): int
    {
        if ($elapsedSec < 5 * 60)    return 60;          // < 5 мин → 60 сек
        if ($elapsedSec < 15 * 60)   return 2 * 60;      // < 15 мин → 2 мин
        if ($elapsedSec < 30 * 60)   return 5 * 60;      // 15-30 мин → 5 мин
        if ($elapsedSec < 6 * 3600)  return 30 * 60;     // 30 мин - 6 ч → 30 мин
        if ($elapsedSec < 3 * 86400) return 3600;        // 6 ч - 3 дня → 1 час
        if ($elapsedSec < 7 * 86400) return 6 * 3600;    // 3-7 дней → 6 часов
        return 24 * 3600;                                 // 7+ дней → раз в сутки
    }

    /**
     * v18.1.24: однократный TG-аларт «ждём smoke» через 30 мин fail'ов.
     * НЕ останавливает джобу. Только уведомляет оператора что polling
     * продолжается с разрядкой.
     */
    private function sendSmokeWaitingAlert(
        int $jobId,
        array $job,
        string $newDomain,
        string $smokePath,
        int $attemptCount,
        array $lastSmoke,
        JobEventLogger $log
    ): void {
        try {
            $tg = $this->makeTelegramService();
            $oldSafe = htmlspecialchars((string)$job['old_domain'], ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
            $pathSafe = htmlspecialchars($smokePath, ENT_QUOTES, 'UTF-8');
            $reasonSafe = htmlspecialchars((string)($lastSmoke['reason'] ?? '?'), ENT_QUOTES, 'UTF-8');
            $jobUrl = $this->buildJobUrl($jobId);

            $tg->send(
                "⏳ <b>refresh #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "Стадия: redirect_enable — прошло 30 минут, smoke ещё не прошёл\n" .
                "Path: <code>{$pathSafe}</code> (после {$attemptCount} проверок)\n" .
                "Последняя причина: {$reasonSafe}\n\n" .
                "<b>Это нормально</b> — обычные причины: DNS пропагация (5-30 мин), " .
                "opcache PHP-FPM, кеш CDN/DDoS-Guard.\n" .
                "Джоба <b>продолжает проверять</b> с разрядкой:\n" .
                "• следующие 6 часов — каждые 30 мин\n" .
                "• до 3 суток — каждый час\n" .
                "• до недели — каждые 6 часов\n" .
                "• потом раз в сутки\n\n" .
                "Действий <b>не требуется</b>. Когда редирект заработает — pipeline пойдёт дальше." .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('redirect_enable', 'Telegram smoke-waiting alert failed: ' . $e->getMessage());
        }
    }

    /**
     * v18.1.13: smoke-test /play — ОДНА попытка.
     *
     * Архитектурное изменение: retry теперь distributed (через cron+next_run_at),
     * не через sleep() внутри одной cron-итерации. См. runRedirectEnableStage.
     *
     * Причина: cron PHP CLI имеет max_execution_time. `sleep(60)` блокировал
     * worker и при определённых условиях процесс убивался watchdog'ом, оставляя
     * стадию в `running` с пустым next_run_at — это deadlock.
     *
     * Возвращает: {ok: bool, reason: string, http_code: int, location: string, redirect_type: string}
     */
    /**
     * v18.1.13: smoke-test /play — ОДНА попытка с retry через cron+next_run_at.
     *
     * v18.1.19: ВНУТРИ одного "тика" теперь chain из нескольких методов:
     *   1. curl с panel-сервера (как раньше) — основной, быстрый
     *   2. (если #1 timeout) — VPS-side smoke через FTP+php loopback на VPS
     *   3. (если #2 не сработал) — внешний публичный checker (httpstatus / hackertarget)
     *
     * Если ХОТЯ БЫ один из методов получил валидный 30x на партнёрку или
     * 200+meta-refresh — считаем pass. Это устраняет ложные failures когда
     * между панелью и VPS есть сетевая блокировка (DDoS-Guard, fail2ban,
     * region-block), но сайт сам по себе работает.
     */
    private function smokeTestRedirectPlay(array $job, JobEventLogger $log): array
    {
        return $this->smokeTestRedirectPlayChain($job, $log);
    }

    /**
     * v18.1.19: chain нескольких методов smoke-теста.
     *
     * Логика: пробуем методы по очереди, пока ХОТЯ БЫ ОДИН не вернёт ok=true.
     * Если все вернули fail — берём результат самого "информативного" (с http_code > 0
     * в приоритете перед timeout'ами).
     *
     * @return array {ok, reason, http_code, location?, redirect_type?, methods_tried[]}
     */
    private function smokeTestRedirectPlayChain(array $job, JobEventLogger $log): array
    {
        $newDomain = (string)$job['new_domain'];
        $jobId = (int)$job['id'];

        // v18.1.32: пробуем СПИСОК path-кандидатов, а не один.
        // Раньше: ОДИН path (detected или hardcoded /play). Если в шаблоне сайта
        // партнёрский path другой (/reg вместо /play или наоборот), smoke вечно фейлил.
        // Теперь: список — рабочий (если ранее подтверждался) → detected → defaults.
        $pathCandidates = $this->resolveSmokePathCandidates($job);
        $log->info('redirect_enable',
            "Smoke path-кандидаты: " . implode(', ', $pathCandidates));

        $vpsIp = $this->resolveVpsIpForJob($job, $log);

        $allowVpsSide = $this->isVpsSideSmokeAllowed();
        $allowExternal = $this->isExternalSmokeAllowed();

        $allPathResults = [];

        foreach ($pathCandidates as $pathIdx => $smokePath) {
            $url = 'https://' . $newDomain . $smokePath;
            $log->info('redirect_enable',
                "Smoke path " . ($pathIdx + 1) . "/" . count($pathCandidates) . ": '{$smokePath}'");

            $methodsResults = [];

            // === Method 1: curl from panel (browser UA + Referer) ===
            $log->info('redirect_enable', "Smoke method 1/4: curl from panel (browser UA), path={$smokePath}");
            $r1 = $this->panelCurlSmoke($url, $newDomain, $vpsIp, 'browser');
            $r1['method'] = 'panel_curl_browser';
            $r1['smoke_path'] = $smokePath;
            $methodsResults[] = $r1;
            if ($this->isValidRedirectResult($r1)) {
                $log->ok('redirect_enable', "Smoke method 1 ✓ на '{$smokePath}': " . $r1['reason']);
                $r1['methods_tried'] = array_map(fn($m) => $m['method'], $methodsResults);
                $r1['working_path'] = $smokePath;
                $this->rememberWorkingSmokePath($jobId, $smokePath, $log);
                return $r1;
            }
            $log->info('redirect_enable',
                "Smoke method 1 не подтвердил (" . ($r1['reason'] ?? '?') . "), пробую следующий метод");

            // === Method 2: curl from panel (YandexBot UA) ===
            $log->info('redirect_enable', "Smoke method 2/4: curl from panel (YandexBot UA)");
            $r2 = $this->panelCurlSmoke($url, $newDomain, $vpsIp, 'yandexbot');
            $r2['method'] = 'panel_curl_yandexbot';
            $r2['smoke_path'] = $smokePath;
            $methodsResults[] = $r2;
            if ($this->isValidRedirectResult($r2)) {
                $log->ok('redirect_enable', "Smoke method 2 ✓ на '{$smokePath}': " . $r2['reason']);
                $r2['methods_tried'] = array_map(fn($m) => $m['method'], $methodsResults);
                $r2['working_path'] = $smokePath;
                $this->rememberWorkingSmokePath($jobId, $smokePath, $log);
                return $r2;
            }
            $log->info('redirect_enable',
                "Smoke method 2 не подтвердил (" . ($r2['reason'] ?? '?') . "), пробую следующий метод");

            // === Method 3: VPS-side smoke ===
            if ($allowVpsSide) {
                $log->info('redirect_enable', "Smoke method 3/4: VPS-side loopback (через FTP)");
                $r3 = $this->vpsSideSmoke($newDomain, (int)$job['site_id'], $vpsIp, $log, $smokePath);
                $r3['method'] = 'vps_side_loopback';
                $r3['smoke_path'] = $smokePath;
                $methodsResults[] = $r3;
                if ($this->isValidRedirectResult($r3)) {
                    $log->ok('redirect_enable', "Smoke method 3 ✓ на '{$smokePath}': " . $r3['reason']);
                    $r3['methods_tried'] = array_map(fn($m) => $m['method'], $methodsResults);
                    $r3['working_path'] = $smokePath;
                    $this->rememberWorkingSmokePath($jobId, $smokePath, $log);
                    return $r3;
                }
                $log->info('redirect_enable',
                    "Smoke method 3 не подтвердил (" . ($r3['reason'] ?? '?') . "), пробую следующий метод");
            } else {
                $log->info('redirect_enable', "Smoke method 3 (VPS-side) пропущен — отключён в настройках");
            }

            // === Method 4: external smoke ===
            if ($allowExternal) {
                $log->info('redirect_enable', "Smoke method 4/4: external HTTP checker");
                $r4 = $this->externalSmoke($url, $newDomain);
                $r4['method'] = 'external_checker';
                $r4['smoke_path'] = $smokePath;
                $methodsResults[] = $r4;
                if ($this->isValidRedirectResult($r4)) {
                    $log->ok('redirect_enable', "Smoke method 4 ✓ на '{$smokePath}': " . $r4['reason']);
                    $r4['methods_tried'] = array_map(fn($m) => $m['method'], $methodsResults);
                    $r4['working_path'] = $smokePath;
                    $this->rememberWorkingSmokePath($jobId, $smokePath, $log);
                    return $r4;
                }
                $log->info('redirect_enable',
                    "Smoke method 4 не подтвердил (" . ($r4['reason'] ?? '?') . ")");
            } else {
                $log->info('redirect_enable', "Smoke method 4 (external) пропущен — отключён в настройках");
            }

            // Все 4 метода на этом path failed → переходим к следующему
            $log->info('redirect_enable',
                "Все методы на path '{$smokePath}' не подтвердили редирект. " .
                ($pathIdx + 1 < count($pathCandidates)
                    ? "Пробую следующий path."
                    : "Path-кандидаты исчерпаны."));
            $allPathResults = array_merge($allPathResults, $methodsResults);
        }

        // Все path × все методы failed. Берём самый информативный.
        $best = $allPathResults[0] ?? ['ok' => false, 'reason' => 'no results', 'http_code' => 0];
        foreach ($allPathResults as $r) {
            if (($r['http_code'] ?? 0) > 0 && ($best['http_code'] ?? 0) === 0) {
                $best = $r;
            }
        }
        $best['methods_tried'] = array_map(
            fn($m) => ($m['smoke_path'] ?? '?') . ':' . $m['method'] . ':' . ($m['http_code'] ?? '?') . ($m['ok'] ? '✓' : '✗'),
            $allPathResults);
        $best['paths_tried'] = $pathCandidates;
        return $best;
    }

    private function isValidRedirectResult(array $r): bool
    {
        return !empty($r['ok']);
    }

    /** v18.1.19: VPS-side smoke включён? Можно отключить через site-settings или конфиг. */
    private function isVpsSideSmokeAllowed(): bool
    {
        // Безопасный default — разрешено. Может быть отключено через .env / settings.
        $env = getenv('REFRESH_VPS_SIDE_SMOKE');
        if ($env === 'false' || $env === '0') return false;
        return true;
    }

    /** v18.1.19: external smoke включён? Зависит от наличия исходящего интернета у панели. */
    private function isExternalSmokeAllowed(): bool
    {
        $env = getenv('REFRESH_EXTERNAL_SMOKE');
        if ($env === 'false' || $env === '0') return false;
        return true;
    }

    /**
     * v18.1.19: curl smoke с панели — переименован из smokeTestRedirectPlaySingleAttempt.
     * Поддерживает 2 типа UA: 'browser' (Chrome+google referer) или 'yandexbot'.
     */
    private function panelCurlSmoke(string $url, string $newDomain, ?string $vpsIp, string $uaType = 'browser'): array
    {
        // v18.1.24: извлекаем path из URL для динамических reason-messages
        // (раньше тут был хардкод "/play" в строках ошибок)
        $smokePathFromUrl = parse_url($url, PHP_URL_PATH) ?: '/';

        $resolveArg = '';
        if ($vpsIp !== null) {
            $resolveArg = sprintf(' --resolve %s:443:%s --resolve %s:80:%s',
                escapeshellarg($newDomain), escapeshellarg($vpsIp),
                escapeshellarg($newDomain), escapeshellarg($vpsIp));
        }

        if ($uaType === 'yandexbot') {
            $ua = 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)';
            // Без -e — yandexbot не должен иметь referer
            $refererArg = '';
        } else {
            $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';
            $refererArg = '-e "https://www.google.com/" ';
        }

        // v18.1.19: -m 15 (было 10) — даём чуть больше времени.
        // --connect-timeout 5 — если за 5 сек не TCP-handshake, точно не дозвонимся.
        $cmd = sprintf(
            'curl -kis --max-redirs 0 --connect-timeout 5 -m 15 --max-filesize 200000%s ' .
            '-A %s ' .
            '%s' .
            '-w "\n__SMOKE__http_code:%%{http_code}__redirect_url:%%{redirect_url}__" %s 2>&1',
            $resolveArg,
            escapeshellarg($ua),
            $refererArg,
            escapeshellarg($url)
        );
        $output = shell_exec($cmd);

        if ($output === null) {
            return ['ok' => false, 'reason' => 'curl упал (нет вывода)', 'http_code' => 0];
        }

        // v18.1.36: передаём реальный path в parser, чтобы reason-сообщения были
        // корректными (раньше parseCurlOutput ссылался на необъявленную переменную
        // $smokePathFromUrl и подставлял пустую строку → "неожиданный HTTP 404 на ").
        return $this->parseCurlOutput($output, $newDomain, $smokePathFromUrl);
    }

    /**
     * v18.1.19: парсит curl -is output. Вынесено чтобы переиспользовать в нескольких методах.
     */
    private function parseCurlOutput(string $output, string $newDomain, string $smokePath = '/play'): array
    {
        // v18.1.36: $smokePathFromUrl использовался в reason-строках ниже, но НЕ был
        // объявлен в этой функции (жил только в panelCurlSmoke). Из-за этого в UI
        // печаталось "неожиданный HTTP {code} на " с пустым path. Теперь path
        // передаётся параметром.
        $smokePathFromUrl = ($smokePath !== '') ? $smokePath : '/play';
        $httpCode = 0;
        $redirectUrl = '';
        if (preg_match('~__SMOKE__http_code:(\d+)__redirect_url:([^_]*)__~', $output, $m)) {
            $httpCode = (int)$m[1];
            $redirectUrl = trim($m[2]);
        }

        // Также вытащим Location из headers напрямую (на случай если curl-w формат не сработал)
        if ($redirectUrl === '' && preg_match('~^Location:\s*(.+?)\r?$~mi', $output, $m)) {
            $redirectUrl = trim($m[1]);
        }

        if ($httpCode === 0) {
            return ['ok' => false, 'reason' => 'curl не получил ответ (timeout?)', 'http_code' => 0];
        }

        if ($httpCode >= 500) {
            return [
                'ok' => false,
                'reason' => "сервер вернул {$httpCode} — сайт сломан",
                'http_code' => $httpCode,
            ];
        }

        // 200 — проверяем meta refresh / JS redirect в body
        if ($httpCode === 200) {
            $metaUrl = $this->extractRedirectFromBody($output, $newDomain);
            if ($metaUrl !== null) {
                $metaHost = parse_url($metaUrl, PHP_URL_HOST);
                return [
                    'ok' => true,
                    'reason' => "{$smokePathFromUrl} → 200 + meta/JS redirect → {$metaHost} (внешний домен — партнёрка работает)",
                    'http_code' => 200,
                    'location' => $metaUrl,
                    'redirect_type' => 'html_meta_or_js',
                ];
            }
            return [
                'ok' => false,
                'reason' => "{$smokePathFromUrl} вернул 200 OK без редиректа в HTML — партнёрский редирект НЕ применяется",
                'http_code' => 200,
            ];
        }

        // 30x — проверяем что Location указывает на ВНЕШНИЙ домен
        if ($httpCode >= 300 && $httpCode < 400) {
            if ($redirectUrl === '') {
                return [
                    'ok' => false,
                    'reason' => "получен {$httpCode}, но Location header пустой",
                    'http_code' => $httpCode,
                ];
            }
            $redirectHost = parse_url($redirectUrl, PHP_URL_HOST);
            $isExternalHost = $redirectHost !== null && $redirectHost !== ''
                && $redirectHost !== $newDomain
                && $redirectHost !== 'www.' . $newDomain;

            if ($isExternalHost) {
                return [
                    'ok' => true,
                    'reason' => "{$smokePathFromUrl} → {$httpCode} → {$redirectHost} (внешний домен — партнёрка работает)",
                    'http_code' => $httpCode,
                    'location' => $redirectUrl,
                    'redirect_type' => 'http_30x',
                ];
            }

            // v18.1.32 fallback: Location на тот же домен, но содержит партнёрские маркеры.
            // Бывает при scheme/host upgrade'ах в Apache.
            $partnerMarkers = ['partners7k', '/l/', '/r/', 'kpromooffer',
                               'promo-', 'partners-', 'partnersolymp', 'olymp-promo',
                               'stake-promo', 'slotwinredirect'];
            foreach ($partnerMarkers as $marker) {
                if (stripos($redirectUrl, $marker) !== false) {
                    return [
                        'ok' => true,
                        'reason' => "{$smokePathFromUrl} → {$httpCode} → location содержит '{$marker}' (партнёрский URL)",
                        'http_code' => $httpCode,
                        'location' => $redirectUrl,
                        'redirect_type' => 'http_30x_marker_match',
                    ];
                }
            }

            return [
                'ok' => false,
                'reason' => "редирект {$httpCode} ведёт на сам же домен ({$redirectUrl}), а не на партнёрку",
                'http_code' => $httpCode,
                'location' => $redirectUrl,
            ];
        }

        return [
            'ok' => false,
            'reason' => "неожиданный HTTP {$httpCode} на {$smokePathFromUrl}",
            'http_code' => $httpCode,
        ];
    }

    /**
     * v18.1.19: VPS-side smoke — заливаем 1-shot php скрипт на VPS через FTP,
     * запрашиваем его через https://newdomain/__smoke_NNN.php, парсим json-ответ,
     * удаляем файл.
     *
     * Внутри скрипт делает curl на http://127.0.0.1/play с Host: newdomain.
     * Это запрос на сам себя — никаких внешних сетевых блокировок.
     *
     * Если loopback недоступен (некоторые конфиги Apache), пробуем http://newdomain
     * напрямую — VPS из своей сети до своего же домена обычно доходит без проблем.
     */
    private function vpsSideSmoke(string $newDomain, int $siteId, ?string $vpsIp, JobEventLogger $log, string $smokePath = '/play'): array
    {
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $site = $st->fetch();
            if (!$site) {
                return ['ok' => false, 'reason' => 'VPS-side smoke: site not found', 'http_code' => 0];
            }

            // Уникальное имя файла — чтобы не конфликтовать с другими процессами
            $token = bin2hex(random_bytes(8));
            $scriptName = "__smoke_{$token}.php";

            // 1-shot PHP. Делает 2 попытки:
            //   а) curl http://127.0.0.1{$smokePath} с Host: newdomain
            //   б) если а упало — curl http://newdomain{$smokePath} напрямую
            // Возвращает JSON с http_code, location, body_excerpt.
            $phpCode = $this->buildVpsSmokePhpScript($newDomain, $smokePath);

            $ftp = $this->makeFtp(
                (string)$site['ftp_host'],
                (string)$site['ftp_user'],
                Crypto::decrypt((string)$site['ftp_pass_enc'])
            );
            $ftp->connect();
            try {
                $ftp->putContent($scriptName, $phpCode, null);
            } catch (\Throwable $e) {
                $ftp->disconnect();
                return ['ok' => false, 'reason' => 'VPS-side: FTP upload failed: ' . $e->getMessage(), 'http_code' => 0];
            }

            // Запрашиваем скрипт. URL — через тот же путь что smoke (https://newdomain/__smoke_xxx.php)
            $smokeUrl = 'https://' . $newDomain . '/' . $scriptName;
            $resolveArg = '';
            if ($vpsIp !== null) {
                $resolveArg = sprintf(' --resolve %s:443:%s', escapeshellarg($newDomain), escapeshellarg($vpsIp));
            }
            $cmd = sprintf(
                'curl -ks --connect-timeout 5 -m 20%s %s 2>&1',
                $resolveArg,
                escapeshellarg($smokeUrl)
            );
            $rawResponse = shell_exec($cmd);

            // Удаляем скрипт с VPS — НЕ должен оставаться (security: открытый curl proxy)
            try {
                $ftp->deleteFile($scriptName);
            } catch (\Throwable $e) {
                $log->warn('redirect_enable',
                    "VPS-side: не удалось удалить {$scriptName} — удали вручную: " . $e->getMessage());
            }
            $ftp->disconnect();

            if ($rawResponse === null || trim((string)$rawResponse) === '') {
                return [
                    'ok' => false,
                    'reason' => 'VPS-side: запрос скрипта не вернул ответа',
                    'http_code' => 0,
                ];
            }

            // Парсим JSON. Если не получилось — значит сам __smoke_xxx.php не запустился.
            $json = json_decode((string)$rawResponse, true);
            if (!is_array($json)) {
                // Возможно сайт перехватил запрос и отдал что-то своё
                return [
                    'ok' => false,
                    'reason' => 'VPS-side: ответ скрипта не JSON (вероятно перехвачено сайтом). Первые 200 символов: ' .
                                mb_substr((string)$rawResponse, 0, 200),
                    'http_code' => 0,
                ];
            }

            // Вытаскиваем результаты из JSON
            $loopback = $json['loopback'] ?? [];
            $external = $json['external'] ?? [];
            $best = $loopback;
            if (empty($loopback['http_code']) && !empty($external['http_code'])) {
                $best = $external;
            }

            $httpCode = (int)($best['http_code'] ?? 0);
            $location = (string)($best['location'] ?? '');
            $bodyExcerpt = (string)($best['body_excerpt'] ?? '');

            if ($httpCode === 0) {
                // v18.1.35: детальный лог почему оба varianta failed
                // (curl error/timeout vs apache отдал что-то странное)
                $loopErr = (string)($loopback['error'] ?? '');
                $loopHttp = (int)($loopback['http_code'] ?? 0);
                $extErr = (string)($external['error'] ?? '');
                $extHttp = (int)($external['http_code'] ?? 0);

                $diag = [];
                if ($loopHttp > 0) {
                    $diag[] = "loopback HTTP {$loopHttp} (location='" .
                        mb_substr((string)($loopback['location'] ?? ''), 0, 100) . "')";
                } elseif ($loopErr !== '') {
                    $diag[] = "loopback curl_error: " . mb_substr($loopErr, 0, 150);
                } else {
                    $diag[] = "loopback no response";
                }
                if ($extHttp > 0) {
                    $diag[] = "external HTTP {$extHttp} (location='" .
                        mb_substr((string)($external['location'] ?? ''), 0, 100) . "')";
                } elseif ($extErr !== '') {
                    $diag[] = "external curl_error: " . mb_substr($extErr, 0, 150);
                } else {
                    $diag[] = "external no response";
                }
                return [
                    'ok' => false,
                    'reason' => 'VPS-side: ' . implode('; ', $diag),
                    'http_code' => 0,
                    'vps_loopback' => $loopback,
                    'vps_external' => $external,
                ];
            }

            // Логика проверки — такая же как в parseCurlOutput
            if ($httpCode >= 300 && $httpCode < 400 && $location !== '') {
                $redirectHost = parse_url($location, PHP_URL_HOST);
                $isExternalHost = $redirectHost !== null && $redirectHost !== ''
                    && $redirectHost !== $newDomain
                    && $redirectHost !== 'www.' . $newDomain;

                if ($isExternalHost) {
                    return [
                        'ok' => true,
                        'reason' => "VPS-side: → {$httpCode} → {$redirectHost} (партнёрка)",
                        'http_code' => $httpCode,
                        'location' => $location,
                        'redirect_type' => 'http_30x',
                    ];
                }

                // v18.1.32 fallback: hostname == newDomain, но Location содержит
                // партнёрские маркеры в QUERY/path. Это бывает, например, если
                // Apache `Redirect 302 /play https://partners7k...` перебивается
                // глобальным http→https upgrade'ом, который меняет ОДНО — он берёт
                // ту же location и просто превращает scheme в https. Реальная
                // партнёрская ссылка всё равно внутри Location.
                $partnerMarkers = ['partners7k', '/l/', '/r/', 'kpromooffer',
                                   'promo-', 'partners-', 'partnersolymp', 'olymp-promo',
                                   'stake-promo', 'slotwinredirect'];
                foreach ($partnerMarkers as $marker) {
                    if (stripos($location, $marker) !== false) {
                        return [
                            'ok' => true,
                            'reason' => "VPS-side: → {$httpCode} → location содержит '{$marker}' (партнёрский URL)",
                            'http_code' => $httpCode,
                            'location' => $location,
                            'redirect_type' => 'http_30x_marker_match',
                        ];
                    }
                }
            }

            if ($httpCode === 200 && $bodyExcerpt !== '') {
                // Имитируем формат для extractRedirectFromBody — это headers + body
                $metaUrl = $this->extractRedirectFromBody(
                    "HTTP/1.1 200 OK\r\n\r\n" . $bodyExcerpt, $newDomain);
                if ($metaUrl !== null) {
                    $metaHost = parse_url($metaUrl, PHP_URL_HOST);
                    return [
                        'ok' => true,
                        'reason' => "VPS-side: /play → 200 + meta redirect → {$metaHost} (партнёрка)",
                        'http_code' => 200,
                        'location' => $metaUrl,
                        'redirect_type' => 'html_meta_or_js',
                    ];
                }
            }

            return [
                'ok' => false,
                'reason' => "VPS-side: получен {$httpCode}, но валидного редиректа на партнёрку нет",
                'http_code' => $httpCode,
                'vps_loopback' => $loopback,
                'vps_external' => $external,
            ];
        } catch (\Throwable $e) {
            return [
                'ok' => false,
                'reason' => 'VPS-side: исключение: ' . $e->getMessage(),
                'http_code' => 0,
            ];
        }
    }

    /** v18.1.19: php-скрипт для loopback smoke на VPS. Возвращает JSON. */
    private function buildVpsSmokePhpScript(string $newDomain, string $smokePath = '/play'): string
    {
        $domainEscaped = addslashes($newDomain);
        // Защита от инъекций: путь должен начинаться с / и содержать только безопасные символы.
        // v18.1.36: явно разрешаем голый '/' (homepage-redirect шаблоны) — регексп ниже
        // требует ≥1 символ после слэша, из-за чего '/' раньше подменялся на '/play'.
        if ($smokePath !== '/' && !preg_match('~^/[a-z0-9_/-]+$~i', $smokePath)) {
            $smokePath = '/play';
        }
        $pathEscaped = addslashes($smokePath);
        return <<<PHP
<?php
// 1-shot smoke probe. УДАЛЯЕТСЯ панелью сразу после запроса.
// Делает curl на {$smokePath} (loopback через 127.0.0.1 + Host header, и напрямую),
// возвращает JSON.
//
// v18.1.32: при получении 30x на тот же хост — делает второй запрос (1 hop),
// чтобы дойти до настоящего партнёрского редиректа. Apache часто делает
// http→https upgrade прежде чем выдать партнёрскую ссылку через mod_alias.
header('Content-Type: application/json; charset=utf-8');

function probe(\$url, \$hostHeader = null) {
    \$ch = curl_init(\$url);
    \$headers = [];
    if (\$hostHeader !== null) \$headers[] = 'Host: ' . \$hostHeader;
    curl_setopt_array(\$ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
        CURLOPT_REFERER => 'https://www.google.com/',
        CURLOPT_HTTPHEADER => \$headers,
    ]);
    \$resp = curl_exec(\$ch);
    \$info = curl_getinfo(\$ch);
    \$err  = curl_error(\$ch);
    curl_close(\$ch);
    if (\$resp === false) {
        return ['http_code' => 0, 'location' => '', 'error' => \$err, 'body_excerpt' => ''];
    }
    \$headerSize = \$info['header_size'] ?? 0;
    \$rawHeaders = substr(\$resp, 0, \$headerSize);
    \$body = substr(\$resp, \$headerSize);
    \$location = '';
    if (preg_match('~^Location:\s*(.+?)\r?\$~mi', \$rawHeaders, \$m)) {
        \$location = trim(\$m[1]);
    }
    return [
        'http_code'    => (int)\$info['http_code'],
        'location'     => \$location,
        'body_excerpt' => substr(\$body, 0, 2000),
    ];
}

// v18.1.32: 2-hop chain — если первый probe вернул 30x на тот же хост,
// делаем второй запрос на новый URL. Возвращаем итоговый результат + сами hops.
function probeChain(\$url, \$hostHeader, \$expectHost) {
    \$hop1 = probe(\$url, \$hostHeader);
    \$result = ['hop1' => \$hop1] + \$hop1;

    \$loc = \$hop1['location'] ?? '';
    \$code = \$hop1['http_code'] ?? 0;

    // Если 30x на тот же хост (например http→https upgrade) — делаем 2-й hop
    if (\$code >= 300 && \$code < 400 && \$loc !== '') {
        \$locHost = parse_url(\$loc, PHP_URL_HOST);
        if (\$locHost !== null && (strcasecmp(\$locHost, \$expectHost) === 0
                || strcasecmp(\$locHost, 'www.' . \$expectHost) === 0)) {
            // 2-й hop на новый URL (без Host header — теперь URL абсолютный)
            \$hop2 = probe(\$loc, null);
            \$result['hop2'] = \$hop2;
            // Итог берём из hop2 (если он успешный) — это путь который реально пройдёт юзер
            if ((\$hop2['http_code'] ?? 0) > 0) {
                \$result['http_code'] = \$hop2['http_code'];
                \$result['location'] = \$hop2['location'];
                \$result['body_excerpt'] = \$hop2['body_excerpt'];
            }
        }
    }
    return \$result;
}

\$result = [
    'probed_at' => date('c'),
    'loopback'  => probeChain('http://127.0.0.1{$pathEscaped}', '{$domainEscaped}', '{$domainEscaped}'),
    'external'  => probeChain('http://{$domainEscaped}{$pathEscaped}', null, '{$domainEscaped}'),
];

echo json_encode(\$result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
PHP;
    }

    /**
     * v18.1.19: external smoke через публичный HTTP-checker.
     *
     * Используем hackertarget.com/http-header-check (бесплатный, лимит ~50/день,
     * не требует API key, возвращает text/plain с заголовками).
     *
     * Альтернативы которые НЕ используем (требуют JS/API key):
     *   - httpstatus.io — JS-only frontend
     *   - urlscan.io — требует API key
     *
     * @return array {ok, reason, http_code, location?, redirect_type?}
     */
    private function externalSmoke(string $url, string $newDomain): array
    {
        // hackertarget.com просто GET'ит URL и возвращает заголовки и meta.
        $apiUrl = 'https://api.hackertarget.com/httpheaders/?q=' . rawurlencode($url);

        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'refresh-panel-smoke/1.0',
        ]);
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $apiCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $body === '') {
            return [
                'ok' => false,
                'reason' => 'External smoke: hackertarget недоступен (' . $err . ')',
                'http_code' => 0,
            ];
        }
        if ($apiCode !== 200) {
            return [
                'ok' => false,
                'reason' => "External smoke: hackertarget вернул HTTP {$apiCode}",
                'http_code' => 0,
            ];
        }

        // Парсим текст. Формат hackertarget'а:
        //   HTTP/1.1 302 Found
        //   Server: ...
        //   Location: https://...
        $body = (string)$body;
        $httpCode = 0;
        if (preg_match('~^HTTP/[\d.]+ (\d{3})~m', $body, $m)) {
            $httpCode = (int)$m[1];
        }
        $location = '';
        if (preg_match('~^Location:\s*(.+?)\r?$~mi', $body, $m)) {
            $location = trim($m[1]);
        }

        // hackertarget может вернуть error message в теле
        if ($httpCode === 0 && stripos($body, 'error') !== false) {
            return [
                'ok' => false,
                'reason' => 'External smoke: hackertarget вернул error — ' . mb_substr($body, 0, 200),
                'http_code' => 0,
            ];
        }

        if ($httpCode === 0) {
            return [
                'ok' => false,
                'reason' => 'External smoke: не смог распарсить ответ hackertarget',
                'http_code' => 0,
            ];
        }

        if ($httpCode >= 300 && $httpCode < 400 && $location !== '') {
            $redirectHost = parse_url($location, PHP_URL_HOST);
            if ($redirectHost !== null && $redirectHost !== '' && $redirectHost !== $newDomain) {
                return [
                    'ok' => true,
                    'reason' => "External: /play → {$httpCode} → {$redirectHost} (партнёрка работает)",
                    'http_code' => $httpCode,
                    'location' => $location,
                    'redirect_type' => 'http_30x',
                ];
            }
        }

        // External checker не отдаёт body, поэтому meta-refresh здесь не парсим
        return [
            'ok' => false,
            'reason' => "External: получен {$httpCode}, но валидного редиректа на партнёрку не видно",
            'http_code' => $httpCode,
        ];
    }

    /** v18.1.13 (deprecated): вызов остался для обратной совместимости. */
    private function smokeTestRedirectPlaySingleAttempt(string $newDomain, array $job, JobEventLogger $log): array
    {
        $vpsIp = $this->resolveVpsIpForJob($job, $log);
        // v18.1.24: используем детектированный path вместо хардкода /play
        $smokePath = $this->resolveSmokePath($job, $log);
        $url = 'https://' . $newDomain . $smokePath;
        return $this->panelCurlSmoke($url, $newDomain, $vpsIp, 'browser');
    }

    /**
     * v18.1.24: возвращает реальный redirect-path для smoke-теста.
     *
     * Приоритет:
     *   1. artifacts['redirect_path_stage']['path'] — детект из analyze_site
     *      (читает .htaccess / index.php / guard.php)
     *   2. Fallback на '/play' (исторический default 7k-шаблонов)
     *
     * Если детект не сработал (path = null) и нужно ТОЧНО узнать какой path
     * работает — можно вызвать probeSmokePathCandidates() которая делает HEAD
     * запросы на /play, /reg, /go, /redirect и берёт первый кто отвечает 30x.
     * Сейчас используем простой fallback на /play чтобы не тратить лишних 4-5
     * HTTP запросов в каждом smoke-тике.
     */
    private function resolveSmokePath(array $job, JobEventLogger $log): string
    {
        try {
            $artifacts = $this->loadArtifacts($job);
            $detected = (string)($artifacts['redirect_path_stage']['path'] ?? '');
            if ($detected !== '' && preg_match('~^/[a-z0-9_-]+$~i', $detected)) {
                return $detected;
            }
        } catch (\Throwable $e) {}
        // Fallback — старое поведение
        return '/play';
    }

    /**
     * v18.1.32: возвращает СПИСОК path'ов для smoke-теста.
     *
     * Раньше resolveSmokePath отдавал ОДИН path. Если detector не нашёл path
     * в .htaccess/index.php/guard.php, возвращался hardcoded /play — даже если
     * для конкретного сайта правильный path был /reg или /go.
     *
     * Теперь:
     *   1) Если найден already-working path (artifacts.redirect_path_stage.working_path) —
     *      первый в списке (предыдущий smoke на нём успел).
     *   2) Если detector нашёл path (artifacts.redirect_path_stage.path) — добавляем.
     *   3) Добавляем стандартный whitelist: /reg, /play, /go, /redirect, /partner.
     *   4) Дедуплицируем, сохраняем порядок.
     *
     * Smoke перебирает методы для path[0], если все failed — переходит к path[1] и т.д.
     */
    private function resolveSmokePathCandidates(array $job): array
    {
        $candidates = [];
        try {
            $artifacts = $this->loadArtifacts($job);
            $stage = $artifacts['redirect_path_stage'] ?? [];

            // 1) уже найденный рабочий path (если предыдущий smoke его подтвердил).
            //    v18.1.36: допускаем и '/' (homepage-redirect шаблоны mellstroy/enomo).
            $working = (string)($stage['working_path'] ?? '');
            if ($working === '/' || ($working !== '' && preg_match('~^/[a-z0-9_-]+$~i', $working))) {
                $candidates[] = $working;
            }

            // 2) detector
            $detected = (string)($stage['path'] ?? '');
            if ($detected !== '' && preg_match('~^/[a-z0-9_-]+$~i', $detected)) {
                $candidates[] = $detected;
            }
        } catch (\Throwable $e) {}

        // 3) стандартный набор fallback'ов в порядке популярности на наших шаблонах
        $defaults = ['/reg', '/play', '/go', '/redirect', '/partner'];
        foreach ($defaults as $p) {
            $candidates[] = $p;
        }

        // 4) v18.1.36: homepage '/' — ПОСЛЕДНИМ кандидатом.
        //    Часть шаблонов (mellstroy/enomo с guard.php) делает партнёрский редирект
        //    ТОЛЬКО на главной '/': guard.php подключён в index.php, а .htaccess не
        //    роутит /play|/reg|/go в index.php (и не имеет catch-all) — поэтому все
        //    path-кандидаты выше отдают 404/301-на-себя, хотя редирект РАБОТАЕТ на '/'.
        //    Ставим последним, чтобы не мешать path-специфичным шаблонам (7k: /play).
        $candidates[] = '/';

        // 5) дедуп с сохранением порядка
        return array_values(array_unique($candidates));
    }

    /**
     * v18.1.32: сохраняет working_path в artifacts после успешного smoke.
     * Следующие attempts будут идти сразу на этот path, без перебора.
     */
    private function rememberWorkingSmokePath(int $jobId, string $workingPath, JobEventLogger $log): void
    {
        try {
            $patch = ['redirect_path_stage' => [
                'working_path' => $workingPath,
                'working_path_confirmed_at' => date('Y-m-d H:i:s'),
            ]];
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('redirect_enable',
                'Не удалось сохранить working_path: ' . $e->getMessage());
        }
    }


    /**
     * v18.1.12: парсит curl-output (заголовки + body) и ищет HTML/JS redirect
     * на внешний домен (не newDomain).
     *
     * Поддерживаемые форматы:
     *   1. <meta http-equiv="refresh" content="0;url=...">
     *      (1win-шаблон + классический HTML redirect)
     *   2. window.location.href = "..."
     *      (JS redirect)
     *   3. window.location = "..." или document.location = "..."
     *   4. location.replace("...")
     *
     * Возвращает URL первого найденного редиректа на внешний домен, или null если нет.
     */
    private function extractRedirectFromBody(string $output, string $newDomain): ?string
    {
        // Отделяем body от headers (HTTP/x.x \r\n\r\n)
        $bodyStart = strpos($output, "\r\n\r\n");
        if ($bodyStart === false) {
            $bodyStart = strpos($output, "\n\n");
            if ($bodyStart === false) {
                $body = $output;
            } else {
                $body = substr($output, $bodyStart + 2);
            }
        } else {
            $body = substr($output, $bodyStart + 4);
        }

        // Убираем curl-w маркер из body если он попал
        $body = preg_replace('~\n?__SMOKE__http_code:\d+__redirect_url:[^_]*__\s*$~', '', $body);

        $candidates = [];

        // 1. <meta http-equiv="refresh" content="N;url=URL">
        if (preg_match('~<meta\s+[^>]*http-equiv\s*=\s*["\']refresh["\'][^>]*content\s*=\s*["\']?\s*\d+\s*;\s*url\s*=\s*([^"\'>\s]+)~i', $body, $m)) {
            $candidates[] = $m[1];
        }

        // 2. window.location.href = "URL"
        if (preg_match('~window\.location\.href\s*=\s*["\']([^"\']+)["\']~i', $body, $m)) {
            $candidates[] = $m[1];
        }

        // 3. window.location = "URL" / document.location = "URL"
        if (preg_match('~(?:window|document)\.location\s*=\s*["\']([^"\']+)["\']~i', $body, $m)) {
            $candidates[] = $m[1];
        }

        // 4. location.replace("URL") / location.assign("URL")
        if (preg_match('~location\.(?:replace|assign)\s*\(\s*["\']([^"\']+)["\']~i', $body, $m)) {
            $candidates[] = $m[1];
        }

        // Возвращаем ПЕРВЫЙ кандидат, который указывает на внешний домен
        foreach ($candidates as $url) {
            $url = trim(html_entity_decode($url));
            if ($url === '' || $url === '#') continue;
            $host = parse_url($url, PHP_URL_HOST);
            if ($host === null || $host === '' || $host === $newDomain) {
                // относительный или на сам себя — не считаем редиректом
                continue;
            }
            return $url;
        }

        return null;
    }

    /**
     * v18.1.8: после redirect_enable — проверяем что REFRESH-DISABLED маркеры
     * действительно исчезли из ключевых файлов (.htaccess, index.php).
     *
     * Скачивает файлы через FTP и ищет паттерны:
     *   - '# REFRESH-DISABLED:' (для .htaccess — Apache комментарий)
     *   - '// REFRESH-DISABLED:' (для index.php — PHP комментарий)
     *
     * Возвращает массив имён файлов в которых маркеры остались, или [] если всё ОК.
     *
     * Используем ту же base_path что в redirect_disabled_stage чтобы попасть в правильную
     * директорию (если у сайта alias structure типа /var/www/... .casino/).
     */
    private function verifyNoRefreshDisabledMarkers(array $job, JobEventLogger $log): array
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];

        // Загружаем артефакты чтобы понять base_path (где искать файлы)
        $artifacts = !empty($job['artifacts_json'])
            ? (json_decode((string)$job['artifacts_json'], true) ?: [])
            : [];

        // Ищем base_path сначала в redirect_disabled_stage, потом в replacement_plan
        $basePath = $artifacts['redirect_disabled_stage']['base_path']
                 ?? $artifacts['replacement_plan']['base_path']
                 ?? null;

        if ($basePath === null) {
            $log->info('redirect_enable',
                'Post-validation: base_path не найден в artifacts, пропускаю проверку');
            return [];
        }

        // Загружаем сайт для FTP credentials
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
            $st->execute([$siteId]);
            $site = $st->fetch();
            if (!$site || empty($site['ftp_host'])) {
                $log->info('redirect_enable',
                    'Post-validation: FTP не настроен, пропускаю проверку');
                return [];
            }
        } catch (\Throwable $e) {
            $log->info('redirect_enable',
                'Post-validation: DB error, пропускаю: ' . $e->getMessage());
            return [];
        }

        try {
            $ftpPass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            $ftp = $this->makeFtp((string)$site['ftp_host'], (string)$site['ftp_user'], $ftpPass);
            $ftp->connect();
        } catch (\Throwable $e) {
            $log->info('redirect_enable',
                'Post-validation: FTP connect failed, пропускаю: ' . $e->getMessage());
            return [];
        }

        $remaining = [];
        $filesToCheck = ['.htaccess', 'index.php'];

        foreach ($filesToCheck as $fileName) {
            $remoteAbs = $basePath === '' ? $fileName : (rtrim($basePath, '/') . '/' . $fileName);
            try {
                $content = $ftp->tryGetContent($remoteAbs);
            } catch (\Throwable $e) {
                $log->info('redirect_enable',
                    "Post-validation: не получилось скачать {$fileName}: " . $e->getMessage());
                continue;
            }
            if (!is_string($content) || $content === '') {
                continue;
            }

            // Ищем маркеры
            // # REFRESH-DISABLED: (htaccess style)
            // // REFRESH-DISABLED: (PHP style)
            if (preg_match('~^\s*(?:#|//)\s*REFRESH-DISABLED:~m', $content)) {
                $remaining[] = $fileName;
                $log->warn('redirect_enable',
                    "Post-validation: в {$fileName} найден REFRESH-DISABLED маркер (редирект всё ещё выключен)");
            }
        }

        try { $ftp->disconnect(); } catch (\Throwable $e) {}
        return $remaining;
    }

    /**
     * Handler стадии ssl_le_polling (v14b) — multi-tick.
     *
     * Запрашивает LE сертификат и ждёт его выпуска через DNS-01 challenge
     * (мы за DDoS-Guard, http-01 невозможен).
     *
     * Каждый tick:
     *   - Tick 1: создать cert, получить TXT, push в Namecheap, resume
     *   - Tick 2-N: проверить статус. Ready → applyToSite → done. Errored → решить.
     *
     * После N тиков (15 = ~15 минут) сдаёмся: оставляем self-signed,
     * переходим на done. Пользователь может потом руками довыпустить через FP UI.
     *
     * Между тиками — пауза 60сек через next_run_at.
     */
    /**
     * v25.2-a1: один Telegram при ПЕРЕХОДЕ в transient SSL-состояние
     * (rate_limited / timeout_6h / restart_blocked). Anti-spam по alert_key в
     * artifacts.ssl_le_stage.last_alert_key; повтор того же — тишина.
     */
    private function maybeSslTransientAlert(int $jobId, string $oldDomain, string $newDomain, array $decision, JobEventLogger $log): void
    {
        $key = (string)($decision['alert_key'] ?? '');
        if ($key === '') return;
        try {
            $st = DB::pdo()->prepare("SELECT artifacts_json FROM refresh_jobs WHERE id=?");
            $st->execute([$jobId]);
            $arts = json_decode((string)$st->fetchColumn(), true) ?: [];
            $prevKey = (string)($arts['ssl_le_stage']['last_alert_key'] ?? '');
            if ($prevKey === $key) return; // уже уведомляли об этом состоянии

            $patch = ['ssl_le_stage' => ['last_alert_key' => $key, 'last_alert_at' => date('Y-m-d H:i:s')]];
            DB::pdo()->prepare("UPDATE refresh_jobs SET artifacts_json=JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id=?")
                ->execute([json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);

            $label = [
                'rate_limit'        => "🚦 Rate-limit Let's Encrypt — ждём и продолжаем автоматически",
                'long_wait'         => "⏳ SSL выпускается дольше обычного — продолжаем автоматически",
                'restart_cooldown'  => "♻️ Auto-restart на cooldown — продолжаем существующий issuance",
            ][(string)($decision['telegram_hint'] ?? '')] ?? "ℹ️ SSL issuance продолжается";

            $tg = $this->makeTelegramService();
            $jobUrl = $this->buildJobUrl($jobId);
            $oldSafe = htmlspecialchars($oldDomain, ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
            $tg->send(
                "⏳ <b>refresh #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "SSL: {$label}\n" .
                "Джоба НЕ остановлена — выпуск продолжается автоматически." .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('ssl_le_polling', 'Transient SSL alert failed: ' . $e->getMessage());
        }
    }

    private function runSslLeStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        if ($newDomain === '') {
            $log->warn('ssl_le_polling', 'new_domain пуст, пропускаем');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // v25.2-a1.1 (§Блокер 2): единственный владелец выпуска — TrustedSslReconciler.
        // runSslLeStage НЕ вызывает pollLetsEncrypt напрямую, а делегирует. Это
        // исключает двойной вызов ACME в одном cron-tick (throttle + issue-lock
        // общие, reconciler в конце тика пропустит эту джобу по ssl_issue_next_poll_at).
        $reconciler = new TrustedSslReconciler();
        $decision = $reconciler->reconcileJob($jobId);
        $dkind = (string)($decision['decision'] ?? '');
        $status = (string)($decision['status'] ?? '');

        if ($dkind === 'skipped_lock' || $dkind === 'skipped_same_tick') {
            // Кто-то уже выпускает эту джобу в этом тике/процессе — просто подождём.
            try {
                DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='pending', next_run_at=DATE_ADD(NOW(), INTERVAL 15 SECOND) WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
            } catch (\Throwable $e) {}
            return;
        }

        if ($dkind === SslOutcomeClassifier::DECISION_ISSUED || $status === 'issued') {
            // Сертификат выпущен и применён (reconciler уже сделал SSL-check + nudge).
            $log->ok('ssl_le_polling', '✓ LE сертификат выпущен и применён — стадия завершена.');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        if ($dkind === SslOutcomeClassifier::DECISION_FATAL) {
            // Reconciler уже перевёл джобу в awaiting_user (fatal на ssl_le_polling)
            // и сохранил fatal в artifacts + один Telegram. Ничего не дублируем.
            $log->error('ssl_le_polling', 'SSL выпуск остановлен (fatal): ' . (string)($decision['message'] ?? ''));
            return;
        }

        // TRANSIENT — reconciler уже назначил next_run_at (pending). Джоба продолжит
        // автоматически; awaiting_user не ставим.
        $log->info('ssl_le_polling',
            'Сертификат выпускается. Следующая автоматическая проверка через 30 секунд.',
            ['event_code' => 'ssl.issuance_waiting', 'next_check_seconds' => 30,
             'technical_reason' => (string)($decision['reason'] ?? 'pending')]);
    }

    /**
     * Сформировать URL карточки джобы для Telegram-алерта.
     * Вернёт пустую строку если 'app.url' не задано в config/app.php.
     */
    /**
     * v14i: определяет, упала ли verify из-за DNS race condition (новый домен ещё
     * не пропагирован), в отличие от реальной проблемы с заменой.
     *
     * Маркер DNS race — упал new_http И/ИЛИ new_robots с сообщением
     * "Could not resolve host". Если нет хоть одного такого упавшего —
     * это НЕ DNS race.
     *
     * @deprecated v18: используйте isRetryableVerifyFailure (более широкий)
     */
    private function isDnsRaceFailure(array $verifyResult): bool
    {
        $checks = $verifyResult['checks'] ?? [];
        $failed = $verifyResult['failed_checks'] ?? [];

        if (empty($failed)) return false;

        $newOnly = ['new_http', 'new_robots'];
        foreach ($failed as $name) {
            if (!in_array($name, $newOnly, true)) {
                return false;
            }
        }

        foreach ($failed as $name) {
            $msg = (string)($checks[$name]['message'] ?? '');
            if (stripos($msg, 'resolve host') !== false
                || stripos($msg, "Couldn't resolve") !== false
                || stripos($msg, 'name resolution') !== false
                || stripos($msg, 'name or service not known') !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * v18-fix: определяет, является ли провал verify_replacement
     * "ретраиваемым" (т.е. может пройти сама через 1-15 минут).
     *
     * РЕТРАИВАЕМЫЕ ситуации:
     *   1. DNS race — "Could not resolve host" (новый домен не пропагирован)
     *   2. Кеш CDN/nginx — HTTP 200, но контент robots.txt не тот
     *      (старый robots на новом домене или новый на старом)
     *   3. OPCache PHP — robots.php / config.php ещё не подхватили обновления
     *   4. 5xx от downstream сервиса (DDoS-Guard origin прогревается, etc.)
     *   5. Connection timeout / refused (промежуточная сеть)
     *
     * НЕ-РЕТРАИВАЕМЫЕ (нужен оператор):
     *   1. HTTP 4xx (404, 403) — что-то реально сломано
     *   2. SSL ошибки (cert mismatch, expired) — нужно проверить SSL
     *   3. robots отдаёт правильный код, но контент СОВСЕМ не похож на robots
     *      (HTML страница вместо robots.txt — типичный "DDoS-Guard challenge")
     *
     * Стратегия: возвращаем true (ретраить) если хотя бы ОДИН failed-чек
     * выглядит ретраиваемым. Это либеральнее чем "все ретраиваемые", но
     * после 5 попыток (~12 мин) всё равно перейдём в awaiting_user.
     */
    private function isRetryableVerifyFailure(array $verifyResult): bool
    {
        $checks = $verifyResult['checks'] ?? [];
        $failed = $verifyResult['failed_checks'] ?? [];

        if (empty($failed)) return false;

        foreach ($failed as $name) {
            $check = $checks[$name] ?? [];
            $msg = (string)($check['message'] ?? '');
            $http = (int)($check['http_code'] ?? 0);

            // (1) DNS race
            if (stripos($msg, 'resolve host') !== false
                || stripos($msg, "couldn't resolve") !== false
                || stripos($msg, 'name resolution') !== false
                || stripos($msg, 'name or service not known') !== false) {
                return true;
            }

            // (4) 5xx — серверная транзиентная ошибка
            if ($http >= 500 && $http < 600) {
                return true;
            }

            // (5) Сетевые тайматы / connection refused
            if (stripos($msg, 'timed out') !== false
                || stripos($msg, 'timeout') !== false
                || stripos($msg, 'connection refused') !== false
                || stripos($msg, 'connection reset') !== false) {
                return true;
            }

            // (2)+(3) Кеш / OPCache: HTTP 200 (или 3xx), но robots проверка не прошла
            // Это касается именно robots-чеков (new_robots, old_robots)
            if (($name === 'new_robots' || $name === 'old_robots')
                && $http >= 200 && $http < 400) {
                // Если HTTP ок, но проверка robots провалилась — это либо кеш
                // либо OPCache, либо реально неправильный robots. Ретраим —
                // если действительно неправильный, то пройдём 5 попыток и
                // затем awaiting_user.
                return true;
            }

            // Любой other failed чек — НЕ ретраим
        }

        return false;
    }

    /**
     * v18-fix: описывает в человеко-читаемой форме ПОЧЕМУ делаем retry.
     * Используется для логов и Telegram-уведомлений.
     */
    private function describeRetryReason(array $verifyResult): string
    {
        $checks = $verifyResult['checks'] ?? [];
        $failed = $verifyResult['failed_checks'] ?? [];

        $reasons = [];

        foreach ($failed as $name) {
            $check = $checks[$name] ?? [];
            $msg = (string)($check['message'] ?? '');
            $http = (int)($check['http_code'] ?? 0);

            if (stripos($msg, 'resolve host') !== false
                || stripos($msg, "couldn't resolve") !== false) {
                $reasons[] = 'DNS пропагация не успела';
                continue;
            }

            if ($http >= 500 && $http < 600) {
                $reasons[] = "{$name}: HTTP {$http} (5xx — сервер не готов)";
                continue;
            }

            if (stripos($msg, 'timeout') !== false) {
                $reasons[] = "{$name}: timeout";
                continue;
            }

            if (($name === 'new_robots' || $name === 'old_robots')
                && $http >= 200 && $http < 400) {
                $reasons[] = "{$name}: HTTP {$http}, но контент не тот (вероятно кеш)";
                continue;
            }

            $reasons[] = "{$name}: " . substr($msg, 0, 80);
        }

        return implode('; ', array_unique($reasons));
    }

    /**
     * v18-fix: получить IP VPS-сервера для --resolve fallback в SiteVerifier.
     *
     * Источники (в порядке приоритета):
     *   1. artifacts.vps_ip — кладётся туда на стадии domain_purchasing
     *   2. sites_managed.vps_ip — конфигурация сайта
     *
     * Возвращает null если IP не найден или не похож на валидный.
     */
    protected function resolveVpsIpForJob(array $job, JobEventLogger $log): ?string
    {
        // 1) из artifacts
        $artifacts = !empty($job['artifacts_json'])
            ? (json_decode((string)$job['artifacts_json'], true) ?: [])
            : [];
        $ip = (string)($artifacts['vps_ip'] ?? '');
        if ($ip !== '' && filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }

        // 2) из sites_managed
        try {
            $st = DB::pdo()->prepare("SELECT vps_ip FROM sites_managed WHERE id = ?");
            $st->execute([(int)$job['site_id']]);
            $ip2 = (string)$st->fetchColumn();
            if ($ip2 !== '' && filter_var($ip2, FILTER_VALIDATE_IP)) {
                return $ip2;
            }
        } catch (\Throwable $e) {
            $log->info('verify_replacement',
                'Не удалось получить vps_ip из sites_managed: ' . $e->getMessage());
        }

        return null;
    }

    /**
     * v18.1: загрузить ssl_le_enabled для сайта данной джобы.
     *
     * Возвращает true если в sites_managed.ssl_le_enabled=1, иначе false.
     * Используется в step() и nextStage() чтобы решать, выполнять ли ssl_le_polling.
     *
     * Не валит pipeline при ошибках — возвращает false (как default).
     */
    private function loadSslLeEnabledForJob(array $job): bool
    {
        $siteId = (int)($job['site_id'] ?? 0);
        if ($siteId === 0) return false;
        try {
            $st = DB::pdo()->prepare("SELECT ssl_le_enabled FROM sites_managed WHERE id = ?");
            $st->execute([$siteId]);
            return (bool)$st->fetchColumn();
        } catch (\Throwable $e) {
            // Возможно колонка ещё не добавлена (миграция 013 не применена) — вернём false
            return false;
        }
    }

    /**
     * v18.1.28: Defensive проверка pipeline state перед verify_replacement.
     *
     * Pipeline-инвариант: на стадии verify_replacement редирект должен быть
     * отключён в config.php (стадия redirect_disable уже отработала). Если
     * по какой-то причине редирект всё ещё включён ($redirect_enabled = 1),
     * это значит redirect_disable тихо упал — косяк скрипта. Восстанавливаем
     * pipeline state: повторно вызываем RedirectToggler::disable().
     *
     * Не возвращает ошибку — даже если disable повторно упал, дальнейший
     * verify Method 2/3 разберётся (и возможно сделает повторную попытку
     * disable как часть Method 3).
     *
     * Принцип: «если редирект должен быть выключен, а он вдруг включён —
     * это косяк скрипта, надо детектировать и исправлять».
     */
    private function ensureRedirectDisabledForVerify(array $job, JobEventLogger $log): void
    {
        $siteId = (int)($job['site_id'] ?? 0);
        $jobId = (int)$job['id'];
        if ($siteId === 0) return;

        // Скачиваем config.php через FTP, чтобы узнать реальное состояние
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
            $st->execute([$siteId]);
            $site = $st->fetch();
            if (!$site || empty($site['ftp_host']) || empty($site['ftp_user']) || empty($site['ftp_pass_enc'])) {
                return; // FTP не настроен — пропускаем defensive check
            }

            $ftpPass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            $ftp = $this->makeFtp((string)$site['ftp_host'], (string)$site['ftp_user'], $ftpPass);
            $ftp->connect();
            $configContent = $ftp->tryGetContent('config.php');
            try { $ftp->disconnect(); } catch (\Throwable $e) {}

            if (!is_string($configContent) || $configContent === '') {
                return; // config.php не нашли — defensive check невозможен
            }

            // Проверяем актуальное состояние $redirect_enabled
            // Ищем НЕзакомментированное `$redirect_enabled = 1`.
            // Если есть REFRESH-DISABLED маркер ('// REFRESH-DISABLED: $redirect_enabled = 1')
            // — это значит pipeline-disable отработал, редирект отключён.
            $hasRefreshMarker = preg_match(
                '~^\s*//\s*REFRESH-DISABLED\b.*\$redirect_enabled\s*=\s*1~m',
                $configContent
            ) === 1;
            $hasActiveEnable = preg_match(
                '~^(?!\s*//)\s*\$redirect_enabled\s*=\s*1\s*;~m',
                $configContent
            ) === 1;

            if ($hasRefreshMarker && !$hasActiveEnable) {
                // Всё ок — редирект корректно отключён pipeline-стадией.
                return;
            }

            if (!$hasActiveEnable) {
                // Нет ни маркера ни активного enable=1 — либо файл exotic, либо
                // редирект уже отключён через другое правило. Не вмешиваемся.
                return;
            }

            // ━━━ КОСЯК: редирект ВКЛЮЧЁН хотя должен быть отключён ━━━
            $log->warn('verify_replacement',
                '⚠ Pipeline state нарушен: $redirect_enabled = 1 в config.php, ' .
                'хотя стадия redirect_disable уже должна была отключить. ' .
                'Восстанавливаю инвариант: повторно отключаю редирект.');

            $toggler = new RedirectToggler();
            $result = $toggler->disable($siteId, $jobId, $log);
            if (!empty($result['ok'])) {
                $log->info('verify_replacement',
                    '✓ Pipeline state восстановлен: редирект отключён повторно ' .
                    '(' . count($result['applied_rules'] ?? []) . ' правил применено)');

                // Обновляем artifacts.redirect_disabled_stage чтобы UI и pipeline
                // имели актуальный state. JSON_MERGE_PATCH — merge не replace.
                try {
                    $patch = ['redirect_disabled_stage' => [
                        'ok' => true,
                        'applied_rules' => $result['applied_rules'] ?? [],
                        'snapshots' => $result['snapshots'] ?? [],
                        'base_path' => $result['base_path'] ?? '',
                        'redisable_at' => date('Y-m-d H:i:s'),
                        'redisable_reason' => 'pipeline state mismatch: $redirect_enabled was 1 on verify_replacement',
                    ]];
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET
                            artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                         WHERE id = ?"
                    )->execute([
                        json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                        $jobId,
                    ]);
                } catch (\Throwable $e) {
                    $log->warn('verify_replacement',
                        'Не удалось обновить artifacts после re-disable: ' . $e->getMessage());
                }
                sleep(2); // пауза для opcache
            } else {
                $log->error('verify_replacement',
                    '⚠ Не удалось восстановить state — re-disable редиректа упал: ' .
                    implode('; ', array_slice($result['errors'] ?? ['?'], 0, 2)) .
                    '. Verify попробует Method 3 (pipeline-aware temp-disable).');
            }
        } catch (\Throwable $e) {
            $log->warn('verify_replacement',
                'Defensive check (ensureRedirectDisabled) упал: ' . $e->getMessage() .
                '. Verify продолжит как обычно.');
        }
    }

    /**
     * v18.1.2: 5-я проверка для verify_replacement — анализ robots.php через FTP.
     *
     * Возвращает структуру совместимую с verify_stage.checks.* (либо null если
     * проверку нельзя выполнить и она не должна влиять на result).
     *
     * Поведение:
     *   1. Скачивает robots.php через FTP. Если не получается — null (skip).
     *   2. Прогоняет через RobotsPhpAnalyzer.
     *   3. Если ОК → возвращает {ok:true, message: 'robots.php имеет sameHost защиту'}
     *   4. Если НЕ ОК + autopatch_robots_php=1 (DEFAULT, включено для всех сайтов):
     *      - Перезаписываем robots.php рекомендуемым шаблоном через FTP
     *      - Возвращаем {ok:true, message: 'robots.php автоматически перезаписан', autopatched: true}
     *      - Pipeline продолжается без вмешательства оператора
     *   5. Если НЕ ОК + autopatch_robots_php=0 (выключено вручную для сайта):
     *      - Возвращаем {ok:false, message: 'robots.php требует правки', recommended_snippet: ...}
     *      - Это попадёт в failed_checks → джоба уйдёт в awaiting_user
     *      - Оператор правит файл руками или включает autopatch галкой и ретраит
     */
    private function checkAndMaybeAutopatchRobots(array $job, JobEventLogger $log): ?array
    {
        // Загружаем сайт
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
            $st->execute([(int)$job['site_id']]);
            $site = $st->fetch();
            if (!$site || empty($site['ftp_host']) || empty($site['ftp_user']) || empty($site['ftp_pass_enc'])) {
                $log->info('verify_replacement',
                    'robots_php_logic: FTP не настроен — пропускаем проверку');
                return null;
            }
        } catch (\Throwable $e) {
            $log->info('verify_replacement',
                'robots_php_logic: DB error — пропускаем проверку: ' . $e->getMessage());
            return null;
        }

        // v18.1.2: default = 1 (включено). Если миграция 014 не применена —
        // колонки нет в БД, ?? даст null → bool false. Поэтому используем
        // явную проверку: только если значение явно 0 — выключено.
        $autopatchValue = $site['autopatch_robots_php'] ?? 1;
        $autopatchEnabled = (int)$autopatchValue === 1;

        // Читаем robots.php через FTP
        $robotsContent = null;
        $ftp = null;
        try {
            $ftpPass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            $ftp = $this->makeFtp((string)$site['ftp_host'], (string)$site['ftp_user'], $ftpPass);
            $ftp->connect();
            $robotsContent = $ftp->tryGetContent('robots.php');
        } catch (\Throwable $e) {
            $log->info('verify_replacement',
                'robots_php_logic: FTP read failed — пропускаем: ' . $e->getMessage());
            if ($ftp) try { $ftp->disconnect(); } catch (\Throwable $e2) {}
            return null;
        }

        // Если файла нет — robots.txt видимо статический, skip
        if (!is_string($robotsContent) || $robotsContent === '') {
            $log->info('verify_replacement',
                'robots_php_logic: robots.php не найден — пропускаем (видимо robots.txt статический)');
            try { $ftp->disconnect(); } catch (\Throwable $e) {}
            return null;
        }

        // Анализируем
        $analyzer = new RobotsPhpAnalyzer();
        $analysis = $analyzer->analyze($robotsContent);

        if (!empty($analysis['ok'])) {
            try { $ftp->disconnect(); } catch (\Throwable $e) {}
            $log->info('verify_replacement',
                "robots_php_logic: ✓ " . $analysis['reason']);
            return [
                'ok' => true,
                'message' => 'robots.php имеет проверку домена и ветку Disallow: /',
                'has_host_check' => $analysis['has_host_check'],
                'has_disallow_branch' => $analysis['has_disallow_branch'],
                'reason' => $analysis['reason'],
            ];
        }

        // v18.1.28: ВАЖНОЕ ПЕРЕОПРЕДЕЛЕНИЕ.
        // Для сломанного шаблона (Allow:/ в "if (!sameHost)" branch) autopatch
        // ОБЯЗАТЕЛЕН независимо от site setting `autopatch_robots_php`.
        //
        // Логика: этот случай — это полностью сломанный шаблон, никакой "кастомной
        // логики" в нём нет (это просто опечатка Allow vs Disallow). Терять нечего,
        // оставлять как есть нельзя (старый домен открыт для поисковиков). Принцип:
        // «где можно починить самостоятельно — чинит сам, не дёргает оператора».
        if (!empty($analysis['broken_template'])) {
            if (!$autopatchEnabled) {
                $log->warn('verify_replacement',
                    'robots_php_logic: broken_template detected — включаю autopatch ' .
                    'принудительно (override site.autopatch_robots_php=0). ' .
                    'Сломанный шаблон не имеет "кастомной логики", терять нечего.');
                $autopatchEnabled = true;
            } else {
                $log->info('verify_replacement',
                    'robots_php_logic: broken_template detected, autopatch включён — чиним');
            }
        }

        // Файл некорректный
        $log->warn('verify_replacement',
            "robots_php_logic: ✗ " . $analysis['reason']);

        if ($autopatchEnabled) {
            // Autopatch — перезаписываем файл рекомендуемым шаблоном
            $newContent = $analyzer->getRecommendedSnippet();
            $log->info('verify_replacement',
                "robots_php_logic: autopatch_robots_php=1 → перезаписываю robots.php рекомендуемым шаблоном");

            // v18.1.3: СНАЧАЛА сохраняем backup в snapshot-директорию джобы
            // (та же, куда ReplacementApplier пишет snapshots для отката).
            // Это позволяет откатить robots.php кнопкой «↩️ Откатить snapshot».
            //
            // Также пишем .bak в FTP — на случай если snapshot-директория
            // недоступна, или для ручного восстановления через FTP.
            $jobId = (int)$job['id'];
            $snapshotDir = dirname(__DIR__, 2) . '/storage/snapshots/job_' . $jobId;
            $snapshotPath = $snapshotDir . '/robots_php.before.txt';
            $snapshotSaved = false;
            try {
                if (!is_dir($snapshotDir)) {
                    @mkdir($snapshotDir, 0775, true);
                }
                if (is_dir($snapshotDir)) {
                    $bytesWritten = @file_put_contents($snapshotPath, $robotsContent);
                    if ($bytesWritten !== false) {
                        $snapshotSaved = true;
                        $log->info('verify_replacement',
                            "robots_php_logic: backup сохранён в storage/snapshots/job_{$jobId}/robots_php.before.txt " .
                            "(" . strlen($robotsContent) . " байт)");
                    }
                }
            } catch (\Throwable $e) {
                $log->warn('verify_replacement',
                    "robots_php_logic: не удалось сохранить snapshot: " . $e->getMessage());
            }

            // FTP backup — рядом с файлом, .bak с timestamp.
            // Это backup второго уровня: если snapshot-директория накроется,
            // оригинал всё равно остаётся на FTP.
            $ftpBakPath = 'robots.php.bak_' . date('Ymd_His');
            $ftpBakSaved = false;
            try {
                // putContent с backupExt=null просто записывает файл.
                // Здесь записываем ОРИГИНАЛ как .bak (а не новый контент).
                $ftp->putContent($ftpBakPath, $robotsContent, null);
                $ftpBakSaved = true;
            } catch (\Throwable $e) {
                $log->info('verify_replacement',
                    "robots_php_logic: FTP .bak не создан (не критично, есть snapshot): " . $e->getMessage());
            }
            if ($ftpBakSaved) {
                $log->info('verify_replacement',
                    "robots_php_logic: FTP backup сохранён как {$ftpBakPath}");
            }

            try {
                // Передаём backupExt=null — мы УЖЕ сделали backup сами выше (двух видов),
                // не плодим лишние .bak файлы от putContent.
                $ftp->putContent('robots.php', $newContent, null);
                $ftp->disconnect();
                $log->ok('verify_replacement',
                    "robots_php_logic: ✓ файл перезаписан рекомендуемым шаблоном " .
                    "(snapshot=" . ($snapshotSaved ? 'yes' : 'no') . ", ftp_bak=" . ($ftpBakSaved ? 'yes' : 'no') . ")");

                // v18.1.3: добавляем robots.php в config_replaced_stage.snapshots
                // чтобы кнопка «↩️ Откатить snapshot» (RefreshJobController::rollback)
                // могла его восстановить вместе с остальными файлами.
                if ($snapshotSaved) {
                    try {
                        DB::pdo()->prepare(
                            "UPDATE refresh_jobs SET
                                artifacts_json = JSON_MERGE_PATCH(
                                    COALESCE(artifacts_json, '{}'),
                                    JSON_OBJECT(
                                        'config_replaced_stage',
                                        JSON_OBJECT(
                                            'snapshots',
                                            JSON_OBJECT('robots.php', 'robots_php.before.txt')
                                        )
                                    )
                                )
                             WHERE id = ?"
                        )->execute([$jobId]);
                        $log->info('verify_replacement',
                            "robots_php_logic: snapshot 'robots.php' добавлен в config_replaced_stage — кнопка отката его подхватит");
                    } catch (\Throwable $e) {
                        $log->warn('verify_replacement',
                            "robots_php_logic: не удалось добавить snapshot в config_replaced_stage: " . $e->getMessage());
                    }
                }

                return [
                    'ok' => true,
                    'message' => 'robots.php автоматически перезаписан (autopatch_robots_php=1). ' .
                                 'Backup: ' . ($snapshotSaved ? 'snapshot ✓' : 'snapshot ✗') . ', ' .
                                 ($ftpBakSaved ? 'FTP .bak ✓' : 'FTP .bak ✗'),
                    'autopatched' => true,
                    'previous_reason' => $analysis['reason'],
                    'snapshot_saved' => $snapshotSaved,
                    'snapshot_path' => $snapshotSaved ? "storage/snapshots/job_{$jobId}/robots_php.before.txt" : null,
                    'ftp_bak_saved' => $ftpBakSaved,
                    'ftp_bak_path' => $ftpBakSaved ? $ftpBakPath : null,
                ];
            } catch (\Throwable $e) {
                try { $ftp->disconnect(); } catch (\Throwable $e2) {}
                $log->error('verify_replacement',
                    "robots_php_logic: autopatch упал на записи — " . $e->getMessage());
                return [
                    'ok' => false,
                    'message' => 'robots.php требует правки, autopatch включён, но запись через FTP не удалась: ' . $e->getMessage(),
                    'reason' => $analysis['reason'],
                    'recommended_snippet' => $newContent,
                    'autopatch_attempted' => true,
                    'autopatch_failed' => true,
                ];
            }
        }

        // Autopatch выключен → возвращаем fail для awaiting_user
        try { $ftp->disconnect(); } catch (\Throwable $e) {}
        return [
            'ok' => false,
            'message' => "robots.php требует правки: " . $analysis['reason'],
            'has_host_check' => $analysis['has_host_check'],
            'has_disallow_branch' => $analysis['has_disallow_branch'],
            'reason' => $analysis['reason'],
            'details' => $analysis['details'],
            'recommended_snippet' => $analyzer->getRecommendedSnippet(),
            'robots_excerpt' => mb_substr($robotsContent, 0, 500),
            'autopatch_enabled' => false,
            // v18.1.28: пробрасываем сломанный шаблон + closed-branch анализ для UI
            'broken_template' => !empty($analysis['broken_template']),
            'closed_branch' => $analysis['closed_branch'] ?? null,
        ];
    }

    /**
     * v18-fix: подчистка старых .bak файлов на FTP сайта.
     *
     * Делается в analyze_site (когда у нас есть scanResult и base_path).
     * Подключается к FTP, листит корень сайта, удаляет .bak файлы старше 7 дней
     * которые подходят под наши паттерны. Не валит pipeline при ошибке —
     * это housekeeping шаг, не критичный.
     *
     * @return array|null result от BackupFileCleaner::cleanup() или null
     *                    если cleanup не получилось вообще запустить
     */
    private function cleanupOldBackupFiles(array $scanResult, int $jobId, JobEventLogger $log): ?array
    {
        // Загружаем сайт чтобы получить FTP-параметры
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
            $st->execute([(int)($scanResult['site_id'] ?? 0)]);
            $site = $st->fetch();

            // Если не нашли по scanResult.site_id, попробуем через job
            if (!$site) {
                // scanResult может не содержать site_id — берём из job напрямую
                $stJob = DB::pdo()->prepare("SELECT site_id FROM refresh_jobs WHERE id = ?");
                $stJob->execute([$jobId]);
                $jobSiteId = (int)$stJob->fetchColumn();
                if ($jobSiteId > 0) {
                    $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
                    $st->execute([$jobSiteId]);
                    $site = $st->fetch();
                }
            }

            if (!$site) {
                $log->warn('analyze_site',
                    'BackupFileCleaner: не нашёл сайт для cleanup, пропускаю (не критично)');
                return null;
            }
        } catch (\Throwable $e) {
            $log->warn('analyze_site',
                'BackupFileCleaner: DB error при загрузке сайта: ' . $e->getMessage());
            return null;
        }

        // Расшифровываем FTP пароль и подключаемся
        try {
            $ftpUser = (string)($site['ftp_user'] ?? '');
            $ftpHost = (string)($site['ftp_host'] ?? '');
            $ftpPassEnc = (string)($site['ftp_pass_enc'] ?? '');
            if ($ftpUser === '' || $ftpHost === '' || $ftpPassEnc === '') {
                $log->info('analyze_site',
                    'BackupFileCleaner: FTP параметры сайта не настроены, пропускаю');
                return null;
            }
            $ftpPass = Crypto::decrypt($ftpPassEnc);
            $ftp = $this->makeFtp($ftpHost, $ftpUser, $ftpPass);
            $ftp->connect();
        } catch (\Throwable $e) {
            $log->warn('analyze_site',
                'BackupFileCleaner: FTP connect failed: ' . $e->getMessage());
            return null;
        }

        $basePath = (string)($scanResult['base_path'] ?? '');

        try {
            $cleaner = new BackupFileCleaner($ftp, $log);
            $result = $cleaner->cleanup($basePath, 7);
        } catch (\Throwable $e) {
            $log->warn('analyze_site',
                'BackupFileCleaner exception: ' . $e->getMessage());
            $result = null;
        }

        try {
            $ftp->disconnect();
        } catch (\Throwable $e) {
            // не критично
        }

        return $result;
    }

    /**
     * v16: Стадия update_classes_call.
     *
     * Логика:
     *   1. Берём path из sites_managed.update_classes_url (если задан)
     *      → callUrl = https://<new_domain> + path
     *   2. Иначе — автодетект через FTP в корне сайта (v17.11):
     *      a) variant-refresh.php (новый формат enomo v3) → читаем config.php,
     *         извлекаем $variant_settings['manual_secret'],
     *         собираем /variant-refresh.php?k=<secret>
     *      b) update_classes.php (старый формат) → используем /update_classes.php (без секрета)
     *      Если ни того ни другого → пропускаем стадию (записываем skipped)
     *   3. Вызываем GET-запросом, ждём HTTP 2xx/3xx
     *   4. На любом сетевом фейле — warn (не блокируем pipeline)
     *
     * v17.10: update_classes_url теперь хранится как path (например
     * "/update_classes.php?token=X"), домен подставляется здесь.
     * Backward compat: если в БД оказался полный URL (со схемой) — используем как есть.
     */
    private function runUpdateClassesCallStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        if ($newDomain === '') {
            $log->warn('update_classes_call', 'new_domain пуст, пропускаю стадию');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // ═══ ТЗ 039 §10.2: рандомизация отключена оператором на уровне сайта ═══
        // uc_mode=disabled → HTTP=0, стадия завершается как «не используется».
        // Ветка срабатывает ТОЛЬКО если execution ещё не начинался: для
        // started/ambiguous/... решение принимают recovery-ветки/оператор ниже.
        $siteUc = ['uc_mode' => 'auto', 'uc_capability' => 'unknown'];
        try {
            $stUc = DB::pdo()->prepare("SELECT uc_mode, uc_capability FROM sites_managed WHERE id=?");
            $stUc->execute([$siteId]);
            $rowUc = $stUc->fetch();
            if (is_array($rowUc)) {
                $siteUc['uc_mode'] = (string)($rowUc['uc_mode'] ?? 'auto');
                $siteUc['uc_capability'] = (string)($rowUc['uc_capability'] ?? 'unknown');
            }
        } catch (\Throwable $e) { /* колонок 039 может ещё не быть — режим auto */ }
        if ($siteUc['uc_mode'] === 'disabled'
            && empty($job['php_uniquification_verified_at'])
            && !in_array($this->ucExecutionState($jobId),
                ['started', 'ambiguous', 'completed', 'verified', 'operator_skipped'], true)) {
            $this->saveUcStage($jobId, [
                'outcome' => 'not_applicable',
                'disabled_by_operator' => true,
                'uc_mode' => 'disabled',
                'decided_at' => date('Y-m-d H:i:s'),
            ]);
            $this->markUcState($jobId, 'completed');
            $log->ok('update_classes_call',
                'На этом сайте рандомизация классов отключена настройкой сайта. Этап пропущен автоматически, скрипт не вызывался.',
                ['event_code' => 'uc.disabled_by_site', 'technical_reason' => 'uc_mode=disabled']);
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // === v25.0-a: GATE готовности домена ПЕРЕД PHP-уникализацией ===
        // Смена классов трогает боевые PHP-файлы сайта. Запускать её, пока
        // новый домен не отвечает публично (нет DNS / self-signed SSL / не 200),
        // нельзя: это давало ложные PHP-ошибки на самом деле недоступного сайта.
        //
        // Реализовано как многотиковая подстадия БЕЗ изменения STAGES_ORDER:
        // стадия остаётся update_classes_call, но пока домен не готов —
        // DomainReadinessRunner планирует повторные проверки (301→200, streak
        // 2/2, probe-файл). Готовность фиксируется в domain_https_ready_at.
        //
        // Отключаемо флагом (на случай сайтов без публичного домена / отладки).
        if (AppSettings::getBool('readiness.enabled', true)
            && empty($job['domain_technical_ready_at'])
            && empty($job['domain_https_ready_at'])) {

            // Перечитываем СВЕЖУЮ джобу — cron мог выбрать её раньше, а мы уже
            // под job-lock'ом (CronController/runStep держат rfp_job_<id>).
            $fresh = $this->reloadJob($jobId) ?? $job;
            if (JobLifecycleService::isTerminal((string)$fresh['stage'])) {
                return; // закрыта/завершена — ничего не делаем
            }

            $runner = new DomainReadinessRunner();
            $result = $runner->tick($fresh, $log);

            if ($result === 'ready') {
                // Готово — падаем НИЖЕ и в этом же тике выполняем уникализацию.
                // Перечитаем джобу, чтобы дальше работать с domain_https_ready_at.
                $job = $this->reloadJob($jobId) ?? $job;
            } else {
                // waiting/awaiting_user/terminal — runner уже выставил статус и
                // next_run_at. Из стадии выходим, не трогая сайт.
                return;
            }
        }

        // === v25.0-a: серверный контроль перед фактической уникализацией ===
        // Даже если domain_https_ready_at стоит — делаем свежий контрольный
        // HTTPS-запрос. Если домен вдруг перестал давать 200 (SSL истёк, сайт
        // упал), это НЕ PHP-ошибка: retry уникализации не крутим, ошибку не
        // пишем, а возвращаемся к ожиданию готовности.
        if (AppSettings::getBool('readiness.enabled', true)
            && AppSettings::getBool('readiness.recheck_before_uniquification', true)) {

            $svc = $this->makeDomainReadinessService();
            $arts0 = $this->loadArtifacts($job);
            $token = (string)($arts0['domain_readiness_stage']['probe_token'] ?? '');
            $check = $svc->checkOnce($newDomain, $jobId, $token);

            // v25.1-a: НЕ требуем доверенный TLS. Достаточно технической
            // доступности (сайт реально отвечает на новом домене: 301→HTTPS
            // того же домена ИЛИ HTTPS 2xx/3xx, даже self-signed). Trusted SSL
            // нужен позже — для verification/recrawl, но не для смены классов.
            $reachable = !empty($check['technical_ready']);
            if (!$reachable) {
                $log->warn('update_classes_call',
                    'Домен пока недоступен из интернета. Панель автоматически проверит его снова через 30 секунд.',
                    ['event_code' => 'domain.awaiting_dns',
                     'next_check_seconds' => DomainReadinessService::normalIntervalSec(),
                     'technical_reason' => DomainReadinessService::explainReason((string)$check['reason'])]);
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET
                        domain_technical_ready_at = NULL,
                        domain_readiness_success_streak = 0,
                        stage_status = 'pending',
                        next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
                     WHERE id = ?
                       AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([DomainReadinessService::normalIntervalSec(), $jobId]);
                return;
            }
        }

        // PATCH_3 (§13): HTTPS smoke НЕ подтверждает. verification_pending / уже
        // начатый execution → FTP-проверка по ДОВЕРЕННОМУ корню (не response path).
        $arts0 = $this->loadArtifacts($job);
        $ucStage = $arts0['update_classes_stage'] ?? [];
        $prevExecEarly = $this->ucExecutionState($jobId);
        if ((!empty($ucStage['verification_pending'])
                || in_array($prevExecEarly, ['started','ambiguous','completed'], true))
            && empty($job['php_uniquification_verified_at'])) {
            $trust0 = $this->resolveTrustedPhysicalRoot($job, $siteId);
            if (($trust0['status'] ?? '') === 'conflict') {
                $log->warn('update_classes_call', 'update_classes_expected_root_conflict: ' . implode(' vs ', $trust0['roots'] ?? []));
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage_status='awaiting_user',
                        stage_error='update_classes: expected_physical_root_conflict', next_run_at=NULL
                      WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([$jobId]);
                return;
            }
            if (($trust0['status'] ?? '') !== 'ok') {
                $log->warn('update_classes_call', 'update_classes_expected_root_unknown: корень не определён — жду оператора.');
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage_status='awaiting_user',
                        stage_error='update_classes: expected_physical_root_unknown', next_run_at=NULL
                      WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([$jobId]);
                return;
            }
            $execStarted0 = (string)($ucStage['execution_started_at'] ?? ($job['uc_execution_started_at'] ?? ''));
            $sp0 = $this->loadSavedProfile($job);
            $savedScriptPath0 = (string)($ucStage['script_path'] ?? '');
            if (!is_array($sp0) && in_array($prevExecEarly, ['started','ambiguous'], true)) {
                // PATCH_6.1: первый вызов профиль не сохраняет (marker-based). Recovery строит
                // профиль ЛЕНИВО из script_path. Нет ни профиля, ни script_path → fail-closed.
                if ($savedScriptPath0 === '') {
                    $log->warn('update_classes_call', 'started/ambiguous без профиля и без script_path — verified по старым файлам запрещён. awaiting_user.');
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET stage_status='awaiting_user',
                            stage_error='update_classes: started_without_profile', next_run_at=NULL
                          WHERE id=? AND stage='update_classes_call'"
                    )->execute([$jobId]);
                    return;
                }
                $recP0 = $this->resolveVerificationProfile($job, (string)$trust0['root'], $savedScriptPath0);
                $recS0 = (string)($recP0['strategy'] ?? 'unknown');
                if (!in_array($recS0, ['class_mapping','variant_state','none'], true)) {
                    $log->warn('update_classes_call', 'recovery-формат неизвестен (' . $recS0 . ') — awaiting_user, без повторного вызова.');
                    DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL WHERE id=? AND stage='update_classes_call'")->execute(['update_classes: recovery_' . $recS0, $jobId]);
                    return;
                }
                // ТЗ046 ADDENDUM §8/§10: class_mapping recovery — только через delta-verifier,
                // BEFORE из сохранённого evidence (не текущий mapping). Без повторного HTTP.
                if ($recS0 === 'class_mapping') {
                    if ($this->recoverClassMappingByDelta($job, $log, (string)$trust0['root'], $recP0,
                            $this->loadSavedEvidence($job) ?: [], $prevExecEarly)) return;
                }
                $sp0 = $recP0; unset($sp0['state_before'], $sp0['evidence_before']);
                $popts = ['execution_started_at' => $execStarted0, 'profile' => $sp0,
                          'state_before' => ($recP0['state_before'] ?? null),
                          'evidence_before' => ['variant_state' => ($recP0['state_before'] ?? null),
                                                'class_mapping' => ($recP0['evidence_before']['class_mapping'] ?? null)]];
                $res0 = $this->verifyUniquificationByFtp($job, $log, (string)$trust0['root'], $popts);
                $this->settleUpdateClassesByFtp($jobId, $res0, ['stage' => (string)$job['stage']], $log);
                return;
            }
            $ev0 = $this->loadSavedEvidence($job);
            // ТЗ046 ADDENDUM: class_mapping — authoritative proof только delta-verifier.
            if (is_array($sp0) && (string)($sp0['strategy'] ?? '') === 'class_mapping') {
                if ($this->recoverClassMappingByDelta($job, $log, (string)$trust0['root'], (array)$sp0,
                        is_array($ev0) ? $ev0 : [], $prevExecEarly)) return;
            }
            $popts = ['execution_started_at' => $execStarted0];
            if (is_array($sp0)) $popts['profile'] = $sp0;
            if (is_array($ev0)) { if (isset($ev0['variant_state'])) $popts['state_before'] = $ev0['variant_state']; $popts['evidence_before'] = $ev0; }
            $res0 = $this->verifyUniquificationByFtp($job, $log, (string)$trust0['root'], $popts);
            $this->settleUpdateClassesByFtp($jobId, $res0, ['stage' => (string)$job['stage']], $log);
            return;
        }

        // 1. Кастомный path применяется ТОЛЬКО в режиме uc_mode=custom (ТЗ §8.1).
        $customContract = '';
        try {
            $st = DB::pdo()->prepare(
                "SELECT update_classes_url, uc_verification_contract FROM sites_managed WHERE id=?"
            );
            $st->execute([$siteId]);
            $rowC = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            $customPath = trim((string)($rowC['update_classes_url'] ?? ''));
            $customContract = trim((string)($rowC['uc_verification_contract'] ?? ''));
        } catch (\Throwable $e) {
            $customPath = '';
        }
        if ($siteUc['uc_mode'] !== 'custom') {
            $customPath = '';
        } elseif ($customPath === '') {
            // §8.1: в режиме custom update_classes_url обязателен.
            $log->warn('update_classes_call',
                'Для сайта включён режим кастомного адреса рандомизации, но сам адрес не задан. Запуск запрещён, нужно указать корректный URL/path.',
                ['event_code' => 'uc.custom_url_missing']);
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: custom_url_missing', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return;
        } elseif (!in_array($customContract, ['json_ok_true', 'exact_marker', 'ftp_profile'], true)) {
            // §7.2: custom URL без выбранного способа подтверждения результата —
            // HTTP=0, capability=needs_review, понятная причина.
            try {
                DB::pdo()->prepare("UPDATE sites_managed SET uc_capability='needs_review' WHERE id=?")->execute([$siteId]);
            } catch (\Throwable $e) {}
            $log->warn('update_classes_call',
                'Не настроен способ проверки результата для кастомного скрипта. Панель не будет запускать скрипт, пока не выбран способ подтверждения (строгий JSON, точный маркер или проверка файлов по FTP).',
                ['event_code' => 'uc.custom_contract_missing']);
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: custom_verification_contract_missing', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return;
        }

        $callUrl = '';
        $reason = '';

        if ($customPath !== '') {
            // v17.10: храним path, подставляем домен сами.
            if (preg_match('~^https?://~i', $customPath)) {
                // P0.8: полный URL допустим ТОЛЬКО если host == new_domain. old_domain
                // сам по себе НЕ достаточен (при переезде указывает на старый сайт).
                // Иной host — лишь при подтверждённом alias (тот же trusted root + site_id).
                $host = mb_strtolower((string)(parse_url($customPath, PHP_URL_HOST) ?: ''));
                $nd = mb_strtolower((string)$newDomain);
                $aliasOk = ($host !== '' && $host !== $nd) ? $this->isConfirmedAliasHost($host, $siteId, $job) : false;
                if ($host !== $nd && !$aliasOk) {
                    $log->warn('update_classes_call',
                        "custom_script_host_mismatch: URL host '{$host}' != new_domain '{$nd}' и не подтверждённый alias — вызов запрещён.");
                    DB::pdo()->prepare(
                        "UPDATE refresh_jobs SET stage_status='awaiting_user',
                            stage_error='update_classes: custom_script_host_mismatch', next_run_at=NULL
                          WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                    )->execute([$jobId]);
                    return;
                }
                $callUrl = $customPath;
                $reason = 'custom_full_url';
                $log->info('update_classes_call', "Полный URL из настроек, host подтверждён (" . ($aliasOk ? 'alias' : 'new_domain') . "): {$callUrl}");
            } else {
                // Path-only: подставляем https://<new_domain>
                if ($customPath[0] !== '/') $customPath = '/' . $customPath;
                $callUrl = 'https://' . $newDomain . $customPath;
                $reason = 'custom_path';
                $log->info('update_classes_call',
                    "Используется кастомный path '{$customPath}', собран URL: {$callUrl}");
            }
        } else {
            // 2. ТЗ 039 §7/§8: режим auto — live re-detect инспектором (read-only
            //    FTP, сигнатуры содержимого, секрет из live config.php). Источник
            //    истины — свежая проверка, кэш uc_capability в БД не используется
            //    для решения (§23.12); результат записывается в sites_managed.
            $log->info('update_classes_call',
                'Проверяю применимость рандомизации по FTP (live, только чтение файлов)...');

            $insp = $this->makeRandomizationInspector();
            $ir = $insp->inspectAndPersist($siteId);
            $irCap = (string)($ir['capability'] ?? 'ftp_error');
            // ревью P1: baseline capability_snapshot должен отражать СВЕЖИЙ
            // результат live-инспекции, а не устаревшее значение из БД.
            $siteUc['uc_capability'] = $irCap;
            $irDet = is_array($ir['detection'] ?? null) ? $ir['detection'] : [];
            $irBase = (string)($irDet['base'] ?? '');
            $detected = ['found' => false, 'status' => $irCap, 'filename' => '', 'path' => '',
                         'secret_extracted' => null, 'secret_source' => 'none',
                         'fingerprint_sha256' => (string)($irDet['files'][0]['fingerprint_sha256'] ?? '')];
            if ($irCap === SiteRandomizationInspector::CAP_VARIANT_REFRESH) {
                $sec = (string)($ir['secret'] ?? '');
                if ($sec === '') {
                    // Дефенс: capability=variant_refresh без runtime-секрета невозможен,
                    // но fail-closed: считаем needs_review (fallback 'go' запрещён §8.2).
                    $detected['status'] = 'needs_review';
                } else {
                    $detected['found'] = true;
                    $detected['status'] = 'found';
                    $detected['filename'] = 'variant-refresh.php';
                    $detected['secret_extracted'] = $sec;
                    $detected['secret_source'] = 'config.php';
                    $detected['path'] = '/variant-refresh.php?k=' . rawurlencode($sec);
                    $log->ok('update_classes_call',
                        'Подтверждён поддерживаемый variant-refresh.php, секрет из config.php получен.',
                        ['event_code' => 'uc.detected_variant_refresh']);
                }
            } elseif ($irCap === SiteRandomizationInspector::CAP_UPDATE_CLASSES) {
                $detected['found'] = true;
                $detected['status'] = 'found';
                $detected['filename'] = 'update_classes.php';
                $detected['path'] = '/update_classes.php';
                $log->ok('update_classes_call',
                    'Подтверждён поддерживаемый update_classes.php.',
                    ['event_code' => 'uc.detected_update_classes']);
            } elseif ($irCap === SiteRandomizationInspector::CAP_CONFIRMED_ABSENT) {
                $log->info('update_classes_call',
                    'Поддерживаемых скриптов рандомизации на сайте нет (проверено по FTP).',
                    ['event_code' => 'uc.confirmed_absent']);
            } else {
                $log->warn('update_classes_call',
                    'Применимость рандомизации не подтверждена (' . $irCap . '): '
                    . (string)($irDet['reason'] ?? '') . '. Скрипт не запускался.',
                    ['event_code' => 'uc.detection_' . $irCap,
                     'technical_reason' => (string)($irDet['reason'] ?? '')]);
            }
            unset($irBase);

            if (!$detected['found']) {
                // P0.2/P0.3/P1.3: НЕ считаем это «скрипта нет → not_applicable → gate».
                // FTP-ошибка или неоднозначность НЕ должна открывать gate и НЕ должна
                // ставить verified_at. Делегируем решение profile-системе ниже
                // (она вернёт none[+confirmed_absent] БЕЗ verified_at, либо
                // ftp_unavailable/unknown → awaiting_user fail-closed). callUrl пока пуст.
                $log->info('update_classes_call',
                    'Автодетект не нашёл скрипт в корне (' . (string)($detected['status'] ?? 'not_found')
                    . ') — окончательное решение примет profile-система (fail-closed).');
                $callUrl = '';
                $reason = 'defer_to_profile';
            } else {
                // Собираем callUrl: домен + path
                $callUrl = 'https://' . $newDomain . $detected['path'];
                $reason = 'auto_from_ftp';
                $log->info('update_classes_call',
                    "Найден '{$detected['filename']}', дёргаю: {$callUrl}");
            }
        }

        // 3. Вызываем HTTP-запросом
        // v18.1.18: передаём vpsIp + newDomain для --resolve fallback (DNS может ещё пропагироваться)
        $vpsIp = $this->resolveVpsIpForJob($job, $log);

        // v18.1.34: PRE-FLIGHT CHECK — убедиться что HTTPS на newDomain РЕАЛЬНО
        // ведёт на наш сайт, а не на default vhost VPS. Это может произойти если:
        //  - aliases_added прошло, но Apache config ещё не перезапустился
        //  - self-signed cert ещё не привязался к vhost'у для newDomain
        //  - SNI fallback: Apache отдаёт default vhost при unknown SNI
        // В этом случае update_classes.php запустится на ЧУЖОМ сайте.
        $preflight = $this->checkSiteResponsiveToNewDomain($newDomain, $vpsIp, $log);
        if (!$preflight['ok']) {
            $log->warn('update_classes_call',
                "Pre-flight check не прошёл: {$preflight['reason']}. " .
                "Похоже что HTTPS на {$newDomain} ещё не настроен или ведёт на default vhost. " .
                "Откладываю запуск рандомизации до готовности сайта.");

            $patch = ['update_classes_stage' => [
                'ok' => false,
                'action' => 'preflight_failed',
                'preflight_reason' => $preflight['reason'],
                'preflight_response_excerpt' => mb_substr((string)($preflight['body'] ?? ''), 0, 200),
                'last_attempt_at' => date('Y-m-d H:i:s'),
            ]];
            try {
                // v25.1-a1 (Блокер 2): временный preflight — pending, чтобы cron
                // сам подхватил следующий тик. awaiting_user здесь навсегда
                // парковал стадию (retry-spam guard авто-подхватывает только
                // verify_replacement).
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET
                        artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?),
                        stage_status = 'pending',
                        next_run_at = DATE_ADD(NOW(), INTERVAL 60 SECOND)
                     WHERE id = ?
                       AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([
                    json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $jobId,
                ]);
            } catch (\Throwable $e) {}
            return;
        }

        $log->info('update_classes_call',
            "Pre-flight ✓: {$newDomain} отвечает корректно (видим маркер newDomain в HTML)");

        // PATCH_2 (§4/§7): ожидаемые ПОЛНЫЕ физические корни. Для операции,
        // изменяющей боевые файлы, fail-OPEN запрещён: неизвестен корень →
        // НЕ запускаем скрипт.
        // PATCH_3 (§3): единый ДОВЕРЕННЫЙ physical root. HTTP-response путь никогда
        // не входит в источники. conflict / unknown → fail-closed (скрипт не вызываем).
        $trust = $this->resolveTrustedPhysicalRoot($job, $siteId);
        $trustStatus = (string)($trust['status'] ?? 'unknown');
        if ($trustStatus === 'conflict') {
            $log->warn('update_classes_call',
                'update_classes_expected_root_conflict: ' . implode(' vs ', $trust['roots'] ?? []) . ' — запуск запрещён.');
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: expected_physical_root_conflict', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return;
        }
        if ($trustStatus !== 'ok') {
            $log->warn('update_classes_call',
                'update_classes_expected_root_unknown (' . $trustStatus . '): корень не определён — запуск запрещён.');
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: expected_physical_root_unknown', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return;
        }
        $trustedRoot = (string)$trust['root'];

        // PATCH_2 (§3/§4): анти-повтор по РЕАЛЬНОМУ столбцу uc_execution_state.
        $prevExec = $this->ucExecutionState($jobId);
        if (in_array($prevExec, ['started', 'ambiguous', 'completed', 'verified', 'operator_skipped'], true)
            && empty($job['php_uniquification_verified_at'])) {
            $log->info('update_classes_call',
                "update_classes_duplicate_blocked: uc_execution_state={$prevExec} — автоповтор запрещён, проверяю по FTP.");
            $es = (string)($job['uc_execution_started_at'] ?? '');
            $ropts = ['execution_started_at' => $es];
            $sp = $this->loadSavedProfile($job); if (is_array($sp)) $ropts['profile'] = $sp;
            $ev = $this->loadSavedEvidence($job); if (is_array($ev) && isset($ev['variant_state'])) $ropts['state_before'] = $ev['variant_state'];
            $res = $this->verifyUniquificationByFtp($job, $log, $trustedRoot, $ropts);
            $this->settleUpdateClassesByFtp($jobId, $res, ['stage' => 'update_classes_call'], $log);
            return;
        }

        // ═══ PATCH_5 (P0.4): profile+evidence СНАЧАЛА, затем ОДИН атомарный переход ═══
        // Дешёвый wrong_stage pre-check (без FTP) по свежей джобе.
        $freshPre = $this->reloadJob($jobId) ?? $job;
        if ((string)$freshPre['stage'] !== 'update_classes_call') {
            $log->warn('update_classes_call', 'wrong_stage pre-check: стадия уже ' . (string)$freshPre['stage'] . ' — HTTP=0, FTP=0.');
            return;
        }
        // Анти-повтор: если execution уже начат/завершён или gate закрыт — reconciliation
        // по СОХРАНЁННОМУ профилю (никогда не строим заново для started-джобы).
        $ucPre = (string)($freshPre['uc_execution_state'] ?? '');
        if (!empty($freshPre['php_uniquification_verified_at']) || self::updateClassesGateSatisfied($freshPre)) {
            $log->info('update_classes_call', 'gate уже удовлетворён — no-op.');
            return;
        }
        if (in_array($ucPre, ['started', 'completed', 'ambiguous'], true)) {
            $es = (string)($freshPre['uc_execution_started_at'] ?? '');
            $saved = $this->loadSavedProfile($freshPre);
            $arts0 = $this->loadArtifacts($freshPre);
            $savedScriptPath = (string)($arts0['update_classes_stage']['script_path'] ?? '');
            if (!is_array($saved)) {
                // PATCH_6.1: первый вызов профиль не сохраняет (marker-based). Для recovery
                // строим профиль ЛЕНИВО из сохранённого script_path. Если ни профиля, ни
                // script_path нет → нечем восстанавливать → fail-closed (verified запрещён).
                if ($savedScriptPath === '') {
                    $log->warn('update_classes_call', 'started без сохранённого профиля и без script_path — verified по старым файлам запрещён. awaiting_user.');
                    DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error='update_classes: started_without_profile', next_run_at=NULL WHERE id=? AND stage='update_classes_call'")->execute([$jobId]);
                    return;
                }
                $recP = $this->resolveVerificationProfile($freshPre, $trustedRoot, $savedScriptPath);
                $recS = (string)($recP['strategy'] ?? 'unknown');
                if (!in_array($recS, ['class_mapping', 'variant_state', 'none'], true)) {
                    $log->warn('update_classes_call', 'recovery-формат неизвестен (' . $recS . ') — awaiting_user, без повторного вызова.');
                    DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL WHERE id=? AND stage='update_classes_call'")->execute(['update_classes: recovery_' . $recS, $jobId]);
                    return;
                }
                // ТЗ046 ADDENDUM §8/§10: class_mapping recovery — только delta, BEFORE из сохранённого evidence.
                if ($recS === 'class_mapping') {
                    if ($this->recoverClassMappingByDelta($freshPre, $log, $trustedRoot, $recP,
                            $this->loadSavedEvidence($freshPre) ?: [], $ucPre)) return;
                }
                $saved = $recP; unset($saved['state_before'], $saved['evidence_before']);
                $opts = ['execution_started_at' => $es, 'profile' => $saved,
                         'state_before' => ($recP['state_before'] ?? null),
                         'evidence_before' => ['variant_state' => ($recP['state_before'] ?? null),
                                               'class_mapping' => ($recP['evidence_before']['class_mapping'] ?? null)]];
                $res = $this->verifyUniquificationByFtp($freshPre, $log, $trustedRoot, $opts);
                $this->settleUpdateClassesByFtp($jobId, $res, ['stage' => 'update_classes_call'], $log);
                return;
            }
            $opts = ['execution_started_at' => $es, 'profile' => $saved];
            $ev = $this->loadSavedEvidence($freshPre); if (is_array($ev)) { if (isset($ev['variant_state'])) $opts['state_before'] = $ev['variant_state']; $opts['evidence_before'] = $ev; }
            // ТЗ046 ADDENDUM: class_mapping — authoritative proof только delta-verifier.
            if (is_array($saved) && (string)($saved['strategy'] ?? '') === 'class_mapping') {
                if ($this->recoverClassMappingByDelta($freshPre, $log, $trustedRoot, (array)$saved,
                        is_array($ev) ? $ev : [], $ucPre)) return;
            }
            $res = $this->verifyUniquificationByFtp($freshPre, $log, $trustedRoot, $opts);
            $this->settleUpdateClassesByFtp($jobId, $res, ['stage' => 'update_classes_call'], $log);
            return;
        }

        // ═══ PATCH_6.1: ПЕРВЫЙ штатный вызов — SCRIPT-DRIVEN, без зависимости от
        // resolveVerificationProfile()/распознавания внутренней структуры сайта. Достаточно:
        // FTP success + trusted root ok + (скрипт найден ИЛИ custom path существует в root)
        // + корректный host → atomic reservation → один HTTP → success+marker = completed.
        // Профиль/mapping/state_before/FTP-verify — ТОЛЬКО для ambiguous/recovery (ниже). ═══
        $scriptPath = '';
        if (isset($customPath) && $customPath !== '') $scriptPath = (string)$customPath;
        elseif (isset($detected) && is_array($detected) && !empty($detected['path'])) $scriptPath = (string)$detected['path'];
        $isVariant = (stripos($scriptPath, 'variant-refresh') !== false)
            || (isset($detected['filename']) && stripos((string)$detected['filename'], 'variant-refresh') !== false);

        $awaiting = function($err) use ($jobId, $log) {
            $log->warn('update_classes_call', $err . ' — запуск запрещён (fail-closed), execution НЕ переходит в started.');
            DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute(['update_classes: ' . $err, $jobId]);
        };

        if ($callUrl === '') {
            // Скрипт не найден автодетектом. Решение — по СТАТУСУ детекции, НЕ по профилю:
            //   confirmed_absent (FTP success + root ok, скрипта нет) → not_applicable;
            //   ftp_error/not_found (не смогли подтвердить) → awaiting (gate НЕ открываем).
            $dstatus = (string)($detected['status'] ?? 'not_found');
            if ($dstatus === 'confirmed_absent') {
                $this->saveUcStage($jobId, ['outcome' => 'not_applicable', 'confirmed_absent' => true,
                    'script_detect_status' => $dstatus, 'profile_saved_at' => date('Y-m-d H:i:s')]);
                $this->markUcState($jobId, 'completed');
                $log->info('update_classes_call', 'update_classes_not_applicable: FTP-анализ успешен, root подтверждён, поддерживаемого скрипта нет — HTTP=0, verified_at НЕ ставится.');
                $this->setStatus($jobId, 'ok', 'stage_finished_at');
                return;
            }
            $awaiting('verification_script_' . $dstatus);
            return;
        }

        // callUrl != '' → скрипт найден / custom задан. Для custom (не автодетект) подтверждаем,
        // что путь РЕАЛЬНО существует в доверенном root (модель: "custom path существует в root").
        // Для auto_from_ftp существование уже подтверждено детекцией.
        if (($reason === 'custom_path' || $reason === 'custom_full_url')) {
            $relPath = ltrim((string)(parse_url($scriptPath, PHP_URL_PATH) ?: $scriptPath), '/');
            $existsInRoot = $this->customScriptExistsInTrustedRoot($job, $trustedRoot, $relPath, $log);
            if ($existsInRoot === false) { $awaiting('custom_script_path_not_found_in_root'); return; }
            if ($existsInRoot === null)  { $awaiting('custom_script_path_unverifiable'); return; }
        }

        // ═══ ТЗ 039 §9.1: BASELINE ДО ПЕРВОГО HTTP. Строим strategy-профиль и
        // evidence_before (для variant — state/nonce/timestamp, для mapping —
        // SHA-256 файлов) и сохраняем их АТОМАРНО в том же reservation-UPDATE,
        // который переводит execution в started. Не удалось построить/сохранить
        // baseline → HTTP=0, стадия НЕ переходит в started (fail-closed). ═══
        $baselineProfile = $this->resolveVerificationProfile($job, $trustedRoot, $scriptPath);
        $bStrat = (string)($baselineProfile['strategy'] ?? 'unknown');
        // ТЗ v2.0 §6.1 (дефект 5): выбранный оператором custom-контракт ОБЯЗАТЕЛЕН.
        // Код НЕ имеет права подменять его другим на основании найденного
        // FTP-профиля или формата ответа. Каждый контракт → строго своя стратегия:
        //   json_ok_true → strict_json (успех только по строгому JSON ok===true);
        //   exact_marker → exact_marker (точная строка; пуст marker → HTTP=0);
        //   ftp_profile  → строго FTP-профиль (variant_state/class_mapping);
        //                  профиль/baseline не построен → HTTP=0, БЕЗ подмены на JSON.
        $isCustomMode = (strpos($reason, 'custom') === 0);
        if ($isCustomMode) {
            $contract = (string)($customContract ?? '');
            if ($contract === 'json_ok_true') {
                $bStrat = 'strict_json';
                $baselineProfile = ['strategy' => 'strict_json', 'confirm' => 'json_ok_true'];
            } elseif ($contract === 'exact_marker') {
                $marker = '';
                try {
                    $mst = DB::pdo()->prepare("SELECT uc_verification_marker FROM sites_managed WHERE id=?");
                    $mst->execute([$siteId]);
                    $marker = trim((string)($mst->fetchColumn() ?: ''));
                } catch (\Throwable $e) { $marker = ''; }
                if ($marker === '') {
                    // §6.3: exact_marker выбран, но marker пуст → HTTP=0.
                    $log->warn('update_classes_call',
                        'Для кастомного скрипта выбран способ «точный маркер», но сама строка не задана. Запуск запрещён.',
                        ['event_code' => 'uc.custom_marker_missing']);
                    DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error='update_classes: custom_marker_missing', next_run_at=NULL WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
                    return;
                }
                $bStrat = 'exact_marker';
                $baselineProfile = ['strategy' => 'exact_marker', 'confirm' => 'exact_marker', 'marker' => $marker];
            } elseif ($contract === 'ftp_profile') {
                // §6.1/§6.3: ТОЛЬКО FTP-профиль. resolveVerificationProfile обязан
                // был вернуть variant_state/class_mapping. Иначе — HTTP=0, БЕЗ
                // переключения на strict_json.
                if (!in_array($bStrat, ['variant_state', 'class_mapping'], true)) {
                    $log->warn('update_classes_call',
                        'Для кастомного скрипта выбран способ проверки «по файлам (FTP)», но профиль проверки не удалось построить. Запуск запрещён — панель не будет подменять способ проверки.',
                        ['event_code' => 'uc.custom_ftp_profile_unavailable', 'technical_reason' => $bStrat]);
                    DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error='update_classes: custom_ftp_profile_unavailable', next_run_at=NULL WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
                    return;
                }
                // strategy остаётся variant_state/class_mapping как построено.
            } else {
                // contract отсутствует/неизвестен → HTTP=0, needs_review (§6.3).
                try { DB::pdo()->prepare("UPDATE sites_managed SET uc_capability='needs_review' WHERE id=?")->execute([$siteId]); } catch (\Throwable $e) {}
                $log->warn('update_classes_call',
                    'Не настроен способ проверки результата для кастомного скрипта. Панель не будет запускать скрипт, пока не выбран способ подтверждения.',
                    ['event_code' => 'uc.custom_contract_missing']);
                DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error='update_classes: custom_verification_contract_missing', next_run_at=NULL WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')")->execute([$jobId]);
                return;
            }
        }
        if (!in_array($bStrat, ['variant_state', 'class_mapping', 'strict_json', 'exact_marker'], true)) {
            $log->warn('update_classes_call',
                'Baseline для проверки результата построить не удалось (strategy=' . $bStrat
                . ') — HTTP-вызов запрещён, чтобы результат не оказался недоказуемым.',
                ['event_code' => 'uc.baseline_unavailable', 'technical_reason' => $bStrat]);
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error=?, next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute(['update_classes: baseline_unavailable_' . $bStrat, $jobId]);
            return;
        }
        $baselineProfileToSave = $baselineProfile;
        unset($baselineProfileToSave['state_before'], $baselineProfileToSave['evidence_before']);
        $evidenceBefore = [
            'variant_state' => ($baselineProfile['state_before'] ?? null),
            'class_mapping' => ($baselineProfile['evidence_before']['class_mapping'] ?? null),
        ];
        if ($bStrat === 'variant_state' && !is_array($evidenceBefore['variant_state'])) {
            // Для variant-стратегии baseline обязан включать состояние варианта
            // до вызова (nonce/timestamp). Нет состояния → нечем доказывать.
            $log->warn('update_classes_call',
                'Baseline variant-состояния до вызова прочитать не удалось — HTTP-вызов запрещён.',
                ['event_code' => 'uc.baseline_unavailable', 'technical_reason' => 'variant_state_unreadable']);
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: baseline_variant_state_unreadable', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return;
        }
        if ($bStrat === 'class_mapping'
            && !$this->classMappingEvidenceComplete($baselineProfile, $evidenceBefore)) {
            $log->warn('update_classes_call',
                'Baseline контрольных файлов (mapping/выходные файлы) неполон — HTTP-вызов запрещён.',
                ['event_code' => 'uc.baseline_unavailable', 'technical_reason' => 'class_mapping_evidence_incomplete']);
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: baseline_mapping_incomplete', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return;
        }

        $execId = bin2hex(random_bytes(6));
        $execStartedAt = date('Y-m-d H:i:s');
        // script_kind: для strict_json (custom) — 'custom', иначе по типу скрипта.
        $scriptKind = in_array($bStrat, ['strict_json','exact_marker'], true) ? 'custom' : ($isVariant ? 'variant_state' : 'update_classes');
        $ucStagePayload = ['script_path' => $scriptPath, 'script_kind' => $scriptKind,
            'first_call_marker_based' => false, 'baseline_saved' => true, 'profile_saved_at' => $execStartedAt,
            'execution_id' => $execId, 'execution_started_at' => $execStartedAt,
            // §9.1: baseline атомарно вместе с переходом в started.
            'profile' => $baselineProfileToSave,
            'evidence_before' => $evidenceBefore,
            'baseline' => [
                'strategy' => $bStrat,
                'captured_at' => $execStartedAt,
                'script_fingerprint_sha256' => (string)($detected['fingerprint_sha256'] ?? ''),
                'capability_snapshot' => $siteUc['uc_capability'],
                'trusted_root' => $trustedRoot,
            ]];
        $reserved = false;
        try {
            $u = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    uc_execution_state='started', uc_execution_id=?, uc_execution_started_at=?,
                    uc_execution_attempts=COALESCE(uc_execution_attempts,0)+1,
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?), updated_at=NOW()
                  WHERE id=? AND stage='update_classes_call'
                    AND stage_status IN ('pending','running','awaiting_user','ok')
                    AND (uc_execution_state IS NULL OR uc_execution_state='' OR uc_execution_state='not_started')");
            $u->execute([$execId, $execStartedAt,
                json_encode(['update_classes_stage' => $ucStagePayload], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
            if ($u->rowCount() === 1) {
                $back = $this->reloadJob($jobId) ?? $job;
                $reserved = ((string)($back['uc_execution_id'] ?? '') === $execId);
            }
        } catch (\Throwable $e) { $reserved = false; }
        if (!$reserved) {
            $log->info('update_classes_call', 'reserve не подтверждён (rowCount≠1 или read-back) — HTTP=0, откладываю.');
            return;
        }
        $log->info('update_classes_call', "update_classes_reserved (marker-based, script-driven): execution_id={$execId}");
        $verifyOpts = ['script_path' => $scriptPath, 'script_kind' => $scriptKind,
                       'execution_started_at' => $execStartedAt];

        // PATCH_3 (§13): http_started ДО вызова клиента.
        $log->info('update_classes_call', 'update_classes_http_started (execution_id=' . $execId . ')');
        $result = $this->callUpdateClassesUrl($callUrl, $log, $newDomain, $vpsIp);

        $this->saveUcStage($jobId, [
            'url' => $callUrl, 'action' => $reason,
            'http_code' => $result['http_code'] ?? 0,
            'message' => (string)($result['message'] ?? ''),
            'response_excerpt' => mb_substr((string)($result['body'] ?? ''), 0, 200),
            'execution_id' => $execId,
        ]);
        if (isset($detected) && is_array($detected) && !empty($detected['found'])) {
            $this->saveUcStage($jobId, [
                'detected_filename' => $detected['filename'] ?? '',
                'detected_path' => $detected['path'] ?? '',
            ]);
        }
        if (!empty($result['ok'])) {
            try { DB::pdo()->prepare("UPDATE sites_managed SET update_last_called_at = NOW() WHERE id=?")->execute([$siteId]); }
            catch (\Throwable $e) {}
        }

        // ТЗ046 §6–§11/§14: для class_mapping ЕДИНСТВЕННЫЙ proof факта рандомизации —
        // семантическая дельта правых частей mapping ДО/ПОСЛЕ. HTTP-маркер сам по себе
        // НЕ выставляет php_uniquification_verified_at. Ambiguous HTTP + delta>=1 → verified
        // (без повторного mutating-вызова). success HTTP + delta=0 → awaiting_user.
        if ($bStrat === 'class_mapping') {
            $this->settleClassMappingByDelta(
                $job, $log, $trustedRoot, $baselineProfile, $evidenceBefore, $execId,
                $execStartedAt, $result, $verifyOpts
            );
            return;
        }

        // PATCH_3 (§3/§4): wrong-root по ПОЛНОМУ доверенному корню. response path
        // сохраняем ТОЛЬКО как response_detected_root (никогда не как trusted).
        if (!empty($result['ok'])) {
            $bodyCheck = $this->validateUpdateClassesResponse(
                (string)($result['body'] ?? ''), $newDomain, $trustedRoot, $log);
            if (!$bodyCheck['ok'] && !empty($bodyCheck['has_path'])) {
                $log->warn('update_classes_call',
                    'update_classes_wrong_root: ' . $bodyCheck['reason'] . ' — автоповтор запрещён, проверяю свой корень по FTP.');
                $this->markUcState($jobId, 'ambiguous');
                $this->saveUcStage($jobId, [
                    'outcome' => 'wrong_root', 'wrong_site' => true,
                    'response_detected_root' => (string)($bodyCheck['response_detected_root'] ?? ''),
                ]);
                $res = $this->verifyUniquificationByFtp($job, $log, $trustedRoot, ['execution_started_at' => $execStartedAt] + $verifyOpts);
                $this->settleUpdateClassesByFtp($jobId, $res, ['stage' => 'update_classes_call'], $log);
                return;
            }
        }

        // Сужение (b): success + completion marker ЗАВЕРШАЕТ этап (marker-based).
        // Внутренние CSS/JS/PHP outputs НЕ сертифицируем. FTP-verify используется только
        // как ограниченный recovery для НЕОДНОЗНАЧНОГО ответа (timeout/502/reset/нет marker).
        // §9.2: kind определяет строгий формат успеха. Для кастомного скрипта
        // формат заранее неизвестен — принимаем и строгий JSON, и классический маркер.
        // ревью P0#5: у custom — свой контракт (строгий JSON ok=true), НЕ '' (что
        // раньше принимало и legacy-маркеры).
        // §7.2: контракт успеха определяется стратегией baseline (для custom —
        // выбранным способом подтверждения). exact_marker → точная строка.
        if ($bStrat === 'exact_marker') {
            $markerKind = 'exact_marker';
        } elseif ($bStrat === 'strict_json') {
            $markerKind = 'custom';
        } else {
            $markerKind = $isVariant ? 'variant_state' : 'update_classes';
        }
        $expectedMarker = (string)($baselineProfile['marker'] ?? '');
        $hasMarker = $this->hasUpdateClassesCompletionMarker((string)($result['body'] ?? ''), $markerKind, $expectedMarker);
        if (!empty($result['ok']) && $hasMarker) {
            $completePatch = [
                'outcome' => 'completed_by_marker',
                'completion_marker' => true,
                'http_code' => (int)($result['http_code'] ?? 0),
                'execution_id' => $execId,
                'completed_at' => date('Y-m-d H:i:s'),
            ];
            $u = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    php_uniquification_verified_at = NOW(), uc_execution_state = 'completed',
                    stage_status = 'ok', stage_error = NULL, stage_finished_at = NOW(), next_run_at = NOW(),
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                  WHERE id = ? AND stage = 'update_classes_call'
                    AND php_uniquification_verified_at IS NULL
                    AND uc_execution_id = ?
                    AND stage_status IN ('running','pending','awaiting_user')"
            );
            $u->execute([json_encode(['update_classes_stage' => $completePatch], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId, $execId]);
            // PATCH_6.1 (item 2): completion UPDATE обязан примениться (rowCount==1). Если нет
            // (стадия/execution сменились, gate уже закрыт, другой worker) И целевое состояние
            // не подтверждено read-back — НЕ пишем ложный success, возвращаем state_conflict.
            if ($u->rowCount() !== 1) {
                $back = $this->reloadJob($jobId) ?? $job;
                $confirmed = !empty($back['php_uniquification_verified_at'])
                    && (string)($back['uc_execution_id'] ?? '') === $execId
                    && (string)($back['stage'] ?? '') === 'update_classes_call';
                if (!$confirmed) {
                    $this->markUcState($jobId, 'ambiguous');
                    $this->saveUcStage($jobId, ['outcome' => 'state_conflict',
                        'state_conflict_reason' => 'completion UPDATE rowCount=0 и целевое состояние не подтверждено read-back',
                        'execution_id' => $execId]);
                    DB::pdo()->prepare("UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error='update_classes: state_conflict', next_run_at=NULL WHERE id=? AND stage='update_classes_call' AND php_uniquification_verified_at IS NULL")->execute([$jobId]);
                    $log->warn('update_classes_call', 'update_classes_state_conflict: completion UPDATE не применился (rowCount=0), read-back не подтвердил — ложный success НЕ записан.');
                    return;
                }
            }
            $log->ok('update_classes_call',
                'Скрипт рандомизации подтвердил выполнение. Этап завершён (повторный запуск не выполняется).',
                ['event_code' => 'uc.completed_by_marker',
                 'technical_reason' => 'HTTP ' . (int)($result['http_code'] ?? 0) . ' + completion marker']);
            // ТЗ 039 §9.3: после подтверждённого ответа — strategy-specific FTP
            // read-back против evidence_before (baseline до HTTP), для аудита.
            // Достоверный ответ скрипта НЕ понижается результатом read-back.
            // Для strict_json (custom) FTP read-back не выполняется: единственный
            // контракт — строгий JSON ok=true, сравнивать по FTP нечего.
            if (in_array($bStrat, ['strict_json','exact_marker'], true)) {
                $this->saveUcStage($jobId, ['read_back_after_success' => [
                    'status' => 'skipped_' . $bStrat,
                    'checked_at' => date('Y-m-d H:i:s'),
                ]]);
                return;
            }
            try {
                $rbOpts = ['execution_started_at' => $execStartedAt,
                           'profile' => $baselineProfileToSave,
                           'evidence_before' => $evidenceBefore];
                if (isset($evidenceBefore['variant_state']) && is_array($evidenceBefore['variant_state'])) {
                    $rbOpts['state_before'] = $evidenceBefore['variant_state'];
                }
                $rb = $this->verifyUniquificationByFtp($job, $log, $trustedRoot, $rbOpts);
                $this->saveUcStage($jobId, ['read_back_after_success' => [
                    'status' => (string)($rb['status'] ?? ''),
                    'changed' => $rb['changed'] ?? null,
                    'checked_at' => date('Y-m-d H:i:s'),
                ]]);
            } catch (\Throwable $e) {
                $this->saveUcStage($jobId, ['read_back_after_success' => [
                    'status' => 'ftp_error', 'error' => $e->getMessage(),
                    'checked_at' => date('Y-m-d H:i:s'),
                ]]);
            }
            return;
        }

        // ревью P1: ЯВНАЯ ошибка скрипта (JSON ok=false) — это НЕ неоднозначность.
        // Скрипт однозначно сообщил об ошибке → failed + awaiting_user, автоповтор
        // запрещён до решения оператора. FTP-recovery здесь не нужен (нечего
        // «доподтверждать»: скрипт сам сказал, что не выполнил).
        $scriptErr = $this->scriptExplicitlyReportedError((string)($result['body'] ?? ''));
        if ($scriptErr) {
            $errMsg = $this->extractScriptError((string)($result['body'] ?? ''));
            $this->markUcState($jobId, 'failed');
            $this->saveUcStage($jobId, [
                'outcome' => 'script_error',
                'script_reported_error' => true,
                'error_message' => $errMsg,
                'decided_at' => date('Y-m-d H:i:s'),
            ]);
            $log->error('update_classes_call',
                'Скрипт рандомизации вернул ошибку: ' . ($errMsg !== '' ? $errMsg : 'без описания')
                . '. Автоматический повтор не выполняется — нужно решение оператора.',
                ['event_code' => 'uc.script_error', 'technical_reason' => 'json_ok_false']);
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error=?, next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute(['update_classes: script_reported_error', $jobId]);
            return;
        }

        // Неоднозначный ответ (timeout/502/reset/нет marker) → ambiguous, БЕЗ повторного
        // HTTP-вызова. Ограниченный FTP-recovery против baseline.
        $ambReason = !empty($result['ok'])
            ? 'HTTP ' . (int)($result['http_code'] ?? 0) . ' без completion marker'
            : 'HTTP ' . (int)($result['http_code'] ?? 0) . ' / ' . (string)($result['message'] ?? 'вызов не завершён');
        $this->markUcState($jobId, 'ambiguous');
        $this->saveUcStage($jobId, ['ambiguous_reason' => $ambReason,
            'script_reported_error' => false]);
        // Для strict_json (custom) FTP read-back невозможен: контракт — только
        // строгий JSON ok=true. Если его не было — оставляем ambiguous +
        // awaiting_user без автоповтора; решение за оператором.
        if (in_array($bStrat, ['strict_json','exact_marker'], true)) {
            $log->warn('update_classes_call',
                'Кастомный скрипт рандомизации был вызван, но не вернул подтверждающий ответ ('
                . $ambReason . '). Повторный запуск заблокирован; проверьте результат вручную.',
                ['event_code' => 'uc.http_ambiguous', 'technical_reason' => $ambReason]);
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: custom_ambiguous_no_json', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return;
        }
        $log->warn('update_classes_call',
            'Скрипт рандомизации был вызван, но панель пока не смогла достоверно подтвердить результат ('
            . $ambReason . '). Повторный запуск заблокирован; выполняю проверку файлов по FTP против baseline.',
            ['event_code' => 'uc.http_ambiguous', 'technical_reason' => $ambReason]);
        // ТЗ 039 §9.3/§24.6: read-back сравнивается ИМЕННО с baseline, сохранённым
        // до HTTP (evidence_before из atomic reservation), а не с лениво
        // перечитанным «после» состоянием.
        $recOpts = ['profile' => $baselineProfileToSave,
                    'evidence_before' => $evidenceBefore,
                    'script_path' => $scriptPath, 'execution_started_at' => $execStartedAt];
        if (isset($evidenceBefore['variant_state']) && is_array($evidenceBefore['variant_state'])) {
            $recOpts['state_before'] = $evidenceBefore['variant_state'];
        }
        $res = $this->verifyUniquificationByFtp($job, $log, $trustedRoot, $recOpts);
        $this->settleUpdateClassesByFtp($jobId, $res, ['stage' => 'update_classes_call'], $log);
        return;
    }

    /**
     * v25.0-a1 (B4): свежий HTTPS smoke нового домена после смены классов.
     * Возвращает true только при публичном HTTPS 200 + валидном SSL (без
     * self-signed) и допустимом финальном хосте. Использует тот же строгий
     * probe, что и readiness. Сетевые/HTTP-ошибки → false.
     */



    /**
     * v25.1-a (§3.2): подтверждение уникализации через HTTPS smoke.
     * НЕ требует доверенного TLS — достаточно HTTPS 200 на нашем домене
     * (finalHostAllowed), self-signed допустим. Trusted SSL нужен позже
     * (verification/recrawl), но не для смены классов.
     */
    private function verifyUniquification(string $newDomain, JobEventLogger $log): bool
    {
        $newDomain = strtolower(trim($newDomain));
        if ($newDomain === '') return false;
        try {
            $probe = $this->makeHttpProbe();
            // v25.1-a1 (Блокер 1): non-strict transport — self-signed на старте
            // НЕ должен давать final_code=0. Публичный DNS, без RESOLVE.
            $https = $probe->probeHttpsAllowUntrusted('https://' . $newDomain . '/');
            $finalUrl = (string)($https['final_url'] ?? '');
            // Требуем: код 200; финальный URL остался на HTTPS нашего домена
            // (finalHostAllowed проверяет https-схему и host = domain/www.domain).
            $ok = ((int)$https['final_code'] === 200)
                && DomainReadinessService::finalHostAllowed($finalUrl, $newDomain);
            if (!$ok) {
                $log->info('update_classes_call',
                    'HTTPS smoke (non-strict): final=' . (int)$https['final_code']
                    . ' final_url=' . ($finalUrl !== '' ? $finalUrl : '-')
                    . ' self_signed=' . (!empty($https['self_signed']) ? '1' : '0')
                    . ' ssl_trusted=' . (!empty($https['ssl_trusted']) ? '1' : '0')
                    . ' (self-signed допустим, важен код 200 и наш host)');
            }
            return $ok;
        } catch (\Throwable $e) {
            $log->info('update_classes_call', 'HTTPS smoke упал: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * v17.11: автодетект скрипта рандомизации в корне сайта через FTP.
     *
     * Поддерживает 2 формата:
     *   1. Старый: update_classes.php — без секрета, дёргается просто GET /update_classes.php
     *   2. Новый (enomo v3): variant-refresh.php — секрет в config.php
     *      ($variant_settings['manual_secret'] => 'go'), формат вызова: ?k=SECRET
     *
     * @return array{
     *   found: bool,                         // есть ли хоть один файл
     *   filename: string,                    // 'update_classes.php' | 'variant-refresh.php' | ''
     *   path: string,                        // path для callUrl: '/update_classes.php' | '/variant-refresh.php?k=go'
     *   secret_extracted: ?string,           // извлечённый manual_secret (или null)
     *   secret_source: string,               // 'config.php' | 'fallback_default' | 'none'
     * }
     */
    private function detectRefreshScript(int $siteId, JobEventLogger $log): array
    {
        $result = [
            'found' => false,
            'status' => 'not_found',
            'filename' => '',
            'path' => '',
            'secret_extracted' => null,
            'secret_source' => 'none',
        ];

        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $site = $st->fetch();
            if (!$site) { $result['status'] = 'ftp_error'; return $result; }

            $ftp = $this->makeFtp(
                (string)$site['ftp_host'],
                (string)$site['ftp_user'],
                Crypto::decrypt((string)$site['ftp_pass_enc'])
            );
            $ftp->connect();
            try {
                // Проверяем сначала новый формат (variant-refresh.php), потом старый
                $hasNew = $ftp->fileExists('variant-refresh.php');
                $hasOld = $ftp->fileExists('update_classes.php');

                if ($hasNew) {
                    $log->info('update_classes_call',
                        'Найден variant-refresh.php (формат enomo v3). ' .
                        'Пытаюсь извлечь manual_secret из config.php...');

                    $secret = $this->extractManualSecretFromConfig($ftp, $log);
                    $result['filename'] = 'variant-refresh.php';
                    $result['found'] = true;
                    $result['status'] = 'found';

                    if ($secret !== null) {
                        $result['secret_extracted'] = $secret;
                        $result['secret_source'] = 'config.php';
                        $result['path'] = '/variant-refresh.php?k=' . rawurlencode($secret);
                        $log->ok('update_classes_call',
                            "manual_secret извлечён из config.php: '{$secret}'. " .
                            "Path: {$result['path']}");
                    } else {
                        // ТЗ 039 §8.2: fallback 'go' ЗАПРЕЩЁН. Секрет не найден →
                        // needs_review, path не строится, HTTP-вызов не выполняется.
                        $result['found'] = false;
                        $result['status'] = 'needs_review';
                        $result['secret_source'] = 'missing';
                        $result['path'] = '';
                        $log->warn('update_classes_call',
                            "Не удалось извлечь непустой manual_secret из config.php. " .
                            "Автовызов запрещён (needs_review), fallback-секрет не используется. " .
                            "Укажи корректный path через 'Рандомизация классов' или проверь config.php.");
                    }
                } elseif ($hasOld) {
                    $log->info('update_classes_call',
                        'Найден update_classes.php (старый формат, без секрета).');
                    $result['filename'] = 'update_classes.php';
                    $result['path'] = '/update_classes.php';
                    $result['found'] = true;
                    $result['status'] = 'found';
                } else {
                    // FTP-root успешно открыт, но скриптов нет — ДОСТОВЕРНОЕ отсутствие.
                    $result['status'] = 'confirmed_absent';
                    $log->info('update_classes_call',
                        'Ни variant-refresh.php, ни update_classes.php в корне сайта не найдены (confirmed_absent).');
                }
            } finally {
                $ftp->disconnect();
            }
        } catch (\Throwable $e) {
            // P0.2: любая FTP-ошибка = ftp_error (НЕ «скрипта нет»).
            $result['status'] = 'ftp_error';
            $log->warn('update_classes_call', 'FTP-проверка упала: ' . $e->getMessage());
        }

        return $result;
    }

    /**
     * v17.11: качает config.php через FTP и пытается извлечь
     * $variant_settings['manual_secret'] через regex (без eval — безопасно).
     *
     * Поддерживает форматы:
     *   'manual_secret' => 'go',
     *   'manual_secret'=>'go',
     *   "manual_secret" => "go",
     *   'manual_secret' => "go",
     *
     * @return ?string найденный секрет или null
     */
    private function extractManualSecretFromConfig($ftp, JobEventLogger $log): ?string
    {
        // Пробуем разные пути config.php (как в FpSyncService)
        $candidates = ['config.php', '/config.php', 'public/config.php', '/public/config.php'];
        $content = '';
        $foundPath = '';

        foreach ($candidates as $remotePath) {
            try {
                $content = $ftp->getContent($remotePath);
                if ($content !== '') {
                    $foundPath = $remotePath;
                    break;
                }
            } catch (\Throwable $e) {
                // Файла нет на этом пути — пробуем следующий
                continue;
            }
        }

        if ($content === '') {
            $log->warn('update_classes_call',
                'Не удалось прочитать config.php ни с одного пути');
            return null;
        }

        $log->info('update_classes_call',
            "config.php прочитан с '{$foundPath}' (" . strlen($content) . " байт)");

        // Regex: ['"]manual_secret['"]\s*=>\s*['"](значение)['"]
        // Захватываем значение в группе 1.
        if (preg_match(
            '~[\'"]manual_secret[\'"]\s*=>\s*[\'"]([^\'"]*)[\'"]~',
            $content,
            $m
        )) {
            $secret = (string)$m[1];
            if ($secret !== '') {
                return $secret;
            }
            $log->warn('update_classes_call',
                'manual_secret в config.php найден, но пустой');
            return null;
        }

        $log->info('update_classes_call',
            "manual_secret в config.php не найден " .
            "(вероятно, шаблон без \$variant_settings)");
        return null;
    }

    /**
     * v18.1.34: Pre-flight check — убедиться что HTTPS на newDomain действительно
     * ведёт на наш сайт (config.php уже заменён → в HTML должно быть упоминание
     * newDomain), а не на default vhost VPS (чужой сайт).
     *
     * Возникает в момент когда aliases_added прошло, но Apache config ещё не
     * перезапустился, либо self-signed SSL ещё не привязан к vhost'у — Apache
     * отдаёт default vhost при unknown SNI.
     *
     * @return array{ok: bool, reason: string, body?: string}
     */
    protected function checkSiteResponsiveToNewDomain(
        string $newDomain,
        ?string $vpsIp,
        JobEventLogger $log
    ): array {
        $url = 'https://' . $newDomain . '/';

        // Сначала пробуем напрямую (DNS если уже пропагировался)
        $r = $this->doUpdateClassesCurl($url);
        if (!$r['ok'] && $vpsIp !== null
                && isset($r['curl_error'])
                && stripos($r['curl_error'], 'could not resolve host') !== false) {
            // DNS ещё не пропагирован — пробуем через --resolve
            $r = $this->doUpdateClassesCurl($url, $newDomain, $vpsIp);
        }

        if (!$r['ok']) {
            return [
                'ok' => false,
                'reason' => 'не удалось получить HTTP-ответ: ' .
                    ($r['message'] ?? $r['curl_error'] ?? '?'),
                'body' => (string)($r['body'] ?? ''),
            ];
        }

        $body = (string)($r['body'] ?? '');
        if ($body === '') {
            return [
                'ok' => false,
                'reason' => "пустое тело ответа (HTTP {$r['http_code']})",
                'body' => '',
            ];
        }

        // Главная проверка: в HTML должен быть упомянут newDomain. На этапе
        // update_classes_call config.php уже заменён → HTML содержит ссылки/canonical
        // с newDomain. Если в HTML мы видим ТОЛЬКО другие домены — попали в default vhost.
        $bodyLow = mb_strtolower($body);
        $needle = mb_strtolower($newDomain);

        if (strpos($bodyLow, $needle) !== false) {
            return ['ok' => true, 'reason' => "newDomain '{$newDomain}' найден в HTML", 'body' => $body];
        }

        // Дополнительная диагностика: попробуем выяснить КАКОЙ домен отдаёт VPS
        $foreignDomain = $this->extractForeignDomainFromBody($body, $newDomain);
        $reason = "newDomain '{$newDomain}' НЕ найден в HTML";
        if ($foreignDomain !== '') {
            $reason .= " (вместо него встречается '{$foreignDomain}' — попали в default vhost)";
        }
        return ['ok' => false, 'reason' => $reason, 'body' => $body];
    }

    /**
     * v18.1.34: Post-call body check — проверить что ответ update_classes.php
     * относится к нашему сайту.
     *
     * Скрипт обычно пишет в response пути типа `/var/www/<sitename>/...`. Если
     * <sitename> явно не от нашего newDomain — это false-positive.
     *
     * @return array{ok: bool, reason: string, detected_domain?: string}
     */
    /**
     * v25.2-a1.6.4.1 (§5): completion marker. HTTP 200 сам по себе не доказывает
     * завершение рандомизации. Для старого update_classes.php требуем маркер
     * "Update process completed."; для variant-refresh — его JSON/маркер.
     */
    private function hasUpdateClassesCompletionMarker(string $body, string $kind = '', string $marker = ''): bool
    {
        if ($body === '') return false;
        // §7.2: exact_marker — успех ТОЛЬКО при точном вхождении заданной строки.
        if ($kind === 'exact_marker') {
            return $marker !== '' && strpos($body, $marker) !== false;
        }
        // ТЗ 039 §9.2 / ревью P0#5: контракт успеха РАЗДЕЛЁН по типу скрипта.
        // Общий regex {"status":"ok"} / «variant refresh completed» удалён —
        // посторонний ответ не должен закрывать стадию.
        if ($kind === 'variant_state' || $kind === 'variant_refresh') {
            // variant-refresh → ТОЛЬКО строгий JSON с ok === true.
            $j = json_decode(trim($body), true);
            return is_array($j) && array_key_exists('ok', $j) && $j['ok'] === true;
        }
        if ($kind === 'update_classes') {
            // §8.5 (v4): классический update_classes.php подтверждается ТОЛЬКО
            // точным marker СВОЕГО семейства (передан из baseline/profile).
            // Общий список маркеров удалён — ответ одного семейства не должен
            // закрывать стадию другого. Нет marker → успех невозможен.
            return $marker !== '' && strpos($body, $marker) !== false;
        }
        if ($kind === 'custom') {
            // custom → строгий JSON ok===true (единственный явный контракт, что
            // панель умеет проверять для произвольного скрипта). Иные ответы —
            // не успех; результат подтверждается FTP read-back по baseline.
            $j = json_decode(trim($body), true);
            return is_array($j) && array_key_exists('ok', $j) && $j['ok'] === true;
        }
        // kind не задан (не должно происходить в норме): консервативно —
        // принимаем только строгий JSON ok===true.
        $j = json_decode(trim($body), true);
        return is_array($j) && array_key_exists('ok', $j) && $j['ok'] === true;
    }

    /** ТЗ 039 §9.2: явная ошибка скрипта — строгий JSON с ok=false. */
    private function scriptExplicitlyReportedError(string $body): bool
    {
        if ($body === '') return false;
        $j = json_decode(trim($body), true);
        return is_array($j) && array_key_exists('ok', $j) && $j['ok'] === false;
    }

    /** Текст ошибки из JSON ok=false (для лога/аудита). */
    private function extractScriptError(string $body): string
    {
        $j = json_decode(trim($body), true);
        if (!is_array($j)) return '';
        foreach (['error', 'message', 'reason'] as $k) {
            if (isset($j[$k]) && is_string($j[$k]) && $j[$k] !== '') return mb_substr($j[$k], 0, 300);
        }
        return '';
    }

    /** ТЗ 039 §7: seam для тестов — live-инспектор рандомизации. */
    protected function makeRandomizationInspector(): SiteRandomizationInspector
    {
        return new SiteRandomizationInspector();
    }

    /** Слить patch в update_classes_stage (JSON_MERGE_PATCH). НЕ для критичных полей. */
    private function saveUcStage(int $jobId, array $patch): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?) WHERE id=?"
            )->execute([
                json_encode(['update_classes_stage' => $patch], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) { /* не критично */ }
    }

    /**
     * PATCH_2 (§5/§6): АТОМАРНОЕ fail-closed резервирование запуска update_classes.
     * @return array{result:string, error?:string}
     */
    private function reserveUpdateClassesExecution(int $jobId, string $executionId): array
    {
        try {
            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs
                    SET uc_execution_state = 'started',
                        uc_execution_started_at = NOW(),
                        uc_execution_id = ?,
                        uc_execution_attempts = COALESCE(uc_execution_attempts,0) + 1,
                        updated_at = NOW()
                  WHERE id = ?
                    AND stage = 'update_classes_call'
                    AND stage_status IN ('pending','running','awaiting_user')
                    AND (uc_execution_state IS NULL OR uc_execution_state = '' OR uc_execution_state = 'not_started')"
            );
            $st->execute([$executionId, $jobId]);
            if ($st->rowCount() === 1) {
                return ['result' => 'reserved'];
            }
            $cur = DB::pdo()->prepare("SELECT stage, stage_status, uc_execution_state FROM refresh_jobs WHERE id=?");
            $cur->execute([$jobId]);
            $row = $cur->fetch(PDO::FETCH_ASSOC);
            if (!$row) return ['result' => 'conflict'];
            $es = (string)($row['uc_execution_state'] ?? '');
            if ((string)$row['stage'] !== 'update_classes_call') return ['result' => 'wrong_stage'];
            if ($es === 'started') return ['result' => 'already_started'];
            if (in_array($es, ['completed','verified','operator_skipped'], true)) return ['result' => 'already_completed'];
            return ['result' => 'conflict'];
        } catch (\Throwable $e) {
            return ['result' => 'db_error', 'error' => $e->getMessage()];
        }
    }

    /** Прочитать uc_execution_state джобы (реальный столбец). */
    private function ucExecutionState(int $jobId): string
    {
        try {
            $st = DB::pdo()->prepare("SELECT uc_execution_state FROM refresh_jobs WHERE id=?");
            $st->execute([$jobId]);
            return (string)($st->fetchColumn() ?: '');
        } catch (\Throwable $e) { return ''; }
    }

    /** Установить uc_execution_state (переход состояния после резервирования). */
    private function markUcState(int $jobId, string $state): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET uc_execution_state=?, updated_at=NOW()
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$state, $jobId]);
        } catch (\Throwable $e) { /* некритично */ }
    }

    /**
     * PATCH_3 (§3): нормализация физического корня. Полный путь; _usr не срезается;
     * без небезопасного lowercase.
     */
    protected function normalizePhysicalRoot(string $path): ?string
    {
        $p = trim($path);
        if ($p === '') return null;
        $p = str_replace('\\', '/', $p);
        $p = preg_replace('~/+~', '/', $p);
        $p = rtrim($p, '/');
        return $p !== '' ? $p : null;
    }

    /** Валиден ли путь как FastPanel docroot (/var/www/<user>/data/www/<site>). */
    private function looksLikeDocRoot(string $root): bool
    {
        return (bool)preg_match('~^/var/www/[A-Za-z0-9._-]+/data/www/[A-Za-z0-9._-]+$~', $root);
    }

    /** Извлечь ПОЛНЫЕ docroot'ы /var/www/<user>/data/www/<site> из тела ответа. */
    private function extractDocRootsFromBody(string $body): array
    {
        $roots = [];
        if (preg_match_all('~/var/www/[A-Za-z0-9._-]+/data/www/[A-Za-z0-9._-]+~', $body, $m)) {
            foreach ($m[0] as $r) { $n = $this->normalizePhysicalRoot($r); if ($n !== null) $roots[$n] = true; }
        }
        return array_keys($roots);
    }

    /**
     * PATCH_3 (§3): единый ДОВЕРЕННЫЙ canonical physical root. HTTP-response путь
     * НИКОГДА не входит в источники. Конфликт двух сильных источников → блокировка.
     * @return array{status:string, root?:string, source?:string, roots?:array, evidence?:array}
     *   status ∈ ok | unknown | conflict | invalid
     */
    private function resolveTrustedPhysicalRoot(array $job, int $siteId): array
    {
        $arts = $this->loadArtifacts($job);
        $primary = $this->normalizePhysicalRoot((string)($arts['replacement_plan']['site_root'] ?? ''));
        $fp = '';
        try {
            $st = DB::pdo()->prepare("SELECT fp_index_dir FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $fp = (string)($st->fetchColumn() ?: '');
        } catch (\Throwable $e) {}
        $fp = $this->normalizePhysicalRoot($fp);

        // Валидность сильных источников.
        if ($primary !== null && !$this->looksLikeDocRoot($primary)) {
            return ['status' => 'invalid', 'source' => 'replacement_plan.site_root', 'roots' => [$primary]];
        }
        if ($fp !== null && !$this->looksLikeDocRoot($fp)) {
            // fp_index_dir иногда не docroot — не используем как доверенный, но не блокируем primary.
            $fp = null;
        }

        if ($primary !== null && $fp !== null) {
            if ($primary === $fp) {
                return ['status' => 'ok', 'root' => $primary,
                    'source' => 'replacement_plan+fp_index_dir', 'evidence' => ['primary' => $primary, 'fp_index_dir' => $fp]];
            }
            // §3: два непустых доверенных источника различаются → блокировка.
            return ['status' => 'conflict', 'roots' => [$primary, $fp],
                'source' => 'replacement_plan vs fp_index_dir'];
        }
        if ($primary !== null) {
            return ['status' => 'ok', 'root' => $primary, 'source' => 'replacement_plan.site_root'];
        }
        if ($fp !== null) {
            return ['status' => 'ok', 'root' => $fp, 'source' => 'fp_index_dir'];
        }
        return ['status' => 'unknown'];
    }

    /**
     * PATCH_3 (§3): проверка HTTP-ответа по ДОВЕРЕННОМУ корню. HTTP-путь никогда
     * не сохраняется как trusted (сохраняется в response_detected_root отдельно).
     */
    private function validateUpdateClassesResponse(
        string $body,
        string $newDomain,
        string $trustedRoot,
        JobEventLogger $log
    ): array {
        if ($body === '') {
            return ['ok' => true, 'reason' => 'пустое тело', 'has_path' => false];
        }
        $trusted = $this->normalizePhysicalRoot($trustedRoot);
        $found = $this->extractDocRootsFromBody($body);
        if (empty($found)) {
            return ['ok' => true, 'reason' => 'нет полного physical root в ответе', 'has_path' => false];
        }
        if ($trusted === null) {
            return ['ok' => false, 'has_path' => true, 'response_detected_root' => $found[0],
                'reason' => 'trusted root неизвестен, а ответ содержит physical path'];
        }
        foreach ($found as $f) {
            if ($f !== $trusted) {
                return ['ok' => false, 'has_path' => true, 'response_detected_root' => $f,
                    'reason' => "physical root {$f} не совпадает с доверенным ({$trusted})"];
            }
        }
        return ['ok' => true, 'has_path' => true, 'reason' => 'physical root совпал с доверенным'];
    }

    /**
     * PATCH_3 (§3): устаревший resolveExpectedPhysicalRoots оставлен как тонкая
     * обёртка над доверенным резолвером (возвращает [root] или []).
     */
    private function resolveExpectedPhysicalRoots(array $job, int $siteId): array
    {
        $t = $this->resolveTrustedPhysicalRoot($job, $siteId);
        return (($t['status'] ?? '') === 'ok' && !empty($t['root'])) ? [$t['root']] : [];
    }

    /**
     * PATCH_2 (§4): FTP-подключение к сайту (протектед seam для тестов).
     */
    protected function makeSiteFtp(int $siteId): ?object
    {
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $site = $st->fetch(PDO::FETCH_ASSOC);
            if (!$site) return null;
            $host = trim((string)($site['ftp_host'] ?? ''));
            $user = trim((string)($site['ftp_user'] ?? ''));
            $pass = '';
            if (!empty($site['ftp_pass_enc'])) {
                try { $pass = Crypto::decrypt((string)$site['ftp_pass_enc']); } catch (\Throwable $e) {}
            }
            if ($host === '' || $user === '') return null;
            $ftp = $this->makeFtp($host, $user, $pass);
            $ftp->connect();
            return $ftp;
        } catch (\Throwable $e) { return null; }
    }

    /**
     * PATCH_3 (§10): FTP identity anchor. Абсолютный pwd → должен совпасть с
     * trusted root. chroot pwd=/ → config.php должен содержать домен джобы
     * (old/new/current). Только identity_verified разрешает verified.
     * @return array{status:string, via:string, marker?:string, pwd?:string}
     */
    protected function verifyFtpSiteIdentity($ftp, string $trustedRoot, array $job): array
    {
        $pwd = '';
        try { $pwd = (string)$ftp->pwd(); } catch (\Throwable $e) {}
        $normPwd = $this->normalizePhysicalRoot($pwd);
        $trusted = $this->normalizePhysicalRoot($trustedRoot);

        if ($normPwd !== null && strpos($normPwd, '/var/www/') === 0) {
            // Абсолютный pwd: pwd должен быть docroot или его предком/потомком в пределах trusted.
            if ($trusted !== null && ($normPwd === $trusted
                || strpos($trusted, $normPwd . '/') === 0
                || strpos($normPwd, $trusted . '/') === 0)) {
                return ['status' => 'identity_verified', 'via' => 'pwd_absolute', 'pwd' => $pwd];
            }
            return ['status' => 'identity_mismatch', 'via' => 'pwd_absolute', 'pwd' => $pwd];
        }

        // chroot pwd='/': независимый маркер — КАНОНИЧЕСКОЕ поле домена в config.php.
        $B = (string)($job['__site_base'] ?? '');
        $B = ($B === '') ? '' : rtrim($B, '/') . '/';
        $jobDomains = [];
        foreach (['old_domain','new_domain'] as $k) {
            $d = mb_strtolower(trim((string)($job[$k] ?? '')));
            if ($d !== '') $jobDomains[$d] = true;
        }
        try {
            $sid = (int)($job['site_id'] ?? 0);
            if ($sid > 0) {
                $st = DB::pdo()->prepare("SELECT current_domain FROM sites_managed WHERE id=?");
                $st->execute([$sid]);
                $cd = mb_strtolower(trim((string)($st->fetchColumn() ?: '')));
                if ($cd !== '') $jobDomains[$cd] = true;
            }
        } catch (\Throwable $e) {}

        $cfgDomains = $this->readConfigDomains($ftp, $B);
        if (empty($cfgDomains)) {
            return ['status' => 'identity_ambiguous', 'via' => 'no_config_domain', 'pwd' => $pwd];
        }
        foreach ($cfgDomains as $cd) {
            if (isset($jobDomains[$cd])) {
                return ['status' => 'identity_verified', 'via' => 'config_domain', 'marker' => $cd, 'pwd' => $pwd];
            }
        }
        return ['status' => 'identity_mismatch', 'via' => 'config_other_domain', 'pwd' => $pwd,
            'config_domains' => $cfgDomains];
    }

    /**
     * PATCH_2 (§10): FastPanel FTP chroot — достижимый каталог templates.
     */
    private function resolveRemoteTemplatesPath($ftp, string $trustedRoot): array
    {
        $pwd = '';
        try { $pwd = (string)$ftp->pwd(); } catch (\Throwable $e) {}
        $cands = ['templates', './templates', '/templates'];
        $tr = rtrim((string)$trustedRoot, '/');
        if ($tr !== '') $cands[] = $tr . '/templates';
        $checked = [];
        foreach ($cands as $c) {
            $checked[] = $c;
            try {
                $entries = $ftp->listDir($c);
                if (is_array($entries) && count($entries) > 0) {
                    return ['status' => 'found', 'path' => $c, 'ftp_pwd' => $pwd,
                        'candidate' => $c, 'checked_paths' => $checked];
                }
            } catch (\Throwable $e) {}
        }
        return ['status' => 'not_found', 'ftp_pwd' => $pwd, 'checked_paths' => $checked];
    }

    /** Нормализованный basename элемента ftp-листинга. */
    private function ftpBasename(string $name): string
    {
        $name = str_replace('\\', '/', trim($name));
        $name = rtrim($name, '/');
        $pos = strrpos($name, '/');
        return $pos === false ? $name : substr($name, $pos + 1);
    }

    /**
     * PATCH_3 (§5): множество CSS class-token'ов из selector'ов (без комментариев,
     * с границами CSS-идентификатора). Ищем только «.class», не произвольную подстроку.
     */
    private function extractCssClassTokens(string $css): array
    {
        // 1. удалить комментарии
        $css = preg_replace('~/\*.*?\*/~s', '', $css);
        $tokens = [];
        // 2. .class с границами: точка + CSS identifier, дальше не [A-Za-z0-9_-]
        if (preg_match_all('~\.(-?[A-Za-z_][A-Za-z0-9_-]*)(?![A-Za-z0-9_-])~', $css, $m)) {
            foreach ($m[1] as $t) $tokens[$t] = true;
        }
        return $tokens;
    }

    /**
     * ADDENDUM (§5/§6): class-token'ы из HTML-атрибутов class="..." (точное
     * разбиение по пробелам, без подстрок). Для single-responsive сайтов классы
     * живут в шаблонах (content.php), а не только в CSS.
     */
    private function extractHtmlClassTokens(string $html): array
    {
        $tokens = [];
        foreach (['~class\s*=\s*"([^"]*)"~i', "~class\\s*=\\s*'([^']*)'~i"] as $re) {
            if (preg_match_all($re, $html, $m)) {
                foreach ($m[1] as $cl) {
                    foreach (preg_split('~\s+~', trim($cl)) as $c) {
                        if ($c !== '') $tokens[$c] = true;
                    }
                }
            }
        }
        return $tokens;
    }

    /** Токены классов из одного output (CSS-selector + HTML class="..."). */
    private function extractClassTokensFromOutput(string $content): array
    {
        $t = $this->extractCssClassTokens($content);
        foreach ($this->extractHtmlClassTokens($content) as $k => $_) $t[$k] = true;
        return $t;
    }

    /** Существует ли файл по FTP (chroot-relative). */
    private function ftpFileExists($ftp, string $path): bool
    {
        try {
            if (method_exists($ftp, 'fileExists')) { $r = $ftp->fileExists($path); if (is_bool($r)) return $r; }
        } catch (\Throwable $e) {}
        try { $c = $ftp->tryGetContent($path); return $c !== null; } catch (\Throwable $e) { return false; }
    }

    /** Прочитать активный template из config.php ($template = N;). null если нет. */
    private function readActiveTemplateFromConfig($ftp, string $B = ''): ?string
    {
        foreach ([$B . 'config.php', './' . $B . 'config.php'] as $p) {
            $c = null;
            try { $c = $ftp->tryGetContent($p); } catch (\Throwable $e) { $c = null; }
            if ($c === null || $c === '') continue;
            // P1.2/P1.3: каноническое поле $template = N; убираем /* */, // (кроме ://) и # (в начале строки).
            $noComments = $this->stripPhpComments((string)$c);
            if (preg_match('~\$template\s*=\s*[\'"]?([A-Za-z0-9_-]+)[\'"]?\s*;~', $noComments, $m)) {
                return (string)$m[1];
            }
            return null;
        }
        return null;
    }

    /**
     * PATCH_4 (P1.2): канонические домены сайта из config.php (не текстовый поиск).
     * Разбирает $domain / define('DOMAIN') / 'current_domain' и т.п.
     */
    private function readConfigDomains($ftp, string $B = ''): array
    {
        $domains = [];
        foreach ([$B . 'config.php', './' . $B . 'config.php'] as $p) {
            $c = null;
            try { $c = $ftp->tryGetContent($p); } catch (\Throwable $e) { $c = null; }
            if ($c === null || $c === '') continue;
            $noComments = $this->stripPhpComments((string)$c);
            foreach ([
                '~\$domain\s*=\s*[\'"]([^\'"]+)[\'"]~',
                '~\$current_domain\s*=\s*[\'"]([^\'"]+)[\'"]~',
                '~\$site_domain\s*=\s*[\'"]([^\'"]+)[\'"]~',
                '~define\(\s*[\'"](?:DOMAIN|SITE_DOMAIN|CURRENT_DOMAIN)[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]~i',
            ] as $re) {
                if (preg_match_all($re, $noComments, $mm)) foreach ($mm[1] as $raw) {
                    $raw = trim($raw);
                    // Значение может быть полным URL — извлекаем host.
                    if (preg_match('~^https?://~i', $raw)) { $raw = (string)(parse_url($raw, PHP_URL_HOST) ?: ''); }
                    $raw = preg_replace('~[/:].*$~', '', $raw); // на всякий случай отрезаем хвост
                    $d = mb_strtolower(trim($raw));
                    if ($d !== '' && strpos($d, '.') !== false) $domains[$d] = true;
                }
            }
            break;
        }
        return array_keys($domains);
    }

    /** PATCH_5 (P1.3): убрать PHP-комментарии безопасно (не ломая :// в URL). */
    private function stripPhpComments(string $c): string
    {
        $c = preg_replace('~/\*.*?\*/~s', '', $c);          // блок
        $c = preg_replace('~(?<!:)//[^\n]*~', '', $c);        // // но не ://
        $c = preg_replace('~^\s*#[^\n]*~m', '', $c);          // # в начале строки
        return $c;
    }

    /** PATCH_5 (P1.3): каноническое имя brand/catalog из config.php. */
    private function readConfigBrand($ftp, string $B = ''): ?string
    {
        foreach ([$B . 'config.php', './' . $B . 'config.php'] as $p) {
            $c = null;
            try { $c = $ftp->tryGetContent($p); } catch (\Throwable $e) { $c = null; }
            if ($c === null || $c === '') continue;
            $nc = $this->stripPhpComments((string)$c);
            foreach (['~\$brand\s*=\s*[\'"]([A-Za-z0-9_-]+)[\'"]~', '~\$catalog\s*=\s*[\'"]([A-Za-z0-9_-]+)[\'"]~'] as $re) {
                if (preg_match($re, $nc, $m)) return (string)$m[1];
            }
            return null;
        }
        return null;
    }

    /** ADDENDUM: profile из artifacts (сохранённый до вызова), null если нет. */
    private function loadSavedProfile(array $job): ?array
    {
        $arts = $this->loadArtifacts($job);
        $p = $arts['update_classes_stage']['profile'] ?? null;
        return is_array($p) ? $p : null;
    }

    /** PATCH_4 (P0.1): evidence_before из artifacts (state_before для variant_state). */
    private function loadSavedEvidence(array $job): ?array
    {
        $arts = $this->loadArtifacts($job);
        $e = $arts['update_classes_stage']['evidence_before'] ?? null;
        return is_array($e) ? $e : null;
    }

    /**
     * PATCH_6 (P0.8): полон ли evidence_before для class_mapping — before-hash обязан
     * присутствовать для КАЖДОГО required path (mapping + required outputs) каждого unit.
     */
    private function classMappingEvidenceComplete(array $profile, ?array $evidence): bool
    {
        if (($profile['strategy'] ?? '') !== 'class_mapping') return true;
        $cm = is_array($evidence) ? ($evidence['class_mapping'] ?? null) : null;
        if (!is_array($cm) || empty($cm)) return false;
        foreach ((array)($profile['units'] ?? []) as $unit) {
            $paths = [(string)($unit['mapping'] ?? '')];
            foreach ((array)($unit['outputs'] ?? []) as $o) {
                $req = is_array($o) ? (bool)($o['required'] ?? true) : true;
                $pp  = is_array($o) ? (string)($o['path'] ?? '') : (string)$o;
                if ($req && $pp !== '') $paths[] = $pp;
            }
            foreach (array_unique($paths) as $pp) {
                if ($pp === '') continue;
                if (!isset($cm[$pp]) || !array_key_exists('sha256', (array)$cm[$pp]) || $cm[$pp]['sha256'] === null) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * PATCH_5 (P0.8): host признаётся alias текущего сайта только при доказанной связи —
     * запись в site_domain_aliases / sites_managed.aliases_json того же site_id, чей
     * physical root совпадает с trusted root джобы. Совпадения с old_domain НЕ достаточно.
     */
    private function isConfirmedAliasHost(string $host, int $siteId, array $job): bool
    {
        $host = mb_strtolower(trim($host));
        if ($host === '') return false;
        $norm = function(string $h): string { $h = mb_strtolower(trim($h)); return preg_replace('~^www\.~', '', $h); };
        $target = $norm($host);
        try {
            // PATCH_6.1 (item 1): читаем СУЩЕСТВУЮЩИЕ источники alias 27-го дампа.
            //   sites_managed.aliases      — JSON-массив строк (домены);
            //   sites_managed.fp_raw_json  — {"aliases":[{"name":..,"raw_name":..}]};
            // плюс введённые в PATCH_6 aliases_json (массив строк) и таблица site_domain_aliases.
            // SELECT * — устойчиво к отсутствию отдельных колонок (aliases_json может
            // отсутствовать до миграции 035; тогда просто не будет в $row).
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];

            foreach (['aliases', 'aliases_json'] as $col) {
                if (!empty($row[$col])) {
                    $al = json_decode((string)$row[$col], true);
                    if (is_array($al)) foreach ($al as $a) {
                        $val = is_array($a) ? (string)($a['name'] ?? $a['raw_name'] ?? '') : (string)$a;
                        if ($val !== '' && $norm($val) === $target) return true;
                    }
                }
            }
            if (!empty($row['fp_raw_json'])) {
                $raw = json_decode((string)$row['fp_raw_json'], true);
                if (is_array($raw) && isset($raw['aliases']) && is_array($raw['aliases'])) {
                    foreach ($raw['aliases'] as $a) {
                        $val = is_array($a) ? (string)($a['name'] ?? $a['raw_name'] ?? '') : (string)$a;
                        if ($val !== '' && $norm($val) === $target) return true;
                    }
                }
            }
        } catch (\Throwable $e) {}
        try {
            $st = DB::pdo()->prepare("SELECT COUNT(*) c FROM site_domain_aliases WHERE site_id=? AND (LOWER(alias_domain)=? OR LOWER(alias_domain)=?)");
            $st->execute([$siteId, $host, $target]);
            if ((int)($st->fetchColumn() ?: 0) > 0) return true;
        } catch (\Throwable $e) { /* таблицы может не быть */ }
        return false;
    }

    /**
     * PATCH_6.1: подтвердить, что custom script path РЕАЛЬНО существует внутри доверенного
     * физического root через FTP. true — существует; false — не существует / выходит за root;
     * null — FTP недоступен (проверить нельзя). Используется только для первого вызова
     * custom-path/custom-full-url (auto_from_ftp уже подтверждён детекцией).
     */
    private function customScriptExistsInTrustedRoot(array $job, string $trustedRoot, string $relPath, JobEventLogger $log): ?bool
    {
        $relPath = ltrim(trim($relPath), '/');
        if ($relPath === '') return false;
        // anti-traversal: путь не должен выходить за пределы root.
        if (strpos($relPath, '..') !== false || strpos($relPath, "\0") !== false) {
            $log->warn('update_classes_call', 'custom path содержит запрещённый сегмент (..) — не в root.');
            return false;
        }
        $ftp = $this->makeSiteFtp((int)$job['site_id']);
        if ($ftp === null) { $log->info('update_classes_call', 'custom path: FTP недоступен — проверить существование нельзя (null).'); return null; }
        try {
            // Проверка root-relative (та же конвенция, что detectRefreshScript:
            // fileExists('update_classes.php')). FTP-сессия сайта чрутирована в docroot;
            // физическое совпадение root уже подтверждено resolveTrustedPhysicalRoot=ok выше.
            $exists = $ftp->fileExists($relPath);
            $log->info('update_classes_call', 'custom path ' . $relPath . ' в trusted root (' . rtrim($trustedRoot, '/') . '): ' . ($exists ? 'найден' : 'не найден'));
            return (bool)$exists;
        } catch (\Throwable $e) {
            $log->info('update_classes_call', 'custom path: FTP-ошибка при проверке (' . $e->getMessage() . ') — null.');
            return null;
        } finally {
            try { $ftp->disconnect(); } catch (\Throwable $e) {}
        }
    }


    /**
     * ADDENDUM (§3/§4): открыть FTP, построить profile, для variant_state снять
     * state_before. 'ftp_unavailable' если FTP недоступен (fail-closed выше).
     */
    private function resolveVerificationProfile(array $job, string $trustedRoot, string $scriptPath): array
    {
        $ftp = $this->makeSiteFtp((int)$job['site_id']);
        if ($ftp === null) return ['strategy' => 'ftp_unavailable'];
        try {
            $p = $this->buildVerificationProfile($ftp, $trustedRoot, $job, $scriptPath);
            $strat = (string)($p['strategy'] ?? '');
            // P0.9: identity фиксируется в профиле (none/confirmed_absent требуют identity_verified).
            if (in_array($strat, ['none','variant_state','class_mapping'], true)) {
                $jobForId = $job; $jobForId['__site_base'] = (string)($p['site_base'] ?? '');
                $ident = $this->verifyFtpSiteIdentity($ftp, $this->normalizePhysicalRoot($trustedRoot) ?? $trustedRoot, $jobForId);
                $p['identity'] = (string)($ident['status'] ?? 'identity_ambiguous');
            }
            if ($strat === 'variant_state') {
                $p['state_before'] = $this->readVariantState($ftp, (string)($p['state']['file'] ?? 'data/variant-state.json'));
            }
            // P0.5: evidence_before для class_mapping — SHA-256 mapping + required outputs ДО вызова.
            if ($strat === 'class_mapping') {
                $p['evidence_before'] = ['class_mapping' => $this->captureClassMappingEvidence($ftp, (array)($p['units'] ?? []))];
            }
            return $p;
        } finally {
            try { $ftp->disconnect(); } catch (\Throwable $e) {}
        }
    }

    /**
     * PATCH_5 (P0.5): снять доказательства ДО вызова — для каждого mapping и каждого
     * required output: exists/size/sha256. Хранится в profile.evidence_before, чтобы
     * после HTTP доказать, что файлы изменились ИМЕННО в этом execution.
     */
    private function captureClassMappingEvidence($ftp, array $units): array
    {
        $ev = [];
        $mappingPaths = [];
        foreach ($units as $unit) {
            $mp = (string)($unit['mapping'] ?? '');
            if ($mp !== '') $mappingPaths[$mp] = (string)($unit['id'] ?? '');
        }
        foreach ($units as $unit) {
            $uid = (string)($unit['id'] ?? '');
            $paths = [(string)($unit['mapping'] ?? '')];
            foreach ((array)($unit['outputs'] ?? []) as $o) {
                $pp = is_array($o) ? (string)($o['path'] ?? '') : (string)$o;
                $req = is_array($o) ? (bool)($o['required'] ?? true) : true;
                if ($req && $pp !== '') $paths[] = $pp;
            }
            foreach (array_unique($paths) as $pp) {
                if ($pp === '') continue;
                $c = null;
                try { $c = $ftp->tryGetContent($pp); } catch (\Throwable $e) {}
                if ($c === null) {
                    $ev[$pp] = ['exists' => false, 'size' => 0, 'sha256' => null];
                } else {
                    $entry = ['exists' => true, 'size' => strlen($c), 'sha256' => hash('sha256', $c), 'unit' => $uid];
                    // ТЗ046 §6: для mapping-файлов сохраняем сами пары (old:new) для semantic before/after diff.
                    if (isset($mappingPaths[$pp])) {
                        $entry['pairs'] = ClassMappingDeltaVerifier::parsePairs($c);
                        $entry['pairs_count'] = count($entry['pairs']);
                    }
                    $ev[$pp] = $entry;
                }
            }
        }
        return $ev;
    }

    /** Прочитать variant-state.json по FTP. */
    private function readVariantState($ftp, string $file): ?array
    {
        try {
            $c = $ftp->tryGetContent($file);
            if ($c === null || $c === '') return null;
            $d = json_decode($c, true);
            return is_array($d) ? $d : null;
        } catch (\Throwable $e) { return null; }
    }

    /**
     * PATCH_5 (P1.1): whitelist сосуществующих old-классов — PROFILE-SPECIFIC и ЯВНЫЙ,
     * по умолчанию ПУСТОЙ. Никаких глобальных эвристик swiper/slick/owl. Классы
     * задаются оператором per-site: app_settings 'uc.allowed_old_coexist.<domain>'
     * (приоритет) или глобальный 'uc.allowed_old_coexist' (обычно пуст). Так на сайте,
     * где класс ДОЛЖЕН быть заменён, он не будет скрыт чужим whitelist.
     */
    private function allowedOldCoexist($ftp = null, string $B = '', $domains = ''): array
    {
        $cands = is_array($domains) ? $domains : [$domains];
        // добавим канонические домены из config.php (стабильный идентификатор сайта)
        if ($ftp !== null) { try { foreach ($this->readConfigDomains($ftp, $B) as $d) $cands[] = $d; } catch (\Throwable $e) {} }
        $wl = [];
        foreach ($cands as $dom) {
            $dom = mb_strtolower(trim((string)$dom));
            if ($dom === '') continue;
            $extra = (string)AppSettings::getRaw('uc.allowed_old_coexist.' . $dom, '');
            if ($extra !== '') { foreach (explode(',', $extra) as $c) { $c = trim($c); if ($c !== '') $wl[] = $c; } }
        }
        // P1.2 (PATCH_6): глобальный fallback УДАЛЁН из автоматического verified. Он
        // допустим только как явный emergency-mode (uc.allowed_old_coexist.emergency=1),
        // и тогда пишется предупреждение — но НЕ участвует в auto verified (см. verifier).
        return array_values(array_unique($wl));
    }

    /**
     * PATCH_4 (P0.7): единый remote_site_base — каталог, где реально лежат
     * config.php/templates/скрипт. Используется ВСЕМИ FTP-операциями. '' = docroot;
     * для multisite — 'sites/<subsite>'. Возвращает ['base'=>..., 'multisite'=>bool,
     * 'subsites'=>[...], 'status'=>ok|multisite_unconfigured|not_found].
     */
    private function resolveRemoteSiteBase($ftp, array $job): array
    {
        // Явный subsite: сначала sites_managed.uc_site_subroot, затем artifacts.
        $explicit = '';
        try {
            $sid = (int)($job['site_id'] ?? 0);
            if ($sid > 0) {
                $st = DB::pdo()->prepare("SELECT uc_site_subroot FROM sites_managed WHERE id=?");
                $st->execute([$sid]);
                $explicit = trim((string)($st->fetchColumn() ?: ''));
            }
        } catch (\Throwable $e) {}
        if ($explicit === '') {
            $arts = $this->loadArtifacts($job);
            $explicit = (string)($arts['uc_profile']['site_subroot'] ?? '');
        }
        $probe = function($base) use ($ftp) {
            $b = rtrim($base, '/'); $pfx = $b === '' ? '' : $b . '/';
            return $this->ftpFileExists($ftp, $pfx . 'config.php')
                || $this->ftpFileExists($ftp, $pfx . 'update_classes.php')
                || $this->ftpFileExists($ftp, $pfx . 'variant-refresh.php')
                || $this->ftpFileExists($ftp, $pfx . 'templates');
        };
        if ($explicit !== '' && $probe($explicit)) {
            return ['base' => rtrim($explicit, '/'), 'multisite' => true, 'status' => 'ok'];
        }
        // docroot напрямую?
        if ($probe('')) return ['base' => '', 'multisite' => false, 'status' => 'ok'];
        // multisite: каталог sites/<subsite>
        $subs = [];
        try {
            foreach ((array)$ftp->listDir('sites') as $n) {
                $b = $this->ftpBasename((string)$n);
                if ($b !== '' && $b !== '.' && $b !== '..' && $b !== '_hostmap.php' && $this->ftpFileExists($ftp, 'sites/' . $b . '/config.php')) $subs[] = $b;
            }
        } catch (\Throwable $e) {}
        if (!empty($subs)) {
            // P0.7: попробовать автоматически определить subsite из sites/_hostmap.php
            // по old/new/current домену джобы. Только точное соответствие.
            $auto = $this->resolveSubsiteFromHostmap($ftp, $job, $subs);
            if ($auto !== null && $probe('sites/' . $auto)) {
                return ['base' => 'sites/' . $auto, 'multisite' => true, 'status' => 'ok', 'auto_subsite' => $auto, 'subsites' => $subs];
            }
            // Без явного/однозначного subsite — НЕ угадываем (P0.4/P0.7).
            return ['base' => '', 'multisite' => true, 'subsites' => $subs,
                    'hostmap_suggestion' => $auto, 'status' => 'multisite_unconfigured'];
        }
        return ['base' => '', 'multisite' => false, 'status' => 'not_found'];
    }

    /**
     * PATCH_5 (P0.7): точное соответствие домена джобы → subsite slug по sites/_hostmap.php
     * (host => slug). Возвращает slug или null (если нет однозначного соответствия).
     */
    private function resolveSubsiteFromHostmap($ftp, array $job, array $subs): ?string
    {
        $map = null;
        try { $c = $ftp->tryGetContent('sites/_hostmap.php'); } catch (\Throwable $e) { $c = null; }
        if (!isset($c) || $c === null || $c === '') return null;
        // _hostmap.php: `return array('host' => 'slug', ...)` — парсим пары без eval.
        $pairs = [];
        if (preg_match_all("~['\"]([A-Za-z0-9.\-]+)['\"]\\s*=>\\s*['\"]([A-Za-z0-9_\-]+)['\"]~", (string)$c, $mm, PREG_SET_ORDER)) {
            foreach ($mm as $m) { $pairs[mb_strtolower($m[1])] = $m[2]; }
        }
        if (empty($pairs)) return null;
        $cands = [];
        foreach (['new_domain','old_domain'] as $k) {
            $d = mb_strtolower(trim((string)($job[$k] ?? '')));
            if ($d !== '' && isset($pairs[$d])) $cands[$pairs[$d]] = true;
            if ($d !== '' && isset($pairs['www.' . $d])) $cands[$pairs['www.' . $d]] = true;
        }
        $cands = array_keys(array_intersect_key(array_flip(array_keys($cands)), array_flip($subs)) ?: []);
        // строго один слаг, реально существующий среди subs
        $valid = array_values(array_filter(array_keys($cands ? array_flip($cands) : []), fn($s) => in_array($s, $subs, true)));
        return (count($valid) === 1) ? $valid[0] : null;
    }

    /**
     * PATCH_4 (P0.3/P0.4/P0.6/P0.8): построить immutable verification profile по
     * структуре. Единый base; multisite → unconfigured; нет templates+есть скрипт
     * → unknown; строгий active template; per-output required manifest.
     */
    private function buildVerificationProfile($ftp, string $trustedRoot, array $job, string $scriptPath): array
    {
        $baseInfo = $this->resolveRemoteSiteBase($ftp, $job);
        if (($baseInfo['status'] ?? '') === 'multisite_unconfigured') {
            return ['strategy' => 'multisite_unconfigured', 'subsites' => $baseInfo['subsites'] ?? []];
        }
        if (($baseInfo['status'] ?? '') === 'not_found') {
            // FTP открыт, но структуры сайта не видно по base — не считаем это none.
            return ['strategy' => ($scriptPath !== '') ? 'unknown' : 'not_found'];
        }
        $B = ($baseInfo['base'] === '') ? '' : rtrim($baseInfo['base'], '/') . '/';
        $jobDomains = [mb_strtolower((string)($job['new_domain'] ?? '')), mb_strtolower((string)($job['old_domain'] ?? ''))];
        $wl = $this->allowedOldCoexist($ftp, $B, $jobDomains);

        $profile = [
            'profile_version' => 2, 'strategy' => 'unknown',
            'script' => ['kind' => 'none', 'path' => (string)$scriptPath],
            'physical_root' => $trustedRoot, 'site_base' => $baseInfo['base'], 'multisite' => (bool)($baseInfo['multisite'] ?? false),
            'active_template' => null, 'brand' => '', 'units' => [], 'state' => null,
            'allowed_old_coexist' => $wl,
        ];

        $hasUpdateClasses  = $this->ftpFileExists($ftp, $B . 'update_classes.php');
        $hasVariantRefresh = $this->ftpFileExists($ftp, $B . 'variant-refresh.php');
        $hasVariantState   = $this->ftpFileExists($ftp, $B . 'data/variant-state.json');

        // §8 (v4): если найден update_classes.php — определить КОНКРЕТНОЕ
        // семейство по структурным сигнатурам (не по маркеру ответа) и
        // зафиксировать family + fingerprint + точный completion-marker в
        // профиле. Это единственный источник marker для проверки успеха —
        // общий список маркеров удалён. Читаем файл ПОЛНОСТЬЮ; частичное чтение
        // → ftp_error.
        $ucFamily = null; $ucMarker = ''; $ucFingerprint = ''; $ucFamilyStatus = '';
        if ($hasUpdateClasses) {
            $ucContent = null;
            try { $ucContent = $ftp->tryGetContent($B . 'update_classes.php'); } catch (\Throwable $e) { $ucContent = null; }
            if ($ucContent === null || $ucContent === '') {
                return ['strategy' => 'ftp_error', 'error' => 'update_classes_read_failed'];
            }
            $reg = new RandomizationScriptProfileRegistry();
            $det = $reg->detect($ucContent);
            $ucFamilyStatus = (string)($det['status'] ?? 'needs_review');
            $ucFingerprint = (string)($det['fingerprint'] ?? '');
            if ($ucFamilyStatus === 'supported') {
                $ucFamily = (string)($det['family'] ?? '');
                $ucMarker = (string)($det['marker'] ?? '');
            }
        }

        // Семейство B: variant_state.
        if ($hasVariantRefresh && $hasVariantState) {
            $profile['strategy'] = 'variant_state';
            $profile['script'] = ['kind' => 'variant_refresh', 'path' => $scriptPath ?: ('/' . $B . 'variant-refresh.php')];
            $profile['state'] = ['file' => $B . 'data/variant-state.json', 'required_change_fields' => ['refresh_nonce']];
            return $profile;
        }

        // templates?
        $tplEntries = [];
        try { foreach ((array)$ftp->listDir($B . 'templates') as $n) { $b = $this->ftpBasename((string)$n); if ($b !== '' && $b !== '.' && $b !== '..') $tplEntries[] = $b; } }
        catch (\Throwable $e) {}

        if (empty($tplEntries)) {
            // P0.3: нет templates + есть скрипт/custom → unknown (fail-closed), НЕ none.
            if ($hasUpdateClasses || $scriptPath !== '') {
                $profile['strategy'] = 'unknown';
                $profile['script'] = ['kind' => $hasUpdateClasses ? 'update_classes' : 'custom', 'path' => $scriptPath];
                return $profile;
            }
            // Достоверно нет механизма → none (confirmed_absent).
            $profile['strategy'] = 'none';
            $profile['script'] = ['kind' => 'none', 'path' => ''];
            $profile['confirmed_absent'] = true;
            return $profile;
        }

        $activeTpl = $this->readActiveTemplateFromConfig($ftp, $B);
        $numericTpls = array_values(array_filter($tplEntries, fn($e) => ctype_digit((string)$e)));

        // Семейство D (split): кандидаты templates/<T>/source/desktop/...
        $splitCands = [];
        foreach ($numericTpls as $T) {
            if ($this->ftpFileExists($ftp, $B . 'templates/' . $T . '/source/desktop/class_name_mapping_desktop.txt')) {
                $splitCands[] = (string)$T;
            }
        }
        if (!empty($splitCands)) {
            // P0.6 строгий выбор.
            $T = $this->chooseActiveTemplate($splitCands, $activeTpl);
            if (!is_string($T)) return $T; // error-массив (mismatch/ambiguous)
            $base = $B . 'templates/' . $T;
            $tplHtml = [$base . '/content.php', $base . '/header.php', $base . '/footer.php'];
            $ftpRef = $ftp;
            $mk = function($css) use ($tplHtml, $ftpRef) {
                $o = [['path' => $css, 'proof' => 'mapping_tokens', 'required' => true]];
                // P0.6: HTML-шаблоны, которые реально существуют и переписываются скриптом,
                // считаются required (их отсутствие/непеременность блокирует verified).
                foreach ($tplHtml as $h) {
                    $hc = null; try { $hc = $ftpRef->tryGetContent($h); } catch (\Throwable $e) {}
                    $nonEmpty = ($hc !== null && trim((string)$hc) !== '');
                    $o[] = ['path' => $h, 'proof' => 'mapping_tokens', 'required' => $nonEmpty];
                }
                return $o;
            };
            // §8.6 (v4): class_mapping допустим ТОЛЬКО при доказанном семействе.
            if ($ucFamilyStatus === 'conflict') {
                return ['strategy' => 'error', 'error' => 'update_classes_family_conflict', 'conflicts' => (array)($det['conflicts'] ?? [])];
            }
            if ($ucFamily === null || $ucMarker === '') {
                return ['strategy' => 'unknown', 'reason' => 'update_classes_family_unresolved'];
            }
            $profile['strategy'] = 'class_mapping';
            $profile['script'] = ['kind' => 'update_classes', 'path' => $scriptPath];
            $profile['family'] = $ucFamily; $profile['marker'] = $ucMarker; $profile['fingerprint'] = $ucFingerprint;
            $profile['active_template'] = (string)$T;
            $profile['units'] = [
                ['id' => 'desktop', 'mapping' => $base . '/source/desktop/class_name_mapping_desktop.txt',
                 'outputs' => $mk($base . '/desktop/assets/styles.css'), 'required' => true],
                ['id' => 'mobile', 'mapping' => $base . '/source/mobile/class_name_mapping_mobile.txt',
                 'outputs' => $mk($base . '/mobile/assets/styles.css'), 'required' => true],
            ];
            return $profile;
        }

        // Семейство C (single): templates/<brand>/<T>/source/class_name_mapping.txt
        // и 7k-подобный templates/<T>/source/class_name_mapping.txt.
        $brands = array_values(array_filter($tplEntries, fn($e) => !ctype_digit((string)$e)));
        $searchBases = [];
        foreach ($brands as $brand) {
            try { foreach ((array)$ftp->listDir($B . 'templates/' . $brand) as $n) { $b = $this->ftpBasename((string)$n); if (ctype_digit($b)) $searchBases[] = ['brand' => $brand, 'tpl' => $b, 'base' => $B . 'templates/' . $brand . '/' . $b]; } }
            catch (\Throwable $e) {}
        }
        foreach ($numericTpls as $T) $searchBases[] = ['brand' => '', 'tpl' => (string)$T, 'base' => $B . 'templates/' . $T];

        $candidates = [];
        foreach ($searchBases as $sb) {
            if ($this->ftpFileExists($ftp, $sb['base'] . '/source/class_name_mapping.txt')) $candidates[] = $sb;
        }
        if (empty($candidates)) {
            if ($hasUpdateClasses || $scriptPath !== '') return ['strategy' => 'unknown'];
            $profile['strategy'] = 'none'; $profile['confirmed_absent'] = true; return $profile;
        }

        // P0.6/P1.3: строгий выбор brand+tpl. Одинаковый tpl id у нескольких brand →
        // ambiguous, ЕСЛИ config однозначно не задаёт brand ($brand/$catalog).
        $byTpl = [];
        foreach ($candidates as $c) { $byTpl[(string)$c['tpl']][] = $c; }
        $cfgBrand = $this->readConfigBrand($ftp, $B);
        $chosen = null;
        if ($activeTpl !== null) {
            if (!isset($byTpl[(string)$activeTpl])) {
                return ['strategy' => 'error', 'error' => 'active_template_mismatch',
                    'config_template' => (string)$activeTpl, 'candidates' => array_map(fn($c) => $c['base'], $candidates)];
            }
            $cands = $byTpl[(string)$activeTpl];
            if (count($cands) > 1) {
                if ($cfgBrand !== null) {
                    $match = array_values(array_filter($cands, fn($c) => (string)$c['brand'] === (string)$cfgBrand));
                    if (count($match) === 1) { $chosen = $match[0]; }
                }
                if ($chosen === null) return ['strategy' => 'error', 'error' => 'active_template_ambiguous_brands',
                    'config_brand' => $cfgBrand, 'candidates' => array_map(fn($c) => $c['base'], $cands)];
            } else {
                $chosen = $cands[0];
            }
        } else {
            if (count($candidates) === 1) $chosen = $candidates[0];
            elseif ($cfgBrand !== null) {
                $match = array_values(array_filter($candidates, fn($c) => (string)$c['brand'] === (string)$cfgBrand));
                if (count($match) === 1) $chosen = $match[0];
                else return ['strategy' => 'error', 'error' => 'active_template_ambiguous',
                    'config_brand' => $cfgBrand, 'candidates' => array_map(fn($c) => $c['base'], $candidates)];
            }
            else return ['strategy' => 'error', 'error' => 'active_template_ambiguous',
                'candidates' => array_map(fn($c) => $c['base'], $candidates)];
        }

        // outputs main: styles.css (required) | пул assets/css/*.css. P0.6: каждый
        // непустой на момент построения CSS считается required (его пропажа/непеременность
        // блокирует verified); пустые (placeholder) — optional. HTML — required если есть.
        $outputs = [];
        if ($this->ftpFileExists($ftp, $chosen['base'] . '/styles.css')) {
            $outputs[] = ['path' => $chosen['base'] . '/styles.css', 'proof' => 'mapping_tokens', 'required' => true];
        } else {
            try {
                foreach ((array)$ftp->listDir($chosen['base'] . '/assets/css') as $n) {
                    $b = $this->ftpBasename((string)$n);
                    if (!preg_match('~\.css$~i', $b)) continue;
                    $p = $chosen['base'] . '/assets/css/' . $b;
                    $c = null; try { $c = $ftp->tryGetContent($p); } catch (\Throwable $e) {}
                    $nonEmpty = ($c !== null && trim((string)$c) !== '');
                    $outputs[] = ['path' => $p, 'proof' => 'mapping_tokens', 'required' => $nonEmpty];
                }
            } catch (\Throwable $e) {}
        }
        foreach (['content.php', 'header.php', 'footer.php'] as $h) {
            $hp = $chosen['base'] . '/' . $h;
            $hc = null; try { $hc = $ftp->tryGetContent($hp); } catch (\Throwable $e) {}
            $nonEmpty = ($hc !== null && trim((string)$hc) !== '');
            $outputs[] = ['path' => $hp, 'proof' => 'mapping_tokens', 'required' => $nonEmpty];
        }
        // §8.6 (v4): class_mapping допустим ТОЛЬКО при доказанном семействе.
        if ($ucFamilyStatus === 'conflict') {
            return ['strategy' => 'error', 'error' => 'update_classes_family_conflict', 'conflicts' => (array)($det['conflicts'] ?? [])];
        }
        if ($ucFamily === null || $ucMarker === '') {
            return ['strategy' => 'unknown', 'reason' => 'update_classes_family_unresolved'];
        }
        $profile['strategy'] = 'class_mapping';
        $profile['script'] = ['kind' => 'update_classes', 'path' => $scriptPath];
        $profile['family'] = $ucFamily; $profile['marker'] = $ucMarker; $profile['fingerprint'] = $ucFingerprint;
        $profile['brand'] = (string)$chosen['brand'];
        $profile['active_template'] = (string)$chosen['tpl'];
        $profile['units'] = [
            ['id' => 'main', 'mapping' => $chosen['base'] . '/source/class_name_mapping.txt',
             'outputs' => $outputs, 'required' => true],
        ];
        return $profile;
    }

    /** P0.6: однозначный выбор active template для split-кандидатов. */
    private function chooseActiveTemplate(array $cands, ?string $activeTpl)
    {
        if ($activeTpl !== null) {
            if (!in_array((string)$activeTpl, $cands, true)) {
                return ['strategy' => 'error', 'error' => 'active_template_mismatch',
                    'config_template' => (string)$activeTpl, 'candidates' => $cands];
            }
            return (string)$activeTpl;
        }
        if (count($cands) === 1) return (string)$cands[0];
        return ['strategy' => 'error', 'error' => 'active_template_ambiguous', 'candidates' => $cands];
    }

    /**
     * PATCH_4 (P0.8/P0.9/P1.1): проверить одну class_mapping unit. Каждый required
     * output проверяется ОТДЕЛЬНО (существует/непуст/mtime); один файл не компенсирует
     * отсутствие другого. old-классы запрещены, кроме profile whitelist.
     */
    private function verifyClassMappingUnit($ftp, array $unit, int $minPairs, float $threshold, array $allowedOld, array $mtimeOpts = [], array $evidenceBefore = []): array
    {
        $id = (string)($unit['id'] ?? '');
        $mapContent = null;
        try { $mapContent = $ftp->tryGetContent((string)($unit['mapping'] ?? '')); } catch (\Throwable $e) {}
        if ($mapContent === null || trim($mapContent) === '') {
            return ['id' => $id, 'verified' => false, 'status' => 'verification_error', 'reason' => 'mapping_absent'];
        }
        $pairs = $this->parseClassMapping((string)$mapContent);
        if (empty($pairs)) {
            return ['id' => $id, 'verified' => false, 'status' => 'verification_error', 'reason' => 'mapping_invalid'];
        }

        $execStartedAt = (string)($mtimeOpts['execution_started_at'] ?? '');
        $skewSec = (int)($mtimeOpts['skew'] ?? 300);
        $checkMtime = ($mtimeOpts['mode'] ?? 'auto') !== 'legacy_recovery' && $execStartedAt !== '';
        $execTs = $execStartedAt !== '' ? strtotime($execStartedAt) : false;

        // P0.8: каждый required output — отдельно (exists+nonempty+mtime+proof+hash-change).
        $tokens = [];
        $outResults = [];
        $anyTokenOutput = false;
        $mtimeSeen = false; $mtimeStale = false;
        $haveEvidence = !empty($evidenceBefore);
        $anyReqHashSeen = false; $anyReqChanged = false; $anyReqUnchanged = false; $unchangedSamples = [];
        foreach ((array)($unit['outputs'] ?? []) as $out) {
            $path = is_array($out) ? (string)($out['path'] ?? '') : (string)$out;
            $proof = is_array($out) ? (string)($out['proof'] ?? 'mapping_tokens') : 'mapping_tokens';
            $req = is_array($out) ? (bool)($out['required'] ?? true) : true;
            $c = null;
            try { $c = $ftp->tryGetContent($path); } catch (\Throwable $e) {}
            $exists = ($c !== null && $c !== '');
            if (!$exists) {
                $outResults[$path] = ['ok' => !$req, 'reason' => 'missing_or_empty', 'required' => $req];
                if ($req) return ['id' => $id, 'verified' => false, 'status' => 'verification_error',
                    'reason' => 'required_output_missing:' . $path, 'outputs' => $outResults];
                continue;
            }
            if ($proof === 'mapping_tokens') {
                $anyTokenOutput = true;
                foreach ($this->extractClassTokensFromOutput((string)$c) as $tok => $_) $tokens[$tok] = true;
            }
            // P0.5: сравнение sha256 с evidence_before (только для required с известным before-hash).
            if ($req && $haveEvidence && isset($evidenceBefore[$path]['sha256']) && $evidenceBefore[$path]['sha256'] !== null) {
                $anyReqHashSeen = true;
                $changedThis = (hash('sha256', (string)$c) !== $evidenceBefore[$path]['sha256']);
                if ($changedThis) { $anyReqChanged = true; }
                else { $anyReqUnchanged = true; if (count($unchangedSamples) < 8) $unchangedSamples[] = $path; }
                $outResults[$path]['changed'] = $changedThis;
                $outResults[$path]['sha_before'] = $evidenceBefore[$path]['sha256'];
                $outResults[$path]['sha_after'] = hash('sha256', (string)$c);
            }
            // P1.1: mtime каждого output.
            if ($checkMtime && $execTs !== false) {
                $dir = (strpos($path, '/') !== false) ? substr($path, 0, strrpos($path, '/')) : '';
                $mt = $this->ftpMtime($ftp, $dir, $this->ftpBasename($path));
                if ($mt !== null) { $mtimeSeen = true; if ($mt < ($execTs - $skewSec)) $mtimeStale = true; }
            }
            $outResults[$path] = ['ok' => true, 'required' => $req, 'proof' => $proof];
        }
        if (!$anyTokenOutput) {
            return ['id' => $id, 'verified' => false, 'status' => 'verification_error', 'reason' => 'no_token_outputs', 'outputs' => $outResults];
        }
        // P0.5: mapping hash change.
        $mp = (string)($unit['mapping'] ?? '');
        if ($haveEvidence && isset($evidenceBefore[$mp]['sha256']) && $evidenceBefore[$mp]['sha256'] !== null) {
            $mc = null; try { $mc = $ftp->tryGetContent($mp); } catch (\Throwable $e) {}
            if ($mc !== null) { $anyReqHashSeen = true;
                if (hash('sha256', (string)$mc) !== $evidenceBefore[$mp]['sha256']) $anyReqChanged = true;
                else { $anyReqUnchanged = true; $unchangedSamples[] = $mp; } }
        }

        // P0.9: old-классы запрещены, кроме whitelist.
        $newFound = 0; $oldFound = 0; $oldLeaked = 0; $leakedSamples = [];
        $wl = array_fill_keys($allowedOld, true);
        foreach ($pairs as [$oldC, $newC]) {
            if ($newC !== '' && isset($tokens[$newC])) $newFound++;
            if ($oldC !== '' && isset($tokens[$oldC])) {
                $oldFound++;
                if (!isset($wl[$oldC])) { $oldLeaked++; if (count($leakedSamples) < 5) $leakedSamples[] = $oldC; }
            }
        }
        $total = count($pairs);
        $ratio = $total > 0 ? ($newFound / $total) : 0.0;
        $tsBad = ($mtimeSeen && $mtimeStale);
        // Ограниченный recovery-сигнал (НЕ сертификация каждого файла): при наличии
        // evidence_before, если НИ ОДИН required output/mapping не изменился → скрипт не
        // отработал в этом execution → not_applied. Это heuristic для ambiguous-recovery.
        $hashUnchanged = ($haveEvidence && $anyReqHashSeen && !$anyReqChanged);
        // P1.2: при наличии evidence_before mtime вспомогателен; без него mtime=unavailable
        // в auto-режиме → ambiguous (нет доказательства свежести).
        $mtimeUnavailBad = ($checkMtime && !$haveEvidence && !$mtimeSeen);
        $verified = ($total >= $minPairs) && ($ratio >= $threshold) && ($oldLeaked === 0)
                    && !$tsBad && !$hashUnchanged && !$mtimeUnavailBad;
        $status = $verified ? 'verified'
                  : ($hashUnchanged ? 'not_applied'
                  : (($tsBad || $mtimeUnavailBad) ? 'ambiguous' : 'not_applied'));
        return ['id' => $id, 'verified' => $verified, 'status' => $status,
            'mapping_total' => $total, 'new_found' => $newFound, 'old_found' => $oldFound,
            'old_leaked' => $oldLeaked, 'old_leaked_samples' => $leakedSamples,
            'hash_unchanged' => $hashUnchanged, 'unchanged_samples' => $unchangedSamples,
            'ratio' => round($ratio, 4), 'mtime_seen' => $mtimeSeen, 'mtime_stale' => $mtimeStale, 'outputs' => $outResults];
    }

    /**
     * PATCH_3 + ADDENDUM: profile-driven FTP-проверка. Использует СОХРАНЁННЫЙ
     * profile (opts['profile']) либо строит структурно. Проверяет только units из
     * profile. strategy=none → not_applicable; variant_state → nonce; class_mapping
     * → units; identity + mtime. Никаких desktop/mobile-предположений.
     * @return array{status, physical_root, identity, strategy, units, desktop, mobile, details, timestamp_check}
     */
    /**
     * ТЗ046 ADDENDUM §8/§25: единое authoritative ядро proof рандомизации для class_mapping.
     * FTP identity + AFTER read (с того же trusted root) + semantic diff + verdict.
     * @return array{verdict:array, diff:array, identity:string}
     */
    protected function runClassDeltaProof(array $job, string $trustedRoot, string $siteBase, array $before): array
    {
        $siteId = (int)$job['site_id'];
        $identityOk = false; $identityStatus = 'identity_ambiguous';
        $diff = ['ok' => false, 'changed_pairs' => 0, 'common' => 0, 'error' => 'ftp_unavailable', 'files' => [], 'sample' => null];
        $ftp = $this->makeSiteFtp($siteId);
        if ($ftp !== null) {
            try {
                $root = $this->normalizePhysicalRoot($trustedRoot) ?? '';
                $jobForId = $job; $jobForId['__site_base'] = $siteBase;
                $ident = $this->verifyFtpSiteIdentity($ftp, $root, $jobForId);
                $identityStatus = (string)($ident['status'] ?? 'identity_ambiguous');
                $identityOk = ($identityStatus === 'identity_verified');
                $reader = function (string $p) use ($ftp) { return $ftp->tryGetContent($p); };
                $diff = ClassMappingDeltaVerifier::diff($before, $reader);
            } catch (\Throwable $e) {
                $diff = ['ok' => false, 'changed_pairs' => 0, 'common' => 0, 'error' => 'ftp_exception:' . $e->getMessage(), 'files' => [], 'sample' => null];
            }
        }
        $verdict = ClassMappingDeltaVerifier::verdict($identityOk, $before, $diff);
        return ['verdict' => $verdict, 'diff' => $diff, 'identity' => $identityStatus];
    }

    /** Установить verified по подтверждённой дельте (общий UPDATE для normal и recovery путей). */
    private function markClassDeltaVerified(int $jobId, string $execId, array $verdict, array $diff, bool $httpAmbiguous, string $outcome): bool
    {
        $completePatch = [
            'outcome' => $outcome,
            'changed_pairs' => (int)$verdict['changed_pairs'],
            'files_checked' => (int)$verdict['files_checked'],
            'http_ambiguous' => $httpAmbiguous,
            'execution_id' => $execId,
            'completed_at' => date('Y-m-d H:i:s'),
        ];
        $u = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                php_uniquification_verified_at = NOW(), uc_execution_state = 'completed',
                stage_status = 'ok', stage_error = NULL, stage_finished_at = NOW(), next_run_at = NOW(),
                artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
              WHERE id = ? AND stage = 'update_classes_call'
                AND php_uniquification_verified_at IS NULL
                AND stage_status IN ('running','pending','awaiting_user')"
        );
        $u->execute([json_encode(['update_classes_stage' => $completePatch], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
        return $u->rowCount() === 1;
    }

    /** Сохранить class_delta_result артефакт (§18). */
    private function saveClassDeltaResult(int $jobId, JobEventLogger $log, array $diff, array $verdict, string $identityStatus, bool $httpAmbiguous): void
    {
        $this->saveArtifacts($jobId, ['class_delta_after' => [
            'checked_at' => gmdate('Y-m-d H:i:s'), 'identity' => $identityStatus,
            'changed_pairs' => (int)($diff['changed_pairs'] ?? 0), 'unchanged_pairs' => (int)($diff['unchanged'] ?? 0),
            'common_pairs' => (int)($diff['common'] ?? 0), 'added_pairs' => (int)($diff['added'] ?? 0),
            'removed_pairs' => (int)($diff['removed'] ?? 0), 'before_pairs' => (int)($diff['before_count'] ?? 0),
            'after_pairs' => (int)($diff['after_count'] ?? 0), 'verified' => (bool)$verdict['verified'],
            'verdict' => $verdict['reason'], 'http_ambiguous' => $httpAmbiguous,
            'examples' => array_slice((array)($diff['examples'] ?? []), 0, 10),
        ]], $log, 'update_classes_call');
    }

    /**
     * ТЗ046 ADDENDUM §10–§17: recovery для class_mapping (uc_execution_state started/completed/ambiguous).
     * НЕ повторяет mutating HTTP. BEFORE берётся из сохранённого evidence; AFTER — текущие mapping-файлы.
     * verified ТОЛЬКО при identity verified И changed_pairs>=1. Иначе awaiting_user (без retry).
     * @return bool true — если стадия разрешена этим методом (verified или awaiting_user выставлен).
     */
    protected function recoverClassMappingByDelta(array $job, JobEventLogger $log, string $trustedRoot,
        array $savedProfile, array $savedEvidence, string $ucState): bool
    {
        $jobId = (int)$job['id'];
        $siteBase = (string)($savedProfile['site_base'] ?? '');
        $execId = (string)($job['uc_execution_id'] ?? '');

        // BEFORE из сохранённого evidence: mapping-файлы = записи с непустыми 'pairs'.
        $evCm = (array)($savedEvidence['class_mapping'] ?? []);
        $beforeFiles = [];
        foreach ($evCm as $path => $e) {
            if (!is_array($e)) continue;
            if (!empty($e['exists']) && isset($e['pairs']) && is_array($e['pairs']) && $e['pairs'] !== []) {
                $beforeFiles[(string)$path] = ['ok' => true, 'pairs_count' => (int)($e['pairs_count'] ?? count($e['pairs'])),
                    'sha256' => $e['sha256'] ?? null, 'pairs' => $e['pairs']];
            }
        }
        // §15: BEFORE отсутствует/повреждён → нельзя ни доказать, ни безопасно перезапустить → awaiting_user.
        if (empty($beforeFiles)) {
            $log->error('update_classes_call',
                '🚨 Невозможно достоверно проверить предыдущий запуск update_classes.php. Панель обнаружила незавершённое '
                . 'выполнение, однако снимок классов ДО запуска отсутствует или повреждён. Определить, изменилась ли '
                . 'рандомизация, невозможно. Повторный автоматический запуск заблокирован. Требуется вмешательство.',
                ['event_code' => 'uc.class_delta_error', 'technical_reason' => 'before_evidence_missing']);
            $this->markUcState($jobId, 'ambiguous');
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: снимок классов ДО запуска отсутствует — проверка невозможна',
                    next_run_at=NULL
                  WHERE id=? AND stage='update_classes_call' AND php_uniquification_verified_at IS NULL"
            )->execute([$jobId]);
            return true;
        }
        $before = ['ok' => true, 'files' => $beforeFiles];

        $proof = $this->runClassDeltaProof($job, $trustedRoot, $siteBase, $before);
        $diff = $proof['diff']; $verdict = $proof['verdict']; $identityStatus = $proof['identity'];
        $this->saveClassDeltaResult($jobId, $log, $diff, $verdict, $identityStatus, /*ambiguous*/true);

        if ($verdict['verified']) {
            $changed = (int)$verdict['changed_pairs'];
            $beforeCount = (int)($diff['before_count'] ?? 0);
            $unchanged = (int)($diff['unchanged'] ?? 0);
            $s = $verdict['sample'] ?? null;
            $log->ok('update_classes_call',
                "✓ Рандомизация классов подтверждена после восстановления джобы. Предыдущий процесс панели завершился "
                . "до окончания контрольной проверки; повторный запуск update_classes.php НЕ выполнялся. Панель сравнила "
                . "сохранённые классы ДО предыдущего запуска с текущим состоянием сайта. Проверено классов: {$beforeCount}. "
                . "Изменено: {$changed}. Не изменилось: {$unchanged}." . ($s ? " Пример: {$s['key']}: {$s['before']} → {$s['after']}." : ''),
                ['event_code' => 'uc.class_delta_verified']);
            $this->markClassDeltaVerified($jobId, $execId, $verdict, $diff, /*ambiguous*/true, 'class_delta_verified_recovery');
            return true;
        }

        $reason = (string)$verdict['reason'];
        $this->markUcState($jobId, ($reason === 'no_class_change' || $reason === 'no_common_keys') ? 'not_applied' : 'ambiguous');
        $beforeCount = (int)($diff['before_count'] ?? 0);

        if ($reason === 'no_class_change') {
            $log->error('update_classes_call',
                "🚨 Рандомизация классов не подтверждена. Ранее update_classes.php мог быть запущен, но панель не успела "
                . "получить окончательный результат. Контрольное сравнение: классов ДО: {$beforeCount}, изменено: 0. "
                . "Повторный автоматический запуск НЕ выполняется, так как предыдущий вызов мог частично выполнить действия. "
                . "Требуется проверка человеком.",
                ['event_code' => 'uc.class_delta_zero']);
            $err = 'update_classes: рандомизация не подтверждена при восстановлении (изменено 0 классов)';
        } elseif ($reason === 'no_common_keys') {
            $log->error('update_classes_call',
                "🚨 Рандомизация классов не подтверждена: структура mapping-файлов полностью изменилась (нет общих ключей "
                . "классов между снимками ДО и ПОСЛЕ), поэтому простое сравнение невозможно. Повторный автоматический запуск "
                . "заблокирован. Требуется проверка.",
                ['event_code' => 'uc.class_delta_error', 'technical_reason' => 'no_common_keys']);
            $err = 'update_classes: verification_inconclusive (нет общих ключей классов)';
        } else {
            $human = [
                'ftp_identity_unverified' => 'не удалось подтвердить, что читается именно этот сайт (FTP identity)',
                'before_snapshot_incomplete' => 'снимок классов ДО неполный',
            ][$reason] ?? ('проверка не завершена (' . $reason . ')');
            $log->error('update_classes_call',
                "🚨 Рандомизация классов не подтверждена при восстановлении: {$human}. Повторный автоматический запуск "
                . "заблокирован. Требуется проверка доступа/состояния сайта.",
                ['event_code' => 'uc.class_delta_error', 'technical_reason' => $reason]);
            $err = 'update_classes: рандомизация не подтверждена при восстановлении (' . $reason . ')';
        }
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL
              WHERE id=? AND stage='update_classes_call' AND php_uniquification_verified_at IS NULL"
        )->execute([$err, $jobId]);
        return true;
    }

    /**
     * ТЗ046 §6–§14: единственный proof факта рандомизации для class_mapping — семантическая
     * дельта правых частей mapping ДО/ПОСЛЕ. Ставит php_uniquification_verified_at ТОЛЬКО при
     * changed_pairs>=1 И verified FTP identity. delta=0 (даже при HTTP 200) → awaiting_user без
     * повторного mutating-вызова. Строгая output-проверка — как warning-диагностика (§12).
     */
    protected function settleClassMappingByDelta(array $job, JobEventLogger $log, string $trustedRoot,
        array $baselineProfile, array $evidenceBefore, string $execId, string $execStartedAt,
        array $httpResult, array $verifyOpts): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $units = (array)($baselineProfile['units'] ?? []);
        $siteBase = (string)($baselineProfile['site_base'] ?? '');

        // BEFORE-пары из evidence_before (захвачены до HTTP).
        $evCm = (array)($evidenceBefore['class_mapping'] ?? []);
        $beforeFiles = [];
        foreach ($units as $unit) {
            $mp = (string)($unit['mapping'] ?? '');
            if ($mp === '') continue;
            $e = $evCm[$mp] ?? null;
            if (is_array($e) && !empty($e['exists']) && isset($e['pairs']) && is_array($e['pairs']) && $e['pairs'] !== []) {
                $beforeFiles[$mp] = ['ok' => true, 'pairs_count' => (int)($e['pairs_count'] ?? count($e['pairs'])),
                    'sha256' => $e['sha256'] ?? null, 'pairs' => $e['pairs']];
            } else {
                $beforeFiles[$mp] = ['ok' => false, 'reason' => 'before_missing'];
            }
        }
        $before = ['ok' => !empty($beforeFiles) && !in_array(false, array_map(fn($f) => !empty($f['ok']), $beforeFiles), true),
                   'files' => $beforeFiles];

        // Единое authoritative ядро: FTP identity + AFTER read + semantic diff + verdict.
        $proof = $this->runClassDeltaProof($job, $trustedRoot, $siteBase, $before);
        $diff = $proof['diff']; $verdict = $proof['verdict']; $identityStatus = $proof['identity'];
        $httpAmbiguous = empty($httpResult['ok']);

        // артефакт class_delta_after (компактный) — всегда сохраняем как доказательство.
        $afterArtifact = [
            'checked_at' => gmdate('Y-m-d H:i:s'),
            'identity' => $identityStatus,
            'changed_pairs' => (int)($diff['changed_pairs'] ?? 0),
            'before_count' => (int)($diff['before_count'] ?? 0),
            'after_count' => (int)($diff['after_count'] ?? 0),
            'unchanged' => (int)($diff['unchanged'] ?? 0),
            'files' => $diff['files'] ?? [],
            'sample' => $diff['sample'] ?? null,
            'verdict' => $verdict['reason'],
            'http_ambiguous' => $httpAmbiguous,
        ];
        $this->saveArtifacts($jobId, ['class_delta_after' => $afterArtifact], $log, 'update_classes_call');

        if ($verdict['verified']) {
            // §11: подтверждено фактическим сравнением. Ставим verified даже при ambiguous HTTP (§14: без повтора).
            $changed = (int)$verdict['changed_pairs'];
            $beforeCount = (int)($diff['before_count'] ?? 0);
            $unchanged = (int)($diff['unchanged'] ?? 0);
            $s = $verdict['sample'] ?? null;
            $log->ok('update_classes_call',
                "✓ Рандомизация классов подтверждена фактическим сравнением до/после. "
                . "Проверено mapping-файлов: " . (int)$verdict['files_checked'] . ". "
                . "Классов до: {$beforeCount}. Изменено значений: {$changed}. Не изменилось: {$unchanged}."
                . ($s ? " Пример: {$s['key']}: {$s['before']} → {$s['after']}." : '')
                . ($httpAmbiguous ? " (HTTP-ответ был неоднозначным — подтверждено по фактическому состоянию классов.)" : ''),
                ['event_code' => 'uc.class_delta_verified']);

            // §12: строгая output-проверка теперь только warning-диагностика (не отменяет факт).
            try {
                $strict = $this->verifyUniquificationByFtp($job, $log, $trustedRoot,
                    ['execution_started_at' => $execStartedAt] + $verifyOpts);
                if (($strict['status'] ?? '') !== 'verified') {
                    $log->warn('update_classes_call',
                        'Рандомизация подтверждена сравнением классов, но дополнительная строгая проверка выходных файлов дала статус «'
                        . (string)($strict['status'] ?? '?') . '» — это не отменяет факт рандомизации, оставлено как диагностика.',
                        ['event_code' => 'uc.class_delta_verified']);
                }
            } catch (\Throwable $e) { /* диагностика не критична */ }

            $completePatch = [
                'outcome' => 'class_delta_verified',
                'changed_pairs' => $changed,
                'files_checked' => (int)$verdict['files_checked'],
                'http_ambiguous' => $httpAmbiguous,
                'execution_id' => $execId,
                'completed_at' => date('Y-m-d H:i:s'),
            ];
            $u = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    php_uniquification_verified_at = NOW(), uc_execution_state = 'completed',
                    stage_status = 'ok', stage_error = NULL, stage_finished_at = NOW(), next_run_at = NOW(),
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                  WHERE id = ? AND stage = 'update_classes_call'
                    AND php_uniquification_verified_at IS NULL
                    AND uc_execution_id = ?
                    AND stage_status IN ('running','pending','awaiting_user')"
            );
            $u->execute([json_encode(['update_classes_stage' => $completePatch], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId, $execId]);
            if ($u->rowCount() !== 1) {
                $back = $this->reloadJob($jobId) ?? $job;
                if (empty($back['php_uniquification_verified_at'])) {
                    $log->warn('update_classes_call', 'class_delta verified, но completion UPDATE не применился (gate/execution сменились). Оставляю без ложного success.');
                }
            }
            return;
        }

        // НЕ подтверждено — разбираем причину.
        $reason = (string)$verdict['reason'];
        $this->markUcState($jobId, $reason === 'no_class_change' ? 'not_applied' : 'ambiguous');

        if ($reason === 'no_class_change') {
            $beforeCount = (int)($diff['before_count'] ?? 0);
            $log->error('update_classes_call',
                "🚨 Рандомизация классов не подтверждена. Скрипт update_classes.php сообщил об успешном выполнении, "
                . "но контрольные значения классов до и после запуска совпадают. Изменено классов: 0 из {$beforeCount}. "
                . "Панель НЕ считает этап выполненным. Автоматический повторный вызов скрипта не выполняется, "
                . "чтобы исключить повторный mutating-запуск. Требуется проверка update_classes.php.",
                ['event_code' => 'uc.class_delta_zero']);
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: рандомизация не подтверждена (изменено 0 классов) — проверьте update_classes.php',
                    next_run_at=NULL
                  WHERE id=? AND stage='update_classes_call' AND php_uniquification_verified_at IS NULL"
            )->execute([$jobId]);
            return;
        }

        // verification_error: identity/ before / after unreadable — без повтора mutating-вызова (§14).
        $human = [
            'ftp_identity_unverified' => 'не удалось подтвердить, что читается именно этот сайт (FTP identity)',
            'before_snapshot_incomplete' => 'отсутствует достоверный снимок классов ДО запуска',
        ][$reason] ?? ('проверка не завершена (' . $reason . ')');
        $log->error('update_classes_call',
            "🚨 Рандомизация классов не подтверждена: {$human}. Панель НЕ считает этап выполненным и не повторяет "
            . "запуск скрипта автоматически. Требуется проверка доступа/состояния сайта.",
            ['event_code' => 'uc.class_delta_error', 'technical_reason' => $reason]);
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET stage_status='awaiting_user',
                stage_error=?, next_run_at=NULL
              WHERE id=? AND stage='update_classes_call' AND php_uniquification_verified_at IS NULL"
        )->execute(['update_classes: рандомизация не подтверждена (' . $reason . ')', $jobId]);
    }

    protected function verifyUniquificationByFtp(array $job, JobEventLogger $log, string $trustedRoot, array $opts = []): array
    {
        $siteId = (int)$job['site_id'];
        $minPairs = max(1, AppSettings::getInt('uc.minimum_mapping_pairs', 20));
        $threshold = 0.95;
        $mode = (string)($opts['verification_mode'] ?? 'auto');
        $execStartedAt = (string)($opts['execution_started_at'] ?? '');
        $skewSec = max(0, AppSettings::getInt('uc.mtime_clock_skew_sec', 300));
        $scriptPath = (string)($opts['script_path'] ?? '');

        $root = $this->normalizePhysicalRoot($trustedRoot) ?? '';
        $base = [
            'status' => 'verification_error', 'physical_root' => $root, 'remote_templates_path' => '',
            'identity' => 'identity_ambiguous', 'strategy' => 'unknown', 'units' => [],
            'desktop' => ['applicable' => false], 'mobile' => ['applicable' => false],
            'details' => '', 'timestamp_check' => 'unavailable',
        ];
        if ($root === '') { $base['details'] = 'trusted root неизвестен'; $base['status'] = 'ambiguous'; return $base; }

        $ftp = $this->makeSiteFtp($siteId);
        if ($ftp === null) { $base['details'] = 'FTP недоступен'; return $base; }

        try {
            // Profile: сохранённый или структурный (даёт единый site_base для всех FTP-операций).
            $profile = (isset($opts['profile']) && is_array($opts['profile'])) ? $opts['profile']
                : $this->buildVerificationProfile($ftp, $root, $job, $scriptPath);
            $strategy = (string)($profile['strategy'] ?? 'unknown');
            $base['strategy'] = $strategy;
            $siteBase = (string)($profile['site_base'] ?? '');

            // §10 identity anchor (P0.7: с единым base).
            $jobForIdent = $job; $jobForIdent['__site_base'] = $siteBase;
            $ident = $this->verifyFtpSiteIdentity($ftp, $root, $jobForIdent);
            $base['identity'] = $ident['status'];
            if ($ident['status'] === 'identity_mismatch') {
                $base['status'] = 'verification_error';
                $base['details'] = 'FTP identity mismatch (' . $ident['via'] . ')';
                return $base;
            }
            $identityOk = ($ident['status'] === 'identity_verified');

            if ($strategy === 'error') {
                $base['status'] = 'ambiguous';
                $base['details'] = (string)($profile['error'] ?? 'profile_error');
                return $base;
            }
            if ($strategy === 'multisite_unconfigured') {
                $base['status'] = 'awaiting_user';
                $base['details'] = 'multisite_unconfigured: subsite не выбран (' . implode(',', $profile['subsites'] ?? []) . ')';
                return $base;
            }
            if ($strategy === 'none') {
                $base['status'] = 'not_applicable';
                $base['details'] = 'strategy=none (нет механизма рандомизации, confirmed_absent)';
                return $base;
            }
            if ($strategy === 'unknown' || $strategy === 'not_found') {
                $base['status'] = 'verification_error';
                $base['details'] = 'verification_profile_' . $strategy;
                return $base;
            }
            if ($strategy === 'variant_state') {
                $stateFile = (string)($profile['state']['file'] ?? 'data/variant-state.json');
                $after = $this->readVariantState($ftp, $stateFile);
                $before = $opts['state_before'] ?? null;
                $fields = (array)($profile['state']['required_change_fields'] ?? ['refresh_nonce']);
                $base['units'] = ['variant_state' => ['after' => $after]];
                if ($after === null) { $base['status'] = 'verification_error'; $base['details'] = 'variant-state.json недоступен'; return $base; }
                if (!is_array($before)) {
                    $base['status'] = 'ambiguous'; $base['details'] = 'variant_state: нет state_before для сравнения'; return $base;
                }
                $changed = false;
                foreach ($fields as $f) { if (($before[$f] ?? null) !== ($after[$f] ?? null)) { $changed = true; break; } }
                $base['status'] = ($changed && $identityOk) ? 'verified' : ($changed ? 'verification_error' : 'not_applied');
                $base['details'] = 'variant_state changed=' . ($changed ? 'yes' : 'no') . '; identity=' . $ident['status'];
                return $base;
            }

            // strategy = class_mapping — проверяем ТОЛЬКО units из profile.
            $units = (array)($profile['units'] ?? []);
            if (empty($units)) { $base['status'] = 'verification_error'; $base['details'] = 'class_mapping без units'; return $base; }

            $allowedOld = (array)($profile['allowed_old_coexist'] ?? []);
            $mtimeOpts = ['mode' => $mode, 'execution_started_at' => $execStartedAt, 'skew' => $skewSec];
            $evBefore = (array)($opts['evidence_before']['class_mapping'] ?? []);

            $unitResults = []; $allVerified = true; $mtimeSeen = false; $mtimeStale = false;
            foreach ($units as $unit) {
                $ur = $this->verifyClassMappingUnit($ftp, $unit, $minPairs, $threshold, $allowedOld, $mtimeOpts, $evBefore);
                $unitResults[(string)$unit['id']] = $ur;
                if (empty($ur['verified'])) $allVerified = false;
                if (!empty($ur['mtime_seen'])) { $mtimeSeen = true; if (!empty($ur['mtime_stale'])) $mtimeStale = true; }
            }
            $base['units'] = $unitResults;
            if (isset($unitResults['desktop'])) $base['desktop'] = ['applicable' => true] + $unitResults['desktop'];
            if (isset($unitResults['mobile'])) $base['mobile'] = ['applicable' => true] + $unitResults['mobile'];

            $tsCheck = 'unavailable';
            if ($mode !== 'legacy_recovery' && $execStartedAt !== '') $tsCheck = $mtimeSeen ? ($mtimeStale ? 'stale' : 'fresh') : 'unavailable';
            elseif ($mode === 'legacy_recovery') $tsCheck = 'soft';
            $base['timestamp_check'] = $tsCheck;

            if ($allVerified && $identityOk && $tsCheck !== 'stale') $base['status'] = 'verified';
            elseif ($tsCheck === 'stale') $base['status'] = 'ambiguous';
            elseif (!$identityOk) $base['status'] = 'verification_error';
            else $base['status'] = 'not_applied';

            $parts = [];
            foreach ($unitResults as $id => $ur) {
                $parts[] = $id . '=' . (($ur['new_found'] ?? '?') . '/' . ($ur['mapping_total'] ?? '?') . ' oldLeaked=' . ($ur['old_leaked'] ?? '?') . ($ur['verified'] ? ' ok' : ' FAIL(' . ($ur['reason'] ?? $ur['status']) . ')'));
            }
            $base['details'] = 'root=' . $root . '; base=' . ($profile['site_base'] ?? '') . '; strategy=class_mapping; tpl=' . ($profile['active_template'] ?? '?')
                . '; identity=' . $ident['status'] . '; ts=' . $tsCheck . '; ' . implode('; ', $parts);
            return $base;
        } catch (\Throwable $e) {
            $base['details'] = $e->getMessage();
            return $base;
        } finally {
            try { $ftp->disconnect(); } catch (\Throwable $e) {}
        }
    }

    /** mtime файла через listDirEntries (если FTP умеет). null если недоступно. */
    private function ftpMtime($ftp, string $dir, string $file): ?int
    {
        if (!method_exists($ftp, 'listDirEntries')) return null;
        try {
            foreach ((array)$ftp->listDirEntries($dir) as $e) {
                $name = is_array($e) ? (string)($e['name'] ?? '') : '';
                if ($this->ftpBasename($name) === $file) {
                    $mt = is_array($e) ? ($e['mtime'] ?? null) : null;
                    return $mt !== null ? (int)$mt : null;
                }
            }
        } catch (\Throwable $e) {}
        return null;
    }

    /** Разобрать mapping «oldClass:newClass» построчно. */
    private function parseClassMapping(string $content): array
    {
        $pairs = [];
        foreach (preg_split('~\r?\n~', $content) as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, ':') === false) continue;
            [$old, $new] = array_pad(explode(':', $line, 2), 2, '');
            $old = trim($old); $new = trim($new);
            if ($old !== '' && $new !== '') $pairs[] = [$old, $new];
        }
        return $pairs;
    }

    /**
     * PATCH_3 (§6/§7): урегулировать стадию по ПОЛУЧЕННОМУ verify-результату с
     * conditional UPDATE (stage/status/version predicates) + rowCount.
     * @return array{result:string} result ∈ applied|already_settled|state_conflict|terminal|update_failed|not_verified
     */
    private function settleUpdateClassesByFtp(int $jobId, array $res, array $expectedState, JobEventLogger $log): array
    {
        $status = (string)($res['status'] ?? 'verification_error');
        $details = (string)($res['details'] ?? '');
        $artifactPatch = [
            'outcome' => $status === 'verified' ? 'verified' : $status,
            'ftp_verified' => $status === 'verified',
            'ftp_details' => $details,
            'ftp_identity' => (string)($res['identity'] ?? ''),
            'ftp_desktop' => $res['desktop'] ?? null,
            'ftp_mobile' => $res['mobile'] ?? null,
            'verified_root' => (string)($res['physical_root'] ?? ''),
            'remote_templates_path' => (string)($res['remote_templates_path'] ?? ''),
            'timestamp_check' => (string)($res['timestamp_check'] ?? 'unavailable'),
        ];
        $expStage = (string)($expectedState['stage'] ?? 'update_classes_call');

        // ADDENDUM: strategy=none → not_applicable открывает gate без verified_at.
        if ($status === 'not_applicable') {
            $artifactPatch['outcome'] = 'not_applicable';
            $this->saveUcStage($jobId, $artifactPatch);
            $u = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET uc_execution_state='completed', stage_status='ok',
                    stage_error=NULL, stage_finished_at=NOW(), next_run_at=NOW()
                  WHERE id=? AND stage=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $u->execute([$jobId, $expStage]);
            $log->info('update_classes_call', 'update_classes_not_applicable (FTP): ' . $details);
            return ['result' => $u->rowCount() === 1 ? 'applied' : 'already_settled'];
        }

        if ($status !== 'verified') {
            // не verified — awaiting_user с деталями (conditional по стадии).
            $this->saveUcStage($jobId, $artifactPatch);
            $u = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL
                  WHERE id=? AND stage=? AND php_uniquification_verified_at IS NULL
                    AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $u->execute([mb_substr('update_classes_call: FTP=' . $status . ' — ' . $details, 0, 1000), $jobId, $expStage]);
            $log->warn('update_classes_call', 'update_classes_ftp_' . $status . ': ' . $details);
            return ['result' => 'not_verified'];
        }

        // verified: conditional UPDATE со stage/status/version predicates.
        if ($expStage === 'update_classes_call') {
            $u = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    php_uniquification_verified_at = NOW(), uc_execution_state = 'completed',
                    stage_status = 'ok', stage_error = NULL, stage_finished_at = NOW(), next_run_at = NOW(),
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                 WHERE id = ? AND stage = 'update_classes_call'
                   AND php_uniquification_verified_at IS NULL
                   AND stage_status IN ('running','pending','awaiting_user')"
            );
            $u->execute([json_encode(['update_classes_stage' => $artifactPatch], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId]);
        } else {
            // legacy-джоба дальше по pipeline: открыть gate, стадию не финишим.
            $u = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    php_uniquification_verified_at = NOW(), uc_execution_state = 'completed',
                    stage_status = 'pending', stage_error = NULL, next_run_at = NOW(),
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?)
                 WHERE id = ? AND stage = ?
                   AND php_uniquification_verified_at IS NULL
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            );
            $u->execute([json_encode(['update_classes_stage' => $artifactPatch], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $jobId, $expStage]);
        }

        if ($u->rowCount() === 1) {
            $log->ok('update_classes_call', 'update_classes_ftp_verified: ' . $details);
            return ['result' => 'applied'];
        }

        // §7 rowCount=0 — перечитать, решить already_settled / state_conflict.
        $cur = DB::pdo()->prepare("SELECT stage, stage_status, php_uniquification_verified_at FROM refresh_jobs WHERE id=?");
        $cur->execute([$jobId]);
        $row = $cur->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['php_uniquification_verified_at'])) {
            return ['result' => 'already_settled'];
        }
        if ($row && in_array((string)$row['stage'], ['done','failed','cancelled','superseded'], true)) {
            return ['result' => 'terminal'];
        }
        $log->warn('update_classes_call', 'update_classes_settle_state_conflict (rowCount=0)');
        return ['result' => 'state_conflict'];
    }

    /**
     * PATCH_3 (§8): публичный вход ручного восстановления. Сервис сам проверяет
     * допустимость (нельзя обойти контроллер), verify один раз, conditional settle.
     * @return array{outcome:string, details:string, settle?:string}
     */
    public function recoverUpdateClassesByFtp(int $jobId, JobEventLogger $log): array
    {
        $job = $this->reloadJob($jobId);
        if (!$job) return ['outcome' => 'verification_error', 'details' => 'джоба не найдена'];

        // §15 идемпотентность.
        if (!empty($job['php_uniquification_verified_at']) || self::updateClassesGateSatisfied($job)) {
            return ['outcome' => 'already_settled', 'details' => 'gate уже закрыт'];
        }
        // §8 контракт допустимости на СЕРВИСНОМ уровне (свежая строка).
        if (!self::manualVerificationPolicy($job)['allowed']) {
            return ['outcome' => 'not_allowed', 'details' => 'состояние джобы не допускает ручную проверку'];
        }

        $siteId = (int)$job['site_id'];
        $trust = $this->resolveTrustedPhysicalRoot($job, $siteId);
        if (($trust['status'] ?? '') === 'conflict') {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: expected_physical_root_conflict', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return ['outcome' => 'expected_physical_root_conflict', 'details' => implode(' vs ', $trust['roots'] ?? [])];
        }
        if (($trust['status'] ?? '') !== 'ok') {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error='update_classes: expected_physical_root_unknown', next_run_at=NULL
                  WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$jobId]);
            return ['outcome' => 'expected_physical_root_unknown', 'details' => (string)($trust['status'] ?? '')];
        }

        // ADDENDUM: используем СОХРАНЁННЫЙ profile (если есть), иначе строим структурно.
        $opts = ['verification_mode' => 'legacy_recovery'];
        $saved = $this->loadSavedProfile($job);
        if (is_array($saved)) $opts['profile'] = $saved;
        // ТЗ 039 §9.3: read-back сравнивается с baseline, сохранённым ДО HTTP.
        // «Проверить по FTP ещё раз» обязана поднять evidence_before/state_before
        // из artifacts, иначе variant_state не с чем сравнить (ambiguous навсегда).
        $savedEv = $this->loadSavedEvidence($job);
        if (is_array($savedEv)) {
            $opts['evidence_before'] = $savedEv;
            if (isset($savedEv['variant_state']) && is_array($savedEv['variant_state'])) {
                $opts['state_before'] = $savedEv['variant_state'];
            }
        }
        $es = (string)($job['uc_execution_started_at'] ?? '');
        if ($es !== '') $opts['execution_started_at'] = $es;
        // §11 ручное восстановление — мягкий mtime-режим (явно).
        $res = $this->verifyUniquificationByFtp($job, $log, (string)$trust['root'], $opts);
        $settle = $this->settleUpdateClassesByFtp($jobId, $res, ['stage' => (string)$job['stage']], $log);
        return ['outcome' => (string)$res['status'], 'details' => (string)$res['details'], 'settle' => $settle['result']];
    }

    /**
     * PATCH_3 (§12): единый предикат допустимости ручной проверки (UI + controller + service).
     * @return array{allowed:bool, reason:string}
     */
    public static function manualVerificationPolicy(array $job): array
    {
        if (!empty($job['php_uniquification_verified_at'])) return ['allowed' => false, 'reason' => 'already_verified'];
        if (self::updateClassesGateSatisfied($job)) return ['allowed' => false, 'reason' => 'gate_satisfied'];
        $stage = (string)($job['stage'] ?? '');
        $status = (string)($job['stage_status'] ?? '');
        $exec = (string)($job['uc_execution_state'] ?? '');
        if (in_array($stage, ['done','failed','cancelled','superseded'], true)) return ['allowed' => false, 'reason' => 'terminal'];
        if ($stage === 'update_classes_call') {
            // §gate-fix: FTP-проверку предлагаем ТОЛЬКО после реальной попытки исполнения
            // (execution_state/outcome не пусты) либо ambiguous/verification_pending.
            // В нейтральном ожидании доступности (outcome=NULL, execution_state=NULL)
            // update_classes.php ещё не запускался — проверять нечего (write=0).
            if (!self::updateClassesExecutionAttempted($job)) return ['allowed' => false, 'reason' => 'awaiting_execution'];
            return ['allowed' => true, 'reason' => 'uc_stage'];
        }
        // legacy-джоба дальше по pipeline с нерешённым результатом.
        $arts = !empty($job['artifacts_json']) ? (json_decode((string)$job['artifacts_json'], true) ?: []) : [];
        $outcome = (string)($arts['update_classes_stage']['outcome'] ?? '');
        if (in_array($outcome, ['call_failed','wrong_root','wrong_site','not_applied','ambiguous','verification_error','applied_verification_pending'], true)) {
            return ['allowed' => true, 'reason' => 'legacy_unresolved'];
        }
        if (in_array($exec, ['started','ambiguous','completed'], true)) return ['allowed' => true, 'reason' => 'legacy_exec'];
        return ['allowed' => false, 'reason' => 'no_unresolved_result'];
    }

    /**
     * §gate-fix: единый предикат «была реальная попытка исполнения update_classes».
     * Нейтральное ожидание доступности = execution_state ПУСТ И outcome ПУСТ.
     * Generic stage_status='ok' сюда НЕ относится и пропуском не считается.
     */
    public static function updateClassesExecutionAttempted(array $job): bool
    {
        $exec = trim((string)($job['uc_execution_state'] ?? ''));
        if ($exec !== '' && $exec !== 'not_started') return true;
        $arts = [];
        if (!empty($job['artifacts_json'])) {
            $d = json_decode((string)$job['artifacts_json'], true);
            if (is_array($d)) $arts = $d;
        }
        $outcome = trim((string)($arts['update_classes_stage']['outcome'] ?? ''));
        return $outcome !== '';
    }

    /**
     * §gate-fix: активно ли состояние ручного вмешательства по рандомизации.
     * true → показывать recovery-блок (Verify/Skip). false → нейтральное ожидание/скрыто.
     */
    public static function updateClassesInterventionActive(array $job): bool
    {
        if (self::updateClassesGateSatisfied($job)) return false;
        if (in_array((string)($job['stage'] ?? ''), ['done','failed','cancelled','superseded'], true)) return false;
        $status = (string)($job['stage_status'] ?? '');
        return self::updateClassesExecutionAttempted($job) || $status === 'awaiting_user';
    }

    /** PATCH_3 (§12) + §gate-fix: skip доступен ТОЛЬКО в состоянии вмешательства. */
    public static function manualSkipPolicy(array $job): array
    {
        if (self::updateClassesGateSatisfied($job)) return ['allowed' => false, 'reason' => 'gate_satisfied'];
        $stage = (string)($job['stage'] ?? '');
        if (in_array($stage, ['done','failed','cancelled','superseded'], true)) return ['allowed' => false, 'reason' => 'terminal'];
        $status = (string)($job['stage_status'] ?? '');
        $attempted = self::updateClassesExecutionAttempted($job);
        // Нейтральное ожидание доступности (outcome=NULL, execution_state=NULL и НЕ
        // awaiting_user) — skip НЕ предлагаем: рандом ещё даже не пытались применить.
        if ($stage === 'update_classes_call' && ($attempted || $status === 'awaiting_user')) {
            return ['allowed' => true, 'reason' => 'intervention'];
        }
        return ['allowed' => false, 'reason' => 'neutral_or_not_reached'];
    }

    /**
     * PATCH_3 (§17): gate — уникализация пройдена по факту, не по позиции стадии.
     */
    public static function updateClassesGateSatisfied(array $job): bool
    {
        if (!empty($job['php_uniquification_verified_at'])) return true;
        $arts = [];
        if (!empty($job['artifacts_json'])) {
            $d = json_decode((string)$job['artifacts_json'], true);
            if (is_array($d)) $arts = $d;
        }
        $uc = $arts['update_classes_stage'] ?? [];
        if ((string)($uc['outcome'] ?? '') === 'not_applicable') return true;
        if (!empty($uc['skipped_by_operator'])) return true;
        return false;
    }


    /**
     * v18.1.34: Helper — попытаться вытащить «чужой» домен из HTML body.
     * Используется только для лога — какой сайт VPS отдал нам по ошибке.
     */
    private function extractForeignDomainFromBody(string $body, string $newDomain): string
    {
        // Ищем хосты в href/src/canonical
        if (preg_match_all('~(?:href|src|content)=["\']https?://([a-z0-9.-]+\.[a-z]{2,})~i', $body, $m)) {
            foreach ($m[1] as $h) {
                $hLow = mb_strtolower($h);
                // Пропускаем CDN/чужие сервисы
                if (strpos($hLow, 'yandex') !== false) continue;
                if (strpos($hLow, 'google') !== false) continue;
                if (strpos($hLow, 'gstatic') !== false) continue;
                if (strpos($hLow, 'cloudflare') !== false) continue;
                if (strpos($hLow, 'jquery') !== false) continue;
                if (strpos($hLow, 'bootstrap') !== false) continue;
                // Пропускаем наш newDomain (если вдруг)
                if (strpos($hLow, mb_strtolower($newDomain)) !== false) continue;
                // Это первый «чужой» домен
                return $h;
            }
        }
        return '';
    }

    /**
     * GET-запрос на URL, возвращает ['ok' => bool, 'http_code' => int, 'message' => string, 'body' => string].
     *
     * v18.1.18: при DNS-ошибке (Could not resolve host) повторяет с --resolve fallback на VPS IP.
     * Это критично сразу после покупки нового домена когда NS-записи ещё пропагируются.
     */
    protected function callUpdateClassesUrl(
        string $url,
        JobEventLogger $log,
        ?string $domainForResolve = null,
        ?string $vpsIp = null
    ): array {
        $first = $this->doUpdateClassesCurl($url);
        if ($first['ok']) {
            return $first;
        }

        // Не-DNS ошибка — fallback не поможет
        $isDnsError = isset($first['curl_error'])
            && stripos($first['curl_error'], 'could not resolve host') !== false;

        if (!$isDnsError || $vpsIp === null || $domainForResolve === null) {
            return $first;
        }

        $log->info('update_classes_call',
            "DNS для {$domainForResolve} ещё не пропагирован у нас. Повторяю через --resolve {$vpsIp}");

        $second = $this->doUpdateClassesCurl($url, $domainForResolve, $vpsIp);
        if ($second['ok']) {
            $second['message'] .= " (через --resolve, DNS пропагируется)";
            $second['used_resolve'] = true;
        }
        return $second;
    }

    /** Один curl-вызов с опциональным --resolve. */
    private function doUpdateClassesCurl(
        string $url,
        ?string $resolveDomain = null,
        ?string $resolveIp = null
    ): array {
        $ch = curl_init();
        $opts = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,  // self-signed может быть на старте
            CURLOPT_SSL_VERIFYHOST => 0,
            // v18.1.10: UA содержит "yandex" чтобы 1win-стиль шаблоны (с handleRequest гард-функцией)
            // распознали нас как бота и пропустили в нормальный flow. Иначе update_classes_call
            // попадает на index.php → handleRequest → isDirectAccess → exit(500) и стадия думает
            // что скрипта не существует.
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) refresh-panel-update-classes',
        ];

        if ($resolveDomain !== null && $resolveIp !== null) {
            $opts[CURLOPT_RESOLVE] = [
                "{$resolveDomain}:443:{$resolveIp}",
                "{$resolveDomain}:80:{$resolveIp}",
            ];
        }

        curl_setopt_array($ch, $opts);
        $body = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($body === false) {
            return [
                'ok' => false,
                'http_code' => 0,
                'message' => 'curl error: ' . $err,
                'curl_error' => $err,
                'body' => '',
            ];
        }

        $ok = $httpCode >= 200 && $httpCode < 400;
        return [
            'ok' => $ok,
            'http_code' => $httpCode,
            'message' => $ok ? "HTTP {$httpCode}" : "HTTP {$httpCode} (non-success)",
            'body' => is_string($body) ? $body : '',
        ];
    }

    // ============================================================
    // === v17 Yandex.Webmaster handlers ===
    // ============================================================

    /**
     * Стадия wm_account_resolve.
     *
     * Определяет к какому аккаунту Webmaster принадлежит старый домен.
     * Если в форме создания джобы был задан webmaster_account_override_id —
     * используется он. Иначе — автодетект через API всех аккаунтов с кешем.
     */
    /* ==================== P0: trusted SSL gate перед Webmaster ==================== */

    /** Test-only injectable TLS-probe для trusted_ssl_gate (production: null → live). */
    protected $trustedSslProbe = null;
    public function setTrustedSslProbe(?callable $f): void { $this->trustedSslProbe = $f; }

    public const SSL_PIPELINE_REVISION = 'ssl_before_webmaster_v1';
    /** Интервал повторного poll gate, сек. */
    private const TRUSTED_SSL_POLL_SEC = 30;
    /** Однократное предупреждение о долгом ожидании, сек (30 мин). */
    private const TRUSTED_SSL_LONG_SEC = 1800;
    /** Общий timeout выпуска SSL: gate → awaiting_user, Yandex = 0 вызовов (6 ч). */
    private const TRUSTED_SSL_TIMEOUT_SEC = 21600;

    /**
     * §4.3: ленивый перевод существующей джобы на новую revision. Только если:
     * required ещё не установлен, стадия СТРОГО до wm_account_resolve по STAGES_ORDER,
     * и в артефактах нет следов Webmaster-контура. Джобы в wm_* и далее — legacy.
     */
    private function maybeAdoptSslRevision(array $job, JobEventLogger $log): array
    {
        if ((int)($job['trusted_ssl_gate_required'] ?? 0) === 1) return $job;
        if (!empty($job['pipeline_revision'])) return $job;
        $stage = (string)($job['stage'] ?? '');
        $idx = array_search($stage, self::STAGES_ORDER, true);
        $wmIdx = array_search('wm_account_resolve', self::STAGES_ORDER, true);
        if ($idx === false || $wmIdx === false || $idx >= $wmIdx) return $job;
        $artifacts = $this->loadArtifacts($job);
        foreach (array_keys($artifacts) as $k) {
            if (strpos((string)$k, 'wm_') === 0) return $job; // уже есть Webmaster-артефакты — legacy
        }
        try {
            $st = DB::pdo()->prepare(
                "UPDATE refresh_jobs SET pipeline_revision=?, trusted_ssl_gate_required=1
                  WHERE id=? AND trusted_ssl_gate_required=0 AND pipeline_revision IS NULL"
            );
            $st->execute([self::SSL_PIPELINE_REVISION, (int)$job['id']]);
            if ($st->rowCount() === 1) {
                $log->info($stage, 'Джоба переведена на pipeline_revision=' . self::SSL_PIPELINE_REVISION
                    . ': перед Webmaster будет обязательный публичный trusted-SSL gate.');
                $job['pipeline_revision'] = self::SSL_PIPELINE_REVISION;
                $job['trusted_ssl_gate_required'] = 1;
            }
        } catch (\Throwable $e) { /* не критично: guard добьёт при входе в wm_* */ }
        return $job;
    }

    /**
     * §4.5: единый fail-closed guard в начале КАЖДОГО wm_*-handler. Для джобы новой
     * revision без атомарно сохранённого успешного gate: Yandex API не вызывается,
     * джоба возвращается в trusted_ssl_gate (или awaiting_user при повреждённом
     * состоянии). Возвращает true, если Webmaster разрешён.
     */
    private function wmSslGateGuard(array $job, JobEventLogger $log, string $wmStage): bool
    {
        if ((int)($job['trusted_ssl_gate_required'] ?? 0) !== 1) return true; // legacy-путь
        $artifacts = $this->loadArtifacts($job);
        $gateOk = !empty($artifacts['trusted_ssl_gate']['ok']);
        $completedAt = $job['trusted_ssl_gate_completed_at'] ?? null;
        if ($gateOk && !empty($completedAt)) return true;

        $jobId = (int)$job['id'];
        // Повреждённое/половинчатое состояние: артефакт ok есть, а completed_at нет
        // (или наоборот) — атомарность §4.4 нарушена внешним вмешательством.
        $corrupted = ($gateOk xor !empty($completedAt));

        // Событие пишем один раз на стадию (без спама при повторных cron-тиках).
        $flag = (string)($artifacts['trusted_ssl_gate_guard']['bounced_from'] ?? '');
        if ($flag !== $wmStage) {
            $log->warn($wmStage, $corrupted
                ? 'Guard: состояние trusted-SSL gate повреждено (артефакт и completed_at рассинхронизированы). Yandex API не вызывается, джоба переведена в awaiting_user.'
                : 'Guard: попытка входа в Webmaster без подтверждённого публичного trusted SSL. Yandex API не вызывается, джоба возвращена на trusted_ssl_gate.');
            $this->saveArtifacts($jobId, ['trusted_ssl_gate_guard' => ['bounced_from' => $wmStage, 'at' => gmdate('Y-m-d H:i:s')]], $log, $wmStage);
        }

        if ($corrupted) {
            $this->setStatusAwaitingUser($jobId, 'trusted_ssl_gate state corrupted');
            return false;
        }
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage='trusted_ssl_gate', stage_status='pending', stage_error=NULL, next_run_at=NOW() WHERE id=?"
            )->execute([$jobId]);
        } catch (\Throwable $e) {
            $this->setStatusAwaitingUser($jobId, 'trusted_ssl_gate guard redirect failed');
        }
        return false;
    }

    /**
     * P0 §4.2/§4.4/§4.7: стадия trusted_ssl_gate. Реальная публичная TLS-проверка;
     * успех фиксируется ОДНОЙ строгой транзакцией (артефакт + completed_at + ok,
     * rowCount=1, иначе ROLLBACK и gate не закрыт); ожидание — pending+poll без
     * спама в логи; timeout → awaiting_user; Yandex API здесь не вызывается вовсе.
     */
    private function runTrustedSslGateStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));
        if ($newDomain === '') {
            $log->error('trusted_ssl_gate', 'new_domain пуст — публичная SSL-проверка невозможна. Перевожу в awaiting_user.');
            $this->setStatusAwaitingUser($jobId, 'trusted_ssl_gate: new_domain пуст');
            return;
        }

        $gate = new TrustedSslGate($this->trustedSslProbe);
        $result = $gate->verify($newDomain);

        if (!empty($result['ok'])) {
            // §4.4: атомарное завершение. Никакого saveArtifacts-с-подавлением + setStatus.
            $pdo = DB::pdo();
            try {
                $pdo->beginTransaction();
                $st = $pdo->prepare(
                    "UPDATE refresh_jobs SET
                        artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json,'{}'), ?),
                        trusted_ssl_gate_completed_at = NOW(),
                        stage_status = 'ok',
                        stage_finished_at = NOW(),
                        stage_error = NULL
                      WHERE id = ? AND stage = 'trusted_ssl_gate' AND stage_status = 'running'"
                );
                $st->execute([
                    json_encode(['trusted_ssl_gate' => $result, 'trusted_ssl_gate_wait' => null],
                        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $jobId,
                ]);
                if ($st->rowCount() !== 1) {
                    $pdo->rollBack();
                    $log->error('trusted_ssl_gate',
                        'Атомарная фиксация gate не подтверждена (rowCount!=1: стадия/статус изменились конкурентно). Gate НЕ закрыт, Yandex не вызывается; повтор на следующем тике.');
                    $this->schedulePendingPoll($jobId, self::TRUSTED_SSL_POLL_SEC, $log);
                    return;
                }
                $pdo->commit();
            } catch (\Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $log->error('trusted_ssl_gate', 'Ошибка сохранения gate: ' . $e->getMessage()
                    . '. Gate НЕ закрыт, Yandex не вызывается; повтор на следующем тике.');
                $this->schedulePendingPoll($jobId, self::TRUSTED_SSL_POLL_SEC, $log);
                return;
            }
            $log->ok('trusted_ssl_gate',
                'Действующий сертификат подтверждён. Панель переходит к добавлению сайта в Webmaster.',
                ['event_code' => 'ssl.gate_confirmed',
                 'technical_reason' => 'issuer=' . (string)($result['issuer'] ?? '?') . ' domain=' . $newDomain]);
            // §3.2/§4: канонический код подтверждения доверенного сертификата live-проверкой.
            $log->ok('trusted_ssl_gate',
                'Доверенный сертификат подтверждён live-проверкой.',
                ['event_code' => 'ssl.trusted', 'source' => 'external_service',
                 'issuer' => (string)($result['issuer'] ?? '')]);
            return;
        }

        if (!empty($result['fatal'])) {
            $log->error('trusted_ssl_gate', 'Fatal при публичной SSL-проверке: '
                . (string)($result['reason'] ?? 'unknown') . '. Перевожу в awaiting_user (Yandex = 0 вызовов).');
            $this->setStatusAwaitingUser($jobId, 'trusted_ssl_gate fatal: ' . (string)($result['reason'] ?? 'unknown'));
            return;
        }

        // Ожидание доверенного публичного сертификата.
        $reason = (string)($result['reason'] ?? 'not_trusted_yet');
        $artifacts = $this->loadArtifacts($job);
        $wait = is_array($artifacts['trusted_ssl_gate_wait'] ?? null) ? $artifacts['trusted_ssl_gate_wait'] : [];
        $now = time();
        $enteredAt = (int)($wait['entered_at_unix'] ?? 0);
        $patch = [];
        if ($enteredAt === 0) {
            $enteredAt = $now;
            $patch = ['entered_at_unix' => $now, 'last_logged_reason' => $reason, 'long_notified' => false];
            $log->info('trusted_ssl_gate',
                'Проверяем действующий сертификат на публичном сайте. До успешной проверки сайт не будет добавлен в Webmaster.',
                ['event_code' => 'ssl.gate_checking',
                 'technical_reason' => $reason . ' domain=' . $newDomain]);
        } elseif ((string)($wait['last_logged_reason'] ?? '') !== $reason) {
            $patch = ['last_logged_reason' => $reason];
            $log->info('trusted_ssl_gate', 'Причина ожидания SSL изменилась: ' . $reason . '.');
        }
        $elapsed = max(0, $now - $enteredAt);
        if ($elapsed >= self::TRUSTED_SSL_TIMEOUT_SEC) {
            $log->error('trusted_ssl_gate', 'Timeout ожидания публичного доверенного SSL ('
                . intdiv($elapsed, 3600) . ' ч, причина: ' . $reason
                . '). Перевожу в awaiting_user. Yandex Webmaster не вызывался.');
            if ($patch) $this->saveArtifacts($jobId, ['trusted_ssl_gate_wait' => array_merge($wait, $patch)], $log, 'trusted_ssl_gate');
            $this->setStatusAwaitingUser($jobId, 'trusted_ssl_gate timeout: ' . $reason);
            return;
        }
        if ($elapsed >= self::TRUSTED_SSL_LONG_SEC && empty($wait['long_notified'])) {
            $patch['long_notified'] = true;
            $log->warn('trusted_ssl_gate', 'Длительное ожидание публичного доверенного SSL ('
                . intdiv($elapsed, 60) . ' мин) для ' . $newDomain . '. Проверьте выпуск сертификата.',
                ['event_code' => 'ssl.wait_long', 'source' => 'external_service', 'elapsed_sec' => $elapsed]);
        } elseif (empty($wait['pending_notified'])) {
            // §3.2/§4: штатное ожидание SSL — info, best-effort, pipeline не блокируется.
            $patch['pending_notified'] = true;
            $log->info('trusted_ssl_gate', 'Штатное ожидание выпуска доверенного SSL для ' . $newDomain . '.',
                ['event_code' => 'ssl.pending', 'source' => 'external_service']);
        }
        if ($patch) $this->saveArtifacts($jobId, ['trusted_ssl_gate_wait' => array_merge($wait, $patch)], $log, 'trusted_ssl_gate');
        $this->schedulePendingPoll($jobId, self::TRUSTED_SSL_POLL_SEC, $log);
    }

    /** pending + next_run_at (повторяющиеся сообщения в refresh_job_events НЕ пишутся). */
    private function schedulePendingPoll(int $jobId, int $sec, JobEventLogger $log): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='pending', stage_error=NULL,
                        next_run_at=DATE_ADD(NOW(), INTERVAL ? SECOND)
                  WHERE id=? AND stage='trusted_ssl_gate'"
            )->execute([$sec, $jobId]);
        } catch (\Throwable $e) {
            $log->warn('trusted_ssl_gate', 'Не смог поставить next_run_at: ' . $e->getMessage());
        }
    }

    /* ================== /P0: trusted SSL gate перед Webmaster ==================== */

    private function runWmAccountResolveStage(array $job, JobEventLogger $log): void
    {
        // P0 §4.5: fail-closed — без атомарно подтверждённого trusted-SSL gate
        // Yandex API для новой revision не вызывается.
        if (!$this->wmSslGateGuard($job, $log, 'wm_account_resolve')) return;
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $oldDomain = (string)$job['old_domain'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        $mapping = $this->makeSiteWebmasterMappingService();
        if (method_exists($mapping, 'setJobContext')) $mapping->setJobContext($jobId, 'wm_account_resolve', $log);

        // 1. Если есть override → используем его (создаём link для нового домена сразу)
        $overrideId = $job['webmaster_account_override_id'] ?? null;
        $overrideId = $overrideId !== null ? (int)$overrideId : 0;

        // 2. Резолвим аккаунт где живёт СТАРЫЙ домен (кеш или API, или v17.4 cascade)
        // v17.4: передаём newDomain чтобы cascade его исключил из кандидатов
        // revision 2 §9/§10: critical routing failure из поиска по аккаунтам → критический стоп
        // (а не ложное «домен не найден»).
        try {
            $oldLink = $mapping->resolveAccountForDomain($siteId, $oldDomain, $log, $newDomain);
        } catch (\Throwable $e) {
            if ($this->stopIfWmRoutingFatal($e, $jobId, $log, 0, 'wm_account_resolve')) return;
            throw $e;
        }

        if ($oldLink === null && $overrideId === 0) {
            $log->error('wm_account_resolve',
                "Домен {$oldDomain} не найден ни в одном аккаунте Webmaster (даже cascade), " .
                "и override не задан. Невозможно продолжить автоматически.");
            $log->info('wm_account_resolve',
                "💡 Что делать оператору: выбери Webmaster аккаунт в форме «Указать Webmaster аккаунт (override)» " .
                "ниже на этой странице → нажми «Применить override и продолжить». " .
                "Pipeline продолжится — новый домен будет добавлен в выбранный аккаунт. " .
                "Старый домен НЕ будет удалён из Webmaster (т.к. он там не зарегистрирован) — это нормально.");
            $log->info('wm_account_resolve',
                "Альтернатива: добавь {$oldDomain} в один из существующих аккаунтов через webmaster.yandex.ru " .
                "и нажми «🔁 Повторить verify» — система найдёт его автоматически.");
            $this->setStatusAwaitingUser($jobId,
                "wm_account_resolve: ни старый домен ({$oldDomain}), ни его aliases не найдены ни в одном " .
                "из доступных Webmaster аккаунтов. Выбери override-аккаунт через UI (форма ниже на странице джобы).");
            return;
        }

        // 3. Решаем куда ДОБАВЛЯТЬ новый домен
        $targetAccountId = 0;
        $sourceAccountId = $oldLink['webmaster_account_id'] ?? 0;

        // v17.4: matched_domain — это РЕАЛЬНО найденный домен (может отличаться от $oldDomain
        // если сработал cascade). Именно его удалим в wm_old_removed.
        $matchedDomain = (string)($oldLink['matched_domain'] ?? $oldDomain);
        $resolveSource = (string)($oldLink['source'] ?? 'override');

        if ($overrideId > 0) {
            $targetAccountId = $overrideId;
            $log->info('wm_account_resolve',
                "Override активен: новый домен будет добавлен в аккаунт #{$overrideId}");
        } else {
            $targetAccountId = $sourceAccountId;
            $log->info('wm_account_resolve',
                "Новый домен будет добавлен в тот же аккаунт где найден старый: #{$targetAccountId}");
        }

        // 4. Создаём preview link для нового домена (пока без user_id/host_id)
        $mapping->upsertLink([
            'site_id' => $siteId,
            'domain' => $newDomain,
            'webmaster_account_id' => $targetAccountId,
            'user_id' => '',
            'host_id' => '',
            'verified' => 0,
        ]);

        // 5. Сохраняем результат в artifacts
        $patch = ['wm_account_resolve_stage' => [
            'ok' => true,
            'old_domain' => $oldDomain,
            'matched_domain' => $matchedDomain,            // v17.4: что реально нашлось
            'cascade_used' => $resolveSource === 'cascade', // v17.4
            'old_account_id' => (int)$sourceAccountId,
            'old_user_id' => (string)($oldLink['user_id'] ?? ''),
            'old_host_id' => (string)($oldLink['host_id'] ?? ''),
            'new_domain' => $newDomain,
            'new_account_id' => $targetAccountId,
            'override_used' => $overrideId > 0,
            'source' => $resolveSource,
        ]];
        $this->saveArtifacts($jobId, $patch, $log, 'wm_account_resolve');

        if ($matchedDomain !== $oldDomain) {
            $log->ok('wm_account_resolve',
                "✓ Cascade resolve OK: запрашивали '{$oldDomain}', нашли '{$matchedDomain}' " .
                "в аккаунте #{$sourceAccountId}. Новый '{$newDomain}' → аккаунт #{$targetAccountId}.");
        } else {
            $log->ok('wm_account_resolve',
                "✓ Resolve OK: старый '{$oldDomain}' → аккаунт #{$sourceAccountId}, " .
                "новый '{$newDomain}' → аккаунт #{$targetAccountId}");
        }

        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    /**
     * Стадия wm_added.
     *
     * Добавляет новый домен в выбранный аккаунт Webmaster.
     * URL: https://newdomain.casino:443
     */
    private function runWmAddedStage(array $job, JobEventLogger $log): void
    {
        // P0 §4.5: fail-closed — без атомарно подтверждённого trusted-SSL gate
        // Yandex API для новой revision не вызывается.
        if (!$this->wmSslGateGuard($job, $log, 'wm_added')) return;
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        // v25.0-b: gate к Вебмастеру — PHP-уникализация должна быть подтверждена
        // (verified) ЛИБО явно неприменима (not_applicable). Если поле пустое и
        // уникализация применима — не идём в Вебмастер (иначе добавим в индекс
        // сайт со старыми классами).
        if (AppSettings::getBool('wm.require_uniquification_gate', true)) {
            $arts0 = $this->loadArtifacts($job);
            $ucOutcome = (string)($arts0['update_classes_stage']['outcome'] ?? '');
            $applicable = $arts0['update_classes_stage']['uniquification_applicable'] ?? null;
            // v25.2-a1.6.4.1 (§9): единый предикат — verified_at | not_applicable |
            // skipped_by_operator. Позиция стадии в STAGES_ORDER НЕ является
            // основанием пройти gate.
            $gateOk = self::updateClassesGateSatisfied($job) || $applicable === false;
            if (!$gateOk) {
                $log->warn('wm_added',
                    'PHP-уникализация ещё не подтверждена (php_uniquification_verified_at пуст, '
                    . "outcome='{$ucOutcome}'). Вебмастер не стартует. Нужна FTP-проверка рандома "
                    . '(«Проверить уже выполненный рандом») или явный пропуск.');
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET
                        stage_status = 'awaiting_user',
                        stage_error = 'wm_added: рандомизация классов не подтверждена (нужна FTP-проверка)',
                        next_run_at = NULL
                     WHERE id = ?
                       AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([$jobId]);
                return;
            }
        }

        $artifacts = $this->loadArtifacts($job);
        $resolveStage = $artifacts['wm_account_resolve_stage'] ?? null;
        if ($resolveStage === null) {
            $log->error('wm_added', 'Не было wm_account_resolve_stage — что-то сломалось');
            $this->setStatusFailed($jobId, 'wm_added: no account_resolve in artifacts');
            return;
        }

        $accountId = (int)($resolveStage['new_account_id'] ?? 0);
        if ($accountId <= 0) {
            $log->error('wm_added', 'new_account_id пуст в артефактах');
            $this->setStatusFailed($jobId, 'wm_added: new_account_id empty');
            return;
        }

        // v25.0-b: host_id polling — Яндекс регистрирует host АСИНХРОННО.
        // check existing → addHost один раз → перечитывать список → нашли →
        // сохранить → готово; timeout → awaiting_user (без повторного addHost).
        $fresh = $this->reloadJob($jobId) ?? $job;
        if (JobLifecycleService::isTerminal((string)$fresh['stage'])) return;

        $poll = $this->makeWmHostPollingService();
        // revision 2 §8: critical routing failure из вложенного tick() → единая pipeline policy.
        try {
            $res = $poll->tick($fresh, $accountId, $newDomain, $log);
        } catch (\Throwable $e) {
            if ($this->stopIfWmRoutingFatal($e, $jobId, $log, $accountId, 'wm_added')) return;
            throw $e;
        }

        switch ($res['result']) {
            case 'ready':
                // finish() уже выставил wm_added_stage.ok + status ok. Готово.
                return;
            case 'waiting':
            case 'awaiting_user':
            case 'terminal':
            default:
                // Состояние уже выставлено сервисом (pending+next_run_at /
                // awaiting_user / ничего для terminal). Выходим.
                return;
        }
    }

    /**
     * Стадия wm_verified.
     *
     * Получает HTML_FILE verifier от Yandex, загружает файл через FTP,
     * запускает верификацию и проверяет результат.
     */
    private function runWmVerifiedStage(array $job, JobEventLogger $log): void
    {
        // P0 §4.5: fail-closed — без атомарно подтверждённого trusted-SSL gate
        // Yandex API для новой revision не вызывается.
        if (!$this->wmSslGateGuard($job, $log, 'wm_verified')) return;
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        $artifacts = $this->loadArtifacts($job);
        $addedStage = $artifacts['wm_added_stage'] ?? null;
        if ($addedStage === null) {
            $log->error('wm_verified', 'Не было wm_added_stage');
            $this->setStatusFailed($jobId, 'wm_verified: no wm_added in artifacts');
            return;
        }

        $accountId = (int)$addedStage['account_id'];
        $userId = (string)$addedStage['user_id'];
        $hostId = (string)$addedStage['host_id'];

        // v18.1.33: если уже была начата верификация (файл залит, POST отправлен) —
        // переходим в polling-режим вместо повторной заливки. Это нужно потому что
        // верификация Webmaster длится от секунд до минут, и каждый tick должен
        // просто проверять текущий status, а не заново всё запускать.
        $verifiedStage = $artifacts['wm_verified_stage'] ?? null;
        $alreadyTriggered = $verifiedStage !== null
            && !empty($verifiedStage['triggered_at'])
            && !empty($verifiedStage['file_url']);

        // v25.1-a1 (Блокер 3): фиксируем начало отсчёта ДО первого API-вызова,
        // чтобы warning/long_pending считались и при сбоях подготовительной фазы.
        if (empty(($artifacts['wm_verified_stage'] ?? [])['poll_started_at_unix'])) {
            $st0 = $artifacts['wm_verified_stage'] ?? [];
            $st0['poll_started_at_unix'] = $st0['poll_started_at_unix'] ?? time();
            $this->saveArtifacts($jobId, ['wm_verified_stage' => $st0], $log, 'wm_verified');
            $job = $this->reloadJob($jobId) ?? $job;
            $artifacts = $this->loadArtifacts($job);
        }

        // v25.2-a1 (§Блокер 5): для СТАРЫХ джоб, впервые попавших на новый
        // подэтапный движок, засекаем fast_pipeline_started_at_unix=NOW(), чтобы
        // adaptive-retry начинался с 15с, а не с большого backoff от старого
        // часового poll_started_at_unix. Отсчёт быстрого retry ведём от него.
        if (empty(($artifacts['wm_verified_stage'] ?? [])['fast_pipeline_started_at_unix'])) {
            $st1 = $artifacts['wm_verified_stage'] ?? [];
            $st1['fast_pipeline_started_at_unix'] = time();
            $this->saveArtifacts($jobId, ['wm_verified_stage' => $st1], $log, 'wm_verified');
            $job = $this->reloadJob($jobId) ?? $job;
            $artifacts = $this->loadArtifacts($job);
        }
        // Для быстрого retry используем fast_pipeline-отсчёт (новый движок).
        $pollStart0 = (int)(($artifacts['wm_verified_stage'] ?? [])['fast_pipeline_started_at_unix']
            ?? ($artifacts['wm_verified_stage'] ?? [])['poll_started_at_unix'] ?? time());

        // a1.6.1 (Блокер 1): проверяем оба gate ДО создания Yandex-клиента.
        // Verified/skip Webmaster не должны зависеть от живого OAuth-токена: если
        // токен истёк, но webmaster_gate уже закрыт, стадия обязана завершиться
        // (или ждать только SSL), а НЕ падать в awaiting_user из-за ненужного клиента.
        $vs = $artifacts['wm_verified_stage'] ?? [];
        if ($this->wmTryCompleteStage($jobId, $job, $vs, $log)) {
            return; // оба gate закрыты — стадия завершена
        }
        if ($this->webmasterGateClosed($vs)) {
            // Webmaster закрыт (verified/skip), ssl_gate ещё нет — ждём trusted SSL.
            // Yandex-клиент здесь не нужен и НЕ создаётся.
            // ТЗ 039 §20: это старая джоба (начата до нового порядка этапов). Права в
            // Webmaster уже подтверждены; ждём завершения выпуска сертификата и НЕ
            // выполняем повторное добавление сайта. event_code даёт человекочитаемый
            // текст в UI/Telegram через единый presenter.
            $log->info('wm_verified',
                'Это старая джоба, начатая до обновления порядка этапов. Права в Webmaster уже подтверждены; панель ждёт завершения выпуска сертификата и не выполняет повторное добавление сайта.',
                ['event_code' => 'ssl.legacy_wait',
                 'technical_reason' => 'awaiting_trusted_ssl_after_verification']);
            $this->scheduleWmVerifiedRetry($jobId, 0, $log, 'awaiting_trusted_ssl_after_verification');
            return;
        }

        try {
            // Webmaster ещё не закрыт → клиент действительно нужен.
            $client = $this->makeWmClient($accountId);
            $this->emitWmRouting($client, $log, (int)$accountId, (int)$jobId, 'wm_verified');

            if ($alreadyTriggered) {
                // === Polling: только GET checkVerification ===
                $this->pollWmVerified($job, $log, $client, $userId, $hostId,
                    (string)($verifiedStage['uin'] ?? ''),
                    (string)($verifiedStage['file'] ?? ''),
                    (string)($verifiedStage['file_url'] ?? ''));
                return;
            }

            // === v25.2-a: кешируемые подэтапы (§3,§5). Не повторяем уже
            // выполненную работу: verifier запрашивается один раз, FTP-заливка
            // один раз, public probe — быстрый, строгий gate — только перед POST.
            $this->runWmVerifiedSubphases($job, $log, $client, $userId, $hostId, $siteId, $newDomain, $pollStart0);
        } catch (\Throwable $e) {
            // v25.1-a1 (Блокер 3): классифицируем ошибку вместо слепого awaiting.
            if ($this->stopIfWmRoutingFatal($e, $jobId, $log, (int)($accountId ?? 0), 'wm_verified')) return;
            $class = $this->classifyWmError($e);
            $elapsed = max(0, time() - $pollStart0);
            if ($class === 'temporary') {
                $log->warn('wm_verified',
                    'Временная ошибка подготовки верификации (продолжаю автоматически): ' . $e->getMessage());
                $this->scheduleWmVerifiedRetry($jobId, $elapsed, $log, $e->getMessage());
                $this->maybeMarkLongPending($jobId, $elapsed, $log, 'prep_api_error');
            } elseif ($class === 'config_fatal') {
                $log->error('wm_verified', 'Ошибка конфигурации верификации: ' . $e->getMessage());
                $this->setStatusAwaitingUser($jobId,
                    'wm_verified: ошибка конфигурации — ' . mb_substr($e->getMessage(), 0, 200));
            } else { // auth_fatal
                $log->error('wm_verified', 'Неисправимая ошибка доступа: ' . $e->getMessage());
                $this->setStatusAwaitingUser($jobId,
                    'wm_verified: доступ/OAuth — ' . mb_substr($e->getMessage(), 0, 200));
            }
        }
    }

    /**
     * v25.2-a (§3,§5,§6,§12): подэтапный проход wm_verified с кешированием.
     * Полное durable-state в artifacts (wm_verified_stage), диагностические
     * зеркала — в колонках 030. §12: подробный лог только при СМЕНЕ подэтапа.
     */
    private function runWmVerifiedSubphases(array $job, JobEventLogger $log, $client,
        string $userId, string $hostId, int $siteId, string $newDomain, int $pollStart0): void
    {
        $jobId = (int)$job['id'];
        $artifacts = $this->loadArtifacts($job);
        $stage = is_array($artifacts['wm_verified_stage'] ?? null) ? $artifacts['wm_verified_stage'] : [];

        $pipeline = new WmVerifierPipeline($this->makeHttpProbe());
        $verFs = $this->makeFileVerifier();
        $prevSub = (string)($stage['subphase'] ?? '');

        // --- Подэтап 1: verifier_received (кеш §5.1) ---
        if (WmVerifierPipeline::needsFetchVerifier($stage, $hostId)) {
            $log->info('wm_verified', 'Получаю HTML_FILE verifier у Yandex...');
            $verifier = $client->getHtmlFileVerifier($userId, $hostId);
            $content = (string)$verifier['content'];
            $stage['uin'] = (string)$verifier['uin'];
            $stage['file'] = (string)$verifier['file'];
            $stage['content'] = $content;
            $stage['content_sha256'] = hash('sha256', $content);
            $stage['host_id'] = $hostId;
            // при новом verifier сбрасываем последующие подэтапы
            unset($stage['uploaded_at'], $stage['uploaded_filename'], $stage['uploaded_content_sha256'],
                  $stage['public_at'], $stage['public_method'], $stage['public_http_code'], $stage['public_final_url'],
                  $stage['strict_https_at']);
            $this->logWmSub($log, $prevSub, 'verifier_received', "✓ Verifier получен и сохранён (uin={$stage['uin']}, file={$stage['file']})");
        }
        $fileName = (string)$stage['file'];
        $content = (string)$stage['content'];
        $contentSha = (string)$stage['content_sha256'];

        // --- Подэтап 2: verifier_uploaded (кеш §5.2, FTP один раз) ---
        if (WmVerifierPipeline::needsUpload($stage, $fileName, $contentSha)) {
            $up = $verFs->uploadFileOnly($siteId, $fileName, $content, $log);
            if (empty($up['ok'])) {
                // FTP-ошибка: fatal (нет доступа) vs временная.
                $msg = (string)($up['message'] ?? '');
                if (mb_stripos($msg, 'ftp') !== false && (mb_stripos($msg, 'not found') !== false || mb_stripos($msg, 'реквизит') !== false || mb_stripos($msg, 'login') !== false || mb_stripos($msg, 'auth') !== false)) {
                    $log->error('wm_verified', 'FTP недоступен: ' . $msg);
                    $this->setStatusAwaitingUser($jobId, 'wm_verified: FTP — ' . mb_substr($msg, 0, 200));
                    return;
                }
                $log->warn('wm_verified', 'FTP-заливка не удалась (временная), повтор: ' . $msg);
                $this->persistWmSubphase($jobId, $stage, 'verifier_received');
                $this->scheduleWmVerifiedRetry($jobId, max(0, time() - $pollStart0), $log, 'ftp_upload_retry');
                return;
            }
            $stage['uploaded_at'] = date('Y-m-d H:i:s');
            $stage['uploaded_filename'] = $fileName;
            $stage['uploaded_content_sha256'] = $contentSha;
            $this->logWmSub($log, $prevSub, 'verifier_uploaded', "✓ Verifier загружен по FTP: {$fileName}");
        }

        // --- Подэтап 3: verifier_publicly_reachable (быстрый probe §5.3) ---
        if (empty($stage['public_at'])) {
            $vpsIp = $this->resolveVpsIpForJob($job, $log);
            $pub = $pipeline->publicProbe($newDomain, $fileName, $content, $vpsIp);
            if (!empty($pub['fatal'])) {
                // §8: редирект на чужой домен — fatal, нужен оператор.
                $log->error('wm_verified', 'Публичная проверка: чужой редирект — ' . $pub['reason']);
                $this->setStatusAwaitingUser($jobId, 'wm_verified: редирект на чужой домен (' . $pub['reason'] . ')');
                return;
            }
            if (empty($pub['ok'])) {
                // Ещё не видно публично (self-signed/DNS/5xx) — transient, ждём.
                // §Блокер 5: при УСТОЙЧИВОМ провале проверяем файл по FTP и при
                // отсутствии/несовпадении sha — один controlled re-upload.
                $failN = (int)($stage['public_fail_count'] ?? 0) + 1;
                $stage['public_fail_count'] = $failN;
                $lastFtpCheck = (int)($stage['last_ftp_probe_unix'] ?? 0);
                $ftpCheckDue = (time() - $lastFtpCheck) >= 60; // не чаще раза в минуту
                if ($failN >= 3 && $ftpCheckDue) {
                    $stage['last_ftp_probe_unix'] = time();
                    $remoteSha = $verFs->readRemoteSha($siteId, $fileName, $log);
                    // §Блокер 5: null здесь = файл ОТСУТСТВУЕТ (мы проверили факт) →
                    // перезаливаем; иначе сравниваем sha.
                    $fileMissingOrWrong = ($remoteSha === null) || ($remoteSha !== $contentSha);
                    if ($fileMissingOrWrong) {
                        $log->warn('wm_verified', 'FTP-recovery: файл отсутствует/повреждён (sha не совпал) — один controlled re-upload.');
                        unset($stage['uploaded_at'], $stage['uploaded_filename'], $stage['uploaded_content_sha256']);
                        $up = $verFs->uploadFileOnly($siteId, $fileName, $content, $log);
                        if (!empty($up['ok'])) {
                            $stage['uploaded_at'] = date('Y-m-d H:i:s');
                            $stage['uploaded_filename'] = $fileName;
                            $stage['uploaded_content_sha256'] = $contentSha;
                            $stage['ftp_recovery_count'] = (int)($stage['ftp_recovery_count'] ?? 0) + 1;
                            $stage['public_fail_count'] = 0; // дать шанс новому probe
                        }
                    } else {
                        $log->info('wm_verified', 'FTP-recovery: файл на месте (sha совпал), ждём публичную доступность (TLS/DNS).');
                    }
                }
                $this->persistWmSubphase($jobId, $stage, 'verifier_uploaded');
                // §12: подробность только при первом входе; далее короткий лог из scheduleWmVerifiedRetry.
                if ($prevSub !== 'verifier_uploaded' || empty($stage['public_probe_logged'])) {
                    $log->info('wm_verified', 'Ожидаем публичную доступность verifier (self-signed/DNS). ' . $pub['reason']);
                    $stage['public_probe_logged'] = true;
                    $this->persistWmSubphase($jobId, $stage, 'verifier_uploaded');
                }
                $this->scheduleWmVerifiedRetry($jobId, max(0, time() - $pollStart0), $log, 'awaiting_public');
                return;
            }
            $stage['public_at'] = date('Y-m-d H:i:s');
            $stage['public_method'] = $pub['method'];
            $stage['public_http_code'] = $pub['http_code'];
            $stage['public_final_url'] = $pub['final_url'];
            $stage['public_fail_count'] = 0;
            $this->logWmSub($log, $prevSub, 'verifier_publicly_reachable', "✓ Verifier доступен на правильном vhost (способ {$pub['method']})");
        }

        // --- Подэтап 4 (a1.6 §3): trusted HTTPS проверяется НЕЗАВИСИМО и НЕ
        // блокирует submit. Раньше здесь стоял return на self-signed — из-за него
        // Яндекс не начинал проверку, пока LE не выпустил trusted SSL. Теперь SSL —
        // отдельный gate (ssl_gate), а submit зависит только от public_at.
        if (empty($stage['strict_https_at'])) {
            $gate = $pipeline->strictHttpsGate($newDomain, $fileName, $content);
            if (!empty($gate['ok'])) {
                $stage['strict_https_at'] = date('Y-m-d H:i:s');
                $this->logWmSub($log, $prevSub, 'trusted_https_ready', '✓ Строгий HTTPS-gate пройден (доверенный TLS)');
                $this->persistWmSubphase($jobId, $stage, WmVerifierPipeline::nextSubphase($stage));
            } else {
                // НЕ return: SSL reconciler доведёт trusted позже; verification идёт параллельно.
                if ($prevSub === 'verifier_publicly_reachable') {
                    $log->info('wm_verified', 'Trusted SSL ещё не готов (' . $gate['reason'] . ') — Webmaster-верификация идёт параллельно, SSL продолжает выпускаться.');
                }
            }
        }

        // --- Подэтап 5: verification_submitted (POST один раз, под lock §13) ---
        // a1.6 §2: submit зависит ТОЛЬКО от public_at (verifier публично доступен),
        // НЕ от trusted SSL. Self-signed НЕ блокирует отправку.
        if (empty($stage['submitted_at'])) {
            $lock = 'rfp_wm_submit_' . $jobId;
            if (!$this->acquireDbLock($lock, 5)) {
                $log->info('wm_verified', 'Submit занят другим процессом, повтор.');
                $this->scheduleWmVerifiedRetry($jobId, max(0, time() - $pollStart0), $log, 'submit_lock_busy');
                return;
            }
            try {
                // повторно перечитаем состояние под локом (идемпотентность)
                $fresh = $this->loadArtifacts($this->reloadJob($jobId) ?? $job);
                $freshStage = is_array($fresh['wm_verified_stage'] ?? null) ? $fresh['wm_verified_stage'] : [];
                if (!empty($freshStage['submitted_at'])) {
                    $stage = $freshStage; // уже отправлено параллельным тиком
                } else {
                    // a1.6 §5: перед POST — checkVerification. Если Яндекс уже
                    // IN_PROGRESS/VERIFIED/SUCCESS (POST мог пройти, но ответ
                    // потерялся) — считаем submit состоявшимся, POST не повторяем.
                    $alreadyStarted = false; $preState = '';
                    try {
                        $pre = $client->checkVerification($userId, $hostId);
                        $preState = $this->normalizeVerificationState($pre);
                        if ($preState === 'verified' || $preState === 'success' || $this->isVerificationInProgress($preState)) {
                            $alreadyStarted = true;
                        }
                    } catch (\Throwable $e) { /* checkVerification недоступен — делаем обычный POST */ }

                    if ($alreadyStarted) {
                        $stage['submitted_at'] = date('Y-m-d H:i:s');
                        $stage['verification_poll_started_at'] = $stage['verification_poll_started_at'] ?? date('Y-m-d H:i:s');
                        $stage['triggered_at'] = $stage['triggered_at'] ?? date('Y-m-d H:i:s');
                        $stage['verification_state'] = $preState;
                        $stage['file_url'] = 'https://' . $newDomain . '/' . ltrim($fileName, '/');
                        $stage['poll_attempt'] = 0;
                        $stage['last_state'] = $preState;
                        $log->info('wm_verified', "Verification уже запущена в Яндекс (state={$preState}) — POST не повторяю, перехожу к polling.");
                        $this->persistWmSubphase($jobId, $stage, 'verification_submitted');
                        $this->handleVerificationState($job, $log, $preState, $client, $userId, $hostId,
                            (string)$stage['uin'], $fileName, (string)$stage['file_url']);
                        return;
                    }

                    $log->info('wm_verified', 'Запускаю POST verification/HTML_FILE...');
                    $verRes = $client->verifyHost($userId, $hostId, 'HTML_FILE');
                    $verState = $this->normalizeVerificationState($verRes);
                    $stage['submitted_at'] = date('Y-m-d H:i:s');
                    $stage['verification_poll_started_at'] = date('Y-m-d H:i:s'); // a1.6 §6: отдельный таймер Yandex
                    $stage['triggered_at'] = $stage['triggered_at'] ?? date('Y-m-d H:i:s');
                    $stage['verification_state'] = $verState;
                    $stage['file_url'] = 'https://' . $newDomain . '/' . ltrim($fileName, '/');
                    $stage['first_response'] = $verRes;
                    $stage['poll_attempt'] = 0;
                    $stage['last_state'] = $verState;
                    $this->logWmSub($log, $prevSub, 'verification_submitted', '✓ Verification отправлена в Яндекс (параллельно с выпуском SSL)');
                    $this->persistWmSubphase($jobId, $stage, 'verification_submitted');

                    // §6.2: продолжаем в том же тике — первый poll сразу.
                    $this->handleVerificationState($job, $log, $verState, $client, $userId, $hostId,
                        (string)$stage['uin'], $fileName, (string)$stage['file_url']);
                    return;
                }
            } finally {
                $this->releaseDbLock($lock);
            }
        }

        // Уже submitted (или стало submitted под локом) — обычный polling.
        $this->persistWmSubphase($jobId, $stage, WmVerifierPipeline::nextSubphase($stage));
        $this->pollWmVerified($job, $log, $client, $userId, $hostId,
            (string)($stage['uin'] ?? ''), (string)($stage['file'] ?? ''), (string)($stage['file_url'] ?? ''));
    }

    /** §13: advisory-lock для эксклюзивного submit verification (один POST). */
    private function acquireDbLock(string $name, int $timeoutSec = 5): bool
    {
        try {
            $st = DB::pdo()->prepare("SELECT GET_LOCK(?, ?)");
            $st->execute([$name, $timeoutSec]);
            return ((int)$st->fetchColumn() === 1);
        } catch (\Throwable $e) { return false; }
    }

    private function releaseDbLock(string $name): void
    {
        try { DB::pdo()->prepare("SELECT RELEASE_LOCK(?)")->execute([$name]); } catch (\Throwable $e) {}
    }

    /** §12: подробный лог только при смене подэтапа. */
    private function logWmSub(JobEventLogger $log, string $prevSub, string $newSub, string $msg): void
    {
        if ($prevSub !== $newSub) {
            $log->ok('wm_verified', $msg);
        }
    }

    /** Сохранить durable-state подэтапа: artifacts JSON + зеркала в колонки 030. */
    private function persistWmSubphase(int $jobId, array $stage, string $subphase): void
    {
        $stage['subphase'] = $subphase;
        $stage['poll_started_at_unix'] = $stage['poll_started_at_unix'] ?? time();
        try {
            $this->saveArtifacts($jobId, ['wm_verified_stage' => $stage], new JobEventLogger($jobId), 'wm_verified');
        } catch (\Throwable $e) { /* durable-state в JSON — приоритет; лог не критичен */ }
        // Диагностические зеркала (миграция 030) — best-effort, не влияют на логику.
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    wm_verifier_uploaded_at      = ?,
                    wm_verifier_public_at        = ?,
                    wm_verifier_strict_https_at  = ?,
                    wm_verification_submitted_at = ?,
                    wm_verification_last_state   = ?,
                    wm_verification_last_poll_at = COALESCE(?, wm_verification_last_poll_at)
                 WHERE id = ?"
            )->execute([
                $stage['uploaded_at'] ?? null,
                $stage['public_at'] ?? null,
                $stage['strict_https_at'] ?? null,
                $stage['submitted_at'] ?? null,
                isset($stage['last_state']) ? mb_substr((string)$stage['last_state'], 0, 32) : null,
                $stage['last_poll_at'] ?? null,
                $jobId,
            ]);
        } catch (\Throwable $e) { /* зеркала не критичны */ }
    }

    /**
     * v25.1-a1 (Блокер 4): различаем причину неуспеха uploadVerificationFile.
     * ftp_fatal → awaiting_user; временная публичная недоступность (self-signed/
     * DNS/HTTP 0/5xx/trusted SSL ещё выпускается) → pending + backoff;
     * file_mismatch (тело неверно) обрабатывается recovery в polling.
     */
    private function handleFileUploadFailure(int $jobId, array $upRes, int $pollStart0, JobEventLogger $log): void
    {
        $msg = mb_strtolower((string)($upRes['message'] ?? ''));
        $reason = (string)($upRes['reason'] ?? ''); // сервис может явно указать
        $elapsed = max(0, time() - $pollStart0);

        $isFtpFatal = ($reason === 'ftp_fatal')
            || (mb_strpos($msg, 'ftp') !== false && (mb_strpos($msg, 'реквизит') !== false
                || mb_strpos($msg, 'login') !== false || mb_strpos($msg, 'auth') !== false
                || mb_strpos($msg, 'password') !== false || mb_strpos($msg, 'denied') !== false
                || mb_strpos($msg, 'connect') !== false));

        if ($isFtpFatal) {
            $log->error('wm_verified', 'Upload файла верификации: неисправимая FTP-ошибка — ' . $upRes['message']);
            $this->setStatusAwaitingUser($jobId, 'wm_verified: FTP — ' . mb_substr((string)$upRes['message'], 0, 200));
            return;
        }

        // Иначе — временная публичная недоступность файла (self-signed, DNS,
        // HTTP 0/5xx, trusted SSL ещё выпускается). Файл на FTP залит; ждём,
        // пока станет публично доступен. Продолжаем автоматически.
        $log->warn('wm_verified',
            'Файл верификации залит, но публично ещё не подтверждён (временно): ' . $upRes['message']
            . '. Продолжаю автоматические проверки.');
        $this->scheduleWmVerifiedRetry($jobId, $elapsed, $log, 'file_public_pending');
        $this->maybeMarkLongPending($jobId, $elapsed, $log, 'file_public_pending');
    }

    /**
     * v18.1.33: Polling-цикл для wm_verified. Каждый tick — GET checkVerification,
     * проверка state, retry с adaptive backoff если ещё in_progress.
     */
    /** a1.6 §4: закрыт ли webmaster_gate — verified/confirmed ИЛИ Webmaster пропущен. */
    private function webmasterGateClosed(array $stage): bool
    {
        if (!empty($stage['skipped_by_operator'])) return true;
        if (in_array(($stage['verification_state'] ?? ''), ['verified', 'success'], true)) return true;
        if (!empty($stage['confirmed_at'])) return true;
        return false;
    }

    /** a1.6 §4: завершить стадию, если ЗАКРЫТЫ оба gate (webmaster + ssl). */
    private function wmTryCompleteStage(int $jobId, array $job, array $stage, JobEventLogger $log): bool
    {
        if ($this->webmasterGateClosed($stage) && $this->sslGateClosed($job, $stage)) {
            $this->saveArtifacts($jobId, ['wm_verified_stage' => [
                'ok' => true,
                'confirmed_at' => $stage['confirmed_at'] ?? ($this->webmasterGateClosed($stage) && empty($stage['skipped_by_operator']) ? date('Y-m-d H:i:s') : ($stage['confirmed_at'] ?? null)),
            ]], $log, 'wm_verified');
            $log->ok('wm_verified', '✓ Оба gate закрыты (webmaster + ssl) — стадия wm_verified завершена.');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return true;
        }
        return false;
    }

    /**
     * a1.6 §4: закрыт ли ssl_gate — trusted HTTPS готов ИЛИ SSL пропущен оператором.
     */
    private function sslGateClosed(array $job, array $stage): bool
    {
        $artifacts = $this->loadArtifacts($job);
        // P0: для новой revision публичный trusted SSL уже подтверждён стадией
        // trusted_ssl_gate ДО Webmaster → второй gate закрыт по определению;
        // awaiting_trusted_ssl_after_verification для таких джоб недостижимо.
        if (!empty($artifacts['trusted_ssl_gate']['ok'])) return true;
        if (!empty($artifacts['ssl_le_stage']['skipped_by_operator'])) return true;
        if (!empty($stage['strict_https_at'])) return true;
        $newDomain = trim((string)($job['new_domain'] ?? ''));
        if ($newDomain === '') return false;
        try {
            $st = DB::pdo()->prepare("SELECT status FROM domain_ssl_statuses WHERE domain = ? COLLATE utf8mb4_unicode_ci LIMIT 1");
            $st->execute([$newDomain]);
            if ((string)$st->fetchColumn() === 'trusted') return true;
        } catch (\Throwable $e) { /* игнор */ }
        try {
            $pipeline = new WmVerifierPipeline($this->makeHttpProbe());
            $gate = $pipeline->strictHttpsGate($newDomain, (string)($stage['file'] ?? ''), (string)($stage['content'] ?? ''));
            return !empty($gate['ok']);
        } catch (\Throwable $e) { return false; }
    }

    /**
     * a1.6 §6: время ожидания Яндекса — ТОЛЬКО от verification_poll_started_at
     * (или submitted_at), а не от общего poll_started_at_unix.
     */
    private function wmYandexWaitSec(array $stage): int
    {
        $anchor = $stage['verification_poll_started_at'] ?? ($stage['submitted_at'] ?? null);
        if ($anchor === null) return 0;
        $ts = strtotime((string)$anchor);
        if ($ts === false || $ts <= 0) return 0;
        return max(0, time() - $ts);
    }

    /**
     * a1.6.1 (Блокер 2): elapsed для Yandex-polling (сообщения, backoff,
     * long_pending). После submit — считаем от Yandex-таймера (submitted_at),
     * а не от общего poll_started_at_unix.
     * a1.6.2 (аудит): наличие Yandex-якоря определяем по НАЛИЧИЮ поля, а не по
     * положительности elapsed. Сразу после POST submitted_at=NOW → elapsed=0 —
     * это КОРРЕКТНЫЙ ноль, а не «якоря нет». Иначе первый IN_PROGRESS ошибочно
     * брал бы старый poll_started_at_unix (часы подготовки) и включал long_pending.
     */
    private function wmPollElapsedSec(array $stage): int
    {
        $hasYandexAnchor = !empty($stage['verification_poll_started_at'])
            || !empty($stage['submitted_at']);
        if ($hasYandexAnchor) {
            return $this->wmYandexWaitSec($stage);
        }
        $p = (int)($stage['poll_started_at_unix'] ?? time());
        return max(0, time() - $p);
    }

    private function pollWmVerified(array $job, JobEventLogger $log,
        YandexWebmasterClient $client, string $userId, string $hostId,
        string $uin, string $fileName, string $fileUrl): void
    {
        $jobId = (int)$job['id'];
        $artifacts = $this->loadArtifacts($job);
        $stage = $artifacts['wm_verified_stage'] ?? [];

        $attempt = (int)($stage['poll_attempt'] ?? 0) + 1;
        $elapsedSec = $this->wmPollElapsedSec($stage); // a1.6.1: от submitted_at, не общий

        $log->info('wm_verified',
            "Polling attempt #{$attempt} (Yandex проверяет " . round($elapsedSec / 60, 1) . " мин)...");

        try {
            $info = $client->checkVerification($userId, $hostId);
            $verState = $this->normalizeVerificationState($info);

            // Обновляем artifacts
            $patch = ['wm_verified_stage' => [
                'verification_state' => $verState,
                'poll_attempt' => $attempt,
                'last_poll_at' => date('Y-m-d H:i:s'),
                'last_poll_response' => $info,
            ]];
            $this->saveArtifacts($jobId, $patch, $log, 'wm_verified');

            $this->handleVerificationState($job, $log, $verState, $client, $userId, $hostId,
                $uin, $fileName, $fileUrl);
        } catch (\Throwable $e) {
            // v25.1-a1 (Блокер 3): классифицируем ошибку. Временные (429/5xx/
            // network) → pending+backoff; неисправимые (401/403/OAuth) →
            // awaiting_user (иначе крутились бы вечно).
            if ($this->stopIfWmRoutingFatal($e, $jobId, $log, 0, 'wm_verified')) return;
            $class = $this->classifyWmError($e);
            if ($class === 'temporary') {
                $log->warn('wm_verified', "Polling ошибка (временная, продолжаю): " . $e->getMessage());
                $this->scheduleWmVerifiedRetry($jobId, $elapsedSec, $log, $e->getMessage());
                $this->maybeMarkLongPending($jobId, $elapsedSec, $log, 'api_error');
            } elseif ($class === 'config_fatal') {
                $log->error('wm_verified', "Polling: ошибка конфигурации — " . $e->getMessage());
                $this->setStatusAwaitingUser($jobId,
                    'wm_verified: ошибка конфигурации — ' . mb_substr($e->getMessage(), 0, 200));
            } else { // auth_fatal
                $log->error('wm_verified', "Polling: неисправимая ошибка доступа — " . $e->getMessage());
                $this->setStatusAwaitingUser($jobId,
                    'wm_verified: доступ/OAuth — ' . mb_substr($e->getMessage(), 0, 200));
            }
        }
    }

    /**
     * v18.1.33: общая логика обработки verification_state — для первого
     * запроса и для polling. На verified — переход дальше. На in_progress —
     * retry. На failed — awaiting_user.
     */
    private function handleVerificationState(array $job, JobEventLogger $log,
        string $verState, YandexWebmasterClient $client, string $userId, string $hostId,
        string $uin, string $fileName, string $fileUrl): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        $stage = ($this->loadArtifacts($job)['wm_verified_stage'] ?? []);
        // a1.6.1 (Блокер 2): после submit считаем ожидание Яндекса от его таймера,
        // а не от общего poll_started_at_unix (подготовка verifier/FTP/public могла
        // занять часы — это НЕ время ожидания Яндекса).
        $elapsedSec = $this->wmPollElapsedSec($stage);

        if ($verState === 'verified' || $verState === 'success') {
            // a1.6 §4/§5: Webmaster-контур подтвердил (Яндекс: VERIFIED или SUCCESS).
            // Фиксируем confirmed_at, но
            // стадию завершаем ТОЛЬКО когда закрыт и ssl_gate (trusted SSL или
            // ssl skip). Иначе — остаёмся pending, SSL reconciler продолжает выпуск.
            $stage = ($this->loadArtifacts($job)['wm_verified_stage'] ?? []);
            $yandexWaitSec = $this->wmYandexWaitSec($stage);
            if (empty($stage['confirmed_at'])) {
                $log->ok('wm_verified',
                    "✓ Yandex подтвердил права (verified) после " . round($yandexWaitSec / 60, 1) . " мин проверки Яндекса");
                try {
                    $mapping = new SiteWebmasterMappingService();
                    $mapping->updateLink($siteId, $newDomain, [
                        'verified' => 1, 'verification_uin' => $uin, 'verification_file' => $fileName,
                    ]);
                } catch (\Throwable $e) { $log->warn('wm_verified', 'updateLink failed: ' . $e->getMessage()); }
            }
            $patch = ['wm_verified_stage' => [
                'verification_state' => 'verified',
                'confirmed_at' => $stage['confirmed_at'] ?? date('Y-m-d H:i:s'),
                'verified_at' => $stage['verified_at'] ?? date('Y-m-d H:i:s'),
                'yandex_wait_sec' => $yandexWaitSec,
            ]];
            $this->saveArtifacts($jobId, $patch, $log, 'wm_verified');

            // Проверяем оба gate. ВАЖНО: перечитываем job из БД — loadArtifacts
            // читает $job['artifacts_json'], а он устарел (не видит только что
            // сохранённый confirmed_at). Без reload gate не закроется.
            $jobFresh = $this->reloadJob($jobId) ?? $job;
            $stage = ($this->loadArtifacts($jobFresh)['wm_verified_stage'] ?? []);
            if (!$this->wmTryCompleteStage($jobId, $jobFresh, $stage, $log)) {
                // Яндекс подтвердил раньше SSL — ждём trusted, БЕЗ нового submit/poll.
                // a1.6.1 (Блокер 2): это НЕ ожидание Яндекса — короткая SSL-проверка
                // (elapsed=0 → 15с), Yandex long-pending здесь НЕ запускаем.
                $log->info('wm_verified',
                    'Webmaster подтверждён, ждём trusted SSL (awaiting_trusted_ssl_after_verification). SSL reconciler продолжает выпуск.');
                $this->scheduleWmVerifiedRetry($jobId, 0, $log, 'awaiting_trusted_ssl_after_verification');
            }
            return;
        }

        if ($this->isVerificationInProgress($verState)) {
            // v25.1-a (§9): IN_PROGRESS — обычное ожидание, НЕ блокируем.
            // Продолжаем polling; по warning-порогу помечаем long_pending.
            $log->info('wm_verified',
                "⏳ Yandex ещё проверяет (state={$verState}). Прошло " .
                round($elapsedSec / 60, 1) . " мин. Продолжаю автоматические проверки.");
            $this->scheduleWmVerifiedRetry($jobId, $elapsedSec, $log);
            $this->maybeMarkLongPending($jobId, $elapsedSec, $log, $verState);
            return;
        }

        // v25.1-a (§9): обычные временные состояния НЕ переводят в ожидание
        // оператора. IN_PROGRESS / NONE / INTERNAL_ERROR / неизвестное —
        // остаются pending с backoff. По истечении warning-порога — один раз
        // предупреждаем (лог + Telegram) и ставим визуальный long_pending, но
        // polling ПРОДОЛЖАЕТСЯ (не останавливаем pipeline).
        if ($this->isVerificationFailed($verState)) {
            // v25.1-a1 (Блокер 4): НАСТОЯЩЕЕ восстановление — перезаливаем файл и
            // повторяем verifyHost. v25.1-a1.1: outcome-aware, чтобы фатальный
            // результат не перезаписывался обратно в pending и чтобы временные
            // ошибки не жгли лимит recovery.
            $stage = ($this->loadArtifacts($job)['wm_verified_stage'] ?? []);
            $lastRecovery = (int)($stage['last_recovery_unix'] ?? 0);
            $recoveryGapSec = max(60, AppSettings::getInt('wm.recovery_min_gap_seconds', 300));
            $recoveries = (int)($stage['recovery_count'] ?? 0);
            $maxRecoveries = max(1, AppSettings::getInt('wm.recovery_max_attempts', 5));

            if ($recoveries >= $maxRecoveries) {
                // Успешные перезаливки исчерпаны — устойчивая проблема vhost/файла.
                $log->error('wm_verified',
                    "VERIFICATION_FAILED: восстановление исчерпано ({$recoveries}/{$maxRecoveries}). Нужен оператор.");
                $this->setStatusAwaitingUser($jobId,
                    "wm_verified: файл верификации не подтверждается после {$recoveries} авто-перезаливок — проверьте vhost/файл {$fileUrl}");
                return;
            }

            if ((time() - $lastRecovery) >= $recoveryGapSec) {
                $log->warn('wm_verified',
                    "state={$verState} — выполняю авто-восстановление (перезаливка + повторная верификация), попытка " . ($recoveries + 1) . "/{$maxRecoveries}.");
                $outcome = $this->recoverVerificationFile($job, $log, $client, $userId, $hostId, $fileName);

                if ($outcome === 'fatal') {
                    // recoverVerificationFile уже выставил awaiting_user. НЕ
                    // планируем retry (иначе перезапишем в pending) и фиксируем
                    // next_run_at=NULL, чтобы cron не подхватывал.
                    try {
                        DB::pdo()->prepare(
                            "UPDATE refresh_jobs SET next_run_at = NULL
                             WHERE id = ? AND stage_status = 'awaiting_user'"
                        )->execute([$jobId]);
                    } catch (\Throwable $e) {}
                    return;
                }

                if ($outcome === 'restarted') {
                    // Реальная попытка — тратим лимит и обновляем rate-limit.
                    $st = ($this->loadArtifacts($this->reloadJob($jobId) ?? $job)['wm_verified_stage'] ?? []);
                    $st['recovery_count'] = (int)($st['recovery_count'] ?? $recoveries) + 1;
                    $st['last_recovery_unix'] = time();
                    $this->saveArtifacts($jobId, ['wm_verified_stage' => $st], $log, 'wm_verified');
                }
                // 'temporary' — лимит НЕ тратим, просто продолжаем polling ниже.
            } else {
                $log->info('wm_verified',
                    "state={$verState} — жду интервал до следующего авто-восстановления. Продолжаю polling.");
            }
            $this->scheduleWmVerifiedRetry($jobId, $elapsedSec, $log, "verification_failed_recovery");
            $this->maybeMarkLongPending($jobId, $elapsedSec, $log, $verState);
            return;
        }

        // IN_PROGRESS / NONE / INTERNAL_ERROR / любое иное неподтверждённое —
        // продолжаем автоматический polling с backoff, без awaiting_user.
        $log->info('wm_verified',
            "⏳ Верификация не подтверждена (state={$verState}), прошло "
            . round($elapsedSec / 60, 1) . " мин. Продолжаю автоматические проверки.");
        $this->scheduleWmVerifiedRetry($jobId, $elapsedSec, $log);
        $this->maybeMarkLongPending($jobId, $elapsedSec, $log, $verState);
        return;
    }

    /**
     * v25.1-a (§9.2): по истечении warning-порога один раз пометить long_pending
     * + отправить одно предупреждение. Polling НЕ останавливается.
     */
    private function maybeMarkLongPending(int $jobId, int $elapsedSec, JobEventLogger $log, string $verState): void
    {
        $warnMin = max(1, AppSettings::getInt('wm.verification_warning_minutes', 60));
        if ($elapsedSec < $warnMin * 60) return;

        $arts = $this->loadArtifacts(['id' => $jobId, 'artifacts_json' =>
            (DB::pdo()->query("SELECT artifacts_json FROM refresh_jobs WHERE id=" . (int)$jobId)->fetchColumn() ?: '{}')]);
        $stage = $arts['wm_verified_stage'] ?? [];
        if (!empty($stage['long_pending_warned_at'])) return; // уже предупреждали

        $stage['long_pending'] = true;
        $stage['long_pending_warned_at'] = date('Y-m-d H:i:s');
        $this->saveArtifacts($jobId, ['wm_verified_stage' => $stage], $log, 'wm_verified');
        $log->warn('wm_verified',
            "Верификация в статусе '{$verState}' дольше {$warnMin} мин — это дольше обычного, "
            . "но НЕ ошибка: продолжаю автоматические проверки (long_pending).");
        try {
            if (class_exists('TelegramNotifier')) {
                TelegramNotifier::notify("⚠ Джоба #{$jobId}: верификация Вебмастера идёт дольше {$warnMin} мин "
                    . "(state={$verState}). Оператор не нужен, проверки продолжаются автоматически.");
            }
        } catch (\Throwable $e) { /* уведомление не критично */ }
    }

    /**
     * v25.1-a1 (Блокер 4): controlled recovery для VERIFICATION_FAILED /
     * 404 / body-mismatch. Заново получает verifier, перезаливает файл, строго
     * проверяет и повторно вызывает verifyHost. Ошибки классифицируются:
     * temporary → просто продолжаем polling; auth/config_fatal → awaiting.
     * Частота ограничена вызывающим (last_recovery_unix + recovery_count).
     */
    /**
     * v25.1-a1.1: outcome-aware recovery. Возвращает:
     *   'restarted' — файл перезалит и повторный verifyHost отправлен (реальная
     *                 попытка; вызывающий инкрементит recovery_count, ставит pending);
     *   'temporary' — временный сбой API/сети ДО/во время попытки (429/5xx/network)
     *                 или публичная проверка файла ещё не прошла — лимит НЕ тратим,
     *                 вызывающий ставит pending + backoff;
     *   'fatal'     — неисправимая ошибка (OAuth 401/403, config): метод уже
     *                 выставил awaiting_user + next_run_at=NULL; вызывающий НЕ
     *                 должен планировать retry.
     *
     * ВАЖНО (Блокер аудита a1.1): recovery_count/ rate-limit НЕ трогаем здесь —
     * вызывающий инкрементит только при 'restarted', чтобы временные ошибки не
     * жгли лимит и не превращались в awaiting_user.
     */
    private function recoverVerificationFile(array $job, JobEventLogger $log,
        YandexWebmasterClient $client, string $userId, string $hostId, string $fileName): string
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        try {
            // 1) Актуальный verifier (uin/file/content могут обновиться).
            $verifier = $client->getHtmlFileVerifier($userId, $hostId);
            $uin      = (string)$verifier['uin'];
            $fresh    = (string)$verifier['file'];
            $content  = (string)$verifier['content'];
            $useFile  = $fresh !== '' ? $fresh : $fileName;

            // 2) Перезаливаем файл на VPS (v25.2-a §16: без sleep, только FTP).
            $verFs = $this->makeFileVerifier();
            $upRes = $verFs->uploadFileOnly($siteId, $useFile, $content, $log);

            if (empty($upRes['ok'])) {
                // Различаем FTP-фатал и временную публичную недоступность.
                $msg = mb_strtolower((string)($upRes['message'] ?? ''));
                $reason = (string)($upRes['reason'] ?? '');
                $ftpFatal = ($reason === 'ftp_fatal')
                    || (mb_strpos($msg, 'ftp') !== false && (mb_strpos($msg, 'реквизит') !== false
                        || mb_strpos($msg, 'login') !== false || mb_strpos($msg, 'auth') !== false
                        || mb_strpos($msg, 'password') !== false || mb_strpos($msg, 'denied') !== false
                        || mb_strpos($msg, 'connect') !== false));
                if ($ftpFatal) {
                    $log->error('wm_verified', 'Recovery: неисправимая FTP-ошибка — ' . $upRes['message']);
                    $this->setStatusAwaitingUser($jobId, 'wm_verified: recovery FTP — ' . mb_substr((string)$upRes['message'], 0, 200));
                    return 'fatal';
                }
                // Временная публичная недоступность (self-signed/DNS/5xx): файл на
                // FTP уже лежит, ждём. Лимит НЕ тратим.
                $log->info('wm_verified',
                    'Recovery: файл перезалит, публичная проверка ещё не прошла (' . $upRes['message'] . '). Продолжаю.');
                return 'temporary';
            }

            // 3) Обновим сохранённые данные файла + повторный POST verifyHost.
            $stage2 = ($this->loadArtifacts($this->reloadJob($jobId) ?? $job)['wm_verified_stage'] ?? []);
            $stage2['uin'] = $uin;
            $stage2['file'] = $useFile;
            $stage2['file_url'] = $upRes['url'] ?? ($stage2['file_url'] ?? '');
            $this->saveArtifacts($jobId, ['wm_verified_stage' => $stage2], $log, 'wm_verified');

            $log->info('wm_verified', 'Recovery: повторный POST verifyHost/HTML_FILE...');
            $client->verifyHost($userId, $hostId, 'HTML_FILE');
            $log->ok('wm_verified', 'Recovery: файл перезалит и верификация перезапущена. Продолжаю polling.');
            return 'restarted';
        } catch (\Throwable $e) {
            if ($this->stopIfWmRoutingFatal($e, $jobId, $log, 0, 'wm_verified')) return 'fatal';
            $class = $this->classifyWmError($e);
            if ($class === 'temporary') {
                $log->warn('wm_verified', 'Recovery: временная ошибка (' . $e->getMessage() . '). Повторю позже.');
                return 'temporary'; // лимит не тратим; вызывающий продолжит polling
            }
            if ($class === 'config_fatal') {
                $log->error('wm_verified', 'Recovery: ошибка конфигурации — ' . $e->getMessage());
                $this->setStatusAwaitingUser($jobId, 'wm_verified: recovery config — ' . mb_substr($e->getMessage(), 0, 200));
                return 'fatal';
            }
            $log->error('wm_verified', 'Recovery: неисправимый доступ — ' . $e->getMessage());
            $this->setStatusAwaitingUser($jobId, 'wm_verified: recovery доступ/OAuth — ' . mb_substr($e->getMessage(), 0, 200));
            return 'fatal';
        }
    }

    /**
     * v18.1.33: нормализация verification_state от Webmaster API.
     * Yandex возвращает разные варианты: 'verified', 'VERIFIED', 'in_progress',
     * 'IN_PROGRESS', 'verification_in_progress', etc. Приводим к нижнему регистру
     * и убираем префикс 'verification_'.
     */
    private function normalizeVerificationState($response): string
    {
        if (is_array($response)) {
            $raw = (string)($response['verification_state']
                ?? $response['data']['verification_state']
                ?? 'unknown');
        } else {
            $raw = (string)$response;
        }
        $low = strtolower(trim($raw));
        // Убираем префикс verification_ для удобства
        if (strpos($low, 'verification_') === 0) {
            $low = substr($low, strlen('verification_'));
        }
        return $low;
    }

    private function isVerificationInProgress(string $state): bool
    {
        return in_array($state, [
            'in_progress',
            'pending',
            'started',
            'processing',
        ], true);
    }

    private function isVerificationFailed(string $state): bool
    {
        return in_array($state, [
            'failed',
            'verification_failed',
            'error',
            'rejected',
        ], true);
    }

    /**
     * v25.1-a1 (Блокер 3): единый классификатор ошибок wm_verified для ВСЕХ
     * фаз (создание клиента, getHtmlFileVerifier, uploadVerificationFile,
     * verifyHost, checkVerification). Возвращает 'auth_fatal' | 'temporary' |
     * 'config_fatal'.
     *
     *   auth_fatal  → awaiting_user (нужен оператор): 401/403/OAuth/токен/аккаунт.
     *   temporary   → pending + backoff: 429/5xx/network/timeout/connect/SSL.
     *   config_fatal→ awaiting_user с точной причиной: устойчивый 400/404
     *                 неверного host/account, неверные FTP-реквизиты.
     */
    private function classifyWmError(\Throwable $e): string
    {
        // revision §5/§6: routing failure НИКОГДА не temporary. Критические причины
        // (mismatch/bind/resolve/redirect) → config_fatal (оператор), timeout → temporary.
        if (WebmasterRoutingFailurePolicy::isCritical($e)) return 'config_fatal';
        if (WebmasterRoutingFailurePolicy::isTransient($e)) return 'temporary';
        $m = mb_strtolower($e->getMessage());
        // Явные HTTP-коды из текста ошибки клиента.
        $has = function (array $needles) use ($m): bool {
            foreach ($needles as $n) { if (mb_strpos($m, $n) !== false) return true; }
            return false;
        };
        // 1) Неисправимая аутентификация/авторизация.
        if ($has(['401', '403', 'unauthorized', 'forbidden', 'oauth', 'токен', 'token',
                  'invalid_grant', 'revoked', 'access denied', 'аккаунт удал', 'account deleted',
                  'not your host', 'чужой аккаунт'])) {
            return 'auth_fatal';
        }
        // 2) Временные ошибки API/сети — продолжаем polling.
        if ($has(['429', '500', '502', '503', '504', 'timeout', 'timed out', 'time-out',
                  'temporarily', 'temporary', 'connection', 'could not resolve', 'network',
                  'ssl', 'tls', 'gateway', 'unavailable', 'reset by peer', 'try again'])) {
            return 'temporary';
        }
        // 3) Устойчивая ошибка конфигурации/запроса — оператор с точной причиной.
        if ($has(['400', '404', 'not found', 'bad request', 'ftp', 'реквизит', 'credential',
                  'permission denied', 'no such', 'wrong host', 'неверн'])) {
            return 'config_fatal';
        }
        // По умолчанию — считаем временной (безопаснее продолжить polling, чем
        // навсегда остановить корректную джобу). Auth/config уже отсеяны выше.
        return 'temporary';
    }

    /**
     * v18.1.33: adaptive backoff для polling wm_verified.
     * 30s → 1min → 3min → 5min → 15min → 30min → 1h → 6h (потом потолок 24h).
     */
    private function computeWmVerifiedRetryDelay(int $elapsedSec): int
    {
        // v25.2-a (§7): быстрый adaptive retry. Если внешний cron вызывается
        // каждые 15 сек, первая повторная проверка доступна через 15с.
        if ($elapsedSec < 5 * 60)      return 15;       // первые 5 мин — каждые 15 сек
        if ($elapsedSec < 15 * 60)     return 30;       // 5–15 мин — каждые 30 сек
        if ($elapsedSec < 60 * 60)     return 60;       // 15–60 мин — каждую минуту
        if ($elapsedSec < 6 * 3600)    return 3 * 60;   // до 6 ч — каждые 3 мин
        if ($elapsedSec < 24 * 3600)   return 3600;     // до 24 ч — каждый час
        return 6 * 3600;                                 // дальше — каждые 6 часов
    }

    private function scheduleWmVerifiedRetry(int $jobId, int $elapsedSec,
        JobEventLogger $log, string $extraReason = ''): void
    {
        $delay = $this->computeWmVerifiedRetryDelay($elapsedSec);
        $delayHuman = $delay >= 3600
            ? round($delay / 3600, 1) . ' ч'
            : ($delay >= 60 ? round($delay / 60) . ' мин' : $delay . ' сек');

        try {
            // v25.1-a (§9): штатный retry верификации — pending, чтобы cron
            // автоматически подхватывал транзиентное состояние. Раньше здесь
            // стоял awaiting_user как «парковка», что конфликтовало с реальным
            // смыслом «нужен оператор» и останавливало pipeline.
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
                 WHERE id = ?
                   AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([$delay, $jobId]);
            $msg = "Следующая проверка через {$delayHuman}";
            if ($extraReason !== '') {
                $msg .= " (причина: {$extraReason})";
            }
            $log->info('wm_verified', $msg);
        } catch (\Throwable $e) {
            $log->warn('wm_verified', 'Не удалось запланировать retry: ' . $e->getMessage());
        }
    }


    /**
     * Стадия wm_sitemap — добавляет sitemap к хосту в Webmaster.
     */
    private function runWmSitemapStage(array $job, JobEventLogger $log): void
    {
        // P0 §4.5: fail-closed — без атомарно подтверждённого trusted-SSL gate
        // Yandex API для новой revision не вызывается.
        if (!$this->wmSslGateGuard($job, $log, 'wm_sitemap')) return;
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        $artifacts = $this->loadArtifacts($job);
        $addedStage = $artifacts['wm_added_stage'] ?? null;
        if ($addedStage === null) {
            $this->setStatusFailed($jobId, 'wm_sitemap: no wm_added in artifacts');
            return;
        }

        $accountId = (int)$addedStage['account_id'];
        $userId = (string)$addedStage['user_id'];
        $hostId = (string)$addedStage['host_id'];

        $sitemapUrl = 'https://' . $newDomain . '/sitemap.xml';

        try {
            $client = $this->makeWmClient($accountId);
            $this->emitWmRouting($client, $log, (int)$accountId, (int)$jobId, 'wm_sitemap');
            $log->info('wm_sitemap', "Добавляю sitemap: {$sitemapUrl}");
            $res = $client->addSitemap($userId, $hostId, $sitemapUrl);

            $mapping = new SiteWebmasterMappingService();
            $mapping->updateLink($siteId, $newDomain, ['sitemap_added' => 1]);

            $patch = ['wm_sitemap_stage' => [
                'ok' => true,
                'sitemap_url' => $sitemapUrl,
                'response' => $res,
            ]];
            $this->saveArtifacts($jobId, $patch, $log, 'wm_sitemap');

            $log->ok('wm_sitemap', "✓ Sitemap добавлен: {$sitemapUrl}");
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
        } catch (\Throwable $e) {
            // revision §6: routing failure (mismatch/bind/resolve/redirect) → критический стоп,
            // НЕ проглатываем как обычный warning и НЕ ставим stage OK.
            if ($this->stopIfWmRoutingFatal($e, $jobId, $log, $accountId, 'wm_sitemap')) return;
            // Не блокируем — sitemap не критичен для индексации, Yandex и сам найдёт
            $log->warn('wm_sitemap',
                "Не удалось добавить sitemap (но pipeline продолжается): " . $e->getMessage());
            $patch = ['wm_sitemap_stage' => [
                'ok' => false,
                'error' => $e->getMessage(),
                'sitemap_url' => $sitemapUrl,
            ]];
            $this->saveArtifacts($jobId, $patch, $log, 'wm_sitemap');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
        }
    }

    /**
     * v18: Стадия wm_robots — проверка что robots.txt доступен на новом домене,
     * плюс опциональная диагностика через Yandex API.
     *
     * Реализация скопирована со стиля Hub Panel:
     *   1. HTTP HEAD-проверка https://NEW_DOMAIN/robots.txt — основной шаг
     *      (если отдаётся 2xx-3xx → робот сможет его прочитать)
     *   2. Опционально GET /v4/.../hosts/{hid}/robots — узнать что Yandex
     *      уже видит (если эндпоинт доступен в публичном API)
     *
     * Поведение по результатам:
     *   - HEAD ok (2xx-3xx) → ok, стадия успешно
     *   - HEAD failed (404/timeout/5xx) → warn, но идём дальше — Yandex
     *     увидит robots.txt при обходе сайта в любом случае, даже если
     *     прямо сейчас он недоступен (CDN cache, временный сбой)
     *   - API GET 401 диагностического robots endpoint → best-effort api_unavailable (warning),
     *     следующие стадии всё равно упадут с 401, лучше остановиться
     *     сразу с понятной ошибкой
     *   - API GET 200 → парсим директивы/sitemaps/access_status
     *   - API GET 404 → endpoint не доступен, не критично (большинство случаев)
     *
     * Стадия best-effort: 401 доп. API НЕ валит pipeline; fail-closed только для routing fatal.
     * Все остальные ошибки логируются как warn и идут дальше.
     *
     * Зачем вообще: после wm_verified Yandex автоматически читает robots.txt
     * при следующем обходе. Эта стадия — диагностика что (а) файл реально
     * доступен HTTP-ом, и (б) опционально что Yandex его уже видит.
     */
    private function runWmRobotsStage(array $job, JobEventLogger $log): void
    {
        // P0 §4.5: fail-closed — без атомарно подтверждённого trusted-SSL gate
        // Yandex API для новой revision не вызывается.
        if (!$this->wmSslGateGuard($job, $log, 'wm_robots')) return;
        $jobId = (int)$job['id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        if ($newDomain === '') {
            $log->warn('wm_robots', 'new_domain пустой — пропускаю');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // === Шаг 1: полноценная HTTP GET-проверка robots.txt (P1-1) ===
        // GET + чтение тела + TLS verify + контроль конечного host + валидация содержимого.
        $robotsUrl = "https://{$newDomain}/robots.txt";
        $log->info('wm_robots', "HTTP GET {$robotsUrl}");
        $headCheck = $this->httpGetRobots($robotsUrl);

        $expectedHost = strtolower($this->bareDomain($newDomain));
        $finalHostBare = preg_replace('~^www\\.~', '', (string)($headCheck['final_host'] ?? ''));
        $transportOk = ($headCheck['http'] >= 200 && $headCheck['http'] < 400);
        $hostOk = ($finalHostBare === '' ? true : ($finalHostBare === $expectedHost));
        $httpOk = $transportOk && $hostOk;                                   // прямой HTTP «доступен»
        $contentOk = $httpOk && RobotsCheckDecision::contentLooksLikeRobots($headCheck['body'] ?? null);

        if (!$hostOk) {
            $log->warn('wm_robots',
                "⚠ robots.txt после редиректов ушёл на другой host: {$finalHostBare} (ожидался {$expectedHost}).");
        }
        $log->info('wm_robots',
            "robots GET: http={$headCheck['http']} host_ok=" . ($hostOk ? '1' : '0')
            . " content_ok=" . ($contentOk ? '1' : '0')
            . ($headCheck['final_url'] !== $robotsUrl ? ", final={$headCheck['final_url']}" : ''));

        // === Шаг 2: опционально — диагностический GET к Yandex API ===
        // Этого может НЕ быть в публичном API; если 404 — просто пропускаем.
        // 401 доп. API (диагностика robots) → best-effort api_unavailable, БЕЗ остановки pipeline.
        $apiResult = ['attempted' => false];

        $artifacts = $this->loadArtifacts($job);
        $resolveStage = $artifacts['wm_account_resolve_stage'] ?? null;
        $addedStage   = $artifacts['wm_added_stage'] ?? null;

        if ($resolveStage !== null && $addedStage !== null) {
            $accountId = (int)($resolveStage['new_account_id'] ?? 0);
            $userId    = (string)($addedStage['user_id'] ?? $resolveStage['new_user_id'] ?? '');
            $hostId    = (string)($addedStage['host_id'] ?? '');

            if ($accountId > 0 && $userId !== '' && $hostId !== '') {
                $log->info('wm_robots',
                    "GET Yandex API: что Yandex видит про robots для host_id={$hostId}");
                // revision 2 §11/§12: critical routing failure из API-диагностики robots —
                // критический стоп (НЕ «endpoint недоступен, идём дальше», НЕ второй endpoint).
                try {
                    $apiResult = $this->fetchRobotsFromApi($accountId, $userId, $hostId, $log, $jobId);
                } catch (\Throwable $e) {
                    // P0-2: routing fatal обрабатывается ПЕРВЫМ и БЕЗУСЛОВНО — независимо от $httpOk.
                    // Политика fail-closed маршрутизации (PATCH 047) не зависит от доступности robots.txt.
                    if ($this->stopIfWmRoutingFatal($e, $jobId, $log, $accountId, 'wm_robots')) return;
                    // Не-fatal ошибка доп. API → best-effort недоступность (без ERROR/setStatusFailed).
                    $apiResult = ['attempted' => true, 'ok' => false, 'http_code' => null,
                                  'error' => $e->getMessage(), 'best_effort_continued' => true];
                }
                // P0-1: fetchRobotsFromApi для 401 больше НЕ дергает setStatusFailed — возвращает
                // структурированный результат; трактуем как недоступность доп. API (best-effort) ниже.
            }
        }

        // === Решение по стадии — чистая политика RobotsCheckDecision (тестируемая, §10) ===
        $apiForDecision = [
            'attempted' => !empty($apiResult['attempted']),
            'ok'        => !empty($apiResult['ok']),
            'http_code' => $apiResult['http_code'] ?? null,
            'routing_fatal' => false, // routing fatal уже обработан выше (stopIfWmRoutingFatal → return)
        ];
        $decision = RobotsCheckDecision::decide($httpOk, $contentOk, $apiForDecision);

        // === Сохраняем артефакты (раздельные признаки: транспорт / содержимое / доп. API) ===
        $stageData = [
            'http_check' => [
                'url'        => $robotsUrl,
                'http_code'  => $headCheck['http'],
                'final_url'  => $headCheck['final_url'],
                'final_host' => $headCheck['final_host'] ?? '',
                'curl_err'   => $headCheck['err'],
                'transport_ok' => $transportOk,
                'host_ok'      => $hostOk,
                'content_ok'   => $contentOk,
                'ok'           => $httpOk,
            ],
            'api_check'      => $apiResult,
            'robots_http_ok' => $httpOk,
            'robots_content_ok' => $contentOk,
            'api_attempted'  => !empty($apiResult['attempted']),
            'api_ok'         => !empty($apiResult['ok']),
            'best_effort'    => true,
            'verified'       => $decision['verified'],
            'overall_ok'     => $decision['verified'], // подтверждение = прямой HTTP + валидное содержимое
        ];
        $this->saveArtifacts($jobId, ['wm_robots_stage' => $stageData], $log, 'wm_robots');

        // Fail-closed (защитно; обычно routing fatal уже перехвачен в catch).
        if ($decision['action'] === 'stop_fatal') {
            $this->setStatusAwaitingUser($jobId, 'wm_robots: routing fatal (fail-closed)');
            return;
        }

        // Эмитим точные события политики (verified / http_unavailable / content_invalid / api_unavailable).
        foreach ($decision['events'] as $ev) {
            $ctx = ['event_code' => $ev['code'], 'source' => $ev['source'],
                    'robots_http' => $headCheck['http']];
            foreach (['robots_http_ok','robots_content_ok','api_http'] as $k) {
                if (array_key_exists($k, $ev)) $ctx[$k] = $ev[$k];
            }
            if (($ev['level'] ?? 'info') === 'ok') {
                $log->ok('wm_robots', 'robots.txt подтверждён прямым HTTP GET (TLS+host+содержимое). Pipeline → wm_recrawl.', $ctx);
            } elseif (($ev['level'] ?? 'info') === 'warn') {
                $msg = $ev['code'] === 'robots.http_unavailable'
                        ? 'robots.txt недоступен по прямому HTTP (best-effort). Pipeline идёт дальше.'
                        : ($ev['code'] === 'robots.content_invalid'
                            ? 'robots.txt ответил, но содержимое не распознано как директивы (best-effort).'
                            : 'Дополнительная API-проверка robots недоступна (best-effort).');
                $log->warn('wm_robots', $msg, $ctx);
            } else {
                $log->info('wm_robots', 'robots: ' . $ev['code'], $ctx);
            }
        }

        // Стадия best-effort → ok (не перетираем никакой fatal: он бы уже сделал return выше).
        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    /**
     * v18: HTTP HEAD-проверка robots.txt.
     * Аналог httpHead() из Hub Panel — следует за редиректами,
     * возвращает финальный код и URL.
     *
     * @return array{http:int, final_url:string, err:?string}
     */
    private function httpHeadRobots(string $url): array
    {
        $ch = curl_init($url);
        if ($ch === false) {
            return ['http' => 0, 'final_url' => $url, 'err' => 'curl_init failed'];
        }
        curl_setopt_array($ch, [
            CURLOPT_NOBODY         => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            // v18.1.10: yandex UA — см. комментарий выше про 1win шаблоны
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) refresh-panel-robots-check',
        ]);
        curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $err = (string)curl_error($ch);
        curl_close($ch);

        return [
            'http'      => $http,
            'final_url' => $final !== '' ? $final : $url,
            'err'       => $err !== '' ? $err : null,
        ];
    }

    /**
     * P1-1: полноценная проверка robots.txt прямым GET.
     *  - читает ТЕЛО (не HEAD), следует редиректам;
     *  - TLS verification включён (перед стадией уже пройден trusted_ssl_gate → fail-closed);
     *  - возвращает конечный host для контроля, что не ушли на чужой домен/страницу.
     */
    private function httpGetRobots(string $url): array
    {
        $ch = curl_init($url);
        if ($ch === false) return ['http' => 0, 'final_url' => $url, 'final_host' => '', 'body' => null, 'err' => 'curl_init failed'];
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,   // P1-1: TLS проверяется (trusted SSL уже подтверждён gate'ом)
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) refresh-panel-robots-check',
        ]);
        $body = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $err = (string)curl_error($ch);
        curl_close($ch);
        $finalHost = strtolower((string)parse_url($final !== '' ? $final : $url, PHP_URL_HOST));
        return [
            'http'       => $http,
            'final_url'  => $final !== '' ? $final : $url,
            'final_host' => $finalHost,
            'body'       => is_string($body) ? $body : null,
            'err'        => $err !== '' ? $err : null,
        ];
    }

    /**
     * v18: попытка получить инфу о robots через Yandex API.
     *
     * Возвращает структурированный результат + ОСОБОЕ поведение для 401:
     * если токен протух → setStatusFailed() и pipeline останавливается.
     *
     * @return array{
     *   attempted:bool,
     *   ok:bool,
     *   endpoint:?string,
     *   http_code:?int,
     *   directives_count:?int,
     *   sitemaps:array,
     *   access_status:?string,
     *   error:?string
     * }
     */
    private function fetchRobotsFromApi(int $accountId, string $userId, string $hostId,
                                         JobEventLogger $log, int $jobId): array
    {
        $client = $this->makeWmClient($accountId);
        $this->emitWmRouting($client, $log, (int)$accountId, (int)$jobId, 'wm_robots');

        $tries = [
            "/v4/user/" . rawurlencode($userId) . "/hosts/" . rawurlencode($hostId) . "/robots",
            "/v4/user/" . rawurlencode($userId) . "/hosts/" . rawurlencode($hostId) . "/robots.txt",
        ];

        $lastErr = null;
        $lastHttpCode = null;

        foreach ($tries as $path) {
            try {
                $resp = $client->rawRequest('GET', $path, [], null);

                // успех — парсим что вернулось
                $directives = $resp['directives']
                              ?? $resp['data']['directives']
                              ?? null;
                $sitemaps = $resp['sitemaps']
                            ?? $resp['data']['sitemaps']
                            ?? [];
                $accessStatus = $resp['access_status']
                                ?? $resp['data']['access_status']
                                ?? null;

                $directivesCount = is_array($directives) ? count($directives) : null;
                $sitemapsList = is_array($sitemaps)
                    ? array_values(array_filter(array_map(
                        fn($s) => is_string($s) ? $s : ($s['url'] ?? null),
                        $sitemaps), 'is_string'))
                    : [];

                $log->info('wm_robots',
                    "✓ Yandex API ответил по {$path}: " .
                    "директив=" . ($directivesCount ?? '?') .
                    ", sitemaps=" . count($sitemapsList) .
                    ", access_status=" . ($accessStatus ?? '?'));

                return [
                    'attempted'        => true,
                    'ok'               => true,
                    'endpoint'         => $path,
                    'http_code'        => 200,
                    'directives_count' => $directivesCount,
                    'sitemaps'         => $sitemapsList,
                    'access_status'    => $accessStatus,
                    'error'            => null,
                ];

            } catch (\Throwable $e) {
                // revision 2 §12: critical routing failure — НЕ пробуем второй endpoint и НЕ
                // считаем endpoint недоступным. Пробрасываем в runWmRobotsStage → критический стоп.
                if (WebmasterRoutingFailurePolicy::isCritical($e)) throw $e;
                $msg = $e->getMessage();
                $lastErr = $msg;

                // 401 доп. API (диагностика robots): best-effort — НЕ останавливаем pipeline,
                // фиксируем структурированно; решение принимает RobotsCheckDecision.
                if (strpos($msg, 'HTTP 401') !== false || strpos($msg, '401') !== false) {
                    // P0-1: диагностический best-effort endpoint НЕ пишет ERROR и НЕ дергает
                    // setStatusFailed(). 401 доп. API возвращается структурированно; решение о
                    // презентации (robots.api_unavailable, best-effort) принимает runWmRobotsStage.
                    $log->info('wm_robots',
                        "Дополнительный Webmaster API вернул 401 (диагностика robots, best-effort). " .
                        "Прямой HTTP-результат robots.txt оценивается отдельно.");
                    return [
                        'attempted'  => true,
                        'ok'         => false,
                        'endpoint'   => $path,
                        'http_code'  => 401,
                        'error'      => 'auth_401',
                        'error_kind' => 'auth_401',
                        'sitemaps'   => [],
                    ];
                }

                // 404 — endpoint не доступен в публичном API, пробуем следующий
                // 5xx — Yandex API временно недоступен, тоже пробуем следующий
                if (preg_match('/HTTP (\d+)/', $msg, $matches)) {
                    $lastHttpCode = (int)$matches[1];
                }
            }
        }

        // Все попытки провалились — это ОК, не критично.
        // Endpoint просто не доступен в публичном API.
        $log->info('wm_robots',
            "Yandex API не отдал robots-инфо ни через один эндпоинт " .
            "(последняя ошибка: {$lastErr}). Это нормально: эти эндпоинты " .
            "не задокументированы в публичном API. Yandex прочитает robots.txt " .
            "автоматически при следующем обходе сайта.");

        return [
            'attempted' => true,
            'ok'        => false,
            'endpoint'  => null,
            'http_code' => $lastHttpCode,
            'sitemaps'  => [],
            'error'     => $lastErr,
        ];
    }

    /**
     * Стадия wm_recrawl — запрашивает переобход главной + внутренних страниц.
     *
     * v18.1: для 7k шаблона достаём $pages из config.php (через FTP) и отправляем
     * все ключи как URL'ы. Это даёт более полный recrawl: не только главная,
     * но и /bonus, /zerkalo, /vhod и т.д.
     *
     * Для шаблонов где $pages нет (sykaaa-casino и подобные) — fallback на главную.
     */
    private function runWmRecrawlStage(array $job, JobEventLogger $log): void
    {
        // P0 §4.5: fail-closed — без атомарно подтверждённого trusted-SSL gate
        // Yandex API для новой revision не вызывается.
        if (!$this->wmSslGateGuard($job, $log, 'wm_recrawl')) return;
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        $artifacts = $this->loadArtifacts($job);
        $addedStage = $artifacts['wm_added_stage'] ?? null;
        if ($addedStage === null) {
            $this->setStatusFailed($jobId, 'wm_recrawl: no wm_added in artifacts');
            return;
        }

        $accountId = (int)$addedStage['account_id'];
        $userId = (string)$addedStage['user_id'];
        $hostId = (string)$addedStage['host_id'];

        // v25.0-b: планируем URL в таблицу refresh_job_recrawl_urls (идемпотентно).
        // ТЗ046 §1: sitemap НИКОГДА не отправляется в переобход. Роли: home (required) + page.
        // sitemap как sitemap добавляется отдельной стадией wm_sitemap (addSitemap) — её не трогаем.
        $urls = $this->buildRecrawlUrls($job, $newDomain, $log);
        $plan = [];
        $home = 'https://' . $newDomain . '/';
        $plan[] = ['url' => $home, 'role' => 'home', 'required' => true];
        foreach ($urls as $u) {
            if (rtrim($u, '/') === rtrim($home, '/')) continue; // главная уже добавлена
            if (RecrawlUrlRepository::isSitemapUrl($u)) {          // ТЗ046: sitemap не в переобход
                $log->info('wm_recrawl', "  — {$u} — sitemap, в переобход не отправляется");
                continue;
            }
            $plan[] = ['url' => $u, 'role' => 'page', 'required' => true];
        }
        $added = RecrawlUrlRepository::planUrls($jobId, $plan);
        if ($added > 0) {
            $log->info('wm_recrawl', "Запланировано URL для переобхода: +{$added} (всего в очереди на отправку)");
        }
        // ТЗ046 §2: финализировать старые sitemap-строки из БД до любого claim/submit.
        $excludedSitemap = RecrawlUrlRepository::excludeSitemapRows($jobId);
        if ($excludedSitemap > 0) {
            $log->info('wm_recrawl', "Старые sitemap-строки исключены из переобхода: {$excludedSitemap} (sitemap_not_for_recrawl)");
        }

        try {
            $client = $this->makeWmClient($accountId);
            $this->emitWmRouting($client, $log, (int)$accountId, (int)$jobId, 'wm_recrawl');

            // v25.0-b1 (B4): восстановить залипшие __claimed (упавшие процессы).
            $recovered = RecrawlUrlRepository::recoverStaleClaims($jobId,
                max(60, AppSettings::getInt('recrawl.claim_timeout_seconds', 300)));
            if ($recovered > 0) {
                $log->info('wm_recrawl', "Восстановлено зависших claim-строк: {$recovered}");
            }

            $quota = $client->getRecrawlQuota($userId, $hostId);
            $remainder = (int)$quota['quota_remainder'];
            $log->info('wm_recrawl',
                "Recrawl quota: daily={$quota['daily_quota']}, remainder={$remainder}");

            // Квота 0 → НЕ failed: помечаем невыдвинутые pending_quota и ждём окна.
            if ($remainder <= 0) {
                $claimed = RecrawlUrlRepository::claimBatch($jobId, 50);
                foreach ($claimed as $r) {
                    RecrawlUrlRepository::markPendingQuota((int)$r['id'], 900);
                }
                $log->warn('wm_recrawl', 'Квота исчерпана — жду следующего окна (pending_quota).');
                $this->finishRecrawlTick($jobId, $newDomain, $siteId, $log, /*quotaZero*/true);
                return;
            }

            $batchLimit = min($remainder, max(1, AppSettings::getInt('recrawl.batch_per_tick', 20)));
            $claimed = RecrawlUrlRepository::claimBatch($jobId, $batchLimit);

            $submit = $this->makeRecrawlSubmit();
            $attempted = 0; $accepted = 0; $retry = 0; $failed = 0; $pendingQuota = 0;
            $quotaUsed = 0; $anyAccepted = false;
            $awaitHost = false; $awaitAccount = false; $awaitMsg = '';

            foreach ($claimed as $r) {
                $id = (int)$r['id'];
                $url = (string)$r['url'];
                $attemptsSoFar = (int)$r['attempts'];
                if ($remainder - $quotaUsed <= 0) {
                    RecrawlUrlRepository::markPendingQuota($id, 900); $pendingQuota++;
                    continue;
                }
                $attempted++;
                $res = $submit->submit($client, $userId, $hostId, $url, $newDomain);
                $outcome = (string)$res['outcome'];

                switch ($outcome) {
                    case 'accepted':
                        RecrawlUrlRepository::markAccepted($id,
                            $res['api_http_code'] ?? null, $res['task_id'] ?? null, $res['page_http_code'] ?? null);
                        $accepted++; $quotaUsed++; $anyAccepted = true;
                        $log->info('wm_recrawl', "  ✓ {$url} — принят"
                            . (!empty($res['task_id']) ? " (task_id={$res['task_id']})" : ''));
                        break;
                    case 'pending_quota':
                        RecrawlUrlRepository::markPendingQuota($id, 900); $pendingQuota++;
                        $log->info('wm_recrawl', "  ⏸ {$url} — квота исчерпана (pending_quota)");
                        break;
                    case 'failed':
                        RecrawlUrlRepository::markFailedImmediate($id, (string)($res['error'] ?? 'invalid'),
                            $res['api_http_code'] ?? null, $res['api_error_code'] ?? null);
                        $failed++;
                        $log->warn('wm_recrawl', "  ✗ {$url} — отклонён: " . ($res['error'] ?? 'invalid'));
                        break;
                    case 'awaiting_host':
                        RecrawlUrlRepository::releaseClaims($jobId);
                        $awaitHost = true; $awaitMsg = (string)($res['error'] ?? 'host not verified');
                        break 2; // прекращаем цикл — нужен возврат к верификации
                    case 'awaiting_account':
                        RecrawlUrlRepository::releaseClaims($jobId);
                        $awaitAccount = true; $awaitMsg = (string)($res['error'] ?? 'account error');
                        break 2;
                    case 'retry':
                    default:
                        $role = (string)($r['role'] ?? 'page');
                        $pageCode = (int)($res['page_http_code'] ?? 0);
                        // sitemap.xml физически отсутствует (404/410) — это НЕ
                        // ошибка: помечаем excluded, чтобы не блокировать стадию.
                        if ($role === 'sitemap' && in_array($pageCode, [404, 410], true)) {
                            RecrawlUrlRepository::markExcluded($id, "sitemap.xml отсутствует на сайте (HTTP {$pageCode})");
                            $log->info('wm_recrawl', "  — {$url} — sitemap отсутствует (HTTP {$pageCode}), исключён");
                            break;
                        }
                        $st = ($res['reason'] ?? '') === 'wrong_final_host'
                            ? RecrawlUrlRepository::markFailedImmediate($id, (string)$res['error'], null, 'WRONG_HOST')
                            : (isset($res['page_http_code']) && (int)$res['page_http_code'] !== 200 && empty($res['api_http_code'])
                                ? RecrawlUrlRepository::markPageUnreachable($id, $attemptsSoFar, (string)($res['error'] ?? 'page not 200'), (int)($res['page_http_code'] ?? 0))
                                : RecrawlUrlRepository::markRetryOrFailed($id, $attemptsSoFar, (string)($res['error'] ?? 'temporary'), $res['api_http_code'] ?? null, $res['api_error_code'] ?? null));
                        if ($st === RecrawlUrlRepository::ST_FAILED) { $failed++; $log->warn('wm_recrawl', "  ✗ {$url} — исчерпаны попытки: " . ($res['error'] ?? '')); }
                        else { $retry++; $log->info('wm_recrawl', "  ↻ {$url} — повтор позже: " . ($res['error'] ?? '')); }
                        break;
                }
            }

            // Возврат к верификации / аккаунт-ошибка — awaiting_user сразу.
            if ($awaitHost) {
                $log->error('wm_recrawl', "Host не верифицирован при recrawl — возврат к верификации: {$awaitMsg}");
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL
                     WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([mb_substr("wm_recrawl: host не верифицирован ({$awaitMsg}). Перепройдите wm_verified.", 0, 1000), $jobId]);
                return;
            }
            if ($awaitAccount) {
                $log->error('wm_recrawl', "Ошибка аккаунта при recrawl: {$awaitMsg}");
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL
                     WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
                )->execute([mb_substr("wm_recrawl: ошибка аккаунта Вебмастера ({$awaitMsg}).", 0, 1000), $jobId]);
                return;
            }

            $log->info('wm_recrawl',
                "Тик recrawl: attempted={$attempted}, accepted={$accepted}, retry={$retry}, "
                . "pending_quota={$pendingQuota}, failed={$failed}");

            // v25.0-b1 (B4): mapping.recrawl_requested — ТОЛЬКО если реально
            // приняли хоть один URL (не при accepted=0).
            if ($anyAccepted) {
                (new SiteWebmasterMappingService())->updateLink($siteId, $newDomain, ['recrawl_requested' => 1]);
            }
            $this->finishRecrawlTick($jobId, $newDomain, $siteId, $log, /*quotaZero*/false);

        } catch (\Throwable $e) {
            // revision §6: routing failure → критический awaiting_user, НЕ обычный pending/retry.
            if ($this->stopIfWmRoutingFatal($e, $jobId, $log, $accountId, 'wm_recrawl')) {
                RecrawlUrlRepository::releaseClaims($jobId);
                return;
            }
            // Ошибка получения quota / клиента — не роняем, освобождаем claim и повторяем.
            RecrawlUrlRepository::releaseClaims($jobId);
            $log->warn('wm_recrawl', 'Exception (повтор позже): ' . $e->getMessage());
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='pending',
                    next_run_at=DATE_ADD(NOW(), INTERVAL ? SECOND)
                 WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                class_exists('DomainReadinessService') ? DomainReadinessService::normalIntervalSec() : 60,
                $jobId,
            ]);
        }
    }

    /**
     * v25.0-b: решение о завершении/продолжении recrawl-стадии по сводке.
     * done ТОЛЬКО когда все обязательные accepted/excluded (и home+sitemap
     * accepted). Частичная отправка НЕ даёт общий успех. Обязательный URL в
     * failed → awaiting_user с конкретным URL. Иначе — pending + next_run_at.
     */
    private function finishRecrawlTick(int $jobId, string $newDomain, int $siteId, JobEventLogger $log, bool $quotaZero): void
    {
        $s = RecrawlUrlRepository::summary($jobId);
        // Реальные счётчики в артефакты (агрегированная сводка).
        $this->saveArtifacts($jobId, ['wm_recrawl_stage' => [
            'planned'       => $s['planned'],
            'accepted'      => $s['accepted'],
            'retry'         => $s['retry'],
            'pending'       => $s['pending'],
            'pending_quota' => $s['pending_quota'],
            'failed'        => $s['failed'],
            'excluded'      => $s['excluded'],
            'required_open' => $s['required_open'],
            'updated_at'    => date('Y-m-d H:i:s'),
        ]], $log, 'wm_recrawl');

        // Обязательный URL исчерпал попытки → оператору с конкретикой.
        if (RecrawlUrlRepository::hasRequiredFailure($jobId)) {
            $first = $s['required_failed'][0] ?? ['url' => '?', 'last_error' => ''];
            $log->warn('wm_recrawl',
                "Обязательный URL не удалось отправить: {$first['url']} ({$first['last_error']}).");
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user',
                    stage_error=?, next_run_at=NULL
                 WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                mb_substr("wm_recrawl: обязательный URL {$first['url']} не отправлен: {$first['last_error']}", 0, 1000),
                $jobId,
            ]);
            return;
        }

        // Всё обязательное принято → стадия завершена.
        if (RecrawlUrlRepository::isComplete($jobId)) {
            $log->ok('wm_recrawl',
                "✓ Переобход отправлен полностью: accepted={$s['accepted']}, excluded={$s['excluded']} "
                . "(planned={$s['planned']}).");
            // v25.0-b1 (B4): полный успех — отдельный признак в артефактах
            // (recrawl_requested в mapping уже стоит после первого accepted).
            $this->saveArtifacts($jobId, ['wm_recrawl_stage' => [
                'recrawl_completed' => true,
                'completed_at' => date('Y-m-d H:i:s'),
            ]], $log, 'wm_recrawl');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // Ещё есть недосланное → продолжаем на следующих тиках.
        // НО: если работы не осталось, а стадия всё равно не complete (например
        // всё excluded и 0 принятых — Яндексу ничего не отправлено), это тупик,
        // а не «ждём»: уводим оператору, чтобы не крутить pending вечно.
        if (!RecrawlUrlRepository::hasWorkLeft($jobId)) {
            $log->warn('wm_recrawl',
                "Переобход не отправлен ни по одному URL (accepted={$s['accepted']}, "
                . "excluded={$s['excluded']}, planned={$s['planned']}). Требуется вмешательство.");
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET stage_status='awaiting_user', stage_error=?, next_run_at=NULL
                 WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
            )->execute([
                mb_substr("wm_recrawl: не принято ни одного URL (accepted={$s['accepted']}, "
                    . "excluded={$s['excluded']}). Проверьте доступность страниц и верификацию host.", 0, 1000),
                $jobId,
            ]);
            return;
        }

        $interval = $quotaZero
            ? max(300, AppSettings::getInt('recrawl.quota_wait_seconds', 900))
            : (class_exists('DomainReadinessService') ? DomainReadinessService::normalIntervalSec() : 60);
        $log->info('wm_recrawl',
            "Отправка не завершена (accepted={$s['accepted']}/{$s['planned']}, "
            . "pending_quota={$s['pending_quota']}, retry={$s['retry']}). Досылаю на следующих тиках.");
        DB::pdo()->prepare(
            "UPDATE refresh_jobs SET stage_status='pending',
                next_run_at=DATE_ADD(NOW(), INTERVAL ? SECOND)
             WHERE id=? AND stage NOT IN ('done','failed','cancelled','superseded')"
        )->execute([$interval, $jobId]);
    }

    /**
     * v18.1: формирует список URL для recrawl.
     *
     * Стратегия:
     *   1. Пытаемся прочитать config.php через FTP и распарсить $pages
     *      (PhpPagesParser). Для 7k шаблона это даст 7+ URL.
     *   2. Если config.php не достаётся / $pages пуст — возвращаем главную как
     *      fallback (как было до v18.1).
     *
     * @return string[] список абсолютных URL (минимум один: главная)
     */
    private function buildRecrawlUrls(array $job, string $newDomain, JobEventLogger $log): array
    {
        $rootUrl = 'https://' . $newDomain . '/';
        $fallback = [$rootUrl];

        // Загружаем сайт чтобы получить FTP-параметры
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
            $st->execute([(int)$job['site_id']]);
            $site = $st->fetch();
            if (!$site || empty($site['ftp_host']) || empty($site['ftp_user'])
                || empty($site['ftp_pass_enc'])) {
                $log->info('wm_recrawl',
                    'FTP параметры сайта не настроены, отправим только главную');
                return $fallback;
            }
        } catch (\Throwable $e) {
            $log->info('wm_recrawl',
                'Не удалось загрузить сайт для FTP: ' . $e->getMessage());
            return $fallback;
        }

        // Пробуем прочитать config.php через FTP
        $configContent = null;
        try {
            $ftpPass = Crypto::decrypt((string)$site['ftp_pass_enc']);
            $ftp = $this->makeFtp((string)$site['ftp_host'], (string)$site['ftp_user'], $ftpPass);
            $ftp->connect();
            $configContent = $ftp->tryGetContent('config.php');
            $ftp->disconnect();
        } catch (\Throwable $e) {
            $log->info('wm_recrawl',
                'Не удалось прочитать config.php через FTP: ' . $e->getMessage());
        }

        if (!is_string($configContent) || $configContent === '') {
            return $fallback;
        }

        // Парсим $pages
        try {
            $parser = new PhpPagesParser();
            $urls = $parser->getPageUrls($configContent, $newDomain, 'https');
            if (empty($urls)) {
                $log->info('wm_recrawl',
                    '$pages в config.php не найден или пуст — отправим только главную');
                return $fallback;
            }
            $log->info('wm_recrawl',
                "Распарсили \$pages: найдено " . count($urls) . " URL'ов");
            return $urls;
        } catch (\Throwable $e) {
            $log->warn('wm_recrawl',
                'PhpPagesParser failed: ' . $e->getMessage() . ' — отправим только главную');
            return $fallback;
        }
    }

    /**
     * Стадия index_watching — multi-tick polling индексации.
     *
     * Опрашивает Yandex API раз в час, ждём появления URLов в индексе.
     * Лимит 7 дней. После — awaiting_user (но pipeline уже сделал большую часть).
     */
    /**
     * Стадия index_watching v17.1.
     *
     * Adaptive polling (как SSL):
     *   - 0-5 мин:    каждые 30 сек  (ловим быстрый bot Yandex после recrawl)
     *   - 5-15 мин:   каждые 2 мин   (плавный спад нагрузки)
     *   - 15-30 мин:  каждые 5 мин
     *   - 30 мин:     STOP → awaiting_user (по требованию пользователя)
     *
     * Каскад методов проверки (см. IndexCheckOrchestrator):
     *   1. xmlstock (если включён)  — основной
     *   2. webmaster_summary        — fallback
     *   3. webmaster_history        — fallback
     *   4. webmaster_samples        — fallback
     *   5. webmaster_events         — fallback
     */
    private function runIndexWatchingStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $newDomain = trim((string)($job['new_domain'] ?? ''));

        $artifacts = $this->loadArtifacts($job);
        $addedStage = $artifacts['wm_added_stage'] ?? null;
        $watchState = $artifacts['index_watching_stage'] ?? [];

        $accountId = (int)($addedStage['account_id'] ?? 0);
        $userId = (string)($addedStage['user_id'] ?? '');
        $hostId = (string)($addedStage['host_id'] ?? '');

        if ($accountId === 0 || $userId === '' || $hostId === '') {
            $this->setStatusFailed($jobId, 'index_watching: no wm_added artifacts');
            return;
        }

        // === v17.1: time-based adaptive polling ===
        // v18.1.22: ТАЙМАУТ УБРАН.
        // Раньше через 30 минут джоба уходила в awaiting_user — это противоречит
        // идее «панель работает сама без оператора». xmlstock-запрос дешёвый,
        // adaptive backoff (см. computeIndexWatchingDelay) гарантирует что в день
        // мы делаем десятки запросов, а не тысячи. Сайт может появиться в индексе
        // через часы или дни — нет смысла стопать в первый же час.
        //
        // Что осталось — однократное Telegram-уведомление через 30 минут «ещё
        // ждём», чтобы оператор знал что джоба активна, но не требует от него
        // действий. После этого тиши, polling продолжается с разрядкой.
        $startedAt = (int)($watchState['started_at'] ?? 0);
        if ($startedAt === 0) $startedAt = time();
        $tickCount = (int)($watchState['tick_count'] ?? 0) + 1;
        $elapsedSec = time() - $startedAt;

        // v18.1.28: на первом тике стадии — фоновая проверка баланса XMLStock.
        // Если баланс упадёт ниже 100₽ — pipeline получит TG-алерт, потому что
        // полная стадия index_watching может съесть много xmlstock-запросов
        // (adaptive polling: десятки запросов в день).
        if ($tickCount === 1) {
            try {
                $checker = $this->makeBalanceCheckService();
                $br = $checker->checkOne('xmlstock', 'after_index_check', 'default');
                if (!empty($br['ok'])) {
                    $log->info('index_watching',
                        'Баланс XMLStock: ' . number_format((float)$br['balance'], 2) . ' ₽ ' .
                        ($br['status'] === 'low' ? '(НИЖЕ порога — отправлен TG-алерт)' : '(норма)'));
                }
            } catch (\Throwable $e) {
                // silent — не критично, основной cron всё равно проверит
            }
        }

        // Однократный Telegram-аларт через 30 мин «ещё ждём» (не останавливаем).
        $alertThresholdSec = 30 * 60;
        $alertSentAt = (string)($watchState['waiting_alert_sent_at'] ?? '');
        if ($elapsedSec >= $alertThresholdSec && $alertSentAt === '') {
            $log->info('index_watching',
                "Прошло 30 минут — отправляю Telegram-уведомление 'ещё не в индексе, продолжаю ждать'. " .
                "Polling продолжается с разрядкой (30 мин → 1 ч → 6 ч → 24 ч).");
            $this->sendIndexWatchingWaitingAlert($jobId, $job, $newDomain, $watchState, $log);
            // Запишем что отправили — чтобы не дублировать
            $watchState['waiting_alert_sent_at'] = date('Y-m-d H:i:s');
        }

        // === Запускаем cascade проверку ===
        $hostUrl = 'https://' . $newDomain;
        $checker = new IndexCheckOrchestrator();
        $result = $checker->checkIndexed($accountId, $hostUrl, $userId, $hostId, $log,
            (int)$jobId, $siteId !== null ? (int)$siteId : null, 'index_watching');

        // === Сохраняем state ===
        $patch = ['index_watching_stage' => array_merge($watchState, [
            'started_at' => $startedAt,
            'tick_count' => $tickCount,
            'last_check_at' => date('Y-m-d H:i:s'),
            'pages_indexed' => (int)$result['pages_indexed'],
            'primary_method' => (string)$result['primary_method'],
            'methods_tried' => $result['methods_tried'],
            'last_message' => (string)$result['message'],
        ])];
        $this->saveArtifacts($jobId, $patch, $log, 'index_watching');

        $mapping = new SiteWebmasterMappingService();
        $mapping->updateLink($siteId, $newDomain, [
            'indexed' => $result['indexed'] ? 1 : 0,
            'indexed_pages_count' => (int)$result['pages_indexed'],
            'last_index_check_method' => (string)$result['primary_method'],
            'last_index_check_at' => date('Y-m-d H:i:s'),
        ]);

        // === Indexed → переход дальше ===
        if ($result['indexed']) {
            $log->ok('index_watching',
                "✅ Сайт в индексе! pages={$result['pages_indexed']}, " .
                "method={$result['primary_method']}. Переход к redirect_enable.");

            // §6: ban-monitor armed ТОЛЬКО при подтверждении XMLStock (не webmaster fallback).
            if ((string)$result['primary_method'] === 'xmlstock' && (int)$result['pages_indexed'] >= 1) {
                try {
                    (new BanMonitorService())->armFromXmlStockIndexed(
                        (int)$jobId,
                        $siteId !== null ? (int)$siteId : null,
                        (string)$newDomain,
                        new \DateTimeImmutable('now', new \DateTimeZone('UTC')),
                        (int)$result['pages_indexed']
                    );
                } catch (\Throwable $e) {
                    error_log('[ban-monitor arm/index_watching] ' . $e->getMessage());
                }
            }

            // v18: критичное уведомление — юзер хочет видеть это всегда
            try {
                $tg = $this->makeTelegramService();
                $newDomain = (string)$job['new_domain'];
                $oldDomain = (string)$job['old_domain'];
                $pages = (int)$result['pages_indexed'];
                $minutes = round($elapsedSec / 60, 1);
                $tg->notifyImportant($jobId,
                    'Новый домен в индексе Yandex',
                    "Старый: <code>" . htmlspecialchars($oldDomain, ENT_QUOTES, 'UTF-8') . "</code>\n" .
                    "Новый:  <code>" . htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8') . "</code>\n" .
                    "Найдено страниц: <b>{$pages}</b>\n" .
                    "Время до индекса: ~{$minutes} мин\n" .
                    "Метод: {$result['primary_method']}\n\n" .
                    "Pipeline продолжает: " .
                    ($job['mode'] === 'refresh'
                        ? 'включит партнёрский редирект и отправит TG со списком URL для удаления старого из поиска.'
                        : 'добавит 301 в .htaccess и попросит подать заявку на переезд.')
                );
            } catch (\Throwable $e) {}

            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // === Ещё не в индексе — adaptive next tick ===
        $delaySec = $this->computeIndexWatchingDelay($elapsedSec);
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
                 WHERE id = ?"
            )->execute([$delaySec, $jobId]);
        } catch (\Throwable $e) {}

        $delayLabel = $delaySec >= 60 ? round($delaySec / 60) . ' мин' : $delaySec . ' сек';
        $minutes = round($elapsedSec / 60, 1);
        $log->info('index_watching',
            "Tick {$tickCount}: пока не в индексе. Прошло {$minutes}/30 мин. " .
            "Следующая проверка через {$delayLabel}.");
    }

    /**
     * v17.1: adaptive интервалы между тиками index_watching.
     * v18.1.22: расширены за 30 мин — polling больше не останавливается.
     *
     *   0-5 мин:    каждые 30 сек    (быстрая первичная проверка)
     *   5-15 мин:   каждые 2 мин
     *   15-30 мин:  каждые 5 мин
     *   30 мин-6 ч: каждые 30 мин   (24 запроса за 6 часов)
     *   6 ч-3 дня:  каждый час      (~66 запросов за 66 часов)
     *   3-7 дней:   каждые 6 часов  (4 запроса/день)
     *   7+ дней:    каждые 24 часа  (1 запрос/день — на случай если домен
     *                                 индексируется через 2-3 недели)
     *
     * Итого за 7 дней — около 130 запросов к xmlstock. Это копейки даже на
     * самом дешёвом тарифе.
     */
    private function computeIndexWatchingDelay(int $elapsedSec): int
    {
        if ($elapsedSec < 5 * 60)        return 30;          // < 5 мин → 30 сек
        if ($elapsedSec < 15 * 60)       return 2 * 60;      // < 15 мин → 2 мин
        if ($elapsedSec < 30 * 60)       return 5 * 60;      // 15-30 мин → 5 мин
        if ($elapsedSec < 6 * 3600)      return 30 * 60;     // 30 мин - 6 ч → 30 мин
        if ($elapsedSec < 3 * 86400)     return 3600;        // 6 ч - 3 дня → 1 час
        if ($elapsedSec < 7 * 86400)     return 6 * 3600;    // 3-7 дней → 6 часов
        return 24 * 3600;                                     // 7+ дней → раз в сутки
    }

    /**
     * v18.1.6: Telegram alert о таймауте index_watching.
     *
     * Идемпотентный: первый вызов посылает alert и записывает флаг в artifacts.
     * Повторные вызовы (если каким-то образом джоба зациклится) — пропуск.
     *
     * Раньше из-за бага в setStatusAwaitingUser (next_run_at не сбрасывался)
     * cron каждую минуту подхватывал джобу как retry, она снова падала по
     * 30-min timeout и снова слала alert. За ночь пришло 800+ сообщений в TG.
     * Теперь даже если какая-то другая ошибка приведёт к повторному вызову —
     * alert не уйдёт второй раз.
     */
    /**
     * v18.1.22: Telegram-уведомление «ещё ждём индекс» через 30 минут.
     *
     * Это НЕ остановка, не awaiting_user — джоба продолжает polling с разрядкой.
     * Цель — дать оператору знать что джоба активна, ничего делать не надо.
     *
     * Идемпотентный: первый вызов посылает alert и записывает waiting_alert_sent_at
     * в artifacts. Повторные вызовы (на каждом следующем тике после 30 мин) —
     * пропуск, чтобы не спамить.
     */
    private function sendIndexWatchingWaitingAlert(
        int $jobId,
        array $job,
        string $newDomain,
        array $watchState,
        JobEventLogger $log
    ): void {
        // Проверяем флаг — слали ли уже alert?
        try {
            $artifacts = $this->loadArtifacts($job);
            $alertSent = !empty($artifacts['index_watching_stage']['waiting_alert_sent_at']);
            if ($alertSent) {
                $log->info('index_watching',
                    "Telegram waiting alert уже был отправлен ранее ({$artifacts['index_watching_stage']['waiting_alert_sent_at']}) — пропускаем повторный.");
                return;
            }
        } catch (\Throwable $e) {
            // Если artifacts не загружаются — не блокируем alert
        }

        try {
            $tg = $this->makeTelegramService();
            $oldSafe = htmlspecialchars((string)$job['old_domain'], ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
            $jobUrl = $this->buildJobUrl($jobId);
            $tickCount = (int)($watchState['tick_count'] ?? 0) + 1;

            $tg->send(
                "⏳ <b>refresh #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "Стадия: index_watching — прошло 30 минут\n" .
                "Сайт пока НЕ в индексе (после {$tickCount} проверок).\n\n" .
                "<b>Это нормально</b> — индексация может занять часы или дни.\n" .
                "Джоба <b>продолжает мониторинг</b> с разрядкой:\n" .
                "• следующие 6 часов — проверка каждые 30 мин\n" .
                "• до 3 суток — каждый час\n" .
                "• до недели — каждые 6 часов\n" .
                "• потом раз в сутки\n\n" .
                "Действий от тебя <b>не требуется</b>. Когда домен попадёт в индекс — придёт уведомление." .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );

            // Записываем флаг — чтобы повторный вызов не слал alert
            $this->saveArtifacts($jobId,
                ['index_watching_stage' => [
                    'waiting_alert_sent_at' => date('Y-m-d H:i:s'),
                ]],
                $log,
                'index_watching');
        } catch (\Throwable $e) {
            $log->warn('index_watching', 'Telegram alert failed: ' . $e->getMessage());
        }
    }

    /**
     * Стадия wm_old_removed — после успешной индексации удаляем старый домен
     * из его исходного аккаунта.
     *
     * v17.4: удаляем именно тот домен который был НАЙДЕН в Webmaster
     * (matched_domain из cascade), а не тот что в job.old_domain.
     * Если cascade нашёл volna-202.casino вместо запрошенного volna-204.casino —
     * удаляем volna-202.casino (volna-204.casino мог никогда не быть в Webmaster).
     */
    private function runWmOldRemovedStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $oldDomain = (string)$job['old_domain'];

        $artifacts = $this->loadArtifacts($job);
        $resolveStage = $artifacts['wm_account_resolve_stage'] ?? null;

        if ($resolveStage === null) {
            $log->warn('wm_old_removed', 'wm_account_resolve_stage пуст — пропускаю');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // v17.4: matched_domain — что РЕАЛЬНО нашли в Webmaster (может != old_domain если cascade)
        $matchedDomain = (string)($resolveStage['matched_domain'] ?? $oldDomain);
        $cascadeUsed = !empty($resolveStage['cascade_used']);

        $oldAccountId = (int)($resolveStage['old_account_id'] ?? 0);
        $oldUserId = (string)($resolveStage['old_user_id'] ?? '');
        $oldHostId = (string)($resolveStage['old_host_id'] ?? '');

        if ($oldAccountId === 0 || $oldUserId === '' || $oldHostId === '') {
            $log->warn('wm_old_removed',
                'Нет полной информации о старом домене (старый аккаунт/userId/hostId пусты). ' .
                'Пропускаю — старый домен останется в Webmaster.');
            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        try {
            $client = $this->makeWmClient($oldAccountId);
            $this->emitWmRouting($client, $log, (int)$oldAccountId, (int)$jobId, 'wm_old_removed');

            if ($cascadeUsed && $matchedDomain !== $oldDomain) {
                $log->info('wm_old_removed',
                    "Cascade был использован: запрашивали '{$oldDomain}', " .
                    "удаляю РЕАЛЬНО найденный '{$matchedDomain}' (host_id={$oldHostId}) из аккаунта #{$oldAccountId}");
            } else {
                $log->info('wm_old_removed',
                    "Удаляю старый домен '{$matchedDomain}' (host_id={$oldHostId}) из аккаунта #{$oldAccountId}");
            }

            $res = $client->deleteHost($oldUserId, $oldHostId);

            $mapping = new SiteWebmasterMappingService();
            $mapping->markRemoved($siteId, $matchedDomain);

            $patch = ['wm_old_removed_stage' => [
                'ok' => true,
                'old_domain' => $oldDomain,
                'matched_domain' => $matchedDomain,        // v17.4
                'cascade_used' => $cascadeUsed,            // v17.4
                'old_account_id' => $oldAccountId,
                'old_host_id' => $oldHostId,
                'response' => $res,
            ]];
            $this->saveArtifacts($jobId, $patch, $log, 'wm_old_removed');

            $log->ok('wm_old_removed',
                "✓ Старый домен '{$matchedDomain}' удалён из Webmaster аккаунта #{$oldAccountId}");
        } catch (\Throwable $e) {
            // revision §6: routing failure → критический стоп, НЕ warning + stage OK.
            if ($this->stopIfWmRoutingFatal($e, $jobId, $log, (int)$oldAccountId, 'wm_old_removed')) return;
            $log->warn('wm_old_removed',
                "Не удалось удалить старый домен '{$matchedDomain}' (но pipeline идёт дальше): " . $e->getMessage());
            $this->saveArtifacts($jobId,
                ['wm_old_removed_stage' => [
                    'ok' => false,
                    'matched_domain' => $matchedDomain,
                    'error' => $e->getMessage(),
                ]],
                $log, 'wm_old_removed');
        }

        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    // ========================================================================
    // ============================ v18 МЕТОДЫ ================================
    // ========================================================================

    /**
     * v18 (move_indexed/move_simple): добавляет 301-редирект-блок в .htaccess
     * сайта со старого домена на новый.
     *
     * Использует HtaccessRedirectAppender, который:
     *   - проверяет идемпотентность (не дублирует блок если уже есть)
     *   - делает snapshot оригинального .htaccess
     *   - заливает изменения через FTP
     *
     * После записи verify-фаза: GET https://{old_domain}/ ожидает HTTP 301 +
     * Location, указывающий на новый домен.
     */
    private function runMoveHtaccessRedirectStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $siteId = (int)$job['site_id'];
        $oldDomain = trim((string)$job['old_domain']);
        $newDomain = trim((string)$job['new_domain']);

        if ($oldDomain === '' || $newDomain === '') {
            $log->error('move_htaccess_redirect',
                "old_domain/new_domain пуст: '{$oldDomain}' / '{$newDomain}'");
            $this->setStatusFailed($jobId, 'move_htaccess_redirect: old/new domain пуст');
            return;
        }

        // Загружаем сайт для FTP credentials
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id=?");
            $st->execute([$siteId]);
            $site = $st->fetch();
            if (!$site) {
                $this->setStatusFailed($jobId, 'move_htaccess_redirect: site not found');
                return;
            }
        } catch (\Throwable $e) {
            $this->setStatusFailed($jobId, 'move_htaccess_redirect: db: ' . $e->getMessage());
            return;
        }

        if (empty($site['ftp_user']) || empty($site['ftp_pass_enc']) || empty($site['ftp_host'])) {
            $log->error('move_htaccess_redirect',
                'Не настроен FTP для сайта — нечем редактировать .htaccess');
            $this->setStatusAwaitingUser($jobId, 'move_htaccess_redirect: FTP не настроен');
            return;
        }

        // Готовим FTP и appender
        $ftpPass = '';
        try {
            $ftpPass = Crypto::decrypt((string)$site['ftp_pass_enc']);
        } catch (\Throwable $e) {
            $this->setStatusFailed($jobId, 'move_htaccess_redirect: ftp_pass_enc: ' . $e->getMessage());
            return;
        }

        $ftp = $this->makeFtp(
            (string)$site['ftp_host'],
            (string)$site['ftp_user'],
            $ftpPass,
            ['passive' => true, 'timeout' => 30]
        );

        $snapshotDir = Paths::storage('snapshots') . '/job_' . $jobId;
        $appender = new HtaccessRedirectAppender($ftp, $snapshotDir);

        try {
            $log->info('move_htaccess_redirect',
                "Добавляю 301 в .htaccess: {$oldDomain} → {$newDomain}");

            $ftp->connect();
            try {
                $appendResult = $appender->appendRedirect($oldDomain, $newDomain, $jobId);
            } finally {
                $ftp->disconnect();
            }
        } catch (\Throwable $e) {
            $log->error('move_htaccess_redirect', 'FTP ошибка: ' . $e->getMessage());
            $this->setStatusFailed($jobId, 'move_htaccess_redirect: ftp: ' . $e->getMessage());
            return;
        }

        if (!$appendResult['ok']) {
            $log->error('move_htaccess_redirect',
                'Не удалось добавить блок: ' . ($appendResult['error'] ?? 'unknown'));
            $this->saveArtifacts($jobId,
                ['move_htaccess_redirect_stage' => $appendResult],
                $log, 'move_htaccess_redirect');
            $this->setStatusFailed($jobId,
                'move_htaccess_redirect: ' . ($appendResult['error'] ?? 'append failed'));
            return;
        }

        if ($appendResult['was_present_before']) {
            $log->info('move_htaccess_redirect',
                "Блок уже был в .htaccess (idempotent skip), bytes={$appendResult['bytes_before']}");
        } else {
            $log->info('move_htaccess_redirect',
                "Блок добавлен. Bytes: {$appendResult['bytes_before']} → {$appendResult['bytes_after']}");
        }

        // === Verify: проверяем что HTTP запрос на старый домен теперь редиректит на новый ===
        $verify = $this->verifyHtaccessRedirect($oldDomain, $newDomain);
        $appendResult['verify'] = $verify;

        $this->saveArtifacts($jobId,
            ['move_htaccess_redirect_stage' => $appendResult],
            $log, 'move_htaccess_redirect');

        if (!$verify['ok']) {
            $log->warn('move_htaccess_redirect',
                "Verify провалился: HTTP {$verify['http_code']}, location='{$verify['location']}'. " .
                "Блок добавлен, но 301 не работает. Возможно проблема с .htaccess (другие правила, AllowOverride). " .
                "Pipeline остановлен — нужно проверить руками.");
            $this->setStatusAwaitingUser($jobId,
                "move_htaccess_redirect verify: HTTP {$verify['http_code']}, location={$verify['location']}");
            return;
        }

        $log->ok('move_htaccess_redirect',
            "✓ 301 редирект работает: https://{$oldDomain}/ → {$verify['location']}");
        $this->setStatus($jobId, 'ok', 'stage_finished_at');
    }

    /**
     * Проверяет что GET https://{old_domain}/ возвращает 301 на нужный новый домен.
     *
     * Не следует за редиректом — нам нужен именно код 301 и заголовок Location.
     */
    private function verifyHtaccessRedirect(string $oldDomain, string $newDomain): array
    {
        $url = "https://{$oldDomain}/";
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_NOBODY => true,
            CURLOPT_HEADER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            // v18.1.10: yandex UA — см. комментарий выше про 1win шаблоны
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) refresh-panel-htaccess-verify',
        ]);
        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        $location = '';
        if (is_string($resp) && $resp !== '') {
            if (preg_match('~^Location:\s*(\S+)~mi', $resp, $m)) {
                $location = trim($m[1]);
            }
        }

        $expectedHostMatch = false;
        if ($location !== '') {
            $parsed = parse_url($location);
            $host = strtolower((string)($parsed['host'] ?? ''));
            $host = preg_replace('~^www\.~', '', $host);
            $expectedHostMatch = ($host === strtolower(preg_replace('~^www\.~', '', $newDomain)));
        }

        return [
            'ok' => ($code === 301 || $code === 302) && $expectedHostMatch,
            'http_code' => $code,
            'location' => $location,
            'curl_error' => $err !== '' ? $err : null,
            'expected_host_match' => $expectedHostMatch,
        ];
    }

    /**
     * v18 (move_indexed/move_simple): ставит джобу в awaiting_user и шлёт TG
     * с инструкцией оператору — самому подать заявку на переезд через
     * веб-интерфейс Webmaster (api для этой операции у Yandex'а нет).
     *
     * При повторном заходе (после нажатия "✓ Я отправил" в UI) стадия НЕ
     * вызывается — контроллер сам ставит stage_status='ok' и pipeline
     * продолжается на move_poll_status.
     *
     * Поэтому здесь только инициализация + awaiting_user + TG.
     */
    private function runMoveSubmitRequestStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $newDomain = (string)$job['new_domain'];
        $oldDomain = (string)$job['old_domain'];

        $artifacts = $this->loadArtifacts($job);
        $resolveStage = $artifacts['wm_account_resolve_stage'] ?? null;

        // Из wm_account_resolve берём host_id и email аккаунта (для прямой ссылки в TG/UI)
        $newAccountId = (int)($resolveStage['new_account_id'] ?? 0);
        $newHostId = (string)($resolveStage['new_host_id'] ?? '');
        $newAccountEmail = '';

        if ($newAccountId > 0) {
            try {
                $st = DB::pdo()->prepare(
                    "SELECT email, label FROM yandex_webmaster_accounts WHERE id = ?"
                );
                $st->execute([$newAccountId]);
                $row = $st->fetch();
                if ($row) {
                    $newAccountEmail = (string)($row['email'] ?? '');
                }
            } catch (\Throwable $e) {}
        }

        // Прямая ссылка на инструмент "Переезд сайта" в Webmaster
        // Если host_id у нас в формате "https:domain.com:443" — оно работает в URL
        $webmasterMirrorsUrl = $newHostId !== ''
            ? 'https://webmaster.yandex.ru/site/' . rawurlencode($newHostId) . '/indexing/mirrors/'
            : 'https://webmaster.yandex.ru/sites/';

        $awaitingSince = date('Y-m-d H:i:s');

        $patch = ['move_submit_request_stage' => [
            'awaiting_since' => $awaitingSince,
            'new_account_id' => $newAccountId,
            'new_account_email' => $newAccountEmail,
            'new_host_id' => $newHostId,
            'webmaster_mirrors_url' => $webmasterMirrorsUrl,
            'old_domain' => $oldDomain,
            'new_domain' => $newDomain,
            'ack_at' => null,
        ]];
        $this->saveArtifacts($jobId, $patch, $log, 'move_submit_request');

        $log->info('move_submit_request',
            "Ожидаю ручного действия: оператор подаёт заявку на переезд в Webmaster. " .
            "URL: {$webmasterMirrorsUrl}");

        // Telegram-уведомление
        try {
            $tg = $this->makeTelegramService();
            $oldSafe = htmlspecialchars($oldDomain, ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
            $emailSafe = htmlspecialchars($newAccountEmail !== '' ? $newAccountEmail : '— не определён —',
                ENT_QUOTES, 'UTF-8');
            $jobUrl = $this->buildJobUrl($jobId);

            $tg->send(
                "🚚 <b>move #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "Стадия: move_submit_request (awaiting_user)\n\n" .
                "Подай заявку на переезд через Webmaster:\n" .
                "1. Войди под аккаунтом: <code>{$emailSafe}</code>\n" .
                "2. Открой инструмент «Переезд сайта»: <a href=\"{$webmasterMirrorsUrl}\">тык</a>\n" .
                "3. Введи новый адрес: <code>https://{$newSafe}</code>\n" .
                "4. Нажми «Сохранить»\n" .
                "5. Вернись в Refresh Panel и нажми «✅ Я подал заявку»\n\n" .
                "Заявка обрабатывается ~30-40 минут. После твоего подтверждения " .
                "система начнёт мониторить статус автоматически." .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('move_submit_request', 'Telegram alert failed: ' . $e->getMessage());
        }

        $this->setStatusAwaitingUser($jobId,
            'move_submit_request: жду ручной подачи заявки в Webmaster');
    }

    /**
     * v18 (move_indexed/move_simple): multi-tick polling статуса переезда.
     *
     * Каждый тик: GET /v4/user/{uid}/hosts → ищем старый домен → проверяем что
     * у него main_mirror.host_id указывает на новый домен.
     *
     * v18.1.10: polling БЕЗ timeout'а. Крутимся пока Yandex не вернёт финальный
     * статус. Yandex обрабатывает заявки от часов до 30+ дней — timeout создавал
     * риск пропустить успешное завершение.
     *
     * Adaptive intervals:
     *   0-1ч:    каждые 5 мин   (заявка обычно обрабатывается за 30-40 мин)
     *   1-6ч:    каждые 30 мин
     *   6-24ч:   каждый 1 час
     *   >1д:     каждые 4 часа  (минимальная нагрузка на API)
     *
     * TG-уведомления отправляются при ЛЮБОМ изменении статуса (in_progress →
     * другой статус), не только при success. См. блок `if ($prevStatus !== ...)`.
     */

    /**
     * v18.1.17: helper для случая когда move_poll_status НЕ может проверить статус
     * (нет webmaster аккаунта старого/нового домена).
     *
     * Вместо setStatusFailed (тупик) — ставим awaiting_user + TG. Оператор может:
     *  1) Завершить джобу вручную (markMoveDone в контроллере) — переезд считается done
     *  2) Указать webmaster аккаунт через override и Повторить
     *  3) Откатить snapshot если переезд не нужен
     */
    private function moveAwaitingUserNoAccount(array $job, JobEventLogger $log, string $reason): void
    {
        $jobId = (int)$job['id'];

        // Сохраним отдельный флаг в артефактах чтобы UI показал кнопку "Завершить"
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode([
                    'move_poll_status_stage' => [
                        'awaiting_no_account' => true,
                        'awaiting_reason' => $reason,
                    ]
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn('move_poll_status', 'Не сохранил awaiting_no_account flag: ' . $e->getMessage());
        }

        // TG-уведомление
        try {
            $tg = $this->makeTelegramService();
            $oldSafe = htmlspecialchars((string)$job['old_domain'], ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars((string)$job['new_domain'], ENT_QUOTES, 'UTF-8');
            $jobUrl = $this->buildJobUrl($jobId);
            $tg->send(
                "⚠️ <b>move #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "Стадия: move_poll_status (awaiting_user)\n\n" .
                "❌ Не могу автоматически проверить статус переезда: " .
                htmlspecialchars($reason, ENT_QUOTES, 'UTF-8') . "\n\n" .
                "Возможные действия в UI джобы:\n" .
                "• <b>Завершить джобу</b> — если переезд уже сделан вне панели или не нужен\n" .
                "• <b>Webmaster override</b> в настройках сайта + Повторить\n" .
                "• <b>Откатить snapshot</b> — если хочешь отменить переезд" .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('move_poll_status', 'Telegram alert failed: ' . $e->getMessage());
        }

        $this->setStatusAwaitingUser($jobId,
            'move_poll_status: ' . $reason . '. ' .
            'Используй "Завершить джобу" если переезд уже сделан, или укажи Webmaster override и Повтори.');
    }

    private function runMovePollStatusStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $oldDomain = (string)$job['old_domain'];
        $newDomain = (string)$job['new_domain'];

        $artifacts = $this->loadArtifacts($job);
        $resolveStage = $artifacts['wm_account_resolve_stage'] ?? null;
        $pollState = $artifacts['move_poll_status_stage'] ?? [
            'started_at' => date('Y-m-d H:i:s'),
            'tick_count' => 0,
            'last_status' => null,
            'last_check_at' => null,
        ];

        if ($resolveStage === null) {
            // v18.1.17: вместо setStatusFailed — awaiting_user, дать оператору
            // возможность завершить вручную или повторить.
            $log->error('move_poll_status',
                'wm_account_resolve_stage отсутствует в artifacts. ' .
                'Вероятно стадия wm_account_resolve была пропущена или упала. ' .
                'Без аккаунта Webmaster невозможно проверить статус переезда автоматически.');
            $this->moveAwaitingUserNoAccount($job, $log,
                'wm_account_resolve_stage отсутствует в артефактах');
            return;
        }

        $oldAccountId = (int)($resolveStage['old_account_id'] ?? 0);
        $oldUserId = (string)($resolveStage['old_user_id'] ?? '');

        // Fallback если старый домен не был найден в Webmaster
        // (override-сценарий: новый аккаунт = старый аккаунт)
        if ($oldAccountId === 0 || $oldUserId === '') {
            $oldAccountId = (int)($resolveStage['new_account_id'] ?? 0);
            $oldUserId = (string)($resolveStage['new_user_id'] ?? '');
        }

        if ($oldAccountId === 0 || $oldUserId === '') {
            // v18.1.17: вместо setStatusFailed — awaiting_user, дать оператору
            // возможность завершить вручную или указать webmaster аккаунт.
            $log->error('move_poll_status',
                'Не удалось определить Webmaster-аккаунт для проверки статуса переезда. ' .
                'Старый домен (' . $oldDomain . ') не найден в подключённых Webmaster-аккаунтах. ' .
                'Возможные действия: (1) указать аккаунт вручную через "webmaster override" в сайте, ' .
                '(2) завершить джобу вручную если переезд уже сделан вне нашей панели, ' .
                '(3) повторить если аккаунт только что подключён.');
            $this->moveAwaitingUserNoAccount($job, $log,
                'старый домен ' . $oldDomain . ' не найден в Webmaster-аккаунтах');
            return;
        }

        $checker = new MoveStatusChecker();
        if (method_exists($checker, 'setJobContext')) $checker->setJobContext($jobId, 'move_poll_status', $log);
        $check = $checker->checkMoveStatus($oldAccountId, $oldUserId, $oldDomain, $newDomain);

        // revision 2 §13/§18: critical routing failure — критический стоп, НЕ обычный api_error retry.
        if (($check['status'] ?? '') === 'routing_error') {
            $this->applyWmRoutingCriticalStop($jobId, $log, 'move_poll_status', (int)$oldAccountId,
                (string)($check['routing_reason'] ?? 'source_ip_mismatch'), (string)($check['reason'] ?? ''));
            return;
        }

        // v18.1.10: детектор изменения статуса. Шлём TG только когда статус
        // ИЗМЕНИЛСЯ с предыдущего тика — это значит у Yandex что-то поменялось
        // в обработке заявки. Без этой проверки TG бы спамил каждый тик
        // (особенно при `in_progress` — каждые 5 мин в начале и каждые 4 часа потом).
        //
        // Алгоритм:
        //   - читаем prev_status из artifacts (предыдущий тик)
        //   - сравниваем с текущим check[status]
        //   - если разные → TG-уведомление + сохранение нового статуса
        //   - сам статус сохраняется в last_status дальше по коду
        //
        // Особые случаи:
        //   - первый тик (prev_status === null) → шлём TG только если статус НЕ in_progress
        //     (in_progress — "норма", его нет смысла анонсировать как изменение)
        //   - api_error → НЕ считаем изменением (это временный сбой, не статус Yandex)
        $prevStatus = $pollState['last_status'] ?? null;
        $statusChanged = ($prevStatus !== $check['status'])
                      && ($check['status'] !== 'api_error');
        $isFirstTick = ($prevStatus === null);
        $shouldNotify = $statusChanged
                      && !($isFirstTick && $check['status'] === 'in_progress');

        if ($shouldNotify) {
            try {
                $tg = $this->makeTelegramService();
                $oldSafe = htmlspecialchars($oldDomain, ENT_QUOTES, 'UTF-8');
                $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
                $jobUrl = $this->buildJobUrl($jobId);

                // Подбираем иконку и текст под конкретный статус
                $icon = '🔄';
                $headline = "Статус заявки изменился: {$check['status']}";
                switch ($check['status']) {
                    case 'success':
                        $icon = '✅';
                        $headline = "Переезд УСПЕШНО завершён.\n" .
                                    "main_mirror старого домена = {$newSafe}.";
                        break;
                    case 'in_progress':
                        $icon = '⏳';
                        $headline = "Заявка обнаружена в Webmaster, статус: в обработке.\n" .
                                    "Polling продолжается, следующая проверка через несколько мин.";
                        break;
                    case 'wrong_mirror':
                        $icon = '⚠️';
                        $headline = "Yandex склеил со ВТОРЫМ зеркалом ({$check['old_host_main_mirror']}), " .
                                    "а не с нашим новым доменом. Pipeline остановлен.";
                        break;
                    case 'old_not_found':
                        $icon = '⚠️';
                        $headline = "Старый домен {$oldSafe} ИСЧЕЗ из Webmaster аккаунта. " .
                                    "Возможно удалён руками или истекла верификация. Pipeline остановлен.";
                        break;
                    case 'new_not_found':
                        $icon = '⚠️';
                        $headline = "Новый домен {$newSafe} НЕ найден в Webmaster аккаунте. " .
                                    "Pipeline остановлен.";
                        break;
                    default:
                        $headline = "Статус заявки изменился: {$prevStatus} → {$check['status']}.\n" .
                                    "Причина: {$check['reason']}";
                }

                $prevStatusLabel = $prevStatus === null ? '(первый тик)' : $prevStatus;
                $tg->send(
                    "{$icon} <b>move #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                    "Статус: <b>{$prevStatusLabel} → {$check['status']}</b>\n\n" .
                    $headline .
                    ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
                );
            } catch (\Throwable $e) {
                $log->warn('move_poll_status', 'Telegram alert failed: ' . $e->getMessage());
            }
        }

        $pollState['tick_count'] = (int)($pollState['tick_count'] ?? 0) + 1;
        $pollState['last_check_at'] = date('Y-m-d H:i:s');
        $pollState['last_status'] = $check['status'];
        $pollState['last_main_mirror'] = $check['old_host_main_mirror'];
        $pollState['last_reason'] = $check['reason'];

        $tickCount = $pollState['tick_count'];

        if ($check['status'] === 'success') {
            $pollState['success_at'] = date('Y-m-d H:i:s');
            $this->saveArtifacts($jobId,
                ['move_poll_status_stage' => $pollState],
                $log, 'move_poll_status');

            $log->ok('move_poll_status',
                "✅ Переезд успешен (tick #{$tickCount}): main_mirror у {$oldDomain} = {$newDomain}");

            // TG уже отправлен выше в блоке shouldNotify

            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        if ($check['status'] === 'wrong_mirror') {
            // Yandex склеил со ВТОРЫМ зеркалом, а не с нашим — это плохой знак
            $this->saveArtifacts($jobId,
                ['move_poll_status_stage' => $pollState],
                $log, 'move_poll_status');
            $log->warn('move_poll_status',
                "main_mirror = {$check['old_host_main_mirror']}, ожидали {$newDomain}. Pipeline остановлен.");
            $this->setStatusAwaitingUser($jobId,
                "move_poll_status: main_mirror указывает не на наш новый домен ({$check['old_host_main_mirror']})");
            return;
        }

        if ($check['status'] === 'old_not_found') {
            $this->saveArtifacts($jobId,
                ['move_poll_status_stage' => $pollState],
                $log, 'move_poll_status');
            $log->warn('move_poll_status',
                "Старый домен {$oldDomain} не найден в аккаунте — кто-то удалил руками или истекла верификация. " .
                "Pipeline остановлен.");
            $this->setStatusAwaitingUser($jobId,
                "move_poll_status: старый домен исчез из Webmaster");
            return;
        }

        if ($check['status'] === 'api_error') {
            // Не критично — попробуем на следующем тике. Но если уже много раз подряд — failed.
            $consecErrors = (int)($pollState['consecutive_api_errors'] ?? 0) + 1;
            $pollState['consecutive_api_errors'] = $consecErrors;
            $this->saveArtifacts($jobId,
                ['move_poll_status_stage' => $pollState],
                $log, 'move_poll_status');

            if ($consecErrors >= 5) {
                $log->error('move_poll_status',
                    "5 подряд API errors: {$check['reason']}. Pipeline остановлен.");
                $this->setStatusAwaitingUser($jobId,
                    'move_poll_status: 5 API errors подряд: ' . $check['reason']);
                return;
            }

            $log->warn('move_poll_status',
                "API error #{$consecErrors}: {$check['reason']}. Повторю через 10 мин.");

            // Сразу retry через 10 мин
            try {
                DB::pdo()->prepare(
                    "UPDATE refresh_jobs SET
                        stage_status = 'pending',
                        next_run_at = DATE_ADD(NOW(), INTERVAL 600 SECOND)
                     WHERE id = ?"
                )->execute([$jobId]);
            } catch (\Throwable $e) {}
            return;
        }

        // status === 'in_progress' — заявка ещё обрабатывается
        $pollState['consecutive_api_errors'] = 0; // сбрасываем счётчик ошибок

        // === Adaptive next tick ===
        $startedAt = strtotime((string)($pollState['started_at'] ?? 'now'));
        $elapsedSec = max(0, time() - $startedAt);

        // v18.1.10: polling работает БЕЗ timeout'а — крутимся пока Yandex не вернёт
        // финальный статус (success / wrong_mirror / old_not_found / new_not_found).
        // Раньше был 15-часовой timeout, потом 7-дневный — оба ушли.
        // Логика: заявки на склейку зеркал у Yandex могут обрабатываться от часов
        // до 30+ дней. Если timeout'нем — оператор не получит TG и не узнает что
        // переезд завершился. Лучше polling крутить бесконечно (раз в 4 часа после
        // первых суток это копеечная нагрузка) и слать TG при изменении статуса.
        //
        // Защита от бесконечного цикла: success/wrong_mirror/old_not_found/new_not_found
        // выше уже сделали setStatus(ok) или setStatusAwaitingUser — больше cron не подхватит.
        // А `in_progress` статус — для него мы здесь, и просто ставим next_run_at.

        $delaySec = $this->computeMovePollDelay($elapsedSec);

        $this->saveArtifacts($jobId,
            ['move_poll_status_stage' => $pollState],
            $log, 'move_poll_status');

        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
                 WHERE id = ?"
            )->execute([$delaySec, $jobId]);
        } catch (\Throwable $e) {}

        $minutes = round($elapsedSec / 60, 1);
        $delayLabel = $delaySec >= 60 ? round($delaySec / 60) . ' мин' : $delaySec . ' сек';
        $log->info('move_poll_status',
            "Tick {$tickCount}: {$check['reason']}. Прошло {$minutes} мин. " .
            "Следующая проверка через {$delayLabel}.");
    }

    /**
     * Adaptive интервалы между тиками move_poll_status.
     *
     * v18-fix: упрощено по запросу оператора:
     * v18.1.10: интервалы расширены для 7-дневного polling.
     *   0-60 мин (первый час):   каждые 5 мин   = 12 тиков
     *   1ч - 6ч:                  каждые 30 мин = 10 тиков
     *   6ч - 24ч:                 каждый 1 час  = 18 тиков
     *   1д - 7д:                  каждые 4 часа = ~36 тиков
     *
     * Логика: первый час Yandex обычно либо обрабатывает заявку, либо нет.
     * Если за час не появился main_mirror — дальше ждём терпеливо.
     * После первого дня заявка либо одобрена, либо в очереди (обычно 1-3 дня).
     * Чем дольше — тем реже тики, чтобы не нагружать API.
     *
     * Итого за 7 дней polling'а будет ~76 тиков.
     */
    private function computeMovePollDelay(int $elapsedSec): int
    {
        if ($elapsedSec < 60 * 60)      return 5 * 60;       // 0-1ч:  каждые 5 мин
        if ($elapsedSec < 6 * 3600)     return 30 * 60;      // 1-6ч:  каждые 30 мин
        if ($elapsedSec < 24 * 3600)    return 60 * 60;      // 6-24ч: каждый 1 час
        return 4 * 60 * 60;                                   // >1д:    каждые 4 часа
    }

    /**
     * v18.1.23: ФИНАЛЬНЫЙ МОНИТОРИНГ — объединение index_watching + move_poll_status.
     *
     * Зачем объединили: для move-режимов раньше шли последовательно:
     *   index_watching → move_submit_request → move_poll_status
     * Это растягивало pipeline на часы. На практике:
     *   - появление нового домена в индексе — само по себе сигнал что переезд
     *     состоялся (Яндекс начал отдавать новый домен в выдаче)
     *   - main_mirror в Webmaster может обновиться раньше индекса или позже —
     *     порядок не детерминирован
     * Поэтому делаем обе проверки на каждом тике и завершаем при ЛЮБОМ из условий.
     *
     * Что проверяется:
     *   1. pages_indexed >= 1 для нового домена через IndexCheckOrchestrator
     *      (xmlstock как основной, Webmaster API как fallback)
     *   2. main_mirror(oldDomain) == newDomain через MoveStatusChecker
     *      (Yandex Webmaster API)
     *
     * Что завершает джобу:
     *   - индекс ✓ ИЛИ переезд (success) — markJobDone, TG-уведомление
     *   - переезд (wrong_mirror/old_not_found/new_not_found) — awaiting_user
     *     (это негативные финальные статусы, оператор должен решить)
     *   - api_error 5 раз подряд → awaiting_user (как было в move_poll_status)
     *
     * Adaptive backoff — использует computeIndexWatchingDelay (30 сек → 1 ч → ... → 24 ч),
     * polling бесконечный без таймаута. Через 30 мин — однократный TG "ждём".
     */
    private function runFinalMonitoringStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $newDomain = (string)$job['new_domain'];
        $oldDomain = (string)$job['old_domain'];

        $artifacts = $this->loadArtifacts($job);
        $watchState = $artifacts['final_monitoring_stage'] ?? [];

        // Резолв webmaster аккаунта (тот же что для index_watching/move_poll)
        $addedStage = $artifacts['wm_added_stage'] ?? null;
        $resolveStage = $artifacts['wm_account_resolve_stage'] ?? null;

        if ($addedStage === null) {
            $log->error('final_monitoring', 'wm_added_stage отсутствует — нет данных для проверки индексации');
            $this->setStatusAwaitingUser($jobId,
                'final_monitoring: wm_added_stage пуст. Pipeline вышел не туда.');
            return;
        }

        $accountId = (int)($addedStage['account_id'] ?? 0);
        $userId    = (string)($addedStage['user_id'] ?? '');
        $hostId    = (string)($addedStage['host_id'] ?? '');

        // Для move-проверки берём аккаунт СТАРОГО домена (где он был найден в wm_account_resolve)
        $oldAccountId = (int)($resolveStage['old_account_id'] ?? 0);
        $oldUserId    = (string)($resolveStage['old_user_id'] ?? '');
        // Fallback: если старый не нашёлся в Webmaster (override-сценарий),
        // используем new-аккаунт (это и есть тот же где новый домен)
        if ($oldAccountId === 0 || $oldUserId === '') {
            $oldAccountId = (int)($resolveStage['new_account_id'] ?? $accountId);
            $oldUserId    = (string)($resolveStage['new_user_id'] ?? $userId);
        }

        // Init state на первом тике
        $startedAt = (int)($watchState['started_at_unix'] ?? 0);
        if ($startedAt === 0) {
            $startedAt = time();
            $watchState['started_at_unix'] = $startedAt;
            $watchState['started_at'] = date('Y-m-d H:i:s');
        }
        $tickCount = (int)($watchState['tick_count'] ?? 0) + 1;
        $watchState['tick_count'] = $tickCount;
        $elapsedSec = time() - $startedAt;
        $watchState['last_check_at'] = date('Y-m-d H:i:s');

        // === Однократный TG-аларт через 30 мин «ещё ждём» ===
        $alertThresholdSec = 30 * 60;
        $alertSentAt = (string)($watchState['waiting_alert_sent_at'] ?? '');
        if ($elapsedSec >= $alertThresholdSec && $alertSentAt === '') {
            $log->info('final_monitoring',
                "Прошло 30 минут — отправляю Telegram-уведомление 'ещё ждём' (не останавливаемся).");
            $this->sendFinalMonitoringWaitingAlert($jobId, $job, $newDomain, $watchState, $log);
            $watchState['waiting_alert_sent_at'] = date('Y-m-d H:i:s');
        }

        // === Проверка 1: индексация ===
        // v22.2: для move-режимов берём ОБЩИЙ доменный лок — тот же, что используют
        // ручная проверка и cron раздела «Переезды». Без него pipeline и оператор
        // могли отправить два платных XMLStock-запроса одновременно: проверка
        // «активен ли pipeline» сама по себе гонку не закрывает (состояние могло
        // измениться между проверкой и запросом).
        $isMoveModeIdx = in_array((string)($job['mode'] ?? ''), ['move_indexed', 'move_simple'], true);
        $idxLockTaken = false;
        if ($isMoveModeIdx && class_exists('RelocationIndexChecker')) {
            $idxLockTaken = RelocationIndexChecker::acquireLock($newDomain, 5);
            if (!$idxLockTaken) {
                $log->info('final_monitoring',
                    'Проверка индекса пропущена на этом тике: домен уже проверяет другой процесс '
                    . '(ручная проверка или cron раздела «Переезды»). Подтверждение переезда проверяем как обычно.');
            }
        }

        $indexCheck = ['ok' => false, 'pages_indexed' => 0, 'message' => 'не проверено'];
        $indexCheckSkipped = ($isMoveModeIdx && !$idxLockTaken);

        // v22.3: ПОСЛЕ захвата лока перечитываем состояние. Пока мы ждали лок,
        // ручная или фоновая проверка могла завершиться и зафиксировать индекс —
        // без этой проверки pipeline отправил бы второй платный запрос.
        // Здесь же проверяется баланс XMLStock: раньше остановка по низкому
        // балансу работала только для manual/cron, а pipeline продолжал тратить.
        if ($isMoveModeIdx && $idxLockTaken) {
            $gate = RelocationIndexChecker::pipelineIndexGate($jobId, $newDomain);
            if (empty($gate['proceed'])) {
                $indexCheckSkipped = true;
                $log->info('final_monitoring',
                    'Проверка индекса пропущена: ' . $gate['message']
                    . '. Подтверждение главного зеркала проверяем как обычно.');
            }
        }

        if (!$indexCheckSkipped) {
            try {
                $hostUrl = 'https://' . $newDomain;
                $checker = new IndexCheckOrchestrator();
                $indexCheck = $checker->checkIndexed($accountId, $hostUrl, $userId, $hostId, $log);
            } catch (\Throwable $e) {
                $log->warn('final_monitoring', 'Проверка индексации упала: ' . $e->getMessage());
                $indexCheck = ['ok' => false, 'pages_indexed' => 0, 'message' => 'check error: ' . $e->getMessage()];
            }
        }

        if ($idxLockTaken) {
            RelocationIndexChecker::releaseLock($newDomain);
        }
        // v22.3: при пропуске проверки НЕ затираем прежние значения фиктивными
        // нулями — иначе артефакт выглядел бы как «проверили и ничего не нашли».
        if (!$indexCheckSkipped) {
            $watchState['last_pages_indexed'] = (int)$indexCheck['pages_indexed'];
            $watchState['last_index_method']  = (string)($indexCheck['primary_method'] ?? '');
            $watchState['last_index_message'] = (string)$indexCheck['message'];
        } else {
            $watchState['last_index_skipped_at'] = date('Y-m-d H:i:s');
        }

        // v22: передаём УЖЕ полученный результат в раздел «Переезды».
        // Дополнительный запрос к XMLStock не выполняется — это была бы двойная
        // трата платного лимита. Внутри применяется строгое правило источника:
        // first_indexed_at пишется только при primary_method='xmlstock'.
        if ($isMoveModeIdx && !$indexCheckSkipped) {
            RelocationIndexChecker::applyPipelineResult($jobId, $indexCheck);
        }

        // === Проверка 2: статус переезда (Webmaster main_mirror) ===
        $moveCheck = ['status' => 'api_error', 'reason' => 'не проверено'];
        try {
            $moveChecker = new MoveStatusChecker();
            if (method_exists($moveChecker, 'setJobContext')) $moveChecker->setJobContext($jobId, 'final_monitoring', $log);
            $moveCheck = $moveChecker->checkMoveStatus($oldAccountId, $oldUserId, $oldDomain, $newDomain);
        } catch (\Throwable $e) {
            $log->warn('final_monitoring', 'Проверка статуса переезда упала: ' . $e->getMessage());
            $moveCheck = ['status' => 'api_error', 'reason' => 'check error: ' . $e->getMessage()];
        }
        // revision 2 §13/§18: routing failure на финальном мониторинге → критический стоп.
        if (($moveCheck['status'] ?? '') === 'routing_error') {
            $this->applyWmRoutingCriticalStop($jobId, $log, 'final_monitoring', (int)$oldAccountId,
                (string)($moveCheck['routing_reason'] ?? 'source_ip_mismatch'), (string)($moveCheck['reason'] ?? ''));
            return;
        }
        $prevMoveStatus = $watchState['last_move_status'] ?? null;
        $watchState['last_move_status'] = (string)$moveCheck['status'];
        $watchState['last_move_reason'] = (string)$moveCheck['reason'];

        // === Решение ===
        // v18.1.28: ВАЖНОЕ ИСПРАВЛЕНИЕ.
        // Раньше: `$indexed || $moveSuccess` — любой из двух сигналов считался success.
        // Проблема: в move_indexed режиме новый домен УЖЕ в индексе на момент начала
        // final_monitoring (потому что pipeline загрузил sitemap/recrawl/wm_robots →
        // Yandex проиндексировал новый домен). Это давало мгновенный false-success
        // НЕ дожидаясь подтверждения переезда от Webmaster (main_mirror).
        //
        // Правильно: в move-режимах ждём ИМЕННО Webmaster подтверждение переезда
        // (main_mirror старого = новый). Индексация — только дополнительный сигнал
        // прогресса, в success-критерий не входит.
        //
        // Для legacy ситуаций (refresh-джоба застряла на final_monitoring через
        // nextStageFor redirect) — оставляем старую логику OR.
        $indexed = ((int)$indexCheck['pages_indexed']) >= 1;
        $moveSuccess = ($moveCheck['status'] === 'success');
        $mode = (string)($job['mode'] ?? 'refresh');
        $isMoveMode = ($mode === 'move_indexed' || $mode === 'move_simple');

        // Логируем тик
        $minutes = round($elapsedSec / 60, 1);
        $log->info('final_monitoring',
            "Tick {$tickCount} (прошло {$minutes} мин): " .
            "индекс={$indexCheck['pages_indexed']} стр., переезд={$moveCheck['status']}.");

        // === SUCCESS path ===
        // В move-режимах: только moveSuccess. Индексация — info, не success.
        // В refresh (legacy через redirect): OR-логика как раньше.
        $isSuccess = $isMoveMode ? $moveSuccess : ($indexed || $moveSuccess);

        if ($isSuccess) {
            if ($isMoveMode) {
                // В move-режимах единственный success-сигнал — Webmaster main_mirror.
                $reason = "Yandex подтвердил переезд: main_mirror старого = новый домен" .
                          ($indexed ? " (новый домен также в индексе: {$indexCheck['pages_indexed']} стр.)" : "");
            } else {
                $reason = $indexed && $moveSuccess
                    ? "оба сигнала: домен в индексе ({$indexCheck['pages_indexed']} стр.) + переезд завершён"
                    : ($indexed
                        ? "домен попал в индекс ({$indexCheck['pages_indexed']} стр.)"
                        : "переезд завершён (main_mirror старого = новый)");
            }
            $watchState['result'] = 'success';
            $watchState['success_reason'] = $reason;
            $watchState['success_mode'] = $isMoveMode ? 'move_confirmation_only' : 'index_or_move';
            $watchState['finished_at'] = date('Y-m-d H:i:s');
            $this->saveArtifacts($jobId,
                ['final_monitoring_stage' => $watchState],
                $log, 'final_monitoring');

            // v22: фактический переезд для раздела «Переезды».
            // Фиксируем ТОЛЬКО в move-режимах и ТОЛЬКО когда успех обеспечен
            // подтверждением Webmaster (main_mirror старого = новый), то есть
            // success_mode = 'move_confirmation_only'. Индексация сама по себе
            // фактическим переездом не считается.
            if ($isMoveMode && $moveSuccess) {
                try {
                    $relRow = RelocationService::findByJobId($jobId);
                    if ($relRow && RelocationService::markMoveCompleted((int)$relRow['id'])) {
                        $log->ok('final_monitoring',
                            'Переезд зафиксирован в разделе «Переезды» (main_mirror подтверждён).');
                    }
                } catch (\Throwable $e) {
                    $log->warn('final_monitoring',
                        'Не удалось зафиксировать переезд в разделе: ' . $e->getMessage());
                }
            }

            $log->ok('final_monitoring',
                "✓ Финальный мониторинг завершён успешно: {$reason}");

            // Telegram уведомление об успехе ДО markJobDone (markJobDone тоже шлёт, но другое)
            $this->sendFinalMonitoringSuccessAlert($jobId, $job, $newDomain, $indexCheck, $moveCheck, $reason, $log);

            $this->setStatus($jobId, 'ok', 'stage_finished_at');
            return;
        }

        // v18.1.28: для move-режимов — если индекс есть но переезд ещё не подтверждён,
        // логируем info: «ждём подтверждения от Yandex», и продолжаем polling.
        if ($isMoveMode && $indexed && !$moveSuccess) {
            $log->info('final_monitoring',
                "Новый домен в индексе ({$indexCheck['pages_indexed']} стр.), но переезд ещё НЕ " .
                "подтверждён Webmaster (main_mirror={$moveCheck['status']}). " .
                "Это нормально для move-режима — ждём подтверждения Yandex.");
        }

        // === Негативные финальные статусы переезда (Yandex однозначно отказал) ===
        if (in_array($moveCheck['status'], ['wrong_mirror', 'old_not_found', 'new_not_found'], true)) {
            // v18.1.28: ранее тут был fallback «если индекс есть — считаем success».
            // Это работало только для refresh-режима. Для move-режимов индексация
            // НЕ является success-сигналом (она уже была до final_monitoring),
            // поэтому negative move-статус однозначно означает что переезд провалился.
            // Если индекс присутствует — это уже обработано в SUCCESS path выше
            // (для refresh-режима через OR-логику).
            $watchState['result'] = 'negative';
            $watchState['negative_reason'] = $moveCheck['reason'];
            $watchState['finished_at'] = date('Y-m-d H:i:s');
            $this->saveArtifacts($jobId,
                ['final_monitoring_stage' => $watchState],
                $log, 'final_monitoring');

            $log->error('final_monitoring',
                "Yandex вернул негативный статус переезда: {$moveCheck['status']} — {$moveCheck['reason']}");
            $this->setStatusAwaitingUser($jobId,
                'final_monitoring: ' . $moveCheck['status'] . ' — ' . $moveCheck['reason']);
            return;
        }

        // === API error — несколько подряд = awaiting_user ===
        if ($moveCheck['status'] === 'api_error') {
            $consecErrors = (int)($watchState['consecutive_api_errors'] ?? 0) + 1;
            $watchState['consecutive_api_errors'] = $consecErrors;

            if ($consecErrors >= 5) {
                // v18.1.28: для move-режима если 5 API errors подряд — реально
                // блокируем (раньше комментарий говорил «если индекс есть — не
                // блокируем», но это работало только для refresh). В move-режиме
                // нам ОБЯЗАТЕЛЕН ответ Webmaster API, индекс не заменяет его.
                $log->error('final_monitoring',
                    "5 подряд API errors при проверке переезда: {$moveCheck['reason']}. " .
                    ($isMoveMode
                        ? "Move-режим требует подтверждения от Webmaster API; индексация " .
                          "не заменяет это подтверждение. Pipeline остановлен."
                        : "Индекс пока тоже не нашёлся. Pipeline остановлен (нужно решение оператора)."));
                $this->saveArtifacts($jobId,
                    ['final_monitoring_stage' => $watchState],
                    $log, 'final_monitoring');
                $this->setStatusAwaitingUser($jobId,
                    'final_monitoring: 5 API errors подряд: ' . $moveCheck['reason']);
                return;
            }

            $log->warn('final_monitoring',
                "API error при проверке переезда #{$consecErrors}: {$moveCheck['reason']}. " .
                "Polling продолжается, индекс ещё может появиться.");
        } else {
            // status = in_progress — сбрасываем счётчик ошибок
            $watchState['consecutive_api_errors'] = 0;
        }

        // === Adaptive next tick ===
        // Используем тот же алгоритм что и для index_watching: 30 сек → 2 мин → ... → 24 ч
        $delaySec = $this->computeIndexWatchingDelay($elapsedSec);

        $this->saveArtifacts($jobId,
            ['final_monitoring_stage' => $watchState],
            $log, 'final_monitoring');

        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    stage_status = 'pending',
                    next_run_at = DATE_ADD(NOW(), INTERVAL ? SECOND)
                 WHERE id = ?"
            )->execute([$delaySec, $jobId]);
        } catch (\Throwable $e) {}

        $delayLabel = $delaySec >= 3600
            ? round($delaySec / 3600, 1) . ' ч'
            : ($delaySec >= 60 ? round($delaySec / 60) . ' мин' : $delaySec . ' сек');
        $log->info('final_monitoring',
            "Следующая проверка через {$delayLabel}.");

        // TG-уведомление об изменении статуса переезда (если изменился)
        if ($prevMoveStatus !== null
            && $prevMoveStatus !== $moveCheck['status']
            && $moveCheck['status'] !== 'api_error') {
            // success обработан выше, остальные изменения — info
            $log->info('final_monitoring',
                "Статус переезда изменился: {$prevMoveStatus} → {$moveCheck['status']}");
        }
    }

    /**
     * v18.1.23: однократный TG-аларт «ещё ждём» через 30 мин final_monitoring.
     */
    private function sendFinalMonitoringWaitingAlert(
        int $jobId,
        array $job,
        string $newDomain,
        array $watchState,
        JobEventLogger $log
    ): void {
        try {
            $artifacts = $this->loadArtifacts($job);
            if (!empty($artifacts['final_monitoring_stage']['waiting_alert_sent_at'])) {
                return;
            }
        } catch (\Throwable $e) {}

        try {
            $tg = $this->makeTelegramService();
            $oldSafe = htmlspecialchars((string)$job['old_domain'], ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
            $jobUrl = $this->buildJobUrl($jobId);
            $tickCount = (int)($watchState['tick_count'] ?? 0);

            $tg->send(
                "⏳ <b>refresh #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "Стадия: финальный мониторинг — прошло 30 минут\n" .
                "Пока ни индексации, ни подтверждения переезда (после {$tickCount} проверок).\n\n" .
                "<b>Это нормально</b> — индексация может занять часы или дни.\n" .
                "Джоба <b>продолжает мониторинг</b> с разрядкой:\n" .
                "• следующие 6 часов — проверка каждые 30 мин\n" .
                "• до 3 суток — каждый час\n" .
                "• до недели — каждые 6 часов\n" .
                "• потом раз в сутки\n\n" .
                "Проверяются ОБА сигнала: появление в индексе + Yandex Webmaster (склейка зеркал). " .
                "Что наступит первым — то и завершит джобу.\n\n" .
                "Действий от тебя <b>не требуется</b>." .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('final_monitoring', 'Telegram waiting alert failed: ' . $e->getMessage());
        }
    }

    /**
     * v18.1.23: TG-уведомление об успехе финального мониторинга.
     * markJobDone сам отправит общее «джоба завершена», но здесь — детали что
     * именно сработало (индекс/переезд/оба).
     */
    private function sendFinalMonitoringSuccessAlert(
        int $jobId,
        array $job,
        string $newDomain,
        array $indexCheck,
        array $moveCheck,
        string $reason,
        JobEventLogger $log
    ): void {
        try {
            $tg = $this->makeTelegramService();
            $oldSafe = htmlspecialchars((string)$job['old_domain'], ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
            $jobUrl = $this->buildJobUrl($jobId);

            $indexedPages = (int)($indexCheck['pages_indexed'] ?? 0);
            $moveStatus = (string)($moveCheck['status'] ?? '?');

            $details = '';
            if ($indexedPages >= 1) {
                $details .= "• Индекс: {$indexedPages} страниц(ы) ✓\n";
            }
            if ($moveStatus === 'success') {
                $details .= "• Webmaster: main_mirror старого = новый ✓\n";
            }

            $tg->send(
                "🎉 <b>refresh #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "Финальный мониторинг завершён успешно!\n\n" .
                "{$details}\n" .
                "Причина завершения: " . htmlspecialchars($reason, ENT_QUOTES, 'UTF-8') .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('final_monitoring', 'Telegram success alert failed: ' . $e->getMessage());
        }
    }

    /**
     * v18 (только refresh): финальная стадия — собираем список URL'ов старого
     * домена и шлём его в TG оператору для ручной отправки в "Удаление страниц
     * из поиска" в Webmaster.
     *
     * НЕ вызывает никаких API Yandex (публичного метода для удаления страниц
     * из индекса нет). Только формирует список и ставит awaiting_user.
     *
     * Источники URL'ов (по приоритету):
     *   1. SitemapFetcher на новом домене (он сейчас рабочий с актуальным sitemap)
     *      — затем заменяем new_domain → old_domain в каждом URL
     *   2. Если sitemap пустой/недоступен — берём минимум: ["https://{old}/"]
     *
     * При повторном заходе (после нажатия "✓ Я отправил" в UI) стадия НЕ
     * вызывается — контроллер сам ставит stage_status='ok' и pipeline
     * завершается (это последняя стадия refresh).
     */
    private function runOldDelurlNotifyStage(array $job, JobEventLogger $log): void
    {
        $jobId = (int)$job['id'];
        $oldDomain = trim((string)$job['old_domain']);
        $newDomain = trim((string)$job['new_domain']);

        $artifacts = $this->loadArtifacts($job);
        $resolveStage = $artifacts['wm_account_resolve_stage'] ?? null;

        // Email старого аккаунта (под которым нужно зайти в Webmaster)
        $oldAccountId = (int)($resolveStage['old_account_id'] ?? 0);
        $oldAccountEmail = '';
        if ($oldAccountId > 0) {
            try {
                $st = DB::pdo()->prepare(
                    "SELECT email FROM yandex_webmaster_accounts WHERE id = ?"
                );
                $st->execute([$oldAccountId]);
                $row = $st->fetch();
                if ($row) $oldAccountEmail = (string)($row['email'] ?? '');
            } catch (\Throwable $e) {}
        }

        // host_id для прямой ссылки на инструмент
        $oldHostId = (string)($resolveStage['old_host_id'] ?? '');

        $log->info('old_delurl_notify',
            "Собираю URL'ы старого домена {$oldDomain} для del-url инструкции");

        // === Источник 1: sitemap нового домена (наиболее актуальный) ===
        $fetcher = new SitemapFetcher();
        $sitemap = $fetcher->fetchByDomain($newDomain);
        $urls = [];
        $source = 'sitemap_failed';

        if (!empty($sitemap['urls'])) {
            // Sitemap нового домена есть — переписываем new → old
            $urls = $fetcher->rewriteDomain($sitemap['urls'], $newDomain, $oldDomain);
            $source = 'sitemap_new_rewritten';
            $log->info('old_delurl_notify',
                "Sitemap {$sitemap['source_url']}: {$sitemap['http_code']}, " .
                "получено " . count($sitemap['urls']) . " URL → переписано в {$oldDomain}: " . count($urls));
        }

        // Fallback: пробуем sitemap старого домена напрямую
        if (empty($urls)) {
            $oldSitemap = $fetcher->fetchByDomain($oldDomain);
            if (!empty($oldSitemap['urls'])) {
                $urls = $oldSitemap['urls'];
                $source = 'sitemap_old';
                $log->info('old_delurl_notify',
                    "Fallback на sitemap старого: " . count($urls) . " URL из {$oldSitemap['source_url']}");
            }
        }

        // Минимум — корневой URL
        if (empty($urls)) {
            $urls = ["https://{$oldDomain}/"];
            $source = 'fallback_root_only';
            $log->warn('old_delurl_notify',
                'Sitemap не получен, оставляю только корневой URL https://' . $oldDomain . '/');
        }

        // Дедуплицируем и сортируем (чтобы оператору было удобно копировать)
        $urls = array_values(array_unique($urls));
        sort($urls);

        // Прямая ссылка на инструмент в Webmaster
        $delUrlToolUrl = $oldHostId !== ''
            ? 'https://webmaster.yandex.ru/site/' . rawurlencode($oldHostId) . '/tools/del-url/'
            : 'https://webmaster.yandex.ru/sites/';

        $awaitingSince = date('Y-m-d H:i:s');

        $patch = ['old_delurl_notify_stage' => [
            'awaiting_since' => $awaitingSince,
            'old_domain' => $oldDomain,
            'old_host_id' => $oldHostId,
            'old_account_id' => $oldAccountId,
            'old_account_email' => $oldAccountEmail,
            'urls_count' => count($urls),
            'urls' => $urls,
            'urls_source' => $source,
            'del_url_tool_url' => $delUrlToolUrl,
            'tg_sent' => false,
            'ack_at' => null,
        ]];

        // Отправляем TG
        $tgSent = false;
        try {
            $tg = $this->makeTelegramService();
            $oldSafe = htmlspecialchars($oldDomain, ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');
            $emailSafe = htmlspecialchars($oldAccountEmail !== '' ? $oldAccountEmail : '— не определён —',
                ENT_QUOTES, 'UTF-8');
            $jobUrl = $this->buildJobUrl($jobId);
            $urlsCount = count($urls);

            $tgSent = $tg->send(
                "🗑 <b>refresh #{$jobId} | {$oldSafe} → {$newSafe}</b>\n" .
                "Стадия: old_delurl_notify (awaiting_user)\n\n" .
                "<b>Удали страницы старого домена из поиска</b>\n" .
                "Аккаунт WM: <code>{$emailSafe}</code>\n" .
                "URLов в списке: {$urlsCount}\n\n" .
                "Что сделать:\n" .
                "1. Войди в Webmaster под <code>{$emailSafe}</code>\n" .
                "2. Открой инструмент: <a href=\"{$delUrlToolUrl}\">Удаление страниц из поиска</a>\n" .
                "3. Скопируй список URL из карточки джобы (textarea «Список URL для удаления»)\n" .
                "4. Вставь в Webmaster и нажми «Удалить»\n" .
                "5. Вернись в Refresh Panel и нажми «✅ Готово»\n\n" .
                "Лимит: 500 URL/день в Webmaster — у тебя {$urlsCount} URL." .
                ($jobUrl !== '' ? "\n\n→ <a href=\"{$jobUrl}\">Открыть джобу</a>" : '')
            );
        } catch (\Throwable $e) {
            $log->warn('old_delurl_notify', 'Telegram alert failed: ' . $e->getMessage());
        }

        $patch['old_delurl_notify_stage']['tg_sent'] = $tgSent;
        $this->saveArtifacts($jobId, $patch, $log, 'old_delurl_notify');

        $log->info('old_delurl_notify',
            "Подготовлен список из " . count($urls) . " URL ({$source}). " .
            "Жду оператора (TG: " . ($tgSent ? 'отправлено' : 'не настроен') . ").");

        $this->setStatusAwaitingUser($jobId,
            'old_delurl_notify: жду ручной отправки URL в "Удаление страниц из поиска"');
    }

    // ========================================================================
    // ========================== /v18 МЕТОДЫ =================================
    // ========================================================================

    /** Хелпер: загрузить artifacts из job. */
    private function loadArtifacts(array $job): array
    {
        if (empty($job['artifacts_json'])) return [];
        return json_decode((string)$job['artifacts_json'], true) ?: [];
    }

    /** Хелпер: сохранить patch в artifacts через JSON_MERGE_PATCH. */
    private function saveArtifacts(int $jobId, array $patch, JobEventLogger $log, string $stage): void
    {
        try {
            DB::pdo()->prepare(
                "UPDATE refresh_jobs SET
                    artifacts_json = JSON_MERGE_PATCH(COALESCE(artifacts_json, '{}'), ?)
                 WHERE id = ?"
            )->execute([
                json_encode($patch, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $jobId,
            ]);
        } catch (\Throwable $e) {
            $log->warn($stage, 'Не сохранил artifacts: ' . $e->getMessage());
        }
    }

    private function buildJobUrl(int $jobId): string
    {
        $base = trim((string)config('app.url', ''));
        if ($base === '') return '';
        return rtrim($base, '/') . '/jobs/show?id=' . $jobId;
    }

    /**
     * Возвращает следующую стадию или null если она последняя.
     */
    /**
     * Определить следующую стадию pipeline'а.
     *
     * v18: учитывает $job['mode']:
     *   - 'refresh'      — старый цикл с redirect_enable + old_delurl_notify в конце
     *   - 'move_indexed' — пропускает redirect_disable; после index_watching →
     *                      move_htaccess_redirect → move_submit_request → move_poll_status → done
     *   - 'move_simple'  — пропускает redirect_disable + sitemap/recrawl/index_watching;
     *                      после wm_verified → move_* → done
     *
     * Сигнатура расширена: nextStage(string, ?array). Если $job=null или
     * mode не задан — считаем 'refresh' (back-compat).
     *
     * Также экспортирована статическая версия nextStageFor() — её использует
     * RefreshJobController::skipStage чтобы тоже знать про mode.
     *
     * v18.1: учитывает sites_managed.ssl_le_enabled — если выключено, стадия
     * ssl_le_polling пропускается. Параметр читается из enrichего job (см.
     * resolveJobMeta()).
     */
    private function nextStage(string $current, ?array $job = null): ?string
    {
        $mode = is_array($job) ? (string)($job['mode'] ?? 'refresh') : 'refresh';
        $sslLeEnabled = is_array($job) ? (bool)($job['_ssl_le_enabled'] ?? false) : false;
        return self::nextStageFor($current, $mode, $sslLeEnabled);
    }

    /**
     * Статический аналог nextStage, доступный из RefreshJobController.
     * Используется в skipStage и подобных контроллерных операциях.
     *
     * @param string $current Текущая стадия
     * @param string $mode    'refresh'|'move_indexed'|'move_simple'
     * @return string|null Следующая стадия или null если pipeline закончен
     */
    public static function nextStageFor(string $current, string $mode = 'refresh', bool $sslLeEnabled = false): ?string
    {
        $isMove = ($mode === 'move_indexed' || $mode === 'move_simple');

        // === Линейная часть: до verify_replacement общая для всех режимов ===
        if ($current === 'aliases_added')         return 'ssl_self_signed_first';
        if ($current === 'ssl_self_signed_first') return 'redirect_disable';
        if ($current === 'redirect_disable')      return 'analyze_site';
        if ($current === 'analyze_site')          return 'config_replaced';
        if ($current === 'config_replaced')       return 'verify_replacement';

        // v18.1: после verify_replacement — ssl_le_polling ТОЛЬКО если включено в настройках сайта.
        // Если не включено → пропускаем стадию и идём сразу к update_classes_call.
        // v18.1.2: robots.php logic check теперь ВСТРОЕНА в verify_replacement как 5-я проверка
        // (с возможностью autopatch если включено в настройках сайта).
        if ($current === 'verify_replacement') {
            return $sslLeEnabled ? 'ssl_le_polling' : 'update_classes_call';
        }
        if ($current === 'ssl_le_polling')        return 'update_classes_call';

        // v18.1: redirect_enable перенесён ДО webmaster секции —
        // sitemap.xml/robots.txt должны отдаваться правильно когда Webmaster их запрашивает.
        // С включённым $redirect_enabled = 1, guard.php в 7k шаблоне ПРОПУСКАЕТ
        // запросы на sitemap.xml и robots.txt (специальная whitelist в guard).
        if ($current === 'update_classes_call')   return 'redirect_enable';

        // === v18.1.10 развилка после redirect_enable ===
        // refresh                       → wm_account_resolve (как раньше)
        // move_indexed / move_simple    → move_htaccess_redirect ПЕРЕД webmaster
        //
        // Логика: для move-режимов важно поставить 301 со старого на новый ДО того
        // как мы начинаем работать с Webmaster и подаём заявку на склейку. Иначе
        // Yandex проверяет main_mirror и видит что 301 нет — отклоняет заявку.
        // Раньше move_htaccess_redirect был В САМОМ КОНЦЕ — это значило что 301
        // ставился слишком поздно (после index_watching), и заявка часто
        // отклонялась с "redirect not found".
        if ($current === 'redirect_enable') {
            return $isMove ? 'move_htaccess_redirect' : 'trusted_ssl_gate';
        }

        // move_htaccess_redirect для всех move-режимов идёт к trusted_ssl_gate (P0),
        // затем к Webmaster. Прямого перехода в wm_account_resolve больше нет.
        if ($current === 'move_htaccess_redirect') return 'trusted_ssl_gate';

        // P0: публичный trusted-SSL gate — единственный вход в Webmaster-контур.
        if ($current === 'trusted_ssl_gate')       return 'wm_account_resolve';

        if ($current === 'wm_account_resolve')    return 'wm_added';
        if ($current === 'wm_added')              return 'wm_verified';

        // === v18.1 развилка после wm_verified ===
        // v18.1.23: для move-режимов submit_request подаём СРАЗУ (не ждём индекс).
        // Заявка на переезд может быть подана как только Webmaster-верификация прошла.
        // Дальше final_monitoring параллельно следит и за индексом, и за статусом заявки.
        //
        // move_simple → пропускаем sitemap/recrawl/robots/index_watching,
        //                идём сразу к move_submit_request.
        // move_indexed → wm_recrawl → wm_sitemap → wm_robots → move_submit_request
        //                (sitemap/recrawl всё ещё помогают индексации, оставляем).
        // refresh → wm_recrawl → ... → index_watching → old_delurl_notify
        if ($current === 'wm_verified') {
            return $mode === 'move_simple' ? 'move_submit_request' : 'wm_recrawl';
        }

        // v18.1: новый порядок Webmaster — recrawl → sitemap → robots
        // v18.1.23: для move_indexed после wm_robots идём в move_submit_request
        // (а НЕ в index_watching — теперь это часть final_monitoring).
        if ($current === 'wm_recrawl')  return 'wm_sitemap';
        if ($current === 'wm_sitemap')  return 'wm_robots';
        if ($current === 'wm_robots') {
            return $isMove ? 'move_submit_request' : 'index_watching';
        }

        // === v18.1.10 → v18.1.23: index_watching ТОЛЬКО для refresh ===
        // Для move-режимов отдельной стадии index_watching больше нет — её
        // функцию выполняет final_monitoring (одновременно с move-проверкой).
        if ($current === 'index_watching') {
            // refresh → финал refresh
            // (на случай если старая move-джоба застряла на index_watching —
            //  redirect на final_monitoring чтобы не терять контекст)
            return $isMove ? 'final_monitoring' : 'old_delurl_notify';
        }

        if ($current === 'old_delurl_notify') return null; // финал refresh

        // === v18.1.23 финал move: объединённый мониторинг ===
        // move_submit_request → final_monitoring (вместо move_poll_status)
        if ($current === 'move_submit_request')    return 'final_monitoring';

        // Старая стадия move_poll_status — если джоба застряла на ней, переводим в final_monitoring
        if ($current === 'move_poll_status')       return 'final_monitoring';

        if ($current === 'final_monitoring')       return null; // финал move

        // === Deprecated с v18: wm_old_removed ===
        if ($current === 'wm_old_removed') return null;

        // === Общая логика по STAGES_ORDER для пройденных стадий (queued, domain_purchasing) ===
        $idx = array_search($current, self::STAGES_ORDER, true);
        if ($idx === false) return null;
        $next = self::STAGES_ORDER[$idx + 1] ?? null;

        if ($next === 'dns_configuring') {
            return 'aliases_added';
        }

        // 'done' — это маркер terminal, оркестратор должен вызвать markJobDone
        if ($next === 'done') return null;

        return $next;
    }

    /**
     * v18: возвращает упорядоченный список стадий, которые пройдёт джоба
     * данного режима — от 'queued' до терминальной стадии (включая 'done').
     *
     * Используется для отрисовки прогресс-бара в UI: чтобы для move-джобы
     * не показывалась стадия old_delurl_notify, а для refresh-джобы не
     * показывались move_*. Каждая джоба видит только СВОИ стадии.
     *
     * Реализация: симулируем pipeline через nextStageFor() начиная с queued,
     * пока не упрёмся в null (= done). Защищены от циклов через лимит 50
     * итераций (реальный pipeline ≤ 18 стадий).
     *
     * @param string $mode 'refresh'|'move_indexed'|'move_simple'
     * @return string[] Список стадий, заканчивающийся 'done'
    /**
     * v18: возвращает упорядоченный список стадий, которые пройдёт джоба
     * данного режима — от 'queued' до терминальной стадии (включая 'done').
     *
     * Используется для отрисовки прогресс-бара в UI: чтобы для move-джобы
     * не показывалась стадия old_delurl_notify, а для refresh-джобы не
     * показывались move_*. Каждая джоба видит только СВОИ стадии.
     *
     * v18.1: добавлен параметр $sslLeEnabled — если false, ssl_le_polling
     * не включается в pipeline (стадия пропускается). Это влияет на счётчик
     * и progress bar в UI: оператор видит ровно те стадии, через которые джоба
     * реально пройдёт.
     *
     * Реализация: симулируем pipeline через nextStageFor() начиная с queued,
     * пока не упрёмся в null или цикл.
     */
    public static function pipelineStagesFor(string $mode = 'refresh', bool $sslLeEnabled = false): array
    {
        $stages = ['queued'];
        $current = 'queued';
        $maxSteps = 50;

        for ($i = 0; $i < $maxSteps; $i++) {
            $next = self::nextStageFor($current, $mode, $sslLeEnabled);
            if ($next === null) break;
            // защита от цикла (на случай если nextStageFor сломается)
            if (in_array($next, $stages, true)) break;
            $stages[] = $next;
            $current = $next;
        }

        // Финальный маркер done — UI отрисует его как «Готово»
        $stages[] = 'done';

        return $stages;
    }

    /** PATCH_6 (P0.2): опциональный recorder переходов стадий (test-only, в production null). */
    protected $transitionRecorder = null;
    public function setTransitionRecorder(callable $f): void { $this->transitionRecorder = $f; }

    private function setStage(int $jobId, string $stage, string $status): void
    {
        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage = ?,
                stage_status = ?,
                stage_started_at = NULL,
                stage_finished_at = NULL,
                stage_error = NULL,
                next_run_at = NULL
             WHERE id = ?"
        );
        $st->execute([$stage, $status, $jobId]);
        if ($this->transitionRecorder !== null) ($this->transitionRecorder)($jobId, $stage, $status);
    }

    private function setStatus(int $jobId, string $status, ?string $timestampField = null): void
    {
        $sql = "UPDATE refresh_jobs SET stage_status = ?";
        $params = [$status];
        if ($timestampField === 'stage_started_at') {
            $sql .= ", stage_started_at = NOW()";
        } elseif ($timestampField === 'stage_finished_at') {
            $sql .= ", stage_finished_at = NOW()";
        }
        $sql .= " WHERE id = ?";
        $params[] = $jobId;
        $st = DB::pdo()->prepare($sql);
        $st->execute($params);
    }

    private function setStatusFailed(int $jobId, string $error): void
    {
        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage_status = 'failed',
                stage_error = ?,
                stage_finished_at = NOW()
             WHERE id = ?"
        );
        $st->execute([mb_substr($error, 0, 1000), $jobId]);
    }

    /**
     * Перевести стадию в awaiting_user — стадия не failed, но требует
     * ручного вмешательства. Cron такие джобы не подхватывает,
     * пока пользователь не нажмёт "Продолжить" или "Откатить" в UI.
     */
    /**
     * Установить awaiting_user (ждёт оператора) и сбросить next_run_at = NULL.
     *
     * v18.1.6: ВАЖНО — сбрасываем next_run_at, иначе retry-механизм в stepInternal
     * подхватит джобу как ретрай и зациклит её. Сценарий который ловили:
     *
     *   index_watching polling: ставит next_run_at = NOW() + 60s каждый тик.
     *   После 30 минут timeout: вызывает setStatusAwaitingUser(...) — но
     *   ДО этого фикса next_run_at не сбрасывался. Cron на следующей минуте:
     *     - status = awaiting_user
     *     - next_run_at в прошлом
     *     → "retry pickup!" → запуск index_watching → опять timeout → ...
     *   Каждый цикл шлёт TG-уведомление. 800+ сообщений за ночь.
     *
     * Этот метод предназначен для ФИНАЛЬНОГО awaiting (ждём оператора навсегда).
     * Если нужно "ждём время для ретрая" (как verify_replacement) — используй
     * прямой UPDATE с явным next_run_at, не этот метод.
     */
    private function setStatusAwaitingUser(int $jobId, string $reason): void
    {
        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage_status = 'awaiting_user',
                stage_error = ?,
                stage_finished_at = NOW(),
                next_run_at = NULL
             WHERE id = ?"
        );
        $st->execute([mb_substr($reason, 0, 1000), $jobId]);
    }

    private function markJobDone(int $jobId, JobEventLogger $log, array $job): void
    {
        $st = DB::pdo()->prepare(
            "UPDATE refresh_jobs SET
                stage = 'done',
                stage_status = 'ok',
                stage_error = NULL,
                stage_finished_at = NOW(),
                next_run_at = NULL,
                ssl_issue_next_poll_at = NULL
             WHERE id = ?"
        );
        $st->execute([$jobId]);

        // v25.0-a: финальная очистка probe-файла готовности (best-effort).
        try {
            (new ProbeFileManager())->removeForJob($jobId, $log);
        } catch (\Throwable $e) {
            error_log("markJobDone: probe cleanup failed: " . $e->getMessage());
        }

        $oldDomain = (string)$job['old_domain'];
        $newDomain = (string)$job['new_domain'];
        if ($newDomain === '') {
            // Возможно artifacts_json содержит — fallback
            $row = DB::pdo()->prepare("SELECT new_domain FROM refresh_jobs WHERE id=?");
            $row->execute([$jobId]);
            $newDomain = (string)$row->fetchColumn();
        }

        // ТЗ 041 §8: сразу после done/ok исключить СТАРЫЙ домен из SSL-мониторинга
        // (ожидаемый редирект old→new не должен давать ложную Telegram-аварию).
        // §8.1: ошибка cleanup НЕ откатывает уже завершённый pipeline, но не
        // проглатывается — error_log + warning-событие джобы.
        try {
            (new DomainSslStatusRepository())->archiveCompletedOldDomain(
                $oldDomain,
                $newDomain,
                isset($job['site_id']) && $job['site_id'] !== null ? (int)$job['site_id'] : null,
                $jobId
            );
        } catch (\Throwable $e) {
            error_log('markJobDone: SSL old-domain cleanup failed'
                . ' job_id=' . $jobId
                . ' old_domain=' . $oldDomain
                . ' error=' . $e->getMessage());
            try {
                $log->warn('done', 'Не удалось отключить SSL-мониторинг старого домена. Требуется проверка оператора.',
                    ['old_domain' => $oldDomain, 'error' => $e->getMessage()]);
            } catch (\Throwable $e2) { /* best-effort */ }
        }

        try {
            $log->done($oldDomain, $newDomain);
        } catch (\Throwable $e) {
            // если done() сам упадёт (например JobEventLogger::write баг как был в v17),
            // не валим pipeline — просто логируем
            error_log("markJobDone: log->done() failed: " . $e->getMessage());
        }

        // v18: критичное уведомление о завершении — отправляется ВСЕГДА
        // независимо от notify_on_done в settings
        try {
            $tg = $this->makeTelegramService();
            $mode = (string)($job['mode'] ?? 'refresh');
            $modeRu = [
                'refresh'      => 'Перевыставление',
                'move_indexed' => 'Переезд (с индексацией)',
                'move_simple'  => 'Переезд (без индексации)',
            ][$mode] ?? $mode;

            $oldSafe = htmlspecialchars($oldDomain, ENT_QUOTES, 'UTF-8');
            $newSafe = htmlspecialchars($newDomain, ENT_QUOTES, 'UTF-8');

            $tg->notifyImportant($jobId,
                "Джоба завершена ({$modeRu})",
                "<code>{$oldSafe}</code> → <code>{$newSafe}</code>\n\n" .
                "Pipeline пройден до конца. Pipeline завершён."
            );
        } catch (\Throwable $e) {}
    }
}
