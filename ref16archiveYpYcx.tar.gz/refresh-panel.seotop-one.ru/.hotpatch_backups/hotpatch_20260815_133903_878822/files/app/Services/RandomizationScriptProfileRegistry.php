<?php
/**
 * ТЗ 039 v4 §8.2: реестр известных профилей скриптов рандомизации.
 *
 * Для автоматически найденного update_classes.php инспектор определяет
 * КОНКРЕТНОЕ семейство по имени файла + минимум двум независимым структурным
 * сигнатурам (не по маркеру ответа). Каждому семейству соответствует РОВНО
 * ОДИН точный completion-marker. Общий список маркеров (classic) удалён —
 * ответ одного семейства не должен подтверждать успех другого.
 *
 * Сигнатуры — реальные устойчивые фрагменты из поддерживаемых скриптов
 * (fixtures/sites/{7k2500,r7,irvin}/update_classes.php):
 *   7k    — split mobile/desktop, templates/2, generateNewFileName + ___<hex8>;
 *   r7    — templates/r7, updateClassNameMapping, update_classes.log;
 *   irvin — image-first: generateImageSuffix, renameImagesAlways, replaceImagesInCss.
 */
final class RandomizationScriptProfileRegistry
{
    /**
     * @return array<int,array{family:string,script:string,required_signatures:array<int,string>,completion_marker:string}>
     */
    public function profiles(): array
    {
        return [
            [
                'family' => '7k',
                'script' => 'update_classes.php',
                'required_signatures' => [
                    'updateClassMappings',      // уникальное имя функции 7k
                    'generateNewFileName',      // 7k переименовывает файлы (___<hex8>)
                    'mobilePath',               // split mobile/desktop
                    'templates/2',              // путь шаблонов 7k
                ],
                'min_signatures' => 2,
                'completion_marker' => 'Update process completed.',
            ],
            [
                'family' => 'r7',
                'script' => 'update_classes.php',
                'required_signatures' => [
                    'updateClassNameMapping',   // r7: ClassName (не ClassMappings)
                    'templates/r7',             // путь шаблонов r7
                    'update_classes.log',       // r7 пишет собственный лог
                ],
                'min_signatures' => 2,
                'completion_marker' => 'Скрипт успешно выполнен!',
            ],
            [
                'family' => 'irvin',
                'script' => 'update_classes.php',
                'required_signatures' => [
                    'generateImageSuffix',      // irvin работает с картинками
                    'renameImagesAlways',
                    'replaceImagesInCss',
                    'processPhpFiles',
                ],
                'min_signatures' => 2,
                'completion_marker' => '✅ Готово.',
            ],
        ];
    }

    /**
     * Определить семейство по содержимому файла.
     * @return array{status:string,family?:string,marker?:string,matched?:array<int,string>,fingerprint?:string,conflicts?:array<int,string>}
     *   status: supported | needs_review | conflict
     */
    public function detect(string $fileContent): array
    {
        $fingerprint = hash('sha256', $fileContent);
        $matchedProfiles = [];
        $matchedSignaturesByFamily = [];

        foreach ($this->profiles() as $profile) {
            $hits = [];
            foreach ($profile['required_signatures'] as $sig) {
                if (strpos($fileContent, $sig) !== false) {
                    $hits[] = $sig;
                }
            }
            $need = (int)($profile['min_signatures'] ?? 2);
            if (count($hits) >= $need) {
                $matchedProfiles[] = $profile;
                $matchedSignaturesByFamily[$profile['family']] = $hits;
            }
        }

        if (count($matchedProfiles) === 1) {
            $p = $matchedProfiles[0];
            return [
                'status' => 'supported',
                'family' => $p['family'],
                'marker' => $p['completion_marker'],
                'matched' => $matchedSignaturesByFamily[$p['family']],
                'fingerprint' => $fingerprint,
            ];
        }
        if (count($matchedProfiles) >= 2) {
            return [
                'status' => 'conflict',
                'conflicts' => array_map(static fn($p) => $p['family'], $matchedProfiles),
                'fingerprint' => $fingerprint,
            ];
        }
        return ['status' => 'needs_review', 'fingerprint' => $fingerprint];
    }
}
