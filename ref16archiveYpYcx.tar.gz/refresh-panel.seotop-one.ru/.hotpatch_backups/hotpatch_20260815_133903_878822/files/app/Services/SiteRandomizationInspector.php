<?php

/**
 * ТЗ 039 §7–§8: read-only определение применимости рандомизации для сайта.
 *
 * Инспектор ТОЛЬКО читает файлы по FTP и НИКОГДА не вызывает PHP-скрипты по
 * HTTP. Проверка выполняется внутри подтверждённого физического root сайта
 * (FTP-учётка сайта) с учётом sites_managed.uc_site_subroot.
 *
 * Вызывается:
 *   1) после успешного импорта/синхронизации сайта (SiteConfigSyncService);
 *   2) по кнопке «Проверить рандомизацию» на карточке сайта;
 *   3) live re-detect перед mutating-вызовом в стадии update_classes_call
 *      (источник истины — свежая live-проверка, а не кэш БД; §7, §23.12).
 *
 * Классификация (§6/§8):
 *   confirmed_absent — FTP успешен, поддерживаемых скриптов нет;
 *   variant_refresh  — variant-refresh.php + поддерживаемая сигнатура +
 *                      непустой manual_secret из live config.php
 *                      (fallback 'go' ЗАПРЕЩЁН, §8.2);
 *   update_classes   — update_classes.php + поддерживаемая сигнатура;
 *   needs_review     — файл найден, но формат/применимость не подтверждены
 *                      (неизвестная сигнатура, нечитаемое содержимое,
 *                      отсутствующий секрет);
 *   conflict         — найдены оба скрипта одновременно;
 *   ftp_error        — FTP-проверка не завершилась (НЕ считается отсутствием).
 *
 * Секрет в БД НЕ сохраняется: uc_detection_json хранит только secret_present.
 */
final class SiteRandomizationInspector
{
    /** Версия инспектора — попадает в evidence (§4.4). */
    public const INSPECTOR_VERSION = '039.2';

    public const CAP_UNKNOWN          = 'unknown';
    public const CAP_CONFIRMED_ABSENT = 'confirmed_absent';
    public const CAP_VARIANT_REFRESH  = 'variant_refresh';
    public const CAP_UPDATE_CLASSES   = 'update_classes';
    public const CAP_CUSTOM           = 'custom';
    public const CAP_NEEDS_REVIEW     = 'needs_review';
    public const CAP_CONFLICT         = 'conflict';
    public const CAP_FTP_ERROR        = 'ftp_error';

    /** Максимум байт скрипта, скачиваемых для проверки сигнатуры. */
    private const MAX_SCRIPT_BYTES = 65536;

    /** @var callable|null (array $siteRow): object — фабрика FTP-клиента (тест-seam). */
    private $ftpFactory;
    /** @var RandomizationScriptProfileRegistry единый реестр семейств (§6.2). */
    private $profileRegistry;

    /** Runtime-значение секрета последней инспекции (в БД не пишется). */
    private ?string $runtimeSecret = null;

    public function __construct(?callable $ftpFactory = null, ?RandomizationScriptProfileRegistry $profileRegistry = null)
    {
        $this->ftpFactory = $ftpFactory;
        // §6.2: единый источник истины о семействах. По умолчанию — тот же
        // реестр, что использует исполнитель, чтобы import/sync/live-инспекция
        // и стадия джобы давали ОДИН ответ.
        if ($profileRegistry === null && !class_exists('RandomizationScriptProfileRegistry', false)) {
            $f = __DIR__ . '/RandomizationScriptProfileRegistry.php';
            if (is_file($f)) require_once $f;
        }
        $this->profileRegistry = $profileRegistry ?? new RandomizationScriptProfileRegistry();
    }

    /**
     * Read-only инспекция без записи в БД.
     *
     * Ключ 'secret' — runtime-значение manual_secret для исполнителя стадии
     * (построение path). В uc_detection_json НЕ сохраняется: persist() пишет
     * только 'detection' (там лишь secret_present).
     *
     * @return array{capability:string, detection:array, secret:?string}
     */
    public function inspect(int $siteId): array
    {
        $checkedAt = date('Y-m-d H:i:s');
        $this->runtimeSecret = null;
        $det = [
            'checked_at'       => $checkedAt,
            'inspector_version'=> self::INSPECTOR_VERSION,
            'base'             => '',
            'subroot'          => '',
            'physical_root'    => '',
            'files'            => [],
            'secret_present'   => null,
            'has_state_file'   => null,
            'reason'           => '',
        ];

        $site = $this->loadSite($siteId);
        if ($site === null) {
            $det['reason'] = 'site_not_found';
            return ['capability' => self::CAP_FTP_ERROR, 'detection' => $det, 'secret' => null];
        }

        $subroot = trim((string)($site['uc_site_subroot'] ?? ''));
        $base = $subroot === '' ? '' : rtrim($subroot, '/') . '/';
        $det['subroot'] = $subroot;
        $det['base'] = $base;

        if (trim((string)($site['ftp_host'] ?? '')) === ''
            || trim((string)($site['ftp_user'] ?? '')) === '') {
            $det['reason'] = 'ftp_credentials_missing';
            return ['capability' => self::CAP_FTP_ERROR, 'detection' => $det, 'secret' => null];
        }

        $ftp = null;
        try {
            $ftp = $this->makeFtp($site);
            $ftp->connect();
        } catch (\Throwable $e) {
            $det['reason'] = 'ftp_connect_failed: ' . $e->getMessage();
            return ['capability' => self::CAP_FTP_ERROR, 'detection' => $det, 'secret' => null];
        }

        try {
            try { $det['physical_root'] = (string)$ftp->pwd(); } catch (\Throwable $e) {}
            $cap = $this->classify($ftp, $base, $det);
            return ['capability' => $cap, 'detection' => $det, 'secret' => $this->runtimeSecret];
        } catch (\Throwable $e) {
            // §8.4/§23.8: любая незавершённая FTP-проверка = ftp_error,
            // а НЕ confirmed_absent.
            $det['reason'] = 'ftp_error: ' . $e->getMessage();
            return ['capability' => self::CAP_FTP_ERROR, 'detection' => $det, 'secret' => null];
        } finally {
            try { $ftp->disconnect(); } catch (\Throwable $e) {}
        }
    }

    /** Инспекция + запись результата в sites_managed. */
    public function inspectAndPersist(int $siteId): array
    {
        $res = $this->inspect($siteId);
        $this->persist($siteId, $res);
        return $res;
    }

    /**
     * Записать capability/детали в sites_managed. Секрет НЕ сохраняется.
     * uc_mode НЕ трогаем: режим — решение оператора, инспектор меняет только факт.
     */
    public function persist(int $siteId, array $result): void
    {
        $cap = (string)($result['capability'] ?? self::CAP_UNKNOWN);
        $det = $result['detection'] ?? [];
        try {
            DB::pdo()->prepare(
                "UPDATE sites_managed
                    SET uc_capability = ?, uc_detection_json = ?, uc_detected_at = NOW()
                  WHERE id = ?"
            )->execute([
                $cap,
                json_encode($det, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $siteId,
            ]);
        } catch (\Throwable $e) {
            // Отказ записи кэша не должен ронять вызывающий поток: live-результат
            // остаётся источником истины для текущей операции.
        }
    }

    /** Человеческое название механизма для карточки сайта (§10). */
    public static function mechanismLabel(string $capability): string
    {
        switch ($capability) {
            case self::CAP_VARIANT_REFRESH:
                return 'Скрипт смены вариантов (variant-refresh.php)';
            case self::CAP_UPDATE_CLASSES:
                return 'Скрипт смены классов (update_classes.php)';
            case self::CAP_CUSTOM:
                return 'Кастомный адрес, заданный оператором';
            case self::CAP_CONFIRMED_ABSENT:
                return 'Не найден';
            default:
                return 'Не подтверждён';
        }
    }

    // ── внутренняя классификация ────────────────────────────────────────────

    private function classify($ftp, string $base, array &$det): string
    {
        // ТЗ 039 §4.3 / ревью P0#2: решение принимается ТОЛЬКО по строгому
        // трёхсостояниевому листингу. confirmed_absent допускается лишь при
        // авторитетном ok=true. listing.ok=false → ftp_error, автопропуск запрещён.
        $dirPath = $base === '' ? '.' : rtrim($base, '/');
        $listing = $this->strictListing($ftp, $dirPath);
        $det['dir_listing_source'] = (string)($listing['source'] ?? 'none');
        $det['dir_raw_count'] = (int)($listing['raw_count'] ?? 0);
        $det['dir_parsed_count'] = (int)($listing['parsed_count'] ?? 0);
        if (!empty($listing['errors'])) $det['dir_listing_errors'] = $listing['errors'];
        if (empty($listing['ok'])) {
            $det['reason'] = 'ftp_listing_unauthoritative';
            throw new \RuntimeException('ftp_listing_unauthoritative: ' . $dirPath);
        }
        $names = (array)($listing['names'] ?? []);
        $det['dir_listing_ok'] = true;
        $det['dir_entries'] = count($names);

        $hasVariant = in_array('variant-refresh.php', $names, true);
        $hasClassic = in_array('update_classes.php', $names, true);
        $det['has_state_file'] = $this->fileReadable($ftp, $base . 'data/variant-state.json');

        // §8.2 п.5: оба скрипта одновременно — конфликт, автозапуск запрещён.
        if ($hasVariant && $hasClassic) {
            $det['files'][] = $this->fileEntry($ftp, $base . 'variant-refresh.php', 'variant');
            $det['files'][] = $this->fileEntry($ftp, $base . 'update_classes.php', 'classic');
            $det['reason'] = 'both_scripts_present';
            return self::CAP_CONFLICT;
        }

        if ($hasVariant) {
            $entry = $this->fileEntry($ftp, $base . 'variant-refresh.php', 'variant');
            $det['files'][] = $entry;
            if ($entry['signature'] === 'unreadable') {
                $det['reason'] = 'variant_script_unreadable';
                return self::CAP_NEEDS_REVIEW;
            }
            if ($entry['signature'] !== 'variant_supported') {
                $det['reason'] = 'variant_signature_unsupported';
                return self::CAP_NEEDS_REVIEW;
            }
            // §8.2 п.3: непустой manual_secret из live config.php обязателен.
            // Прочитанный из config секрет ЛЮБОЙ (в т.ч. 'go' у beef) — валиден;
            // запрещён лишь СИНТЕТИЧЕСКИЙ fallback, когда секрет не найден вовсе.
            $secret = $this->extractManualSecret($ftp, $base);
            $det['secret_present'] = ($secret !== null && $secret !== '');
            if (!$det['secret_present']) {
                $det['reason'] = 'manual_secret_missing';
                return self::CAP_NEEDS_REVIEW;
            }
            $this->runtimeSecret = $secret;
            $det['reason'] = 'variant_signature_and_secret_confirmed';
            return self::CAP_VARIANT_REFRESH;
        }

        if ($hasClassic) {
            // §6.3 (v5): определяем КОНКРЕТНОЕ семейство через единый registry,
            // а НЕ по одному общему признаку. Файл читаем полностью; при ошибке
            // чтения — ftp_error (не needs_review, чтобы отличать «не смогли
            // прочитать» от «прочитали, но не распознали»).
            $content = $this->tryReadScript($ftp, $base . 'update_classes.php');
            if (!is_string($content) || trim($content) === '') {
                $det['files'][] = ['path' => $base . 'update_classes.php', 'expected' => 'classic', 'signature' => 'unreadable'];
                $det['reason'] = 'update_classes_script_unreadable';
                $det['script_path'] = '/update_classes.php';
                return self::CAP_FTP_ERROR;
            }
            $profile = $this->profileRegistry->detect($content);
            $status = (string)($profile['status'] ?? 'needs_review');
            $fingerprint = (string)($profile['fingerprint'] ?? hash('sha256', $content));
            $det['files'][] = [
                'path' => $base . 'update_classes.php',
                'expected' => 'classic',
                'signature' => ($status === 'supported' ? 'update_classes_supported' : $status),
                'fingerprint_sha256' => $fingerprint,
            ];
            $det['script_path'] = '/update_classes.php';

            if ($status === 'supported') {
                // §6.4/§8.1: сохраняем family + fingerprint + точный marker.
                $det['family'] = (string)$profile['family'];
                $det['fingerprint_sha256'] = $fingerprint;
                $det['matched_signatures'] = (array)($profile['matched'] ?? []);
                $det['completion_contract'] = 'exact_marker';
                $det['completion_marker'] = (string)$profile['marker'];
                $det['reason'] = 'update_classes_family_confirmed';
                return self::CAP_UPDATE_CLASSES;
            }
            if ($status === 'conflict') {
                $det['matched_families'] = (array)($profile['conflicts'] ?? []);
                $det['fingerprint_sha256'] = $fingerprint;
                $det['reason'] = 'update_classes_family_conflict';
                return self::CAP_CONFLICT;
            }
            // needs_review: прочитали, но семейство не определено.
            // НЕ сохраняем completion_marker и family.
            $det['fingerprint_sha256'] = $fingerprint;
            $det['reason'] = 'update_classes_family_unresolved';
            return self::CAP_NEEDS_REVIEW;
        }

        // §8.4: каталог достоверно прочитан, поддерживаемых скриптов в нём нет.
        $det['reason'] = 'no_randomization_scripts';
        return self::CAP_CONFIRMED_ABSENT;
    }

    /**
     * Строгий листинг каталога (§4.2). Предпочитает FtpService::listDirStrict
     * (авторитетный трёхсостояниевый контракт), иначе — совместимый фолбэк для
     * клиентов/фейков без строгого метода (эмуляция того же контракта).
     *
     * @return array{ok:bool, names:array, source:string, raw_count:int, parsed_count:int, errors:array}
     */
    private function strictListing($ftp, string $dirPath): array
    {
        if (method_exists($ftp, 'listDirStrict')) {
            try {
                $r = $ftp->listDirStrict($dirPath);
                if (is_array($r) && array_key_exists('ok', $r)) {
                    $r['names'] = array_map('basename', (array)($r['names'] ?? []));
                    return $r;
                }
            } catch (\Throwable $e) {
                return ['ok'=>false,'names'=>[],'source'=>'none','raw_count'=>0,'parsed_count'=>0,
                        'errors'=>['listDirStrict_threw: '.$e->getMessage()]];
            }
        }
        // Фолбэк: listDirEntries → listDir, различаем пустой-авторитетный через
        // контрольное чтение config.php (как в старой логике).
        $names = null; $source = 'none';
        try {
            if (method_exists($ftp, 'listDirEntries')) {
                $entries = $ftp->listDirEntries($dirPath);
                if (is_array($entries)) {
                    $names = [];
                    foreach ($entries as $e) {
                        $n = is_array($e) ? (string)($e['name'] ?? '') : (string)$e;
                        if ($n !== '') $names[] = basename($n);
                    }
                    $source = 'entries';
                }
            }
        } catch (\Throwable $e) { $names = null; }
        if ($names === null) {
            try {
                if (method_exists($ftp, 'listDir')) {
                    $list = $ftp->listDir($dirPath);
                    if (is_array($list)) { $names = array_map('basename', $list); $source = 'nlist'; }
                }
            } catch (\Throwable $e) { $names = null; }
        }
        if ($names === null) {
            return ['ok'=>false,'names'=>[],'source'=>'none','raw_count'=>0,'parsed_count'=>0,'errors'=>['listing_failed']];
        }
        if (count($names) === 0) {
            $probe = $this->fileReadable($ftp, ($dirPath === '.' ? '' : $dirPath . '/') . 'config.php')
                  || $this->fileReadable($ftp, 'config.php');
            if (!$probe) {
                return ['ok'=>false,'names'=>[],'source'=>$source,'raw_count'=>0,'parsed_count'=>0,'errors'=>['empty_unauthoritative']];
            }
        }
        return ['ok'=>true,'names'=>array_values(array_unique($names)),'source'=>$source,
                'raw_count'=>count($names),'parsed_count'=>count($names),'errors'=>[]];
    }

    /** Надёжная проверка читаемости файла: пытаемся получить содержимое. */
    private function fileReadable($ftp, string $path): bool
    {
        try {
            $c = $ftp->tryGetContent($path);
            return $c !== null;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Скачать содержимое и построить запись о файле: сигнатура + fingerprint. */
    private function fileEntry($ftp, string $path, string $expected): array
    {
        $entry = [
            'name' => basename($path),
            'path' => '/' . ltrim($path, '/'),
            'present' => true,
            'signature' => 'unreadable',
            'fingerprint_sha256' => null,
        ];
        $content = null;
        try {
            $content = $ftp->tryGetContent($path);
        } catch (\Throwable $e) {
            $content = null;
        }
        if ($content === null || $content === '') {
            return $entry;
        }
        if (strlen($content) > self::MAX_SCRIPT_BYTES) {
            $content = substr($content, 0, self::MAX_SCRIPT_BYTES);
        }
        $entry['fingerprint_sha256'] = hash('sha256', $content);
        // Для variant-скрипта сигнатура может жить в подключаемом движке
        // (includes/variant_engine.php) — дочитываем его при необходимости.
        $entry['signature'] = $this->classifySignature($content, $expected, $ftp, dirname($path));
        return $entry;
    }

    /**
     * Сигнатуры поддерживаемых семейств шаблонов (§8.2/§8.3, ревью P0#3/P0#5).
     *
     * variant-refresh.php — семейство variant-engine: manual_secret + механизм
     *   ротации. На beef сам скрипт содержит только manual_secret +
     *   variant_manual_rotate() и подключает includes/variant_engine.php, где
     *   уже refresh_nonce/variant_read_state — при недостатке маркеров в самом
     *   файле сканируем require'ы.
     * update_classes.php — классическое семейство: class_name_mapping ЛИБО один
     *   из точных legacy-маркеров завершения реальных сайтов.
     */
    private function classifySignature(string $content, string $expected, $ftp = null, string $dir = ''): string
    {
        if ($expected === 'variant') {
            if (!preg_match('~manual_secret~i', $content)) return 'unsupported';
            if ($this->hasVariantCore($content)) return 'variant_supported';
            if ($ftp !== null && $this->includeFilesHaveVariantCore($ftp, $dir, $content)) {
                return 'variant_supported';
            }
            return 'unsupported';
        }
        // §6.1 (v5): классификация update_classes.php больше НЕ живёт здесь —
        // семейство определяет RandomizationScriptProfileRegistry по ≥2
        // структурным сигнатурам. Общий признак (class_name_mapping / общий
        // маркер) удалён во избежание ложного «поддерживается».
        return 'unsupported';
    }

    /** Прочитать скрипт целиком (до лимита). null — если недоступен/пуст. */
    private function tryReadScript($ftp, string $path): ?string
    {
        $content = null;
        try { $content = $ftp->tryGetContent($path); } catch (\Throwable $e) { $content = null; }
        if (!is_string($content) || $content === '') return null;
        if (strlen($content) > self::MAX_SCRIPT_BYTES) {
            // читаем полностью для fingerprint, но registry смотрит сигнатуры —
            // ограничение защищает от гигантских файлов.
            $content = substr($content, 0, self::MAX_SCRIPT_BYTES);
        }
        return $content;
    }

    /** Ядро variant-сигнатуры: механизм ротации/состояния. */
    private function hasVariantCore(string $content): bool
    {
        return (bool)preg_match(
            '~variant[\s_-]?state|variant\s+rotated|refresh_nonce|manual_nonce'
            . '|variant-state\.json|variant_manual_rotate|variant_read_state'
            . '|variant_write_state|variant_engine~i', $content);
    }

    /**
     * Просканировать require/include из variant-скрипта на variant-core.
     * Только относительные includes в каталоге сайта, до 6 кандидатов.
     */
    private function includeFilesHaveVariantCore($ftp, string $dir, string $content): bool
    {
        $m = [];
        if (!preg_match_all('~(?:require|include)(?:_once)?\s*\(?\s*__DIR__\s*\.\s*[\'"]([^\'"]+)[\'"]~', $content, $m)) {
            preg_match_all('~(?:require|include)(?:_once)?\s*\(?\s*[\'"]([^\'"]+\.php)[\'"]~', $content, $m);
        }
        $cands = array_slice(array_unique($m[1] ?? []), 0, 6);
        foreach ($cands as $rel) {
            $rel = ltrim($rel, '/');
            if ($rel === '' || strpos($rel, '..') !== false) continue;
            $path = ($dir === '' || $dir === '.') ? $rel : rtrim($dir, '/') . '/' . $rel;
            $c = null;
            try { $c = $ftp->tryGetContent($path); } catch (\Throwable $e) { $c = null; }
            if ($c !== null && $this->hasVariantCore($c)) return true;
        }
        return false;
    }

    /** manual_secret из live config.php (те же кандидаты путей, что в оркестраторе). */
    private function extractManualSecret($ftp, string $base): ?string
    {
        $candidates = [];
        if ($base !== '') {
            $candidates[] = $base . 'config.php';
            $candidates[] = $base . 'public/config.php';
        }
        $candidates[] = 'config.php';
        $candidates[] = '/config.php';
        $candidates[] = 'public/config.php';
        $candidates[] = '/public/config.php';

        $content = '';
        foreach ($candidates as $p) {
            try {
                $c = $ftp->tryGetContent($p);
            } catch (\Throwable $e) {
                $c = null;
            }
            if ($c !== null && $c !== '') { $content = $c; break; }
        }
        if ($content === '') return null;
        if (preg_match('~[\'"]manual_secret[\'"]\s*=>\s*[\'"]([^\'"]*)[\'"]~', $content, $m)) {
            $secret = (string)$m[1];
            return $secret !== '' ? $secret : null;
        }
        return null;
    }

    private function loadSite(int $siteId): ?array
    {
        try {
            $st = DB::pdo()->prepare("SELECT * FROM sites_managed WHERE id = ?");
            $st->execute([$siteId]);
            $row = $st->fetch();
            return is_array($row) ? $row : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function makeFtp(array $site)
    {
        if ($this->ftpFactory !== null) {
            return ($this->ftpFactory)($site);
        }
        return new FtpService(
            (string)$site['ftp_host'],
            (string)$site['ftp_user'],
            Crypto::decrypt((string)$site['ftp_pass_enc'])
        );
    }
}
