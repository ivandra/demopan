<?php
/**
 * Правила автоматического отключения/включения редиректов на сайтах
 * во время перевыставления.
 *
 * Каждое правило обрабатывается независимо. На один сайт может сработать
 * несколько правил (если, например, в .htaccess Redirect 302 И в config.php
 * $redirect_enabled).
 *
 * Структура правила:
 *   id              — уникальный идентификатор для логов
 *   description     — человеко-читаемое описание
 *   file            — какой файл проверяем и в нём же делаем замены
 *
 *   detect          — regex для определения "есть ли активный редирект"
 *                     (если совпадение есть — правило применяется)
 *
 *   disable_find    — regex для поиска строки в файле
 *   disable_replace — на что заменить (можно использовать ${1}, ${2})
 *
 *   enable_find     — regex для поиска ОТКЛЮЧЁННОЙ строки
 *   enable_replace  — на что заменить чтобы вернуть рабочий редирект
 *
 * Маркер `REFRESH-DISABLED` важен:
 *   - помогает enable точно найти строку отключённую нашей панелью
 *   - не спутать с другими комментариями
 *   - человек видит что это сделала рефреш-панель и можно понять почему
 *
 * Чтобы добавить новое правило — просто добавь массив в конец списка.
 * Никакого кода менять не нужно.
 */

return [

    // ============================================================
    // 1. Redirect 302/301 /play в .htaccess (zooma и подобные)
    // ============================================================
    [
        'id' => 'htaccess_redirect_play',
        'description' => 'Redirect 302/301 /play ... в .htaccess',
        'file' => '.htaccess',

        // Детект: ищем активную строку Redirect 30N /play (не закомментированную)
        'detect' => '~^[ \t]*Redirect\s+30[12]\s+/\S+\s+\S+~mi',

        // Disable: добавляем "# REFRESH-DISABLED: " в начало строки
        // Захватываем оригинальную строку целиком чтобы потом восстановить
        'disable_find'    => '~^([ \t]*)(Redirect\s+30[12]\s+/\S+\s+\S+)$~mi',
        'disable_replace' => '${1}# REFRESH-DISABLED: ${2}',

        // Enable: убираем маркер
        'enable_find'    => '~^([ \t]*)# REFRESH-DISABLED:\s+(Redirect\s+30[12]\s+/\S+\s+\S+)$~mi',
        'enable_replace' => '${1}${2}',
    ],

    // ============================================================
    // 2. $redirect_enabled = 1 в config.php (7k и подобные)
    // ============================================================
    [
        'id' => 'php_redirect_enabled_var',
        'description' => '$redirect_enabled = 1 в config.php',
        'file' => 'config.php',

        // Детект: переменная установлена в 1
        'detect' => '~\$redirect_enabled\s*=\s*1\s*;~',

        // Disable: меняем 1 на 0 + комментарий маркер
        'disable_find'    => '~(\$redirect_enabled\s*=\s*)1(\s*;)~',
        'disable_replace' => '${1}0${2} // REFRESH-DISABLED',

        // Enable: меняем 0 обратно на 1, убираем маркер
        // Допускаем что между 0 и REFRESH-DISABLED может быть пробел/комментарий
        'enable_find'    => '~(\$redirect_enabled\s*=\s*)0(\s*;)\s*//\s*REFRESH-DISABLED~',
        'enable_replace' => '${1}1${2}',
    ],

    // ============================================================
    // 3. handleRequest($config); в index.php (zooma и подобные)
    // ============================================================
    //
    // У zooma index.php содержит свою логику редиректа на партнёрку:
    //
    //     $baseNew    = "https://partners7k-promo.com/l/.../sub_id=Dzooma-25";
    //     $configRed = [...];
    //     function handleRequest($config) { ... header('Location: ...'); ... }
    //     handleRequest($configRed);   <- вот этот вызов запускает редирект
    //     ... затем закрытие php-блока и HTML страницы ...
    //
    // Чтобы временно отключить редирект — комментируем вызов handleRequest().
    // Логика остаётся определённой, просто не вызывается. После refresh —
    // раскомментируем обратно.
    //
    // ВАЖНО: даже если в .htaccess Redirect 302 /play отключён, эта строка в
    // index.php всё равно отправляет пользователя на партнёрку с устаревшим sub_id.
    // Поэтому критично выключать ОБА механизма перед refresh.
    [
        'id' => 'php_index_handle_request',
        'description' => 'handleRequest($configRed) в index.php (zooma)',
        'file' => 'index.php',

        // Детект: активный (не закомментированный) вызов handleRequest($var);
        'detect' => '~^[ \t]*handleRequest\s*\(\s*\$\w+\s*\)\s*;~mi',

        // Disable: комментируем строку с маркером, сохраняя trailing whitespace
        'disable_find'    => '~^([ \t]*)(handleRequest\s*\(\s*\$\w+\s*\)\s*;)([ \t]*)$~mi',
        'disable_replace' => '${1}// REFRESH-DISABLED: ${2}${3}',

        // Enable: убираем маркер
        'enable_find'    => '~^([ \t]*)// REFRESH-DISABLED:\s+(handleRequest\s*\(\s*\$\w+\s*\)\s*;)([ \t]*)$~mi',
        'enable_replace' => '${1}${2}${3}',
    ],

    // ============================================================
    // ============================================================
    // 4. v17.13: $site['redirect']['enabled'] => 1 (enomo v3 шаблон)
    // ============================================================
    //
    // Шаблон enomo v3 (zooma и другие новые сайты) хранит конфигурацию
    // в массиве $site = [...] с вложенным $site['redirect'] = [...].
    // Включённое состояние:
    //
    //     'redirect' => [
    //         'enabled' => 1,
    //         'partner_override_url' => '',
    //         'internal_reg_url' => 'https://...',
    //         ...
    //     ],
    //
    // Чтобы выключить — меняем 1 на 0 + комментарий-маркер.
    //
    // ВАЖНО: regex использует lookhead на 'redirect' => [ чтобы не задеть
    // другие 'enabled' (например в $variant_settings['enabled'] => true).
    [
        'id' => 'php_site_redirect_array_enabled',
        'description' => "\$site['redirect']['enabled'] => 1 в config.php (enomo v3)",
        'file' => 'config.php',

        // Detect: контекст 'redirect' => [ ... 'enabled' => 1
        'detect' => "~'redirect'\s*=>\s*\[[^\]]*?'enabled'\s*=>\s*1~s",

        // Disable: меняем 1 → 0 с маркером, сохраняя контекст redirect через capture group
        'disable_find'    => "~('redirect'\s*=>\s*\[[^\]]*?'enabled'\s*=>\s*)1(\s*,)~s",
        'disable_replace' => '${1}0${2} /* REFRESH-DISABLED */',

        // Enable: убираем маркер, возвращаем 0 → 1
        'enable_find'    => "~('redirect'\s*=>\s*\[[^\]]*?'enabled'\s*=>\s*)0(\s*,)\s*/\*\s*REFRESH-DISABLED\s*\*/~s",
        'enable_replace' => '${1}1${2}',
    ],

    // ============================================================
    // Сюда добавляются новые правила по мере появления шаблонов.
    //
    // Пример заготовки для RewriteRule на партнёрский домен:
    //
    // [
    //     'id' => 'htaccess_rewrite_partner',
    //     'description' => 'RewriteRule .* https://partners.../...',
    //     'file' => '.htaccess',
    //     'detect' => '~RewriteRule.+(partner|promo|aff|7kpromo)~mi',
    //     'disable_find'    => '~^([ \t]*)(RewriteRule\s+\S+\s+\S+\s+\[[^\]]*\])$~mi',
    //     'disable_replace' => '${1}# REFRESH-DISABLED: ${2}',
    //     'enable_find'    => '~^([ \t]*)# REFRESH-DISABLED:\s+(RewriteRule.+)$~mi',
    //     'enable_replace' => '${1}${2}',
    // ],

];
