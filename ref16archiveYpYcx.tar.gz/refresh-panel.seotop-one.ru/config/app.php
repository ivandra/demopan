<?php

return [
    // Сменить на свой случайный ключ длиной 32+ символа
    'app_key' => 'WobIWMtYlQqqimAsEYiRnjJbygISuQcU',

    'env' => 'prod', // prod|dev

    // Логин/пароль для входа в панель.
    // Пароль хранится как plain (для простоты беты), позже перейдём на хеш.
    'auth' => [
        'username' => 'admin',
        'password' => 'seotimoha',
    ],
	
	'app' => [
		'url' => 'https://refresh-panel.seotop-one.ru',
	],
	
	  // FASTPANEL
   'fastpanel' => [
        'timeout' => 30,
        'default_ip' => '95.129.234.52', // тот IP, который выбираешь в мастере
         'verify_tls' => false,
        'add_www_alias' => true,
         'ssl_email' => 'support@pro-managed.com',
         'temp_proxy_base' => 'http://95.129.234.20:7777',
    ],

    'namecheap' => [
        'sandbox' => false,
        'endpoint_sandbox' => 'https://api.sandbox.namecheap.com/xml.response',
        'endpoint'         => 'https://api.namecheap.com/xml.response',
        'max_price_usd'    => 12.0,
        'timeout'          => 30,
    ],

    // Cron-токен — для защиты вызовов /cron/*
    'cron' => [
        'token' => 'ezygulhvri',
        // v18.1.29: Сколько джоб обрабатывать за один cron-tick.
        // ВНИМАНИЕ: это DEFAULT-значение. Реальная настройка хранится в БД
        // (таблица app_settings, ключ 'cron.max_jobs_per_tick') и меняется
        // оператором через /settings → «Параллельная обработка джоб».
        // Это значение используется только как fallback если в БД нет записи
        // (миграция 018 не применена).
        'max_jobs_per_tick' => 5,
    ],
];
