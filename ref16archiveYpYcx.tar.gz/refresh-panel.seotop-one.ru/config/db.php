<?php


return [
    'host' => 'localhost',
    'port' => 3306,
    'db'   => 'refresh_pane',
    'user' => 'refresh_pane',
    'pass' => 'pXNi)%U{01a=fV|+',
];
