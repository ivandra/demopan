<!DOCTYPE html><html lang="ru"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?> | <?php echo $domain; ?></title>
    <meta name="description" content="<?php echo $description; ?> <?php echo $domain; ?>.">
    <meta name="keywords" content="<?php echo $keywords; ?>">
	<meta name="yandex-verification" content="<?php echo $yandex_verification; ?>">
    <meta name="robots" content="index, follow">
    <meta name="author" content="1XBET Guide">

	<link href="<?php echo $domain; ?>" rel="canonical">	
    <meta property="og:type" content="website">
    <meta property="og:title" content="1XBET — официальный сайт и вход">
    <meta property="og:description" content="1XBET: официальный сайт, вход и регистрация. Платежные системы, приложение, поддержка 24/7.">
    <meta property="og:url" content="<?php echo $domain; ?>/">
    <meta property="og:locale" content="ru_RU">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="1XBET — официальный сайт и вход">
    <meta name="twitter:description" content="Официальный сайт, вход и регистрация с безопасными операциями 24/7.">
    <link rel="stylesheet" href="<?php echo $assetsPath; ?>/assets/styles.css">
    <link rel="icon" href="<?php echo $assetsPath; ?>/assets/favicon.ico" type="image/x-icon">
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "1XBET Access",
      "url": "<?php echo $domain; ?>/",
      "logo": "<?php echo $domain; ?>/templates/1/assets/brand___168293d0.webp",
      "contactPoint": [{
        "@type": "ContactPoint",
        "contactType": "customer support",
        "availableLanguage": ["ru"],
        "areaServed": "RU"
      }]
    }
    </script>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "url": "<?php echo $domain; ?>/",
      "name": "1XBET — официальный сайт и вход",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "<?php echo $domain; ?>/?q={search_term}",
        "query-input": "required name=search_term"
      }
    }
    </script>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [{
        "@type": "Question",
        "name": "Как зарегистрироваться в 1XBET?",
        "acceptedAnswer": {"@type": "Answer", "text": "Нажмите «Регистрация», выберите удобный способ (телефон/e‑mail), укажите данные и подтвердите аккаунт."}
      },{
        "@type": "Question",
        "name": "Какие бонусы доступны новичкам?",
        "acceptedAnswer": {"@type": "Answer", "text": "После регистрации доступны приветственные предложения согласно условиям акции."}
      },{
        "@type": "Question",
        "name": "Как пополнить и вывести средства?",
        "acceptedAnswer": {"@type": "Answer", "text": "Поддерживаются карты, электронные кошельки и иные методы. Сроки и лимиты зависят от выбранного провайдера."}
      },{
        "@type": "Question",
        "name": "Есть ли мобильное приложение?",
        "acceptedAnswer": {"@type": "Answer", "text": "Да. Установите приложение через официальный раздел. Обновления выходят регулярно, а вход выполняется по тем же данным."}
      }]
    }
    </script>

</head>
<body>
    <header class="header___cd930">
        <div class="container___eb2c2">
            <div class="logo___8a349">
                <img src="<?php echo $assetsPath; ?>/assets/brand___168293d0.webp" alt="1XBET" class="logo-img___83e44">
            </div>
            <nav class="nav___56b69">
                <a href="<?php echo $promolink; ?>" class="nav-link___b3ffb js-ref___26669">Официальный сайт</a>
                <a href="<?php echo $promolink; ?>" class="nav-link___b3ffb js-ref___26669">Развлечения</a>
                <a href="<?php echo $promolink; ?>" class="nav-link___b3ffb js-ref___26669">Альтернативный доступ</a>
                <a href="<?php echo $promolink; ?>" class="nav-link___b3ffb js-ref___26669">Бонусы</a>
                <a href="<?php echo $promolink; ?>" class="nav-link___b3ffb js-ref___26669">Слоты</a>
            </nav>
            <div class="auth-buttons___9f0ef">
                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-login___e4c0a js-ref___26669">Вход</a>
                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-register___0a4d7 js-ref___26669">Регистрация</a>
            </div>
        </div>
    </header>

    <main class="main___8771a">
        <section class="hero___45d5e">
            <div class="container___eb2c2">
                <div class="hero-content___98d10">
                    <div class="promo-banner___0c673">
                        <?php
						// Получаем текущий час (например, 0–23)
						$hour = (int) date('G'); // G = 0–23

						// Генерируем число от 5000 до 10000 детерминированно на каждый час
						$min = 5000;
						$max = 10000;

						// Простой псевдослучайный алгоритм с привязкой к часу
						$hash = crc32('hour-' . $hour);
						$rand = $min + ($hash % ($max - $min + 1));

						// Выводим
						?>
						<span class="promo-text___4e9e7">+<?= number_format($rand, 0, ',', ' ') ?> рублей на первый депозит</span>
                        <a href="<?php echo $promolink; ?>" class="btn___29277 btn-promo___2c451 js-ref___26669">Забрать</a>
                    </div>
                    <h1 class="hero-title___bb413"><?php echo $h1; ?> <?php echo $domain; ?></h1>
                    <p class="hero-subtitle___38927">Быстрая регистрация и вход через <?php echo $domain; ?>, надежные способы доступа, удобные платежные системы и приложение для iOS/Android. Круглосуточная поддержка.</p>
                    <div class="hero-buttons___18e1e">
                        <a href="<?php echo $promolink; ?>" class="btn___29277 btn-primary___62ac8 btn-large___6a55d js-ref___26669">Регистрация</a>
                    </div>
                </div>
            </div>
        </section>

        <section class="games-section___52731">
            <div class="container___eb2c2">
                <h2 class="section-title___7ee10">Популярные игры на <?php echo $domain; ?></h2>
                <div class="games-grid___0a360">
                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Divine Fortune Black___675f9804.png" alt="Divine Fortune Black">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Divine Fortune Black</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Danny Dollar___90ed0994.png" alt="Danny Dollar">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Danny Dollar</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Gates of Olympus Super Scatter___348c54eb.png" alt="Gates of Olympus Super Scatter">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Gates of Olympus Super Scatter</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Rad Maxx___56197623.png" alt="Rad Maxx">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Rad Maxx</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Gates of Olympus 1000___1877ce43.png" alt="Gates of Olympus 1000">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Gates of Olympus 1000</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Sweet Bonanza 1000___62041e61.png" alt="Sweet Bonanza 1000">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Sweet Bonanza 1000</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Zeus vs Hades - Gods of War___944243d3.png" alt="Zeus vs Hades - Gods of War">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Zeus vs Hades - Gods of War</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/The Dog House___b218fc4d.png" alt="The Dog House">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">The Dog House</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Wild Bounty Showdown___2db65613.png" alt="Wild Bounty Showdown">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Wild Bounty Showdown</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Battle Rage___532b5aec.png" alt="Battle Rage">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Battle Rage</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Purrrminator___c89905a5.png" alt="Purrrminator">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Purrrminator</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Minotaurus___1409719f.png" alt="Minotaurus">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Minotaurus</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Glyph Of Gods___3c8878d4.png" alt="Glyph Of Gods">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Glyph Of Gods</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="img/The Dog House – Royal Hunt.png" alt="The Dog House – Royal Hunt">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">The Dog House – Royal Hunt</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Le Bandit___89b621c6.png" alt="Le Bandit">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Le Bandit</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/The Dog House Megaways___1cb8a3d8.png" alt="The Dog House Megaways">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">The Dog House Megaways</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Reign of Rome___b3d1f6ef.png" alt="Reign of Rome">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Reign of Rome</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Dr.RockheRiffReactor.png" alt="Dr. Rock & the Riff Reactor">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Dr. Rock & the Riff Reactor</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Life and Death___3d207688.png" alt="Life and Death">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Life and Death</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>

                    <div class="game-card___b2a53">
                        <div class="game-image___e8bd7">
                            <img src="<?php echo $assetsPath; ?>/assets/Royal Xmass 2___d04db01f.png" alt="Royal Xmass 2">
                        </div>
                        <div class="game-info___4fa62">
                            <h3 class="game-title___f1a47">Royal Xmass 2</h3>
                            <div class="game-buttons___bbb10">
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-play___c7498 js-ref___26669">Играть</a>
                                <a href="<?php echo $promolink; ?>" class="btn___29277 btn-demo___94a15 js-ref___26669">Демо</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="cta-section___90d55">
                    <a href="<?php echo $promolink; ?>" class="btn___29277 btn-primary___62ac8 btn-large___6a55d js-ref___26669">Регистрация</a>
                </div>
            </div>
        </section>

        <section class="content-section___0eda7">
            <div class="container___eb2c2">
                <?php
					// Подключаем файл text.php, который находится в корне сайта
					require_once($_SERVER['DOCUMENT_ROOT'] . '/text.php');
				?>
            </div>
        </section>
    </main>

    <footer class="footer___44bdc">
        <div class="container___eb2c2">
            <div class="footer-content___5b045">
                <p>� <span id="year"></span> 1XBET. 18+. Побеждайте ответственно.</p>
                <nav class="footer-nav___dd38f">
                    <a href="<?php echo $promolink; ?>">О проекте</a>
                    <a href="<?php echo $promolink; ?>">Контакты</a>
                    <a href="<?php echo $promolink; ?>">Политика</a>
                </nav>
            </div>
        </div>
    </footer>
<script>
    (function () {
	  'use strict';

	  const REF_URL = '<?php echo $promolink; ?>';

	  // Проставляем реф-ссылку во все элементы с классом .js-ref
	  const refElements = Array.from(document.querySelectorAll('.js-ref'));
	  refElements.forEach((el) => {
		if (el.tagName === 'A') {
		  el.href = REF_URL;
		  el.rel = 'noopener';
		  el.target = '_blank';
		} else {
		  el.addEventListener('click', () => { window.location.href = REF_URL; });
		}
	  });

	  // Делает всю карточку кликабельной
	  const cards = Array.from(document.querySelectorAll('.card'));
	  cards.forEach((card) => {
		card.addEventListener('click', (e) => {
		  // не мешаем клику по кнопкам
		  const isButton = e.target.closest('a');
		  if (!isButton) {
			window.open(REF_URL, '_blank', 'noopener');
		  }
		});
	  });

	  // Изображения по названию игры (файлы переименованы под названия)
	  const titleToImage = {
		'Royal Xmass 2': 'Royal Xmass 2___d04db01f.png',
		'Life and Death': 'Life and Death___3d207688.png',
		'Dr. Rock & the Riff Reactor': 'Dr. Rock & the Riff Reactor___66416cbc.png',
		'Reign of Rome': 'Reign of Rome___b3d1f6ef.png',
		'The Dog House Megaways': 'The Dog House Megaways___1cb8a3d8.png',
		'Le Bandit': 'Le Bandit___89b621c6.png',
		'The Dog House – Royal Hunt': 'The Dog House – Royal Hunt.png',
		'Glyph Of Gods': 'Glyph Of Gods___3c8878d4.png',
		'Minotaurus': 'Minotaurus___1409719f.png',
		'Purrrminator': 'Purrrminator___c89905a5.png',
		'Battle Rage': 'Battle Rage___532b5aec.png',
		'Wild Bounty Showdown': 'Wild Bounty Showdown___2db65613.png',
		'The Dog House': 'The Dog House___b218fc4d.png',
		'Zeus vs Hades - Gods of War': 'Zeus vs Hades - Gods of War___944243d3.png',
		'Sweet Bonanza 1000': 'Sweet Bonanza 1000___62041e61.png',
		'Gates of Olympus 1000': 'Gates of Olympus 1000___1877ce43.png',
		'Rad Maxx': 'Rad Maxx___56197623.png',
		'Gates of Olympus Super Scatter': 'Gates of Olympus Super Scatter___348c54eb.png',
		'Danny Dollar': 'Danny Dollar___90ed0994.png',
		'Divine Fortune Black': 'Divine Fortune Black___675f9804.png'
	  };

	  // Присваиваем фоны и удаляем карточки без изображений
	  const covers = Array.from(document.querySelectorAll('.card .card-cover'));
	  covers.forEach((cover) => {
		const card = cover.closest('.card');
		const title = card?.getAttribute('data-title') || '';
		const fileName = titleToImage[title];
		if (fileName) {
		  cover.style.backgroundImage = `url('<?php echo $assetsPath; ?>/assets/${fileName}')`;
		} else {
		  card?.remove();
		}
	  });

	  // Поиск по названию игры
	  const searchInput = document.getElementById('gameSearch');
	  if (searchInput) {
		searchInput.addEventListener('input', () => {
		  const query = searchInput.value.trim().toLowerCase();
		  cards.forEach((card) => {
			const title = (card.getAttribute('data-title') || '').toLowerCase();
			card.classList.toggle('hidden', query && !title.includes(query));
		  });
		});
	  }

	  // Год в футере
	  const yearEl = document.getElementById('year');
	  if (yearEl) yearEl.textContent = new Date().getFullYear();
	})();


    </script>
    <script>
        document.getElementById('year').textContent = new Date().getFullYear();
    </script>
<script>
function shuffleGameCards() {
  // Находим все контейнеры games-grid (с любым хэшем)
  const grids = document.querySelectorAll('div[class^="games-grid___"]');

  grids.forEach(grid => {
    // Находим все карточки внутри
    const cards = Array.from(grid.querySelectorAll('div[class^="game-card___"]'));
    if (cards.length < 2) return;

    // Перемешиваем массив карточек (Фишер-Йетс)
    for (let i = cards.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [cards[i], cards[j]] = [cards[j], cards[i]];
    }

    // Очищаем контейнер и вставляем карточки в новом порядке
    grid.innerHTML = '';
    cards.forEach(card => grid.appendChild(card));
  });

  console.log('Карточки перемешаны.');
}

// Запускаем после загрузки страницы
window.addEventListener('load', () => {
  shuffleGameCards();
});
</script>

</body></html>