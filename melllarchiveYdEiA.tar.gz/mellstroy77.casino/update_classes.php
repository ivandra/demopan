<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// === НАСТРОЙКИ ===
$ENABLE_IMAGE_REPLACEMENT = true;

$basePath = __DIR__ . '/templates/1';
$sourcePath = $basePath . '/source';
$assetsPath = $basePath . '/assets';
$assetsPathCSS = $basePath . '/assets';

$mappingFile = "$sourcePath/class_name_mapping.txt";
$imageMapFile = "$sourcePath/image_mapping.txt";

$phpSourceFiles = [
    'header-php.txt' => 'header.php'
];

$cssSourceFiles = [
    'styles-css.txt' => 'styles.css',
];

// === Утилиты ===
function generateNewClassName($oldName) {
    return $oldName . '___' . substr(md5(uniqid($oldName, true)), 0, 5);
}

function generateImageSuffix() {
    return substr(md5(uniqid(mt_rand(), true)), 0, 8);
}

// === 1. Обновление class_name_mapping.txt ===
function updateClassNameMapping($filePath) {
    if (!file_exists($filePath)) {
        echo "⚠️ class_name_mapping.txt не найден, создаю новый.\n";
        file_put_contents($filePath, "");
        return [];
    }

    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $newMapping = [];

    foreach ($lines as $line) {
        list($original, ) = explode(':', $line);
        $new = generateNewClassName($original);
        $newMapping[] = "$original:$new";
    }

    file_put_contents($filePath, implode("\n", $newMapping));

    $assoc = [];
    foreach ($newMapping as $line) {
        list($k, $v) = explode(':', $line);
        $assoc[$k] = $v;
    }

    return $assoc;
}

function replaceClasses($content, $mapping) {
    return preg_replace_callback('/class="([^"]+)"/', function ($matches) use ($mapping) {
        $classes = preg_split('/\s+/', $matches[1]);
        $new = array_map(function ($c) use ($mapping) {
            return isset($mapping[$c]) ? $mapping[$c] : $c;
        }, $classes);
        return 'class="' . implode(' ', $new) . '"';
    }, $content);
}

// === 2. Обработка PHP-файлов ===
function processPhpFiles($sourcePath, $targetPath, $files, $classMap, $imageMap) {
    foreach ($files as $src => $target) {
        $srcFile = "$sourcePath/$src";
        $dstFile = "$targetPath/$target";

        if (!file_exists($srcFile)) {
            echo "⚠️ Пропущен $srcFile\n";
            continue;
        }

        $content = file_get_contents($srcFile);
        $content = replaceClasses($content, $classMap);

        foreach ($imageMap as $original => $new) {
            $content = str_replace($original, $new, $content);
        }

        file_put_contents($dstFile, $content);
        echo "✅ Обновлён: $dstFile\n";
    }
}

// === 3. Обработка CSS-файлов ===
function processCssFiles($sourcePath, $targetPath, $files, $classMap, $imageMap) {
    foreach ($files as $src => $target) {
        $srcFile = "$sourcePath/$src";
        $dstFile = "$targetPath/$target";

        if (!file_exists($srcFile)) {
            echo "⚠️ Пропущен $srcFile\n";
            continue;
        }

        $content = file_get_contents($srcFile);
        $content = preg_replace_callback('/\.([a-zA-Z0-9_-]+)/', function ($matches) use ($classMap) {
            return '.' . (isset($classMap[$matches[1]]) ? $classMap[$matches[1]] : $matches[1]);
        }, $content);

        foreach ($imageMap as $original => $new) {
            $content = str_replace($original, $new, $content);
        }

        file_put_contents($dstFile, $content);
        echo "✅ Обновлён: $dstFile\n";
    }
}

// === 4. Переименование изображений ===
function renameImagesAlways($assetsPath, $mapFile) {
    if (!is_writable($assetsPath)) {
        echo "❌ Папка недоступна для записи: $assetsPath\n";
        return [];
    }

    $files = scandir($assetsPath);
    $mapping = [];
    $log = [];

    foreach ($files as $file) {
        if (in_array($file, ['.', '..'])) continue;

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'svg'])) continue;

        $rawName = pathinfo($file, PATHINFO_FILENAME);
        $baseName = preg_replace('/___[a-f0-9]{8}$/', '', $rawName);  // удаляем старый хеш, если был
        $originalName = $baseName . '.' . $ext;
        $originalPath = "$assetsPath/$file";

        // Генерируем новое имя
        $newName = $baseName . '___' . generateImageSuffix() . '.' . $ext;
        $newPath = "$assetsPath/$newName";

        $attempt = 0;
        while (file_exists($newPath) && $attempt++ < 5) {
            $newName = $baseName . '___' . generateImageSuffix() . '.' . $ext;
            $newPath = "$assetsPath/$newName";
        }

        // Копируем старый файл под новым именем
        if (@copy($originalPath, $newPath)) {
            $mapping[$originalName] = $newName;
            $log[] = "🖼 $file → $newName";

            // Удаляем старую версию только если имя отличается
            if ($newName !== $file) {
                @unlink($originalPath);
            }
        } else {
            $log[] = "❌ Не удалось переименовать $file";
        }
    }

    // Сохраняем отображение original → new
    if (!empty($mapping)) {
        $lines = array_map(function ($orig) use ($mapping) {
            return "$orig:{$mapping[$orig]}";
        }, array_keys($mapping));
        file_put_contents($mapFile, implode("\n", $lines));
    }

    file_put_contents("$assetsPath/rename_log.txt", implode("\n", $log));

    return $mapping;
}


// === ЗАПУСК ===
echo "🚀 Старт...\n";

if (!is_dir($basePath) || !is_dir($sourcePath)) {
    echo "❌ Ошибка: нет нужных директорий.\n";
    exit;
}

$classMapping = updateClassNameMapping($mappingFile);
$imageMapping = $ENABLE_IMAGE_REPLACEMENT ? renameImagesAlways($assetsPath, $imageMapFile) : [];

processPhpFiles($sourcePath, $basePath, $phpSourceFiles, $classMapping, $imageMapping);
processCssFiles($sourcePath, $assetsPathCSS, $cssSourceFiles, $classMapping, $imageMapping);

echo "✅ Завершено.\n";
?>
