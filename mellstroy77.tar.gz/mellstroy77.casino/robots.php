<?php
require_once __DIR__ . '/config.php';

header('Content-Type: text/plain; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

/**
 * Нормализует host для безопасного сравнения:
 * - lowercase
 * - убирает завершающую точку
 * - убирает www.
 * - порт не учитывается
 */
function robotsNormalizeHost($value)
{
    $value = trim((string)$value);

    if ($value === '') {
        return '';
    }

    // Если передан полный URL — достаём host.
    if (strpos($value, '://') !== false) {
        $parsed = parse_url($value, PHP_URL_HOST);
        $value = is_string($parsed) ? $parsed : '';
    } else {
        // HTTP_HOST может содержать :port.
        $parsed = parse_url('http://' . $value, PHP_URL_HOST);
        $value = is_string($parsed) ? $parsed : $value;
    }

    $value = strtolower(rtrim($value, '.'));

    if (strpos($value, 'www.') === 0) {
        $value = substr($value, 4);
    }

    return $value;
}

$configHost = robotsNormalizeHost($domain);
$requestHost = robotsNormalizeHost(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');

/*
 * Если robots.php открыли через старый домен/чужой alias —
 * не разрешаем индексировать эту копию.
 */
if ($configHost === '' || $requestHost === '' || $requestHost !== $configHost) {
    echo "User-agent: *\n";
    echo "Disallow: /\n";
    exit;
}

/*
 * Правильный новый домен.
 */
$base = rtrim((string)$domain, '/');

echo "User-agent: *\n";
echo "Allow: /\n";
echo "Disallow: /reg\n";
echo "Host: " . $base . "/\n";
echo "Sitemap: " . $base . "/sitemap.xml\n";
